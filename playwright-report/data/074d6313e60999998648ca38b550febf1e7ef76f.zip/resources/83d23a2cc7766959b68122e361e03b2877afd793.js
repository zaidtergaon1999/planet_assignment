class bottomDrawer {
  constructor(id, options, events) {
    this.class = 'bottom-drawer';
    this.element = document.getElementById(id);
    this.elements = {
      overlay: this.element.lastElementChild
    };
    this.listeners = {
      _overlayClick: this._overlayClick.bind(this)
    }
    this.options = options;
    this.events = events;
    this._build();
  }
  _overlayClick(e) {
    this.events.close();
  }
  _build() {
    this.elements.overlay.addEventListener('click', this.listeners._overlayClick);
  }
}