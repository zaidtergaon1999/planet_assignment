class customLogin {
  constructor(id, options) {
    this.element = document.getElementById(id);
    this.class = 'login';
    this.options = options;
    this._build();
  }
  _setCSSVars() {
    this.element.style.setProperty('--login-background', `url('${this.options.backgroundURL}')`);
  }
  _build() {
    this._setCSSVars();
  }
}