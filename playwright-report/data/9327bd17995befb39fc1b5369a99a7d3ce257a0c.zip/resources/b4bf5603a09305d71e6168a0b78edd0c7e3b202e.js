define("ShopperPortalEU_UI_Theme.ShopperPortalEUUIThemeLayoutsComponents.Splash.mvc$model", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.Private.ApplicationLoadEvents.mvc$model"], function (OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_Theme_Private_ApplicationLoadEvents_mvcModel) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("Percentage", "percentageVar", "Percentage", true, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, false)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.fromStructure = function (str) {
return new VariablesRecord(new VariablesRecord.RecordClass({
percentageVar: OS.DataTypes.ImmutableBase.getData(str)
}));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Model._hasValidationWidgetsValue = undefined;
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
if((Model._hasValidationWidgetsValue === undefined)) {
Model._hasValidationWidgetsValue = ShopperPortalEU_UI_Theme_Private_ApplicationLoadEvents_mvcModel.hasValidationWidgets;
}

return Model._hasValidationWidgetsValue;
}
});

Model.prototype.setInputs = function (inputs) {
};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "ShopperPortalEUUIThemeLayoutsComponents.Splash");
});
define("ShopperPortalEU_UI_Theme.ShopperPortalEUUIThemeLayoutsComponents.Splash.mvc$view", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.controller", "react", "OutSystems/ReactView/Main", "ShopperPortalEU_UI_Theme.ShopperPortalEUUIThemeLayoutsComponents.Splash.mvc$model", "ShopperPortalEU_UI_Theme.ShopperPortalEUUIThemeLayoutsComponents.Splash.mvc$controller", "OutSystems/ReactWidgets/Main", "ShopperPortalEU_UI_Theme.Private.ApplicationLoadEvents.mvc$view"], function (OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ThemeController, React, OSView, ShopperPortalEU_UI_Theme_ShopperPortalEUUIThemeLayoutsComponents_Splash_mvc_model, ShopperPortalEU_UI_Theme_ShopperPortalEUUIThemeLayoutsComponents_Splash_mvc_controller, OSWidgets, ShopperPortalEU_UI_Theme_Private_ApplicationLoadEvents_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            var thisIsInstanceOfSuper = this instanceof _super;
            if (thisIsInstanceOfSuper == false) {
                return;
            }

            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "ShopperPortalEUUIThemeLayoutsComponents.Splash";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [ShopperPortalEU_UI_Theme_Private_ApplicationLoadEvents_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return ShopperPortalEU_UI_Theme_ShopperPortalEUUIThemeLayoutsComponents_Splash_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return ShopperPortalEU_UI_Theme_ShopperPortalEUUIThemeLayoutsComponents_Splash_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "splash",
visible: true,
_idProps: {
service: idService,
name: "Element"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Placeholder, {
align: /*Default*/ 0,
content: _this.props.placeholders.logo,
style: "splash__logo ph",
_idProps: {
service: idService,
name: "Logo"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(ShopperPortalEU_UI_Theme_Private_ApplicationLoadEvents_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onLoadComplete$Action: function (redirectURLIn) {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Private/ApplicationLoadEvents OnLoadComplete");
return controller.loadComplete$Action(redirectURLIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
onUpgradeProgress$Action: function (completedIn, totalIn) {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Private/ApplicationLoadEvents OnUpgradeProgress");
controller.upgradeProgress$Action(completedIn, totalIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "2",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("ShopperPortalEU_UI_Theme.ShopperPortalEUUIThemeLayoutsComponents.Splash.mvc$controller", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.controller", "ShopperPortalEU_UI_Theme.languageResources", "ShopperPortalEU_UI_Theme.ShopperPortalEUUIThemeLayoutsComponents.Splash.mvc$debugger"], function (OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ThemeController, ShopperPortalEU_UI_ThemeLanguageResources, ShopperPortalEU_UI_Theme_ShopperPortalEUUIThemeLayoutsComponents_Splash_mvc_Debugger) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = false;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._upgradeProgress$Action = function (completedIn, totalIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("UpgradeProgress");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Theme.ShopperPortalEUUIThemeLayoutsComponents.Splash.UpgradeProgress$vars"))());
vars.value.completedInLocal = completedIn;
vars.value.totalInLocal = totalIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("1ohZxgV1_kKH2z+Fu01SDQ:dayEcYmcUUqVrSkrH3lkEg:/NRWebFlows.uRd0Q1laQ0yzNZQMUt7Aug/NodesShownInESpaceTree.ovpCPvx7oUOWhmiag7YscQ/ClientActions.dayEcYmcUUqVrSkrH3lkEg:oJqPMXyc+MkE6fie4XxkAw", "ShopperPortalEU_UI_Theme", "UpgradeProgress", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:NhJnZv98p0W9G8EUY99IyA", callContext.id);
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:5jNNcf3FRUa_pUtA8B0nUA", callContext.id);
// Percentage = Completed / Total * 150
model.variables.percentageVar = OS.BuiltinFunctions.decimalToInteger(OS.BuiltinFunctions.trunc(OS.BuiltinFunctions.integerToDecimal(vars.value.completedInLocal).div(OS.BuiltinFunctions.integerToDecimal(vars.value.totalInLocal)).times(OS.BuiltinFunctions.integerToDecimal(150))));
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:xVjmSerfpUmJ_8uyjKrrEw", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("1ohZxgV1_kKH2z+Fu01SDQ:dayEcYmcUUqVrSkrH3lkEg", callContext.id);
}

};
Controller.registerVariableGroupType("ShopperPortalEU_UI_Theme.ShopperPortalEUUIThemeLayoutsComponents.Splash.UpgradeProgress$vars", [{
name: "Completed",
attrName: "completedInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Integer,
defaultValue: function () {
return 0;
}
}, {
name: "Total",
attrName: "totalInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Integer,
defaultValue: function () {
return 0;
}
}]);
Controller.prototype._loadComplete$Action = function (redirectURLIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("LoadComplete");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Theme.ShopperPortalEUUIThemeLayoutsComponents.Splash.LoadComplete$vars"))());
vars.value.redirectURLInLocal = redirectURLIn;
varBag.callContext = callContext;
varBag.vars = vars;
OutSystemsDebugger.push("1ohZxgV1_kKH2z+Fu01SDQ:NzWhnH0Nx0CLUOsg1wUzKA:/NRWebFlows.uRd0Q1laQ0yzNZQMUt7Aug/NodesShownInESpaceTree.ovpCPvx7oUOWhmiag7YscQ/ClientActions.NzWhnH0Nx0CLUOsg1wUzKA:0sYhYJHRXu42lr5ldLr_Ug", "ShopperPortalEU_UI_Theme", "LoadComplete", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:bCxubf7ooUmZ2DG0h8mgoA", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:k5z9w1DF+kirs_mn3GdvqA", callContext.id);
// Trigger Event: OnLoadComplete
return controller.onLoadComplete$Action(vars.value.redirectURLInLocal, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:YKCpS8yaHUaAljqQt2PLgw", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("1ohZxgV1_kKH2z+Fu01SDQ:NzWhnH0Nx0CLUOsg1wUzKA", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("1ohZxgV1_kKH2z+Fu01SDQ:NzWhnH0Nx0CLUOsg1wUzKA", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("ShopperPortalEU_UI_Theme.ShopperPortalEUUIThemeLayoutsComponents.Splash.LoadComplete$vars", [{
name: "RedirectURL",
attrName: "redirectURLInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);

Controller.prototype.upgradeProgress$Action = function (completedIn, totalIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._upgradeProgress$Action, callContext, completedIn, totalIn);

};
Controller.prototype.loadComplete$Action = function (redirectURLIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._loadComplete$Action, callContext, redirectURLIn);

};
Controller.prototype.onLoadComplete$Action = function () {
return Promise.resolve();
};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("1ohZxgV1_kKH2z+Fu01SDQ:uRd0Q1laQ0yzNZQMUt7Aug:/NRWebFlows.uRd0Q1laQ0yzNZQMUt7Aug:AOdtJWIZ_kUN4hGD9hTAnA", "ShopperPortalEU_UI_Theme", "ShopperPortalEUUIThemeLayoutsComponents", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("1ohZxgV1_kKH2z+Fu01SDQ:ovpCPvx7oUOWhmiag7YscQ:/NRWebFlows.uRd0Q1laQ0yzNZQMUt7Aug/NodesShownInESpaceTree.ovpCPvx7oUOWhmiag7YscQ:rEMyzrFgAOGSRcT6nlUuWg", "ShopperPortalEU_UI_Theme", "Splash", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("1ohZxgV1_kKH2z+Fu01SDQ:ovpCPvx7oUOWhmiag7YscQ", callContext.id);
OutSystemsDebugger.pop("1ohZxgV1_kKH2z+Fu01SDQ:uRd0Q1laQ0yzNZQMUt7Aug", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return ShopperPortalEU_UI_ThemeController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, ShopperPortalEU_UI_ThemeLanguageResources);
});

define("ShopperPortalEU_UI_Theme.ShopperPortalEUUIThemeLayoutsComponents.Splash.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"LaqodOxyT0CS9TVG5MKIOA": {
getter: function (varBag, idService) {
return varBag.vars.value.completedInLocal;
},
dataType: OS.DataTypes.DataTypes.Integer
},
"D_Y5IW+k6EeCezYOogBfFQ": {
getter: function (varBag, idService) {
return varBag.vars.value.totalInLocal;
},
dataType: OS.DataTypes.DataTypes.Integer
},
"swjKEI2pI0i0U1vIOKb4zQ": {
getter: function (varBag, idService) {
return varBag.vars.value.redirectURLInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"wbuOCf2pu0WQ_6+BfAu1_w": {
getter: function (varBag, idService) {
return varBag.model.variables.percentageVar;
},
dataType: OS.DataTypes.DataTypes.Integer
},
"cYN3IYZN9Uun8XcvjwuxhQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Element"));
})(varBag.model, idService);
}
},
"ev8nRJhFRkC+4n9unTTgLA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Logo"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
