class customButton {
  constructor(id, options) {
    this.class = 'custom-button';
    this.element = document.getElementById(id);
    this.stateClasses = {
      item: {
        element: this.class.concat('__item'),
        icon: this.class.concat('__icon'),
        content: this.class.concat('__content')
      },
      disabled: this.class.concat('--disabled'),
      icon: this.class.concat('--icon')
    };
    this.options = options;
    this._build();
  }
  _setElements() {
    this.elements = {
      button: this.element.querySelector('button'),
      item: {
        element: this.element.querySelector('.' + this.stateClasses.item.element),
        icon: this.element.querySelector('.' + this.stateClasses.item.icon),
        content: this.element.querySelector('.' + this.stateClasses.item.content)
      }
    }
  }
  _setProps() {
    if (this.elements.button) {
      this.elements.button.hasAttribute('disabled') ? this.element.classList.add(this.stateClasses.disabled) : this.element.classList.remove(this.stateClasses.disabled);
      if (this.options.testId) {
        this.elements.button.setAttribute('data-testid', this.options.testId);
        this.elements.item.content.setAttribute('data-testid', this.options.testId.concat('Label'));
        if (this.elements.item.icon) {
          this.elements.item.icon.setAttribute('data-testid', this.options.testId.concat('Icon'));
        }
      } else {
        this.elements.button.removeAttribute('data-testid');
        this.elements.item.content.removeAttribute('data-testid');
        if (this.elements.item.icon) {
          this.elements.item.icon.removeAttribute('data-testid');
        }
      }
    }
    if (this.elements.item.element) {
      this.elements.item.icon !== null && this.elements.item.content.childElementCount === 0 ? this.element.classList.add(this.stateClasses.icon) : this.element.classList.remove(this.stateClasses.icon);
    }
  }
  _build() {
    this._setElements();
    this._setProps();
  }
  parametersChanged(options) {
    this.options = options;
  }
  render() {
    this._setElements();
    this._setProps();
  }
}