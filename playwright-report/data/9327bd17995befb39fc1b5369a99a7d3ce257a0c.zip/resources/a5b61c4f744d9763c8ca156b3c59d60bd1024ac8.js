define("ShopperPortalEU.Refund.RefundHistory.mvc$model", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Theme.controller", "ShopperPortalEU_Forms_IS.controller", "ShopperPortalEU.controller", "ShopperPortalEU.Layouts.LayoutDetail.mvc$model", "ShopperPortalEU.LayoutsComponents.Back.mvc$model", "ShopperPortalEU.Common.DataLoading.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomList.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomLink.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomLinkItem.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCard.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.Flex.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomTag.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.FlexItem.mvc$model", "ShopperPortalEU_Forms_IS.model$FormInfo_WrapperRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Forms_IS", "ShopperPortalEU.model$FormInfo_WrapperList", "ShopperPortalEU_UI_Theme.model$LayoutDetailOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU_UI_Components.model$CustomListOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsIconRec", "ShopperPortalEU_UI_Components.model$CustomCardOptionsRec", "ShopperPortalEU_UI_Components.model$FlexOptionsRec", "ShopperPortalEU_UI_Components.model$CustomTagOptionsRec", "ShopperPortalEU_UI_Components.model$FlexItemOptionsRec", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", "ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger", "ShopperPortalEU_Forms_IS.controller$GetFormList", "ShopperPortalEU.controller$GroupFormsByDate", "ShopperPortalEU.controller$DefaultErrorMessage"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEU_Forms_ISModel, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ThemeController, ShopperPortalEU_Forms_ISController, ShopperPortalEUController, ShopperPortalEU_Layouts_LayoutDetail_mvcModel, ShopperPortalEU_LayoutsComponents_Back_mvcModel, ShopperPortalEU_Common_DataLoading_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomList_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLink_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLinkItem_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCard_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomTag_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FlexItem_mvcModel) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("IsDataFetched", "isDataFetchedVar", "IsDataFetched", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("HasError", "hasErrorVar", "HasError", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("Forms", "formsVar", "Forms", true, false, OS.DataTypes.DataTypes.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEUModel.FormInfo_WrapperList());
}, false, ShopperPortalEUModel.FormInfo_WrapperList), 
this.attr("HasTestUIAvailable", "hasTestUIAvailableVar", "HasTestUIAvailable", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Model._hasValidationWidgetsValue = undefined;
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
if((Model._hasValidationWidgetsValue === undefined)) {
Model._hasValidationWidgetsValue = (((((((((ShopperPortalEU_Layouts_LayoutDetail_mvcModel.hasValidationWidgets || ShopperPortalEU_LayoutsComponents_Back_mvcModel.hasValidationWidgets) || ShopperPortalEU_Common_DataLoading_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomList_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLink_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLinkItem_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCard_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomTag_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FlexItem_mvcModel.hasValidationWidgets);
}

return Model._hasValidationWidgetsValue;
}
});

Model.prototype.setInputs = function (inputs) {
};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "Refund.RefundHistory");
});
define("ShopperPortalEU.Refund.RefundHistory.mvc$view", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Theme.controller", "ShopperPortalEU_Forms_IS.controller", "react", "OutSystems/ReactView/Main", "ShopperPortalEU.Refund.RefundHistory.mvc$model", "ShopperPortalEU.Refund.RefundHistory.mvc$controller", "ShopperPortalEU.clientVariables", "ShopperPortalEU.Layouts.LayoutDetail.mvc$view", "OutSystems/ReactWidgets/Main", "ShopperPortalEU.LayoutsComponents.Back.mvc$view", "ShopperPortalEU.Common.DataLoading.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomList.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomLink.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomLinkItem.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCard.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.Flex.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomTag.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.FlexItem.mvc$view", "ShopperPortalEU_Forms_IS.model$FormInfo_WrapperRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Forms_IS", "ShopperPortalEU.model$FormInfo_WrapperList", "ShopperPortalEU_UI_Theme.model$LayoutDetailOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU_UI_Components.model$CustomListOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsIconRec", "ShopperPortalEU_UI_Components.model$CustomCardOptionsRec", "ShopperPortalEU_UI_Components.model$FlexOptionsRec", "ShopperPortalEU_UI_Components.model$CustomTagOptionsRec", "ShopperPortalEU_UI_Components.model$FlexItemOptionsRec", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", "ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger", "ShopperPortalEU_Forms_IS.controller$GetFormList", "ShopperPortalEU.controller$GroupFormsByDate", "ShopperPortalEU.controller$DefaultErrorMessage"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_Forms_ISModel, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ThemeController, ShopperPortalEU_Forms_ISController, React, OSView, ShopperPortalEU_Refund_RefundHistory_mvc_model, ShopperPortalEU_Refund_RefundHistory_mvc_controller, ShopperPortalEUClientVariables, ShopperPortalEU_Layouts_LayoutDetail_mvc_view, OSWidgets, ShopperPortalEU_LayoutsComponents_Back_mvc_view, ShopperPortalEU_Common_DataLoading_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomList_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLink_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLinkItem_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCard_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomTag_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FlexItem_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            var thisIsInstanceOfSuper = this instanceof _super;
            if (thisIsInstanceOfSuper == false) {
                return;
            }

            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "Refund.RefundHistory";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css", "css/ShopperPortalEU_UI_Theme.ShopperPortalEUUITheme.css", "css/ShopperPortalEU.ShopperPortalEU.css", "css/ShopperPortalEU_UI_Theme.ShopperPortalEUUITheme.extra.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [ShopperPortalEU_Layouts_LayoutDetail_mvc_view, ShopperPortalEU_LayoutsComponents_Back_mvc_view, ShopperPortalEU_Common_DataLoading_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomList_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLink_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLinkItem_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCard_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomTag_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FlexItem_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return ShopperPortalEU_Refund_RefundHistory_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return ShopperPortalEU_Refund_RefundHistory_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "Shopper Portal EU - Refund history";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(ShopperPortalEU_Layouts_LayoutDetail_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
afterAuthentication$Action: function (isAuthenticatedIn) {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Layouts/LayoutDetail AfterAuthentication");
return controller.layoutAfterAuthentication$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "0",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
headerLeft: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_LayoutsComponents_Back_mvc_view, {
inputs: {
ManualRedirect: true
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onClick$Action: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "LayoutsComponents/Back OnClick");
controller.backOnClick$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "1",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}),
headerCenter: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": ("RefundHistory_Title_" + (model.variables.formsVar.length).toString())
},
value: "Refund history",
_idProps: {
service: idService,
uuid: "2"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
headerRight: PlaceholderContent.Empty,
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_Common_DataLoading_mvc_view, {
inputs: {
IsDataFetched: model.variables.isDataFetchedVar,
HasError: model.variables.hasErrorVar
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "3",
alias: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomList_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "4",
alias: "4"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
list: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.List, {
animateItems: false,
extendedProperties: {
"disable-virtualization": "True",
"data-testid": "FormList"
},
gridProperties: {
classes: "OSFillParent"
},
mode: /*Default*/ 0,
source: model.variables.formsVar,
style: "list list-group",
tag: "div",
_idProps: {
service: idService,
name: "FormList_Active"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new IteratorPlaceholderContent(function (idService, callContext) {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "6"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.hasTestUIAvailableVar), asPrimitiveValue(model.variables.formsVar.length), asPrimitiveValue(model.variables.formsVar.getCurrentRowNumber(callContext.iterationContext)), asPrimitiveValue(model.variables.formsVar.getCurrent(callContext.iterationContext).refundAmountMessageAttr), asPrimitiveValue(model.variables.formsVar.getCurrent(callContext.iterationContext).refundAmountTxtAttr), asPrimitiveValue(model.variables.formsVar.getCurrent(callContext.iterationContext).refundLabel_UIAttr), asPrimitiveValue(model.variables.formsVar.getCurrent(callContext.iterationContext).merchantNameAttr), asPrimitiveValue(model.variables.formsVar.getCurrent(callContext.iterationContext).formStatusLabelAttr), asPrimitiveValue(model.variables.formsVar.getCurrent(callContext.iterationContext).formTagStateAttr), asPrimitiveValue(model.variables.formsVar.getCurrent(callContext.iterationContext).formNumberAttr), asPrimitiveValue(model.variables.formsVar.getCurrent(callContext.iterationContext).formDateTxtAttr)]
}, $if(((model.variables.formsVar.getCurrent(callContext.iterationContext).formDateTxtAttr) !== ("")), false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
className: model.getCachedValue(idService.getId("RefundDate_Ctn.class"), function () {
return (((model.variables.formsVar.getCurrentRowNumber(callContext.iterationContext) === 0)) ? ("body-4") : ("body-4 margin-top-05"));
}, function () {
return model.variables.formsVar.getCurrentRowNumber(callContext.iterationContext);
})
},
style: model.getCachedValue(idService.getId("RefundDate_Ctn.Style"), function () {
return ("body-4" + (((model.variables.formsVar.getCurrentRowNumber(callContext.iterationContext) === 0)) ? ("") : (" margin-top-05")));
}, function () {
return model.variables.formsVar.getCurrentRowNumber(callContext.iterationContext);
}),
visible: true,
_idProps: {
service: idService,
name: "RefundDate_Ctn"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": ("RefundDate_" + (model.variables.formsVar.getCurrentRowNumber(callContext.iterationContext)).toString())
},
value: model.variables.formsVar.getCurrent(callContext.iterationContext).formDateTxtAttr,
_idProps: {
service: idService,
uuid: "8"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
}, function () {
return [];
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: model.getCachedValue(idService.getId("n2GvzRhqNUeBNq+YEkAZjQ.Style"), function () {
return ("margin-top-02" + ((((model.variables.formsVar.getCurrentRowNumber(callContext.iterationContext)) !== ((model.variables.formsVar.length - 1)))) ? (" margin-bottom-04") : ("")));
}, function () {
return model.variables.formsVar.getCurrentRowNumber(callContext.iterationContext);
}, function () {
return model.variables.formsVar.length;
}),
visible: true,
_idProps: {
service: idService,
uuid: "9"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLink_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("Mxs1waLG+EuzKZJoji+GTA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomLinkOptionsRec();
rec.testIdAttr = ("FormCardLink_" + (model.variables.formsVar.getCurrentRowNumber(callContext.iterationContext)).toString());
rec.typeAttr = ShopperPortalEUModel.staticEntities.customLinkType.ghost;
return rec;
}();
}, function () {
return model.variables.formsVar.getCurrentRowNumber(callContext.iterationContext);
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "10",
alias: "5"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
link: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Link, {
enabled: true,
transition: OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default),
url: OS.Navigation.generateScreenURL("ShopperPortalEU", "RefundDetails", {
FormNumberIn: OS.DataConversion.ServerDataConverter.asString(model.variables.formsVar.getCurrent(callContext.iterationContext).formNumberAttr, OS.DataTypes.DataTypes.Text)
}),
visible: true,
_idProps: {
service: idService,
uuid: "11"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLinkItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "12",
alias: "6"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCard_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("T0jtcImFwkyeG3Oi4etksg.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomCardOptionsRec();
rec.clickableAttr = true;
rec.testIdAttr = ("FormCard_" + (model.variables.formsVar.getCurrentRowNumber(callContext.iterationContext)).toString());
return rec;
}();
}, function () {
return model.variables.formsVar.getCurrentRowNumber(callContext.iterationContext);
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "13",
alias: "7"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [$if(model.variables.hasTestUIAvailableVar, false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-bottom-02",
visible: true,
_idProps: {
service: idService,
uuid: "14"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": ("FormNumber_" + (model.variables.formsVar.getCurrentRowNumber(callContext.iterationContext)).toString())
},
style: "body-4",
value: model.variables.formsVar.getCurrent(callContext.iterationContext).formNumberAttr,
_idProps: {
service: idService,
uuid: "15"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
}, function () {
return [];
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "16",
alias: "8"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomTag_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("IwWyLzMeIEi8s0FGrg6g4A.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomTagOptionsRec();
rec.stateAttr = model.variables.formsVar.getCurrent(callContext.iterationContext).formTagStateAttr;
rec.testIdAttr = ("FormStateTag_" + (model.variables.formsVar.getCurrentRowNumber(callContext.iterationContext)).toString());
return rec;
}();
}, function () {
return model.variables.formsVar.getCurrent(callContext.iterationContext).formTagStateAttr;
}, function () {
return model.variables.formsVar.getCurrentRowNumber(callContext.iterationContext);
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "17",
alias: "9"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": ("RefundStatus_" + (model.variables.formsVar.getCurrentRowNumber(callContext.iterationContext)).toString())
},
value: model.variables.formsVar.getCurrent(callContext.iterationContext).formStatusLabelAttr,
_idProps: {
service: idService,
uuid: "18"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.formsVar.getCurrentRowNumber(callContext.iterationContext)), asPrimitiveValue(model.variables.formsVar.getCurrent(callContext.iterationContext).formStatusLabelAttr)]
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.formsVar.getCurrentRowNumber(callContext.iterationContext)), asPrimitiveValue(model.variables.formsVar.getCurrent(callContext.iterationContext).formStatusLabelAttr), asPrimitiveValue(model.variables.formsVar.getCurrent(callContext.iterationContext).formTagStateAttr)]
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "heading6 margin-top-02 text-primary-0",
visible: true,
_idProps: {
service: idService,
name: "RefundCompany"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": ("RefundMerchantName_" + (model.variables.formsVar.getCurrentRowNumber(callContext.iterationContext)).toString())
},
value: model.variables.formsVar.getCurrent(callContext.iterationContext).merchantNameAttr,
_idProps: {
service: idService,
uuid: "20"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-top-02",
visible: true,
_idProps: {
service: idService,
name: "RefundValues"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("Dmk7JAyjPUmJDWR78do_fg.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.justifyAttr = ShopperPortalEUModel.staticEntities.flexJustify.spaceBetween;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "22",
alias: "10"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FlexItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "23",
alias: "11"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": ("RefundLabel_" + (model.variables.formsVar.getCurrentRowNumber(callContext.iterationContext)).toString())
},
value: model.variables.formsVar.getCurrent(callContext.iterationContext).refundLabel_UIAttr,
_idProps: {
service: idService,
uuid: "24"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.formsVar.getCurrentRowNumber(callContext.iterationContext)), asPrimitiveValue(model.variables.formsVar.getCurrent(callContext.iterationContext).refundLabel_UIAttr)]
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FlexItem_mvc_view, {
inputs: {
ExtendedClass: "text-align-right"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "25",
alias: "12"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": ("RefundAmount_" + (model.variables.formsVar.getCurrentRowNumber(callContext.iterationContext)).toString())
},
style: "heading6 text-primary-0",
value: model.variables.formsVar.getCurrent(callContext.iterationContext).refundAmountTxtAttr,
_idProps: {
service: idService,
uuid: "26"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "body-4",
visible: true,
_idProps: {
service: idService,
uuid: "27"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": ("RefundAmountMessage_" + (model.variables.formsVar.getCurrentRowNumber(callContext.iterationContext)).toString())
},
value: model.variables.formsVar.getCurrent(callContext.iterationContext).refundAmountMessageAttr,
_idProps: {
service: idService,
uuid: "28"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables.formsVar.getCurrentRowNumber(callContext.iterationContext)), asPrimitiveValue(model.variables.formsVar.getCurrent(callContext.iterationContext).refundAmountMessageAttr), asPrimitiveValue(model.variables.formsVar.getCurrent(callContext.iterationContext).refundAmountTxtAttr)]
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.formsVar.getCurrentRowNumber(callContext.iterationContext)), asPrimitiveValue(model.variables.formsVar.getCurrent(callContext.iterationContext).refundAmountMessageAttr), asPrimitiveValue(model.variables.formsVar.getCurrent(callContext.iterationContext).refundAmountTxtAttr), asPrimitiveValue(model.variables.formsVar.getCurrent(callContext.iterationContext).refundLabel_UIAttr)]
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables.formsVar.getCurrentRowNumber(callContext.iterationContext)), asPrimitiveValue(model.variables.formsVar.getCurrent(callContext.iterationContext).refundAmountMessageAttr), asPrimitiveValue(model.variables.formsVar.getCurrent(callContext.iterationContext).refundAmountTxtAttr), asPrimitiveValue(model.variables.formsVar.getCurrent(callContext.iterationContext).refundLabel_UIAttr), asPrimitiveValue(model.variables.formsVar.getCurrent(callContext.iterationContext).merchantNameAttr), asPrimitiveValue(model.variables.formsVar.getCurrent(callContext.iterationContext).formStatusLabelAttr), asPrimitiveValue(model.variables.formsVar.getCurrent(callContext.iterationContext).formTagStateAttr), asPrimitiveValue(model.variables.formsVar.getCurrent(callContext.iterationContext).formNumberAttr), asPrimitiveValue(model.variables.hasTestUIAvailableVar)]
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.hasTestUIAvailableVar), asPrimitiveValue(model.variables.formsVar.getCurrent(callContext.iterationContext).refundAmountMessageAttr), asPrimitiveValue(model.variables.formsVar.getCurrent(callContext.iterationContext).refundAmountTxtAttr), asPrimitiveValue(model.variables.formsVar.getCurrent(callContext.iterationContext).refundLabel_UIAttr), asPrimitiveValue(model.variables.formsVar.getCurrent(callContext.iterationContext).merchantNameAttr), asPrimitiveValue(model.variables.formsVar.getCurrent(callContext.iterationContext).formStatusLabelAttr), asPrimitiveValue(model.variables.formsVar.getCurrent(callContext.iterationContext).formTagStateAttr), asPrimitiveValue(model.variables.formsVar.getCurrent(callContext.iterationContext).formNumberAttr), asPrimitiveValue(model.variables.formsVar.getCurrentRowNumber(callContext.iterationContext))]
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables.hasTestUIAvailableVar), asPrimitiveValue(model.variables.formsVar.getCurrent(callContext.iterationContext).refundAmountMessageAttr), asPrimitiveValue(model.variables.formsVar.getCurrent(callContext.iterationContext).refundAmountTxtAttr), asPrimitiveValue(model.variables.formsVar.getCurrent(callContext.iterationContext).refundLabel_UIAttr), asPrimitiveValue(model.variables.formsVar.getCurrent(callContext.iterationContext).merchantNameAttr), asPrimitiveValue(model.variables.formsVar.getCurrent(callContext.iterationContext).formStatusLabelAttr), asPrimitiveValue(model.variables.formsVar.getCurrent(callContext.iterationContext).formTagStateAttr), asPrimitiveValue(model.variables.formsVar.getCurrent(callContext.iterationContext).formNumberAttr), asPrimitiveValue(model.variables.formsVar.getCurrentRowNumber(callContext.iterationContext))]
})))];
}, callContext, idService, "1")
},
_dependencies: [asPrimitiveValue(model.variables.hasTestUIAvailableVar)]
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.hasTestUIAvailableVar), asPrimitiveValue(model.variables.formsVar)]
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.hasTestUIAvailableVar), asPrimitiveValue(model.variables.formsVar)]
})];
}),
bottom: PlaceholderContent.Empty
},
_dependencies: [asPrimitiveValue(model.variables.hasTestUIAvailableVar), asPrimitiveValue(model.variables.hasErrorVar), asPrimitiveValue(model.variables.isDataFetchedVar), asPrimitiveValue(model.variables.formsVar)]
}));
        };
        return View;
    })(OSView.BaseView.BaseWebScreen);
	
    return View;
});
define("ShopperPortalEU.Refund.RefundHistory.mvc$controller", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Theme.controller", "ShopperPortalEU_Forms_IS.controller", "ShopperPortalEU.languageResources", "ShopperPortalEU.clientVariables", "ShopperPortalEU.Refund.RefundHistory.mvc$debugger", "ShopperPortalEU.Refund.controller", "ShopperPortalEU_Forms_IS.model$FormInfo_WrapperRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Forms_IS", "ShopperPortalEU.model$FormInfo_WrapperList", "ShopperPortalEU_UI_Theme.model$LayoutDetailOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU_UI_Components.model$CustomListOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsIconRec", "ShopperPortalEU_UI_Components.model$CustomCardOptionsRec", "ShopperPortalEU_UI_Components.model$FlexOptionsRec", "ShopperPortalEU_UI_Components.model$CustomTagOptionsRec", "ShopperPortalEU_UI_Components.model$FlexItemOptionsRec", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", "ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger", "ShopperPortalEU_Forms_IS.controller$GetFormList", "ShopperPortalEU.controller$GroupFormsByDate", "ShopperPortalEU.controller$DefaultErrorMessage"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_Forms_ISModel, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ThemeController, ShopperPortalEU_Forms_ISController, ShopperPortalEULanguageResources, ShopperPortalEUClientVariables, ShopperPortalEU_Refund_RefundHistory_mvc_Debugger, ShopperPortalEU_RefundController) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = true;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._onInitialize$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnInitialize");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:l2G0tHVHnUq5dfpt2IjFSQ:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.bufr7pfXmkCsX7s9zh4pcg/ClientActions.l2G0tHVHnUq5dfpt2IjFSQ:xpCMlRkiYk7+A0yIKrJDdw", "ShopperPortalEU", "OnInitialize", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:uMbLBGmLeEWKox1u1JhYRg", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:cWqnq9f_rkCw06dVomWyXg", callContext.id);
// IsDataFetched = False
model.variables.isDataFetchedVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:cWqnq9f_rkCw06dVomWyXg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// HasError = False
model.variables.hasErrorVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:C239i8Q6xEqNAs_TgFWmNw", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:l2G0tHVHnUq5dfpt2IjFSQ", callContext.id);
}

};
Controller.prototype._backOnClick$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("BackOnClick");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:YAiW27Hqa0O7uEdp43mmbw:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.bufr7pfXmkCsX7s9zh4pcg/ClientActions.YAiW27Hqa0O7uEdp43mmbw:3Z2+U3u25X7JS0o68v_2Lw", "ShopperPortalEU", "BackOnClick", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:VFfdQWcydUSO7jaH_9ocnw", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:DY0SvvB4IkOHAVmpUnhoGA", callContext.id);
// Destination: /ShopperPortalEU/MyRefunds
return OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "MyRefunds", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:YAiW27Hqa0O7uEdp43mmbw", callContext.id);
}

};
Controller.prototype._fetchRefunds$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("FetchRefunds");
callContext = controller.callContext(callContext);
var allExceptionsVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.ErrorHandlerOutputType());
var listFilterByClosedVar = new OS.DataTypes.VariableHolder();
var getFormListVar = new OS.DataTypes.VariableHolder();
var groupFormsByDateVar = new OS.DataTypes.VariableHolder();
var jSONSerializeFormInfoListVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.JSONSerializeOutputType());
varBag.callContext = callContext;
varBag.allExceptionsVar = allExceptionsVar;
varBag.listFilterByClosedVar = listFilterByClosedVar;
varBag.getFormListVar = getFormListVar;
varBag.groupFormsByDateVar = groupFormsByDateVar;
varBag.jSONSerializeFormInfoListVar = jSONSerializeFormInfoListVar;
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:lqdz6t+mH0qgF4_AGkO5ZA:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.bufr7pfXmkCsX7s9zh4pcg/ClientActions.lqdz6t+mH0qgF4_AGkO5ZA:Bj1Nqd7Bl4_3_ASWfjFZuA", "ShopperPortalEU", "FetchRefunds", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:6_HYe3w7nEej+0ZQierWNQ", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:5zF1dTPhhUO3D7TI3QhxFg", callContext.id);
// IsDataFetched = False
model.variables.isDataFetchedVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:5zF1dTPhhUO3D7TI3QhxFg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// HasError = False
model.variables.hasErrorVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:mCv7efdgCEqoGodPXdOGSQ", callContext.id);
// Execute Action: GetFormList
model.flush();
return ShopperPortalEU_Forms_ISController.default.getFormList$Action(callContext).then(function (value) {
getFormListVar.value = value;
}).then(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:7p+NDHHnzUGJZKTe5fu_RQ", callContext.id) && getFormListVar.value.successOut)) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:FmlKM0Qo6UmvifTjF1RMJA", callContext.id);
// JSON Serialize: JSONSerializeFormInfoList
jSONSerializeFormInfoListVar.value.jSONOut = OS.JSONUtils.serializeToJSON(getFormListVar.value.formInfoListOut, false, false);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Vk+ibxoy4UuQeWfQ2siK_g", callContext.id);
// FormInfoListJSON = JSONSerializeFormInfoList.JSON
ShopperPortalEUClientVariables.setFormInfoListJSON(jSONSerializeFormInfoListVar.value.jSONOut);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:4Qx6GY_e7Eqw8jH9BrVrjA", callContext.id);
// Execute Action: ListFilterByClosed
listFilterByClosedVar.value = OS.SystemActions.listFilter(getFormListVar.value.formInfoListOut, function (p) {
return p.isClosedAttr;
}, callContext);

OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:dOpYywvEUkOeYHDcuL3pgA", callContext.id);
// Execute Action: GroupFormsByDate
groupFormsByDateVar.value = ShopperPortalEUController.default.groupFormsByDate$Action(listFilterByClosedVar.value.filteredListOut, callContext);

// FormsList
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:OyyRqw7X202Tp3bColf4Iw", callContext.id);
// Forms = GroupFormsByDate.FormsList_Output
model.variables.formsVar = groupFormsByDateVar.value.formsList_OutputOut;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:OyyRqw7X202Tp3bColf4Iw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// HasTestUIAvailable = GetFormList.SiteHasFormNumberEnabled
model.variables.hasTestUIAvailableVar = getFormListVar.value.siteHasFormNumberEnabledOut;
// IsDataFetched & HasError
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Nh6p8av3XEulmrPrVh0Knw", callContext.id);
// IsDataFetched = True
model.variables.isDataFetchedVar = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Nh6p8av3XEulmrPrVh0Knw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// HasError = False
model.variables.hasErrorVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:nEYgDHL8+EiOZ7hjSjPuQw", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:5ABZqZGgVUikwbx7FSJVDA", callContext.id);
// IsDataFetched = True
model.variables.isDataFetchedVar = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:5ABZqZGgVUikwbx7FSJVDA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// HasError = True
model.variables.hasErrorVar = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:_5Gx_FNnTECIo+gUcLhpXg", callContext.id);
// Execute Action: ErrorMessage
ShopperPortalEU_UI_ThemeController.default.customMessageTrigger$Action(function () {
var rec = new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customMessageType.error;
rec.titleAttr = "We couldn\'t load the forms";
rec.contentAttr = (OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.defaultErrorMessage$Action(callContext).errorMessageOut;
}, OS.DataTypes.DataTypes.Text, callContext.id) + ".");
rec.testIdAttr = "Error";
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Ecvgk6RnL0Gj0JH99jyGAw", callContext.id);
}

});
}).catch(function (ex) {
OS.Logger.trace("RefundHistory.FetchRefunds", OS.Exceptions.getMessage(ex), ex.name);
// Handle Error: AllExceptions
if(!(OS.Exceptions.isSystem(ex))) {
OS.Logger.error(null, ex);
allExceptionsVar.value.exceptionMessageAttr = OS.Exceptions.getMessage(ex);
OutSystemsDebugger.handleException(allExceptionsVar.value.exceptionMessageAttr, callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:alyyexnidkCeXA28BrtMJQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:z5Vrv5nyzkmxabCTazBF4g", callContext.id);
// IsDataFetched = True
model.variables.isDataFetchedVar = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:z5Vrv5nyzkmxabCTazBF4g", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// HasError = True
model.variables.hasErrorVar = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Lw0KLUX8CE+_46HzW5BG4Q", callContext.id);
// Execute Action: GenericErrorMessage
ShopperPortalEU_UI_ThemeController.default.customMessageTrigger$Action(function () {
var rec = new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customMessageType.error;
rec.titleAttr = "We couldn\'t load the forms";
rec.contentAttr = (OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.defaultErrorMessage$Action(callContext).errorMessageOut;
}, OS.DataTypes.DataTypes.Text, callContext.id) + ".");
rec.testIdAttr = "Error";
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:R51TGMdickCOZLmpQMzIvQ", callContext.id);
return OS.Flow.returnAsync();

});
}

throw ex;
}).then(function (res) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:lqdz6t+mH0qgF4_AGkO5ZA", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:lqdz6t+mH0qgF4_AGkO5ZA", callContext.id);
throw ex;

});
};
Controller.prototype._layoutAfterAuthentication$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("LayoutAfterAuthentication");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:SqGE6sy470+lvykSeqQJTA:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.bufr7pfXmkCsX7s9zh4pcg/ClientActions.SqGE6sy470+lvykSeqQJTA:mlBgblEthl+5vpKp6CYpxg", "ShopperPortalEU", "LayoutAfterAuthentication", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:yOkf5J_lGUq0Vd0bqjq9MQ", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:OBP1_oePq0K1QwZjR2Yuiw", callContext.id);
// Execute Action: FetchRefunds
return controller._fetchRefunds$Action(callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:zHHh3zBho02AvB6B_lthjg", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:SqGE6sy470+lvykSeqQJTA", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:SqGE6sy470+lvykSeqQJTA", callContext.id);
throw ex;

});
};

Controller.prototype.onInitialize$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onInitialize$Action, callContext);

};
Controller.prototype.backOnClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._backOnClick$Action, callContext);

};
Controller.prototype.fetchRefunds$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._fetchRefunds$Action, callContext);

};
Controller.prototype.layoutAfterAuthentication$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._layoutAfterAuthentication$Action, callContext);

};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:VcUw8y2coUi7OQ+l92mkmQ:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ:1Ox1BferNhnfzrugqQ41yg", "ShopperPortalEU", "Refund", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:bufr7pfXmkCsX7s9zh4pcg:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.bufr7pfXmkCsX7s9zh4pcg:HoG9yoGcM1LE1GeSlqpoSg", "ShopperPortalEU", "RefundHistory", "NRNodes.WebScreen", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:bufr7pfXmkCsX7s9zh4pcg", callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:VcUw8y2coUi7OQ+l92mkmQ", callContext.id);
};
Controller.prototype.onInitializeEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Refund/RefundHistory On Initialize");
return controller.onInitialize$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return ShopperPortalEU_RefundController.default.handleError(ex, this.callContext());
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return ShopperPortalEUController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, ShopperPortalEULanguageResources);
});

define("ShopperPortalEU.Refund.RefundHistory.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"alyyexnidkCeXA28BrtMJQ": {
getter: function (varBag, idService) {
return varBag.allExceptionsVar.value;
}
},
"4Qx6GY_e7Eqw8jH9BrVrjA": {
getter: function (varBag, idService) {
return varBag.listFilterByClosedVar.value;
}
},
"mCv7efdgCEqoGodPXdOGSQ": {
getter: function (varBag, idService) {
return varBag.getFormListVar.value;
}
},
"dOpYywvEUkOeYHDcuL3pgA": {
getter: function (varBag, idService) {
return varBag.groupFormsByDateVar.value;
}
},
"FmlKM0Qo6UmvifTjF1RMJA": {
getter: function (varBag, idService) {
return varBag.jSONSerializeFormInfoListVar.value;
}
},
"e9CREM_udU2xDBTLyHm4Ig": {
getter: function (varBag, idService) {
return varBag.model.variables.isDataFetchedVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"rsOTsUJ1k0y5M5yUT4vbEg": {
getter: function (varBag, idService) {
return varBag.model.variables.hasErrorVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"FX82C1xdg0m2zHVWiha1ZA": {
getter: function (varBag, idService) {
return varBag.model.variables.formsVar;
}
},
"zI6xj6P_yEK1TskBN7b_tg": {
getter: function (varBag, idService) {
return varBag.model.variables.hasTestUIAvailableVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"JVPiER6xbkeEXutxXQSZkw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderLeft"));
})(varBag.model, idService);
}
},
"_5QToSgCdkytTCMsf5+wqw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderCenter"));
})(varBag.model, idService);
}
},
"DmXDoByFE0qnLSOCr5qrDg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderRight"));
})(varBag.model, idService);
}
},
"1I01bX+NHUirhSTjEsBGtg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"ucJg_EwZ7U+uv2h60vrqQw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"YJb8u8aZW0agIZN+L_U8CA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("List"));
})(varBag.model, idService);
}
},
"M3xqMR2vsUuxFs31FzSQQQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("FormList_Active"));
})(varBag.model, idService);
}
},
"Vx13p0aoAUuYNmsOJueRWw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HasDate"));
})(varBag.model, idService);
}
},
"yEeBwYwS_0GN_JzxNQna+A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("RefundDate_Ctn"));
})(varBag.model, idService);
}
},
"5xeLevlgvkysHf+IWK4Ppg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Link"));
})(varBag.model, idService);
}
},
"3ssjn9LMbE+Y2aYZ72XyFg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"p8_73IIRQEmvFzDTlehXag": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"6NMB_WO7cECiYMcbI_IZWg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HasTestUIAvailable2"));
})(varBag.model, idService);
}
},
"3hqX1W_Qhkarrtc1D5u8og": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"1MQJ4Dgmt0yqeUWucFwMOg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"80qbqpy1J0WX5Ls6FdyQew": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("RefundCompany"));
})(varBag.model, idService);
}
},
"vQPqxZTLy0SD65eLsfZDYA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("RefundValues"));
})(varBag.model, idService);
}
},
"Byi+d5qUKkGq8BOmun8mIQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"6sOUEgF_XUeouvNs1GyLJw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"qsG1eR3_rE2a2T7ifX8xmg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"u0AbjPtp30+hCow7kieZjQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Bottom"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
