class customFlag {
  constructor(id, options) {
    this.class = 'custom-flag';
    this.element = document.getElementById(id);
    this.elements = {
      svg: null,
      use: null
    };
    this.options = options;
    this._build();
  }
  _update() {
    if (this.elements.svg) {
      this.elements.use.setAttribute('xlink:href', `/ShopperPortalEU_UI_Components/custom-flag.svg#${this.class.concat('--').concat(libcountry.getFlag(this.options.flag))}`);
    }
  }
  _build() {
    this.element.innerHTML = '';
    this.elements.svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    this.elements.use = document.createElement('use');
    this.elements.svg.classList.add(this.class);
    this.elements.svg.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
    this._update();
    this.elements.svg.append(this.elements.use);
    this.element.innerHTML = this.elements.svg.outerHTML;
    this.elements.svg = this.element.firstElementChild;
    this.elements.use = this.elements.svg.lastElementChild;
    if (this.options.testId) {
      this.elements.use.setAttribute('data-testid', this.options.testId);
    }
  }
  parametersChanged(options) {
    this.options = options;
    this._update();
  }
}