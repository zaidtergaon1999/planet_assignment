class customAlert {
  constructor(id, options) {
    this.class = 'custom-alert';
    this.element = document.getElementById(id);
    this.elements = {
      title: this.element.lastElementChild.firstElementChild,
      content: this.element.lastElementChild.lastElementChild
    };
    this.stateClasses = {
      onlyContent: this.class.concat('--only-content')
    };
    this.options = options;
  }
  render() {
    this.elements.title.innerHTML === '' && this.elements.content.innerHTML !== '' ? this.element.classList.add(this.stateClasses.onlyContent) : this.element.classList.remove(this.stateClasses.onlyContent);
  }
}