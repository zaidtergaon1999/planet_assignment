class customOpacity {
  constructor(id, options) {
    this.element = document.getElementById(id);
    this.options = options;
    this._build();
  }
  setCSSVariables() {
    this.element.style.setProperty('--opacity', this.options.value);
  }
  _build() {
    this.setCSSVariables();
  }
  parametersChanged(options) {
    this.options = options;
    this.setCSSVariables();
  }
}