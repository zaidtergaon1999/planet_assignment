define("ShopperPortalEU.Support.Locations.mvc$model", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_API.model", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.controller", "ShopperPortalEU.controller$FormatLocationHours", "ShopperPortalEU_UI_Components.model$CustomDropdownCustomValueOptionRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$CustomDropdownListValueOptionsRec", "ShopperPortalEU_API.model$CustomOfficeInfo_WrapperRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_API", "ShopperPortalEU.model$CustomOfficeInfo_WrapperList", "ShopperPortalEU_API.model$RefundPoint_WrapperRec", "ShopperPortalEU.model$RefundPoint_WrapperList", "ShopperPortalEU_UI_Theme.model$LayoutOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$LayoutHeaderOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU.model$ApplicationHeaderRec", "ShopperPortalEU_UI_Components.model$CustomCardOptionsRec", "ShopperPortalEU.model$CountriesWithFlagsDropdownListList", "ShopperPortalEU_UI_Components.model$CustomDropdownListValidationOptionsRec", "ShopperPortalEU_UI_Components.model$CustomDropdownOptionsRec", "ShopperPortalEU_UI_Components.model$CustomDropdownCustomOptionRec", "ShopperPortalEU_UI_Components.model$CustomDropdownSearchOptionsRec", "ShopperPortalEU_UI_Components.model$CustomDropdownNullOptionRec", "ShopperPortalEU_UI_Components.model$CustomDropdownValidationOptionsRec", "ShopperPortalEU.model$CustomDropdownCustomValueOptionList", "ShopperPortalEU_UI_Components.model$FlexOptionsRec", "ShopperPortalEU_UI_Components.model$CustomIconOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonGroupOptionsRec", "ShopperPortalEU_UI_Components.model$CustomAlertOptionsRec", "ShopperPortalEU_UI_Components.model$CustomAlertIconOptionsRec", "ShopperPortalEU_UI_Components.model$CustomColumnsOptionsRec", "ShopperPortalEU_UI_Components.model$CustomSeparatorOptionsRec", "ShopperPortalEU_UI_Components.model$CustomSeparatorLabelOptionsRec", "ShopperPortalEU_UI_Components.model$CardExpandableOptionsRec", "ShopperPortalEU_UI_Components.model$UnescapedHTMLOptionsRec", "ShopperPortalEU_API.model$SPCountry_WrapperRec", "ShopperPortalEU.model$SPCountry_WrapperList", "ShopperPortalEU_UI_Components.model$GetOSRec", "ShopperPortalEU_UI_Components.controller$GetOS", "ShopperPortalEU_API.model$Location_WrapperRec"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_APIModel, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ComponentsController) {
var OS = OutSystems.Internal;

var GetLocationCountriesDataActRec = (function (_super) {
__extends(GetLocationCountriesDataActRec, _super);
function GetLocationCountriesDataActRec(defaults) {
_super.apply(this, arguments);
}
GetLocationCountriesDataActRec.attributesToDeclare = function () {
return [
this.attr("EUCountryList", "eUCountryListOut", "EUCountryList", true, false, OS.DataTypes.DataTypes.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEUModel.SPCountry_WrapperList());
}, true, ShopperPortalEUModel.SPCountry_WrapperList)
].concat(_super.attributesToDeclare.call(this));
};
GetLocationCountriesDataActRec.fromStructure = function (str) {
return new GetLocationCountriesDataActRec(new GetLocationCountriesDataActRec.RecordClass({
eUCountryListOut: OS.DataTypes.ImmutableBase.getData(str)
}));
};
GetLocationCountriesDataActRec.init();
return GetLocationCountriesDataActRec;
})(OS.Model.DataSourceRecord);
var GetLocationsAndCitiesDataActRec = (function (_super) {
__extends(GetLocationsAndCitiesDataActRec, _super);
function GetLocationsAndCitiesDataActRec(defaults) {
_super.apply(this, arguments);
}
GetLocationsAndCitiesDataActRec.attributesToDeclare = function () {
return [
this.attr("CustomsOffices", "customsOfficesOut", "CustomsOffices", true, false, OS.DataTypes.DataTypes.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEUModel.CustomOfficeInfo_WrapperList());
}, true, ShopperPortalEUModel.CustomOfficeInfo_WrapperList), 
this.attr("RefundPoints", "refundPointsOut", "RefundPoints", true, false, OS.DataTypes.DataTypes.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEUModel.RefundPoint_WrapperList());
}, true, ShopperPortalEUModel.RefundPoint_WrapperList), 
this.attr("Cities", "citiesOut", "Cities", true, false, OS.DataTypes.DataTypes.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEUModel.CustomDropdownCustomValueOptionList());
}, true, ShopperPortalEUModel.CustomDropdownCustomValueOptionList)
].concat(_super.attributesToDeclare.call(this));
};
GetLocationsAndCitiesDataActRec.init();
return GetLocationsAndCitiesDataActRec;
})(OS.Model.DataSourceRecord);
var GeUserLocationDataActRec = (function (_super) {
__extends(GeUserLocationDataActRec, _super);
function GeUserLocationDataActRec(defaults) {
_super.apply(this, arguments);
}
GeUserLocationDataActRec.attributesToDeclare = function () {
return [
this.attr("Location", "locationOut", "Location", true, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_APIModel.Location_WrapperRec());
}, true, ShopperPortalEU_APIModel.Location_WrapperRec), 
this.attr("IP", "iPOut", "IP", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
GeUserLocationDataActRec.init();
return GeUserLocationDataActRec;
})(OS.Model.DataSourceRecord);

var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("GroupSelected", "groupSelectedVar", "GroupSelected", true, false, OS.DataTypes.DataTypes.Integer, function () {
return 1;
}, false), 
this.attr("CitySelected", "citySelectedVar", "CitySelected", true, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomDropdownCustomValueOptionRec());
}, false, ShopperPortalEU_UI_ComponentsModel.CustomDropdownCustomValueOptionRec), 
this.attr("CountrySelected", "countrySelectedVar", "CountrySelected", true, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValueOptionsRec());
}, false, ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValueOptionsRec), 
this.attr("Filtered_CustomsOffices", "filtered_CustomsOfficesVar", "Filtered_CustomsOffices", true, false, OS.DataTypes.DataTypes.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEUModel.CustomOfficeInfo_WrapperList());
}, false, ShopperPortalEUModel.CustomOfficeInfo_WrapperList), 
this.attr("Filtered_RefundPoints", "filtered_RefundPointsVar", "Filtered_RefundPoints", true, false, OS.DataTypes.DataTypes.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEUModel.RefundPoint_WrapperList());
}, false, ShopperPortalEUModel.RefundPoint_WrapperList), 
this.attr("IsResetCity", "isResetCityVar", "IsResetCity", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("IsScreenReady", "isScreenReadyVar", "IsScreenReady", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("OS", "oSVar", "OS", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, false), 
this.attr("GetLocationCountries", "getLocationCountriesDataAct", "getLocationCountriesDataAct", true, true, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new GetLocationCountriesDataActRec());
}, true, GetLocationCountriesDataActRec), 
this.attr("GetLocationsAndCities", "getLocationsAndCitiesDataAct", "getLocationsAndCitiesDataAct", true, true, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new GetLocationsAndCitiesDataActRec());
}, true, GetLocationsAndCitiesDataActRec), 
this.attr("GeUserLocation", "geUserLocationDataAct", "geUserLocationDataAct", true, true, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new GeUserLocationDataActRec());
}, true, GeUserLocationDataActRec)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {
Dropdown_City: OS.Model.ValidationWidgetRecord,
ButtonGroup1: OS.Model.ValidationWidgetRecord
};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return true;
}
});

Model.prototype.setInputs = function (inputs) {
};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "Support.Locations");
});
define("ShopperPortalEU.Support.Locations.mvc$view", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_API.model", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.controller", "react", "OutSystems/ReactView/Main", "ShopperPortalEU.Support.Locations.mvc$model", "ShopperPortalEU.Support.Locations.mvc$controller", "ShopperPortalEU.clientVariables", "ShopperPortalEU.Layouts.Layout.mvc$view", "OutSystems/ReactWidgets/Main", "ShopperPortalEU.LayoutsComponents.Menu.mvc$view", "ShopperPortalEU.LayoutsComponents.ApplicationHeader.mvc$view", "ShopperPortalEU.Common.DataLoading.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCard.mvc$view", "ShopperPortalEU.Common.CountryDropdown.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomDropdown.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.Flex.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomIcon.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomButtonGroup.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomAlert.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomColumns.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomSeparator.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CardExpandable.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.UnescapedHTML.mvc$view", "ShopperPortalEU.controller$FormatLocationHours", "ShopperPortalEU_UI_Components.model$CustomDropdownCustomValueOptionRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$CustomDropdownListValueOptionsRec", "ShopperPortalEU_API.model$CustomOfficeInfo_WrapperRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_API", "ShopperPortalEU.model$CustomOfficeInfo_WrapperList", "ShopperPortalEU_API.model$RefundPoint_WrapperRec", "ShopperPortalEU.model$RefundPoint_WrapperList", "ShopperPortalEU_UI_Theme.model$LayoutOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$LayoutHeaderOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU.model$ApplicationHeaderRec", "ShopperPortalEU_UI_Components.model$CustomCardOptionsRec", "ShopperPortalEU.model$CountriesWithFlagsDropdownListList", "ShopperPortalEU_UI_Components.model$CustomDropdownListValidationOptionsRec", "ShopperPortalEU_UI_Components.model$CustomDropdownOptionsRec", "ShopperPortalEU_UI_Components.model$CustomDropdownCustomOptionRec", "ShopperPortalEU_UI_Components.model$CustomDropdownSearchOptionsRec", "ShopperPortalEU_UI_Components.model$CustomDropdownNullOptionRec", "ShopperPortalEU_UI_Components.model$CustomDropdownValidationOptionsRec", "ShopperPortalEU.model$CustomDropdownCustomValueOptionList", "ShopperPortalEU_UI_Components.model$FlexOptionsRec", "ShopperPortalEU_UI_Components.model$CustomIconOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonGroupOptionsRec", "ShopperPortalEU_UI_Components.model$CustomAlertOptionsRec", "ShopperPortalEU_UI_Components.model$CustomAlertIconOptionsRec", "ShopperPortalEU_UI_Components.model$CustomColumnsOptionsRec", "ShopperPortalEU_UI_Components.model$CustomSeparatorOptionsRec", "ShopperPortalEU_UI_Components.model$CustomSeparatorLabelOptionsRec", "ShopperPortalEU_UI_Components.model$CardExpandableOptionsRec", "ShopperPortalEU_UI_Components.model$UnescapedHTMLOptionsRec", "ShopperPortalEU_API.model$SPCountry_WrapperRec", "ShopperPortalEU.model$SPCountry_WrapperList", "ShopperPortalEU_UI_Components.model$GetOSRec", "ShopperPortalEU_UI_Components.controller$GetOS", "ShopperPortalEU_API.model$Location_WrapperRec"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_APIModel, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ComponentsController, React, OSView, ShopperPortalEU_Support_Locations_mvc_model, ShopperPortalEU_Support_Locations_mvc_controller, ShopperPortalEUClientVariables, ShopperPortalEU_Layouts_Layout_mvc_view, OSWidgets, ShopperPortalEU_LayoutsComponents_Menu_mvc_view, ShopperPortalEU_LayoutsComponents_ApplicationHeader_mvc_view, ShopperPortalEU_Common_DataLoading_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCard_mvc_view, ShopperPortalEU_Common_CountryDropdown_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomDropdown_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomIcon_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonGroup_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomAlert_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomColumns_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomSeparator_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CardExpandable_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_UnescapedHTML_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            var thisIsInstanceOfSuper = this instanceof _super;
            if (thisIsInstanceOfSuper == false) {
                return;
            }

            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "Support.Locations";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css", "css/ShopperPortalEU_UI_Theme.ShopperPortalEUUITheme.css", "css/ShopperPortalEU.ShopperPortalEU.css", "css/ShopperPortalEU_UI_Theme.ShopperPortalEUUITheme.extra.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [ShopperPortalEU_Layouts_Layout_mvc_view, ShopperPortalEU_LayoutsComponents_Menu_mvc_view, ShopperPortalEU_LayoutsComponents_ApplicationHeader_mvc_view, ShopperPortalEU_Common_DataLoading_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCard_mvc_view, ShopperPortalEU_Common_CountryDropdown_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomDropdown_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomIcon_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonGroup_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomAlert_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomColumns_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomSeparator_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CardExpandable_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_UnescapedHTML_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return ShopperPortalEU_Support_Locations_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return ShopperPortalEU_Support_Locations_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "Shopper Portal EU - Locations";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(ShopperPortalEU_Layouts_Layout_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "0",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
headerLeft: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_LayoutsComponents_Menu_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "1",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}),
headerCenter: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_LayoutsComponents_ApplicationHeader_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("KZChF+v770aGuaQP9ekLfg.Options"), function () {
return function () {
var rec = new ShopperPortalEUModel.ApplicationHeaderRec();
rec.scrollTitleAttr = "Locations";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "2",
alias: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}),
headerRight: PlaceholderContent.Empty,
headerBottom: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "heading6 text-align-center",
visible: true,
_idProps: {
service: idService,
uuid: "3"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "LocationsTitle"
},
value: "Locations",
_idProps: {
service: idService,
uuid: "4"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
}),
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_Common_DataLoading_mvc_view, {
inputs: {
IsDataFetched: model.variables.isScreenReadyVar
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "5",
alias: "4"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCard_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "6",
alias: "5"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "heading6",
visible: true,
_idProps: {
service: idService,
uuid: "7"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "LeavingEUFrom"
},
value: "Leaving EU from",
_idProps: {
service: idService,
uuid: "8"
},
_widgetRecordProvider: widgetsRecordProvider
})), $if(true, false, this, function () {
return [React.createElement(ShopperPortalEU_Common_CountryDropdown_mvc_view, {
inputs: {
OpenedLabel: "Select country",
NativeLabel: "Country",
TestId: "CountryDropdown",
Selected: model.variables.countrySelectedVar.valueAttr,
List: model.getCachedValue(idService.getId("QIIxDPmqjUyfaTi5mGS8hg.List"), function () {
return OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.getLocationCountriesDataAct.eUCountryListOut, new ShopperPortalEUModel.CountriesWithFlagsDropdownListList(), function (source, target) {
target.flagAttr = source.code2Attr;
target.valueAttr = source.code3DigitsAttr;
target.nameAttr = source.nameAttr;
return target;
});
}, function () {
return model.variables.getLocationCountriesDataAct.eUCountryListOut;
}),
_listInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getLocationCountriesDataAct.dataFetchStatusAttr)
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onChange$Action: function (currentCountryIn) {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common/CountryDropdown OnChange");
return controller.countryOnChange$Action(currentCountryIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "9",
alias: "6"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
label: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Country",
_idProps: {
service: idService,
uuid: "10"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
})];
}, function () {
return [];
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomDropdown_mvc_view, {
inputs: {
List: model.variables.getLocationsAndCitiesDataAct.citiesOut,
_listInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getLocationsAndCitiesDataAct.dataFetchStatusAttr),
ExtendedClass: "margin-top-02",
Options: model.getCachedValue(idService.getId("BGp7pLvIwka__ZbfYiERqA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomDropdownOptionsRec();
rec.testIdAttr = ("CityLocationDropown" + model.variables.citySelectedVar.valueAttr);
rec.isNativeAttr = ((model.variables.oSVar === "ios") && false);
rec.nullAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomDropdownNullOptionRec();
rec.textAttr = "Select";
rec.valueAttr = "";
return rec;
}();
return rec;
}();
}, function () {
return model.variables.citySelectedVar.valueAttr;
}, function () {
return model.variables.oSVar;
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onCustomChange$Action: function (currentDataIn) {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ShopperPortalEUUIComponents/CustomDropdown OnCustomChange");
controller.cityOnChange$Action(currentDataIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "11",
alias: "7"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
label: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
mandatory: false,
targetWidget: "Dropdown_City",
_idProps: {
service: idService,
uuid: "12"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "City"
},
value: "City",
_idProps: {
service: idService,
uuid: "13"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
}),
dropdown: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Dropdown, {
_validationProps: {
validationService: validationService
},
dropdownMode: /*Text*/ 0,
emptyValue: "Select",
enabled: true,
gridProperties: {
classes: "OSFillParent"
},
labels: function (elem) {
return elem.textAttr;
},
list: model.variables.getLocationsAndCitiesDataAct.citiesOut,
mandatory: false,
onChange: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Support/Locations/Dropdown_City OnChange");
controller.cityOnChange$Action(function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomDropdownCustomValueOptionRec();
rec.valueAttr = model.variables.citySelectedVar.valueAttr;
return rec;
}(), controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "dropdown",
values: function (elem) {
return elem.valueAttr;
},
variable: model.createVariable(OS.DataTypes.DataTypes.Text, model.variables.citySelectedVar.valueAttr, function (value) {
model.variables.citySelectedVar.valueAttr = value;
}),
_idProps: {
service: idService,
name: "Dropdown_City"
},
_widgetRecordProvider: widgetsRecordProvider,
list_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getLocationsAndCitiesDataAct.dataFetchStatusAttr),
placeholders: {
content: PlaceholderContent.Empty
},
_dependencies: []
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.getLocationsAndCitiesDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.getLocationsAndCitiesDataAct.citiesOut), asPrimitiveValue(model.variables.citySelectedVar.valueAttr)]
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.oSVar), asPrimitiveValue(model.variables.citySelectedVar.valueAttr), asPrimitiveValue(model.variables.getLocationsAndCitiesDataAct.citiesOut), asPrimitiveValue(model.variables.getLocationsAndCitiesDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.getLocationCountriesDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.getLocationCountriesDataAct.eUCountryListOut), asPrimitiveValue(model.variables.countrySelectedVar.valueAttr)]
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("yi3kGVwf6EaMOXtGRu+TKg.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.alignAttr = ShopperPortalEUModel.staticEntities.flexAlign.center;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
rec.wrapAttr = false;
return rec;
}();
}),
ExtendedClass: "margin-top-04"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "15",
alias: "8"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "16"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomIcon_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("faEUmt6VRkGunryDu_z6vA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomIconOptionsRec();
rec.nameAttr = "lightbulb";
rec.sizeAttr = ShopperPortalEUModel.staticEntities.customIconSize.small;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "17",
alias: "9"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "18"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "TipForCustoms1"
},
style: "font-bold text-primary-black",
value: "Tip: ",
_idProps: {
service: idService,
uuid: "19"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "TipForCustoms2"
},
style: "text-primary-black",
value: (((("Follow signs for " + "\"Customs\"") + " or ") + "\"Tax Refund\"") + " — "),
_idProps: {
service: idService,
uuid: "20"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "TipForCustoms3"
},
style: "text-primary-black",
value: " usually before security.",
_idProps: {
service: idService,
uuid: "21"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
})
},
_dependencies: []
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonGroup_mvc_view, {
inputs: {
ExtendedClass: "margin-top-04"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "22",
alias: "10"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
buttonGroup: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.ButtonGroup, {
_validationProps: {
validationService: validationService
},
enabled: true,
mandatory: false,
style: "button-group",
variable: model.createVariable(OS.DataTypes.DataTypes.Integer, model.variables.groupSelectedVar, function (value) {
model.variables.groupSelectedVar = value;
}),
_idProps: {
service: idService,
name: "ButtonGroup1"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.ButtonGroupItem, {
enabled: true,
extendedProperties: {
"data-testid": "CustomsOffice"
},
style: "button-group-item",
value: 1,
visible: true,
_idProps: {
service: idService,
name: "ButtonGroupItem1"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
value: "Customs office",
_idProps: {
service: idService,
uuid: "25"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.ButtonGroupItem, {
enabled: true,
extendedProperties: {
"data-testid": "RefundPoints"
},
style: "button-group-item",
value: 2,
visible: true,
_idProps: {
service: idService,
name: "ButtonGroupItem2"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
value: "Refund points",
_idProps: {
service: idService,
uuid: "27"
},
_widgetRecordProvider: widgetsRecordProvider
})))];
})
},
_dependencies: [asPrimitiveValue(model.variables.groupSelectedVar)]
}), $if((model.variables.groupSelectedVar === 1), false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomAlert_mvc_view, {
inputs: {
ExtendedClass: "margin-top-04",
Options: model.getCachedValue(idService.getId("UV4u9dtlh0qeL3vVXjBN3w.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomAlertOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customAlertType.warning;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "28",
alias: "11"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
title: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "Customs inspection"
},
value: "Do not check in your Tax Free goods",
_idProps: {
service: idService,
uuid: "29"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "DoNotCheckInYourUnusedGoods"
},
value: "Customs may require an inspection.",
_idProps: {
service: idService,
uuid: "30"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}), $if(model.variables.filtered_CustomsOfficesVar.isEmpty, false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-top-04",
visible: true,
_idProps: {
service: idService,
uuid: "31"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "SorryNoCustomsOfficesAvailable"
},
value: "Sorry, no Customs offices are available at this location.",
_idProps: {
service: idService,
uuid: "32"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
}, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomColumns_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("Tu3pRrzgskq5qysL4O_DRw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomColumnsOptionsRec();
rec.columnsAttr = 1;
return rec;
}();
}),
ExtendedClass: "margin-top-04"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "33",
alias: "12"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.List, {
animateItems: false,
extendedProperties: {
"disable-virtualization": "True"
},
gridProperties: {
classes: "OSFillParent"
},
mode: /*Default*/ 0,
source: model.variables.filtered_CustomsOfficesVar,
style: "list list-group",
tag: "div",
_idProps: {
service: idService,
name: "CustomsOfficesList"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new IteratorPlaceholderContent(function (idService, callContext) {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCard_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "35",
alias: "13"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "heading6",
visible: true,
_idProps: {
service: idService,
uuid: "36"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "Airport"
},
value: model.variables.filtered_CustomsOfficesVar.getCurrent(callContext.iterationContext).categoryNameAttr,
_idProps: {
service: idService,
uuid: "37"
},
_widgetRecordProvider: widgetsRecordProvider
})), $if(((OS.BuiltinFunctions.trim(model.variables.filtered_CustomsOfficesVar.getCurrent(callContext.iterationContext).locationNameAttr)) !== ("")), false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-top-01 body-4",
visible: true,
_idProps: {
service: idService,
uuid: "38"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "LocationName"
},
value: model.variables.filtered_CustomsOfficesVar.getCurrent(callContext.iterationContext).locationNameAttr,
_idProps: {
service: idService,
uuid: "39"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
}, function () {
return [];
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomSeparator_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("ksVnG7E1VkWptQush0tqGQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomSeparatorOptionsRec();
rec.marginTopAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
rec.marginBottomAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
rec.stateAttr = ShopperPortalEUModel.staticEntities.customSeparatorState.lighter;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "40",
alias: "14"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}), $if(((OS.BuiltinFunctions.trim(model.variables.filtered_CustomsOfficesVar.getCurrent(callContext.iterationContext).directionsAttr)) !== ("")), false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "text-primary-black body-4",
visible: true,
_idProps: {
service: idService,
uuid: "41"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("Nm6VYW82XUSq7JtjvG0zmg.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.alignAttr = ShopperPortalEUModel.staticEntities.flexAlign.center;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "42",
alias: "15"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomIcon_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("QarurCLMvka330gDokbkaA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomIconOptionsRec();
rec.nameAttr = "directions";
rec.sizeAttr = ShopperPortalEUModel.staticEntities.customIconSize.small;
rec.testIdAttr = "directionsIcon";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "43",
alias: "16"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}), React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "directions"
},
value: model.variables.filtered_CustomsOfficesVar.getCurrent(callContext.iterationContext).directionsAttr,
_idProps: {
service: idService,
uuid: "44"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.filtered_CustomsOfficesVar.getCurrent(callContext.iterationContext).directionsAttr)]
})), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomSeparator_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("yQJN36AZdEa8TT6J22BLNQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomSeparatorOptionsRec();
rec.marginTopAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
rec.marginBottomAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
rec.stateAttr = ShopperPortalEUModel.staticEntities.customSeparatorState.lighter;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "45",
alias: "17"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}, function () {
return [];
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CardExpandable_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("dkW32zGjEEa29ZrQ+0lYHQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CardExpandableOptionsRec();
rec.isInlineAttr = true;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "46",
alias: "18"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
title: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "Hours"
},
value: "Hours",
_idProps: {
service: idService,
uuid: "47"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_UnescapedHTML_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("n4275JRJS0CzLhyhNzOp0A.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.UnescapedHTMLOptionsRec();
rec.hTMLAttr = OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.formatLocationHours$Action(model.variables.filtered_CustomsOfficesVar.getCurrent(callContext.iterationContext).operationHoursAttr, callContext).formattedLocationHoursOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
rec.testIdAttr = "SP_OperationHours";
return rec;
}();
}, function () {
return model.variables.filtered_CustomsOfficesVar.getCurrent(callContext.iterationContext).operationHoursAttr;
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "48",
alias: "19"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
preview: new PlaceholderContent(function () {
return ["Monday to Friday: 08:00 - 16:00"];
})
},
_dependencies: []
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.filtered_CustomsOfficesVar.getCurrent(callContext.iterationContext).operationHoursAttr)]
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.filtered_CustomsOfficesVar.getCurrent(callContext.iterationContext).operationHoursAttr), asPrimitiveValue(model.variables.filtered_CustomsOfficesVar.getCurrent(callContext.iterationContext).directionsAttr), asPrimitiveValue(model.variables.filtered_CustomsOfficesVar.getCurrent(callContext.iterationContext).locationNameAttr), asPrimitiveValue(model.variables.filtered_CustomsOfficesVar.getCurrent(callContext.iterationContext).categoryNameAttr)]
})];
}, callContext, idService, "2")
},
_dependencies: []
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.filtered_CustomsOfficesVar)]
})];
})];
}, function () {
return [$if(model.variables.filtered_RefundPointsVar.isEmpty, false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-top-04",
visible: true,
_idProps: {
service: idService,
uuid: "49"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "SorryNoRefundPointsAreAvailable"
},
value: "Sorry, no refund points are available at this location.",
_idProps: {
service: idService,
uuid: "50"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
}, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomColumns_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("sjkgDyy+7UuYJzxAqUrMqg.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomColumnsOptionsRec();
rec.columnsAttr = 1;
return rec;
}();
}),
ExtendedClass: "margin-top-04"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "51",
alias: "20"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.List, {
animateItems: false,
extendedProperties: {
"disable-virtualization": "True"
},
gridProperties: {
classes: "OSFillParent"
},
mode: /*Default*/ 0,
source: model.variables.filtered_RefundPointsVar,
style: "list list-group",
tag: "div",
_idProps: {
service: idService,
name: "RefundPointsList"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new IteratorPlaceholderContent(function (idService, callContext) {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCard_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "53",
alias: "21"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "heading6",
visible: true,
_idProps: {
service: idService,
uuid: "54"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "RefundPointName"
},
value: model.variables.filtered_RefundPointsVar.getCurrent(callContext.iterationContext).nameAttr,
_idProps: {
service: idService,
uuid: "55"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomSeparator_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("XEofWOGrtUyCCCjhDaGRww.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomSeparatorOptionsRec();
rec.marginTopAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
rec.marginBottomAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
rec.stateAttr = ShopperPortalEUModel.staticEntities.customSeparatorState.lighter;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "56",
alias: "22"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "text-primary-black body-4",
visible: true,
_idProps: {
service: idService,
uuid: "57"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("oCGZDnweCkeLNuXB_qLF1A.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.alignAttr = ShopperPortalEUModel.staticEntities.flexAlign.center;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "58",
alias: "23"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomIcon_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("+3A+RRgxL02RmdhXOt3CGw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomIconOptionsRec();
rec.nameAttr = "directions";
rec.sizeAttr = ShopperPortalEUModel.staticEntities.customIconSize.small;
rec.testIdAttr = "directionsIcon";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "59",
alias: "24"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}), React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "RefundPointAddress"
},
value: model.variables.filtered_RefundPointsVar.getCurrent(callContext.iterationContext).fullAddressAttr,
_idProps: {
service: idService,
uuid: "60"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.filtered_RefundPointsVar.getCurrent(callContext.iterationContext).fullAddressAttr)]
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables.filtered_RefundPointsVar.getCurrent(callContext.iterationContext).fullAddressAttr), asPrimitiveValue(model.variables.filtered_RefundPointsVar.getCurrent(callContext.iterationContext).nameAttr)]
})];
}, callContext, idService, "3")
},
_dependencies: []
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.filtered_RefundPointsVar)]
})];
})];
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.filtered_RefundPointsVar), asPrimitiveValue(model.variables.filtered_CustomsOfficesVar), asPrimitiveValue(model.variables.groupSelectedVar), asPrimitiveValue(model.variables.oSVar), asPrimitiveValue(model.variables.citySelectedVar.valueAttr), asPrimitiveValue(model.variables.getLocationsAndCitiesDataAct.citiesOut), asPrimitiveValue(model.variables.getLocationsAndCitiesDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.getLocationCountriesDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.getLocationCountriesDataAct.eUCountryListOut), asPrimitiveValue(model.variables.countrySelectedVar.valueAttr)]
})];
}),
bottom: PlaceholderContent.Empty
},
_dependencies: [asPrimitiveValue(model.variables.filtered_RefundPointsVar), asPrimitiveValue(model.variables.filtered_CustomsOfficesVar), asPrimitiveValue(model.variables.groupSelectedVar), asPrimitiveValue(model.variables.oSVar), asPrimitiveValue(model.variables.citySelectedVar.valueAttr), asPrimitiveValue(model.variables.getLocationsAndCitiesDataAct.citiesOut), asPrimitiveValue(model.variables.getLocationsAndCitiesDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.getLocationCountriesDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.getLocationCountriesDataAct.eUCountryListOut), asPrimitiveValue(model.variables.countrySelectedVar.valueAttr), asPrimitiveValue(model.variables.isScreenReadyVar)]
}));
        };
        return View;
    })(OSView.BaseView.BaseWebScreen);
	
    return View;
});
define("ShopperPortalEU.Support.Locations.mvc$controller", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_API.model", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.controller", "ShopperPortalEU.languageResources", "ShopperPortalEU.clientVariables", "ShopperPortalEU.Support.Locations.mvc$debugger", "ShopperPortalEU.Support.controller", "ShopperPortalEU.controller$FormatLocationHours", "ShopperPortalEU_UI_Components.model$CustomDropdownCustomValueOptionRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$CustomDropdownListValueOptionsRec", "ShopperPortalEU_API.model$CustomOfficeInfo_WrapperRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_API", "ShopperPortalEU.model$CustomOfficeInfo_WrapperList", "ShopperPortalEU_API.model$RefundPoint_WrapperRec", "ShopperPortalEU.model$RefundPoint_WrapperList", "ShopperPortalEU_UI_Theme.model$LayoutOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$LayoutHeaderOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU.model$ApplicationHeaderRec", "ShopperPortalEU_UI_Components.model$CustomCardOptionsRec", "ShopperPortalEU.model$CountriesWithFlagsDropdownListList", "ShopperPortalEU_UI_Components.model$CustomDropdownListValidationOptionsRec", "ShopperPortalEU_UI_Components.model$CustomDropdownOptionsRec", "ShopperPortalEU_UI_Components.model$CustomDropdownCustomOptionRec", "ShopperPortalEU_UI_Components.model$CustomDropdownSearchOptionsRec", "ShopperPortalEU_UI_Components.model$CustomDropdownNullOptionRec", "ShopperPortalEU_UI_Components.model$CustomDropdownValidationOptionsRec", "ShopperPortalEU.model$CustomDropdownCustomValueOptionList", "ShopperPortalEU_UI_Components.model$FlexOptionsRec", "ShopperPortalEU_UI_Components.model$CustomIconOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonGroupOptionsRec", "ShopperPortalEU_UI_Components.model$CustomAlertOptionsRec", "ShopperPortalEU_UI_Components.model$CustomAlertIconOptionsRec", "ShopperPortalEU_UI_Components.model$CustomColumnsOptionsRec", "ShopperPortalEU_UI_Components.model$CustomSeparatorOptionsRec", "ShopperPortalEU_UI_Components.model$CustomSeparatorLabelOptionsRec", "ShopperPortalEU_UI_Components.model$CardExpandableOptionsRec", "ShopperPortalEU_UI_Components.model$UnescapedHTMLOptionsRec", "ShopperPortalEU_API.model$SPCountry_WrapperRec", "ShopperPortalEU.model$SPCountry_WrapperList", "ShopperPortalEU_UI_Components.model$GetOSRec", "ShopperPortalEU_UI_Components.controller$GetOS", "ShopperPortalEU_API.model$Location_WrapperRec"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_APIModel, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ComponentsController, ShopperPortalEULanguageResources, ShopperPortalEUClientVariables, ShopperPortalEU_Support_Locations_mvc_Debugger, ShopperPortalEU_SupportController) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {
getLocationCountries$DataActRefresh: -1,
getLocationsAndCities$DataActRefresh: -1,
geUserLocation$DataActRefresh: 0
};
this.dataFetchDependentsGraph = {
getLocationCountries$DataActRefresh: [],
getLocationsAndCities$DataActRefresh: [],
geUserLocation$DataActRefresh: []
};
this.shouldSendClientVarsToDataSources = true;
}
// Server Actions

// Aggregates and Data Actions
Controller.prototype.getLocationCountries$DataActRefresh = function (callContext) {
var model = this.model;
var controller = this.controller;
var callContext = controller.callContext(callContext);
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:iAG7IIVKI0WvPews_0fQTw:/NRWebFlows._1zAHv5LwEGws6WRTm11hA/NodesShownInESpaceTree.DjcQU56OF061EULeDSmmHQ/DataActions.iAG7IIVKI0WvPews_0fQTw:_Lk5BqsL57d5NYcX_wBWcg", "ShopperPortalEU", "GetLocationCountries", "NRFlows.DataScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.setThreadStartName(callContext.id, "Support/Locations/GetLocationCountries");
return controller.callDataAction("DataActionGetLocationCountries", "screenservices/ShopperPortalEU/Support/Locations/DataActionGetLocationCountries", "6RmCf1KzrmcAGUUStBT5ag", function (b) {
model.variables.getLocationCountriesDataAct.dataFetchStatusAttr = b;
}, function (json) {
model.variables.getLocationCountriesDataAct.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getLocationCountriesDataAct.constructor));
}, undefined, OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, callContext, ShopperPortalEUClientVariables, false);

}, function () {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:iAG7IIVKI0WvPews_0fQTw", callContext.id);
controller.popDebuggerContext(callContext);

});
};
Controller.prototype.getLocationsAndCities$DataActRefresh = function (callContext) {
var model = this.model;
var controller = this.controller;
var callContext = controller.callContext(callContext);
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:lj_BL7muYkmryWveyWgUbQ:/NRWebFlows._1zAHv5LwEGws6WRTm11hA/NodesShownInESpaceTree.DjcQU56OF061EULeDSmmHQ/DataActions.lj_BL7muYkmryWveyWgUbQ:IuVZdJ0wwKLeyq5yOfRyZg", "ShopperPortalEU", "GetLocationsAndCities", "NRFlows.DataScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.setThreadStartName(callContext.id, "Support/Locations/GetLocationsAndCities");
return controller.callDataAction("DataActionGetLocationsAndCities", "screenservices/ShopperPortalEU/Support/Locations/DataActionGetLocationsAndCities", "j+j4hP_4hG0Zfec8EW21MQ", function (b) {
model.variables.getLocationsAndCitiesDataAct.dataFetchStatusAttr = b;
}, function (json) {
model.variables.getLocationsAndCitiesDataAct.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getLocationsAndCitiesDataAct.constructor));
}, undefined, OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, callContext, ShopperPortalEUClientVariables, false).then(function () {
OutSystemsDebugger.setThreadStartName(callContext.id, "Support/Locations/GetLocationsAndCities On After Fetch");
controller._getLocationsAndCitiesOnAfterFetch$Action(controller.callContext(callContext));

});

}, function () {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:lj_BL7muYkmryWveyWgUbQ", callContext.id);
controller.popDebuggerContext(callContext);

});
};
Controller.prototype.geUserLocation$DataActRefresh = function (callContext) {
var model = this.model;
var controller = this.controller;
var callContext = controller.callContext(callContext);
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:HN53h5s6fUOkI9MuustUyQ:/NRWebFlows._1zAHv5LwEGws6WRTm11hA/NodesShownInESpaceTree.DjcQU56OF061EULeDSmmHQ/DataActions.HN53h5s6fUOkI9MuustUyQ:MCv9CiL8EnluFaNjReieag", "ShopperPortalEU", "GeUserLocation", "NRFlows.DataScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.setThreadStartName(callContext.id, "Support/Locations/GeUserLocation");
return controller.callDataAction("DataActionGeUserLocation", "screenservices/ShopperPortalEU/Support/Locations/DataActionGeUserLocation", "z+rUeLir1Nbo2zk9GptlfQ", function (b) {
model.variables.geUserLocationDataAct.dataFetchStatusAttr = b;
}, function (json) {
model.variables.geUserLocationDataAct.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.geUserLocationDataAct.constructor));
}, undefined, OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, callContext, ShopperPortalEUClientVariables, false).then(function () {
OutSystemsDebugger.setThreadStartName(callContext.id, "Support/Locations/GeUserLocation On After Fetch");
return controller._geUserLocationOnAfterFetch$Action(controller.callContext(callContext));

});

}, function () {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:HN53h5s6fUOkI9MuustUyQ", callContext.id);
controller.popDebuggerContext(callContext);

});
};

Controller.prototype.dataFetchActionNames = ["getLocationCountries$DataActRefresh", "getLocationsAndCities$DataActRefresh", "geUserLocation$DataActRefresh"];
// Client Actions
Controller.prototype._getLocationsAndCitiesOnAfterFetch$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("GetLocationsAndCitiesOnAfterFetch");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.Support.Locations.GetLocationsAndCitiesOnAfterFetch$vars"))());
var listFilter_CustomsOfficesVar = new OS.DataTypes.VariableHolder();
var listFilter_RefundPointsVar = new OS.DataTypes.VariableHolder();
var listFilter_CityVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.vars = vars;
varBag.listFilter_CustomsOfficesVar = listFilter_CustomsOfficesVar;
varBag.listFilter_RefundPointsVar = listFilter_RefundPointsVar;
varBag.listFilter_CityVar = listFilter_CityVar;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:PaecDGf7N0+OaJ_GwjjkFw:/NRWebFlows._1zAHv5LwEGws6WRTm11hA/NodesShownInESpaceTree.DjcQU56OF061EULeDSmmHQ/ClientActions.PaecDGf7N0+OaJ_GwjjkFw:DR8dnWlUhESW4hNCfIMd3w", "ShopperPortalEU", "GetLocationsAndCitiesOnAfterFetch", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:x0UVm0z6EUWNiSsW8Offag", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:HoCXZ9JYoECmdrHtD+OYpQ", callContext.id);
// Filtered_CustomsOffices = GetLocationsAndCities.CustomsOffices
model.variables.filtered_CustomsOfficesVar = model.variables.getLocationsAndCitiesDataAct.customsOfficesOut;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:HoCXZ9JYoECmdrHtD+OYpQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Filtered_RefundPoints = GetLocationsAndCities.RefundPoints
model.variables.filtered_RefundPointsVar = model.variables.getLocationsAndCitiesDataAct.refundPointsOut;
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:RNYsANYre06C3jbKC5Opnw", callContext.id) && model.variables.isResetCityVar)) {
// set empty city
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:__B1vX6sX0m892zT6QIBVw", callContext.id);
// CitySelected = EmptyCity
model.variables.citySelectedVar = vars.value.emptyCityVar;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:__B1vX6sX0m892zT6QIBVw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// IsScreenReady = True
model.variables.isScreenReadyVar = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:g+mOftsv2Uq_eyBvc5Ctrg", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:LX37v0azX0Ws1XlrnXyKPg", callContext.id);
// Execute Action: ListFilter_City
listFilter_CityVar.value = OS.SystemActions.listFilter(model.variables.getLocationsAndCitiesDataAct.citiesOut, function (p) {
return (OS.BuiltinFunctions.trim(p.textAttr) === OS.BuiltinFunctions.trim(model.variables.geUserLocationDataAct.locationOut.cityAttr));
}, callContext);

// User city in the list?
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:IJpL4T72n02AjyhXZ3YyeA", callContext.id) && ((listFilter_CityVar.value.filteredListOut.isEmpty === false) && (model.variables.isResetCityVar === false)))) {
// set city
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:9zy5rMpql0Ox2di9Ui1c9A", callContext.id);
// CitySelected = ListFilter_City.FilteredList.Current
model.variables.citySelectedVar = listFilter_CityVar.value.filteredListOut.getCurrent(callContext.iterationContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:094SQiZLb0+YOUk0LkGS5Q", callContext.id);
// Execute Action: ListFilter_CustomsOffices
listFilter_CustomsOfficesVar.value = OS.SystemActions.listFilter(model.variables.getLocationsAndCitiesDataAct.customsOfficesOut, function (p) {
return (OS.BuiltinFunctions.trim(p.cityNameAttr) === OS.BuiltinFunctions.trim(model.variables.citySelectedVar.textAttr));
}, callContext);

OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:1R2tn2MDxkGAASPgqCz3mQ", callContext.id);
// Execute Action: ListFilter_RefundPoints
listFilter_RefundPointsVar.value = OS.SystemActions.listFilter(model.variables.getLocationsAndCitiesDataAct.refundPointsOut, function (p) {
return (OS.BuiltinFunctions.trim(p.cityAttr) === OS.BuiltinFunctions.trim(model.variables.citySelectedVar.textAttr));
}, callContext);

// set filtered list
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:PshUHxwy80GFGzunZDWPKg", callContext.id);
// Filtered_CustomsOffices = ListFilter_CustomsOffices.FilteredList
model.variables.filtered_CustomsOfficesVar = listFilter_CustomsOfficesVar.value.filteredListOut;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:PshUHxwy80GFGzunZDWPKg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Filtered_RefundPoints = ListFilter_RefundPoints.FilteredList
model.variables.filtered_RefundPointsVar = listFilter_RefundPointsVar.value.filteredListOut;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:PshUHxwy80GFGzunZDWPKg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// IsScreenReady = True
model.variables.isScreenReadyVar = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:dYcyDOMYt0ekP_5hESta9g", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:CIxB0Bsjl0aApqa6xdSESg", callContext.id);
// IsScreenReady = True
model.variables.isScreenReadyVar = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:mOpohblWAUCabFkonUbhKQ", callContext.id);
}

}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:PaecDGf7N0+OaJ_GwjjkFw", callContext.id);
}

};
Controller.registerVariableGroupType("ShopperPortalEU.Support.Locations.GetLocationsAndCitiesOnAfterFetch$vars", [{
name: "EmptyCity",
attrName: "emptyCityVar",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Record,
defaultValue: function () {
return new ShopperPortalEU_UI_ComponentsModel.CustomDropdownCustomValueOptionRec();
},
complexType: ShopperPortalEU_UI_ComponentsModel.CustomDropdownCustomValueOptionRec
}]);
Controller.prototype._countryOnChange$Action = function (currentCountryIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("CountryOnChange");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.Support.Locations.CountryOnChange$vars"))());
vars.value.currentCountryInLocal = currentCountryIn.clone();
varBag.callContext = callContext;
varBag.vars = vars;
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:sI1JSmfsMUuukTtXRdCcRQ:/NRWebFlows._1zAHv5LwEGws6WRTm11hA/NodesShownInESpaceTree.DjcQU56OF061EULeDSmmHQ/ClientActions.sI1JSmfsMUuukTtXRdCcRQ:GOmxRdQJcj+OO5W883mrvA", "ShopperPortalEU", "CountryOnChange", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:n1w4cDWRrUKxe9FoEGiqig", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
// reset flags
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:6SZM8M0EdE2lDReJ2TedTg", callContext.id);
// CountrySelected = CurrentCountry
model.variables.countrySelectedVar = vars.value.currentCountryInLocal;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:6SZM8M0EdE2lDReJ2TedTg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// IsResetCity = True
model.variables.isResetCityVar = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:6SZM8M0EdE2lDReJ2TedTg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// IsScreenReady = False
model.variables.isScreenReadyVar = false;
// HasCountry?
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:sFqgG1y6n02e5A4VCtY84w", callContext.id) && !(((OS.BuiltinFunctions.textToInteger(model.variables.countrySelectedVar.valueAttr)) !== (0))))) {
// reset flags
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Ha1Z6nxyD0mCLLhd+CyluA", callContext.id);
// IsResetCity = True
model.variables.isResetCityVar = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Ha1Z6nxyD0mCLLhd+CyluA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// IsScreenReady = True
model.variables.isScreenReadyVar = true;
}

OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:RVOR6WohjEa5xmE9FX7EQw", callContext.id);
// Refresh Query: GetLocationsAndCities
var result = controller.getLocationsAndCities$DataActRefresh(callContext);
model.flush();
return result.then(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:tvU2nSchFkKFmLwVyppK+Q", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:sI1JSmfsMUuukTtXRdCcRQ", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:sI1JSmfsMUuukTtXRdCcRQ", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("ShopperPortalEU.Support.Locations.CountryOnChange$vars", [{
name: "CurrentCountry",
attrName: "currentCountryInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Record,
defaultValue: function () {
return new ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValueOptionsRec();
},
complexType: ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValueOptionsRec
}]);
Controller.prototype._geUserLocationOnAfterFetch$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("GeUserLocationOnAfterFetch");
callContext = controller.callContext(callContext);
var listFilter_CountryVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.listFilter_CountryVar = listFilter_CountryVar;
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:OfRLd6u_jUS+_C+kyHmBhg:/NRWebFlows._1zAHv5LwEGws6WRTm11hA/NodesShownInESpaceTree.DjcQU56OF061EULeDSmmHQ/ClientActions.OfRLd6u_jUS+_C+kyHmBhg:lPCHoUewRP86JX9eVRKieg", "ShopperPortalEU", "GeUserLocationOnAfterFetch", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:1+_aVC4VukCYRmOpEjKBpQ", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:gI_eZFC0YUi+3SF8g4Yp0A", callContext.id);
// Refresh Query: GetLocationCountries
var result = controller.getLocationCountries$DataActRefresh(callContext);
model.flush();
return result.then(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:QPh2F28AEkWNqGCuWT9bWA", callContext.id);
// Execute Action: ListFilter_Country
listFilter_CountryVar.value = OS.SystemActions.listFilter(model.variables.getLocationCountriesDataAct.eUCountryListOut, function (p) {
return (p.nameAttr === model.variables.geUserLocationDataAct.locationOut.countryAttr);
}, callContext);

}).then(function () {
// User Location Country?
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:870qG6OOv06wN1JnfXxxVw", callContext.id) && (((model.variables.geUserLocationDataAct.locationOut.countryAttr) !== ("")) && (listFilter_CountryVar.value.filteredListOut.isEmpty === false)))) {
// set CountrySelected
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:uGRWnOZWFkutijxPbHWCFQ", callContext.id);
// CountrySelected.Text = GeUserLocation.Location.Country
model.variables.countrySelectedVar.textAttr = model.variables.geUserLocationDataAct.locationOut.countryAttr;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:uGRWnOZWFkutijxPbHWCFQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// CountrySelected.Value = GeUserLocation.Location.CountryCode
model.variables.countrySelectedVar.valueAttr = model.variables.geUserLocationDataAct.locationOut.countryCodeAttr;
} else {
// set CountrySelected
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Pv_9iN6yukOF5LAeYfL3dQ", callContext.id);
// CountrySelected.Text = GetLocationCountries.EUCountryList[0].Name
model.variables.countrySelectedVar.textAttr = model.variables.getLocationCountriesDataAct.eUCountryListOut.getItem(0).nameAttr;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Pv_9iN6yukOF5LAeYfL3dQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// CountrySelected.Value = GetLocationCountries.EUCountryList[0].Code3Digits
model.variables.countrySelectedVar.valueAttr = model.variables.getLocationCountriesDataAct.eUCountryListOut.getItem(0).code3DigitsAttr;
}

OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:h3u8LHntnEyJ2pK4iyucoA", callContext.id);
// Refresh Query: GetLocationsAndCities
var result = controller.getLocationsAndCities$DataActRefresh(callContext);
model.flush();
return result.then(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:BpfpLSPhTESZDznipEj+5g", callContext.id);
});
});
}).then(function (res) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:OfRLd6u_jUS+_C+kyHmBhg", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:OfRLd6u_jUS+_C+kyHmBhg", callContext.id);
throw ex;

});
};
Controller.prototype._cityOnChange$Action = function (currentDataIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("CityOnChange");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.Support.Locations.CityOnChange$vars"))());
vars.value.currentDataInLocal = currentDataIn.clone();
var listFilterVar = new OS.DataTypes.VariableHolder();
var listFilter_RefundPointsVar = new OS.DataTypes.VariableHolder();
var listFilter_CustomsOfficesVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.vars = vars;
varBag.listFilterVar = listFilterVar;
varBag.listFilter_RefundPointsVar = listFilter_RefundPointsVar;
varBag.listFilter_CustomsOfficesVar = listFilter_CustomsOfficesVar;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:mRkXs76ZjE61MVMcGjM0xw:/NRWebFlows._1zAHv5LwEGws6WRTm11hA/NodesShownInESpaceTree.DjcQU56OF061EULeDSmmHQ/ClientActions.mRkXs76ZjE61MVMcGjM0xw:tF_i7HEOV_sWxLtc_vh+FQ", "ShopperPortalEU", "CityOnChange", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Nj86ZExfNkCbevfBhfkGdA", callContext.id);
// set city
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:+8u9iUJ1Bkiqt_I4_Y3oLA", callContext.id);
// CitySelected = CurrentData
model.variables.citySelectedVar = vars.value.currentDataInLocal;
// NoCitySelected?
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:WcP2NIADwE2VPJHfgkuPow", callContext.id) && (model.variables.citySelectedVar.valueAttr === ""))) {
// reset filtered list
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:TTZS19wBCkGmD+dh57QxIw", callContext.id);
// Filtered_CustomsOffices = GetLocationsAndCities.CustomsOffices
model.variables.filtered_CustomsOfficesVar = model.variables.getLocationsAndCitiesDataAct.customsOfficesOut;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:TTZS19wBCkGmD+dh57QxIw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Filtered_RefundPoints = GetLocationsAndCities.RefundPoints
model.variables.filtered_RefundPointsVar = model.variables.getLocationsAndCitiesDataAct.refundPointsOut;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Q+aJ4T5zxEOMLthy6Dh2+Q", callContext.id);
} else {
// ios
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:on7HS0MFD0KgN3ZK8s+Jgg", callContext.id) && ((model.variables.oSVar === "ios") && false))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:mLNaMd4hsEK5tYzPD_aPxQ", callContext.id);
// Execute Action: ListFilter
listFilterVar.value = OS.SystemActions.listFilter(model.variables.getLocationsAndCitiesDataAct.citiesOut, function (p) {
return (p.valueAttr === model.variables.citySelectedVar.valueAttr);
}, callContext);

OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:oW3Z3_dGDUW9YC15PWKhLA", callContext.id);
// CitySelected.Text = ListFilter.FilteredList.Current.Text
model.variables.citySelectedVar.textAttr = listFilterVar.value.filteredListOut.getCurrent(callContext.iterationContext).textAttr;
}

OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Zvzt7I89pkq+MqdaA6aJVQ", callContext.id);
// Execute Action: ListFilter_CustomsOffices
listFilter_CustomsOfficesVar.value = OS.SystemActions.listFilter(model.variables.getLocationsAndCitiesDataAct.customsOfficesOut, function (p) {
return (OS.BuiltinFunctions.trim(p.cityNameAttr) === OS.BuiltinFunctions.trim(model.variables.citySelectedVar.textAttr));
}, callContext);

OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:15g6tz1jPUeScxE67VRBWg", callContext.id);
// Execute Action: ListFilter_RefundPoints
listFilter_RefundPointsVar.value = OS.SystemActions.listFilter(model.variables.getLocationsAndCitiesDataAct.refundPointsOut, function (p) {
return (OS.BuiltinFunctions.trim(p.cityAttr) === OS.BuiltinFunctions.trim(model.variables.citySelectedVar.textAttr));
}, callContext);

// set filtered list
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ZOzEiraGU0SBWlI7Nu9EZg", callContext.id);
// Filtered_CustomsOffices = ListFilter_CustomsOffices.FilteredList
model.variables.filtered_CustomsOfficesVar = listFilter_CustomsOfficesVar.value.filteredListOut;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ZOzEiraGU0SBWlI7Nu9EZg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Filtered_RefundPoints = ListFilter_RefundPoints.FilteredList
model.variables.filtered_RefundPointsVar = listFilter_RefundPointsVar.value.filteredListOut;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:23Ro2mfwlUK74hOwmONt6w", callContext.id);
}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:mRkXs76ZjE61MVMcGjM0xw", callContext.id);
}

};
Controller.registerVariableGroupType("ShopperPortalEU.Support.Locations.CityOnChange$vars", [{
name: "CurrentData",
attrName: "currentDataInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Record,
defaultValue: function () {
return new ShopperPortalEU_UI_ComponentsModel.CustomDropdownCustomValueOptionRec();
},
complexType: ShopperPortalEU_UI_ComponentsModel.CustomDropdownCustomValueOptionRec
}]);
Controller.prototype._onInitialize$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnInitialize");
callContext = controller.callContext(callContext);
var getOSVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.getOSVar = getOSVar;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:A3Vj1ffofU2Fm2pp7s6fEQ:/NRWebFlows._1zAHv5LwEGws6WRTm11hA/NodesShownInESpaceTree.DjcQU56OF061EULeDSmmHQ/ClientActions.A3Vj1ffofU2Fm2pp7s6fEQ:PQhw+i7MUps0jkcwhHf8_Q", "ShopperPortalEU", "OnInitialize", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ry0l6eZ0BUCPA9HZ98Knfw", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:tZHXoRQHSU+5GZWW1YCFCA", callContext.id);
// Execute Action: GetOS
getOSVar.value = ShopperPortalEU_UI_ComponentsController.default.getOS$Action(callContext);

OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:bY0vlmTeqEObjkfIqtwA0g", callContext.id);
// OS = GetOS.OS.OS.Name
model.variables.oSVar = getOSVar.value.oSOut.oSAttr.nameAttr;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:z2E0BJx9C0O7hMl118qRUg", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:A3Vj1ffofU2Fm2pp7s6fEQ", callContext.id);
}

};

Controller.prototype.getLocationsAndCitiesOnAfterFetch$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._getLocationsAndCitiesOnAfterFetch$Action, callContext);

};
Controller.prototype.countryOnChange$Action = function (currentCountryIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._countryOnChange$Action, callContext, currentCountryIn);

};
Controller.prototype.geUserLocationOnAfterFetch$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._geUserLocationOnAfterFetch$Action, callContext);

};
Controller.prototype.cityOnChange$Action = function (currentDataIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._cityOnChange$Action, callContext, currentDataIn);

};
Controller.prototype.onInitialize$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onInitialize$Action, callContext);

};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:_1zAHv5LwEGws6WRTm11hA:/NRWebFlows._1zAHv5LwEGws6WRTm11hA:mL1lLGIiQoiQpGIO1O5tXg", "ShopperPortalEU", "Support", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:DjcQU56OF061EULeDSmmHQ:/NRWebFlows._1zAHv5LwEGws6WRTm11hA/NodesShownInESpaceTree.DjcQU56OF061EULeDSmmHQ:1ChCarKiorCkkspYxXTIMg", "ShopperPortalEU", "Locations", "NRNodes.WebScreen", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:DjcQU56OF061EULeDSmmHQ", callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:_1zAHv5LwEGws6WRTm11hA", callContext.id);
};
Controller.prototype.onInitializeEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Support/Locations On Initialize");
return controller.onInitialize$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return ShopperPortalEU_SupportController.default.handleError(ex, this.callContext());
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return ShopperPortalEUController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, ShopperPortalEULanguageResources);
});

define("ShopperPortalEU.Support.Locations.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"ourOx42VhUSw0rXUIPVQLw": {
getter: function (varBag, idService) {
return varBag.vars.value.emptyCityVar;
}
},
"094SQiZLb0+YOUk0LkGS5Q": {
getter: function (varBag, idService) {
return varBag.listFilter_CustomsOfficesVar.value;
}
},
"1R2tn2MDxkGAASPgqCz3mQ": {
getter: function (varBag, idService) {
return varBag.listFilter_RefundPointsVar.value;
}
},
"LX37v0azX0Ws1XlrnXyKPg": {
getter: function (varBag, idService) {
return varBag.listFilter_CityVar.value;
}
},
"_BBjfQKyO0CeVflpcExbDg": {
getter: function (varBag, idService) {
return varBag.vars.value.currentCountryInLocal;
}
},
"QPh2F28AEkWNqGCuWT9bWA": {
getter: function (varBag, idService) {
return varBag.listFilter_CountryVar.value;
}
},
"g9b1ETX20kOkcWRYK1sJ4Q": {
getter: function (varBag, idService) {
return varBag.vars.value.currentDataInLocal;
}
},
"mLNaMd4hsEK5tYzPD_aPxQ": {
getter: function (varBag, idService) {
return varBag.listFilterVar.value;
}
},
"15g6tz1jPUeScxE67VRBWg": {
getter: function (varBag, idService) {
return varBag.listFilter_RefundPointsVar.value;
}
},
"Zvzt7I89pkq+MqdaA6aJVQ": {
getter: function (varBag, idService) {
return varBag.listFilter_CustomsOfficesVar.value;
}
},
"tZHXoRQHSU+5GZWW1YCFCA": {
getter: function (varBag, idService) {
return varBag.getOSVar.value;
}
},
"9uJ3VeUEfUajmLNbyqhnuw": {
getter: function (varBag, idService) {
return varBag.model.variables.groupSelectedVar;
},
dataType: OS.DataTypes.DataTypes.Integer
},
"YT_+UZ8iJ0qzxZqW53Awew": {
getter: function (varBag, idService) {
return varBag.model.variables.citySelectedVar;
}
},
"nabeMdHV3ka1nFbMxBjLjQ": {
getter: function (varBag, idService) {
return varBag.model.variables.countrySelectedVar;
}
},
"wL2fGcQyyki4jYiXGEkvhw": {
getter: function (varBag, idService) {
return varBag.model.variables.filtered_CustomsOfficesVar;
}
},
"yKZ68lEOlkyNq3iBOFCJAQ": {
getter: function (varBag, idService) {
return varBag.model.variables.filtered_RefundPointsVar;
}
},
"WL4RhzoUq0yJfwwRIabMuw": {
getter: function (varBag, idService) {
return varBag.model.variables.isResetCityVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"h1_dA9M0qk2L6b1+iz7reQ": {
getter: function (varBag, idService) {
return varBag.model.variables.isScreenReadyVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"qofauBaxREyH7am9NhDNug": {
getter: function (varBag, idService) {
return varBag.model.variables.oSVar;
},
dataType: OS.DataTypes.DataTypes.Text
},
"iAG7IIVKI0WvPews_0fQTw": {
getter: function (varBag, idService) {
return varBag.model.variables.getLocationCountriesDataAct;
}
},
"lj_BL7muYkmryWveyWgUbQ": {
getter: function (varBag, idService) {
return varBag.model.variables.getLocationsAndCitiesDataAct;
}
},
"HN53h5s6fUOkI9MuustUyQ": {
getter: function (varBag, idService) {
return varBag.model.variables.geUserLocationDataAct;
}
},
"GCHwg+nFV0ewMaRI3m6jcA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderLeft"));
})(varBag.model, idService);
}
},
"d84r3335H0epWpL_eLKaUw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderCenter"));
})(varBag.model, idService);
}
},
"XOI4QJOVEUqUOJkBZxCjHg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderRight"));
})(varBag.model, idService);
}
},
"YHYTt9AfKE2g5G+1IHhfFw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderBottom"));
})(varBag.model, idService);
}
},
"g4HDWn5__UaGbzEuKSdJqA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"SSr0eoqOaECP5Ul98b+PuA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"yCw7b6dahkePzhiPkeFeiA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"vg0jQzFrCUuLA_NYvuq0Rg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Label"));
})(varBag.model, idService);
}
},
"90lY9fiKDkqKmG2GNfjQTA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Label"));
})(varBag.model, idService);
}
},
"laUn0BbCP0CHADBVM6GGeg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Dropdown"));
})(varBag.model, idService);
}
},
"hrfnAdMmFEGaY7NhijxZVA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Dropdown_City"));
})(varBag.model, idService);
}
},
"5ffhXSMQyk6+q6csLn1Dzg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"1Mb0OE6ytEmHukehW6WJ4A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("ButtonGroup"));
})(varBag.model, idService);
}
},
"pP7NVtaGWUO_+ArsOKYu_w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("ButtonGroup1"));
})(varBag.model, idService);
}
},
"3vfLy9oYREybwcJvpEZ8Uw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("ButtonGroupItem1"));
})(varBag.model, idService);
}
},
"V8PmIu_1UEGxQyGFR4z9Aw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("ButtonGroupItem2"));
})(varBag.model, idService);
}
},
"YBbYFmIIk06+mglDj9_BVA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("If_CustomsOfficeTab"));
})(varBag.model, idService);
}
},
"WD+NXHL3vE21Sx_2mZIriw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"7ijRPRm_7ky1PsJ8Maq_uQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"0sOxHjxF8U6b9dC2opDqDw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("NoCustomsOffices"));
})(varBag.model, idService);
}
},
"lhQcdbx7U0GwW1i_mlzAcA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"xXw7QuIBbUGtcUXlQeU0jg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("CustomsOfficesList"));
})(varBag.model, idService);
}
},
"uQ4VP+y12UmVH+uhebSRBQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"sctpbpSNlUWXlzzOLIeF9A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HasLocationName2"));
})(varBag.model, idService);
}
},
"KitX_qTQgkWn2a6yRBVaFQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HasDirections2"));
})(varBag.model, idService);
}
},
"6bY3IElN5kGlQQXTwQ_DmQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"2OzwABHw_UaspFZGaHWjlA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"bzpbpVM360ehXNplNhg5mg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"iF6jR1HWDEWAuCYydC4q9Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Preview"));
})(varBag.model, idService);
}
},
"CIkJetohVkmc1Vy+D3Df6w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("NoRefundPoints"));
})(varBag.model, idService);
}
},
"EcDy2Ao1n02vsgt0tTEFHw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"cvqON+0O_0q_Ny0nl2DX3A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("RefundPointsList"));
})(varBag.model, idService);
}
},
"AFfAaasFgUeQ0SHu_hHgSg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"03+DkfPIOUyYRCVWIFnAaA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"N9eYR2P3rEOqRTnL4jeVYQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Bottom"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
