class customPopupLayout {
  constructor(id, options, events) {
    this.element = document.getElementById(id);
    this.elements = {
      popup: this.element.closest('.popup-dialog'),
      backdrop: null
    }
    this.listeners = {
      _overlayClick: this._overlayClick.bind(this)
    }
    this.options = options;
    this.events = events;
    this._build();
  }
  _overlayClick(e) { 
    if (e.target === this.elements.backdrop) {
      this.events.overlayClick();
    }
  }
  _setProps() {
    if (this.options.headerImage.url) {
      this.elements.popup.classList.add('custom-popup--header-image');
      this.elements.popup.style.setProperty('--header-img-url', `url(${this.options.headerImage.url})`);
    } else {
      this.elements.popup.classList.remove('custom-popup--header-image');
      this.elements.popup.style.removeProperty('--header-img-url')
    }
  }
  _build() {
    if (this.elements.popup) {
      this.elements.popup.classList.add('custom-popup');
      this.elements.backdrop = this.elements.popup.parentElement;
      this.elements.backdrop.addEventListener('click', this.listeners._overlayClick);
      this._setProps();
    }
  }
  parametersChanged(options) {
    this.options = options;
    this._setProps();
  }
}