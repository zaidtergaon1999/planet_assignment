define("Auth_Europe.referencesHealth$Users", [], function () {
// Reference to producer 'Users' is OK.
});
define("Auth_Europe.referencesHealth", [], function () {
});
