class phoneNumberInput {
  constructor(id, options, events) {
    this.class = 'phone-number-input';
    this.element = document.getElementById(id);
    this.elementsClasses = {
      dropdown: {
        element: this.class.concat('__dropdown'),
        search: this.class.concat('__dropdown-search'),
        list: this.class.concat('__dropdown-list'),
        item: this.class.concat('__dropdown-item')
      }
    };
    this.elements = {
      input: this.element.firstElementChild.nextElementSibling.firstElementChild.nextElementSibling.firstElementChild,
      dropdown: {
        element: null,
        search: null,
        list: null
      },
      overlay: this.element.lastElementChild
    };
    this.stateClasses = {
      open: this.class.concat('--open'),
      dropdownItem: {
        selected: this.elementsClasses.dropdown.item.concat('--selected'),
        highlighted: this.elementsClasses.dropdown.item.concat('--highlighted'),
        hidden: this.elementsClasses.dropdown.item.concat('--hidden'),
      },
      search: {
        noResults: this.class.concat('--no-search-results')
      }
    };
    this.listeners = {
      _display: this._display.bind(this),
      _setHeight: this._setHeight.bind(this),
      _keydownInput: this._keydownInput.bind(this),
      _keydownDropdown: this._keydownDropdown.bind(this),
      _paste: this._paste.bind(this),
      _dropdownItemHover: this._dropdownItemHover.bind(this),
      _dropdownItemClick: this._dropdownItemClick.bind(this),
      _overlayClick: this._overlayClick.bind(this),
      _input: this._input.bind(this)
    };
    this.dropdownItem = {
      selected: null,
      highlighted: null
    };
    this.open = false;
    this.countries = [];
    this.data = this._resetData();
    this.options = options;
    this.events = events;
    this._build();
  }
  _setHeight() {
    this.element.style.setProperty('--dropdown-height', this.elements.dropdown.element.offsetHeight + 'px');
  }
  _resetData() {
    return {
      phoneNumber: '',
      formattedPhoneNumber: '',
      valid: false,
      country: {
        code: '',
        name: '',
        dialCode: ''
      }
    };
  }
  _resetSelection() {
    if (this.dropdownItem.highlighted) {
      this.dropdownItem.highlighted.classList.remove(this.stateClasses.dropdownItem.highlighted);
    }
    if (this.dropdownItem.selected) {
      this.dropdownItem.selected.classList.remove(this.stateClasses.dropdownItem.selected);
    }
    this.dropdownItem.highlighted = null;
    this.dropdownItem.selected = null;
  }
  _getDropdownItem(c) {
    if (this.elements.dropdown.element) {
      return [...this.elements.dropdown.list.children].find(x => x.dataset.code === c);
    }
  }
  _setHighlighted(el) {
    if (el == null && this.data.country.code) {
      this._setSelected(this._getDropdownItem(this.data.country.code), false);
    } else {
      if (this.dropdownItem.highlighted) {
        this.dropdownItem.highlighted.classList.remove(this.stateClasses.dropdownItem.highlighted);
      }
      if (el == null) {
        el = this.dropdownItem.highlighted || this.elements.dropdown.list.firstElementChild;
      }
      this.dropdownItem.highlighted = el;
      this.dropdownItem.highlighted.classList.add(this.stateClasses.dropdownItem.highlighted);
      this.dropdownItem.highlighted.scrollIntoViewIfNeeded ? this.dropdownItem.highlighted.scrollIntoViewIfNeeded() : this.dropdownItem.highlighted.scrollIntoView();
    }
  }
  _setSelected(el, u = true) {
    if (el) {
      if (this.dropdownItem.selected) {
        this.dropdownItem.selected.classList.remove(this.stateClasses.dropdownItem.selected);
      }
      this.dropdownItem.selected = el;
      this.dropdownItem.selected.classList.add(this.stateClasses.dropdownItem.selected);
      this._setHighlighted(this.dropdownItem.selected);
      if (u) {
        this._setValue('+' + this.dropdownItem.selected.dataset.dialCode, this.dropdownItem.selected.dataset.code, this.dropdownItem.selected.dataset.name, this.dropdownItem.selected.dataset.dialCode);
      }
    }
  }
  _setValue(v, c = '', n = '', d = '') {
    v = v.replaceAll(' ', '');
    let ayt = new libphonenumber.AsYouType();
    this.data = this._resetData();
    if (c === '') {
      this._resetSelection();
    }
    this.data.phoneNumber = v;
    this.data.formattedPhoneNumber = ayt.input(v);
    this.data.country.code = c;
    this.data.country.name = n;
    this.data.country.dialCode = d;
    if (this.data.country.code === '') {
      this.data.country.code = ayt.getCountry();
      if (this.data.country.code) {
        let country = this.countries.find(x => x.code === this.data.country.code);
        if (country) {
          this.data.country.name = country.name;
          this.data.country.dialCode = country.dialCode;
        }
      }
    }
    try {
      let pv = libphonenumber.parsePhoneNumber(v);
      if (pv) {
        this.data.valid = libphonenumber.isValidPhoneNumber(v);
        this.data.country.code = pv.country;
        this.data.country.name = libcountry.getCountryName(pv.country);
        this.data.country.dialCode = pv.countryCallingCode;
      }
      this.events.setValue(JSON.stringify(this.data));
    } catch (error) {
      this.events.setValue(JSON.stringify(this.data));
    }
  }
  _paste(e) {
    e.preventDefault();
    let t = (e.clipboardData || window.clipboardData).getData("text");
    if (t) {
      this._setValue(t.includes('+') ? t : '+' + t);
    }
  }
  _keydownDropdown(e) {
    switch (e.key) {
      case 'Enter':
        e.preventDefault();
        e.stopPropagation();
        this._setSelected(this.dropdownItem.highlighted);
        this._close();
        this.elements.input.focus();
        break;
      case 'ArrowDown':
        this._setHighlighted(this.dropdownItem.highlighted.nextElementSibling ? this.dropdownItem.highlighted.nextElementSibling : this.elements.dropdown.element.firstElementChild.firstElementChild);
        e.preventDefault();
        e.stopPropagation();
        break;
      case 'ArrowUp':
        this._setHighlighted(this.dropdownItem.highlighted.previousElementSibling ? this.dropdownItem.highlighted.previousElementSibling : this.elements.dropdown.element.firstElementChild.lastElementChild);
        e.preventDefault();
        e.stopPropagation();
        break;
      case 'Tab':
        this._close();
        e.stopPropagation();
        break;
      case 'Escape':
        this._close();
        this.elements.input.focus();
        e.stopPropagation();
        e.preventDefault();
        break;
    }
  }
  _input(e) {
    let v = e.target.value;
    if (v) {
      let l = v.slice(-1);
      if ((!/\d/.test(l)) && (v != '+')) {
        v = v.slice(0, -1);
        e.target.value = v;
        this._setValue(v);
      }
    }
  }
  _keydownInput(e) {
    let v = this.elements.input.value;
    if (e.key !== 'Unidentified') {
      if (!e.ctrlKey && e.key !== 'ArrowLeft' && e.key !== 'ArrowRight') {
        if (!(e.key === 'Backspace' || e.key === 'Delete')) {
          if (v.length === 0) {
            e.preventDefault();
            if (/\d/.test(e.key)) {
              v = '+' + e.key;
              this._setValue(v);
            } else {
              v = '+';
              this._setValue(v);
            }
          } else {
            e.preventDefault();
            let pMaxLength = 15; //Mobile number max length
            if (v.replaceAll(' ', '').length === pMaxLength) {
              return;
            }
            if (/\d/.test(e.key)) {
              if (!(v.replaceAll(' ', '').length === pMaxLength)) {
                this._setValue(v + e.key);
              }
            }
          }
        } else {
          e.preventDefault();
          if (e.target.selectionStart === 0 && e.target.selectionEnd === v.length) {
            this._setValue('');
          } else {
            if (e.target.selectionEnd > e.target.selectionStart) {
              let _v = v.substring(0, e.target.selectionStart) + v.substring(e.target.selectionEnd, v.length);
              this._setValue(_v.replaceAll(' ', ''));
            } else {
              if (v.length <= 2) {
                this._setValue('');
              } else {
                if (v.length > 2 && v[v.length - 2] === ' ') {
                  ;
                  this._setValue(v.slice(0, -2));
                } else {
                  this._setValue(v.slice(0, -1));
                }
              }
            }
          }
        }
      }
    } else {
      e.preventDefault();
    }
  }
  _overlayClick(e) {
    this._close();
  }
  _dropdownItemClick(e) {
    if (e.target.dataset.code) {
      this._setSelected(e.target);
      this._close();
      this.elements.input.focus();
    }
  }
  _dropdownItemHover(e) {
    this._setHighlighted(e.currentTarget);
  }
  _build() {
    this.countries = libphonenumber.getCountries().map((x) => ({
      ['code']: x,
      ['name']: libcountry.getCountryName(x),
      ['dialCode']: libphonenumber.getCountryCallingCode(x)
    }));
    this.countries.sort((a, b) => {
      let _a = a.name.toLowerCase(),
        _b = b.name.toLowerCase();
      if (_a < _b) {
        return -1;
      }
      if (_a > _b) {
        return 1;
      }
      return 0;
    });
    this.events.setCountries(JSON.stringify(this.countries));
    this.elements.input.addEventListener('input', this.listeners._input);
    this.elements.input.addEventListener('keydown', this.listeners._keydownInput);
    this.elements.input.addEventListener('paste', this.listeners._paste);
    this.elements.overlay.addEventListener('click', this.listeners._overlayClick);
    if (this.options.phoneNumber) {
      this._setValue(this.options.phoneNumber);
    }
  }
  _display() {
    this.element.classList.add(this.stateClasses.open);
  }
  _close() {
    this.open = false;
    this.element.classList.remove(this.stateClasses.open);
    document.body.removeEventListener('keydown', this.listeners._keydownDropdown);
    setTimeout(this.events.close, 200);
  }
  _open() {
    this.open = true;
    document.body.addEventListener('keydown', this.listeners._keydownDropdown);
    this.events.open();
  }
  search() {
    if (this.elements.dropdown.list) {
      var hideAll = true;
      this.elements.dropdown.list.childNodes.forEach(i => {
        if (i.dataset.name.toLowerCase().includes(this.elements.dropdown.search.value.toLowerCase())) {
          i.classList.remove(this.stateClasses.dropdownItem.hidden);
          hideAll = false;
        } else {
          i.classList.add(this.stateClasses.dropdownItem.hidden);
        }
      });
      if (hideAll) {
        this.element.classList.add(this.stateClasses.search.noResults);
      } else {
        this.element.classList.remove(this.stateClasses.search.noResults);
        this._setHighlighted([...this.elements.dropdown.list.children].find(i => !i.classList.contains(this.stateClasses.dropdownItem.hidden)), false);
      }
    }
  }
  dropdownRendered() {
    this.elements.dropdown.element = this.element.getElementsByClassName(this.elementsClasses.dropdown.element)[0];
    if (this.elements.dropdown.element) {
      this.elements.dropdown.list = this.elements.dropdown.element.getElementsByClassName(this.elementsClasses.dropdown.list)[0];
      this.elements.dropdown.search = this.elements.dropdown.element.querySelector(`.${this.elementsClasses.dropdown.search} [data-input]`);
      this.elements.dropdown.list.addEventListener('click', this.listeners._dropdownItemClick);
      this.elements.dropdown.list.childNodes.forEach(i => i.addEventListener('mouseover', this.listeners._dropdownItemHover));
      setTimeout(this.listeners._setHeight, 0);
      this._setHighlighted();
      this.elements.dropdown.search.focus();
      if (this.dropdownItem.selected) {
        this.dropdownItem.selected.scrollIntoViewIfNeeded ? this.dropdownItem.selected.scrollIntoViewIfNeeded() : this.dropdownItem.selected.scrollIntoView();
      }
      setTimeout(this.listeners._display, 0);
    }
  }
  toggle() {
    this.open ? this._close() : this._open();
  }
  parametersChanged(options) {
    if (this.data.phoneNumber !== options.phoneNumber) {
      this._setValue(options.phoneNumber);
    }
    this.options = options;
  }
  destroy() {
    this._close();
  }
}