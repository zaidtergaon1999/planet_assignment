define("ShopperPortalEU_UI_Resources.referencesHealth$Users", [], function () {
// Reference to producer 'Users' is OK.
});
define("ShopperPortalEU_UI_Resources.referencesHealth", [], function () {
});
