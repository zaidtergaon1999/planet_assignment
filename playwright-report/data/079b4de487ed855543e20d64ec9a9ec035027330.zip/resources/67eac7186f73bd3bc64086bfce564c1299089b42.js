class monthYearInput {
  constructor(id, options, events) {
    this.class = 'month-year-input';
    this.element = document.getElementById(id);
    this.elements = {
      input: this.element.firstElementChild.nextElementSibling.firstElementChild.firstElementChild,
      label: this.element.firstElementChild.querySelector('label')
    };
    this.listeners = {
      _keydown: this._keydown.bind(this),
      _change: this._change.bind(this)
    };
    this.osNullDate = '1900-01-01';
    this.events = events;
    this.options = options;
    this._build();
  }
  _setMaskValue(d) {
    let value = this.elements.input.value,
      maskedValue = '';
    if (value.length === 0) {
      maskedValue = d > 1 ? '0'.concat(d).concat('/') : d;
      this.elements.input.value = maskedValue;
    } else {
      if (value.length === 1) {
        if ((value[0] === '0' && d > 0) || (value[0] === '1' && d < 3)) {
          maskedValue = value.concat(d).concat('/');
          this.elements.input.value = maskedValue;
        }
      } else {
        this.elements.input.value = value.concat(d);
      }
    }
    this._change();
  }
  _change() {
    this.events.change();
  }
  _keydown(e) {
    if (e.key === 'Backspace' || e.key === 'ArrowRight' || e.key === 'ArrowLeft') {
      if (e.key === 'Backspace' && this.elements.input.value.length === 3) {
        this.elements.input.value = this.elements.input.value.slice(0, -1);
      }
    } else {
      e.preventDefault();
      if (/^\d+$/.test(e.key) && this.elements.input.value.length < 5) {
        this._setMaskValue(Number(e.key));
      }
    }
  }
  _labelAttributes() {
    if (this.elements.label) {
      this.options.mandatory ? this.elements.label.classList.add('mandatory') : this.elements.label.classList.remove('mandatory');
      this.options.testId === '' ? this.elements.label.removeAttribute('data-testid') : this.elements.label.setAttribute('data-testid', this.options.testId.concat('Label'));
    }
  }
  _inputAttributes() {
    if (this.elements.input) {
      this.options.testId === '' ? this.elements.input.removeAttribute('data-testid') : this.elements.input.setAttribute('data-testid', this.options.testId.concat('Input'));
    }
  }
  _setAttributes() {
    this._labelAttributes();
    this._inputAttributes();
  }
  _bindLabel() {
    if (this.elements.label) {
      this.elements.label.setAttribute('for', `${this.elements.input.id}`);
    }
  }
  _setInputMode() {
    if (this.options.useMask) {
      this.elements.input.setAttribute('type', 'tel');
      this.elements.input.setAttribute('maxlength', 5);
      this.elements.input.setAttribute('inputmode', 'numeric');
      this.elements.input.setAttribute('pattern', '\d*');
      this.elements.input.setAttribute('title', '');
      this.elements.input.setAttribute('placeholder', 'MM/YY');
      this.elements.input.addEventListener('keydown', this.listeners._keydown);
      this.elements.input.addEventListener('change', this.listeners._change);
    } else {
      this.elements.input.setAttribute('type', 'month');
    }
    if (this.options.ccType) {
      this.elements.input.setAttribute('autocomplete', 'cc-exp');
    }
  }
  _convertMaskedDate() {
    let dt = new Date(),
      value = this.elements.input.value;
    if (value.length === 5) {
      dt.setYear(dt.getFullYear().toString().substring(0, 2).concat(value.substring(3)));
      dt.setMonth(value.substring(0, 2) - 1);
    } else {
      dt = null;
    }
    return dt;
  }
  _setDate() {
    if (this.options.date !== this.osNullDate) {
      let dt = new Date(this.options.date),
        month = dt.getMonth() + 1;
      month = month < 10 ? "0" + month : month;
      if (this.options.useMask) {
        this.elements.input.value = month + '/' + dt.getFullYear().toString().substring(2);
      } else {
        this.elements.input.value = dt.getFullYear() + '-' + month;
      }
    } else {
      if (this.options.useMask && this.elements.input.value.length === 5) {
        this.elements.input.value = '';
      }
    }
  }
  _build() {
    this._setInputMode();
    this._bindLabel();
    this._setAttributes();
    this._setDate();
  }
  getDate() {
    let dt = !this.options.useMask ? new Date(this.elements.input.value) : this._convertMaskedDate();
    if (dt) {
      return JSON.stringify({
        date: dt,
        month: dt.getMonth() + 1,
        year: dt.getFullYear()
      });
    } else {
      return '';
    }
  }
  parametersChanged(options) {
    this.options = options;
    this._setAttributes();
    this._setDate();
  }
}