define("ShopperPortalEU.Common.CountryDropdown.mvc$model", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.controller", "ShopperPortalEU.model$CountriesWithFlagsDropdownListList", "ShopperPortalEU.model$CountriesWithFlagsDropdownListRec", "ShopperPortalEU_UI_Components.model$CustomDropdownListValidationOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$CustomDropdownOptionsRec", "ShopperPortalEU_UI_Components.model$CustomDropdownCustomOptionRec", "ShopperPortalEU_UI_Components.model$CustomDropdownSearchOptionsRec", "ShopperPortalEU_UI_Components.model$CustomDropdownNullOptionRec", "ShopperPortalEU_UI_Components.model$CustomDropdownValidationOptionsRec", "ShopperPortalEU_UI_Components.model$CustomDropdownCustomValueOptionRec", "ShopperPortalEU.model$CustomDropdownCustomValueOptionList", "ShopperPortalEU_UI_Components.model$CustomDropdownListOptionsRec", "ShopperPortalEU_UI_Components.model$CustomDropdownListSearchOptionsRec", "ShopperPortalEU_UI_Components.model$CustomDropdownListSelectedItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomFlagOptionsRec", "ShopperPortalEU_UI_Components.model$CustomDropdownListItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomDropdownListValueOptionsRec", "ShopperPortalEU_UI_Components.model$GetOSRec", "ShopperPortalEU_UI_Components.controller$GetOS"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ComponentsController) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("Countries", "countriesVar", "Countries", true, false, OS.DataTypes.DataTypes.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEUModel.CountriesWithFlagsDropdownListList());
}, false, ShopperPortalEUModel.CountriesWithFlagsDropdownListList), 
this.attr("SelectedCountry", "selectedCountryVar", "SelectedCountry", true, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEUModel.CountriesWithFlagsDropdownListRec());
}, false, ShopperPortalEUModel.CountriesWithFlagsDropdownListRec), 
this.attr("OS", "oSVar", "OS", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, false), 
this.attr("Selected", "selectedIn", "Selected", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, false), 
this.attr("_selectedInDataFetchStatus", "_selectedInDataFetchStatus", "_selectedInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("List", "listIn", "List", true, false, OS.DataTypes.DataTypes.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEUModel.CountriesWithFlagsDropdownListList());
}, false, ShopperPortalEUModel.CountriesWithFlagsDropdownListList), 
this.attr("_listInDataFetchStatus", "_listInDataFetchStatus", "_listInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("OpenedLabel", "openedLabelIn", "OpenedLabel", true, false, OS.DataTypes.DataTypes.Text, function () {
return "Select";
}, false), 
this.attr("_openedLabelInDataFetchStatus", "_openedLabelInDataFetchStatus", "_openedLabelInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("OpenDescription", "openDescriptionIn", "OpenDescription", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, false), 
this.attr("_openDescriptionInDataFetchStatus", "_openDescriptionInDataFetchStatus", "_openDescriptionInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("HasNullValue", "hasNullValueIn", "HasNullValue", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("_hasNullValueInDataFetchStatus", "_hasNullValueInDataFetchStatus", "_hasNullValueInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("NullValue", "nullValueIn", "NullValue", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, false), 
this.attr("_nullValueInDataFetchStatus", "_nullValueInDataFetchStatus", "_nullValueInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("TestId", "testIdIn", "TestId", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, false), 
this.attr("_testIdInDataFetchStatus", "_testIdInDataFetchStatus", "_testIdInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("Validation", "validationIn", "Validation", true, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValidationOptionsRec());
}, false, ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValidationOptionsRec), 
this.attr("_validationInDataFetchStatus", "_validationInDataFetchStatus", "_validationInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("IsMandatory", "isMandatoryIn", "IsMandatory", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("_isMandatoryInDataFetchStatus", "_isMandatoryInDataFetchStatus", "_isMandatoryInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("NativeLabel", "nativeLabelIn", "NativeLabel", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, false), 
this.attr("_nativeLabelInDataFetchStatus", "_nativeLabelInDataFetchStatus", "_nativeLabelInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {
Dropdown_Country: OS.Model.ValidationWidgetRecord
};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return true;
}
});

Model.prototype.setInputs = function (inputs) {
if("Selected" in inputs) {
this.variables.selectedIn = inputs.Selected;
if("_selectedInDataFetchStatus" in inputs) {
this.variables._selectedInDataFetchStatus = inputs._selectedInDataFetchStatus;
}

}

if("List" in inputs) {
this.variables.listIn = inputs.List;
if("_listInDataFetchStatus" in inputs) {
this.variables._listInDataFetchStatus = inputs._listInDataFetchStatus;
}

}

if("OpenedLabel" in inputs) {
this.variables.openedLabelIn = inputs.OpenedLabel;
if("_openedLabelInDataFetchStatus" in inputs) {
this.variables._openedLabelInDataFetchStatus = inputs._openedLabelInDataFetchStatus;
}

}

if("OpenDescription" in inputs) {
this.variables.openDescriptionIn = inputs.OpenDescription;
if("_openDescriptionInDataFetchStatus" in inputs) {
this.variables._openDescriptionInDataFetchStatus = inputs._openDescriptionInDataFetchStatus;
}

}

if("HasNullValue" in inputs) {
this.variables.hasNullValueIn = inputs.HasNullValue;
if("_hasNullValueInDataFetchStatus" in inputs) {
this.variables._hasNullValueInDataFetchStatus = inputs._hasNullValueInDataFetchStatus;
}

}

if("NullValue" in inputs) {
this.variables.nullValueIn = inputs.NullValue;
if("_nullValueInDataFetchStatus" in inputs) {
this.variables._nullValueInDataFetchStatus = inputs._nullValueInDataFetchStatus;
}

}

if("TestId" in inputs) {
this.variables.testIdIn = inputs.TestId;
if("_testIdInDataFetchStatus" in inputs) {
this.variables._testIdInDataFetchStatus = inputs._testIdInDataFetchStatus;
}

}

if("Validation" in inputs) {
this.variables.validationIn = inputs.Validation;
if("_validationInDataFetchStatus" in inputs) {
this.variables._validationInDataFetchStatus = inputs._validationInDataFetchStatus;
}

}

if("IsMandatory" in inputs) {
this.variables.isMandatoryIn = inputs.IsMandatory;
if("_isMandatoryInDataFetchStatus" in inputs) {
this.variables._isMandatoryInDataFetchStatus = inputs._isMandatoryInDataFetchStatus;
}

}

if("NativeLabel" in inputs) {
this.variables.nativeLabelIn = inputs.NativeLabel;
if("_nativeLabelInDataFetchStatus" in inputs) {
this.variables._nativeLabelInDataFetchStatus = inputs._nativeLabelInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "Common.CountryDropdown");
});
define("ShopperPortalEU.Common.CountryDropdown.mvc$view", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.controller", "react", "OutSystems/ReactView/Main", "ShopperPortalEU.Common.CountryDropdown.mvc$model", "ShopperPortalEU.Common.CountryDropdown.mvc$controller", "ShopperPortalEU.clientVariables", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomDropdown.mvc$view", "OutSystems/ReactWidgets/Main", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomDropdownList.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomDropdownListSelectedItem.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomFlag.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomDropdownListItem.mvc$view", "ShopperPortalEU.model$CountriesWithFlagsDropdownListList", "ShopperPortalEU.model$CountriesWithFlagsDropdownListRec", "ShopperPortalEU_UI_Components.model$CustomDropdownListValidationOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$CustomDropdownOptionsRec", "ShopperPortalEU_UI_Components.model$CustomDropdownCustomOptionRec", "ShopperPortalEU_UI_Components.model$CustomDropdownSearchOptionsRec", "ShopperPortalEU_UI_Components.model$CustomDropdownNullOptionRec", "ShopperPortalEU_UI_Components.model$CustomDropdownValidationOptionsRec", "ShopperPortalEU_UI_Components.model$CustomDropdownCustomValueOptionRec", "ShopperPortalEU.model$CustomDropdownCustomValueOptionList", "ShopperPortalEU_UI_Components.model$CustomDropdownListOptionsRec", "ShopperPortalEU_UI_Components.model$CustomDropdownListSearchOptionsRec", "ShopperPortalEU_UI_Components.model$CustomDropdownListSelectedItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomFlagOptionsRec", "ShopperPortalEU_UI_Components.model$CustomDropdownListItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomDropdownListValueOptionsRec", "ShopperPortalEU_UI_Components.model$GetOSRec", "ShopperPortalEU_UI_Components.controller$GetOS"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ComponentsController, React, OSView, ShopperPortalEU_Common_CountryDropdown_mvc_model, ShopperPortalEU_Common_CountryDropdown_mvc_controller, ShopperPortalEUClientVariables, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomDropdown_mvc_view, OSWidgets, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomDropdownList_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomDropdownListSelectedItem_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomFlag_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomDropdownListItem_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            var thisIsInstanceOfSuper = this instanceof _super;
            if (thisIsInstanceOfSuper == false) {
                return;
            }

            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "Common.CountryDropdown";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomDropdown_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomDropdownList_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomDropdownListSelectedItem_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomFlag_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomDropdownListItem_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return ShopperPortalEU_Common_CountryDropdown_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return ShopperPortalEU_Common_CountryDropdown_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), $if(((model.variables.oSVar === "ios") && false), false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomDropdown_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("VfLh2fW0f0adtoxF298Azw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomDropdownOptionsRec();
rec.testIdAttr = model.variables.testIdIn;
rec.isNativeAttr = true;
rec.nullAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomDropdownNullOptionRec();
rec.textAttr = "Select";
return rec;
}();
rec.validationAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomDropdownValidationOptionsRec();
rec.stateAttr = model.variables.validationIn.stateAttr;
rec.messageAttr = model.variables.validationIn.messageAttr;
return rec;
}();
return rec;
}();
}, function () {
return model.variables.testIdIn;
}, function () {
return model.variables.validationIn.stateAttr;
}, function () {
return model.variables.validationIn.messageAttr;
}),
_optionsInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._testIdInDataFetchStatus, model.variables._validationInDataFetchStatus)
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "0",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
label: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
mandatory: model.variables.isMandatoryIn,
targetWidget: "Dropdown_Country",
_idProps: {
service: idService,
uuid: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
mandatory_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._isMandatoryInDataFetchStatus)
}, React.createElement(OSWidgets.Expression, {
value: model.variables.nativeLabelIn,
_idProps: {
service: idService,
uuid: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._nativeLabelInDataFetchStatus)
}))];
}),
dropdown: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Dropdown, {
_validationProps: {
validationService: validationService
},
dropdownMode: /*Text*/ 0,
enabled: true,
gridProperties: {
classes: "OSFillParent"
},
labels: function (elem) {
return elem.nameAttr;
},
list: model.variables.countriesVar,
mandatory: model.variables.isMandatoryIn,
onChange: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common/CountryDropdown/Dropdown_Country OnChange");
return controller.dropdown_CountryOnChange$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
style: "dropdown",
values: function (elem) {
return elem.valueAttr;
},
variable: model.createVariable(OS.DataTypes.DataTypes.Text, model.variables.selectedCountryVar.valueAttr, function (value) {
model.variables.selectedCountryVar.valueAttr = value;
}),
_idProps: {
service: idService,
name: "Dropdown_Country"
},
_widgetRecordProvider: widgetsRecordProvider,
mandatory_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._isMandatoryInDataFetchStatus),
placeholders: {
content: PlaceholderContent.Empty
},
_dependencies: []
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.countriesVar), asPrimitiveValue(model.variables.selectedCountryVar.valueAttr), asPrimitiveValue(model.variables.nativeLabelIn), asPrimitiveValue(model.variables._nativeLabelInDataFetchStatus), asPrimitiveValue(model.variables._isMandatoryInDataFetchStatus), asPrimitiveValue(model.variables.isMandatoryIn)]
})];
}, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomDropdownList_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("C2M28YRvJESlX28XwHrQLA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomDropdownListOptionsRec();
rec.testIdAttr = model.variables.testIdIn;
rec.selectedAttr = model.variables.selectedIn;
rec.nullValueAttr = model.variables.nullValueIn;
rec.labelAttr = model.variables.openedLabelIn;
rec.descriptionAttr = model.variables.openDescriptionIn;
rec.isMandatoryAttr = model.variables.isMandatoryIn;
rec.validationAttr = model.variables.validationIn;
return rec;
}();
}, function () {
return model.variables.testIdIn;
}, function () {
return model.variables.selectedIn;
}, function () {
return model.variables.nullValueIn;
}, function () {
return model.variables.openedLabelIn;
}, function () {
return model.variables.openDescriptionIn;
}, function () {
return model.variables.isMandatoryIn;
}, function () {
return model.variables.validationIn;
}),
_optionsInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._testIdInDataFetchStatus, model.variables._selectedInDataFetchStatus, model.variables._nullValueInDataFetchStatus, model.variables._openedLabelInDataFetchStatus, model.variables._openDescriptionInDataFetchStatus, model.variables._isMandatoryInDataFetchStatus, model.variables._validationInDataFetchStatus)
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onChange$Action: function (currentValueIn) {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ShopperPortalEUUIComponents/CustomDropdownList OnChange");
return controller.customDropdownListOnChange$Action(currentValueIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "4",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
label: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Placeholder, {
align: /*Default*/ 0,
content: _this.props.placeholders.label,
style: "ph",
_idProps: {
service: idService,
name: "Label"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
selected: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomDropdownListSelectedItem_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("ksrF2RCgpUiV+pavaEObww.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomDropdownListSelectedItemOptionsRec();
rec.isPlaceholderAttr = (model.variables.selectedIn === model.variables.nullValueIn);
return rec;
}();
}, function () {
return model.variables.selectedIn;
}, function () {
return model.variables.nullValueIn;
}),
_optionsInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._selectedInDataFetchStatus, model.variables._nullValueInDataFetchStatus)
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "6",
alias: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
left: new PlaceholderContent(function () {
return [$if(((model.variables.selectedIn) !== (model.variables.nullValueIn)), false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomFlag_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("xjhJOCu_10GW_17wnU_HvA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomFlagOptionsRec();
rec.flagAttr = model.variables.selectedCountryVar.flagAttr;
return rec;
}();
}, function () {
return model.variables.selectedCountryVar.flagAttr;
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "7",
alias: "4"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}, function () {
return [];
})];
}),
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: model.variables.selectedCountryVar.nameAttr,
_idProps: {
service: idService,
uuid: "8"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
right: PlaceholderContent.Empty
},
_dependencies: [asPrimitiveValue(model.variables.selectedCountryVar.nameAttr), asPrimitiveValue(model.variables.selectedCountryVar.flagAttr), asPrimitiveValue(model.variables._nullValueInDataFetchStatus), asPrimitiveValue(model.variables._selectedInDataFetchStatus), asPrimitiveValue(model.variables.nullValueIn), asPrimitiveValue(model.variables.selectedIn)]
})];
}),
list: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.List, {
animateItems: false,
extendedProperties: {
"disable-virtualization": "True"
},
gridProperties: {
classes: "OSFillParent"
},
mode: /*Default*/ 0,
source: model.variables.countriesVar,
style: "list list-group",
tag: "div",
_idProps: {
service: idService,
uuid: "9"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new IteratorPlaceholderContent(function (idService, callContext) {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomDropdownListItem_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("hU3CK3U+V0aV8MIfTdjDOA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomDropdownListItemOptionsRec();
rec.isPlaceholderAttr = ((model.variables.hasNullValueIn) ? ((model.variables.countriesVar.getCurrentRowNumber(callContext.iterationContext) === 0)) : (false));
rec.valueAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValueOptionsRec();
rec.textAttr = model.variables.countriesVar.getCurrent(callContext.iterationContext).nameAttr;
rec.valueAttr = model.variables.countriesVar.getCurrent(callContext.iterationContext).valueAttr;
return rec;
}();
return rec;
}();
}, function () {
return model.variables.hasNullValueIn;
}, function () {
return model.variables.countriesVar.getCurrentRowNumber(callContext.iterationContext);
}, function () {
return model.variables.countriesVar.getCurrent(callContext.iterationContext).nameAttr;
}, function () {
return model.variables.countriesVar.getCurrent(callContext.iterationContext).valueAttr;
}),
_optionsInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._hasNullValueInDataFetchStatus)
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "10",
alias: "5"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
left: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomFlag_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("BInlLSW400Ci43ztPZ6Rsw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomFlagOptionsRec();
rec.testIdAttr = ((model.variables.testIdIn + model.variables.countriesVar.getCurrent(callContext.iterationContext).nameAttr) + "Flag");
rec.flagAttr = model.variables.countriesVar.getCurrent(callContext.iterationContext).flagAttr;
return rec;
}();
}, function () {
return model.variables.testIdIn;
}, function () {
return model.variables.countriesVar.getCurrent(callContext.iterationContext).nameAttr;
}, function () {
return model.variables.countriesVar.getCurrent(callContext.iterationContext).flagAttr;
}),
_optionsInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._testIdInDataFetchStatus)
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "11",
alias: "6"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}),
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": (model.variables.testIdIn + model.variables.countriesVar.getCurrent(callContext.iterationContext).nameAttr)
},
value: model.variables.countriesVar.getCurrent(callContext.iterationContext).nameAttr,
_idProps: {
service: idService,
uuid: "12"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
right: PlaceholderContent.Empty,
list: PlaceholderContent.Empty
},
_dependencies: [asPrimitiveValue(model.variables._testIdInDataFetchStatus), asPrimitiveValue(model.variables.countriesVar.getCurrent(callContext.iterationContext).flagAttr), asPrimitiveValue(model.variables.countriesVar.getCurrent(callContext.iterationContext).nameAttr), asPrimitiveValue(model.variables.testIdIn)]
})];
}, callContext, idService, "2")
},
_dependencies: [asPrimitiveValue(model.variables.testIdIn), asPrimitiveValue(model.variables._testIdInDataFetchStatus), asPrimitiveValue(model.variables._hasNullValueInDataFetchStatus), asPrimitiveValue(model.variables.hasNullValueIn)]
})];
})
}
})];
}));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("ShopperPortalEU.Common.CountryDropdown.mvc$controller", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.controller", "ShopperPortalEU.languageResources", "ShopperPortalEU.clientVariables", "ShopperPortalEU.Common.CountryDropdown.mvc$debugger", "ShopperPortalEU.model$CountriesWithFlagsDropdownListList", "ShopperPortalEU.model$CountriesWithFlagsDropdownListRec", "ShopperPortalEU_UI_Components.model$CustomDropdownListValidationOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$CustomDropdownOptionsRec", "ShopperPortalEU_UI_Components.model$CustomDropdownCustomOptionRec", "ShopperPortalEU_UI_Components.model$CustomDropdownSearchOptionsRec", "ShopperPortalEU_UI_Components.model$CustomDropdownNullOptionRec", "ShopperPortalEU_UI_Components.model$CustomDropdownValidationOptionsRec", "ShopperPortalEU_UI_Components.model$CustomDropdownCustomValueOptionRec", "ShopperPortalEU.model$CustomDropdownCustomValueOptionList", "ShopperPortalEU_UI_Components.model$CustomDropdownListOptionsRec", "ShopperPortalEU_UI_Components.model$CustomDropdownListSearchOptionsRec", "ShopperPortalEU_UI_Components.model$CustomDropdownListSelectedItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomFlagOptionsRec", "ShopperPortalEU_UI_Components.model$CustomDropdownListItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomDropdownListValueOptionsRec", "ShopperPortalEU_UI_Components.model$GetOSRec", "ShopperPortalEU_UI_Components.controller$GetOS"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ComponentsController, ShopperPortalEULanguageResources, ShopperPortalEUClientVariables, ShopperPortalEU_Common_CountryDropdown_mvc_Debugger) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = true;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._onInitialize$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnInitialize");
callContext = controller.callContext(callContext);
var getOSVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.getOSVar = getOSVar;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:gzciBIXkbE6yMSvv6CccoQ:/NRWebFlows.B4kRGvrnOEmQonA8ir4Pyg/NodesShownInESpaceTree.4mYWf5mXVka_FLPxGTICPQ/ClientActions.gzciBIXkbE6yMSvv6CccoQ:VHj+RlILsKlsI0o_jMvmeg", "ShopperPortalEU", "OnInitialize", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ZF0cM4w2T0O5yrRZLPC8zA", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:t3v1sIk_30+mYtx9IIhs6A", callContext.id);
// Execute Action: GetOS
getOSVar.value = ShopperPortalEU_UI_ComponentsController.default.getOS$Action(callContext);

OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:acKkiUeVh0WyrkURzeGcbQ", callContext.id);
// OS = GetOS.OS.OS.Name
model.variables.oSVar = getOSVar.value.oSOut.oSAttr.nameAttr;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:tBa0_n7ehkeKKUjWKBtVaQ", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:gzciBIXkbE6yMSvv6CccoQ", callContext.id);
}

};
Controller.prototype._setCountries$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("SetCountries");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:KTOMZbXuy0aiobN0XKNfAg:/NRWebFlows.B4kRGvrnOEmQonA8ir4Pyg/NodesShownInESpaceTree.4mYWf5mXVka_FLPxGTICPQ/ClientActions.KTOMZbXuy0aiobN0XKNfAg:vs99zwZVG8XIOmg22c4uCQ", "ShopperPortalEU", "SetCountries", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:U85rbHyjAkSHmH6rMGJCoQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:qtLerBK51ECtTXjhsntuEA", callContext.id);
// Countries = List
model.variables.countriesVar = model.variables.listIn;
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:1nFF0QEBwEODF1r1GjdQPg", callContext.id) && model.variables.hasNullValueIn)) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:r2E7g5kIkU6jkJDVuHwZCg", callContext.id);
// Execute Action: ListInsert
OS.SystemActions.listInsert(model.variables.countriesVar, function () {
var rec = new ShopperPortalEUModel.CountriesWithFlagsDropdownListRec();
rec.flagAttr = "";
rec.valueAttr = model.variables.nullValueIn;
rec.nameAttr = "Select";
return rec;
}(), 0, callContext);
}

OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:zQs6RsFzVkycXU4oH3YZKA", callContext.id);
// Execute Action: SetSelected
controller._setSelected$Action(callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:LgUHvNNoh0y8uabjDHFWnw", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:KTOMZbXuy0aiobN0XKNfAg", callContext.id);
}

};
Controller.prototype._onReady$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnReady");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:OR8GhyzL9UuAXePV0O63dg:/NRWebFlows.B4kRGvrnOEmQonA8ir4Pyg/NodesShownInESpaceTree.4mYWf5mXVka_FLPxGTICPQ/ClientActions.OR8GhyzL9UuAXePV0O63dg:BvluBFbkxfxVIkau2xPCJQ", "ShopperPortalEU", "OnReady", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ynY2q1lZx0WwOIX39FLdfw", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:qbNe057VWEy0TUAv1QKsCg", callContext.id);
// Execute Action: SetCountries
controller._setCountries$Action(callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:6ZYRs3wciEa1HpYfGYr5IA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:OR8GhyzL9UuAXePV0O63dg", callContext.id);
}

};
Controller.prototype._setSelected$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("SetSelected");
callContext = controller.callContext(callContext);
var listFilterVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.listFilterVar = listFilterVar;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:I5YOms9pCkCuliWkN18tpw:/NRWebFlows.B4kRGvrnOEmQonA8ir4Pyg/NodesShownInESpaceTree.4mYWf5mXVka_FLPxGTICPQ/ClientActions.I5YOms9pCkCuliWkN18tpw:dKcLBXemkfCUOWMb47G1_Q", "ShopperPortalEU", "SetSelected", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:c8zNWq1jdUeoibz_q1XQEw", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:k0neHfMFl0Otny0auodLkw", callContext.id);
// Execute Action: ListFilter
listFilterVar.value = OS.SystemActions.listFilter(model.variables.countriesVar, function (p) {
return (p.valueAttr === model.variables.selectedIn);
}, callContext);

// SelectedCountry
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:PaSFQRUP8k6Y0+5FRhKSWQ", callContext.id);
// SelectedCountry = ListFilter.FilteredList.Current
model.variables.selectedCountryVar = listFilterVar.value.filteredListOut.getCurrent(callContext.iterationContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:PaSFQRUP8k6Y0+5FRhKSWQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// SelectedCountry.Name = If
model.variables.selectedCountryVar.nameAttr = (((model.variables.selectedCountryVar.valueAttr === "")) ? ("Select") : (model.variables.selectedCountryVar.nameAttr));
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:c20FWT304U6GmCYG1pWNDg", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:I5YOms9pCkCuliWkN18tpw", callContext.id);
}

};
Controller.prototype._onParametersChanged$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnParametersChanged");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:yYgqosmRX06ypzlUIGLVxQ:/NRWebFlows.B4kRGvrnOEmQonA8ir4Pyg/NodesShownInESpaceTree.4mYWf5mXVka_FLPxGTICPQ/ClientActions.yYgqosmRX06ypzlUIGLVxQ:cETfQhJg6Upl4+xoAl7CPQ", "ShopperPortalEU", "OnParametersChanged", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:J37Zmq5my0+H2qe6blORww", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:3GvVhJJh+k64OFaDu7Qo8A", callContext.id);
// Execute Action: SetCountries
controller._setCountries$Action(callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:4gWJee6BzkWqPf0e6yT7Yg", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:yYgqosmRX06ypzlUIGLVxQ", callContext.id);
}

};
Controller.prototype._customDropdownListOnChange$Action = function (currentValueIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("CustomDropdownListOnChange");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.Common.CountryDropdown.CustomDropdownListOnChange$vars"))());
vars.value.currentValueInLocal = currentValueIn.clone();
varBag.callContext = callContext;
varBag.vars = vars;
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:qVZFzaZkekSwdYmlwSuI1A:/NRWebFlows.B4kRGvrnOEmQonA8ir4Pyg/NodesShownInESpaceTree.4mYWf5mXVka_FLPxGTICPQ/ClientActions.qVZFzaZkekSwdYmlwSuI1A:VoeT5RoDmNeJSPV40szcYQ", "ShopperPortalEU", "CustomDropdownListOnChange", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Ex_n0EKBo0KzI86Csstsuw", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
// Selected
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:VASNRrPqmkSEI5NIm3iIEA", callContext.id);
// Selected = CurrentValue.Value
model.variables.selectedIn = vars.value.currentValueInLocal.valueAttr;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:g55wEVpJPU6sMs68w_OkXw", callContext.id);
// Execute Action: SetSelected
controller._setSelected$Action(callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:3x+DFj6AlkO6BL0ItRpVoA", callContext.id);
// Trigger Event: OnChange
return controller.onChange$Action(vars.value.currentValueInLocal, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:nQRVx2QfFkGpTSeox2kPpQ", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:qVZFzaZkekSwdYmlwSuI1A", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:qVZFzaZkekSwdYmlwSuI1A", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("ShopperPortalEU.Common.CountryDropdown.CustomDropdownListOnChange$vars", [{
name: "CurrentValue",
attrName: "currentValueInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Record,
defaultValue: function () {
return new ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValueOptionsRec();
},
complexType: ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValueOptionsRec
}]);
Controller.prototype._dropdown_CountryOnChange$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Dropdown_CountryOnChange");
callContext = controller.callContext(callContext);
var listFilterVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.listFilterVar = listFilterVar;
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:Pme++mIT4kqXw8D1vwHcAg:/NRWebFlows.B4kRGvrnOEmQonA8ir4Pyg/NodesShownInESpaceTree.4mYWf5mXVka_FLPxGTICPQ/ClientActions.Pme++mIT4kqXw8D1vwHcAg:q76JPEGfhnPX8kSo_LyeDg", "ShopperPortalEU", "Dropdown_CountryOnChange", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:AvnRWdeOckyeFHRJHVie5A", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:HKKEgAwsFEiqXDaIMpgQVA", callContext.id);
// Execute Action: ListFilter
listFilterVar.value = OS.SystemActions.listFilter(model.variables.countriesVar, function (p) {
return (p.valueAttr === model.variables.selectedCountryVar.valueAttr);
}, callContext);

OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:bucZ7I4kWUi7QwYrKJUj5w", callContext.id);
// Trigger Event: OnChange
return controller.onChange$Action(function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValueOptionsRec();
rec.textAttr = listFilterVar.value.filteredListOut.getCurrent(callContext.iterationContext).nameAttr;
rec.valueAttr = model.variables.selectedCountryVar.valueAttr;
return rec;
}(), callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:4Qs0Dje12UuRWjzidyANsw", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:Pme++mIT4kqXw8D1vwHcAg", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:Pme++mIT4kqXw8D1vwHcAg", callContext.id);
throw ex;

});
};

Controller.prototype.onInitialize$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onInitialize$Action, callContext);

};
Controller.prototype.setCountries$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._setCountries$Action, callContext);

};
Controller.prototype.onReady$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onReady$Action, callContext);

};
Controller.prototype.setSelected$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._setSelected$Action, callContext);

};
Controller.prototype.onParametersChanged$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onParametersChanged$Action, callContext);

};
Controller.prototype.customDropdownListOnChange$Action = function (currentValueIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._customDropdownListOnChange$Action, callContext, currentValueIn);

};
Controller.prototype.dropdown_CountryOnChange$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._dropdown_CountryOnChange$Action, callContext);

};
Controller.prototype.onChange$Action = function () {
return Promise.resolve();
};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:B4kRGvrnOEmQonA8ir4Pyg:/NRWebFlows.B4kRGvrnOEmQonA8ir4Pyg:SzbSE76vSJUYiPdzujZAFw", "ShopperPortalEU", "Common", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:4mYWf5mXVka_FLPxGTICPQ:/NRWebFlows.B4kRGvrnOEmQonA8ir4Pyg/NodesShownInESpaceTree.4mYWf5mXVka_FLPxGTICPQ:04s+Ch42lqDvn5YbWMLh6w", "ShopperPortalEU", "CountryDropdown", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:4mYWf5mXVka_FLPxGTICPQ", callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:B4kRGvrnOEmQonA8ir4Pyg", callContext.id);
};
Controller.prototype.onInitializeEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Common/CountryDropdown On Initialize");
return controller.onInitialize$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onReadyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Common/CountryDropdown On Ready");
return controller.onReady$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Common/CountryDropdown On Parameters Changed");
return controller.onParametersChanged$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return ShopperPortalEUController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, ShopperPortalEULanguageResources);
});

define("ShopperPortalEU.Common.CountryDropdown.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"t3v1sIk_30+mYtx9IIhs6A": {
getter: function (varBag, idService) {
return varBag.getOSVar.value;
}
},
"k0neHfMFl0Otny0auodLkw": {
getter: function (varBag, idService) {
return varBag.listFilterVar.value;
}
},
"xBInGwu_7U6njtMUpMzGEQ": {
getter: function (varBag, idService) {
return varBag.vars.value.currentValueInLocal;
}
},
"HKKEgAwsFEiqXDaIMpgQVA": {
getter: function (varBag, idService) {
return varBag.listFilterVar.value;
}
},
"a+IuUOAFaEeMDWYTqMxWkA": {
getter: function (varBag, idService) {
return varBag.model.variables.countriesVar;
}
},
"LoxW9_+ajk+FOG1YmuHU+w": {
getter: function (varBag, idService) {
return varBag.model.variables.selectedCountryVar;
}
},
"v6aniCEPF0+hCdu5UB_KWQ": {
getter: function (varBag, idService) {
return varBag.model.variables.oSVar;
},
dataType: OS.DataTypes.DataTypes.Text
},
"9t4SzVvPvkSu4osbam_U0Q": {
getter: function (varBag, idService) {
return varBag.model.variables.selectedIn;
},
dataType: OS.DataTypes.DataTypes.Text
},
"GR0MTX_HCUqsFL7TuXMxzQ": {
getter: function (varBag, idService) {
return varBag.model.variables.listIn;
}
},
"3VJvXVC1s0aU6AwROxzqHA": {
getter: function (varBag, idService) {
return varBag.model.variables.openedLabelIn;
},
dataType: OS.DataTypes.DataTypes.Text
},
"WdgY8RXsakG4T8_P2TdQiw": {
getter: function (varBag, idService) {
return varBag.model.variables.openDescriptionIn;
},
dataType: OS.DataTypes.DataTypes.Text
},
"cVYH8PGBG0uVmKHKC6_8Eg": {
getter: function (varBag, idService) {
return varBag.model.variables.hasNullValueIn;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"5a8GvUwFn0+sEeCcKPYmTg": {
getter: function (varBag, idService) {
return varBag.model.variables.nullValueIn;
},
dataType: OS.DataTypes.DataTypes.Text
},
"84FottaUdku6OHy9gyaw7Q": {
getter: function (varBag, idService) {
return varBag.model.variables.testIdIn;
},
dataType: OS.DataTypes.DataTypes.Text
},
"H+X+NElaI0+w3w9w2dWJzQ": {
getter: function (varBag, idService) {
return varBag.model.variables.validationIn;
}
},
"_xHwr0Zbq0e8bFzNv11bDA": {
getter: function (varBag, idService) {
return varBag.model.variables.isMandatoryIn;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"lfLvmg3ymEq5_fe+AeNSiA": {
getter: function (varBag, idService) {
return varBag.model.variables.nativeLabelIn;
},
dataType: OS.DataTypes.DataTypes.Text
},
"jAaUAz2dgUCEySto0M6X_Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Label"));
})(varBag.model, idService);
}
},
"NtU9FiP2cUCjbON2Mp2nxQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Dropdown"));
})(varBag.model, idService);
}
},
"UqJeKEFCiUe7soWGX43Skg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Dropdown_Country"));
})(varBag.model, idService);
}
},
"6GFwmvUcokuJiUnAP09c4w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Label"));
})(varBag.model, idService);
}
},
"6IaInBTzjE2xLpejjhvsNg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Label"));
})(varBag.model, idService);
}
},
"wJW+Qx3xhE69+jaum4KYEw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Selected"));
})(varBag.model, idService);
}
},
"awunT1JuqE+gqSVrpGYLLg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Left"));
})(varBag.model, idService);
}
},
"AD3nLLnL5EWJRxN5MCNt7A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"7fMRcdSgAkasexHKht_suA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Right"));
})(varBag.model, idService);
}
},
"esjBYM78IEykXrxcQexWiQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("List"));
})(varBag.model, idService);
}
},
"9Im0Mef1+kS9iVOa3+UFqw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Left"));
})(varBag.model, idService);
}
},
"e2RV8JzvqUe0B_UcAS7lxQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"zGFp__UwnEqxamq401m8wg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Right"));
})(varBag.model, idService);
}
},
"emGkv6KSEkeVy_gMMZvVpA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("List"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
