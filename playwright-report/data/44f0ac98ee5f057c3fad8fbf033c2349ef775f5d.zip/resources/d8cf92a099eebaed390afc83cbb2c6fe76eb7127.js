define("ShopperPortalEU.Refund.RequestRefund.mvc$model", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.controller", "ShopperPortalEU_Shopper_IS.controller", "ShopperPortalEU.controller$FormatMaskedCard", "ShopperPortalEU_Forms_IS.model$FormInfo_WrapperRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Forms_IS", "ShopperPortalEU.model$FormInfo_WrapperList", "ShopperPortalEU.model$RefundSummaryList", "ShopperPortalEU.model$RequestRefundCardList", "ShopperPortalEU_Shopper_IS.model$DatatransTokenFallbackRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS", "ShopperPortalEU_UI_Components.model$DatatransCardChangeOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Theme.model$LayoutDetailOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU_UI_Components.model$FullHeightContentOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentTopOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentBottomOptionsRec", "ShopperPortalEU_Forms_IS.model$RefundDetails_WrapperRec", "ShopperPortalEU_Forms_IS.model$FormDetails_WrapperRec", "ShopperPortalEU_Forms_IS.model$UIConfigurationRec", "ShopperPortalEU_Forms_IS.model$RefundDetailsPaymentDetails_UIRec", "ShopperPortalEU_UI_Components.model$CustomCheckboxOptionsRec", "ShopperPortalEU_UI_Components.model$CustomCardOptionsRec", "ShopperPortalEU_UI_Components.model$FlexOptionsRec", "ShopperPortalEU_UI_Components.model$CustomIconOptionsRec", "ShopperPortalEU_UI_Components.model$CustomRadioGroupOptionsRec", "ShopperPortalEU_UI_Components.model$CustomRadioButtonOptionsRec", "ShopperPortalEU_UI_Components.model$CustomImageOptionsRec", "ShopperPortalEU_UI_Components.model$CustomTagOptionsRec", "ShopperPortalEU_UI_Components.model$CustomBottomBarOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsIconRec", "ShopperPortalEU_UI_Components.model$CustomSeparatorOptionsRec", "ShopperPortalEU_UI_Components.model$CustomSeparatorLabelOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconRec", "ShopperPortalEU_UI_Components.model$CustomPopupLayoutOptionsRec", "ShopperPortalEU_UI_Components.model$CustomPopupLayoutHeaderImageOptionsRec", "ShopperPortalEU.controller$ClarityEvent", "ShopperPortalEU.controller$GetFormsRefundList", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", "ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger", "ShopperPortalEU_Shopper_IS.model$GetCardsResponseRec", "ShopperPortalEU.model$GetCardsResponseList", "ShopperPortalEU_Shopper_IS.controller$GetCards", "ShopperPortalEU.controller$DefaultErrorMessage", "ShopperPortalEU.model$RequestRefundCardRec", "ShopperPortalEU.controller$CheckValidCard"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_Forms_ISModel, ShopperPortalEU_Shopper_ISModel, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ThemeController, ShopperPortalEU_Shopper_ISController) {
var OS = OutSystems.Internal;

var CancelDataActRec = (function (_super) {
__extends(CancelDataActRec, _super);
function CancelDataActRec(defaults) {
_super.apply(this, arguments);
}
CancelDataActRec.attributesToDeclare = function () {
return [
this.attr("MerchantId", "merchantIdOut", "MerchantId", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CancelDataActRec.fromStructure = function (str) {
return new CancelDataActRec(new CancelDataActRec.RecordClass({
merchantIdOut: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CancelDataActRec.init();
return CancelDataActRec;
})(OS.Model.DataSourceRecord);

var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("FormsList_ReadyForRefund", "formsList_ReadyForRefundVar", "FormsList_ReadyForRefund", true, false, OS.DataTypes.DataTypes.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEUModel.FormInfo_WrapperList());
}, false, ShopperPortalEUModel.FormInfo_WrapperList), 
this.attr("RefundSummaryFormList", "refundSummaryFormListVar", "RefundSummaryFormList", true, false, OS.DataTypes.DataTypes.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEUModel.RefundSummaryList());
}, false, ShopperPortalEUModel.RefundSummaryList), 
this.attr("CardList", "cardListVar", "CardList", true, false, OS.DataTypes.DataTypes.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEUModel.RequestRefundCardList());
}, false, ShopperPortalEUModel.RequestRefundCardList), 
this.attr("DatatransTokenFallback", "datatransTokenFallbackVar", "DatatransTokenFallback", true, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Shopper_ISModel.DatatransTokenFallbackRec());
}, false, ShopperPortalEU_Shopper_ISModel.DatatransTokenFallbackRec), 
this.attr("CardDetailsData", "cardDetailsDataVar", "CardDetailsData", true, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.DatatransCardChangeOptionsRec());
}, false, ShopperPortalEU_UI_ComponentsModel.DatatransCardChangeOptionsRec), 
this.attr("IsToSubmitCard", "isToSubmitCardVar", "IsToSubmitCard", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("IsCardSubmitting", "isCardSubmittingVar", "IsCardSubmitting", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("IsToSaveNewCard", "isToSaveNewCardVar", "IsToSaveNewCard", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("CardErrorMessage", "cardErrorMessageVar", "CardErrorMessage", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, false), 
this.attr("IsExpiryDateError", "isExpiryDateErrorVar", "IsExpiryDateError", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("IsScreenReady", "isScreenReadyVar", "IsScreenReady", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("SelectedCard", "selectedCardVar", "SelectedCard", true, false, OS.DataTypes.DataTypes.Text, function () {
return "0";
}, false), 
this.attr("ShowConfirmationPopup", "showConfirmationPopupVar", "ShowConfirmationPopup", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("PurchaseConfirmationCheck", "purchaseConfirmationCheckVar", "PurchaseConfirmationCheck", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("Cancel", "cancelDataAct", "cancelDataAct", true, true, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new CancelDataActRec());
}, true, CancelDataActRec)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {
Checkbox_IsSaveCard2: OS.Model.ValidationWidgetRecord,
Checkbox_IsSaveCard: OS.Model.ValidationWidgetRecord,
PurchaseConfirmationCheckbox: OS.Model.ValidationWidgetRecord
};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return true;
}
});

Model.prototype.setInputs = function (inputs) {
};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "Refund.RequestRefund");
});
define("ShopperPortalEU.Refund.RequestRefund.mvc$view", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.controller", "ShopperPortalEU_Shopper_IS.controller", "react", "OutSystems/ReactView/Main", "ShopperPortalEU.Refund.RequestRefund.mvc$model", "ShopperPortalEU.Refund.RequestRefund.mvc$controller", "ShopperPortalEU.clientVariables", "ShopperPortalEU.Layouts.LayoutDetail.mvc$view", "OutSystems/ReactWidgets/Main", "ShopperPortalEU.LayoutsComponents.Back.mvc$view", "ShopperPortalEU.Common.Secure.mvc$view", "ShopperPortalEU.Common.DataLoading.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.FullHeightContent.mvc$view", "ShopperPortalEU.InternalComponents.DatatransTokenization_WB.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCheckbox.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCard.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.Flex.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomIcon.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomRadioGroup.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomRadioGroupItem.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomImage.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomTag.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomBottomBar.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomLink.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomLinkItem.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomSeparator.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomButton.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomButtonItem.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomPopup.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomPopupLayout.mvc$view", "ShopperPortalEU.controller$FormatMaskedCard", "ShopperPortalEU_Forms_IS.model$FormInfo_WrapperRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Forms_IS", "ShopperPortalEU.model$FormInfo_WrapperList", "ShopperPortalEU.model$RefundSummaryList", "ShopperPortalEU.model$RequestRefundCardList", "ShopperPortalEU_Shopper_IS.model$DatatransTokenFallbackRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS", "ShopperPortalEU_UI_Components.model$DatatransCardChangeOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Theme.model$LayoutDetailOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU_UI_Components.model$FullHeightContentOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentTopOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentBottomOptionsRec", "ShopperPortalEU_Forms_IS.model$RefundDetails_WrapperRec", "ShopperPortalEU_Forms_IS.model$FormDetails_WrapperRec", "ShopperPortalEU_Forms_IS.model$UIConfigurationRec", "ShopperPortalEU_Forms_IS.model$RefundDetailsPaymentDetails_UIRec", "ShopperPortalEU_UI_Components.model$CustomCheckboxOptionsRec", "ShopperPortalEU_UI_Components.model$CustomCardOptionsRec", "ShopperPortalEU_UI_Components.model$FlexOptionsRec", "ShopperPortalEU_UI_Components.model$CustomIconOptionsRec", "ShopperPortalEU_UI_Components.model$CustomRadioGroupOptionsRec", "ShopperPortalEU_UI_Components.model$CustomRadioButtonOptionsRec", "ShopperPortalEU_UI_Components.model$CustomImageOptionsRec", "ShopperPortalEU_UI_Components.model$CustomTagOptionsRec", "ShopperPortalEU_UI_Components.model$CustomBottomBarOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsIconRec", "ShopperPortalEU_UI_Components.model$CustomSeparatorOptionsRec", "ShopperPortalEU_UI_Components.model$CustomSeparatorLabelOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconRec", "ShopperPortalEU_UI_Components.model$CustomPopupLayoutOptionsRec", "ShopperPortalEU_UI_Components.model$CustomPopupLayoutHeaderImageOptionsRec", "ShopperPortalEU.controller$ClarityEvent", "ShopperPortalEU.controller$GetFormsRefundList", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", "ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger", "ShopperPortalEU_Shopper_IS.model$GetCardsResponseRec", "ShopperPortalEU.model$GetCardsResponseList", "ShopperPortalEU_Shopper_IS.controller$GetCards", "ShopperPortalEU.controller$DefaultErrorMessage", "ShopperPortalEU.model$RequestRefundCardRec", "ShopperPortalEU.controller$CheckValidCard"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_Forms_ISModel, ShopperPortalEU_Shopper_ISModel, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ThemeController, ShopperPortalEU_Shopper_ISController, React, OSView, ShopperPortalEU_Refund_RequestRefund_mvc_model, ShopperPortalEU_Refund_RequestRefund_mvc_controller, ShopperPortalEUClientVariables, ShopperPortalEU_Layouts_LayoutDetail_mvc_view, OSWidgets, ShopperPortalEU_LayoutsComponents_Back_mvc_view, ShopperPortalEU_Common_Secure_mvc_view, ShopperPortalEU_Common_DataLoading_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvc_view, ShopperPortalEU_InternalComponents_DatatransTokenization_WB_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCheckbox_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCard_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomIcon_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomRadioGroup_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomRadioGroupItem_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomImage_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomTag_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomBottomBar_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLink_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLinkItem_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomSeparator_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomPopup_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomPopupLayout_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            var thisIsInstanceOfSuper = this instanceof _super;
            if (thisIsInstanceOfSuper == false) {
                return;
            }

            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "Refund.RequestRefund";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css", "css/ShopperPortalEU_UI_Theme.ShopperPortalEUUITheme.css", "css/ShopperPortalEU.ShopperPortalEU.css", "css/ShopperPortalEU_UI_Theme.ShopperPortalEUUITheme.extra.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [ShopperPortalEU_Layouts_LayoutDetail_mvc_view, ShopperPortalEU_LayoutsComponents_Back_mvc_view, ShopperPortalEU_Common_Secure_mvc_view, ShopperPortalEU_Common_DataLoading_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvc_view, ShopperPortalEU_InternalComponents_DatatransTokenization_WB_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCheckbox_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCard_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomIcon_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomRadioGroup_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomRadioGroupItem_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomImage_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomTag_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomBottomBar_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLink_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLinkItem_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomSeparator_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomPopup_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomPopupLayout_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return ShopperPortalEU_Refund_RequestRefund_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return ShopperPortalEU_Refund_RequestRefund_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "Shopper Portal EU - Request Refund";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(ShopperPortalEU_Layouts_LayoutDetail_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
afterAuthentication$Action: function (isAuthenticatedIn) {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Layouts/LayoutDetail AfterAuthentication");
return controller.onAfterAuthentication$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "0",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
headerLeft: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_LayoutsComponents_Back_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "1",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}),
headerCenter: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "RequestRefund"
},
value: model.getCachedValue(idService.getId("dIXJ6tGLmkGKsI_oWldfWg.Value"), function () {
return ((false) ? ("Add card for refund") : ("Request refund"));
}),
_idProps: {
service: idService,
uuid: "2"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
headerRight: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_Common_Secure_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "3",
alias: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}),
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_Common_DataLoading_mvc_view, {
inputs: {
IsDataFetched: model.variables.isScreenReadyVar
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "4",
alias: "4"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [$if(model.variables.cardListVar.isEmpty, false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "5",
alias: "5"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
top: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_InternalComponents_DatatransTokenization_WB_mvc_view, {
inputs: {
MerchantId: model.variables.cancelDataAct.merchantIdOut,
_merchantIdInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.cancelDataAct.dataFetchStatusAttr),
IsToSaveNewCard: model.variables.isToSaveNewCardVar,
IsToSubmitCard: model.variables.isToSubmitCardVar,
IsFromFormDetailsScreen: ShopperPortalEUClientVariables.getIsFromFormDetailsOrStepScreen(),
FormsList_ReadyForRefund: model.variables.formsList_ReadyForRefundVar,
IsExpiryDateError: model.variables.isExpiryDateErrorVar,
CardDetailsData: model.variables.cardDetailsDataVar,
CardErrorMessage: model.variables.cardErrorMessageVar,
Card: model.variables.selectedCardVar,
TokenFallback: model.variables.datatransTokenFallbackVar
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
cardSubmitted$Action: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "InternalComponents/DatatransTokenization_WB CardSubmitted");
controller.onCardSubmitted$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
errorSavingCard$Action: function (errorMessageIn, isCreateCardGenericErrorIn) {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "InternalComponents/DatatransTokenization_WB ErrorSavingCard");
controller.onErrorSavingCard$Action(errorMessageIn, isCreateCardGenericErrorIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
errorRequestingRefund$Action: function (errorMessageIn) {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "InternalComponents/DatatransTokenization_WB ErrorRequestingRefund");
controller.onError$Action(errorMessageIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
updateParameters$Action: function (cardDetailsDataIn, cardErrorMessageIn, isExpiryDateErrorIn) {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "InternalComponents/DatatransTokenization_WB UpdateParameters");
controller.onParametersChanged$Action(cardDetailsDataIn, cardErrorMessageIn, isExpiryDateErrorIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "6",
alias: "6"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-top-04",
visible: true,
_idProps: {
service: idService,
uuid: "7"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCheckbox_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("mxIjf0RYNEKT7BL2bL6Tfw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomCheckboxOptionsRec();
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "8",
alias: "7"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
checkbox: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Checkbox, {
_validationProps: {
validationService: validationService
},
enabled: true,
extendedProperties: {
"data-testid": "Checkbox_IsSaveCard"
},
onChange: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Refund/RequestRefund/Checkbox_IsSaveCard2 OnChange");
controller.checkbox_IsSaveCardOnChange$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "checkbox",
variable: model.createVariable(OS.DataTypes.DataTypes.Boolean, model.variables.isToSaveNewCardVar, function (value) {
model.variables.isToSaveNewCardVar = value;
}),
_idProps: {
service: idService,
name: "Checkbox_IsSaveCard2"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
label: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Label, {
extendedProperties: {
"data-testid": "CheckboxDefault_Label"
},
gridProperties: {
classes: "OSFillParent"
},
targetWidget: "Checkbox_IsSaveCard2",
_idProps: {
service: idService,
uuid: "10"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "SaveCard"
},
value: "Save card for future refunds",
_idProps: {
service: idService,
uuid: "11"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables.isToSaveNewCardVar)]
}))];
}),
bottom: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCard_mvc_view, {
inputs: {
ExtendedClass: "margin-top-04",
Options: model.getCachedValue(idService.getId("bmpwdus_WU2mfJ5AmSlrdg.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomCardOptionsRec();
rec.isSharperAttr = true;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "12",
alias: "8"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("EXFk4pcG_0msa_Zd+ySAew.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.alignAttr = ShopperPortalEUModel.staticEntities.flexAlign.center;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
rec.wrapAttr = false;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "13",
alias: "9"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomIcon_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("elGKFSmsBUqiqbgwoV+D5w.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomIconOptionsRec();
rec.nameAttr = "currency_exchange";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "14",
alias: "10"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}), React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "refundInfo"
},
style: "body-4 text-primary-35",
value: "Your refund will be paid in your card\'s currency.",
_idProps: {
service: idService,
uuid: "15"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
})];
})
},
_dependencies: []
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.datatransTokenFallbackVar), asPrimitiveValue(model.variables.selectedCardVar), asPrimitiveValue(model.variables.cardErrorMessageVar), asPrimitiveValue(model.variables.cardDetailsDataVar), asPrimitiveValue(model.variables.isExpiryDateErrorVar), asPrimitiveValue(model.variables.formsList_ReadyForRefundVar), asPrimitiveValue(ShopperPortalEUClientVariables.getIsFromFormDetailsOrStepScreen()), asPrimitiveValue(model.variables.isToSubmitCardVar), asPrimitiveValue(model.variables.isToSaveNewCardVar), asPrimitiveValue(model.variables.cancelDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.cancelDataAct.merchantIdOut)]
})];
}, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "16",
alias: "11"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
top: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
style: "heading6 text-primary-35",
value: "Your cards",
_idProps: {
service: idService,
uuid: "17"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomRadioGroup_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("Tc_14ZUuIEi9pPKJgyPisw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomRadioGroupOptionsRec();
rec.testIdAttr = "CardRadioButton";
rec.valueAttr = model.variables.selectedCardVar;
return rec;
}();
}, function () {
return model.variables.selectedCardVar;
}),
ExtendedClass: "margin-top-02"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onChange$Action: function (currentValueIn) {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ShopperPortalEUUIComponents/CustomRadioGroup OnChange");
controller.cardListOnChange$Action(currentValueIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "18",
alias: "12"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
customRadioButton: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.List, {
animateItems: false,
extendedProperties: {
"disable-virtualization": "True"
},
gridProperties: {
classes: "OSFillParent"
},
mode: /*Default*/ 0,
source: model.variables.cardListVar,
style: "list list-group",
tag: "div",
_idProps: {
service: idService,
uuid: "19"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new IteratorPlaceholderContent(function (idService, callContext) {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomRadioGroupItem_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("Qtgg+lBz_UKt5TonfmRfgA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomRadioButtonOptionsRec();
rec.testIdAttr = ((model.variables.cardListVar.getCurrent(callContext.iterationContext).isSeparatedAttr) ? ("CustomRadioGroupItem_AddCard") : (("CustomRadioGroupItem_" + (model.variables.cardListVar.getCurrentRowNumber(callContext.iterationContext)).toString())));
rec.valueAttr = model.variables.cardListVar.getCurrent(callContext.iterationContext).cardAttr;
rec.isSeparatedAttr = model.variables.cardListVar.getCurrent(callContext.iterationContext).isSeparatedAttr;
return rec;
}();
}, function () {
return model.variables.cardListVar.getCurrent(callContext.iterationContext).isSeparatedAttr;
}, function () {
return model.variables.cardListVar.getCurrentRowNumber(callContext.iterationContext);
}, function () {
return model.variables.cardListVar.getCurrent(callContext.iterationContext).cardAttr;
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "20",
alias: "13"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
left: new PlaceholderContent(function () {
return [$if(!(model.variables.cardListVar.getCurrent(callContext.iterationContext).isSeparatedAttr), false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomImage_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("wPUNsA19F0SUfJDBIN3F9A.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomImageOptionsRec();
rec.widthAttr = "24px";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "21",
alias: "14"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
image: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Image, {
type: /*External*/ 1,
url: model.getCachedValue(idService.getId("3JOxjc4JmkuJVJwgAZu1DQ.Url"), function () {
return ((false) ? ("/ShopperPortalEU_UI_Resources/img/ShopperPortalEU_UI_Resources.ECA.svg") : ((("/ShopperPortalEU_UI_Resources/img/ShopperPortalEU_UI_Resources." + model.variables.cardListVar.getCurrent(callContext.iterationContext).getCardsResponseAttr.paymentMethodAttr) + ".svg")));
}, function () {
return model.variables.cardListVar.getCurrent(callContext.iterationContext).getCardsResponseAttr.paymentMethodAttr;
}),
_idProps: {
service: idService,
uuid: "22"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.cardListVar.getCurrent(callContext.iterationContext).getCardsResponseAttr.paymentMethodAttr)]
})];
}, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomIcon_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("2cYA1NOd1Ua9GLi_GjC2Ig.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomIconOptionsRec();
rec.nameAttr = "credit_card";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "23",
alias: "15"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
})];
}),
title: new PlaceholderContent(function () {
return [$if(!(model.variables.cardListVar.getCurrent(callContext.iterationContext).isSeparatedAttr), false, this, function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "MaskedCardNumber"
},
value: model.getCachedValue(idService.getId("4q3X12OnW06ogKe6mEcfyw.Value"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.formatMaskedCard$Action(model.variables.cardListVar.getCurrent(callContext.iterationContext).getCardsResponseAttr.maskedCardNumberAttr, callContext).outputOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
}, function () {
return model.variables.cardListVar.getCurrent(callContext.iterationContext).getCardsResponseAttr.maskedCardNumberAttr;
}),
_idProps: {
service: idService,
uuid: "24"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}, function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "Add"
},
value: "Add card",
_idProps: {
service: idService,
uuid: "25"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})];
}),
description: new PlaceholderContent(function () {
return [$if(!(model.variables.cardListVar.getCurrent(callContext.iterationContext).isSeparatedAttr), false, this, function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "CardDetail"
},
value: model.getCachedValue(idService.getId("dxeQtj0h+UyB9q1vgdvwnQ.Value"), function () {
return (((((model.variables.cardListVar.getCurrent(callContext.iterationContext).getCardsResponseAttr.cardHolderNameAttr) !== (""))) ? (((((OS.BuiltinFunctions.length(model.variables.cardListVar.getCurrent(callContext.iterationContext).getCardsResponseAttr.cardHolderNameAttr) <= 17)) ? (model.variables.cardListVar.getCurrent(callContext.iterationContext).getCardsResponseAttr.cardHolderNameAttr) : ((OS.BuiltinFunctions.substr(model.variables.cardListVar.getCurrent(callContext.iterationContext).getCardsResponseAttr.cardHolderNameAttr, 0, 17) + "..."))) + " · ")) : ("")) + OS.BuiltinFunctions.formatDateTime(model.variables.cardListVar.getCurrent(callContext.iterationContext).getCardsResponseAttr.expiryDateFormatAttr, "MM/yy"));
}, function () {
return model.variables.cardListVar.getCurrent(callContext.iterationContext).getCardsResponseAttr.cardHolderNameAttr;
}, function () {
return model.variables.cardListVar.getCurrent(callContext.iterationContext).getCardsResponseAttr.expiryDateFormatAttr;
}),
_idProps: {
service: idService,
uuid: "26"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}, function () {
return [];
})];
}),
right: new PlaceholderContent(function () {
return [$if(model.variables.cardListVar.getCurrent(callContext.iterationContext).getCardsResponseAttr.isDefaultAttr, false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomTag_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("YKdTO_tc50KlIfbkqYOk7w.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomTagOptionsRec();
rec.stateAttr = ShopperPortalEUModel.staticEntities.customTagState.success;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "27",
alias: "16"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "defaultCard"
},
value: "Default",
_idProps: {
service: idService,
uuid: "28"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
})];
}, function () {
return [];
})];
}),
selectedContent: new PlaceholderContent(function () {
return [$if((model.variables.cardListVar.getCurrent(callContext.iterationContext).cardAttr === "0"), false, this, function () {
return [React.createElement(ShopperPortalEU_InternalComponents_DatatransTokenization_WB_mvc_view, {
inputs: {
TokenFallback: model.variables.datatransTokenFallbackVar,
IsToSubmitCard: model.variables.isToSubmitCardVar,
IsFromFormDetailsScreen: ShopperPortalEUClientVariables.getIsFromFormDetailsOrStepScreen(),
IsExpiryDateError: model.variables.isExpiryDateErrorVar,
Card: model.variables.selectedCardVar,
MerchantId: model.variables.cancelDataAct.merchantIdOut,
_merchantIdInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.cancelDataAct.dataFetchStatusAttr),
IsToSaveNewCard: model.variables.isToSaveNewCardVar,
CardDetailsData: model.variables.cardDetailsDataVar,
CardErrorMessage: model.variables.cardErrorMessageVar,
FormsList_ReadyForRefund: model.variables.formsList_ReadyForRefundVar
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
cardSubmitted$Action: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "InternalComponents/DatatransTokenization_WB CardSubmitted");
controller.onCardSubmitted$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
errorRequestingRefund$Action: function (errorMessageIn) {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "InternalComponents/DatatransTokenization_WB ErrorRequestingRefund");
controller.onError$Action(errorMessageIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
updateParameters$Action: function (cardDetailsDataIn, cardErrorMessageIn, isExpiryDateErrorIn) {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "InternalComponents/DatatransTokenization_WB UpdateParameters");
controller.onParametersChanged$Action(cardDetailsDataIn, cardErrorMessageIn, isExpiryDateErrorIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "29",
alias: "17"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-top-04",
visible: true,
_idProps: {
service: idService,
uuid: "30"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCheckbox_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "31",
alias: "18"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
checkbox: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Checkbox, {
_validationProps: {
validationService: validationService
},
enabled: true,
extendedProperties: {
"data-testid": "Checkbox_IsSaveCard"
},
onChange: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Refund/RequestRefund/Checkbox_IsSaveCard OnChange");
controller.checkbox_IsSaveCardOnChange$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "checkbox",
variable: model.createVariable(OS.DataTypes.DataTypes.Boolean, model.variables.isToSaveNewCardVar, function (value) {
model.variables.isToSaveNewCardVar = value;
}),
_idProps: {
service: idService,
name: "Checkbox_IsSaveCard"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
label: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
targetWidget: "Checkbox_IsSaveCard",
_idProps: {
service: idService,
uuid: "33"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "SaveCard"
},
value: "Save card for future refunds",
_idProps: {
service: idService,
uuid: "34"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables.isToSaveNewCardVar)]
}))];
}, function () {
return [];
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.formsList_ReadyForRefundVar), asPrimitiveValue(model.variables.cardErrorMessageVar), asPrimitiveValue(model.variables.cardDetailsDataVar), asPrimitiveValue(model.variables.isToSaveNewCardVar), asPrimitiveValue(model.variables.cancelDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.cancelDataAct.merchantIdOut), asPrimitiveValue(model.variables.selectedCardVar), asPrimitiveValue(model.variables.isExpiryDateErrorVar), asPrimitiveValue(ShopperPortalEUClientVariables.getIsFromFormDetailsOrStepScreen()), asPrimitiveValue(model.variables.isToSubmitCardVar), asPrimitiveValue(model.variables.datatransTokenFallbackVar), asPrimitiveValue(model.variables.cardListVar.getCurrent(callContext.iterationContext).cardAttr), asPrimitiveValue(model.variables.cardListVar.getCurrent(callContext.iterationContext).getCardsResponseAttr.isDefaultAttr), asPrimitiveValue(model.variables.cardListVar.getCurrent(callContext.iterationContext).getCardsResponseAttr.expiryDateFormatAttr), asPrimitiveValue(model.variables.cardListVar.getCurrent(callContext.iterationContext).getCardsResponseAttr.cardHolderNameAttr), asPrimitiveValue(model.variables.cardListVar.getCurrent(callContext.iterationContext).getCardsResponseAttr.maskedCardNumberAttr), asPrimitiveValue(model.variables.cardListVar.getCurrent(callContext.iterationContext).getCardsResponseAttr.paymentMethodAttr), asPrimitiveValue(model.variables.cardListVar.getCurrent(callContext.iterationContext).isSeparatedAttr)]
})];
}, callContext, idService, "1")
},
_dependencies: [asPrimitiveValue(model.variables.formsList_ReadyForRefundVar), asPrimitiveValue(model.variables.cardErrorMessageVar), asPrimitiveValue(model.variables.cardDetailsDataVar), asPrimitiveValue(model.variables.isToSaveNewCardVar), asPrimitiveValue(model.variables.cancelDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.cancelDataAct.merchantIdOut), asPrimitiveValue(model.variables.selectedCardVar), asPrimitiveValue(model.variables.isExpiryDateErrorVar), asPrimitiveValue(ShopperPortalEUClientVariables.getIsFromFormDetailsOrStepScreen()), asPrimitiveValue(model.variables.isToSubmitCardVar), asPrimitiveValue(model.variables.datatransTokenFallbackVar)]
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.formsList_ReadyForRefundVar), asPrimitiveValue(model.variables.cardErrorMessageVar), asPrimitiveValue(model.variables.cardDetailsDataVar), asPrimitiveValue(model.variables.isToSaveNewCardVar), asPrimitiveValue(model.variables.cancelDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.cancelDataAct.merchantIdOut), asPrimitiveValue(model.variables.selectedCardVar), asPrimitiveValue(model.variables.isExpiryDateErrorVar), asPrimitiveValue(ShopperPortalEUClientVariables.getIsFromFormDetailsOrStepScreen()), asPrimitiveValue(model.variables.isToSubmitCardVar), asPrimitiveValue(model.variables.datatransTokenFallbackVar), asPrimitiveValue(model.variables.cardListVar)]
})];
}),
bottom: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCard_mvc_view, {
inputs: {
ExtendedClass: "margin-top-04",
Options: model.getCachedValue(idService.getId("Ry5UikNLOEaurG5tZxnFqA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomCardOptionsRec();
rec.isSharperAttr = true;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "35",
alias: "19"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("B+677+_5RkyB9Kde2uXkfw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.alignAttr = ShopperPortalEUModel.staticEntities.flexAlign.center;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
rec.wrapAttr = false;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "36",
alias: "20"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomIcon_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("t1cUq9HgCEKk6+F6wINUhQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomIconOptionsRec();
rec.nameAttr = "currency_exchange";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "37",
alias: "21"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}), React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "refundInfo"
},
style: "body-4 text-primary-35",
value: "Your refund will be paid in your card\'s currency.",
_idProps: {
service: idService,
uuid: "38"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
})];
})
},
_dependencies: []
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.formsList_ReadyForRefundVar), asPrimitiveValue(model.variables.cardErrorMessageVar), asPrimitiveValue(model.variables.cardDetailsDataVar), asPrimitiveValue(model.variables.isToSaveNewCardVar), asPrimitiveValue(model.variables.cancelDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.cancelDataAct.merchantIdOut), asPrimitiveValue(model.variables.isExpiryDateErrorVar), asPrimitiveValue(ShopperPortalEUClientVariables.getIsFromFormDetailsOrStepScreen()), asPrimitiveValue(model.variables.isToSubmitCardVar), asPrimitiveValue(model.variables.datatransTokenFallbackVar), asPrimitiveValue(model.variables.cardListVar), asPrimitiveValue(model.variables.selectedCardVar)]
})];
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomBottomBar_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("2Roa5gb8x0CzIS2Fc+MyjA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomBottomBarOptionsRec();
rec.hasShadowAttr = true;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "39",
alias: "22"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("X3LQUOQXykql7mZ9bia0jw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.alignAttr = ShopperPortalEUModel.staticEntities.flexAlign.center;
rec.justifyAttr = ShopperPortalEUModel.staticEntities.flexJustify.spaceBetween;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "40",
alias: "23"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "refundSummary"
},
style: "heading5 text-primary-black",
value: model.getCachedValue(idService.getId("nMr+IKa5MkKVd7nm8ZrzQQ.Value"), function () {
return ("Refund summary " + ((((ShopperPortalEUClientVariables.getFormNumberRA1() === "") && ((model.variables.formsList_ReadyForRefundVar.length) !== (1)))) ? ((("(" + (model.variables.formsList_ReadyForRefundVar.length).toString()) + ")")) : ("")));
}, function () {
return ShopperPortalEUClientVariables.getFormNumberRA1();
}, function () {
return model.variables.formsList_ReadyForRefundVar.length;
}),
_idProps: {
service: idService,
uuid: "41"
},
_widgetRecordProvider: widgetsRecordProvider
}), $if(((ShopperPortalEUClientVariables.getFormNumberRA1() === "") && ((model.variables.formsList_ReadyForRefundVar.length) !== (1))), false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLink_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("LUUL+SapQUqYZ6RWHaJG9w.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomLinkOptionsRec();
rec.testIdAttr = "seeDetails";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "42",
alias: "24"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
link: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Link, {
enabled: true,
transition: OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default),
url: OS.Navigation.generateScreenURL("ShopperPortalEU", "RefundSummary", {}),
visible: true,
_idProps: {
service: idService,
uuid: "43"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLinkItem_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("FfYNdyRfGE+eQuJP6mK7dw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomLinkItemOptionsRec();
rec.iconAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomLinkOptionsIconRec();
rec.nameAttr = "chevron_right";
rec.alignmentAttr = ShopperPortalEUModel.staticEntities.customLinkIconAlignment.right;
return rec;
}();
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "44",
alias: "25"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "See details",
_idProps: {
service: idService,
uuid: "45"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
})];
}, function () {
return [];
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.formsList_ReadyForRefundVar.length), asPrimitiveValue(ShopperPortalEUClientVariables.getFormNumberRA1())]
}), $if(((model.variables.refundSummaryFormListVar.length === 1) || ((ShopperPortalEUClientVariables.getFormNumberRA1()) !== (""))), false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-top-05 body-3 text-primary-black",
visible: true,
_idProps: {
service: idService,
uuid: "46"
},
_widgetRecordProvider: widgetsRecordProvider
}, $if((model.variables.refundSummaryFormListVar.getCurrent(callContext.iterationContext).formInfo_WrapperAttr.length === 1), false, this, function () {
return [React.createElement(OSWidgets.Expression, {
value: model.variables.refundSummaryFormListVar.getCurrent(callContext.iterationContext).formInfo_WrapperAttr.getCurrent(callContext.iterationContext).merchantNameAttr,
_idProps: {
service: idService,
uuid: "47"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}, function () {
return [];
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomSeparator_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("PlIgaudQoUaY+BVJyqnO+A.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomSeparatorOptionsRec();
rec.marginTopAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
rec.marginBottomAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
rec.stateAttr = ShopperPortalEUModel.staticEntities.customSeparatorState.lighter;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "48",
alias: "26"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("E1di1xgVNUCC25mXck5g2w.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.alignAttr = ShopperPortalEUModel.staticEntities.flexAlign.center;
rec.justifyAttr = ShopperPortalEUModel.staticEntities.flexJustify.spaceBetween;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "49",
alias: "27"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "EstimatedRefund_Label"
},
value: "Estimated refund",
_idProps: {
service: idService,
uuid: "50"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "EstimatedRefund_Value"
},
style: "heading6",
value: ((OS.BuiltinFunctions.decimalToText(model.variables.refundSummaryFormListVar.getCurrent(callContext.iterationContext).totalEstimatedRefundAttr) + " ") + model.variables.refundSummaryFormListVar.getCurrent(callContext.iterationContext).currencyAttr),
_idProps: {
service: idService,
uuid: "51"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.refundSummaryFormListVar.getCurrent(callContext.iterationContext).currencyAttr), asPrimitiveValue(model.variables.refundSummaryFormListVar.getCurrent(callContext.iterationContext).totalEstimatedRefundAttr)]
}))];
}, function () {
return [];
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCheckbox_mvc_view, {
inputs: {
ExtendedClass: "margin-top-04",
Options: model.getCachedValue(idService.getId("enNHlXkkM0O8hxQqbQtpkg.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomCheckboxOptionsRec();
rec.testIdAttr = "PurchaseConfirmationCheckbox";
rec.isMandatoryAttr = true;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "52",
alias: "28"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
checkbox: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Checkbox, {
_validationProps: {
validationService: validationService
},
enabled: true,
style: "checkbox",
variable: model.createVariable(OS.DataTypes.DataTypes.Boolean, model.variables.purchaseConfirmationCheckVar, function (value) {
model.variables.purchaseConfirmationCheckVar = value;
}),
_idProps: {
service: idService,
name: "PurchaseConfirmationCheckbox"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
label: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
_idProps: {
service: idService,
uuid: "54"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
value: "I confirm that I made the original purchase and these are my card details",
_idProps: {
service: idService,
uuid: "55"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables.purchaseConfirmationCheckVar)]
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("_5kZ_V_HwkGO+VyYbNZvJw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRec();
rec.testIdAttr = "submitButton";
rec.typeAttr = ShopperPortalEUModel.staticEntities.customButtonType.primary;
rec.isLoadingAttr = model.variables.isCardSubmittingVar;
rec.isFullWidthAttr = true;
return rec;
}();
}, function () {
return model.variables.isCardSubmittingVar;
}),
ExtendedClass: "margin-top-04"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "56",
alias: "29"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
button: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: model.getCachedValue(idService.getId("kVYttejEz06RMTEC2k9CBA.Enabled"), function () {
return ((((model.variables.selectedCardVar) !== ("0"))) ? ((((model.variables.cardDetailsDataVar.lengthAttr > 0) && !(model.variables.cardDetailsDataVar.expiryDateAttr.equals(OS.BuiltinFunctions.nullDate()))) && model.variables.purchaseConfirmationCheckVar)) : (((((model.variables.cardDetailsDataVar.lengthAttr > 0) && !(model.variables.cardDetailsDataVar.expiryDateAttr.equals(OS.BuiltinFunctions.nullDate()))) && model.variables.purchaseConfirmationCheckVar) && ((model.variables.cardDetailsDataVar.cardHolderNameAttr) !== ("")))));
}, function () {
return model.variables.selectedCardVar;
}, function () {
return model.variables.cardDetailsDataVar.lengthAttr;
}, function () {
return model.variables.cardDetailsDataVar.expiryDateAttr;
}, function () {
return model.variables.purchaseConfirmationCheckVar;
}, function () {
return model.variables.cardDetailsDataVar.cardHolderNameAttr;
}),
isDefault: false,
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Refund/RequestRefund/Button OnClick");
controller.confirmSubmit$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn",
visible: true,
_idProps: {
service: idService,
uuid: "57"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("VTPIfD8MHEKPjree9jRWCg.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonItemOptionsRec();
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "58",
alias: "30"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Submit",
_idProps: {
service: idService,
uuid: "59"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables.purchaseConfirmationCheckVar), asPrimitiveValue(model.variables.cardDetailsDataVar.cardHolderNameAttr), asPrimitiveValue(model.variables.cardDetailsDataVar.expiryDateAttr), asPrimitiveValue(model.variables.cardDetailsDataVar.lengthAttr), asPrimitiveValue(model.variables.selectedCardVar)]
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.cardDetailsDataVar.cardHolderNameAttr), asPrimitiveValue(model.variables.cardDetailsDataVar.expiryDateAttr), asPrimitiveValue(model.variables.cardDetailsDataVar.lengthAttr), asPrimitiveValue(model.variables.selectedCardVar), asPrimitiveValue(model.variables.isCardSubmittingVar), asPrimitiveValue(model.variables.purchaseConfirmationCheckVar), asPrimitiveValue(model.variables.refundSummaryFormListVar.getCurrent(callContext.iterationContext).currencyAttr), asPrimitiveValue(model.variables.refundSummaryFormListVar.getCurrent(callContext.iterationContext).totalEstimatedRefundAttr), asPrimitiveValue(model.variables.refundSummaryFormListVar.getCurrent(callContext.iterationContext).formInfo_WrapperAttr.getCurrent(callContext.iterationContext).merchantNameAttr), asPrimitiveValue(model.variables.refundSummaryFormListVar.getCurrent(callContext.iterationContext).formInfo_WrapperAttr.length), asPrimitiveValue(model.variables.refundSummaryFormListVar.length), asPrimitiveValue(model.variables.formsList_ReadyForRefundVar.length), asPrimitiveValue(ShopperPortalEUClientVariables.getFormNumberRA1())]
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomPopup_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "60",
alias: "31"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
popup: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Popup, {
showPopup: model.variables.showConfirmationPopupVar,
style: "popup-dialog",
_idProps: {
service: idService,
uuid: "61"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomPopupLayout_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("T6MN8800mkqpFSijpbAq9g.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomPopupLayoutOptionsRec();
rec.showCloseAttr = true;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onClose$Action: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ShopperPortalEUUIComponents/CustomPopupLayout OnClose");
controller.toggleConfirmationPopup$Action("CloseAddCardConfirmationPopup_btn", controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
onOverlayClick$Action: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ShopperPortalEUUIComponents/CustomPopupLayout OnOverlayClick");
controller.toggleConfirmationPopup$Action("", controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "62",
alias: "32"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
title: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "ConfimationPopup_Title"
},
value: "Are you sure you want the card refund method?",
_idProps: {
service: idService,
uuid: "63"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "ConfimationPopup_Content"
},
value: "After adding this card, the refund method cannot be changed. All other methods will no longer be available at the refund desks.",
_idProps: {
service: idService,
uuid: "64"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
actions: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("rhLYiQFPlkSs+r3Waa1q3Q.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.justifyAttr = ShopperPortalEUModel.staticEntities.flexJustify.spaceBetween;
rec.wrapAttr = false;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "65",
alias: "33"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("lBkRR_QT0UCOGnQow1Ia+g.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRec();
rec.testIdAttr = "ConfimationPopup_Cancel";
rec.typeAttr = ShopperPortalEUModel.staticEntities.customButtonType.reverse;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "66",
alias: "34"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
button: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: false,
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Refund/RequestRefund/Button OnClick");
controller.cancel$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn",
visible: true,
_idProps: {
service: idService,
uuid: "67"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "68",
alias: "35"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Cancel",
_idProps: {
service: idService,
uuid: "69"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("hYglxDHz+kmYsElrBhegsw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRec();
rec.testIdAttr = "ConfimationPopup_Add";
rec.typeAttr = ShopperPortalEUModel.staticEntities.customButtonType.primary;
rec.isLoadingAttr = model.variables.isCardSubmittingVar;
return rec;
}();
}, function () {
return model.variables.isCardSubmittingVar;
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "70",
alias: "36"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
button: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: false,
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Refund/RequestRefund/Button OnClick");
controller.submit$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn",
visible: true,
_idProps: {
service: idService,
uuid: "71"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "72",
alias: "37"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Yes, add card",
_idProps: {
service: idService,
uuid: "73"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.isCardSubmittingVar)]
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.isCardSubmittingVar)]
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables.isCardSubmittingVar), asPrimitiveValue(model.variables.showConfirmationPopupVar)]
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.showConfirmationPopupVar), asPrimitiveValue(model.variables.isCardSubmittingVar), asPrimitiveValue(model.variables.purchaseConfirmationCheckVar), asPrimitiveValue(model.variables.refundSummaryFormListVar.getCurrent(callContext.iterationContext).currencyAttr), asPrimitiveValue(model.variables.refundSummaryFormListVar.getCurrent(callContext.iterationContext).totalEstimatedRefundAttr), asPrimitiveValue(model.variables.refundSummaryFormListVar.getCurrent(callContext.iterationContext).formInfo_WrapperAttr.getCurrent(callContext.iterationContext).merchantNameAttr), asPrimitiveValue(model.variables.refundSummaryFormListVar.getCurrent(callContext.iterationContext).formInfo_WrapperAttr.length), asPrimitiveValue(model.variables.refundSummaryFormListVar.length), asPrimitiveValue(ShopperPortalEUClientVariables.getFormNumberRA1()), asPrimitiveValue(model.variables.datatransTokenFallbackVar), asPrimitiveValue(model.variables.selectedCardVar), asPrimitiveValue(model.variables.cardErrorMessageVar), asPrimitiveValue(model.variables.cardDetailsDataVar), asPrimitiveValue(model.variables.isExpiryDateErrorVar), asPrimitiveValue(model.variables.formsList_ReadyForRefundVar), asPrimitiveValue(ShopperPortalEUClientVariables.getIsFromFormDetailsOrStepScreen()), asPrimitiveValue(model.variables.isToSubmitCardVar), asPrimitiveValue(model.variables.isToSaveNewCardVar), asPrimitiveValue(model.variables.cancelDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.cancelDataAct.merchantIdOut), asPrimitiveValue(model.variables.cardListVar)]
})];
}),
bottom: PlaceholderContent.Empty
},
_dependencies: [asPrimitiveValue(model.variables.showConfirmationPopupVar), asPrimitiveValue(model.variables.isCardSubmittingVar), asPrimitiveValue(model.variables.purchaseConfirmationCheckVar), asPrimitiveValue(model.variables.refundSummaryFormListVar.getCurrent(callContext.iterationContext).currencyAttr), asPrimitiveValue(model.variables.refundSummaryFormListVar.getCurrent(callContext.iterationContext).totalEstimatedRefundAttr), asPrimitiveValue(model.variables.refundSummaryFormListVar.getCurrent(callContext.iterationContext).formInfo_WrapperAttr.getCurrent(callContext.iterationContext).merchantNameAttr), asPrimitiveValue(model.variables.refundSummaryFormListVar.getCurrent(callContext.iterationContext).formInfo_WrapperAttr.length), asPrimitiveValue(model.variables.refundSummaryFormListVar.length), asPrimitiveValue(ShopperPortalEUClientVariables.getFormNumberRA1()), asPrimitiveValue(model.variables.datatransTokenFallbackVar), asPrimitiveValue(model.variables.selectedCardVar), asPrimitiveValue(model.variables.cardErrorMessageVar), asPrimitiveValue(model.variables.cardDetailsDataVar), asPrimitiveValue(model.variables.isExpiryDateErrorVar), asPrimitiveValue(model.variables.formsList_ReadyForRefundVar), asPrimitiveValue(ShopperPortalEUClientVariables.getIsFromFormDetailsOrStepScreen()), asPrimitiveValue(model.variables.isToSubmitCardVar), asPrimitiveValue(model.variables.isToSaveNewCardVar), asPrimitiveValue(model.variables.cancelDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.cancelDataAct.merchantIdOut), asPrimitiveValue(model.variables.cardListVar), asPrimitiveValue(model.variables.isScreenReadyVar)]
}));
        };
        return View;
    })(OSView.BaseView.BaseWebScreen);
	
    return View;
});
define("ShopperPortalEU.Refund.RequestRefund.mvc$controller", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.controller", "ShopperPortalEU_Shopper_IS.controller", "ShopperPortalEU.languageResources", "ShopperPortalEU.clientVariables", "ShopperPortalEU.Refund.RequestRefund.mvc$debugger", "ShopperPortalEU.Refund.controller", "ShopperPortalEU.controller$FormatMaskedCard", "ShopperPortalEU_Forms_IS.model$FormInfo_WrapperRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Forms_IS", "ShopperPortalEU.model$FormInfo_WrapperList", "ShopperPortalEU.model$RefundSummaryList", "ShopperPortalEU.model$RequestRefundCardList", "ShopperPortalEU_Shopper_IS.model$DatatransTokenFallbackRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS", "ShopperPortalEU_UI_Components.model$DatatransCardChangeOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Theme.model$LayoutDetailOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU_UI_Components.model$FullHeightContentOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentTopOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentBottomOptionsRec", "ShopperPortalEU_Forms_IS.model$RefundDetails_WrapperRec", "ShopperPortalEU_Forms_IS.model$FormDetails_WrapperRec", "ShopperPortalEU_Forms_IS.model$UIConfigurationRec", "ShopperPortalEU_Forms_IS.model$RefundDetailsPaymentDetails_UIRec", "ShopperPortalEU_UI_Components.model$CustomCheckboxOptionsRec", "ShopperPortalEU_UI_Components.model$CustomCardOptionsRec", "ShopperPortalEU_UI_Components.model$FlexOptionsRec", "ShopperPortalEU_UI_Components.model$CustomIconOptionsRec", "ShopperPortalEU_UI_Components.model$CustomRadioGroupOptionsRec", "ShopperPortalEU_UI_Components.model$CustomRadioButtonOptionsRec", "ShopperPortalEU_UI_Components.model$CustomImageOptionsRec", "ShopperPortalEU_UI_Components.model$CustomTagOptionsRec", "ShopperPortalEU_UI_Components.model$CustomBottomBarOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsIconRec", "ShopperPortalEU_UI_Components.model$CustomSeparatorOptionsRec", "ShopperPortalEU_UI_Components.model$CustomSeparatorLabelOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconRec", "ShopperPortalEU_UI_Components.model$CustomPopupLayoutOptionsRec", "ShopperPortalEU_UI_Components.model$CustomPopupLayoutHeaderImageOptionsRec", "ShopperPortalEU.controller$ClarityEvent", "ShopperPortalEU.controller$GetFormsRefundList", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", "ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger", "ShopperPortalEU_Shopper_IS.model$GetCardsResponseRec", "ShopperPortalEU.model$GetCardsResponseList", "ShopperPortalEU_Shopper_IS.controller$GetCards", "ShopperPortalEU.controller$DefaultErrorMessage", "ShopperPortalEU.model$RequestRefundCardRec", "ShopperPortalEU.controller$CheckValidCard"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_Forms_ISModel, ShopperPortalEU_Shopper_ISModel, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ThemeController, ShopperPortalEU_Shopper_ISController, ShopperPortalEULanguageResources, ShopperPortalEUClientVariables, ShopperPortalEU_Refund_RequestRefund_mvc_Debugger, ShopperPortalEU_RefundController) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {
cancel$DataActRefresh: 0
};
this.dataFetchDependentsGraph = {
cancel$DataActRefresh: []
};
this.shouldSendClientVarsToDataSources = true;
}
// Server Actions

// Aggregates and Data Actions
Controller.prototype.cancel$DataActRefresh = function (callContext) {
var model = this.model;
var controller = this.controller;
var callContext = controller.callContext(callContext);
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:bPxu0WaYc0m00qph4rshZg:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.bug_ktdZT0il_jkLuKbIcw/DataActions.bPxu0WaYc0m00qph4rshZg:7s7FucW+6Vshm5jwy91+fg", "ShopperPortalEU", "Cancel", "NRFlows.DataScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.setThreadStartName(callContext.id, "Refund/RequestRefund/Cancel");
return controller.callDataAction("DataActionCancel", "screenservices/ShopperPortalEU/Refund/RequestRefund/DataActionCancel", "Q9kNI5g1FCpDaEef+2qxmQ", function (b) {
model.variables.cancelDataAct.dataFetchStatusAttr = b;
}, function (json) {
model.variables.cancelDataAct.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.cancelDataAct.constructor));
}, undefined, OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, callContext, ShopperPortalEUClientVariables, false);

}, function () {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:bPxu0WaYc0m00qph4rshZg", callContext.id);
controller.popDebuggerContext(callContext);

});
};

Controller.prototype.dataFetchActionNames = ["cancel$DataActRefresh"];
// Client Actions
Controller.prototype._toggleConfirmationPopup$Action = function (eventIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("ToggleConfirmationPopup");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.Refund.RequestRefund.ToggleConfirmationPopup$vars"))());
vars.value.eventInLocal = eventIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:8piuGIbBWEay4dERRRicrw:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.bug_ktdZT0il_jkLuKbIcw/ClientActions.8piuGIbBWEay4dERRRicrw:QCkFixgQiC5cY8f3KwHyQQ", "ShopperPortalEU", "ToggleConfirmationPopup", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:42tsXr+RjUSjiJUQowOC_A", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:8pUf0cg_0kK22vAqohlSSw", callContext.id);
// ShowConfirmationPopup = notShowConfirmationPopup
model.variables.showConfirmationPopupVar = !(model.variables.showConfirmationPopupVar);
// Has event
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:LovCqhppYEChGjpL8G4GBg", callContext.id) && ((vars.value.eventInLocal) !== ("")))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:NF67Af_FVEqEq2roQiJRmg", callContext.id);
// Execute Action: ClarityEvent
ShopperPortalEUController.default.clarityEvent$Action(vars.value.eventInLocal, callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:_4qxscGkck2sJ09B+XgkyA", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:+fOGEz8DrUObaS5KkjLx3w", callContext.id);
}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:8piuGIbBWEay4dERRRicrw", callContext.id);
}

};
Controller.registerVariableGroupType("ShopperPortalEU.Refund.RequestRefund.ToggleConfirmationPopup$vars", [{
name: "Event",
attrName: "eventInLocal",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
Controller.prototype._setCardSelected$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("SetCardSelected");
callContext = controller.callContext(callContext);
var listFilterByCardSelectedVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.listFilterByCardSelectedVar = listFilterByCardSelectedVar;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:aXQ_HYn_rUmiajgkSI2eAQ:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.bug_ktdZT0il_jkLuKbIcw/ClientActions.aXQ_HYn_rUmiajgkSI2eAQ:6NH_mGhjSPcpfl6XDtFidA", "ShopperPortalEU", "SetCardSelected", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:um5zrAcPFkOMB+Ai0zW_tg", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Why4d42wNU6SVKVJickqlg", callContext.id);
// Execute Action: ListFilterByCardSelected
listFilterByCardSelectedVar.value = OS.SystemActions.listFilter(model.variables.cardListVar, function (p) {
return (p.cardAttr === model.variables.selectedCardVar);
}, callContext);

// SetCardSelected
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:+QfC4XzMYEG2tElZ6jcOaA", callContext.id);
// CardDetailsData.Length = Length
model.variables.cardDetailsDataVar.lengthAttr = OS.BuiltinFunctions.length(listFilterByCardSelectedVar.value.filteredListOut.getCurrent(callContext.iterationContext).getCardsResponseAttr.maskedCardNumberAttr);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:+QfC4XzMYEG2tElZ6jcOaA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// CardDetailsData.ExpiryDate = ListFilterByCardSelected.FilteredList.Current.GetCardsResponse.ExpiryDateFormat
model.variables.cardDetailsDataVar.expiryDateAttr = OS.BuiltinFunctions.dateTimeToDate(listFilterByCardSelectedVar.value.filteredListOut.getCurrent(callContext.iterationContext).getCardsResponseAttr.expiryDateFormatAttr);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:+QfC4XzMYEG2tElZ6jcOaA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// DatatransTokenFallback.Alias = ListFilterByCardSelected.FilteredList.Current.GetCardsResponse.TokenValue
model.variables.datatransTokenFallbackVar.aliasAttr = listFilterByCardSelectedVar.value.filteredListOut.getCurrent(callContext.iterationContext).getCardsResponseAttr.tokenValueAttr;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:+QfC4XzMYEG2tElZ6jcOaA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// DatatransTokenFallback.MaskedCard = ListFilterByCardSelected.FilteredList.Current.GetCardsResponse.MaskedCardNumber
model.variables.datatransTokenFallbackVar.maskedCardAttr = listFilterByCardSelectedVar.value.filteredListOut.getCurrent(callContext.iterationContext).getCardsResponseAttr.maskedCardNumberAttr;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:+QfC4XzMYEG2tElZ6jcOaA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// DatatransTokenFallback.PaymentMethod = ListFilterByCardSelected.FilteredList.Current.GetCardsResponse.PaymentMethod
model.variables.datatransTokenFallbackVar.paymentMethodAttr = listFilterByCardSelectedVar.value.filteredListOut.getCurrent(callContext.iterationContext).getCardsResponseAttr.paymentMethodAttr;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:+QfC4XzMYEG2tElZ6jcOaA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "6");
// CardDetailsData.PaymentMethod = ListFilterByCardSelected.FilteredList.Current.GetCardsResponse.PaymentMethod
model.variables.cardDetailsDataVar.paymentMethodAttr = listFilterByCardSelectedVar.value.filteredListOut.getCurrent(callContext.iterationContext).getCardsResponseAttr.paymentMethodAttr;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:+QfC4XzMYEG2tElZ6jcOaA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "7");
// CardDetailsData.CardHolderName = ListFilterByCardSelected.FilteredList.Current.GetCardsResponse.CardHolderName
model.variables.cardDetailsDataVar.cardHolderNameAttr = listFilterByCardSelectedVar.value.filteredListOut.getCurrent(callContext.iterationContext).getCardsResponseAttr.cardHolderNameAttr;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:+QfC4XzMYEG2tElZ6jcOaA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "8");
// CardDetailsData.IsValid = True
model.variables.cardDetailsDataVar.isValidAttr = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:WjGMZ0hMhEeCBpzNJE6wKQ", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:aXQ_HYn_rUmiajgkSI2eAQ", callContext.id);
}

};
Controller.prototype._cardListOnChange$Action = function (currentValueIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("CardListOnChange");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.Refund.RequestRefund.CardListOnChange$vars"))());
vars.value.currentValueInLocal = currentValueIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:ALLiHd+3gEiaR+z40qqFFg:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.bug_ktdZT0il_jkLuKbIcw/ClientActions.ALLiHd+3gEiaR+z40qqFFg:WuAxDnb8qeCTCePSlt3t1A", "ShopperPortalEU", "CardListOnChange", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:cnQU+Nuv3EOAjfXTsjYKAA", callContext.id);
// SetCardSelected
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:qIgieAsnu062qAz9rGza_g", callContext.id);
// SelectedCard = CurrentValue
model.variables.selectedCardVar = vars.value.currentValueInLocal;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:eZ+2ITW79EeR8uINcIGnfQ", callContext.id);
// Execute Action: SetCardSelected
controller._setCardSelected$Action(callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:7qYYXrZvyUeRnVvBVmelLw", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:ALLiHd+3gEiaR+z40qqFFg", callContext.id);
}

};
Controller.registerVariableGroupType("ShopperPortalEU.Refund.RequestRefund.CardListOnChange$vars", [{
name: "CurrentValue",
attrName: "currentValueInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
Controller.prototype._onAfterAuthentication$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnAfterAuthentication");
callContext = controller.callContext(callContext);
var getFormsRefundListVar = new OS.DataTypes.VariableHolder();
var getCardsVar = new OS.DataTypes.VariableHolder();
var jSONSerializeRefundSummaryFormListVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.JSONSerializeOutputType());
var jSONDeserializeFormInfo_WrapperVar = new OS.DataTypes.VariableHolder(new (OS.Controller.BaseController.getJSONDeserializeOutputType(ShopperPortalEUModel.FormInfo_WrapperList))());
varBag.callContext = callContext;
varBag.getFormsRefundListVar = getFormsRefundListVar;
varBag.getCardsVar = getCardsVar;
varBag.jSONSerializeRefundSummaryFormListVar = jSONSerializeRefundSummaryFormListVar;
varBag.jSONDeserializeFormInfo_WrapperVar = jSONDeserializeFormInfo_WrapperVar;
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:CSgDMQLHhU2R+FgI701oOw:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.bug_ktdZT0il_jkLuKbIcw/ClientActions.CSgDMQLHhU2R+FgI701oOw:J7fgHnV9JQdLtV+Gtw4shw", "ShopperPortalEU", "OnAfterAuthentication", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:r0cNAy+0tUS9vPGyhZihfA", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:X3094Hb5_E6w5LMC_ErNHw", callContext.id);
// JSON Deserialize: JSONDeserializeFormInfo_Wrapper
jSONDeserializeFormInfo_WrapperVar.value.dataOut = OS.JSONUtils.deserializeFromJSON(ShopperPortalEUClientVariables.getFormInfoListJSON(), ShopperPortalEUModel.FormInfo_WrapperList, false);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:TP6TMbJI2k+NvS7hbbHuCg", callContext.id);
// Execute Action: GetFormsRefundList
getFormsRefundListVar.value = ShopperPortalEUController.default.getFormsRefundList$Action(jSONDeserializeFormInfo_WrapperVar.value.dataOut, callContext);

OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:cEbPArBaa02bCBtqpHZRWA", callContext.id);
// JSON Serialize: JSONSerializeRefundSummaryFormList
jSONSerializeRefundSummaryFormListVar.value.jSONOut = OS.JSONUtils.serializeToJSON(getFormsRefundListVar.value.refundSummaryFormListOut, false, false);
// FormsList_ReadyForRefund & RefundSummaryFormListJSON
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:j96kevx5NEWPmgscK6nXnw", callContext.id);
// FormsList_ReadyForRefund = GetFormsRefundList.FormsList_ReadyForRefund
model.variables.formsList_ReadyForRefundVar = getFormsRefundListVar.value.formsList_ReadyForRefundOut;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:j96kevx5NEWPmgscK6nXnw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// RefundSummaryFormListJSON = JSONSerializeRefundSummaryFormList.JSON
ShopperPortalEUClientVariables.setRefundSummaryFormListJSON(jSONSerializeRefundSummaryFormListVar.value.jSONOut);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:j96kevx5NEWPmgscK6nXnw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// RefundSummaryFormList = GetFormsRefundList.RefundSummaryFormList
model.variables.refundSummaryFormListVar = getFormsRefundListVar.value.refundSummaryFormListOut;
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:7ie1IPhOskq9N5IbsIqhwA", callContext.id) && model.variables.cardListVar.isEmpty)) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:3ijuyaLSkUGvB7F7SmGV1A", callContext.id);
// Execute Action: GetCards
model.flush();
return ShopperPortalEU_Shopper_ISController.default.getCards$Action(ShopperPortalEUClientVariables.getShopperGuid(), callContext).then(function (value) {
getCardsVar.value = value;
}).then(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:nI9JFGXSyU2APSyZGAu5XQ", callContext.id) && getCardsVar.value.isSuccessOut)) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:SwLDh2Ugdk+wZOEW02_3Dw", callContext.id);
// Execute Action: ListAppendAllExistingCards
OS.SystemActions.listAppendAll(model.variables.cardListVar, OS.DataConversion.JSConversions.typeConvertRecordList(getCardsVar.value.cardsOut, new ShopperPortalEUModel.RequestRefundCardList(), function (source, target) {
target.isSeparatedAttr = false;
target.getCardsResponseAttr.maskedCardNumberAttr = source.maskedCardNumberAttr;
target.getCardsResponseAttr.expiryDateAttr = source.expiryDateAttr;
target.getCardsResponseAttr.expiryDateFormatAttr = source.expiryDateFormatAttr;
target.getCardsResponseAttr.isDefaultAttr = source.isDefaultAttr;
target.getCardsResponseAttr.paymentMethodAttr = source.paymentMethodAttr;
target.getCardsResponseAttr.tokenValueAttr = source.tokenValueAttr;
target.getCardsResponseAttr.tokenProviderAttr = source.tokenProviderAttr;
target.getCardsResponseAttr.cardHolderNameAttr = source.cardHolderNameAttr;
return target;
}), callContext);
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:eH7MKk7VqE6xsId7X8IwwQ", callContext.id) && !(model.variables.cardListVar.isEmpty))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:LBpkKbSwNEeMHOvgjH6jNw", callContext.id);
// Execute Action: ListAppendNewCard
OS.SystemActions.listAppend(model.variables.cardListVar, function () {
var rec = new ShopperPortalEUModel.RequestRefundCardRec();
rec.cardAttr = "0";
rec.isSeparatedAttr = true;
return rec;
}(), callContext);
// Foreach CardList
callContext.iterationContext.registerIterationStart(model.variables.cardListVar);
try {var cardListIterator = callContext.iterationContext.getIterator(model.variables.cardListVar);
var cardListIndex = 0;
while ((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:X_Y_22M7FECcqGbG845aAw", callContext.id) && (cardListIndex < model.variables.cardListVar.length))) {
cardListIterator.currentRowNumber = cardListIndex;
// Has value
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:vzhTAVtDOkaCSiRy8trIiw", callContext.id) && !(((model.variables.cardListVar.getItem(cardListIndex.valueOf()).cardAttr) !== (""))))) {
// Set card value
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:iuA2CsERx0Kh2JOn9yS1cQ", callContext.id);
// CardList.Current.Card = If
model.variables.cardListVar.getItem(cardListIndex.valueOf()).cardAttr = ((((model.variables.cardListVar.getItem(cardListIndex.valueOf()).cardAttr) !== (""))) ? (model.variables.cardListVar.getItem(cardListIndex.valueOf()).cardAttr) : (((model.variables.cardListVar.getCurrentRowNumber(callContext.iterationContext) + 1)).toString()));
}

// Not default card
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Q1Vz7bBECkChIBVZPpoYdw", callContext.id) && !(!(model.variables.cardListVar.getItem(cardListIndex.valueOf()).getCardsResponseAttr.isDefaultAttr)))) {
// Set card selected
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:9AmVwesc1EueVR3bVp6J8g", callContext.id);
// SelectedCard = CardList.Current.Card
model.variables.selectedCardVar = model.variables.cardListVar.getItem(cardListIndex.valueOf()).cardAttr;
}

// dummy
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:DOgR8AU_9E6txx0zVd0moQ", callContext.id);
cardListIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(model.variables.cardListVar);
}

// No card selected
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:oiAO9QLaz0yIN746d2Tl6w", callContext.id) && !((model.variables.selectedCardVar === "0")))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:xhVCGJShxEOJfRQIsdmOEw", callContext.id);
// Execute Action: SetCardSelected
controller._setCardSelected$Action(callContext);
}

OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:dOIJy9X7jk68AkynJL9pJw", callContext.id);
// IsScreenReady = True
model.variables.isScreenReadyVar = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:RbkbfoBaGkKqsYYM2ERYcA", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:qUFuTpB2KESsefPZ4zWMyg", callContext.id);
// IsScreenReady = True
model.variables.isScreenReadyVar = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:CNMk+idRj0G9mtsq2l1nxg", callContext.id);
}

} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:LDgpiniEfEej9_2KXeO6iw", callContext.id);
// Execute Action: ErrorMessage
ShopperPortalEU_UI_ThemeController.default.customMessageTrigger$Action(function () {
var rec = new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customMessageType.error;
rec.titleAttr = getCardsVar.value.errorMessageOut;
rec.contentAttr = OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.defaultErrorMessage$Action(callContext).errorMessageOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
rec.testIdAttr = "Error";
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:orep1EGISU60FoWe3QcUGQ", callContext.id);
// IsScreenReady = True
model.variables.isScreenReadyVar = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Y37VEbC91UmmzuxRUJcpPw", callContext.id);
}

});
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:YPfnJFVttkeSsagXFOwk0Q", callContext.id);
// IsScreenReady = True
model.variables.isScreenReadyVar = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:YMnnHsDgXUSaZnc6CieIjQ", callContext.id);
}

});
}).then(function (res) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:CSgDMQLHhU2R+FgI701oOw", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:CSgDMQLHhU2R+FgI701oOw", callContext.id);
throw ex;

});
};
Controller.prototype._onErrorSavingCard$Action = function (errorMessageIn, isCreateCardGenericErrorIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnErrorSavingCard");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.Refund.RequestRefund.OnErrorSavingCard$vars"))());
vars.value.errorMessageInLocal = errorMessageIn;
vars.value.isCreateCardGenericErrorInLocal = isCreateCardGenericErrorIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:Ok1uQCZK00mcHfzgnQ+k0w:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.bug_ktdZT0il_jkLuKbIcw/ClientActions.Ok1uQCZK00mcHfzgnQ+k0w:LpghwLAbpc23qA7Fjkm3Ug", "ShopperPortalEU", "OnErrorSavingCard", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:SwX1DWB_x02LT36pzE2Ubw", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:5HjoD+LI6kunarJkdGiTNg", callContext.id);
// IsCardSubmitting = False
model.variables.isCardSubmittingVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:5HjoD+LI6kunarJkdGiTNg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// IsToSubmitCard = False
model.variables.isToSubmitCardVar = false;
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:M9pbKXysR0i3jmyPrVRxJA", callContext.id) && vars.value.isCreateCardGenericErrorInLocal)) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:iou5l2a+IEWx+5_6KHs4ig", callContext.id);
// Execute Action: ErrorMessage2
ShopperPortalEU_UI_ThemeController.default.customMessageTrigger$Action(function () {
var rec = new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customMessageType.error;
rec.titleAttr = vars.value.errorMessageInLocal;
rec.contentAttr = OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.defaultErrorMessage$Action(callContext).errorMessageOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
rec.testIdAttr = "Error";
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:GBKc0p6YskCJgn5J7o6YPQ", callContext.id);
} else {
// ErrorMessage
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:onpmTo7TTUWmjqeaduH0Ig", callContext.id);
// CardErrorMessage = ErrorMessage
model.variables.cardErrorMessageVar = vars.value.errorMessageInLocal;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:YeXJO7t6REW8Z0Z8nTlOcg", callContext.id);
}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:Ok1uQCZK00mcHfzgnQ+k0w", callContext.id);
}

};
Controller.registerVariableGroupType("ShopperPortalEU.Refund.RequestRefund.OnErrorSavingCard$vars", [{
name: "ErrorMessage",
attrName: "errorMessageInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}, {
name: "IsCreateCardGenericError",
attrName: "isCreateCardGenericErrorInLocal",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Boolean,
defaultValue: function () {
return false;
}
}]);
Controller.prototype._onInitialize$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnInitialize");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:Z44XQzyr3kutby_zkgl6Tg:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.bug_ktdZT0il_jkLuKbIcw/ClientActions.Z44XQzyr3kutby_zkgl6Tg:3j6opJkSgT3tlrbAUE7hOg", "ShopperPortalEU", "OnInitialize", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:UtlyakCwSEuohTMxS7plTw", callContext.id);
// Reset client variable
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:K9sOnP5cW0ihrSrESDuN9g", callContext.id);
// FromCarouselAddCard = False
ShopperPortalEUClientVariables.setFromCarouselAddCard(false);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Xfj+uczqJ0+BNoEQVz_N6A", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:Z44XQzyr3kutby_zkgl6Tg", callContext.id);
}

};
Controller.prototype._onCardSubmitted$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnCardSubmitted");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:W7ptUHAieUy8kn3_klrxyA:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.bug_ktdZT0il_jkLuKbIcw/ClientActions.W7ptUHAieUy8kn3_klrxyA:Bkj1gQIxDF3iXhJ4ReIl4w", "ShopperPortalEU", "OnCardSubmitted", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:kFu1EHbG5U6KHDAveMzaqg", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:f5xhjOQ2WEi90KXpfFejqg", callContext.id);
// IsToSubmitCard = False
model.variables.isToSubmitCardVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ZjrwCfr+LU2HuEnXG+TsBg", callContext.id);
// Execute Action: ToggleConfirmationPopup
controller._toggleConfirmationPopup$Action("SubmitRefund_btn", callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Yu7Zf13NOUydf6Y_LPL0fA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:W7ptUHAieUy8kn3_klrxyA", callContext.id);
}

};
Controller.prototype._closeConfirmationPopup$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("CloseConfirmationPopup");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:iR5Sax7BlU6Hs2itBb+GGQ:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.bug_ktdZT0il_jkLuKbIcw/ClientActions.iR5Sax7BlU6Hs2itBb+GGQ:ntSRRmI0cDeWi6m7QwlinA", "ShopperPortalEU", "CloseConfirmationPopup", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:9GfH2Yij+UW6IAPwrDMYaQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:s8qWy7lrKE2rsFrFhrku7w", callContext.id);
// ShowConfirmationPopup = False
model.variables.showConfirmationPopupVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:2LF4KdPj0UOkNGTuMb6FWg", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:iR5Sax7BlU6Hs2itBb+GGQ", callContext.id);
}

};
Controller.prototype._cancel$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Cancel");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:hTj8go4Oo0CBsVLvj0O6pw:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.bug_ktdZT0il_jkLuKbIcw/ClientActions.hTj8go4Oo0CBsVLvj0O6pw:NJuLRTes9q8M8FiOWHgUpw", "ShopperPortalEU", "Cancel", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:9xGU2UCERESvdfaxfUMEug", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:sNuMnBiCN0yYP3+p_aQOcg", callContext.id);
// Execute Action: ToggleConfirmationPopup
controller._toggleConfirmationPopup$Action("CancelAttachCard_btn", callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:4NOtXNjRj0a1Jd8VyKUdQQ", callContext.id);
// Destination: /ShopperPortalEU/MyRefunds
return OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "MyRefunds", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:hTj8go4Oo0CBsVLvj0O6pw", callContext.id);
}

};
Controller.prototype._onParametersChanged$Action = function (event_CardDetailsDataIn, event_CardErrorMessageIn, event_IsExpiryDateErrorIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnParametersChanged");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.Refund.RequestRefund.OnParametersChanged$vars"))());
vars.value.event_CardDetailsDataInLocal = event_CardDetailsDataIn.clone();
vars.value.event_CardErrorMessageInLocal = event_CardErrorMessageIn;
vars.value.event_IsExpiryDateErrorInLocal = event_IsExpiryDateErrorIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:TP+BhtSV4UmUbqFiy+ImIA:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.bug_ktdZT0il_jkLuKbIcw/ClientActions.TP+BhtSV4UmUbqFiy+ImIA:hbuWDXDXKIYkBN+yqbKujw", "ShopperPortalEU", "OnParametersChanged", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:lukuXxxznUCg9aYEspd7eA", callContext.id);
// Update vars
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:9lPkhWBuNkSsqaoBrxZHcQ", callContext.id);
// CardDetailsData = Event_CardDetailsData
model.variables.cardDetailsDataVar = vars.value.event_CardDetailsDataInLocal;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:9lPkhWBuNkSsqaoBrxZHcQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// CardErrorMessage = Event_CardErrorMessage
model.variables.cardErrorMessageVar = vars.value.event_CardErrorMessageInLocal;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:9lPkhWBuNkSsqaoBrxZHcQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// IsExpiryDateError = Event_IsExpiryDateError
model.variables.isExpiryDateErrorVar = vars.value.event_IsExpiryDateErrorInLocal;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:luGzr+qMnUquASL6rcWWyA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:TP+BhtSV4UmUbqFiy+ImIA", callContext.id);
}

};
Controller.registerVariableGroupType("ShopperPortalEU.Refund.RequestRefund.OnParametersChanged$vars", [{
name: "Event_CardDetailsData",
attrName: "event_CardDetailsDataInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Record,
defaultValue: function () {
return new ShopperPortalEU_UI_ComponentsModel.DatatransCardChangeOptionsRec();
},
complexType: ShopperPortalEU_UI_ComponentsModel.DatatransCardChangeOptionsRec
}, {
name: "Event_CardErrorMessage",
attrName: "event_CardErrorMessageInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}, {
name: "Event_IsExpiryDateError",
attrName: "event_IsExpiryDateErrorInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Boolean,
defaultValue: function () {
return false;
}
}]);
Controller.prototype._confirmSubmit$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("ConfirmSubmit");
callContext = controller.callContext(callContext);
var checkValidCardVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.checkValidCardVar = checkValidCardVar;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:fPaorOePW0aLppAmkE2VrA:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.bug_ktdZT0il_jkLuKbIcw/ClientActions.fPaorOePW0aLppAmkE2VrA:gI0uXkQveJV3KRPJlZ4wrg", "ShopperPortalEU", "ConfirmSubmit", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:v9AsSyuX3kGOQJnbAKHzCg", callContext.id);
// ResetCardErrorMessage
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:gjl69F35K0SPwexyrZN_ig", callContext.id);
// CardErrorMessage = ""
model.variables.cardErrorMessageVar = "";
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:gjl69F35K0SPwexyrZN_ig", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// IsExpiryDateError = False
model.variables.isExpiryDateErrorVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:oa+hIKTcZUK8E4DMrjgnOg", callContext.id);
// Execute Action: CheckValidCard
checkValidCardVar.value = ShopperPortalEUController.default.checkValidCard$Action(model.variables.cardDetailsDataVar.expiryDateAttr, model.variables.cardDetailsDataVar, callContext);

// Valid Card ?
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:JnAWYA7PKkiKjR29_6_Y_A", callContext.id) && checkValidCardVar.value.isValidOut)) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:qyh8Z_sfXk+T7ztsncSMlQ", callContext.id);
// Execute Action: ToggleConfirmationPopup
controller._toggleConfirmationPopup$Action("", callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:t_0+oq6k5USuCUc5AvoEcg", callContext.id);
} else {
// ErrorMessage
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:9NMlvREiXkyNMySisAzjbA", callContext.id);
// CardErrorMessage = CheckValidCard.ErrorMessage
model.variables.cardErrorMessageVar = checkValidCardVar.value.errorMessageOut;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:9NMlvREiXkyNMySisAzjbA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// IsExpiryDateError = CheckValidCard.IsExpiryDateError
model.variables.isExpiryDateErrorVar = checkValidCardVar.value.isExpiryDateErrorOut;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:l_Dc58GNVUGjMoNB4BS+sQ", callContext.id);
}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:fPaorOePW0aLppAmkE2VrA", callContext.id);
}

};
Controller.prototype._checkbox_IsSaveCardOnChange$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Checkbox_IsSaveCardOnChange");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:NdldvmP2EkOwPQ37N1wikA:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.bug_ktdZT0il_jkLuKbIcw/ClientActions.NdldvmP2EkOwPQ37N1wikA:Zemwrwm9hR8XF1dVG+bCHA", "ShopperPortalEU", "Checkbox_IsSaveCardOnChange", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:9NsC_ppMHUm0BqMoqPeSKA", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:qfqPYTRcdkmy88fQvhrqGA", callContext.id) && model.variables.isToSaveNewCardVar)) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:zlpEH2b40EeUxqIxkPvA4g", callContext.id);
// Execute Action: ClarityEvent
ShopperPortalEUController.default.clarityEvent$Action("SetAsFutureCard_check", callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ouFRLgDZhkiQg2VSwMUPXw", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ouFRLgDZhkiQg2VSwMUPXw", callContext.id);
}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:NdldvmP2EkOwPQ37N1wikA", callContext.id);
}

};
Controller.prototype._submit$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Submit");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:5Xfc2NHoSUqTZAsZBn7DiQ:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.bug_ktdZT0il_jkLuKbIcw/ClientActions.5Xfc2NHoSUqTZAsZBn7DiQ:K2zQ9feg+b4q+w9dEKtsWw", "ShopperPortalEU", "Submit", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:8JK9rCqD8ka+ljCrElOPIA", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ib7ec2+CSku0aULtz7umIQ", callContext.id);
// IsToSubmitCard = True
model.variables.isToSubmitCardVar = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ib7ec2+CSku0aULtz7umIQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// IsCardSubmitting = True
model.variables.isCardSubmittingVar = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:mUpRf+0PGEOxggmJ0eRFJw", callContext.id);
// Execute Action: ClarityEvent
ShopperPortalEUController.default.clarityEvent$Action("YesAddCard_btn", callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:tYzos6Rb10u5kYrDb03l0A", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:5Xfc2NHoSUqTZAsZBn7DiQ", callContext.id);
}

};
Controller.prototype._onError$Action = function (errorMessageIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnError");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.Refund.RequestRefund.OnError$vars"))());
vars.value.errorMessageInLocal = errorMessageIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:p7vf_G2VjkqfHM4gEX0hnA:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.bug_ktdZT0il_jkLuKbIcw/ClientActions.p7vf_G2VjkqfHM4gEX0hnA:QsIWgi88noGg6qMlHClL4g", "ShopperPortalEU", "OnError", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:goU4gur990yfXpshQmX6Fg", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:BxpfpJF77ECPurL6U+F+tA", callContext.id);
// IsCardSubmitting = False
model.variables.isCardSubmittingVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:BxpfpJF77ECPurL6U+F+tA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// IsToSubmitCard = False
model.variables.isToSubmitCardVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:7UzsLAXb2EC4ZG31cqP4ZQ", callContext.id);
// Execute Action: ErrorMessage2
ShopperPortalEU_UI_ThemeController.default.customMessageTrigger$Action(function () {
var rec = new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customMessageType.error;
rec.titleAttr = vars.value.errorMessageInLocal;
rec.contentAttr = OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.defaultErrorMessage$Action(callContext).errorMessageOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
rec.testIdAttr = "Error";
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:9o_qaQdbk0uHMrqJl3Xg2g", callContext.id);
// Execute Action: CloseConfirmationPopup
controller._closeConfirmationPopup$Action(callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:QpVYSJPWV0e6466KCaUQ0w", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:p7vf_G2VjkqfHM4gEX0hnA", callContext.id);
}

};
Controller.registerVariableGroupType("ShopperPortalEU.Refund.RequestRefund.OnError$vars", [{
name: "ErrorMessage",
attrName: "errorMessageInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);

Controller.prototype.toggleConfirmationPopup$Action = function (eventIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._toggleConfirmationPopup$Action, callContext, eventIn);

};
Controller.prototype.setCardSelected$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._setCardSelected$Action, callContext);

};
Controller.prototype.cardListOnChange$Action = function (currentValueIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._cardListOnChange$Action, callContext, currentValueIn);

};
Controller.prototype.onAfterAuthentication$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onAfterAuthentication$Action, callContext);

};
Controller.prototype.onErrorSavingCard$Action = function (errorMessageIn, isCreateCardGenericErrorIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onErrorSavingCard$Action, callContext, errorMessageIn, isCreateCardGenericErrorIn);

};
Controller.prototype.onInitialize$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onInitialize$Action, callContext);

};
Controller.prototype.onCardSubmitted$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onCardSubmitted$Action, callContext);

};
Controller.prototype.closeConfirmationPopup$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._closeConfirmationPopup$Action, callContext);

};
Controller.prototype.cancel$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._cancel$Action, callContext);

};
Controller.prototype.onParametersChanged$Action = function (event_CardDetailsDataIn, event_CardErrorMessageIn, event_IsExpiryDateErrorIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onParametersChanged$Action, callContext, event_CardDetailsDataIn, event_CardErrorMessageIn, event_IsExpiryDateErrorIn);

};
Controller.prototype.confirmSubmit$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._confirmSubmit$Action, callContext);

};
Controller.prototype.checkbox_IsSaveCardOnChange$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._checkbox_IsSaveCardOnChange$Action, callContext);

};
Controller.prototype.submit$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._submit$Action, callContext);

};
Controller.prototype.onError$Action = function (errorMessageIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onError$Action, callContext, errorMessageIn);

};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:VcUw8y2coUi7OQ+l92mkmQ:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ:1Ox1BferNhnfzrugqQ41yg", "ShopperPortalEU", "Refund", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:bug_ktdZT0il_jkLuKbIcw:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.bug_ktdZT0il_jkLuKbIcw:kPhXWo+r5Z9CS+VWSWch9A", "ShopperPortalEU", "RequestRefund", "NRNodes.WebScreen", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:bug_ktdZT0il_jkLuKbIcw", callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:VcUw8y2coUi7OQ+l92mkmQ", callContext.id);
};
Controller.prototype.onInitializeEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Refund/RequestRefund On Initialize");
return controller.onInitialize$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return ShopperPortalEU_RefundController.default.handleError(ex, this.callContext());
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return ShopperPortalEUController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, ShopperPortalEULanguageResources);
});

define("ShopperPortalEU.Refund.RequestRefund.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"27EVIEBWxEOwiJB_HOLjEQ": {
getter: function (varBag, idService) {
return varBag.vars.value.eventInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"Why4d42wNU6SVKVJickqlg": {
getter: function (varBag, idService) {
return varBag.listFilterByCardSelectedVar.value;
}
},
"h6c1o4WnpEqreEICiYhGqg": {
getter: function (varBag, idService) {
return varBag.vars.value.currentValueInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"TP6TMbJI2k+NvS7hbbHuCg": {
getter: function (varBag, idService) {
return varBag.getFormsRefundListVar.value;
}
},
"3ijuyaLSkUGvB7F7SmGV1A": {
getter: function (varBag, idService) {
return varBag.getCardsVar.value;
}
},
"cEbPArBaa02bCBtqpHZRWA": {
getter: function (varBag, idService) {
return varBag.jSONSerializeRefundSummaryFormListVar.value;
}
},
"X3094Hb5_E6w5LMC_ErNHw": {
getter: function (varBag, idService) {
return varBag.jSONDeserializeFormInfo_WrapperVar.value;
}
},
"zDZ0Lk4oM02gj2Fe1VgI0w": {
getter: function (varBag, idService) {
return varBag.vars.value.errorMessageInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"1hazuWGM2kWlP+JE4N4+AA": {
getter: function (varBag, idService) {
return varBag.vars.value.isCreateCardGenericErrorInLocal;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"8mwPztdheUCUl_StsyEjZA": {
getter: function (varBag, idService) {
return varBag.vars.value.event_CardDetailsDataInLocal;
}
},
"nAWZww2EkUiv3CKRMOm4hA": {
getter: function (varBag, idService) {
return varBag.vars.value.event_CardErrorMessageInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"hCCCbUtsxEOu1uOx_givVQ": {
getter: function (varBag, idService) {
return varBag.vars.value.event_IsExpiryDateErrorInLocal;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"oa+hIKTcZUK8E4DMrjgnOg": {
getter: function (varBag, idService) {
return varBag.checkValidCardVar.value;
}
},
"A5kUif6pnEO_SFJaJTbE3w": {
getter: function (varBag, idService) {
return varBag.vars.value.errorMessageInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"wDS6ZaMQE0miAlgqLKE6+w": {
getter: function (varBag, idService) {
return varBag.model.variables.formsList_ReadyForRefundVar;
}
},
"XHDw2O6MM0qd4rhXBHgKEg": {
getter: function (varBag, idService) {
return varBag.model.variables.refundSummaryFormListVar;
}
},
"wE0sKyRzG0OXASoZ3FGocg": {
getter: function (varBag, idService) {
return varBag.model.variables.cardListVar;
}
},
"4rkG6EwnsEOT0FdwkFwzMQ": {
getter: function (varBag, idService) {
return varBag.model.variables.datatransTokenFallbackVar;
}
},
"OA7J94vIlUWbjI8+ti92sQ": {
getter: function (varBag, idService) {
return varBag.model.variables.cardDetailsDataVar;
}
},
"A_3nGlaeGEW9Ceebdxzjrg": {
getter: function (varBag, idService) {
return varBag.model.variables.isToSubmitCardVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"4A26KRYa+0WzaLt7y9tLGA": {
getter: function (varBag, idService) {
return varBag.model.variables.isCardSubmittingVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"2LGId0wluUyVJ5z9QlAxag": {
getter: function (varBag, idService) {
return varBag.model.variables.isToSaveNewCardVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"YAKVUgfaDEOxpM2aKZNLsg": {
getter: function (varBag, idService) {
return varBag.model.variables.cardErrorMessageVar;
},
dataType: OS.DataTypes.DataTypes.Text
},
"Rfu2ECNNYUeRFDaXSualOw": {
getter: function (varBag, idService) {
return varBag.model.variables.isExpiryDateErrorVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"gK_5A+r_j0OD3kpIdBA5cQ": {
getter: function (varBag, idService) {
return varBag.model.variables.isScreenReadyVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"xYdLjzIAeE28MFHuM5OFnA": {
getter: function (varBag, idService) {
return varBag.model.variables.selectedCardVar;
},
dataType: OS.DataTypes.DataTypes.Text
},
"b4+UDFOHMEqYRFkFAQQ6tQ": {
getter: function (varBag, idService) {
return varBag.model.variables.showConfirmationPopupVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"U63wkE_PlUisMGmBwekmzA": {
getter: function (varBag, idService) {
return varBag.model.variables.purchaseConfirmationCheckVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"bPxu0WaYc0m00qph4rshZg": {
getter: function (varBag, idService) {
return varBag.model.variables.cancelDataAct;
}
},
"i_SR1eeGO0mS2uXaKRCVJw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderLeft"));
})(varBag.model, idService);
}
},
"ZU3cP5CvXkadchPkwycTpg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderCenter"));
})(varBag.model, idService);
}
},
"n9ffsuTs2U+JzMuX8KsWVA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderRight"));
})(varBag.model, idService);
}
},
"ZKkpXVFT00KuZ1GbGFyEUw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"mTzUV7rDpUiQlUb_5CR_Dw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"XJa48yOj+UmxMPCuZ8M+cw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("CardListEmpty"));
})(varBag.model, idService);
}
},
"EA0Y9a1WNEuYYNahMGkQVQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Top"));
})(varBag.model, idService);
}
},
"QjMOOp4QEU6MzBDz5j_hHg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Checkbox"));
})(varBag.model, idService);
}
},
"qhWpeyl0OUGk9XMFcvNKhg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Checkbox_IsSaveCard2"));
})(varBag.model, idService);
}
},
"Fjyu7_qB9Eu1FetfLRCUsA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Label"));
})(varBag.model, idService);
}
},
"Ny3R9r_wsUmR34qdaGSTwg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Bottom"));
})(varBag.model, idService);
}
},
"9ET3SMEGH0CDYCYtkZ2YtQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"r7z8odYJ2UmTIrjdnH2hTA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"JNFDrnV_vU6bw6V3w_aMiQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Top"));
})(varBag.model, idService);
}
},
"hdGhogw43E6cdmkEnqYYow": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("CustomRadioButton"));
})(varBag.model, idService);
}
},
"lA2jYOD43UiBVmKhXcuflQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Left"));
})(varBag.model, idService);
}
},
"iRpQpYY5PEm_7zWEnptRSQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Image"));
})(varBag.model, idService);
}
},
"nMuR0fNfwUSUcQUPAA_lGw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"rHA+Fr95LkyeQXUdn7SS4g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Description"));
})(varBag.model, idService);
}
},
"AD0cIX1FN0qFkB7_JBiESw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Right"));
})(varBag.model, idService);
}
},
"bZAqMMjbLUGslgbyV1lLNg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"xYtKcTmIM0O+HrMFi3_USw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("SelectedContent"));
})(varBag.model, idService);
}
},
"H+g02N5P2UCn_RbswDqGFQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Checkbox"));
})(varBag.model, idService);
}
},
"quHSHg4uuEG7mxpSdMSaKQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Checkbox_IsSaveCard"));
})(varBag.model, idService);
}
},
"BhtQ0Myb3EWYiDMVmmIYOw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Label"));
})(varBag.model, idService);
}
},
"DDRUcvXjDEGyDJroWnq_eA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Bottom"));
})(varBag.model, idService);
}
},
"V8m4v64uj0aVMVnhq7DrLQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"0GO8nfPzD0W5eVmclHIpZQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"AP3zUBwMEUKQQmo9OUXvhg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"tbM23lb3Q0uMEQqPhL+Btg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"KLbSieYqW0+pn9+8Zgs+ng": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("ShowSeeDetailsLink"));
})(varBag.model, idService);
}
},
"doyRRU7q3UOSQb9r9HcNFQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Link"));
})(varBag.model, idService);
}
},
"dkksL_DHTUeXjuc8AfitnQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"CPfgkm9LLkecwkSHnkM96Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("SameCurrency"));
})(varBag.model, idService);
}
},
"XRuHHtdos0qEt2C5oojBiQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("OneForm"));
})(varBag.model, idService);
}
},
"10QQBJEE3Uq+B5qCYI2vxA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"GVVzjBv4uU2zjMrzh_onxA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Checkbox"));
})(varBag.model, idService);
}
},
"yl0xiq5qPU2QZE9eGwmhoQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("PurchaseConfirmationCheckbox"));
})(varBag.model, idService);
}
},
"KtgWEtZ9v0ipEt8Aqb9Hig": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Label"));
})(varBag.model, idService);
}
},
"YQO5G5p2FEafOG_Ro7nPnQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Button"));
})(varBag.model, idService);
}
},
"HZzxpFEsFUiCzaIBUInvrA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"TSrQa7ct4EGBjVr23FPrPA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Popup"));
})(varBag.model, idService);
}
},
"uXQxjs9nl0iWWYWmwxsKzA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"BVtWxyc6qE6zx7WUCigPIw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"dzN7uJOvpEOsURo6c4k79A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Actions"));
})(varBag.model, idService);
}
},
"1gvEdrsVb0q31Gk6EJW9GQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"5zJg7kczjk6iOa4R4lxaHA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Button"));
})(varBag.model, idService);
}
},
"4TK9gJT7yU27etEb1GQ2XQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"KgRXqdV+c0OF7Ftit++wow": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Button"));
})(varBag.model, idService);
}
},
"wEXDUGC8TEu+S9rPfdvzxw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"niCkwCqAI0uPmoCKJHIYgQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Bottom"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
