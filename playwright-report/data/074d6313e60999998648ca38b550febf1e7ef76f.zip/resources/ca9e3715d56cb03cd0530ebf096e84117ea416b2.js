define("ShopperPortalEU_DataSync.model$TranslationItemList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CMS_IS.model", "ShopperPortalEU_DataSync.model", "ShopperPortalEU_CMS_IS.model$TranslationItemRec", "ShopperPortalEU_DataSync.referencesHealth", "ShopperPortalEU_DataSync.referencesHealth$ShopperPortalEU_CMS_IS"], function (exports, OutSystems, ShopperPortalEU_CMS_ISModel, ShopperPortalEU_DataSyncModel) {
var OS = OutSystems.Internal;
var TranslationItemList = (function (_super) {
__extends(TranslationItemList, _super);
function TranslationItemList(defaults) {
_super.apply(this, arguments);
}
TranslationItemList.itemType = ShopperPortalEU_CMS_ISModel.TranslationItemRec;
return TranslationItemList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_DataSyncModel.TranslationItemList = TranslationItemList;

});
define("ShopperPortalEU_DataSync.model$ResourcesList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CMS_IS.model", "ShopperPortalEU_DataSync.model", "ShopperPortalEU_CMS_IS.model$ResourcesRec", "ShopperPortalEU_DataSync.referencesHealth", "ShopperPortalEU_DataSync.referencesHealth$ShopperPortalEU_CMS_IS"], function (exports, OutSystems, ShopperPortalEU_CMS_ISModel, ShopperPortalEU_DataSyncModel) {
var OS = OutSystems.Internal;
var ResourcesList = (function (_super) {
__extends(ResourcesList, _super);
function ResourcesList(defaults) {
_super.apply(this, arguments);
}
ResourcesList.itemType = ShopperPortalEU_CMS_ISModel.ResourcesRec;
return ResourcesList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_DataSyncModel.ResourcesList = ResourcesList;

});
define("ShopperPortalEU_DataSync.model$CountryRuleTranslationItemList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CMS_IS.model", "ShopperPortalEU_DataSync.model", "ShopperPortalEU_CMS_IS.model$CountryRuleTranslationItemRec", "ShopperPortalEU_DataSync.referencesHealth", "ShopperPortalEU_DataSync.referencesHealth$ShopperPortalEU_CMS_IS"], function (exports, OutSystems, ShopperPortalEU_CMS_ISModel, ShopperPortalEU_DataSyncModel) {
var OS = OutSystems.Internal;
var CountryRuleTranslationItemList = (function (_super) {
__extends(CountryRuleTranslationItemList, _super);
function CountryRuleTranslationItemList(defaults) {
_super.apply(this, arguments);
}
CountryRuleTranslationItemList.itemType = ShopperPortalEU_CMS_ISModel.CountryRuleTranslationItemRec;
return CountryRuleTranslationItemList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_DataSyncModel.CountryRuleTranslationItemList = CountryRuleTranslationItemList;

});
define("ShopperPortalEU_DataSync.model$TranslationRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CMS_IS.model", "ShopperPortalEU_DataSync.model", "ShopperPortalEU_CMS_IS.model$TranslationRec", "ShopperPortalEU_DataSync.referencesHealth", "ShopperPortalEU_DataSync.referencesHealth$ShopperPortalEU_CMS_IS"], function (exports, OutSystems, ShopperPortalEU_CMS_ISModel, ShopperPortalEU_DataSyncModel) {
var OS = OutSystems.Internal;
var TranslationRecord = (function (_super) {
__extends(TranslationRecord, _super);
function TranslationRecord(defaults) {
_super.apply(this, arguments);
}
TranslationRecord.attributesToDeclare = function () {
return [
this.attr("Translation", "translationAttr", "Translation", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_CMS_ISModel.TranslationRec());
}, true, ShopperPortalEU_CMS_ISModel.TranslationRec)
].concat(_super.attributesToDeclare.call(this));
};
TranslationRecord.fromStructure = function (str) {
return new TranslationRecord(new TranslationRecord.RecordClass({
translationAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
TranslationRecord._isAnonymousRecord = true;
TranslationRecord.UniqueId = "7b111022-7bcd-8b43-bcf2-686cc0602247";
TranslationRecord.init();
return TranslationRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_DataSyncModel.TranslationRecord = TranslationRecord;

});
define("ShopperPortalEU_DataSync.model$TranslationRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_DataSync.model", "ShopperPortalEU_DataSync.model$TranslationRecord"], function (exports, OutSystems, ShopperPortalEU_DataSyncModel) {
var OS = OutSystems.Internal;
var TranslationRecordList = (function (_super) {
__extends(TranslationRecordList, _super);
function TranslationRecordList(defaults) {
_super.apply(this, arguments);
}
TranslationRecordList.itemType = ShopperPortalEU_DataSyncModel.TranslationRecord;
return TranslationRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_DataSyncModel.TranslationRecordList = TranslationRecordList;

});
define("ShopperPortalEU_DataSync.model$ResourcesRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CMS_IS.model", "ShopperPortalEU_DataSync.model", "ShopperPortalEU_CMS_IS.model$ResourcesRec", "ShopperPortalEU_DataSync.referencesHealth", "ShopperPortalEU_DataSync.referencesHealth$ShopperPortalEU_CMS_IS"], function (exports, OutSystems, ShopperPortalEU_CMS_ISModel, ShopperPortalEU_DataSyncModel) {
var OS = OutSystems.Internal;
var ResourcesRecord = (function (_super) {
__extends(ResourcesRecord, _super);
function ResourcesRecord(defaults) {
_super.apply(this, arguments);
}
ResourcesRecord.attributesToDeclare = function () {
return [
this.attr("Resources", "resourcesAttr", "Resources", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_CMS_ISModel.ResourcesRec());
}, true, ShopperPortalEU_CMS_ISModel.ResourcesRec)
].concat(_super.attributesToDeclare.call(this));
};
ResourcesRecord.fromStructure = function (str) {
return new ResourcesRecord(new ResourcesRecord.RecordClass({
resourcesAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ResourcesRecord._isAnonymousRecord = true;
ResourcesRecord.UniqueId = "39c19627-2645-c065-4448-4d5864dc7fe5";
ResourcesRecord.init();
return ResourcesRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_DataSyncModel.ResourcesRecord = ResourcesRecord;

});
define("ShopperPortalEU_DataSync.model$ResourcesRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_DataSync.model", "ShopperPortalEU_DataSync.model$ResourcesRecord"], function (exports, OutSystems, ShopperPortalEU_DataSyncModel) {
var OS = OutSystems.Internal;
var ResourcesRecordList = (function (_super) {
__extends(ResourcesRecordList, _super);
function ResourcesRecordList(defaults) {
_super.apply(this, arguments);
}
ResourcesRecordList.itemType = ShopperPortalEU_DataSyncModel.ResourcesRecord;
return ResourcesRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_DataSyncModel.ResourcesRecordList = ResourcesRecordList;

});
define("ShopperPortalEU_DataSync.model$CountryRuleTranslationRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CMS_IS.model", "ShopperPortalEU_DataSync.model", "ShopperPortalEU_CMS_IS.model$CountryRuleTranslationRec", "ShopperPortalEU_DataSync.referencesHealth", "ShopperPortalEU_DataSync.referencesHealth$ShopperPortalEU_CMS_IS"], function (exports, OutSystems, ShopperPortalEU_CMS_ISModel, ShopperPortalEU_DataSyncModel) {
var OS = OutSystems.Internal;
var CountryRuleTranslationRecord = (function (_super) {
__extends(CountryRuleTranslationRecord, _super);
function CountryRuleTranslationRecord(defaults) {
_super.apply(this, arguments);
}
CountryRuleTranslationRecord.attributesToDeclare = function () {
return [
this.attr("CountryRuleTranslation", "countryRuleTranslationAttr", "CountryRuleTranslation", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_CMS_ISModel.CountryRuleTranslationRec());
}, true, ShopperPortalEU_CMS_ISModel.CountryRuleTranslationRec)
].concat(_super.attributesToDeclare.call(this));
};
CountryRuleTranslationRecord.fromStructure = function (str) {
return new CountryRuleTranslationRecord(new CountryRuleTranslationRecord.RecordClass({
countryRuleTranslationAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CountryRuleTranslationRecord._isAnonymousRecord = true;
CountryRuleTranslationRecord.UniqueId = "77a1a134-f967-0c54-aaae-d97809b3f35e";
CountryRuleTranslationRecord.init();
return CountryRuleTranslationRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_DataSyncModel.CountryRuleTranslationRecord = CountryRuleTranslationRecord;

});
define("ShopperPortalEU_DataSync.model$CountryRuleTranslationRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_DataSync.model", "ShopperPortalEU_DataSync.model$CountryRuleTranslationRecord"], function (exports, OutSystems, ShopperPortalEU_DataSyncModel) {
var OS = OutSystems.Internal;
var CountryRuleTranslationRecordList = (function (_super) {
__extends(CountryRuleTranslationRecordList, _super);
function CountryRuleTranslationRecordList(defaults) {
_super.apply(this, arguments);
}
CountryRuleTranslationRecordList.itemType = ShopperPortalEU_DataSyncModel.CountryRuleTranslationRecord;
return CountryRuleTranslationRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_DataSyncModel.CountryRuleTranslationRecordList = CountryRuleTranslationRecordList;

});
define("ShopperPortalEU_DataSync.model$TranslationItemRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CMS_IS.model", "ShopperPortalEU_DataSync.model", "ShopperPortalEU_CMS_IS.model$TranslationItemRec", "ShopperPortalEU_DataSync.referencesHealth", "ShopperPortalEU_DataSync.referencesHealth$ShopperPortalEU_CMS_IS"], function (exports, OutSystems, ShopperPortalEU_CMS_ISModel, ShopperPortalEU_DataSyncModel) {
var OS = OutSystems.Internal;
var TranslationItemRecord = (function (_super) {
__extends(TranslationItemRecord, _super);
function TranslationItemRecord(defaults) {
_super.apply(this, arguments);
}
TranslationItemRecord.attributesToDeclare = function () {
return [
this.attr("TranslationItem", "translationItemAttr", "TranslationItem", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_CMS_ISModel.TranslationItemRec());
}, true, ShopperPortalEU_CMS_ISModel.TranslationItemRec)
].concat(_super.attributesToDeclare.call(this));
};
TranslationItemRecord.fromStructure = function (str) {
return new TranslationItemRecord(new TranslationItemRecord.RecordClass({
translationItemAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
TranslationItemRecord._isAnonymousRecord = true;
TranslationItemRecord.UniqueId = "952c954f-57df-ece3-f10f-2cbe60a3db6c";
TranslationItemRecord.init();
return TranslationItemRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_DataSyncModel.TranslationItemRecord = TranslationItemRecord;

});
define("ShopperPortalEU_DataSync.model$TranslationItemRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_DataSync.model", "ShopperPortalEU_DataSync.model$TranslationItemRecord"], function (exports, OutSystems, ShopperPortalEU_DataSyncModel) {
var OS = OutSystems.Internal;
var TranslationItemRecordList = (function (_super) {
__extends(TranslationItemRecordList, _super);
function TranslationItemRecordList(defaults) {
_super.apply(this, arguments);
}
TranslationItemRecordList.itemType = ShopperPortalEU_DataSyncModel.TranslationItemRecord;
return TranslationItemRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_DataSyncModel.TranslationItemRecordList = TranslationItemRecordList;

});
define("ShopperPortalEU_DataSync.model$TranslationList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CMS_IS.model", "ShopperPortalEU_DataSync.model", "ShopperPortalEU_CMS_IS.model$TranslationRec", "ShopperPortalEU_DataSync.referencesHealth", "ShopperPortalEU_DataSync.referencesHealth$ShopperPortalEU_CMS_IS"], function (exports, OutSystems, ShopperPortalEU_CMS_ISModel, ShopperPortalEU_DataSyncModel) {
var OS = OutSystems.Internal;
var TranslationList = (function (_super) {
__extends(TranslationList, _super);
function TranslationList(defaults) {
_super.apply(this, arguments);
}
TranslationList.itemType = ShopperPortalEU_CMS_ISModel.TranslationRec;
return TranslationList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_DataSyncModel.TranslationList = TranslationList;

});
define("ShopperPortalEU_DataSync.model$CountryRuleTranslationList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CMS_IS.model", "ShopperPortalEU_DataSync.model", "ShopperPortalEU_CMS_IS.model$CountryRuleTranslationRec", "ShopperPortalEU_DataSync.referencesHealth", "ShopperPortalEU_DataSync.referencesHealth$ShopperPortalEU_CMS_IS"], function (exports, OutSystems, ShopperPortalEU_CMS_ISModel, ShopperPortalEU_DataSyncModel) {
var OS = OutSystems.Internal;
var CountryRuleTranslationList = (function (_super) {
__extends(CountryRuleTranslationList, _super);
function CountryRuleTranslationList(defaults) {
_super.apply(this, arguments);
}
CountryRuleTranslationList.itemType = ShopperPortalEU_CMS_ISModel.CountryRuleTranslationRec;
return CountryRuleTranslationList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_DataSyncModel.CountryRuleTranslationList = CountryRuleTranslationList;

});
define("ShopperPortalEU_DataSync.model$CountryRuleTranslationItemRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CMS_IS.model", "ShopperPortalEU_DataSync.model", "ShopperPortalEU_CMS_IS.model$CountryRuleTranslationItemRec", "ShopperPortalEU_DataSync.referencesHealth", "ShopperPortalEU_DataSync.referencesHealth$ShopperPortalEU_CMS_IS"], function (exports, OutSystems, ShopperPortalEU_CMS_ISModel, ShopperPortalEU_DataSyncModel) {
var OS = OutSystems.Internal;
var CountryRuleTranslationItemRecord = (function (_super) {
__extends(CountryRuleTranslationItemRecord, _super);
function CountryRuleTranslationItemRecord(defaults) {
_super.apply(this, arguments);
}
CountryRuleTranslationItemRecord.attributesToDeclare = function () {
return [
this.attr("CountryRuleTranslationItem", "countryRuleTranslationItemAttr", "CountryRuleTranslationItem", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_CMS_ISModel.CountryRuleTranslationItemRec());
}, true, ShopperPortalEU_CMS_ISModel.CountryRuleTranslationItemRec)
].concat(_super.attributesToDeclare.call(this));
};
CountryRuleTranslationItemRecord.fromStructure = function (str) {
return new CountryRuleTranslationItemRecord(new CountryRuleTranslationItemRecord.RecordClass({
countryRuleTranslationItemAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CountryRuleTranslationItemRecord._isAnonymousRecord = true;
CountryRuleTranslationItemRecord.UniqueId = "f78a22a8-88fe-4a98-3f6c-89f5e556c113";
CountryRuleTranslationItemRecord.init();
return CountryRuleTranslationItemRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_DataSyncModel.CountryRuleTranslationItemRecord = CountryRuleTranslationItemRecord;

});
define("ShopperPortalEU_DataSync.model$CountryRuleTranslationItemRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_DataSync.model", "ShopperPortalEU_DataSync.model$CountryRuleTranslationItemRecord"], function (exports, OutSystems, ShopperPortalEU_DataSyncModel) {
var OS = OutSystems.Internal;
var CountryRuleTranslationItemRecordList = (function (_super) {
__extends(CountryRuleTranslationItemRecordList, _super);
function CountryRuleTranslationItemRecordList(defaults) {
_super.apply(this, arguments);
}
CountryRuleTranslationItemRecordList.itemType = ShopperPortalEU_DataSyncModel.CountryRuleTranslationItemRecord;
return CountryRuleTranslationItemRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_DataSyncModel.CountryRuleTranslationItemRecordList = CountryRuleTranslationItemRecordList;

});
define("ShopperPortalEU_DataSync.model", ["exports", "OutSystems/ClientRuntime/Main"], function (exports, OutSystems) {
var OS = OutSystems.Internal;
var ShopperPortalEU_DataSyncModel = exports;
Object.defineProperty(ShopperPortalEU_DataSyncModel, "module", {
get: function () {
return OS.ApplicationInfo.getModules()["cdd73307-91bd-4df2-8f2c-c1d3ed699476"];
}
});

ShopperPortalEU_DataSyncModel.staticEntities = {};
});
