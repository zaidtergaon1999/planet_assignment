define("ShopperPortalEU_Bootstrap_CS.referencesHealth$ServiceCenter", [], function () {
// Reference to producer 'ServiceCenter' is OK.
});
define("ShopperPortalEU_Bootstrap_CS.referencesHealth$Text", [], function () {
// Reference to producer 'Text' is OK.
});
define("ShopperPortalEU_Bootstrap_CS.referencesHealth$Users", [], function () {
// Reference to producer 'Users' is OK.
});
define("ShopperPortalEU_Bootstrap_CS.referencesHealth", [], function () {
});
