define("ShopperPortalEU_DataSync.referencesHealth$ServiceCenter", [], function () {
// Reference to producer 'ServiceCenter' is OK.
});
define("ShopperPortalEU_DataSync.referencesHealth$ShopperPortalEU_CMS_IS", [], function () {
// Reference to producer 'ShopperPortalEU_CMS_IS' is OK.
});
define("ShopperPortalEU_DataSync.referencesHealth$Users", [], function () {
// Reference to producer 'Users' is OK.
});
define("ShopperPortalEU_DataSync.referencesHealth", [], function () {
});
