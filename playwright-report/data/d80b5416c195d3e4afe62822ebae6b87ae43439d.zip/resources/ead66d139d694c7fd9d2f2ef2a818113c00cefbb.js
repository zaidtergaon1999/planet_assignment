class customBottomBar {
  constructor(id) {
    this.class = 'custom-bottom-bar';
    this.element = document.getElementById(id);
    this.listeners = {
      _resize: this._resize.bind(this)
    };
    this.resizeObserver = new ResizeObserver((x) => x.forEach(this.listeners._resize));
    this._build();
  }
  _setCSSVars() {
    let el = this.element,
      h = 0;
    if (el.isConnected) {
      h = el.offsetHeight;
    } else {
      el = document.body.getElementsByClassName(this.class)[0];
      if (el) {
        h = el.offsetHeight;
      }
    }
    document.body.style.setProperty('--custom-bottom-bar-height', `${h}px`);
  }
  _resize(entry) {
    this._setCSSVars();
  }
  _build() {
    this._setCSSVars();
    this.resizeObserver.observe(this.element);
  }
  parametersChanged(options) {
    this.options = options;
  }
}