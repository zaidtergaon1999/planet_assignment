define("ShopperPortalEU_UI_Theme.ShopperPortalEUUIThemeLayoutsComponents.HeaderSteps.mvc$model", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRec"], function (OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("Obj", "objVar", "Obj", true, false, OS.DataTypes.DataTypes.Object, function () {
return null;
}, false), 
this.attr("Steps", "stepsVar", "Steps", true, false, OS.DataTypes.DataTypes.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new OS.DataTypes.IntegerList());
}, false, OS.DataTypes.IntegerList), 
this.attr("Options", "optionsIn", "Options", true, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ThemeModel.HeaderStepsOptionsRec());
}, false, ShopperPortalEU_UI_ThemeModel.HeaderStepsOptionsRec), 
this.attr("_optionsInDataFetchStatus", "_optionsInDataFetchStatus", "_optionsInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return false;
}
});

Model.prototype.setInputs = function (inputs) {
if("Options" in inputs) {
this.variables.optionsIn = inputs.Options;
if("_optionsInDataFetchStatus" in inputs) {
this.variables._optionsInDataFetchStatus = inputs._optionsInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "ShopperPortalEUUIThemeLayoutsComponents.HeaderSteps");
});
define("ShopperPortalEU_UI_Theme.ShopperPortalEUUIThemeLayoutsComponents.HeaderSteps.mvc$view", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.controller", "react", "OutSystems/ReactView/Main", "ShopperPortalEU_UI_Theme.ShopperPortalEUUIThemeLayoutsComponents.HeaderSteps.mvc$model", "ShopperPortalEU_UI_Theme.ShopperPortalEUUIThemeLayoutsComponents.HeaderSteps.mvc$controller", "OutSystems/ReactWidgets/Main", "ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRec"], function (OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ThemeController, React, OSView, ShopperPortalEU_UI_Theme_ShopperPortalEUUIThemeLayoutsComponents_HeaderSteps_mvc_model, ShopperPortalEU_UI_Theme_ShopperPortalEUUIThemeLayoutsComponents_HeaderSteps_mvc_controller, OSWidgets) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            var thisIsInstanceOfSuper = this instanceof _super;
            if (thisIsInstanceOfSuper == false) {
                return;
            }

            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "ShopperPortalEUUIThemeLayoutsComponents.HeaderSteps";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css"];
        };
        View.getJsDependencies = function() {
            return ["scripts/ShopperPortalEU_UI_Theme.headerSteps.js"];
        };
        View.getBlocks = function() {
            return [];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return ShopperPortalEU_UI_Theme_ShopperPortalEUUIThemeLayoutsComponents_HeaderSteps_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return ShopperPortalEU_UI_Theme_ShopperPortalEUUIThemeLayoutsComponents_HeaderSteps_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(OSWidgets.List, {
animateItems: false,
extendedProperties: {
"disable-virtualization": "True",
"data-testid": "HeaderSteps"
},
gridProperties: {
classes: "OSFillParent"
},
mode: /*Default*/ 0,
source: model.variables.stepsVar,
style: "header-steps ph",
tag: "div",
_idProps: {
service: idService,
name: "Element"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new IteratorPlaceholderContent(function (idService, callContext) {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
"data-testid": ("HeaderStep_" + (model.variables.stepsVar.getCurrent(callContext.iterationContext)).toString())
},
style: model.getCachedValue(idService.getId("EFSZBQM+_0+kvRbKrZoMKg.Style"), function () {
return (("header-steps__item" + " header-steps__item--") + (((model.variables.stepsVar.getCurrent(callContext.iterationContext) < model.variables.optionsIn.currentStepAttr)) ? ("previous") : ((((model.variables.stepsVar.getCurrent(callContext.iterationContext) === model.variables.optionsIn.currentStepAttr)) ? ("current") : ("next")))));
}, function () {
return model.variables.stepsVar.getCurrent(callContext.iterationContext);
}, function () {
return model.variables.optionsIn.currentStepAttr;
}),
visible: true,
_idProps: {
service: idService,
uuid: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
style_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._optionsInDataFetchStatus),
_dependencies: []
})];
}, callContext, idService, "1")
},
_dependencies: [asPrimitiveValue(model.variables._optionsInDataFetchStatus), asPrimitiveValue(model.variables.optionsIn.currentStepAttr)]
}));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("ShopperPortalEU_UI_Theme.ShopperPortalEUUIThemeLayoutsComponents.HeaderSteps.mvc$controller", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.controller", "ShopperPortalEU_UI_Theme.languageResources", "ShopperPortalEU_UI_Theme.ShopperPortalEUUIThemeLayoutsComponents.HeaderSteps.mvc$debugger", "ShopperPortalEU_UI_Theme.ShopperPortalEUUIThemeLayoutsComponents.HeaderSteps.mvc$controller.OnParametersChanged.ParametersChangedJS", "ShopperPortalEU_UI_Theme.ShopperPortalEUUIThemeLayoutsComponents.HeaderSteps.mvc$controller.OnReady.InitializeJS", "ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRec"], function (OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ThemeController, ShopperPortalEU_UI_ThemeLanguageResources, ShopperPortalEU_UI_Theme_ShopperPortalEUUIThemeLayoutsComponents_HeaderSteps_mvc_Debugger, ShopperPortalEU_UI_Theme_ShopperPortalEUUIThemeLayoutsComponents_HeaderSteps_mvc_controller_OnParametersChanged_ParametersChangedJS, ShopperPortalEU_UI_Theme_ShopperPortalEUUIThemeLayoutsComponents_HeaderSteps_mvc_controller_OnReady_InitializeJS) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = false;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._onParametersChanged$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnParametersChanged");
callContext = controller.callContext(callContext);
var optionsJSONVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.JSONSerializeOutputType());
varBag.callContext = callContext;
varBag.optionsJSONVar = optionsJSONVar;
try {OutSystemsDebugger.push("1ohZxgV1_kKH2z+Fu01SDQ:u6foCP6BjkqjXywzzKywqQ:/NRWebFlows.uRd0Q1laQ0yzNZQMUt7Aug/NodesShownInESpaceTree.1pMyrcFMRUCehN4yrXo5Fw/ClientActions.u6foCP6BjkqjXywzzKywqQ:lcozRQXBBrvJGNiAI4iDTA", "ShopperPortalEU_UI_Theme", "OnParametersChanged", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:Arr3I_HxIUC8UPCqJYWZOQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:7H2OmgrVaU65SyuO8OJL2w", callContext.id);
// Execute Action: SetSteps
controller._setSteps$Action(callContext);
if((OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:g1fuvhNyjUCExbZXt8Hbyg", callContext.id) && ((model.variables.objVar) !== (OS.BuiltinFunctions.nullObject())))) {
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:+hAwyv+_PEGPBJglpOZYzw", callContext.id);
// JSON Serialize: OptionsJSON
optionsJSONVar.value.jSONOut = OS.JSONUtils.serializeToJSON(model.variables.optionsIn, true, false);
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:rbCa4pRI8UyUttb1rzQKbQ", callContext.id);
// Parameters change method.
controller.safeExecuteJSNode(ShopperPortalEU_UI_Theme_ShopperPortalEUUIThemeLayoutsComponents_HeaderSteps_mvc_controller_OnParametersChanged_ParametersChangedJS, "ParametersChanged", "OnParametersChanged", {
Options: OS.DataConversion.JSNodeParamConverter.to(optionsJSONVar.value.jSONOut, OS.DataTypes.DataTypes.Text),
Obj: OS.DataConversion.JSNodeParamConverter.to(model.variables.objVar, OS.DataTypes.DataTypes.Object)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:DrQZUpWWD0qvz5lFf25emw", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:PfHaEIbkUkK50lDCv2bR2A", callContext.id);
}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("1ohZxgV1_kKH2z+Fu01SDQ:u6foCP6BjkqjXywzzKywqQ", callContext.id);
}

};
Controller.prototype._onReady$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnReady");
callContext = controller.callContext(callContext);
var initializeJSResult = new OS.DataTypes.VariableHolder();
var optionsJSONVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.JSONSerializeOutputType());
varBag.callContext = callContext;
varBag.initializeJSResult = initializeJSResult;
varBag.optionsJSONVar = optionsJSONVar;
try {OutSystemsDebugger.push("1ohZxgV1_kKH2z+Fu01SDQ:SwYaOS1FAky5dmSwhW86Tg:/NRWebFlows.uRd0Q1laQ0yzNZQMUt7Aug/NodesShownInESpaceTree.1pMyrcFMRUCehN4yrXo5Fw/ClientActions.SwYaOS1FAky5dmSwhW86Tg:tbYaOn6bjsneqHmugfyNGw", "ShopperPortalEU_UI_Theme", "OnReady", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:fYWADl2hCESCJ59Gva5HQQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:1Fu1HE64T0+CZiZiaYWwHg", callContext.id);
// JSON Serialize: OptionsJSON
optionsJSONVar.value.jSONOut = OS.JSONUtils.serializeToJSON(model.variables.optionsIn, true, false);
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:G17MWnb_y0q2N6LFSb7wnw", callContext.id);
// Initialize component.
initializeJSResult.value = controller.safeExecuteJSNode(ShopperPortalEU_UI_Theme_ShopperPortalEUUIThemeLayoutsComponents_HeaderSteps_mvc_controller_OnReady_InitializeJS, "Initialize", "OnReady", {
ElementId: OS.DataConversion.JSNodeParamConverter.to(idService.getId("Element"), OS.DataTypes.DataTypes.Text),
Options: OS.DataConversion.JSNodeParamConverter.to(optionsJSONVar.value.jSONOut, OS.DataTypes.DataTypes.Text),
Obj: OS.DataConversion.JSNodeParamConverter.to(null, OS.DataTypes.DataTypes.Object)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Theme.ShopperPortalEUUIThemeLayoutsComponents.HeaderSteps.OnReady$initializeJSResult"))();
jsNodeResult.objOut = OS.DataConversion.JSNodeParamConverter.from($parameters.Obj, OS.DataTypes.DataTypes.Object);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:fQ4Jt1cUkUidEK7VcqL2hQ", callContext.id);
// Obj = Initialize.Obj
model.variables.objVar = initializeJSResult.value.objOut;
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:uOvoPSgBokS7CeOyBz0Z9w", callContext.id);
// Execute Action: SetSteps
controller._setSteps$Action(callContext);
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:a24j70yrSEK+1Y9t4ZxOrA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("1ohZxgV1_kKH2z+Fu01SDQ:SwYaOS1FAky5dmSwhW86Tg", callContext.id);
}

};
Controller.registerVariableGroupType("ShopperPortalEU_UI_Theme.ShopperPortalEUUIThemeLayoutsComponents.HeaderSteps.OnReady$initializeJSResult", [{
name: "Obj",
attrName: "objOut",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Object,
defaultValue: function () {
return null;
}
}]);
Controller.prototype._setSteps$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("SetSteps");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Theme.ShopperPortalEUUIThemeLayoutsComponents.HeaderSteps.SetSteps$vars"))());
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("1ohZxgV1_kKH2z+Fu01SDQ:KkSaiWh9dU2YqdkGvVycGg:/NRWebFlows.uRd0Q1laQ0yzNZQMUt7Aug/NodesShownInESpaceTree.1pMyrcFMRUCehN4yrXo5Fw/ClientActions.KkSaiWh9dU2YqdkGvVycGg:iWgyxb7B8UKBqosXYg6k2w", "ShopperPortalEU_UI_Theme", "SetSteps", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:y_AEQnm4QkSogDufAHmxCw", callContext.id);
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:Mei5aPGnkkGAyqK+HhBJkw", callContext.id);
// Counter = 0
vars.value.counterVar = 0;
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:0ly91yv4L06JzqF3anRvAg", callContext.id);
// Execute Action: ListClear
OS.SystemActions.listClear(model.variables.stepsVar, callContext);
while ((OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:rhEt7oq26UeWfQ59wQCxSg", callContext.id) && (vars.value.counterVar < model.variables.optionsIn.stepsAttr))) {
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:i7vEsIZo6Ee19Oi8oTX1Tg", callContext.id);
// Counter = Counter + 1
vars.value.counterVar = (vars.value.counterVar + 1);
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:Bk7xOuXogUeHoYTHR+LpRg", callContext.id);
// Execute Action: ListAppend
OS.SystemActions.listAppend(model.variables.stepsVar, vars.value.counterVar, callContext);
}

OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:srGJNJZZgkaUXcRgugdHTQ", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("1ohZxgV1_kKH2z+Fu01SDQ:KkSaiWh9dU2YqdkGvVycGg", callContext.id);
}

};
Controller.registerVariableGroupType("ShopperPortalEU_UI_Theme.ShopperPortalEUUIThemeLayoutsComponents.HeaderSteps.SetSteps$vars", [{
name: "Counter",
attrName: "counterVar",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Integer,
defaultValue: function () {
return 0;
}
}]);

Controller.prototype.onParametersChanged$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onParametersChanged$Action, callContext);

};
Controller.prototype.onReady$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onReady$Action, callContext);

};
Controller.prototype.setSteps$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._setSteps$Action, callContext);

};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("1ohZxgV1_kKH2z+Fu01SDQ:uRd0Q1laQ0yzNZQMUt7Aug:/NRWebFlows.uRd0Q1laQ0yzNZQMUt7Aug:AOdtJWIZ_kUN4hGD9hTAnA", "ShopperPortalEU_UI_Theme", "ShopperPortalEUUIThemeLayoutsComponents", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("1ohZxgV1_kKH2z+Fu01SDQ:1pMyrcFMRUCehN4yrXo5Fw:/NRWebFlows.uRd0Q1laQ0yzNZQMUt7Aug/NodesShownInESpaceTree.1pMyrcFMRUCehN4yrXo5Fw:Uw2YXn37V62W+2RNBxZXoA", "ShopperPortalEU_UI_Theme", "HeaderSteps", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("1ohZxgV1_kKH2z+Fu01SDQ:1pMyrcFMRUCehN4yrXo5Fw", callContext.id);
OutSystemsDebugger.pop("1ohZxgV1_kKH2z+Fu01SDQ:uRd0Q1laQ0yzNZQMUt7Aug", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "ShopperPortalEUUIThemeLayoutsComponents/HeaderSteps On Ready");
return controller.onReady$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "ShopperPortalEUUIThemeLayoutsComponents/HeaderSteps On Parameters Changed");
return controller.onParametersChanged$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return ShopperPortalEU_UI_ThemeController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, ShopperPortalEU_UI_ThemeLanguageResources);
});
define("ShopperPortalEU_UI_Theme.ShopperPortalEUUIThemeLayoutsComponents.HeaderSteps.mvc$controller.OnParametersChanged.ParametersChangedJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.Obj.parametersChanged(JSON.parse($parameters.Options));
};
});
define("ShopperPortalEU_UI_Theme.ShopperPortalEUUIThemeLayoutsComponents.HeaderSteps.mvc$controller.OnReady.InitializeJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.Obj = new headerSteps($parameters.ElementId,JSON.parse($parameters.Options));
};
});

define("ShopperPortalEU_UI_Theme.ShopperPortalEUUIThemeLayoutsComponents.HeaderSteps.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"+hAwyv+_PEGPBJglpOZYzw": {
getter: function (varBag, idService) {
return varBag.optionsJSONVar.value;
}
},
"rbCa4pRI8UyUttb1rzQKbQ": {
getter: function (varBag, idService) {
return varBag.parametersChangedJSResult.value;
}
},
"1Fu1HE64T0+CZiZiaYWwHg": {
getter: function (varBag, idService) {
return varBag.optionsJSONVar.value;
}
},
"G17MWnb_y0q2N6LFSb7wnw": {
getter: function (varBag, idService) {
return varBag.initializeJSResult.value;
}
},
"crHwQkhvVk6I805dzvm_Xw": {
getter: function (varBag, idService) {
return varBag.vars.value.counterVar;
},
dataType: OS.DataTypes.DataTypes.Integer
},
"1czIQiti3kyhNIwwM2a8KA": {
getter: function (varBag, idService) {
return varBag.model.variables.objVar;
},
dataType: OS.DataTypes.DataTypes.Object
},
"E+9hwKmuBkqrJHUEKt5N2w": {
getter: function (varBag, idService) {
return varBag.model.variables.stepsVar;
}
},
"lpM3SDyEn0yYlDrjbp5v2A": {
getter: function (varBag, idService) {
return varBag.model.variables.optionsIn;
}
},
"zYmNriBD40+yGpc5RCae2Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Element"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
