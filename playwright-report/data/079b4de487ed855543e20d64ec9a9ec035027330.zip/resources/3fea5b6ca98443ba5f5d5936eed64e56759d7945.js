class unescapedHTML {
  constructor(id, options) {
    this.element = document.getElementById(id);
    this.options = options;
    this._build();
  }
  _set() {
    this.element.innerHTML = this.options.html;
  }
  _build() {
    this._set();
  }
  parametersChanged(options) {
    this.options = options;
    this._set();
  }
}