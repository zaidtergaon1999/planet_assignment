class customInput {
    constructor(id, options) {
        this.class = 'custom-input';
        this.element = document.getElementById(id);
        this.elements = {
            input: this.element.firstElementChild.nextElementSibling.firstElementChild.querySelector('[data-input]'),
            label: this.element.firstElementChild.querySelector('label'),
            validationMessage: null,
            footer: {
                maxLengthCounter: this.element.lastElementChild.lastElementChild
            }
        };
        this.stateClasses = {
            notValid: this.class.concat('--not-valid'),
            disabled: this.class.concat('--disabled')
        };
        this.attributes = {
            maxLength: null
        };
        this.options = options;
        this._build();
    }
    _setMaxLengthCounter() {
        this.elements.footer.maxLengthCounter.innerText = `${this.elements.input.value.length}/${this.attributes.maxLength}`;
    }
    _inputAttributes() {
        if (this.elements.input) {
            this.elements.input.disabled ? this.element.classList.add(this.stateClasses.disabled) : this.element.classList.remove(this.stateClasses.disabled);
            if (this.elements.input.classList.contains('not-valid')) {
                this.element.classList.add(this.stateClasses.notValid);
                this.elements.validationMessage = this.elements.input.nextElementSibling;
            } else {
                this.element.classList.remove(this.stateClasses.notValid);
                this.elements.validationMessage = null;
            }
            this.attributes.maxLength = this.elements.input.getAttribute('maxlength');
            if (this.options.testId) {
                this.elements.input.setAttribute('data-testid', this.options.testId.concat('Input'));
                if (this.elements.label) {
                    this.elements.label.setAttribute('data-testid', this.options.testId.concat('Label'));
                }
                if (this.elements.validationMessage) {
                    this.elements.validationMessage.setAttribute('data-testid', this.options.testId.concat('ValidationMessage'));
                }
            }
        }
    }
    _build() {
        this._inputAttributes();
    }
    render() {
        this._inputAttributes();
        if (this.options.maxLengthCounter) {
            this._setMaxLengthCounter();
        } else {
            this.elements.footer.maxLengthCounter.innerText = '';
        }
    }
    parametersChanged(options) {
        this.options = options;
    }
}