define("ShopperPortalEU.Refund.AddTaxFreeForm.mvc$model", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Theme.controller", "ShopperPortalEU.Layouts.LayoutDetail.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomButton.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomButtonItem.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.FullHeightContent.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.ScanBarcode.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.Flex.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomIcon.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomImage.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomOpacity.mvc$model", "ShopperPortalEU_UI_Components.model$ScanBarcodeDataRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Theme.model$LayoutDetailOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconRec", "ShopperPortalEU_UI_Components.model$FullHeightContentOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentTopOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentBottomOptionsRec", "ShopperPortalEU_UI_Components.model$FlexOptionsRec", "ShopperPortalEU_UI_Components.model$CustomIconOptionsRec", "ShopperPortalEU_UI_Components.model$CustomImageOptionsRec", "ShopperPortalEU_UI_Components.model$CustomOpacityOptionsRec", "ShopperPortalEU.controller$ClarityEvent", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", "ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger", "ShopperPortalEU_UI_Components.model$ScanBarcodeErrorRec"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ThemeModel, ShopperPortalEUController, ShopperPortalEU_UI_ThemeController, ShopperPortalEU_Layouts_LayoutDetail_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_ScanBarcode_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomIcon_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomImage_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomOpacity_mvcModel) {
var OS = OutSystems.Internal;

var IsDemoEnvironmentDataActRec = (function (_super) {
__extends(IsDemoEnvironmentDataActRec, _super);
function IsDemoEnvironmentDataActRec(defaults) {
_super.apply(this, arguments);
}
IsDemoEnvironmentDataActRec.attributesToDeclare = function () {
return [
this.attr("Output", "outputOut", "Output", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
IsDemoEnvironmentDataActRec.fromStructure = function (str) {
return new IsDemoEnvironmentDataActRec(new IsDemoEnvironmentDataActRec.RecordClass({
outputOut: OS.DataTypes.ImmutableBase.getData(str)
}));
};
IsDemoEnvironmentDataActRec.init();
return IsDemoEnvironmentDataActRec;
})(OS.Model.DataSourceRecord);

var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("ShowTips", "showTipsVar", "ShowTips", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("Timeout", "timeoutVar", "Timeout", true, false, OS.DataTypes.DataTypes.Object, function () {
return null;
}, false), 
this.attr("BarcodeData", "barcodeDataVar", "BarcodeData", true, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.ScanBarcodeDataRec());
}, false, ShopperPortalEU_UI_ComponentsModel.ScanBarcodeDataRec), 
this.attr("IsScanLoaded", "isScanLoadedVar", "IsScanLoaded", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("IsDemoEnvironment", "isDemoEnvironmentDataAct", "isDemoEnvironmentDataAct", true, true, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new IsDemoEnvironmentDataActRec());
}, true, IsDemoEnvironmentDataActRec)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Model._hasValidationWidgetsValue = undefined;
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
if((Model._hasValidationWidgetsValue === undefined)) {
Model._hasValidationWidgetsValue = ((((((((ShopperPortalEU_Layouts_LayoutDetail_mvcModel.hasValidationWidgets || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_ScanBarcode_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomIcon_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomImage_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomOpacity_mvcModel.hasValidationWidgets);
}

return Model._hasValidationWidgetsValue;
}
});

Model.prototype.setInputs = function (inputs) {
};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "Refund.AddTaxFreeForm");
});
define("ShopperPortalEU.Refund.AddTaxFreeForm.mvc$view", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.controller", "react", "OutSystems/ReactView/Main", "ShopperPortalEU.Refund.AddTaxFreeForm.mvc$model", "ShopperPortalEU.Refund.AddTaxFreeForm.mvc$controller", "ShopperPortalEU.clientVariables", "ShopperPortalEU.Layouts.LayoutDetail.mvc$view", "OutSystems/ReactWidgets/Main", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomButton.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomButtonItem.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.FullHeightContent.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.ScanBarcode.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.Flex.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomIcon.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomImage.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomOpacity.mvc$view", "ShopperPortalEU_UI_Components.model$ScanBarcodeDataRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Theme.model$LayoutDetailOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconRec", "ShopperPortalEU_UI_Components.model$FullHeightContentOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentTopOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentBottomOptionsRec", "ShopperPortalEU_UI_Components.model$FlexOptionsRec", "ShopperPortalEU_UI_Components.model$CustomIconOptionsRec", "ShopperPortalEU_UI_Components.model$CustomImageOptionsRec", "ShopperPortalEU_UI_Components.model$CustomOpacityOptionsRec", "ShopperPortalEU.controller$ClarityEvent", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", "ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger", "ShopperPortalEU_UI_Components.model$ScanBarcodeErrorRec"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ThemeController, React, OSView, ShopperPortalEU_Refund_AddTaxFreeForm_mvc_model, ShopperPortalEU_Refund_AddTaxFreeForm_mvc_controller, ShopperPortalEUClientVariables, ShopperPortalEU_Layouts_LayoutDetail_mvc_view, OSWidgets, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_ScanBarcode_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomIcon_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomImage_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomOpacity_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            var thisIsInstanceOfSuper = this instanceof _super;
            if (thisIsInstanceOfSuper == false) {
                return;
            }

            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "Refund.AddTaxFreeForm";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css", "css/ShopperPortalEU_UI_Theme.ShopperPortalEUUITheme.css", "css/ShopperPortalEU.ShopperPortalEU.css", "css/ShopperPortalEU_UI_Theme.ShopperPortalEUUITheme.extra.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [ShopperPortalEU_Layouts_LayoutDetail_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_ScanBarcode_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomIcon_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomImage_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomOpacity_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return ShopperPortalEU_Refund_AddTaxFreeForm_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return ShopperPortalEU_Refund_AddTaxFreeForm_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "Shopper Portal EU - Add Tax Free Form";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(ShopperPortalEU_Layouts_LayoutDetail_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("W42vxeNvdU+4RHv8SJiJaw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ThemeModel.LayoutDetailOptionsRec();
rec.darkModeAttr = true;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "0",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
headerLeft: PlaceholderContent.Empty,
headerCenter: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "Add_Tax_Free_form_Title"
},
value: "Add Tax Free form",
_idProps: {
service: idService,
uuid: "1"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
headerRight: new PlaceholderContent(function () {
return [$if(model.variables.isScanLoadedVar, false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("UBcOv2z+xka23pJUumCRWA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRec();
rec.testIdAttr = "CloseAddTFFScreen";
rec.typeAttr = ShopperPortalEUModel.staticEntities.customButtonType.linkSecondary;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "2",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
button: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: false,
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Refund/AddTaxFreeForm/Button OnClick");
controller.closeOnClick$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn",
visible: true,
_idProps: {
service: idService,
uuid: "3"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("ucjdO3w1GkKEgTPZBND19w.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonItemOptionsRec();
rec.iconAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsIconRec();
rec.nameAttr = "close";
return rec;
}();
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "4",
alias: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: PlaceholderContent.Empty
},
_dependencies: []
}))];
})
},
_dependencies: []
})];
}, function () {
return [];
})];
}),
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("mAQJFSJE_0SxGxhrovnz6w.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FullHeightContentOptionsRec();
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space4;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "5",
alias: "4"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
top: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_ScanBarcode_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onError$Action: function (errorIn) {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ShopperPortalEUUIComponents/ScanBarcode OnError");
controller.scanBarcodeOnError$Action(errorIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
onResult$Action: function (dataIn) {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ShopperPortalEUUIComponents/ScanBarcode OnResult");
controller.scanBarcodeOnResult$Action(dataIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
onLoad$Action: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ShopperPortalEUUIComponents/ScanBarcode OnLoad");
controller.scanBarcodeOnLoad$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "6",
alias: "5"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
ExtendedClass: "margin-top-06",
Options: model.getCachedValue(idService.getId("dhOHE77fpUuNinsIShXr3w.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
rec.wrapAttr = false;
rec.lineHeightResetAttr = true;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "7",
alias: "6"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomIcon_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("4FanQGDcXkaRvtbS22poSg.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomIconOptionsRec();
rec.nameAttr = "center_focus_weak";
rec.sizeAttr = ShopperPortalEUModel.staticEntities.customIconSize.extraSmall;
rec.isFilledAttr = true;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "8",
alias: "7"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "9"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "ScanBarCode_Text"
},
value: "Scan the barcode of your Tax Free form",
_idProps: {
service: idService,
uuid: "10"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomImage_mvc_view, {
inputs: {
ExtendedClass: "margin-top-03"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "11",
alias: "8"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
image: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Image, {
type: /*External*/ 1,
url: "/ShopperPortalEU_UI_Resources/img/ShopperPortalEU_UI_Resources.barcode_tff.svg",
_idProps: {
service: idService,
uuid: "12"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomOpacity_mvc_view, {
inputs: {
ExtendedClass: "margin-top-05",
Options: model.getCachedValue(idService.getId("Q5ZQD2xPxE2H0DZZUfla5Q.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomOpacityOptionsRec();
rec.valueAttr = OS.BuiltinFunctions.integerToDecimal(((model.variables.showTipsVar) ? (1) : (0)));
rec.isAnimatedAttr = true;
return rec;
}();
}, function () {
return model.variables.showTipsVar;
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "13",
alias: "9"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("V_k3_ny60E6TYHtwK3A_9A.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.alignAttr = ShopperPortalEUModel.staticEntities.flexAlign.center;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
rec.wrapAttr = false;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "14",
alias: "10"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomIcon_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("izD3MYbeXUyUSjNk7RVBNg.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomIconOptionsRec();
rec.nameAttr = "fit_screen";
rec.sizeAttr = ShopperPortalEUModel.staticEntities.customIconSize.extraSmall;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "15",
alias: "11"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}), React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "AlignOnScreen_Text"
},
value: "Align within the on-screen frame",
_idProps: {
service: idService,
uuid: "16"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
ExtendedClass: "margin-top-04",
Options: model.getCachedValue(idService.getId("C7MJSbqc+U2L5oVIledmxg.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.alignAttr = ShopperPortalEUModel.staticEntities.flexAlign.center;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
rec.wrapAttr = false;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "17",
alias: "12"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomIcon_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("97wrVdp3e0uY2jn2Ms61DQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomIconOptionsRec();
rec.nameAttr = "front_hand";
rec.sizeAttr = ShopperPortalEUModel.staticEntities.customIconSize.extraSmall;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "18",
alias: "13"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}), React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "HoldStill_Text"
},
value: "Hold the Tax Free form still",
_idProps: {
service: idService,
uuid: "19"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
ExtendedClass: "margin-top-04",
Options: model.getCachedValue(idService.getId("rBoX_OL0c0+w3jDk0ZnxLQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.alignAttr = ShopperPortalEUModel.staticEntities.flexAlign.center;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
rec.wrapAttr = false;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "20",
alias: "14"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomIcon_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("Y3PIfuA4E0Cr1Q6URonIpw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomIconOptionsRec();
rec.nameAttr = "light_mode";
rec.sizeAttr = ShopperPortalEUModel.staticEntities.customIconSize.extraSmall;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "21",
alias: "15"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}), React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "GoodLight_Text"
},
value: "Make sure there is good light",
_idProps: {
service: idService,
uuid: "22"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
})];
})
},
_dependencies: []
})];
}),
bottom: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: true,
style: "text-align-center",
visible: model.getCachedValue(idService.getId("UChbdFTlGEKnDF_Haa0tcA.Visible"), function () {
return ((model.variables.isDemoEnvironmentDataAct.outputOut) ? (true) : (model.variables.isScanLoadedVar));
}, function () {
return model.variables.isDemoEnvironmentDataAct.outputOut;
}, function () {
return model.variables.isScanLoadedVar;
}),
_idProps: {
service: idService,
uuid: "23"
},
_widgetRecordProvider: widgetsRecordProvider,
visible_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.isDemoEnvironmentDataAct.dataFetchStatusAttr)
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("yGuFr_wDqEm1MmETzDq1Pg.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRec();
rec.testIdAttr = "EnterYourDetailsManuallyLink";
rec.typeAttr = ShopperPortalEUModel.staticEntities.customButtonType.linkPrimary;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "24",
alias: "16"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
button: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: false,
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Refund/AddTaxFreeForm/Button OnClick");
controller.enterTFFDetailsManually$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn",
visible: true,
_idProps: {
service: idService,
uuid: "25"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "26",
alias: "17"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Enter your details manually",
_idProps: {
service: idService,
uuid: "27"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables.isDemoEnvironmentDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.isScanLoadedVar), asPrimitiveValue(model.variables.isDemoEnvironmentDataAct.outputOut), asPrimitiveValue(model.variables.showTipsVar)]
})];
}),
bottom: PlaceholderContent.Empty
},
_dependencies: [asPrimitiveValue(model.variables.isDemoEnvironmentDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.isDemoEnvironmentDataAct.outputOut), asPrimitiveValue(model.variables.showTipsVar), asPrimitiveValue(model.variables.isScanLoadedVar)]
}));
        };
        return View;
    })(OSView.BaseView.BaseWebScreen);
	
    return View;
});
define("ShopperPortalEU.Refund.AddTaxFreeForm.mvc$controller", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.controller", "ShopperPortalEU.languageResources", "ShopperPortalEU.clientVariables", "ShopperPortalEU.Refund.AddTaxFreeForm.mvc$debugger", "ShopperPortalEU.Refund.controller", "ShopperPortalEU.Refund.AddTaxFreeForm.mvc$controller.SetTimeout.SetTimeoutJS", "ShopperPortalEU.Refund.AddTaxFreeForm.mvc$controller.ClearTimeout.ClearJS", "ShopperPortalEU_UI_Components.model$ScanBarcodeDataRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Theme.model$LayoutDetailOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconRec", "ShopperPortalEU_UI_Components.model$FullHeightContentOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentTopOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentBottomOptionsRec", "ShopperPortalEU_UI_Components.model$FlexOptionsRec", "ShopperPortalEU_UI_Components.model$CustomIconOptionsRec", "ShopperPortalEU_UI_Components.model$CustomImageOptionsRec", "ShopperPortalEU_UI_Components.model$CustomOpacityOptionsRec", "ShopperPortalEU.controller$ClarityEvent", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", "ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger", "ShopperPortalEU_UI_Components.model$ScanBarcodeErrorRec"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ThemeController, ShopperPortalEULanguageResources, ShopperPortalEUClientVariables, ShopperPortalEU_Refund_AddTaxFreeForm_mvc_Debugger, ShopperPortalEU_RefundController, ShopperPortalEU_Refund_AddTaxFreeForm_mvc_controller_SetTimeout_SetTimeoutJS, ShopperPortalEU_Refund_AddTaxFreeForm_mvc_controller_ClearTimeout_ClearJS) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {
showTips$Action: function () {
return controller.executeActionInsideJSNode(controller._showTips$Action.bind(controller), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "ShowTips");
}
};
this.dataFetchDependenciesOriginal = {
isDemoEnvironment$DataActRefresh: 0
};
this.dataFetchDependentsGraph = {
isDemoEnvironment$DataActRefresh: []
};
this.shouldSendClientVarsToDataSources = true;
}
// Server Actions

// Aggregates and Data Actions
Controller.prototype.isDemoEnvironment$DataActRefresh = function (callContext) {
var model = this.model;
var controller = this.controller;
var callContext = controller.callContext(callContext);
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:AS9H9g8i4EG4XyjkHo4JpA:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.ZjwiGilgpk6zwMB6r7Um6g/DataActions.AS9H9g8i4EG4XyjkHo4JpA:A6EmlWkfHbcq4PK15YluhQ", "ShopperPortalEU", "IsDemoEnvironment", "NRFlows.DataScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.setThreadStartName(callContext.id, "Refund/AddTaxFreeForm/IsDemoEnvironment");
return controller.callDataAction("DataActionIsDemoEnvironment", "screenservices/ShopperPortalEU/Refund/AddTaxFreeForm/DataActionIsDemoEnvironment", "1iyQDBoXF3EQFRj8F6fc7A", function (b) {
model.variables.isDemoEnvironmentDataAct.dataFetchStatusAttr = b;
}, function (json) {
model.variables.isDemoEnvironmentDataAct.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.isDemoEnvironmentDataAct.constructor));
}, undefined, OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, callContext, ShopperPortalEUClientVariables, false);

}, function () {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:AS9H9g8i4EG4XyjkHo4JpA", callContext.id);
controller.popDebuggerContext(callContext);

});
};

Controller.prototype.dataFetchActionNames = ["isDemoEnvironment$DataActRefresh"];
// Client Actions
Controller.prototype._onDestroy$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnDestroy");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:de7PCdKeaEWpWbJlM3sXiA:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.ZjwiGilgpk6zwMB6r7Um6g/ClientActions.de7PCdKeaEWpWbJlM3sXiA:MnfkZXxsLFOWKN_ZTPW32g", "ShopperPortalEU", "OnDestroy", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:mufccg3yrEqWABcANtLqLQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Vvgmrq9Ov02TcmH0o6tlyw", callContext.id);
// Execute Action: ClearTimeout
controller._clearTimeout$Action(callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:sEo14lcdsEK9LsfPMOV46w", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:de7PCdKeaEWpWbJlM3sXiA", callContext.id);
}

};
Controller.prototype._setTimeout$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("SetTimeout");
callContext = controller.callContext(callContext);
var setTimeoutJSResult = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.setTimeoutJSResult = setTimeoutJSResult;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:JcuEED3KX0igzRHBl5OmfQ:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.ZjwiGilgpk6zwMB6r7Um6g/ClientActions.JcuEED3KX0igzRHBl5OmfQ:dkZrL4x2o3MkwEtfU9qM2g", "ShopperPortalEU", "SetTimeout", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:0Si3l9LVSEC5oYy5xOUHpA", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:HdzoktWg00G7wpKCFuU3Ew", callContext.id);
setTimeoutJSResult.value = controller.safeExecuteJSNode(ShopperPortalEU_Refund_AddTaxFreeForm_mvc_controller_SetTimeout_SetTimeoutJS, "SetTimeout", "SetTimeout", {
Timeout: OS.DataConversion.JSNodeParamConverter.to(null, OS.DataTypes.DataTypes.Object)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("ShopperPortalEU.Refund.AddTaxFreeForm.SetTimeout$setTimeoutJSResult"))();
jsNodeResult.timeoutOut = OS.DataConversion.JSNodeParamConverter.from($parameters.Timeout, OS.DataTypes.DataTypes.Object);
return jsNodeResult;
}, {
ShowTips: controller.clientActionProxies.showTips$Action
}, {});
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:+reNnxmJDkmHYdAzEz145Q", callContext.id);
// Timeout = SetTimeout.Timeout
model.variables.timeoutVar = setTimeoutJSResult.value.timeoutOut;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:2IwlOMHHJEeH3uj2FQ7eGQ", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:JcuEED3KX0igzRHBl5OmfQ", callContext.id);
}

};
Controller.registerVariableGroupType("ShopperPortalEU.Refund.AddTaxFreeForm.SetTimeout$setTimeoutJSResult", [{
name: "Timeout",
attrName: "timeoutOut",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Object,
defaultValue: function () {
return null;
}
}]);
Controller.prototype._enterTFFDetailsManually$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("EnterTFFDetailsManually");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:iFPRLaz6B0aUGNmKVpqbbg:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.ZjwiGilgpk6zwMB6r7Um6g/ClientActions.iFPRLaz6B0aUGNmKVpqbbg:9hsiUyrnR8aUL5pbVIrk1A", "ShopperPortalEU", "EnterTFFDetailsManually", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:63lv7Y5erkma2nmUIXA3vg", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:BaJdO8ApzUmtzDjYTa3+Sg", callContext.id);
// Execute Action: ClarityEvent
ShopperPortalEUController.default.clarityEvent$Action("AddTFFmanually_link", callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:TjSc594DjEWr8CD4Hm1uuQ", callContext.id);
// Destination: /ShopperPortalEU/TaxFreeFormDetails
return OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "TaxFreeFormDetails", {
TaxFreeFormNumber: OS.DataConversion.ServerDataConverter.asString(model.variables.barcodeDataVar.valueAttr, OS.DataTypes.DataTypes.Text)
}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:iFPRLaz6B0aUGNmKVpqbbg", callContext.id);
}

};
Controller.prototype._clearTimeout$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("ClearTimeout");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:DZZaUsV58UOfN+AGL2FMeA:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.ZjwiGilgpk6zwMB6r7Um6g/ClientActions.DZZaUsV58UOfN+AGL2FMeA:0YgfscWhUqruEca8JMn7Bw", "ShopperPortalEU", "ClearTimeout", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:yUBqNenC0ki5hFxEzNKR+w", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:w8G8Grbf40iQzF4xYjTYXQ", callContext.id) && ((model.variables.timeoutVar) !== (OS.BuiltinFunctions.nullObject())))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:js5Vhz5tyEe4o87I9bVckw", callContext.id);
controller.safeExecuteJSNode(ShopperPortalEU_Refund_AddTaxFreeForm_mvc_controller_ClearTimeout_ClearJS, "Clear", "ClearTimeout", {
Timeout: OS.DataConversion.JSNodeParamConverter.to(model.variables.timeoutVar, OS.DataTypes.DataTypes.Object)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:oseHKWokAkOR2MkDYQrFsQ", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:oseHKWokAkOR2MkDYQrFsQ", callContext.id);
}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:DZZaUsV58UOfN+AGL2FMeA", callContext.id);
}

};
Controller.prototype._closeOnClick$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("CloseOnClick");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:zUKGVtZt70eyTRxpYSv5FQ:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.ZjwiGilgpk6zwMB6r7Um6g/ClientActions.zUKGVtZt70eyTRxpYSv5FQ:KIaUrTOnpWi8+GEt0pQYGw", "ShopperPortalEU", "CloseOnClick", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:8T5QbK2Xb0+JueUi1EAb9g", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:oCuPze28JUaseD+PtXtk5Q", callContext.id);
// Destination: (PreviousScreen)
return OS.Navigation.navigateBack(null, callContext, true);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:zUKGVtZt70eyTRxpYSv5FQ", callContext.id);
}

};
Controller.prototype._showTips$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("ShowTips");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:5iFHX3bj80mVQfrPMh6wuw:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.ZjwiGilgpk6zwMB6r7Um6g/ClientActions.5iFHX3bj80mVQfrPMh6wuw:_sDFQhWXczMqtS_WoqipaA", "ShopperPortalEU", "ShowTips", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:YUErTvrLEkevxYHytKEt7Q", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:r1UDp_s7y0ykDD+fOnaoXw", callContext.id);
// ShowTips = True
model.variables.showTipsVar = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Cydyk1kWSkuzQ6Y8nEZJnQ", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:5iFHX3bj80mVQfrPMh6wuw", callContext.id);
}

};
Controller.prototype._scanBarcodeOnLoad$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("ScanBarcodeOnLoad");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:covsjRb4MUiHoj5B+y0bcw:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.ZjwiGilgpk6zwMB6r7Um6g/ClientActions.covsjRb4MUiHoj5B+y0bcw:WNJ2b95gDYORDg9iyEOAHw", "ShopperPortalEU", "ScanBarcodeOnLoad", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:5B6q3HnPdUCniuxR4Crp5w", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:IGhuYrDK3EWgoGdMv8RFxg", callContext.id);
// IsScanLoaded = True
model.variables.isScanLoadedVar = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ce5AxPGO6EGtB8fdznUBTw", callContext.id);
// Execute Action: SetTimeout
controller._setTimeout$Action(callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:0DqX_WFDXEO3VYrJ6mDLDQ", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:covsjRb4MUiHoj5B+y0bcw", callContext.id);
}

};
Controller.prototype._onInitialize$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnInitialize");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:qO02qMdX7UK4rr96aA_dcQ:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.ZjwiGilgpk6zwMB6r7Um6g/ClientActions.qO02qMdX7UK4rr96aA_dcQ:ToU2+q1quehXCAh1Mplr5Q", "ShopperPortalEU", "OnInitialize", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:mwx2Sq0+fE6vDjJecqJKvQ", callContext.id);
// Reset data
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:aoUJFJYqIES1ZThtOCrxHw", callContext.id);
// ShowTips = False
model.variables.showTipsVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:aoUJFJYqIES1ZThtOCrxHw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// IsScanLoaded = False
model.variables.isScanLoadedVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:a5yaBEWDjU+XC5C2e8I5RQ", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:qO02qMdX7UK4rr96aA_dcQ", callContext.id);
}

};
Controller.prototype._scanBarcodeOnError$Action = function (errorIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("ScanBarcodeOnError");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.Refund.AddTaxFreeForm.ScanBarcodeOnError$vars"))());
vars.value.errorInLocal = errorIn.clone();
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:rHNW2VLbSUehCvCm6qwNGg:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.ZjwiGilgpk6zwMB6r7Um6g/ClientActions.rHNW2VLbSUehCvCm6qwNGg:Z+MSpH2RbZmrDiqkj3YXJA", "ShopperPortalEU", "ScanBarcodeOnError", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:nxoJTl82RkmL60+z1hwY6w", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:rKU8W5bSBkuO_WrnU4EgZA", callContext.id);
// IsScanLoaded = True
model.variables.isScanLoadedVar = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:MJKVP5J8FkSBOQ8sqexZdg", callContext.id);
// Execute Action: CustomMessageTrigger
ShopperPortalEU_UI_ThemeController.default.customMessageTrigger$Action(function () {
var rec = new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customMessageType.error;
rec.titleAttr = ("Code:" + vars.value.errorInLocal.codeAttr);
rec.contentAttr = vars.value.errorInLocal.messageAttr;
rec.testIdAttr = "ScanBarcodeError";
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:PwrTPJiLgUig8VUxdgUDrg", callContext.id);
// Execute Action: ClearTimeout
controller._clearTimeout$Action(callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:bzGgdDAG60iYR6yeMcW+8g", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:rHNW2VLbSUehCvCm6qwNGg", callContext.id);
}

};
Controller.registerVariableGroupType("ShopperPortalEU.Refund.AddTaxFreeForm.ScanBarcodeOnError$vars", [{
name: "Error",
attrName: "errorInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Record,
defaultValue: function () {
return new ShopperPortalEU_UI_ComponentsModel.ScanBarcodeErrorRec();
},
complexType: ShopperPortalEU_UI_ComponentsModel.ScanBarcodeErrorRec
}]);
Controller.prototype._scanBarcodeOnResult$Action = function (dataIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("ScanBarcodeOnResult");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.Refund.AddTaxFreeForm.ScanBarcodeOnResult$vars"))());
vars.value.dataInLocal = dataIn.clone();
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:tsfM8l1f20mV4pDZ1cdKzQ:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.ZjwiGilgpk6zwMB6r7Um6g/ClientActions.tsfM8l1f20mV4pDZ1cdKzQ:zSTmGq6SeMCxyj5s9WYE5w", "ShopperPortalEU", "ScanBarcodeOnResult", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:jDXtwD4wVkmPEROm3Le18A", callContext.id);
// Barcode And Show Tips
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:_va_E61qvkeyRHrESUmhew", callContext.id);
// BarcodeData = Data
model.variables.barcodeDataVar = vars.value.dataInLocal;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:_va_E61qvkeyRHrESUmhew", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// ShowTips = False
model.variables.showTipsVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:fSQ+Cjmxxk64v+YKheiamw", callContext.id);
// Execute Action: ClearTimeout
controller._clearTimeout$Action(callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:kGKBjiOUt0ixLVSzDxr9SA", callContext.id);
// Destination: /ShopperPortalEU/TaxFreeFormDetails
return OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "TaxFreeFormDetails", {
TaxFreeFormNumber: OS.DataConversion.ServerDataConverter.asString(model.variables.barcodeDataVar.valueAttr, OS.DataTypes.DataTypes.Text)
}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:tsfM8l1f20mV4pDZ1cdKzQ", callContext.id);
}

};
Controller.registerVariableGroupType("ShopperPortalEU.Refund.AddTaxFreeForm.ScanBarcodeOnResult$vars", [{
name: "Data",
attrName: "dataInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Record,
defaultValue: function () {
return new ShopperPortalEU_UI_ComponentsModel.ScanBarcodeDataRec();
},
complexType: ShopperPortalEU_UI_ComponentsModel.ScanBarcodeDataRec
}]);

Controller.prototype.onDestroy$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onDestroy$Action, callContext);

};
Controller.prototype.setTimeout$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._setTimeout$Action, callContext);

};
Controller.prototype.enterTFFDetailsManually$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._enterTFFDetailsManually$Action, callContext);

};
Controller.prototype.clearTimeout$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._clearTimeout$Action, callContext);

};
Controller.prototype.closeOnClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._closeOnClick$Action, callContext);

};
Controller.prototype.showTips$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._showTips$Action, callContext);

};
Controller.prototype.scanBarcodeOnLoad$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._scanBarcodeOnLoad$Action, callContext);

};
Controller.prototype.onInitialize$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onInitialize$Action, callContext);

};
Controller.prototype.scanBarcodeOnError$Action = function (errorIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._scanBarcodeOnError$Action, callContext, errorIn);

};
Controller.prototype.scanBarcodeOnResult$Action = function (dataIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._scanBarcodeOnResult$Action, callContext, dataIn);

};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:VcUw8y2coUi7OQ+l92mkmQ:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ:1Ox1BferNhnfzrugqQ41yg", "ShopperPortalEU", "Refund", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:ZjwiGilgpk6zwMB6r7Um6g:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.ZjwiGilgpk6zwMB6r7Um6g:cVwE0mpsimUpAvgwnbHcBg", "ShopperPortalEU", "AddTaxFreeForm", "NRNodes.WebScreen", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:ZjwiGilgpk6zwMB6r7Um6g", callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:VcUw8y2coUi7OQ+l92mkmQ", callContext.id);
};
Controller.prototype.onInitializeEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Refund/AddTaxFreeForm On Initialize");
return controller.onInitialize$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Refund/AddTaxFreeForm On Destroy");
return controller.onDestroy$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return ShopperPortalEU_RefundController.default.handleError(ex, this.callContext());
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return ShopperPortalEUController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, ShopperPortalEULanguageResources);
});
define("ShopperPortalEU.Refund.AddTaxFreeForm.mvc$controller.SetTimeout.SetTimeoutJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.Timeout = setTimeout($actions.ShowTips,10000);
};
});
define("ShopperPortalEU.Refund.AddTaxFreeForm.mvc$controller.ClearTimeout.ClearJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
clearTimeout($parameters.Timeout);
};
});

define("ShopperPortalEU.Refund.AddTaxFreeForm.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"HdzoktWg00G7wpKCFuU3Ew": {
getter: function (varBag, idService) {
return varBag.setTimeoutJSResult.value;
}
},
"js5Vhz5tyEe4o87I9bVckw": {
getter: function (varBag, idService) {
return varBag.clearJSResult.value;
}
},
"ERGbXbHbsEunelXh7L44SQ": {
getter: function (varBag, idService) {
return varBag.vars.value.errorInLocal;
}
},
"uYEbVfBWYkiu4G2A85WGCg": {
getter: function (varBag, idService) {
return varBag.vars.value.dataInLocal;
}
},
"qiD+3h2nZEu1+QnnzzllUg": {
getter: function (varBag, idService) {
return varBag.model.variables.showTipsVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"OEQ00kMcXkK6H+FdSyjpow": {
getter: function (varBag, idService) {
return varBag.model.variables.timeoutVar;
},
dataType: OS.DataTypes.DataTypes.Object
},
"WBDyYcGyEU6vEcc2PdDjZw": {
getter: function (varBag, idService) {
return varBag.model.variables.barcodeDataVar;
}
},
"+WLF+WARF0eh4GCFiHqT8g": {
getter: function (varBag, idService) {
return varBag.model.variables.isScanLoadedVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"AS9H9g8i4EG4XyjkHo4JpA": {
getter: function (varBag, idService) {
return varBag.model.variables.isDemoEnvironmentDataAct;
}
},
"Q8fUwxM5lEaJYaOx8mmevA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderLeft"));
})(varBag.model, idService);
}
},
"LFQ0wiPO_UWowPwzm1GFsQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderCenter"));
})(varBag.model, idService);
}
},
"okTxgbnWyUae5Pq9NxZLdQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderRight"));
})(varBag.model, idService);
}
},
"tfjdO35XeUSQFhtjMzTXDA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Button"));
})(varBag.model, idService);
}
},
"rMRlWYw1g0yEYh_QAa5lbg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"Fgc26biCx0q_7gIXnpvgFw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"IcHSdRzZ_0+J_BbzhGBrjQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Top"));
})(varBag.model, idService);
}
},
"wwwHJuqjrE+ZFCtk+ydILw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"l8RiZ1ntm0mh3oWb_v8UZg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Image"));
})(varBag.model, idService);
}
},
"cpdk0fV10k2pSPYkGqHBpA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"PQlf15DvSU6ckqmmX_xMuA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"JDGP3eeBQEqHrHQo7r3hQQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"CfyWwXOgw0G1UURcwHoq0g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"A70pL4K4H0uHyyHV3RH51A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Bottom"));
})(varBag.model, idService);
}
},
"lh+gfPNg4EuNhNj_f_qW6w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Button"));
})(varBag.model, idService);
}
},
"BHpziyqGA0W1pKiJFgGIXg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"38RPQGAC3ki8ragayo1Txg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Bottom"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
