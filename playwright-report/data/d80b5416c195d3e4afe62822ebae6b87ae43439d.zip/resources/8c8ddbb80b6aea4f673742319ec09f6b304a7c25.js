class headerSteps {
  constructor(id, options) {
    this.element = document.getElementById(id);
    this.options = options;
    this._build();
  }
  _setProps() {
    this.element.style.setProperty('--header-steps', this.options.steps);
  }
  _build() {
    this._setProps();
  }
  parametersChanged(options) {
    this.options = options;
    this._setProps();
  }
}