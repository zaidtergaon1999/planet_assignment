define("ShopperPortalEU_CMS_IS.model$TranslationItemRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CMS_IS.model"], function (exports, OutSystems, ShopperPortalEU_CMS_ISModel) {
var OS = OutSystems.Internal;
var TranslationItemRec = (function (_super) {
__extends(TranslationItemRec, _super);
function TranslationItemRec(defaults) {
_super.apply(this, arguments);
}
TranslationItemRec.attributesToDeclare = function () {
return [
this.attr("Key", "keyAttr", "Key", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Value", "valueAttr", "Value", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
TranslationItemRec.init();
return TranslationItemRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_CMS_ISModel.TranslationItemRec = TranslationItemRec;

});
define("ShopperPortalEU_CMS_IS.model$TranslationItemList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CMS_IS.model", "ShopperPortalEU_CMS_IS.model$TranslationItemRec"], function (exports, OutSystems, ShopperPortalEU_CMS_ISModel) {
var OS = OutSystems.Internal;
var TranslationItemList = (function (_super) {
__extends(TranslationItemList, _super);
function TranslationItemList(defaults) {
_super.apply(this, arguments);
}
TranslationItemList.itemType = ShopperPortalEU_CMS_ISModel.TranslationItemRec;
return TranslationItemList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_CMS_ISModel.TranslationItemList = TranslationItemList;

});
define("ShopperPortalEU_CMS_IS.model$TranslationRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CMS_IS.model", "ShopperPortalEU_CMS_IS.model$TranslationItemList"], function (exports, OutSystems, ShopperPortalEU_CMS_ISModel) {
var OS = OutSystems.Internal;
var TranslationRec = (function (_super) {
__extends(TranslationRec, _super);
function TranslationRec(defaults) {
_super.apply(this, arguments);
}
TranslationRec.attributesToDeclare = function () {
return [
this.attr("CountryCode", "countryCodeAttr", "CountryCode", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("LanguageCode", "languageCodeAttr", "LanguageCode", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Translations", "translationsAttr", "Translations", false, false, OS.DataTypes.DataTypes.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_CMS_ISModel.TranslationItemList());
}, true, ShopperPortalEU_CMS_ISModel.TranslationItemList)
].concat(_super.attributesToDeclare.call(this));
};
TranslationRec.init();
return TranslationRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_CMS_ISModel.TranslationRec = TranslationRec;

});
define("ShopperPortalEU_CMS_IS.model$ResourcesRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CMS_IS.model", "ShopperPortalEU_CMS_IS.model$TranslationItemList"], function (exports, OutSystems, ShopperPortalEU_CMS_ISModel) {
var OS = OutSystems.Internal;
var ResourcesRec = (function (_super) {
__extends(ResourcesRec, _super);
function ResourcesRec(defaults) {
_super.apply(this, arguments);
}
ResourcesRec.attributesToDeclare = function () {
return [
this.attr("TranslationItemList", "translationItemListAttr", "TranslationItemList", false, false, OS.DataTypes.DataTypes.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_CMS_ISModel.TranslationItemList());
}, true, ShopperPortalEU_CMS_ISModel.TranslationItemList)
].concat(_super.attributesToDeclare.call(this));
};
ResourcesRec.fromStructure = function (str) {
return new ResourcesRec(new ResourcesRec.RecordClass({
translationItemListAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ResourcesRec.init();
return ResourcesRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_CMS_ISModel.ResourcesRec = ResourcesRec;

});
define("ShopperPortalEU_CMS_IS.model$CountryRuleTranslationItemRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CMS_IS.model"], function (exports, OutSystems, ShopperPortalEU_CMS_ISModel) {
var OS = OutSystems.Internal;
var CountryRuleTranslationItemRec = (function (_super) {
__extends(CountryRuleTranslationItemRec, _super);
function CountryRuleTranslationItemRec(defaults) {
_super.apply(this, arguments);
}
CountryRuleTranslationItemRec.attributesToDeclare = function () {
return [
this.attr("Key", "keyAttr", "Key", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Value", "valueAttr", "Value", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CountryRuleTranslationItemRec.init();
return CountryRuleTranslationItemRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_CMS_ISModel.CountryRuleTranslationItemRec = CountryRuleTranslationItemRec;

});
define("ShopperPortalEU_CMS_IS.model$CountryRuleTranslationItemList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CMS_IS.model", "ShopperPortalEU_CMS_IS.model$CountryRuleTranslationItemRec"], function (exports, OutSystems, ShopperPortalEU_CMS_ISModel) {
var OS = OutSystems.Internal;
var CountryRuleTranslationItemList = (function (_super) {
__extends(CountryRuleTranslationItemList, _super);
function CountryRuleTranslationItemList(defaults) {
_super.apply(this, arguments);
}
CountryRuleTranslationItemList.itemType = ShopperPortalEU_CMS_ISModel.CountryRuleTranslationItemRec;
return CountryRuleTranslationItemList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_CMS_ISModel.CountryRuleTranslationItemList = CountryRuleTranslationItemList;

});
define("ShopperPortalEU_CMS_IS.model$CountryRuleTranslationRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CMS_IS.model", "ShopperPortalEU_CMS_IS.model$CountryRuleTranslationItemList"], function (exports, OutSystems, ShopperPortalEU_CMS_ISModel) {
var OS = OutSystems.Internal;
var CountryRuleTranslationRec = (function (_super) {
__extends(CountryRuleTranslationRec, _super);
function CountryRuleTranslationRec(defaults) {
_super.apply(this, arguments);
}
CountryRuleTranslationRec.attributesToDeclare = function () {
return [
this.attr("CountryCode", "countryCodeAttr", "CountryCode", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("LanguageCode", "languageCodeAttr", "LanguageCode", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Translations", "translationsAttr", "Translations", false, false, OS.DataTypes.DataTypes.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_CMS_ISModel.CountryRuleTranslationItemList());
}, true, ShopperPortalEU_CMS_ISModel.CountryRuleTranslationItemList)
].concat(_super.attributesToDeclare.call(this));
};
CountryRuleTranslationRec.init();
return CountryRuleTranslationRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_CMS_ISModel.CountryRuleTranslationRec = CountryRuleTranslationRec;

});
define("ShopperPortalEU_CMS_IS.model", ["exports", "OutSystems/ClientRuntime/Main"], function (exports, OutSystems) {
var OS = OutSystems.Internal;
var ShopperPortalEU_CMS_ISModel = exports;
});
