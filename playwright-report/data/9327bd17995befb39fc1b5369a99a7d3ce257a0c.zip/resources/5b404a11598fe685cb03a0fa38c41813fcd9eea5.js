define("ShopperPortalEU_Forms_IS.clientVariables", ["OutSystems/ClientRuntime/Main"], function (OutSystems) {
var OS = OutSystems.Internal;
var ClientVariables = (function (_super) {
var clientVarsService;
function ClientVariables() {
clientVarsService = OS.Injector.resolve(OS.ServiceNames.ClientVariablesService);
}
ClientVariables.prototype.getAccessToken = function () {
return clientVarsService.getVariable("AccessToken", "ShopperPortalEU_Forms_IS", OS.DataTypes.DataTypes.Text);
};
ClientVariables.prototype.setAccessToken = function (value) {
return clientVarsService.setVariable("AccessToken", "ShopperPortalEU_Forms_IS", OS.DataTypes.DataTypes.Text, value);
};
ClientVariables.prototype.getForm_JsonStructure = function () {
return clientVarsService.getVariable("Form_JsonStructure", "ShopperPortalEU_Forms_IS", OS.DataTypes.DataTypes.Text);
};
ClientVariables.prototype.setForm_JsonStructure = function (value) {
return clientVarsService.setVariable("Form_JsonStructure", "ShopperPortalEU_Forms_IS", OS.DataTypes.DataTypes.Text, value);
};
ClientVariables.prototype.getFormsList_JsonStructure = function () {
return clientVarsService.getVariable("FormsList_JsonStructure", "ShopperPortalEU_Forms_IS", OS.DataTypes.DataTypes.Text);
};
ClientVariables.prototype.setFormsList_JsonStructure = function (value) {
return clientVarsService.setVariable("FormsList_JsonStructure", "ShopperPortalEU_Forms_IS", OS.DataTypes.DataTypes.Text, value);
};
ClientVariables.prototype.serialize = function () {
return {
AccessToken: OS.DataConversion.ServerDataConverter.to(this.getAccessToken(), OS.DataTypes.DataTypes.Text),
Form_JsonStructure: OS.DataConversion.ServerDataConverter.to(this.getForm_JsonStructure(), OS.DataTypes.DataTypes.Text),
FormsList_JsonStructure: OS.DataConversion.ServerDataConverter.to(this.getFormsList_JsonStructure(), OS.DataTypes.DataTypes.Text)
};
};
return ClientVariables;
})();
return new ClientVariables();
});
