class menuElement {
  constructor(id, options) {
    this.class = 'menu__element';
    this.element = document.getElementById(id);
    this.options = options;
    this._build();
  }
  _setProps() {
    if (this.options.testId) {
      this.element.firstElementChild.setAttribute('data-testid', this.options.testId);
    }
  }
  _build() {
    this._setProps();
  }
}