class codeInput {
    constructor(id, options, events) {
        this.class = 'code-input';
        this.elementsClasses = {
            inputs: this.class.concat('__input')
        };
        this.stateClasses = {
            error: this.class.concat('--error')
        };
        this.element = document.getElementById(id);
        this.elements = {
            inputsList: this.element.firstElementChild,
            inputs: []
        };
        this.code = '';
        this.listeners = {
            _keydown: this._keydown.bind(this),
            _change: this._change.bind(this),
            _paste: this._paste.bind(this)
        };
        this.options = options;
        this.events = events;
        this._build();
    }
    _updateCode(code) {
        this.code = code;
        this.elements.inputs.forEach((a, b) => {
            a.value = this.code[b] ? this.code[b] : '';
        });
    }
    _setCode() {
        var code = '';
        this.elements.inputs.forEach(i => {
            code += i.value;
        });
        this.code = code;
    }
    _triggerChange() {
        this.events.change(JSON.stringify({
            code: this.code,
            filled: this.code.length === this.options.length
        }));
    }
    _change(e) {
        let input = e.target;
        this._setCode(false);
        this._triggerChange();
        if (input.value.length === 1 && input.nextElementSibling) {
            input.nextElementSibling.focus();
        }
    }
    _keydown(e) {
        let input = e.target;
        if (!e.ctrlKey && e.key !== 'v') {
            if (e.key !== 'Backspace') {
                if (e.key.match(/[0-9]/) === null) {
                    e.preventDefault();
                } else {
                    if (input.value.length > 0) {
                        input.value = '';
                    }
                }
            } else {
                e.preventDefault();
                if (input.value === '' && input.previousElementSibling) {
                    input.previousElementSibling.value = '';
                    input.previousElementSibling.focus();
                }
                input.value = '';
                this._setCode();
                this._triggerChange();
            }
        }
    }
    _paste(e) {
        e.preventDefault();
        var clipboardData = e.clipboardData || window.clipboardData;
        var pastedData = clipboardData.getData('Text');
        pastedData = pastedData.replace(/\D/g, '').substring(0, this.options.length);
        if (pastedData) {
            this._updateCode(pastedData);
            this._triggerChange();
        }
    }
    _resetInputs() {
        this.elements.inputs = [];
        this.elements.inputsList.innerHTML = '';
    }
    _setInputs() {
        for (let i = 0; i < this.options.length; i++) {
            let input = document.createElement('input');
            input.classList.add(this.elementsClasses.inputs);
            input.setAttribute('type', 'number');
            input.setAttribute('name', this.element.id + '_input_' + i);
            input.setAttribute('pattern', '[0-9]*');
            input.setAttribute('min', 0);
            input.setAttribute('max', 9);
            if (this.options.code[i]) {
                input.value = this.options.code[i];
            }
            if (this.options.testId) {
                input.setAttribute('data-testid', this.options.testId.concat(`-input-${i}`));
            }
            input.addEventListener('keydown', this.listeners._keydown);
            input.addEventListener('input', this.listeners._change);
            input.addEventListener('paste', this.listeners._paste);
            input.addEventListener('click', this.events.inputClick);
            this.elements.inputsList.append(input);
            this.elements.inputs.push(input);
        }
    }
    _build() {
        this._setInputs();
        if (this.options.code !== '') {
            this._setCode();
        }
        if (this.options.focusOnStart) {
            this.focus();
        }
    }
    focus() {
        if (this.elements.inputs.length) {
            let _e = this.elements.inputs.find(x => x.value === '');
            if (_e) {
                _e.focus();
            } else {
                this.elements.inputs[this.elements.inputs.length - 1].focus();
            }
        }
    }
    parametersChanged(options) {
        if (options.length !== this.options.length) {
            this.options = options;
            this._resetInputs();
            this._setInputs();
        } else {
            if (options.code !== this.code) {
                this.options = options;
                this._updateCode(this.options.code);
                this._triggerChange();
            } else {
                this.options = options;
            }
        }
    }
}