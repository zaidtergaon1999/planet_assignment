define("ShopperPortalEU_UI_Theme.ShopperPortalEUUIThemeLayoutsComponents.HeaderAction.mvc$model", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$HeaderActionOptionsRec"], function (OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("Obj", "objVar", "Obj", true, false, OS.DataTypes.DataTypes.Object, function () {
return null;
}, false), 
this.attr("Options", "optionsIn", "Options", true, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ThemeModel.HeaderActionOptionsRec());
}, false, ShopperPortalEU_UI_ThemeModel.HeaderActionOptionsRec), 
this.attr("_optionsInDataFetchStatus", "_optionsInDataFetchStatus", "_optionsInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return false;
}
});

Model.prototype.setInputs = function (inputs) {
if("Options" in inputs) {
this.variables.optionsIn = inputs.Options;
if("_optionsInDataFetchStatus" in inputs) {
this.variables._optionsInDataFetchStatus = inputs._optionsInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "ShopperPortalEUUIThemeLayoutsComponents.HeaderAction");
});
define("ShopperPortalEU_UI_Theme.ShopperPortalEUUIThemeLayoutsComponents.HeaderAction.mvc$view", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.controller", "react", "OutSystems/ReactView/Main", "ShopperPortalEU_UI_Theme.ShopperPortalEUUIThemeLayoutsComponents.HeaderAction.mvc$model", "ShopperPortalEU_UI_Theme.ShopperPortalEUUIThemeLayoutsComponents.HeaderAction.mvc$controller", "OutSystems/ReactWidgets/Main", "ShopperPortalEU_UI_Theme.model$HeaderActionOptionsRec"], function (OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ThemeController, React, OSView, ShopperPortalEU_UI_Theme_ShopperPortalEUUIThemeLayoutsComponents_HeaderAction_mvc_model, ShopperPortalEU_UI_Theme_ShopperPortalEUUIThemeLayoutsComponents_HeaderAction_mvc_controller, OSWidgets) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            var thisIsInstanceOfSuper = this instanceof _super;
            if (thisIsInstanceOfSuper == false) {
                return;
            }

            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "ShopperPortalEUUIThemeLayoutsComponents.HeaderAction";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css"];
        };
        View.getJsDependencies = function() {
            return ["scripts/ShopperPortalEU_UI_Theme.headerAction.js"];
        };
        View.getBlocks = function() {
            return [];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return ShopperPortalEU_UI_Theme_ShopperPortalEUUIThemeLayoutsComponents_HeaderAction_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return ShopperPortalEU_UI_Theme_ShopperPortalEUUIThemeLayoutsComponents_HeaderAction_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(OSWidgets.Placeholder, {
align: /*Default*/ 0,
content: _this.props.placeholders.item,
style: model.getCachedValue(idService.getId("Item.Style"), function () {
return ("header-action" + ((!(model.variables.optionsIn.hasAlertAttr)) ? ("") : (" header-action--alert")));
}, function () {
return model.variables.optionsIn.hasAlertAttr;
}),
_idProps: {
service: idService,
name: "Item"
},
_widgetRecordProvider: widgetsRecordProvider,
style_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._optionsInDataFetchStatus)
}));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("ShopperPortalEU_UI_Theme.ShopperPortalEUUIThemeLayoutsComponents.HeaderAction.mvc$controller", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.controller", "ShopperPortalEU_UI_Theme.languageResources", "ShopperPortalEU_UI_Theme.ShopperPortalEUUIThemeLayoutsComponents.HeaderAction.mvc$debugger", "ShopperPortalEU_UI_Theme.ShopperPortalEUUIThemeLayoutsComponents.HeaderAction.mvc$controller.OnReady.InitializeJS", "ShopperPortalEU_UI_Theme.model$HeaderActionOptionsRec"], function (OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ThemeController, ShopperPortalEU_UI_ThemeLanguageResources, ShopperPortalEU_UI_Theme_ShopperPortalEUUIThemeLayoutsComponents_HeaderAction_mvc_Debugger, ShopperPortalEU_UI_Theme_ShopperPortalEUUIThemeLayoutsComponents_HeaderAction_mvc_controller_OnReady_InitializeJS) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = false;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._onReady$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnReady");
callContext = controller.callContext(callContext);
var initializeJSResult = new OS.DataTypes.VariableHolder();
var optionsJSONVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.JSONSerializeOutputType());
varBag.callContext = callContext;
varBag.initializeJSResult = initializeJSResult;
varBag.optionsJSONVar = optionsJSONVar;
try {OutSystemsDebugger.push("1ohZxgV1_kKH2z+Fu01SDQ:VJmQGuFmcUGsInKTcl8mfg:/NRWebFlows.uRd0Q1laQ0yzNZQMUt7Aug/NodesShownInESpaceTree.NhI6fApUX0G4Wgexhpj0hA/ClientActions.VJmQGuFmcUGsInKTcl8mfg:BvnQqlTo4FFYzmdzyQ0Z+A", "ShopperPortalEU_UI_Theme", "OnReady", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:N_SOVLQgokOtld9ccCdiPw", callContext.id);
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:NuMujMw_XE2pcmLoPupFhA", callContext.id);
// JSON Serialize: OptionsJSON
optionsJSONVar.value.jSONOut = OS.JSONUtils.serializeToJSON(model.variables.optionsIn, true, false);
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:1rcydvD8H0CZ3AcENdeXhg", callContext.id);
// Initialize component.
initializeJSResult.value = controller.safeExecuteJSNode(ShopperPortalEU_UI_Theme_ShopperPortalEUUIThemeLayoutsComponents_HeaderAction_mvc_controller_OnReady_InitializeJS, "Initialize", "OnReady", {
Options: OS.DataConversion.JSNodeParamConverter.to(optionsJSONVar.value.jSONOut, OS.DataTypes.DataTypes.Text),
ElementId: OS.DataConversion.JSNodeParamConverter.to(idService.getId("Item"), OS.DataTypes.DataTypes.Text),
Obj: OS.DataConversion.JSNodeParamConverter.to(null, OS.DataTypes.DataTypes.Object)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Theme.ShopperPortalEUUIThemeLayoutsComponents.HeaderAction.OnReady$initializeJSResult"))();
jsNodeResult.objOut = OS.DataConversion.JSNodeParamConverter.from($parameters.Obj, OS.DataTypes.DataTypes.Object);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:jtbhdwQ6YEeV9Dmcl67OXA", callContext.id);
// Obj = Initialize.Obj
model.variables.objVar = initializeJSResult.value.objOut;
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:U+rnO0U5GEWlH6_8cfa+lg", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("1ohZxgV1_kKH2z+Fu01SDQ:VJmQGuFmcUGsInKTcl8mfg", callContext.id);
}

};
Controller.registerVariableGroupType("ShopperPortalEU_UI_Theme.ShopperPortalEUUIThemeLayoutsComponents.HeaderAction.OnReady$initializeJSResult", [{
name: "Obj",
attrName: "objOut",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Object,
defaultValue: function () {
return null;
}
}]);

Controller.prototype.onReady$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onReady$Action, callContext);

};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("1ohZxgV1_kKH2z+Fu01SDQ:uRd0Q1laQ0yzNZQMUt7Aug:/NRWebFlows.uRd0Q1laQ0yzNZQMUt7Aug:AOdtJWIZ_kUN4hGD9hTAnA", "ShopperPortalEU_UI_Theme", "ShopperPortalEUUIThemeLayoutsComponents", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("1ohZxgV1_kKH2z+Fu01SDQ:NhI6fApUX0G4Wgexhpj0hA:/NRWebFlows.uRd0Q1laQ0yzNZQMUt7Aug/NodesShownInESpaceTree.NhI6fApUX0G4Wgexhpj0hA:J7wYCxA7I36PuleGiO3Yog", "ShopperPortalEU_UI_Theme", "HeaderAction", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("1ohZxgV1_kKH2z+Fu01SDQ:NhI6fApUX0G4Wgexhpj0hA", callContext.id);
OutSystemsDebugger.pop("1ohZxgV1_kKH2z+Fu01SDQ:uRd0Q1laQ0yzNZQMUt7Aug", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "ShopperPortalEUUIThemeLayoutsComponents/HeaderAction On Ready");
return controller.onReady$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return ShopperPortalEU_UI_ThemeController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, ShopperPortalEU_UI_ThemeLanguageResources);
});
define("ShopperPortalEU_UI_Theme.ShopperPortalEUUIThemeLayoutsComponents.HeaderAction.mvc$controller.OnReady.InitializeJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.Obj = new headerAction($parameters.ElementId,JSON.parse($parameters.Options));
};
});

define("ShopperPortalEU_UI_Theme.ShopperPortalEUUIThemeLayoutsComponents.HeaderAction.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"NuMujMw_XE2pcmLoPupFhA": {
getter: function (varBag, idService) {
return varBag.optionsJSONVar.value;
}
},
"1rcydvD8H0CZ3AcENdeXhg": {
getter: function (varBag, idService) {
return varBag.initializeJSResult.value;
}
},
"iFWB4mqG30WBCsroCLAvOQ": {
getter: function (varBag, idService) {
return varBag.model.variables.objVar;
},
dataType: OS.DataTypes.DataTypes.Object
},
"oKJZIH0q4kKVa99WKfwyZQ": {
getter: function (varBag, idService) {
return varBag.model.variables.optionsIn;
}
},
"tU4McEs3VUSvkNVqGH_dbw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Item"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
