class layout {
    constructor(options, events) {
        this.class = 'layout';
        this.element = null;
        this.elementsClasses = {
            header: 'header'
        };
        this.elements = {
            header: null
        };
        this.stateClasses = {
            body: {
                darkerBackground: 'body--darker-background',
                darkMode: 'body--dark-mode',
                fullWidth: 'body--full-width',
                menuOpen: 'body--menu-open',
                touch: 'body--touch',
                noTouch: 'body--no-touch',
                scrolled: 'body--scrolled',
                scrollTitle: 'body--scroll-title',
                scrollNoAnimation: 'body--scroll-no-animation'
            },
            layout: {
                default: this.class.concat('--default'),
                largerHeader: this.class.concat('--larger-header'),
                avatarHeader: this.class.concat('--avatar-header')
            },
        };
        this.browserReport = window.layout ? window.layout.browserReport : null;
        this.customMessage = window.layout ? window.layout.customMessage : null;
        this.listeners = {
            _orientationChange: this._orientationChange.bind(this),
            _headerResize: this._headerResize.bind(this),
            _contentResize: this._contentResize.bind(this),
            _onScroll: this._onScroll.bind(this)
        };
        this.headerResizeObserver = null;
        this.contentResizeObserver = null;
        this.options = options;
        this.events = events;
        this.scrollTop = 0;
        this._build();
    }
    _setHeaderProps() {
        if (this.elements.header) {
            document.body.style.setProperty('--hb-height', this.elements.header.lastElementChild.offsetHeight + 'px');
            if (!this.options.header.centered)
                if (this.elements.header.lastElementChild.querySelector('.avatar') == null) {
                    this.elements.header.lastElementChild.offsetHeight > 200 ? this.element.classList.add(this.stateClasses.layout.largerHeader) : this.element.classList.remove(this.stateClasses.layout.largerHeader);
                } else {
                    this.element.classList.remove(this.stateClasses.layout.largerHeader);
                    this.element.classList.add(this.stateClasses.layout.avatarHeader)
                }
        }
    }
    _checkScroll() {
        this.element.scrollHeight - this.element.offsetHeight < 100 ? document.body.classList.add(this.stateClasses.body.scrollNoAnimation) : document.body.classList.remove(this.stateClasses.body.scrollNoAnimation);
    }
    _headerResize(res) {
        this._setHeaderProps();
    }
    _contentResize(res) {
        this._checkScroll();
    }
    _orientationChange(e) {
        let orientation = '';
        if (screen.orientation) {
            orientation = screen.orientation.type.includes('landscape') ? 'landscape' : 'portrait';
        } else {
            orientation = document.body.classList.contains('landscape') ? 'landscape' : 'portrait';
        }
        this.events.orientationChange(orientation);
    }
    _onScroll(e) {
        if (this.scrollTop != e.target.scrollTop) {
            this.scrollTop = e.target.scrollTop;
            let t = this.scrollTop,
                o = 1 - (t * 1.5 / 100);
            t = t > 60 ? 60 : t < 0 ? 0 : t;
            document.body.style.setProperty('--h-translate', t + 'px');
            o = o > 1 ? 1 : o < 0 ? 0 : o;
            document.body.style.setProperty('--h-opacity', o);
            t > 0 ? document.body.classList.add(this.stateClasses.body.scrolled) : document.body.classList.remove(this.stateClasses.body.scrolled);
            t >= 60 ? document.body.classList.add(this.stateClasses.body.scrollTitle) : document.body.classList.remove(this.stateClasses.body.scrollTitle);
        }
    }
    _build() {
        document.body.classList.remove(this.stateClasses.body.menuOpen);
        this.options.darkerBackground ? document.body.classList.add(this.stateClasses.body.darkerBackground) : document.body.classList.remove(this.stateClasses.body.darkerBackground);
        this.options.darkMode ? document.body.classList.add(this.stateClasses.body.darkMode) : document.body.classList.remove(this.stateClasses.body.darkMode);
        if (window.layout === undefined) {
            this.browserReport = browserReportSync();
            if (this.browserReport) {
                if (this.browserReport.browser && this.browserReport.browser.name) {
                    this.browserReport.browser.name = this.browserReport.browser.name.split(' ')[0].toLowerCase() || '';
                    document.body.classList.add(this.browserReport.browser.name);
                }
                if (this.browserReport.os && this.browserReport.os.name) {
                    this.browserReport.os.name = this.browserReport.os.name.toLowerCase();
                    document.body.classList.add(this.browserReport.os.name);
                }
            }
            this.customMessage = new customMessage();
            document.body.classList.add('body-element');
            "ontouchstart" in document.documentElement ? document.body.classList.add(this.stateClasses.body.touch) : document.body.classList.add(this.stateClasses.body.noTouch);
            window.layout = this;
        }
    }
    destroy() {
        window.removeEventListener("orientationchange", this.listeners._orientationChange);
        if (this.options.darkerBackground) {
            document.body.classList.remove(this.stateClasses.body.darkerBackground);
        }
        if (this.headerResizeObserver) {
            this.headerResizeObserver.unobserve(this.elements.header);
        }
        if (this.contentResizeObserver) {
            this.contentResizeObserver.unobserve(this.element.firstElementChild);
        }
        document.body.style.removeProperty('--h-translate');
        document.body.style.removeProperty('--h-opacity');
        document.body.style.removeProperty('--hb-height');
        this.scrollTop = 0;
    }
    ready(id) {
        document.body.classList.remove(this.stateClasses.body.scrolled, this.stateClasses.body.scrollTitle, this.stateClasses.body.scrollNoAnimation);
        this.element = document.getElementById(id);
        this.elements.header = this.element.getElementsByClassName(this.elementsClasses.header)[0];
        if (this.elements.header && this.element.classList.contains(this.stateClasses.layout.default)) {
            this.headerResizeObserver = new ResizeObserver((x) => x.forEach(this.listeners._headerResize));
            this.headerResizeObserver.observe(this.elements.header);
            this.contentResizeObserver = new ResizeObserver((x) => x.forEach(this.listeners._contentResize));
            this.contentResizeObserver.observe(this.element.firstElementChild);
            this.element.addEventListener('scroll', this.listeners._onScroll);
        }
        window.addEventListener("orientationchange", this.listeners._orientationChange);
        window.layout = this;
    }
}