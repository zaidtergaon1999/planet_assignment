class customIcon {
  constructor(id, options) {
    this.class = 'custom-icon';
    this.element = document.getElementById(id);
    this.options = options;
    this._build();
  }
  _setCSSVariables() {
    this.element.style.setProperty('--icon-color', this.options.color);
  }
  _build() {
    this._setCSSVariables();
  }
  parametersChanged(options) {
    this.options = options;
    this._setCSSVariables();
  }
}