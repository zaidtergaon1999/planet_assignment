class customImage {
  constructor(id, options) {
    this.element = document.getElementById(id);
    this.image = this.element.querySelector('img');
    this.options = options;
    this._build();
  }
  _setCSSVariables() {
    if (this.image) {
      this.image.style.width = '';
      this.image.style.height = '';
      this.element.style.setProperty('--image-src', `url(${this.image.src})`);
    }
    this.element.style.setProperty('--image-height', this.options.height);
    this.element.style.setProperty('--image-width', this.options.width);
  }
  _build() {
    this._setCSSVariables();
    if (this.options.testId) {
      if (this.image) {
        this.image.setAttribute('data-testid', this.options.testId);
      }
    }
  }
  render() {
    this._setCSSVariables();
  }
  parametersChanged(options) {
    this.options = options;
  }
}