define("Custom404Plugin.referencesHealth$Users", [], function () {
// Reference to producer 'Users' is OK.
});
define("Custom404Plugin.referencesHealth", [], function () {
});
