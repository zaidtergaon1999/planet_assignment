define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.MonthYearInput.mvc$model", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$MonthYearInputOptionsRec", "ShopperPortalEU_UI_Components.model$MonthYearInputChangeOptionsRec"], function (OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("Obj", "objVar", "Obj", true, false, OS.DataTypes.DataTypes.Object, function () {
return null;
}, false), 
this.attr("DateInput", "dateInputVar", "DateInput", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, false), 
this.attr("Options", "optionsIn", "Options", true, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.MonthYearInputOptionsRec());
}, false, ShopperPortalEU_UI_ComponentsModel.MonthYearInputOptionsRec), 
this.attr("_optionsInDataFetchStatus", "_optionsInDataFetchStatus", "_optionsInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("ExtendedClass", "extendedClassIn", "ExtendedClass", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, false), 
this.attr("_extendedClassInDataFetchStatus", "_extendedClassInDataFetchStatus", "_extendedClassInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {
Input_Date: OS.Model.ValidationWidgetRecord
};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return true;
}
});

Model.prototype.setInputs = function (inputs) {
if("Options" in inputs) {
this.variables.optionsIn = inputs.Options;
if("_optionsInDataFetchStatus" in inputs) {
this.variables._optionsInDataFetchStatus = inputs._optionsInDataFetchStatus;
}

}

if("ExtendedClass" in inputs) {
this.variables.extendedClassIn = inputs.ExtendedClass;
if("_extendedClassInDataFetchStatus" in inputs) {
this.variables._extendedClassInDataFetchStatus = inputs._extendedClassInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "ShopperPortalEUUIComponents.MonthYearInput");
});
define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.MonthYearInput.mvc$view", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.controller", "react", "OutSystems/ReactView/Main", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.MonthYearInput.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.MonthYearInput.mvc$controller", "OutSystems/ReactWidgets/Main", "ShopperPortalEU_UI_Components.model$MonthYearInputOptionsRec", "ShopperPortalEU_UI_Components.model$MonthYearInputChangeOptionsRec"], function (OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ComponentsController, React, OSView, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_MonthYearInput_mvc_model, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_MonthYearInput_mvc_controller, OSWidgets) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            var thisIsInstanceOfSuper = this instanceof _super;
            if (thisIsInstanceOfSuper == false) {
                return;
            }

            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "ShopperPortalEUUIComponents.MonthYearInput";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css"];
        };
        View.getJsDependencies = function() {
            return ["scripts/ShopperPortalEU_UI_Components.monthYearInput.js"];
        };
        View.getBlocks = function() {
            return [];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_MonthYearInput_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_MonthYearInput_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: model.getCachedValue(idService.getId("Element.Style"), function () {
return (((("month-year-input" + ((!(model.variables.optionsIn.useMaskAttr)) ? (" month-year-input--native") : (" month-year-input--mask"))) + ((!(model.variables.optionsIn.isDisabledAttr)) ? ("") : (" month-year-input--disabled"))) + (((model.variables.optionsIn.validationAttr.stateAttr === OS.BuiltinFunctions.nullTextIdentifier())) ? ("") : ((" month-year-input--" + model.variables.optionsIn.validationAttr.stateAttr)))) + (((model.variables.extendedClassIn === "")) ? ("") : ((" " + model.variables.extendedClassIn))));
}, function () {
return model.variables.optionsIn.useMaskAttr;
}, function () {
return model.variables.optionsIn.isDisabledAttr;
}, function () {
return model.variables.optionsIn.validationAttr.stateAttr;
}, function () {
return model.variables.extendedClassIn;
}),
visible: true,
_idProps: {
service: idService,
name: "Element"
},
_widgetRecordProvider: widgetsRecordProvider,
style_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._optionsInDataFetchStatus, model.variables._extendedClassInDataFetchStatus)
}, React.createElement(OSWidgets.Placeholder, {
align: /*Default*/ 0,
content: _this.props.placeholders.label,
style: "month-year-input__label ph",
_idProps: {
service: idService,
name: "Label"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "month-year-input__input-wrapper",
visible: true,
_idProps: {
service: idService,
uuid: "2"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Input, {
_validationProps: {
validationService: validationService
},
enabled: !(model.variables.optionsIn.isDisabledAttr),
extendedEvents: {
onFocus: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ShopperPortalEUUIComponents/MonthYearInput/Input_Date onfocus");
return controller.focus$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
}
},
gridProperties: {
classes: "OSFillParent"
},
inputType: /*Text*/ 0,
mandatory: model.variables.optionsIn.isMandatoryAttr,
maxLength: 0,
onChange: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ShopperPortalEUUIComponents/MonthYearInput/Input_Date OnChange");
return controller.change$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
style: "form-control",
variable: model.createVariable(OS.DataTypes.DataTypes.Text, model.variables.dateInputVar, function (value) {
model.variables.dateInputVar = value;
}),
_idProps: {
service: idService,
name: "Input_Date"
},
_widgetRecordProvider: widgetsRecordProvider,
enabled_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._optionsInDataFetchStatus),
mandatory_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._optionsInDataFetchStatus)
}), $if((model.variables.optionsIn.validationAttr.messageAttr === ""), false, this, function () {
return [];
}, function () {
return [React.createElement(OSWidgets.Expression, {
style: "validation-message",
value: model.variables.optionsIn.validationAttr.messageAttr,
_idProps: {
service: idService,
uuid: "4"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._optionsInDataFetchStatus)
})];
}))));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.MonthYearInput.mvc$controller", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.controller", "ShopperPortalEU_UI_Components.languageResources", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.MonthYearInput.mvc$debugger", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.MonthYearInput.mvc$controller.OnReady.InitializeJS", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.MonthYearInput.mvc$controller.Change.GetDateJS", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.MonthYearInput.mvc$controller.OnParametersChanged.ParametersChangedJS", "ShopperPortalEU_UI_Components.model$MonthYearInputOptionsRec", "ShopperPortalEU_UI_Components.model$MonthYearInputChangeOptionsRec"], function (OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ComponentsController, ShopperPortalEU_UI_ComponentsLanguageResources, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_MonthYearInput_mvc_Debugger, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_MonthYearInput_mvc_controller_OnReady_InitializeJS, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_MonthYearInput_mvc_controller_Change_GetDateJS, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_MonthYearInput_mvc_controller_OnParametersChanged_ParametersChangedJS) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {
change$Action: function () {
return controller.executeActionInsideJSNode(controller._change$Action.bind(controller), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "Change");
}
};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = false;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._onReady$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnReady");
callContext = controller.callContext(callContext);
var initializeJSResult = new OS.DataTypes.VariableHolder();
var optionsJSONVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.JSONSerializeOutputType());
varBag.callContext = callContext;
varBag.initializeJSResult = initializeJSResult;
varBag.optionsJSONVar = optionsJSONVar;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:VCx1Dr8QL06BqttK3Ccqeg:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.6n6CqM294kO_qEx2H7CSnQ/ClientActions.VCx1Dr8QL06BqttK3Ccqeg:kwbeQ6MvPTgld3+W9LjxCg", "ShopperPortalEU_UI_Components", "OnReady", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:vTzIcAZUHkCUZxFwNelQpw", callContext.id);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:DC9mAosHAUSg7VVBUrBnyA", callContext.id);
// JSON Serialize: OptionsJSON
optionsJSONVar.value.jSONOut = OS.JSONUtils.serializeToJSON(model.variables.optionsIn, true, false);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:intuh53mrkS9WQn2za+loA", callContext.id);
// Initialize component
initializeJSResult.value = controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_MonthYearInput_mvc_controller_OnReady_InitializeJS, "Initialize", "OnReady", {
Options: OS.DataConversion.JSNodeParamConverter.to(optionsJSONVar.value.jSONOut, OS.DataTypes.DataTypes.Text),
ElementId: OS.DataConversion.JSNodeParamConverter.to(idService.getId("Element"), OS.DataTypes.DataTypes.Text),
Obj: OS.DataConversion.JSNodeParamConverter.to(null, OS.DataTypes.DataTypes.Object)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.MonthYearInput.OnReady$initializeJSResult"))();
jsNodeResult.objOut = OS.DataConversion.JSNodeParamConverter.from($parameters.Obj, OS.DataTypes.DataTypes.Object);
return jsNodeResult;
}, {
Change: controller.clientActionProxies.change$Action
}, {});
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:14nXj7ozakC+qflqfGITXg", callContext.id);
// Obj = Initialize.Obj
model.variables.objVar = initializeJSResult.value.objOut;
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:XfFiKBFm4UqJH5sFFfF_WQ", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:VCx1Dr8QL06BqttK3Ccqeg", callContext.id);
}

};
Controller.registerVariableGroupType("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.MonthYearInput.OnReady$initializeJSResult", [{
name: "Obj",
attrName: "objOut",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Object,
defaultValue: function () {
return null;
}
}]);
Controller.prototype._change$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Change");
callContext = controller.callContext(callContext);
var getDateJSResult = new OS.DataTypes.VariableHolder();
var cardOptionsJSONVar = new OS.DataTypes.VariableHolder(new (OS.Controller.BaseController.getJSONDeserializeOutputType(ShopperPortalEU_UI_ComponentsModel.MonthYearInputChangeOptionsRec))());
varBag.callContext = callContext;
varBag.getDateJSResult = getDateJSResult;
varBag.cardOptionsJSONVar = cardOptionsJSONVar;
OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:cZiaKbnljEO3rzm0hK4ltg:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.6n6CqM294kO_qEx2H7CSnQ/ClientActions.cZiaKbnljEO3rzm0hK4ltg:1nonnjKYFZl7yrAwBRw1Gg", "ShopperPortalEU_UI_Components", "Change", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:9pNqOWFiFESvuf5pLx8lsw", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:c0ajsfLYxkWgKXl27RRKjQ", callContext.id);
// GetDate method
getDateJSResult.value = controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_MonthYearInput_mvc_controller_Change_GetDateJS, "GetDate", "Change", {
Obj: OS.DataConversion.JSNodeParamConverter.to(model.variables.objVar, OS.DataTypes.DataTypes.Object),
DateInfo: OS.DataConversion.JSNodeParamConverter.to("", OS.DataTypes.DataTypes.Text)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.MonthYearInput.Change$getDateJSResult"))();
jsNodeResult.dateInfoOut = OS.DataConversion.JSNodeParamConverter.from($parameters.DateInfo, OS.DataTypes.DataTypes.Text);
return jsNodeResult;
}, {}, {});
// ValidDate
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:kM0mk28eX0q36KfYjjRh0w", callContext.id) && ((getDateJSResult.value.dateInfoOut) !== ("")))) {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:xMfdgTE0bUSqZsQYZju+Pg", callContext.id);
// JSON Deserialize: CardOptionsJSON
cardOptionsJSONVar.value.dataOut = OS.JSONUtils.deserializeFromJSON(getDateJSResult.value.dateInfoOut, ShopperPortalEU_UI_ComponentsModel.MonthYearInputChangeOptionsRec, false);
// SetDate
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:GP9DY7L4A0uWCprd6mksDg", callContext.id);
// CardOptionsJSON.Data.Date = NewDate
cardOptionsJSONVar.value.dataOut.dateAttr = OS.BuiltinFunctions.newDate(cardOptionsJSONVar.value.dataOut.yearAttr, cardOptionsJSONVar.value.dataOut.monthAttr, OS.BuiltinFunctions.day(OS.BuiltinFunctions.currDate()));
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:BkTL9YQN_U6w9CZm4jrq5w", callContext.id);
// Trigger Event: OnChange
return controller.onChange$Action(cardOptionsJSONVar.value.dataOut, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:XRfua6L46Uep8LCOcxOTrQ", callContext.id);
});
} else {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:+zDi2T5CH0O2JmDQ1xsBWA", callContext.id);
// Trigger Event: OnChangeInvalid
return controller.onChange$Action(function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.MonthYearInputChangeOptionsRec();
rec.dateAttr = OS.BuiltinFunctions.nullDate();
rec.monthAttr = 0;
rec.yearAttr = 0;
return rec;
}(), callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:8WYBjOQZ5kituX0KfcgOOg", callContext.id);
});
}

});
}).then(function (res) {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:cZiaKbnljEO3rzm0hK4ltg", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:cZiaKbnljEO3rzm0hK4ltg", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.MonthYearInput.Change$getDateJSResult", [{
name: "DateInfo",
attrName: "dateInfoOut",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
Controller.prototype._onParametersChanged$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnParametersChanged");
callContext = controller.callContext(callContext);
var optionsJSONVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.JSONSerializeOutputType());
varBag.callContext = callContext;
varBag.optionsJSONVar = optionsJSONVar;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:x9fReH8l50OhvJv_vP+Plg:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.6n6CqM294kO_qEx2H7CSnQ/ClientActions.x9fReH8l50OhvJv_vP+Plg:7ZFgUeW16vfY7QpI5M+AMA", "ShopperPortalEU_UI_Components", "OnParametersChanged", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:GA4patSFi0ik_f9jBHxA3w", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:cj_gU6Ez10iYXTUvOAumlw", callContext.id) && ((model.variables.objVar) !== (OS.BuiltinFunctions.nullObject())))) {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:zA+vDOSNh0qLoWUgN9_BCA", callContext.id);
// JSON Serialize: OptionsJSON
optionsJSONVar.value.jSONOut = OS.JSONUtils.serializeToJSON(model.variables.optionsIn, true, false);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:xXzBsNBtWUWFXHxbw8PC9A", callContext.id);
// Parameters change method.
controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_MonthYearInput_mvc_controller_OnParametersChanged_ParametersChangedJS, "ParametersChanged", "OnParametersChanged", {
Options: OS.DataConversion.JSNodeParamConverter.to(optionsJSONVar.value.jSONOut, OS.DataTypes.DataTypes.Text),
Obj: OS.DataConversion.JSNodeParamConverter.to(model.variables.objVar, OS.DataTypes.DataTypes.Object)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:efcl2HRLWU+D+82Gtszreg", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:7Det5kThUkmRKFKJJcyAsg", callContext.id);
}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:x9fReH8l50OhvJv_vP+Plg", callContext.id);
}

};
Controller.prototype._focus$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Focus");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:FKZh9k4HD0SKG0kyJoHQKA:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.6n6CqM294kO_qEx2H7CSnQ/ClientActions.FKZh9k4HD0SKG0kyJoHQKA:KhXefbpamYlsiXTwuCxwxw", "ShopperPortalEU_UI_Components", "Focus", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:kPXcTWtf_UOIkAc3k6sWHg", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:OmWXKrBpJ0CPx2KDjBcIyw", callContext.id);
// Trigger Event: OnFocus
return controller.onFocus$Action(callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:aPqERFbBdEOzwQ8Nus+hcw", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:FKZh9k4HD0SKG0kyJoHQKA", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:FKZh9k4HD0SKG0kyJoHQKA", callContext.id);
throw ex;

});
};

Controller.prototype.onReady$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onReady$Action, callContext);

};
Controller.prototype.change$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._change$Action, callContext);

};
Controller.prototype.onParametersChanged$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onParametersChanged$Action, callContext);

};
Controller.prototype.focus$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._focus$Action, callContext);

};
Controller.prototype.onFocus$Action = function () {
return Promise.resolve();
};
Controller.prototype.onChange$Action = function () {
return Promise.resolve();
};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:7hC2bHqrKEmxvEuPSzIN0Q:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q:g5BtT+X6uN+vFl8t9PMqCQ", "ShopperPortalEU_UI_Components", "ShopperPortalEUUIComponents", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:6n6CqM294kO_qEx2H7CSnQ:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.6n6CqM294kO_qEx2H7CSnQ:aymrkYB8nfZNOatBCuPzIw", "ShopperPortalEU_UI_Components", "MonthYearInput", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:6n6CqM294kO_qEx2H7CSnQ", callContext.id);
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:7hC2bHqrKEmxvEuPSzIN0Q", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "ShopperPortalEUUIComponents/MonthYearInput On Ready");
return controller.onReady$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "ShopperPortalEUUIComponents/MonthYearInput On Parameters Changed");
return controller.onParametersChanged$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return ShopperPortalEU_UI_ComponentsController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, ShopperPortalEU_UI_ComponentsLanguageResources);
});
define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.MonthYearInput.mvc$controller.OnReady.InitializeJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.Obj = new monthYearInput($parameters.ElementId,JSON.parse($parameters.Options),{
    change:$actions.Change
});
};
});
define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.MonthYearInput.mvc$controller.Change.GetDateJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.DateInfo = $parameters.Obj.getDate();
};
});
define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.MonthYearInput.mvc$controller.OnParametersChanged.ParametersChangedJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.Obj.parametersChanged(JSON.parse($parameters.Options));
};
});

define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.MonthYearInput.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"DC9mAosHAUSg7VVBUrBnyA": {
getter: function (varBag, idService) {
return varBag.optionsJSONVar.value;
}
},
"intuh53mrkS9WQn2za+loA": {
getter: function (varBag, idService) {
return varBag.initializeJSResult.value;
}
},
"xMfdgTE0bUSqZsQYZju+Pg": {
getter: function (varBag, idService) {
return varBag.cardOptionsJSONVar.value;
}
},
"c0ajsfLYxkWgKXl27RRKjQ": {
getter: function (varBag, idService) {
return varBag.getDateJSResult.value;
}
},
"zA+vDOSNh0qLoWUgN9_BCA": {
getter: function (varBag, idService) {
return varBag.optionsJSONVar.value;
}
},
"xXzBsNBtWUWFXHxbw8PC9A": {
getter: function (varBag, idService) {
return varBag.parametersChangedJSResult.value;
}
},
"UAJSHDU_jk6bEMg6p7lR2w": {
getter: function (varBag, idService) {
return varBag.model.variables.objVar;
},
dataType: OS.DataTypes.DataTypes.Object
},
"+OTfwNS0QEe0haiPLulFmw": {
getter: function (varBag, idService) {
return varBag.model.variables.dateInputVar;
},
dataType: OS.DataTypes.DataTypes.Text
},
"Vv727u9t6Ey3b67Kz5Ld+g": {
getter: function (varBag, idService) {
return varBag.model.variables.optionsIn;
}
},
"Mu3OUlOiI0iDABGw9Jz9RQ": {
getter: function (varBag, idService) {
return varBag.model.variables.extendedClassIn;
},
dataType: OS.DataTypes.DataTypes.Text
},
"yP8LZAfNWEqhHOyqJffc7A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Element"));
})(varBag.model, idService);
}
},
"KrAqY2g1CEWbra6qboSKag": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Label"));
})(varBag.model, idService);
}
},
"nKSTW0_enUyf7Du497oG9A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input_Date"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
