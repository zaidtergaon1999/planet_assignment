define("ShopperPortalEU.Authentication.TermsService.mvc$model", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Theme.controller", "ShopperPortalEU_Shopper_IS.controller", "ShopperPortalEU.controller$TRuleWrapper", "ShopperPortalEU_UI_Theme.model$LayoutDetailOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU_UI_Components.model$FullHeightContentOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$FullHeightContentTopOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentBottomOptionsRec", "ShopperPortalEU_UI_Components.model$CircleIconOptionsRec", "ShopperPortalEU_UI_Components.model$CircleIconIconOptionsRec", "ShopperPortalEU_UI_Components.model$CustomCheckboxOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsIconRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconRec", "ShopperPortalEU.controller$HeapIdentify", "ShopperPortalEU.model$ApcuesIdentifyRec", "ShopperPortalEU.controller$ApcuesIdentify", "ShopperPortalEU.controller$ShopperLogout", "ShopperPortalEU.controller$GetCurrentServerURL", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", "ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger", "ShopperPortalEU_Shopper_IS.controller$SetTermsAndConditions", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS", "ShopperPortalEU.controller$ClarityEvent", "ShopperPortalEU.controller$IsProfileEmpty", "ShopperPortalEU.controller$DefaultErrorMessage", "ShopperPortalEU.controller$GenericErrorMessage"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ThemeController, ShopperPortalEU_Shopper_ISController) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("Agree", "agreeVar", "Agree", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("IsLoading", "isLoadingVar", "IsLoading", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {
Checkbox_Agree: OS.Model.ValidationWidgetRecord
};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return true;
}
});

Model.prototype.setInputs = function (inputs) {
};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "Authentication.TermsService");
});
define("ShopperPortalEU.Authentication.TermsService.mvc$view", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Theme.controller", "ShopperPortalEU_Shopper_IS.controller", "react", "OutSystems/ReactView/Main", "ShopperPortalEU.Authentication.TermsService.mvc$model", "ShopperPortalEU.Authentication.TermsService.mvc$controller", "ShopperPortalEU.clientVariables", "ShopperPortalEU.Layouts.LayoutDetail.mvc$view", "OutSystems/ReactWidgets/Main", "ShopperPortalEU.LayoutsComponents.Back.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.FullHeightContent.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CircleIcon.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCheckbox.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomLink.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomLinkItem.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomButton.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomButtonItem.mvc$view", "ShopperPortalEU.controller$TRuleWrapper", "ShopperPortalEU_UI_Theme.model$LayoutDetailOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU_UI_Components.model$FullHeightContentOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$FullHeightContentTopOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentBottomOptionsRec", "ShopperPortalEU_UI_Components.model$CircleIconOptionsRec", "ShopperPortalEU_UI_Components.model$CircleIconIconOptionsRec", "ShopperPortalEU_UI_Components.model$CustomCheckboxOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsIconRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconRec", "ShopperPortalEU.controller$HeapIdentify", "ShopperPortalEU.model$ApcuesIdentifyRec", "ShopperPortalEU.controller$ApcuesIdentify", "ShopperPortalEU.controller$ShopperLogout", "ShopperPortalEU.controller$GetCurrentServerURL", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", "ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger", "ShopperPortalEU_Shopper_IS.controller$SetTermsAndConditions", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS", "ShopperPortalEU.controller$ClarityEvent", "ShopperPortalEU.controller$IsProfileEmpty", "ShopperPortalEU.controller$DefaultErrorMessage", "ShopperPortalEU.controller$GenericErrorMessage"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ThemeController, ShopperPortalEU_Shopper_ISController, React, OSView, ShopperPortalEU_Authentication_TermsService_mvc_model, ShopperPortalEU_Authentication_TermsService_mvc_controller, ShopperPortalEUClientVariables, ShopperPortalEU_Layouts_LayoutDetail_mvc_view, OSWidgets, ShopperPortalEU_LayoutsComponents_Back_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CircleIcon_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCheckbox_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLink_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLinkItem_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            var thisIsInstanceOfSuper = this instanceof _super;
            if (thisIsInstanceOfSuper == false) {
                return;
            }

            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "Authentication.TermsService";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css", "css/ShopperPortalEU_UI_Theme.ShopperPortalEUUITheme.css", "css/ShopperPortalEU.ShopperPortalEU.css", "css/ShopperPortalEU_UI_Theme.ShopperPortalEUUITheme.extra.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [ShopperPortalEU_Layouts_LayoutDetail_mvc_view, ShopperPortalEU_LayoutsComponents_Back_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CircleIcon_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCheckbox_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLink_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLinkItem_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return ShopperPortalEU_Authentication_TermsService_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return ShopperPortalEU_Authentication_TermsService_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "Shopper Portal EU - Terms of service";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(ShopperPortalEU_Layouts_LayoutDetail_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("FqYNwdSGskK_n6O69pXPkw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ThemeModel.LayoutDetailOptionsRec();
rec.headerStepsAttr = function () {
var rec = new ShopperPortalEU_UI_ThemeModel.HeaderStepsOptionsRec();
rec.stepsAttr = 4;
rec.currentStepAttr = 1;
return rec;
}();
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "0",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
headerLeft: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_LayoutsComponents_Back_mvc_view, {
inputs: {
ManualRedirect: true
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onClick$Action: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "LayoutsComponents/Back OnClick");
return controller.backOnClick$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "1",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}),
headerCenter: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "TermsOfServiceTitle"
},
value: "Terms of service",
_idProps: {
service: idService,
uuid: "2"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
headerRight: PlaceholderContent.Empty,
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("p_W1J+b3nUiqTunzaUniHg.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FullHeightContentOptionsRec();
rec.topAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FullHeightContentTopOptionsRec();
rec.verticalAlignmentAttr = ShopperPortalEUModel.staticEntities.fullHeightContentAlignment.center;
rec.horizontalAlignmentAttr = ShopperPortalEUModel.staticEntities.fullHeightContentAlignment.center;
return rec;
}();
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "3",
alias: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
top: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "text-align-center",
visible: true,
_idProps: {
service: idService,
uuid: "4"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CircleIcon_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("CLG8RpHCTES0Qa+EYHet7Q.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CircleIconOptionsRec();
rec.iconAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CircleIconIconOptionsRec();
rec.nameAttr = "terms_conditions_pictogram";
rec.familyAttr = ShopperPortalEUModel.staticEntities.customIconFamily.planet;
return rec;
}();
rec.sizeAttr = ShopperPortalEUModel.staticEntities.circleIconSize.large;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "5",
alias: "4"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCheckbox_mvc_view, {
inputs: {
ExtendedClass: "margin-top-08",
Options: model.getCachedValue(idService.getId("ezdgDXfQIky8dnbX1ke0YA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomCheckboxOptionsRec();
rec.testIdAttr = "TermsOfService";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "6",
alias: "5"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
checkbox: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Checkbox, {
_validationProps: {
validationService: validationService
},
enabled: !(model.variables.isLoadingVar),
style: "checkbox",
variable: model.createVariable(OS.DataTypes.DataTypes.Boolean, model.variables.agreeVar, function (value) {
model.variables.agreeVar = value;
}),
_idProps: {
service: idService,
name: "Checkbox_Agree"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
label: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "I have read and agree to Planet\'s ",
_idProps: {
service: idService,
uuid: "8"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "9"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLink_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("Tv0tpANDYEWMqEHsctNSGg.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomLinkOptionsRec();
rec.testIdAttr = "TermsAndConditionsLink";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "10",
alias: "6"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
link: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Link, {
enabled: true,
extendedProperties: {
target: "_blank"
},
transition: OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default),
url: OS.Navigation.generateScreenURL(OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("support_termsandconditions", "", callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id), {}),
visible: true,
_idProps: {
service: idService,
uuid: "11"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLinkItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "12",
alias: "7"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "terms and conditions",
_idProps: {
service: idService,
uuid: "13"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
}), React.createElement(OSWidgets.Expression, {
value: " and ",
_idProps: {
service: idService,
uuid: "14"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLink_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("YrsGRcueXEi2dvcDD4Idvw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomLinkOptionsRec();
rec.testIdAttr = "PrivacyPolicyLink";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "15",
alias: "8"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
link: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Link, {
enabled: true,
extendedProperties: {
target: "_blank"
},
transition: OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default),
url: OS.Navigation.generateScreenURL(OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("support_privacypolicy", "", callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id), {}),
visible: true,
_idProps: {
service: idService,
uuid: "16"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLinkItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "17",
alias: "9"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "privacy policy",
_idProps: {
service: idService,
uuid: "18"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables.isLoadingVar), asPrimitiveValue(model.variables.agreeVar)]
})];
}),
bottom: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("WM41nb56mUWIIJTb5NcD2A.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRec();
rec.testIdAttr = "TermsOfServiceContinue";
rec.typeAttr = ShopperPortalEUModel.staticEntities.customButtonType.primary;
rec.isLoadingAttr = model.variables.isLoadingVar;
rec.isFullWidthAttr = true;
return rec;
}();
}, function () {
return model.variables.isLoadingVar;
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "19",
alias: "10"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
button: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: model.variables.agreeVar,
isDefault: false,
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Authentication/TermsService/Button OnClick");
return controller.continue$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
style: "btn",
visible: true,
_idProps: {
service: idService,
uuid: "20"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "21",
alias: "11"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Continue",
_idProps: {
service: idService,
uuid: "22"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables.agreeVar)]
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.isLoadingVar), asPrimitiveValue(model.variables.agreeVar)]
})];
}),
bottom: PlaceholderContent.Empty
},
_dependencies: [asPrimitiveValue(model.variables.isLoadingVar), asPrimitiveValue(model.variables.agreeVar)]
}));
        };
        return View;
    })(OSView.BaseView.BaseWebScreen);
	
    return View;
});
define("ShopperPortalEU.Authentication.TermsService.mvc$controller", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Theme.controller", "ShopperPortalEU_Shopper_IS.controller", "ShopperPortalEU.languageResources", "ShopperPortalEU.clientVariables", "ShopperPortalEU.Authentication.TermsService.mvc$debugger", "ShopperPortalEU.Authentication.controller", "ShopperPortalEU.controller$TRuleWrapper", "ShopperPortalEU_UI_Theme.model$LayoutDetailOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU_UI_Components.model$FullHeightContentOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$FullHeightContentTopOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentBottomOptionsRec", "ShopperPortalEU_UI_Components.model$CircleIconOptionsRec", "ShopperPortalEU_UI_Components.model$CircleIconIconOptionsRec", "ShopperPortalEU_UI_Components.model$CustomCheckboxOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsIconRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconRec", "ShopperPortalEU.controller$HeapIdentify", "ShopperPortalEU.model$ApcuesIdentifyRec", "ShopperPortalEU.controller$ApcuesIdentify", "ShopperPortalEU.controller$ShopperLogout", "ShopperPortalEU.controller$GetCurrentServerURL", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", "ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger", "ShopperPortalEU_Shopper_IS.controller$SetTermsAndConditions", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS", "ShopperPortalEU.controller$ClarityEvent", "ShopperPortalEU.controller$IsProfileEmpty", "ShopperPortalEU.controller$DefaultErrorMessage", "ShopperPortalEU.controller$GenericErrorMessage"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ThemeController, ShopperPortalEU_Shopper_ISController, ShopperPortalEULanguageResources, ShopperPortalEUClientVariables, ShopperPortalEU_Authentication_TermsService_mvc_Debugger, ShopperPortalEU_AuthenticationController) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = true;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._onInitialize$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnInitialize");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:D1rbhFDZpkidMl48w4d16Q:/NRWebFlows.ozCJCRi2BU2OkqD4Zl84lQ/NodesShownInESpaceTree.MFxrfBocFEutRtAR+f6q8A/ClientActions.D1rbhFDZpkidMl48w4d16Q:baIYUJ1HO9dYoRYzoigwaA", "ShopperPortalEU", "OnInitialize", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:1dLCN8KH10GNygEEn7B+kw", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:5JqARVMvcU6R6kDNrsTNbQ", callContext.id);
// Execute Action: HeapIdentify
ShopperPortalEUController.default.heapIdentify$Action(ShopperPortalEUClientVariables.getEmail(), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:iz5WZNJvZEetbvLgFaNaKA", callContext.id);
// Execute Action: ApcuesIdentify
ShopperPortalEUController.default.apcuesIdentify$Action(function () {
var rec = new ShopperPortalEUModel.ApcuesIdentifyRec();
rec.guidAttr = ShopperPortalEUClientVariables.getShopperGuid();
rec.nameAttr = ShopperPortalEUClientVariables.getShopperName();
rec.emailAttr = ShopperPortalEUClientVariables.getEmail();
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:CM_ZqZj_CE6Ufnn_pYlv7g", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:D1rbhFDZpkidMl48w4d16Q", callContext.id);
}

};
Controller.prototype._backOnClick$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("BackOnClick");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:Q3ArlOmmyESd9r11GVTy7A:/NRWebFlows.ozCJCRi2BU2OkqD4Zl84lQ/NodesShownInESpaceTree.MFxrfBocFEutRtAR+f6q8A/ClientActions.Q3ArlOmmyESd9r11GVTy7A:06Lyl74lzDkLB5RIumnzjQ", "ShopperPortalEU", "BackOnClick", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:tvXOkZUFXUOIl0rjVAeCSA", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:X9__iHaDekW3LhJ3mIg_UA", callContext.id) && !(((ShopperPortalEUClientVariables.getLoginType() === 0) || (ShopperPortalEUClientVariables.getLoginType() === OS.BuiltinFunctions.nullIdentifier()))))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:JrPFEEK6yEq5bEJIoBT09g", callContext.id);
// LoginURL = GetCurrentServerURL() + "/ShopperPortalEU/VerifyIdentity?LT=" + LoginType
ShopperPortalEUClientVariables.setLoginURL(((OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.getCurrentServerURL$Action(callContext).uRLOut;
}, OS.DataTypes.DataTypes.Text, callContext.id) + "/ShopperPortalEU/VerifyIdentity?LT=") + (ShopperPortalEUClientVariables.getLoginType()).toString()));
}

OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:dyEed70Pt0+YYzy43j5Emw", callContext.id);
// Execute Action: ShopperLogout
model.flush();
return ShopperPortalEUController.default.shopperLogout$Action(callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:DOxnQ8P9AkGwTMO9j2iFaQ", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:Q3ArlOmmyESd9r11GVTy7A", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:Q3ArlOmmyESd9r11GVTy7A", callContext.id);
throw ex;

});
};
Controller.prototype._continue$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Continue");
callContext = controller.callContext(callContext);
var allExceptionsVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.ErrorHandlerOutputType());
var setTermsAndConditionsVar = new OS.DataTypes.VariableHolder();
var isProfileEmptyVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.allExceptionsVar = allExceptionsVar;
varBag.setTermsAndConditionsVar = setTermsAndConditionsVar;
varBag.isProfileEmptyVar = isProfileEmptyVar;
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:kXwo0dnuHkWLXYp5gGw+jA:/NRWebFlows.ozCJCRi2BU2OkqD4Zl84lQ/NodesShownInESpaceTree.MFxrfBocFEutRtAR+f6q8A/ClientActions.kXwo0dnuHkWLXYp5gGw+jA:xPMzHpy3aGLglyugj4LCtw", "ShopperPortalEU", "Continue", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:_JH62rL390SXzw80wAOzpQ", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:E1dGdUWwNUuDQcY1uedVmA", callContext.id) && model.variables.agreeVar)) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Grnp+001SE6pApenILhV+A", callContext.id);
// IsLoading = True
model.variables.isLoadingVar = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:GsIkIXqgAkqV8X7Cozn1oQ", callContext.id);
// Execute Action: SetTermsAndConditions
model.flush();
return ShopperPortalEU_Shopper_ISController.default.setTermsAndConditions$Action(ShopperPortalEUClientVariables.getShopperGuid(), callContext).then(function (value) {
setTermsAndConditionsVar.value = value;
}).then(function () {
// IsSuccess
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:MIgezeudJ0CEh66ytVcNVA", callContext.id) && setTermsAndConditionsVar.value.isSuccessOut)) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:z+ETz6Vzok2wwMceFEx_jw", callContext.id);
// Execute Action: IsProfileEmpty
model.flush();
return ShopperPortalEUController.default.isProfileEmpty$Action(callContext).then(function (value) {
isProfileEmptyVar.value = value;
}).then(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:7uLyTY4WbUmOjwjnAI84eg", callContext.id) && isProfileEmptyVar.value.successOut)) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:cAeFXis2K0Kr__03w+Emhg", callContext.id);
// Execute Action: ClarityEvent
ShopperPortalEUController.default.clarityEvent$Action("T&Cs_btn", callContext);
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:dUicWpmIx0aWcz9cVKrhZg", callContext.id) && isProfileEmptyVar.value.resultOut)) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:S7AEnR3uXUepCVXxQVwg3A", callContext.id);
// Destination: /ShopperPortalEU/PassportDetails
return OS.Flow.returnAsync(OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "PassportDetails", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true));
} else {
// Update vars
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:4qwNSQdSAUqzjQcMzDkLKg", callContext.id);
// IsProfileDetailsNavigation = False
ShopperPortalEUClientVariables.setIsProfileDetailsNavigation(false);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:UgwPZmwIbUSqlaq3mINKnw", callContext.id);
// Destination: /ShopperPortalEU/CompleteDetails
return OS.Flow.returnAsync(OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "CompleteDetails", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true));
}

} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:peU90shKhkmIpkOOUbD6lg", callContext.id);
// IsLoading = False
model.variables.isLoadingVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:wl_zHVqJHU2GDLAsw+ODGA", callContext.id);
// Execute Action: CustomMessageTrigger2
ShopperPortalEU_UI_ThemeController.default.customMessageTrigger$Action(function () {
var rec = new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customMessageType.error;
rec.titleAttr = isProfileEmptyVar.value.errorMessageOut;
rec.contentAttr = OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.defaultErrorMessage$Action(callContext).errorMessageOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
rec.testIdAttr = "GetShopperError";
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:NhXEeZI0UUW_6vRJ2LAXGw", callContext.id);
}

});
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:107Ou3_nMU+Hq5cGQVLDGQ", callContext.id);
// IsLoading = False
model.variables.isLoadingVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:86awQ+dhFk+bs4lct7ANcQ", callContext.id);
// Execute Action: CustomMessageTrigger
ShopperPortalEU_UI_ThemeController.default.customMessageTrigger$Action(function () {
var rec = new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customMessageType.error;
rec.titleAttr = setTermsAndConditionsVar.value.errorMessageOut;
rec.contentAttr = OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.defaultErrorMessage$Action(callContext).errorMessageOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
rec.testIdAttr = "TermsOfServiceError";
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:0XELIzOBME6wiVyR00Kekg", callContext.id);
}

});
});
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:5rCeeCYeAkaXLTkmpz4nEA", callContext.id);
}

});
}).catch(function (ex) {
OS.Logger.trace("TermsService.Continue", OS.Exceptions.getMessage(ex), ex.name);
// Handle Error: AllExceptions
if(!(OS.Exceptions.isSystem(ex))) {
OS.Logger.error(null, ex);
allExceptionsVar.value.exceptionMessageAttr = OS.Exceptions.getMessage(ex);
OutSystemsDebugger.handleException(allExceptionsVar.value.exceptionMessageAttr, callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:WtJM1P+SBEWDckVu88UqQQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:AOOB5loCzkWhPuC8p_nWjQ", callContext.id);
// Execute Action: CustomMessageTrigger3
ShopperPortalEU_UI_ThemeController.default.customMessageTrigger$Action(function () {
var rec = new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customMessageType.error;
rec.titleAttr = "Sorry, we are experiencing technical difficulties";
rec.contentAttr = OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.genericErrorMessage$Action(callContext).errorMessageOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:7eV6wRys3EWbthpO+ixksA", callContext.id);
return OS.Flow.returnAsync();

});
}

throw ex;
}).then(function (res) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:kXwo0dnuHkWLXYp5gGw+jA", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:kXwo0dnuHkWLXYp5gGw+jA", callContext.id);
throw ex;

});
};

Controller.prototype.onInitialize$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onInitialize$Action, callContext);

};
Controller.prototype.backOnClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._backOnClick$Action, callContext);

};
Controller.prototype.continue$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._continue$Action, callContext);

};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:ozCJCRi2BU2OkqD4Zl84lQ:/NRWebFlows.ozCJCRi2BU2OkqD4Zl84lQ:EruRjKvlJ0FVyQ96YiDGmw", "ShopperPortalEU", "Authentication", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:MFxrfBocFEutRtAR+f6q8A:/NRWebFlows.ozCJCRi2BU2OkqD4Zl84lQ/NodesShownInESpaceTree.MFxrfBocFEutRtAR+f6q8A:fbGsbO3w5M3JXlFPVA50WA", "ShopperPortalEU", "TermsService", "NRNodes.WebScreen", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:MFxrfBocFEutRtAR+f6q8A", callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:ozCJCRi2BU2OkqD4Zl84lQ", callContext.id);
};
Controller.prototype.onInitializeEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Authentication/TermsService On Initialize");
return controller.onInitialize$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return ShopperPortalEU_AuthenticationController.default.handleError(ex, this.callContext());
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return ShopperPortalEUController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, ShopperPortalEULanguageResources);
});

define("ShopperPortalEU.Authentication.TermsService.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"WtJM1P+SBEWDckVu88UqQQ": {
getter: function (varBag, idService) {
return varBag.allExceptionsVar.value;
}
},
"GsIkIXqgAkqV8X7Cozn1oQ": {
getter: function (varBag, idService) {
return varBag.setTermsAndConditionsVar.value;
}
},
"z+ETz6Vzok2wwMceFEx_jw": {
getter: function (varBag, idService) {
return varBag.isProfileEmptyVar.value;
}
},
"TRffjUNOmEeCfqKL84GP8Q": {
getter: function (varBag, idService) {
return varBag.model.variables.agreeVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"5f0_F_ZzEUKZkWRuGxk0+g": {
getter: function (varBag, idService) {
return varBag.model.variables.isLoadingVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"G_wOYOom90e0L4MnXJV+FQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderLeft"));
})(varBag.model, idService);
}
},
"+73vR4UKJES3wfhT+Z7E5A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderCenter"));
})(varBag.model, idService);
}
},
"8v6xeHWIlUyFgPEe2nY6IA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderRight"));
})(varBag.model, idService);
}
},
"wMHXLNdYuEimJ2nka0tJIA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"kFOygNUwk0618_YHHfHk_w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Top"));
})(varBag.model, idService);
}
},
"zQXtN8RJfUWA1QYntIpjoQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Checkbox"));
})(varBag.model, idService);
}
},
"OzTwe0dPnUC+Gh4QaJSHew": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Checkbox_Agree"));
})(varBag.model, idService);
}
},
"ob6Q2BNQVkSoyP8JAZJrJQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Label"));
})(varBag.model, idService);
}
},
"g4v7F9HoAki2TSY4I+JGcQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Link"));
})(varBag.model, idService);
}
},
"WGs4khzKPE6zxNAmK1e+iA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"3eOpYaSHhkyKO4q69b3hDw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Link"));
})(varBag.model, idService);
}
},
"t2vSk2gJHUC5kj9pz_tUuw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"h95MqrrHp0KgVjgbafBmdw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Bottom"));
})(varBag.model, idService);
}
},
"Sxg9DCM4C0i_gU57FIZBUQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Button"));
})(varBag.model, idService);
}
},
"rJwMvU9ON0GOvtc8EiWJKw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"SELVkg6CzE2z1oue+d20_A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Bottom"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
