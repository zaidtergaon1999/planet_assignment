class circleIcon {
  constructor(id, options) {
    this.element = document.getElementById(id);
    this.options = options;
    this._build();
  }
  _setCSSVariables() {
    this.element.style.setProperty('--circle-background', this.options.background);
  }
  _build() {
    this._setCSSVariables();
  }
  parametersChanged(options) {
    this.options = options;
    this._setCSSVariables();
  }
}