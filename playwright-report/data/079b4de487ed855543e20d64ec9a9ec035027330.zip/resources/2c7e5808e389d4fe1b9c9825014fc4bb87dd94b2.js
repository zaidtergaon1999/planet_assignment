try {require(["es6-promise", "tslib"], function (es6promise, tslib) {
require(["OutSystems/ClientRuntime/Main", "ShopperPortalEU.appDefinition"], function (OutSystems, ShopperPortalEUAppDefinition) {
var OS = OutSystems.Internal;
OS.Settings.setPlatformSettings({
IndexedDBOffline: false,
UseNewWebSQLImpl: false,
SendEnvParamOnManifestRequest: true
});
OS.ErrorScreen.initializeErrorPage(ShopperPortalEUAppDefinition, OS.Application.default);
});
});
} catch (ex) {
console.error(ex);
}

