define("ShopperPortalEU_DataSync.controller$GetCMSBackofficeTranslations", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_DataSync.model", "ShopperPortalEU_DataSync.controller", "ShopperPortalEU_CMS_IS.model", "ShopperPortalEU_DataSync.controller$GetCMSBackofficeTranslations.GetJSONCountryRulesJS", "ShopperPortalEU_CMS_IS.model$CountryRuleTranslationRec", "ShopperPortalEU_DataSync.referencesHealth", "ShopperPortalEU_DataSync.referencesHealth$ShopperPortalEU_CMS_IS", "ShopperPortalEU_DataSync.model$CountryRuleTranslationList"], function (exports, OutSystems, ShopperPortalEU_DataSyncModel, ShopperPortalEU_DataSyncController, ShopperPortalEU_CMS_ISModel, ShopperPortalEU_DataSync_controller_GetCMSBackofficeTranslations_GetJSONCountryRulesJS) {
var OS = OutSystems.Internal;
ShopperPortalEU_DataSyncController.default.getCMSBackofficeTranslations$Action = function (countryCodeIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_DataSync.GetCMSBackofficeTranslations$vars"))());
vars.value.countryCodeInLocal = countryCodeIn;
var getJSONCountryRulesJSResult = new OS.DataTypes.VariableHolder();
var jSONDeserializeCountryRulesVar = new OS.DataTypes.VariableHolder(new (OS.Controller.BaseController.getJSONDeserializeOutputType(ShopperPortalEU_DataSyncModel.CountryRuleTranslationList))());
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_DataSync.GetCMSBackofficeTranslations$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.getJSONCountryRulesJSResult = getJSONCountryRulesJSResult;
varBag.jSONDeserializeCountryRulesVar = jSONDeserializeCountryRulesVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("BzPXzb2R8k2PLMHT7WmUdg:upqBhlihqUSshJirTJI4Mg:/ClientActionFlows.upqBhlihqUSshJirTJI4Mg:JVTlLO4YwTGm0zKyykGZjg", "ShopperPortalEU_DataSync", "GetCMSBackofficeTranslations", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:RtJDtdvBlkaI3pRFrXWmlQ", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:DYZmmUk_Q0mWIl8z3uv5RQ", callContext.id) && ((vars.value.countryCodeInLocal) !== ("")))) {
OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:FlZl73ej+UCGyi7Bvj4G3g", callContext.id);
getJSONCountryRulesJSResult.value = controller.safeExecuteJSNode(ShopperPortalEU_DataSync_controller_GetCMSBackofficeTranslations_GetJSONCountryRulesJS, "GetJSONCountryRules", "GetCMSBackofficeTranslations", {
jsonCountryRules: OS.DataConversion.JSNodeParamConverter.to("", OS.DataTypes.DataTypes.Text)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("ShopperPortalEU_DataSync.GetCMSBackofficeTranslations$getJSONCountryRulesJSResult"))();
jsNodeResult.jsonCountryRulesOut = OS.DataConversion.JSNodeParamConverter.from($parameters.jsonCountryRules, OS.DataTypes.DataTypes.Text);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:lWtdFOmwtUGQhNliKquwpA", callContext.id);
// JSON Deserialize: JSONDeserializeCountryRules
jSONDeserializeCountryRulesVar.value.dataOut = OS.JSONUtils.deserializeFromJSON(getJSONCountryRulesJSResult.value.jsonCountryRulesOut, ShopperPortalEU_DataSyncModel.CountryRuleTranslationList, false);
// Foreach JSONDeserializeCountryRules.Data
callContext.iterationContext.registerIterationStart(jSONDeserializeCountryRulesVar.value.dataOut);
try {var dataIterator = callContext.iterationContext.getIterator(jSONDeserializeCountryRulesVar.value.dataOut);
var dataIndex = 0;
while ((OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:jXw89ePAF06TtjRqKovl8g", callContext.id) && (dataIndex < jSONDeserializeCountryRulesVar.value.dataOut.length))) {
dataIterator.currentRowNumber = dataIndex;
// Selected country ?
if((OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:TDkdSKtx80upEHpR8QUwDA", callContext.id) && (jSONDeserializeCountryRulesVar.value.dataOut.getItem(dataIndex.valueOf()).countryCodeAttr === vars.value.countryCodeInLocal))) {
OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:Q+xK7cm1HkWqIbOzajXobA", callContext.id);
// Translation = JSONDeserializeCountryRules.Data.Current
outVars.value.translationOut = jSONDeserializeCountryRulesVar.value.dataOut.getItem(dataIndex.valueOf());
}

dataIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(jSONDeserializeCountryRulesVar.value.dataOut);
}

OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:7f8ZscdHyUOniPRCg0Ca+Q", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:D0jkysEgykGxP6lc+G8Itw", callContext.id);
}

return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("BzPXzb2R8k2PLMHT7WmUdg:upqBhlihqUSshJirTJI4Mg", callContext.id);
}

};
var controller = ShopperPortalEU_DataSyncController.default;
ShopperPortalEU_DataSyncController.default.constructor.registerVariableGroupType("ShopperPortalEU_DataSync.GetCMSBackofficeTranslations$vars", [{
name: "CountryCode",
attrName: "countryCodeInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEU_DataSyncController.default.constructor.registerVariableGroupType("ShopperPortalEU_DataSync.GetCMSBackofficeTranslations$getJSONCountryRulesJSResult", [{
name: "jsonCountryRules",
attrName: "jsonCountryRulesOut",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEU_DataSyncController.default.constructor.registerVariableGroupType("ShopperPortalEU_DataSync.GetCMSBackofficeTranslations$outVars", [{
name: "Translation",
attrName: "translationOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Record,
defaultValue: function () {
return new ShopperPortalEU_CMS_ISModel.CountryRuleTranslationRec();
},
complexType: ShopperPortalEU_CMS_ISModel.CountryRuleTranslationRec
}]);
ShopperPortalEU_DataSyncController.default.clientActionProxies.getCMSBackofficeTranslations$Action = function (countryCodeIn) {
countryCodeIn = (countryCodeIn === undefined) ? "" : countryCodeIn;
return controller.executeActionInsideJSNode(ShopperPortalEU_DataSyncController.default.getCMSBackofficeTranslations$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(countryCodeIn, OS.DataTypes.DataTypes.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Translation: actionResults.translationOut
};
});
};
});
define("ShopperPortalEU_DataSync.controller$GetCMSBackofficeTranslations.GetJSONCountryRulesJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
try {
    
    if(window.localStorage.getItem('jsonCountryRules') !== null){
        $parameters.jsonCountryRules = window.localStorage.getItem('jsonCountryRules');
    }
    
} catch (e) {
    console.log(e);
}

};
});

define("ShopperPortalEU_DataSync.controller$GetKeyByLabel", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_DataSync.model", "ShopperPortalEU_DataSync.controller", "ShopperPortalEU_CMS_IS.model", "ShopperPortalEU_CMS_IS.model$TranslationRec", "ShopperPortalEU_DataSync.referencesHealth", "ShopperPortalEU_DataSync.referencesHealth$ShopperPortalEU_CMS_IS", "ShopperPortalEU_DataSync.controller$GetLanguageT", "ShopperPortalEU_CMS_IS.model$TranslationItemRec", "ShopperPortalEU_DataSync.model$TranslationItemList"], function (exports, OutSystems, ShopperPortalEU_DataSyncModel, ShopperPortalEU_DataSyncController, ShopperPortalEU_CMS_ISModel) {
var OS = OutSystems.Internal;
ShopperPortalEU_DataSyncController.default.getKeyByLabel$Action = function (labelIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_DataSync.GetKeyByLabel$vars"))());
vars.value.labelInLocal = labelIn;
var getEnglishTranslationsVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_DataSync.GetKeyByLabel$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.getEnglishTranslationsVar = getEnglishTranslationsVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("BzPXzb2R8k2PLMHT7WmUdg:UcQsH4v8Q029vHeRWEzZ8Q:/ClientActionFlows.UcQsH4v8Q029vHeRWEzZ8Q:EODctzUFQcpdIyX1q1cMDQ", "ShopperPortalEU_DataSync", "GetKeyByLabel", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:jd2friGNZEWkoPO_AeBqPw", callContext.id);
OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:+0Yhh3Glrk+TyO5MVYFxfQ", callContext.id);
// Execute Action: GetEnglishTranslations
getEnglishTranslationsVar.value = ShopperPortalEU_DataSyncController.default.getLanguageT$Action("en", callContext);

// Foreach GetEnglishTranslations.Translation.Translations
callContext.iterationContext.registerIterationStart(getEnglishTranslationsVar.value.translationOut.translationsAttr);
try {var translationsIterator = callContext.iterationContext.getIterator(getEnglishTranslationsVar.value.translationOut.translationsAttr);
var translationsIndex = 0;
while ((OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:Ip0vhOdkgUW1qgUXhQg0ug", callContext.id) && (translationsIndex < getEnglishTranslationsVar.value.translationOut.translationsAttr.length))) {
translationsIterator.currentRowNumber = translationsIndex;
// Translation found ?
if((OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:gTi+uOGr4U6bMkL8zvW78Q", callContext.id) && (vars.value.labelInLocal === getEnglishTranslationsVar.value.translationOut.translationsAttr.getItem(translationsIndex.valueOf()).valueAttr))) {
OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:GlsgCLwSSkCjdw2+D3sTYg", callContext.id);
// Key = GetEnglishTranslations.Translation.Translations.Current.Key
outVars.value.keyOut = getEnglishTranslationsVar.value.translationOut.translationsAttr.getItem(translationsIndex.valueOf()).keyAttr;
}

translationsIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(getEnglishTranslationsVar.value.translationOut.translationsAttr);
}

OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:y6gxMg+RnUuSwUBJA1iU+A", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("BzPXzb2R8k2PLMHT7WmUdg:UcQsH4v8Q029vHeRWEzZ8Q", callContext.id);
}

};
var controller = ShopperPortalEU_DataSyncController.default;
ShopperPortalEU_DataSyncController.default.constructor.registerVariableGroupType("ShopperPortalEU_DataSync.GetKeyByLabel$vars", [{
name: "Label",
attrName: "labelInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEU_DataSyncController.default.constructor.registerVariableGroupType("ShopperPortalEU_DataSync.GetKeyByLabel$outVars", [{
name: "Key",
attrName: "keyOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEU_DataSyncController.default.clientActionProxies.getKeyByLabel$Action = function (labelIn) {
labelIn = (labelIn === undefined) ? "" : labelIn;
return controller.executeActionInsideJSNode(ShopperPortalEU_DataSyncController.default.getKeyByLabel$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(labelIn, OS.DataTypes.DataTypes.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Key: OS.DataConversion.JSNodeParamConverter.to(actionResults.keyOut, OS.DataTypes.DataTypes.Text)
};
});
};
});

define("ShopperPortalEU_DataSync.controller$GetLanguageT", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_DataSync.model", "ShopperPortalEU_DataSync.controller", "ShopperPortalEU_CMS_IS.model", "ShopperPortalEU_DataSync.controller$GetLanguageT.GetJsonTJS", "ShopperPortalEU_CMS_IS.model$TranslationRec", "ShopperPortalEU_DataSync.referencesHealth", "ShopperPortalEU_DataSync.referencesHealth$ShopperPortalEU_CMS_IS", "ShopperPortalEU_DataSync.model$TranslationList"], function (exports, OutSystems, ShopperPortalEU_DataSyncModel, ShopperPortalEU_DataSyncController, ShopperPortalEU_CMS_ISModel, ShopperPortalEU_DataSync_controller_GetLanguageT_GetJsonTJS) {
var OS = OutSystems.Internal;
ShopperPortalEU_DataSyncController.default.getLanguageT$Action = function (languageCodeIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_DataSync.GetLanguageT$vars"))());
vars.value.languageCodeInLocal = languageCodeIn;
var getJsonTJSResult = new OS.DataTypes.VariableHolder();
var jSONDeserializeTranslationVar = new OS.DataTypes.VariableHolder(new (OS.Controller.BaseController.getJSONDeserializeOutputType(ShopperPortalEU_DataSyncModel.TranslationList))());
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_DataSync.GetLanguageT$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.getJsonTJSResult = getJsonTJSResult;
varBag.jSONDeserializeTranslationVar = jSONDeserializeTranslationVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("BzPXzb2R8k2PLMHT7WmUdg:B64t5Ln4I0WN+ky8u9Nqaw:/ClientActionFlows.B64t5Ln4I0WN+ky8u9Nqaw:DmHp35kpLzbd7C3TRQOpVQ", "ShopperPortalEU_DataSync", "GetLanguageT", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:_Px73A3Im0WS4gQzmgzkeQ", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:ZFqagpBJqUyJfrfvMix8tw", callContext.id) && ((vars.value.languageCodeInLocal) !== ("")))) {
OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:EJW50VvPuUqKyNHFQrd5Uw", callContext.id);
getJsonTJSResult.value = controller.safeExecuteJSNode(ShopperPortalEU_DataSync_controller_GetLanguageT_GetJsonTJS, "GetJsonT", "GetLanguageT", {
jsonT: OS.DataConversion.JSNodeParamConverter.to("", OS.DataTypes.DataTypes.Text)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("ShopperPortalEU_DataSync.GetLanguageT$getJsonTJSResult"))();
jsNodeResult.jsonTOut = OS.DataConversion.JSNodeParamConverter.from($parameters.jsonT, OS.DataTypes.DataTypes.Text);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:eLZfGRjjvUCt23cqmtrM5Q", callContext.id);
// JSON Deserialize: JSONDeserializeTranslation
jSONDeserializeTranslationVar.value.dataOut = OS.JSONUtils.deserializeFromJSON(getJsonTJSResult.value.jsonTOut, ShopperPortalEU_DataSyncModel.TranslationList, false);
// Foreach JSONDeserializeTranslation.Data
callContext.iterationContext.registerIterationStart(jSONDeserializeTranslationVar.value.dataOut);
try {var dataIterator = callContext.iterationContext.getIterator(jSONDeserializeTranslationVar.value.dataOut);
var dataIndex = 0;
while ((OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:GLnOcvyQUU+zqW+At_gx5w", callContext.id) && (dataIndex < jSONDeserializeTranslationVar.value.dataOut.length))) {
dataIterator.currentRowNumber = dataIndex;
// English ?
if((OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:KZv86x_8gUKXT2STiV6IGw", callContext.id) && (jSONDeserializeTranslationVar.value.dataOut.getItem(dataIndex.valueOf()).languageCodeAttr === vars.value.languageCodeInLocal))) {
OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:JETC7zXr7UOkNI4WH2hZ4g", callContext.id);
// Translation = JSONDeserializeTranslation.Data.Current
outVars.value.translationOut = jSONDeserializeTranslationVar.value.dataOut.getItem(dataIndex.valueOf());
}

dataIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(jSONDeserializeTranslationVar.value.dataOut);
}

OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:3kyeZE4lk0y9oevbVRhBwA", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:Edtm1dwxQkiSt+X31dEb4w", callContext.id);
}

return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("BzPXzb2R8k2PLMHT7WmUdg:B64t5Ln4I0WN+ky8u9Nqaw", callContext.id);
}

};
var controller = ShopperPortalEU_DataSyncController.default;
ShopperPortalEU_DataSyncController.default.constructor.registerVariableGroupType("ShopperPortalEU_DataSync.GetLanguageT$vars", [{
name: "LanguageCode",
attrName: "languageCodeInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEU_DataSyncController.default.constructor.registerVariableGroupType("ShopperPortalEU_DataSync.GetLanguageT$getJsonTJSResult", [{
name: "jsonT",
attrName: "jsonTOut",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEU_DataSyncController.default.constructor.registerVariableGroupType("ShopperPortalEU_DataSync.GetLanguageT$outVars", [{
name: "Translation",
attrName: "translationOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Record,
defaultValue: function () {
return new ShopperPortalEU_CMS_ISModel.TranslationRec();
},
complexType: ShopperPortalEU_CMS_ISModel.TranslationRec
}]);
ShopperPortalEU_DataSyncController.default.clientActionProxies.getLanguageT$Action = function (languageCodeIn) {
languageCodeIn = (languageCodeIn === undefined) ? "" : languageCodeIn;
return controller.executeActionInsideJSNode(ShopperPortalEU_DataSyncController.default.getLanguageT$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(languageCodeIn, OS.DataTypes.DataTypes.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Translation: actionResults.translationOut
};
});
};
});
define("ShopperPortalEU_DataSync.controller$GetLanguageT.GetJsonTJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
try {
    
    if(window.localStorage.getItem('jsonT') !== null){
        $parameters.jsonT = window.localStorage.getItem('jsonT');
    }
    
} catch (e) {
    console.log(e);
}

};
});

define("ShopperPortalEU_DataSync.controller$LoadCMSBackofficeTToLocalStorage", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_DataSync.model", "ShopperPortalEU_DataSync.controller", "ShopperPortalEU_CMS_IS.model", "ShopperPortalEU_DataSync.controller$LoadCMSBackofficeTToLocalStorage.SaveCountryRulesJS", "ShopperPortalEU_CMS_IS.model$CountryRuleTranslationRec", "ShopperPortalEU_DataSync.referencesHealth", "ShopperPortalEU_DataSync.referencesHealth$ShopperPortalEU_CMS_IS", "ShopperPortalEU_DataSync.model$CountryRuleTranslationList"], function (exports, OutSystems, ShopperPortalEU_DataSyncModel, ShopperPortalEU_DataSyncController, ShopperPortalEU_CMS_ISModel, ShopperPortalEU_DataSync_controller_LoadCMSBackofficeTToLocalStorage_SaveCountryRulesJS) {
var OS = OutSystems.Internal;
ShopperPortalEU_DataSyncController.default.loadCMSBackofficeTToLocalStorage$Action = function (translationsIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_DataSync.LoadCMSBackofficeTToLocalStorage$vars"))());
vars.value.translationsInLocal = translationsIn.clone();
var jSONSerializeTranslationsVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.JSONSerializeOutputType());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.jSONSerializeTranslationsVar = jSONSerializeTranslationsVar;
OutSystemsDebugger.push("BzPXzb2R8k2PLMHT7WmUdg:nopfrFdKQU2+nosSANBIMQ:/ClientActionFlows.nopfrFdKQU2+nosSANBIMQ:kWbgcMUIx_DeIxakAeqP7Q", "ShopperPortalEU_DataSync", "LoadCMSBackofficeTToLocalStorage", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:DReumdt1jkOeaEfgAAkzTQ", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
// Has CountryRules
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:mrPXHKoolU+E7nFK8YY1yg", callContext.id) && !(vars.value.translationsInLocal.isEmpty))) {
OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:YoI1t_1m5ESCrprqz9vlfA", callContext.id);
// JSON Serialize: JSONSerializeTranslations
jSONSerializeTranslationsVar.value.jSONOut = OS.JSONUtils.serializeToJSON(vars.value.translationsInLocal, false, false);
OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:6N+8j5Ax_EyG16YDrZywAg", callContext.id);
return controller.safeExecuteAsyncJSNode(ShopperPortalEU_DataSync_controller_LoadCMSBackofficeTToLocalStorage_SaveCountryRulesJS, "SaveCountryRules", "LoadCMSBackofficeTToLocalStorage", {
Text: OS.DataConversion.JSNodeParamConverter.to(jSONSerializeTranslationsVar.value.jSONOut, OS.DataTypes.DataTypes.Text)
}, function ($parameters) {
}, {}, {}).then(function () {
OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:Y7019AoZo0qjLJArTp654Q", callContext.id);
});
} else {
OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:zoX6aicTVE+iPt6MzUKf8Q", callContext.id);
}

});
}).then(function () {
return ;
}).then(function (res) {
OutSystemsDebugger.pop("BzPXzb2R8k2PLMHT7WmUdg:nopfrFdKQU2+nosSANBIMQ", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("BzPXzb2R8k2PLMHT7WmUdg:nopfrFdKQU2+nosSANBIMQ", callContext.id);
throw ex;

});
};
var controller = ShopperPortalEU_DataSyncController.default;
ShopperPortalEU_DataSyncController.default.constructor.registerVariableGroupType("ShopperPortalEU_DataSync.LoadCMSBackofficeTToLocalStorage$vars", [{
name: "Translations",
attrName: "translationsInLocal",
mandatory: false,
dataType: OS.DataTypes.DataTypes.RecordList,
defaultValue: function () {
return new ShopperPortalEU_DataSyncModel.CountryRuleTranslationList();
},
complexType: ShopperPortalEU_DataSyncModel.CountryRuleTranslationList
}]);
ShopperPortalEU_DataSyncController.default.clientActionProxies.loadCMSBackofficeTToLocalStorage$Action = function (translationsIn) {
translationsIn = (translationsIn === undefined) ? new ShopperPortalEU_DataSyncModel.CountryRuleTranslationList() : translationsIn;
return controller.executeActionInsideJSNode(ShopperPortalEU_DataSyncController.default.loadCMSBackofficeTToLocalStorage$Action.bind(controller, translationsIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("ShopperPortalEU_DataSync.controller$LoadCMSBackofficeTToLocalStorage.SaveCountryRulesJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
return new Promise(function ($resolve, $reject) {
try {
    const jsonCountryRules = JSON.parse($parameters.Text);

    window.localStorage.setItem("jsonCountryRules", JSON.stringify(jsonCountryRules));

    $resolve();
} catch (e) {
    $reject(e);
}
});
};
});

define("ShopperPortalEU_DataSync.controller$SyncCMSBackofficeTranslations", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_DataSync.model", "ShopperPortalEU_DataSync.controller", "ShopperPortalEU_CMS_IS.model", "ShopperPortalEU_DataSync.controller$SyncCMSBackofficeTranslations.GetJSONCountryRulesJS", "ShopperPortalEU_CMS_IS.model$CountryRuleTranslationRec", "ShopperPortalEU_DataSync.referencesHealth", "ShopperPortalEU_DataSync.referencesHealth$ShopperPortalEU_CMS_IS", "ShopperPortalEU_DataSync.model$CountryRuleTranslationList", "ShopperPortalEU_DataSync.controller$LoadCMSBackofficeTToLocalStorage", "ShopperPortalEU_DataSync.controller$ServerAction.GetCMSCountryRules"], function (exports, OutSystems, ShopperPortalEU_DataSyncModel, ShopperPortalEU_DataSyncController, ShopperPortalEU_CMS_ISModel, ShopperPortalEU_DataSync_controller_SyncCMSBackofficeTranslations_GetJSONCountryRulesJS) {
var OS = OutSystems.Internal;
ShopperPortalEU_DataSyncController.default.syncCMSBackofficeTranslations$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var getCMSCountryRulesVar = new OS.DataTypes.VariableHolder();
var getJSONCountryRulesJSResult = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.getCMSCountryRulesVar = getCMSCountryRulesVar;
varBag.getJSONCountryRulesJSResult = getJSONCountryRulesJSResult;
OutSystemsDebugger.push("BzPXzb2R8k2PLMHT7WmUdg:Hq+nAj9zP0+1uUqwNxpzrg:/ClientActionFlows.Hq+nAj9zP0+1uUqwNxpzrg:FUqtNCXPNgVYPIjilvcxeA", "ShopperPortalEU_DataSync", "SyncCMSBackofficeTranslations", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:gg8+J4w0LUqFV3R8Amff9A", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:Ktf4iyABpkWg0LEQIjj8Og", callContext.id);
getJSONCountryRulesJSResult.value = controller.safeExecuteJSNode(ShopperPortalEU_DataSync_controller_SyncCMSBackofficeTranslations_GetJSONCountryRulesJS, "GetJSONCountryRules", "SyncCMSBackofficeTranslations", {
jsonCountryRules: OS.DataConversion.JSNodeParamConverter.to("", OS.DataTypes.DataTypes.Text)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("ShopperPortalEU_DataSync.SyncCMSBackofficeTranslations$getJSONCountryRulesJSResult"))();
jsNodeResult.jsonCountryRulesOut = OS.DataConversion.JSNodeParamConverter.from($parameters.jsonCountryRules, OS.DataTypes.DataTypes.Text);
return jsNodeResult;
}, {}, {});
// Didn't sync yet ?
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:CYOdnOLWyE6yBxgKsCuByA", callContext.id) && (getJSONCountryRulesJSResult.value.jsonCountryRulesOut === ""))) {
OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:vdVE5L24XEun6W29_3ZGgg", callContext.id);
// Execute Action: GetCMSCountryRules
return controller.getCMSCountryRules$ServerAction(callContext).then(function (value) {
getCMSCountryRulesVar.value = value;
}).then(function () {
OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:THgytfLl1UGZ1u2s9NJr_g", callContext.id);
// Execute Action: LoadCMSBackofficeTToLocalStorage
return ShopperPortalEU_DataSyncController.default.loadCMSBackofficeTToLocalStorage$Action(getCMSCountryRulesVar.value.countryRulesOut, callContext);
}).then(function () {
OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:266NNLHjLkW5JX5C2jv0iQ", callContext.id);
});
} else {
OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:z0CggxBSQEuAerXv2sYLAw", callContext.id);
}

});
}).then(function () {
return ;
}).then(function (res) {
OutSystemsDebugger.pop("BzPXzb2R8k2PLMHT7WmUdg:Hq+nAj9zP0+1uUqwNxpzrg", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("BzPXzb2R8k2PLMHT7WmUdg:Hq+nAj9zP0+1uUqwNxpzrg", callContext.id);
throw ex;

});
};
var controller = ShopperPortalEU_DataSyncController.default;
ShopperPortalEU_DataSyncController.default.constructor.registerVariableGroupType("ShopperPortalEU_DataSync.SyncCMSBackofficeTranslations$getJSONCountryRulesJSResult", [{
name: "jsonCountryRules",
attrName: "jsonCountryRulesOut",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEU_DataSyncController.default.clientActionProxies.syncCMSBackofficeTranslations$Action = function () {
return controller.executeActionInsideJSNode(ShopperPortalEU_DataSyncController.default.syncCMSBackofficeTranslations$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("ShopperPortalEU_DataSync.controller$SyncCMSBackofficeTranslations.GetJSONCountryRulesJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
try {
    
    if(window.localStorage.getItem('jsonCountryRules') !== null){
        $parameters.jsonCountryRules = window.localStorage.getItem('jsonCountryRules');
    }
    
} catch (e) {
    console.log(e);
}

};
});

define("ShopperPortalEU_DataSync.controller$T", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_DataSync.model", "ShopperPortalEU_DataSync.controller", "ShopperPortalEU_CMS_IS.model", "ShopperPortalEU_CMS_IS.model$TranslationRec", "ShopperPortalEU_DataSync.referencesHealth", "ShopperPortalEU_DataSync.referencesHealth$ShopperPortalEU_CMS_IS", "ShopperPortalEU_DataSync.controller$GetLanguageT", "ShopperPortalEU_DataSync.controller$GetKeyByLabel", "ShopperPortalEU_CMS_IS.model$TranslationItemRec", "ShopperPortalEU_DataSync.model$TranslationItemList"], function (exports, OutSystems, ShopperPortalEU_DataSyncModel, ShopperPortalEU_DataSyncController, ShopperPortalEU_CMS_ISModel) {
var OS = OutSystems.Internal;
ShopperPortalEU_DataSyncController.default.t$Action = function (labelIn, languageCodeIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_DataSync.T$vars"))());
vars.value.labelInLocal = labelIn;
vars.value.languageCodeInLocal = languageCodeIn;
var getLanguageTVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_DataSync.T$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.getLanguageTVar = getLanguageTVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("BzPXzb2R8k2PLMHT7WmUdg:7tL+Fs7s20+__1l2aGIyjA:/ClientActionFlows.7tL+Fs7s20+__1l2aGIyjA:nvb4YftK4i2CCYBZFCCGaA", "ShopperPortalEU_DataSync", "T", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:Bl8OIM5pyE2p_tQsaydWuQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:BNHqiLeXk0GJpwyJWLx6ZQ", callContext.id);
// Execute Action: GetLanguageT
getLanguageTVar.value = ShopperPortalEU_DataSyncController.default.getLanguageT$Action(vars.value.languageCodeInLocal, callContext);

// Foreach GetLanguageT.Translation.Translations
callContext.iterationContext.registerIterationStart(getLanguageTVar.value.translationOut.translationsAttr);
try {var translationsIterator = callContext.iterationContext.getIterator(getLanguageTVar.value.translationOut.translationsAttr);
var translationsIndex = 0;
while ((OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:7QvyrsWzfUiH0q+gJdidPg", callContext.id) && (translationsIndex < getLanguageTVar.value.translationOut.translationsAttr.length))) {
translationsIterator.currentRowNumber = translationsIndex;
// Key found ?
if((OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:8l+YPLtsUEO7TfnBRZLU0A", callContext.id) && (OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEU_DataSyncController.default.getKeyByLabel$Action(vars.value.labelInLocal, callContext).keyOut;
}, OS.DataTypes.DataTypes.Text, callContext.id) === getLanguageTVar.value.translationOut.translationsAttr.getItem(translationsIndex.valueOf()).keyAttr))) {
OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:JUeviJPkrkG6Lk5jlu5y5g", callContext.id);
// Text = GetLanguageT.Translation.Translations.Current.Value
outVars.value.textOut = getLanguageTVar.value.translationOut.translationsAttr.getItem(translationsIndex.valueOf()).valueAttr;
}

translationsIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(getLanguageTVar.value.translationOut.translationsAttr);
}

OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:emRxG_eWyUSY8i99JHFf0g", callContext.id);
// Text = If
outVars.value.textOut = (((outVars.value.textOut === "")) ? (vars.value.labelInLocal) : (outVars.value.textOut));
OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:dl7VFQ3wl0W7IW1tqjEm7Q", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("BzPXzb2R8k2PLMHT7WmUdg:7tL+Fs7s20+__1l2aGIyjA", callContext.id);
}

};
var controller = ShopperPortalEU_DataSyncController.default;
ShopperPortalEU_DataSyncController.default.constructor.registerVariableGroupType("ShopperPortalEU_DataSync.T$vars", [{
name: "Label",
attrName: "labelInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}, {
name: "LanguageCode",
attrName: "languageCodeInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEU_DataSyncController.default.constructor.registerVariableGroupType("ShopperPortalEU_DataSync.T$outVars", [{
name: "Text",
attrName: "textOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEU_DataSyncController.default.clientActionProxies.t$Action = function (labelIn, languageCodeIn) {
labelIn = (labelIn === undefined) ? "" : labelIn;
languageCodeIn = (languageCodeIn === undefined) ? "" : languageCodeIn;
return controller.executeActionInsideJSNode(ShopperPortalEU_DataSyncController.default.t$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(labelIn, OS.DataTypes.DataTypes.Text), OS.DataConversion.JSNodeParamConverter.from(languageCodeIn, OS.DataTypes.DataTypes.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Text: OS.DataConversion.JSNodeParamConverter.to(actionResults.textOut, OS.DataTypes.DataTypes.Text)
};
});
};
});

define("ShopperPortalEU_DataSync.controller$TCMS", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_DataSync.model", "ShopperPortalEU_DataSync.controller", "ShopperPortalEU_CMS_IS.model", "ShopperPortalEU_CMS_IS.model$CountryRuleTranslationRec", "ShopperPortalEU_DataSync.referencesHealth", "ShopperPortalEU_DataSync.referencesHealth$ShopperPortalEU_CMS_IS", "ShopperPortalEU_DataSync.controller$GetCMSBackofficeTranslations", "ShopperPortalEU_CMS_IS.model$CountryRuleTranslationItemRec", "ShopperPortalEU_DataSync.model$CountryRuleTranslationItemList"], function (exports, OutSystems, ShopperPortalEU_DataSyncModel, ShopperPortalEU_DataSyncController, ShopperPortalEU_CMS_ISModel) {
var OS = OutSystems.Internal;
ShopperPortalEU_DataSyncController.default.tCMS$Action = function (key_In, countryCodeIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_DataSync.TCMS$vars"))());
vars.value.key_InLocal = key_In;
vars.value.countryCodeInLocal = countryCodeIn;
var getCMSBackofficeTranslationsVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_DataSync.TCMS$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.getCMSBackofficeTranslationsVar = getCMSBackofficeTranslationsVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("BzPXzb2R8k2PLMHT7WmUdg:CavPH3HIa02GiC4FuqTwfA:/ClientActionFlows.CavPH3HIa02GiC4FuqTwfA:hq1WGvDuDpIOa4uc5k4gNg", "ShopperPortalEU_DataSync", "TCMS", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:LnxAA4nngUeXVj9fDispEw", callContext.id);
OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:5qOZyh1De0OrixJCwlOiyA", callContext.id);
// Execute Action: GetCMSBackofficeTranslations
getCMSBackofficeTranslationsVar.value = ShopperPortalEU_DataSyncController.default.getCMSBackofficeTranslations$Action(vars.value.countryCodeInLocal, callContext);

// Foreach GetCMSBackofficeTranslations.Translation.Translations
callContext.iterationContext.registerIterationStart(getCMSBackofficeTranslationsVar.value.translationOut.translationsAttr);
try {var translationsIterator = callContext.iterationContext.getIterator(getCMSBackofficeTranslationsVar.value.translationOut.translationsAttr);
var translationsIndex = 0;
while ((OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:fSwnY3OB6UaVJTyoKTzHEQ", callContext.id) && (translationsIndex < getCMSBackofficeTranslationsVar.value.translationOut.translationsAttr.length))) {
translationsIterator.currentRowNumber = translationsIndex;
// Rule found ?
if((OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:RW7y9PjFV0ORXPyJMj4q7Q", callContext.id) && (vars.value.key_InLocal === getCMSBackofficeTranslationsVar.value.translationOut.translationsAttr.getItem(translationsIndex.valueOf()).keyAttr))) {
OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:_TvtfHEB30a2kbsqpZzl6Q", callContext.id);
// Text = GetCMSBackofficeTranslations.Translation.Translations.Current.Value
outVars.value.textOut = getCMSBackofficeTranslationsVar.value.translationOut.translationsAttr.getItem(translationsIndex.valueOf()).valueAttr;
}

translationsIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(getCMSBackofficeTranslationsVar.value.translationOut.translationsAttr);
}

OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:UoLpS6GYakCx0QrtkQEIQw", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("BzPXzb2R8k2PLMHT7WmUdg:CavPH3HIa02GiC4FuqTwfA", callContext.id);
}

};
var controller = ShopperPortalEU_DataSyncController.default;
ShopperPortalEU_DataSyncController.default.constructor.registerVariableGroupType("ShopperPortalEU_DataSync.TCMS$vars", [{
name: "Key_",
attrName: "key_InLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}, {
name: "CountryCode",
attrName: "countryCodeInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEU_DataSyncController.default.constructor.registerVariableGroupType("ShopperPortalEU_DataSync.TCMS$outVars", [{
name: "Text",
attrName: "textOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEU_DataSyncController.default.clientActionProxies.tCMS$Action = function (key_In, countryCodeIn) {
key_In = (key_In === undefined) ? "" : key_In;
countryCodeIn = (countryCodeIn === undefined) ? "" : countryCodeIn;
return controller.executeActionInsideJSNode(ShopperPortalEU_DataSyncController.default.tCMS$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(key_In, OS.DataTypes.DataTypes.Text), OS.DataConversion.JSNodeParamConverter.from(countryCodeIn, OS.DataTypes.DataTypes.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Text: OS.DataConversion.JSNodeParamConverter.to(actionResults.textOut, OS.DataTypes.DataTypes.Text)
};
});
};
});

define("ShopperPortalEU_DataSync.controller$ServerAction.GetCMSCountryRules", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_DataSync.model", "ShopperPortalEU_DataSync.controller", "ShopperPortalEU_CMS_IS.model", "ShopperPortalEU_CMS_IS.model$CountryRuleTranslationRec", "ShopperPortalEU_DataSync.referencesHealth", "ShopperPortalEU_DataSync.referencesHealth$ShopperPortalEU_CMS_IS", "ShopperPortalEU_DataSync.model$CountryRuleTranslationList"], function (exports, OutSystems, ShopperPortalEU_DataSyncModel, ShopperPortalEU_DataSyncController, ShopperPortalEU_CMS_ISModel) {
var OS = OutSystems.Internal;
ShopperPortalEU_DataSyncController.default.getCMSCountryRules$ServerAction = function (callContext) {
var controller = this.controller;
return controller.callServerAction("GetCMSCountryRules", "screenservices/ShopperPortalEU_DataSync/ActionGetCMSCountryRules", "0u5S5ZdkWpEtLplgK+mSvQ", {}, controller.callContext(callContext), OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, false).then(function (outputs) {
var executeServerActionResult = new (controller.constructor.getVariableGroupType("ShopperPortalEU_DataSync$ActionGetCMSCountryRules"))();
executeServerActionResult.countryRulesOut = OS.DataConversion.ServerDataConverter.from(outputs.CountryRules, ShopperPortalEU_DataSyncModel.CountryRuleTranslationList);
return executeServerActionResult;
});
};
ShopperPortalEU_DataSyncController.default.constructor.registerVariableGroupType("ShopperPortalEU_DataSync$ActionGetCMSCountryRules", [{
name: "CountryRules",
attrName: "countryRulesOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.RecordList,
defaultValue: function () {
return new ShopperPortalEU_DataSyncModel.CountryRuleTranslationList();
},
complexType: ShopperPortalEU_DataSyncModel.CountryRuleTranslationList
}]);
});
define("ShopperPortalEU_DataSync.controller", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_DataSync.model", "ShopperPortalEU_DataSync.controller$debugger"], function (exports, OutSystems, ShopperPortalEU_DataSyncModel, ShopperPortalEU_DataSync_Controller_debugger) {
var OS = OutSystems.Internal;
var ShopperPortalEU_DataSyncController = exports;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
}
Controller.prototype.clientActionProxies = {};
Controller.prototype.roles = {};
Controller.prototype.defaultTimeout = 10;
Controller.prototype.getDefaultTimeout = function () {
return ShopperPortalEU_DataSyncController.default.defaultTimeout;
};
Controller.prototype.getClientActionProxies = function (controller) {
var _this = this;
var thisController = controller;
return Object.keys(this.clientActionProxies).reduce(function (acc, actionName) {
acc[actionName] = function () {
if(thisController.isActive()) {
return _this.clientActionProxies[actionName].apply(thisController, arguments);
}

return Promise.resolve();
};
return acc;
}, {});
};
return Controller;
})(OS.Controller.BaseModuleController);
ShopperPortalEU_DataSyncController.default = new Controller(null, "ShopperPortalEU_DataSync");
});
define("ShopperPortalEU_DataSync.controller$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"vdVE5L24XEun6W29_3ZGgg": {
getter: function (varBag, idService) {
return varBag.getCMSCountryRulesVar.value;
}
},
"Ktf4iyABpkWg0LEQIjj8Og": {
getter: function (varBag, idService) {
return varBag.getJSONCountryRulesJSResult.value;
}
},
"b9QG_GUcbkGaqFdP5YPIOg": {
getter: function (varBag, idService) {
return varBag.vars.value.labelInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"C45y+DYCq0mga6Meo3hFMA": {
getter: function (varBag, idService) {
return varBag.vars.value.languageCodeInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"Sud6ZblCwUGlQ0dotv88og": {
getter: function (varBag, idService) {
return varBag.outVars.value.textOut;
},
dataType: OS.DataTypes.DataTypes.Text
},
"BNHqiLeXk0GJpwyJWLx6ZQ": {
getter: function (varBag, idService) {
return varBag.getLanguageTVar.value;
}
},
"C3ndSBCu4UGyI4rbE67J6w": {
getter: function (varBag, idService) {
return varBag.vars.value.labelInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"UCvhyuxD_ku0KW6G4qo2fQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.keyOut;
},
dataType: OS.DataTypes.DataTypes.Text
},
"+0Yhh3Glrk+TyO5MVYFxfQ": {
getter: function (varBag, idService) {
return varBag.getEnglishTranslationsVar.value;
}
},
"HhjY+KeJxEyRgAsQpstsAA": {
getter: function (varBag, idService) {
return varBag.vars.value.key_InLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"mTta4sAEmUie_BiGd2EDjA": {
getter: function (varBag, idService) {
return varBag.vars.value.countryCodeInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"HHDQC7kCJUisuV58HMJBMA": {
getter: function (varBag, idService) {
return varBag.outVars.value.textOut;
},
dataType: OS.DataTypes.DataTypes.Text
},
"5qOZyh1De0OrixJCwlOiyA": {
getter: function (varBag, idService) {
return varBag.getCMSBackofficeTranslationsVar.value;
}
},
"aFs2XWTgbk2RHG+RSNxlZQ": {
getter: function (varBag, idService) {
return varBag.vars.value.countryCodeInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"jwzPmQ1bSUaqyJUWyIkCJg": {
getter: function (varBag, idService) {
return varBag.outVars.value.translationOut;
}
},
"lWtdFOmwtUGQhNliKquwpA": {
getter: function (varBag, idService) {
return varBag.jSONDeserializeCountryRulesVar.value;
}
},
"FlZl73ej+UCGyi7Bvj4G3g": {
getter: function (varBag, idService) {
return varBag.getJSONCountryRulesJSResult.value;
}
},
"8oWz5Dm4J0SBrRn3cWtKhQ": {
getter: function (varBag, idService) {
return varBag.vars.value.translationsInLocal;
}
},
"YoI1t_1m5ESCrprqz9vlfA": {
getter: function (varBag, idService) {
return varBag.jSONSerializeTranslationsVar.value;
}
},
"6N+8j5Ax_EyG16YDrZywAg": {
getter: function (varBag, idService) {
return varBag.saveCountryRulesJSResult.value;
}
},
"o66zP9sBuEqJoBNJjSD9PQ": {
getter: function (varBag, idService) {
return varBag.vars.value.languageCodeInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"6saPn7gKd0STBOEjfA6ycg": {
getter: function (varBag, idService) {
return varBag.outVars.value.translationOut;
}
},
"eLZfGRjjvUCt23cqmtrM5Q": {
getter: function (varBag, idService) {
return varBag.jSONDeserializeTranslationVar.value;
}
},
"EJW50VvPuUqKyNHFQrd5Uw": {
getter: function (varBag, idService) {
return varBag.getJsonTJSResult.value;
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
