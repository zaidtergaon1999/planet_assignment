define("ShopperPortalEU.Refund.MyRefunds.mvc$model", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.controller", "ShopperPortalEU_Forms_IS.controller", "ShopperPortalEU_UI_Theme.controller", "ShopperPortalEU.Layouts.Layout.mvc$model", "ShopperPortalEU.LayoutsComponents.Menu.mvc$model", "ShopperPortalEU.LayoutsComponents.ApplicationHeader.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CardBackground.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.Flex.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomButton.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomButtonItem.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.FullHeightContent.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomLink.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomLinkItem.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCard.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.ProgressBar.mvc$model", "ShopperPortalEU.Common.DataLoading.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CircleIcon.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomList.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomTag.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.FlexItem.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomAlert.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomPopup.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomPopupLayout.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.BulletsList.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.BulletsListItem.mvc$model", "ShopperPortalEU_Forms_IS.model$FormInfo_WrapperRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Forms_IS", "ShopperPortalEU.model$FormInfo_WrapperList", "ShopperPortalEU.model$BooleanBooleanRecord", "ShopperPortalEU_UI_Theme.model$LayoutOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$LayoutHeaderOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU.model$ApplicationHeaderRec", "ShopperPortalEU_UI_Components.model$CustomCarouselOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$CardBackgroundOptionsRec", "ShopperPortalEU_UI_Components.model$FlexOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconRec", "ShopperPortalEU_UI_Components.model$FullHeightContentOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentTopOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentBottomOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsIconRec", "ShopperPortalEU_UI_Components.model$CustomCardOptionsRec", "ShopperPortalEU_UI_Components.model$ProgressBarOptionsRec", "ShopperPortalEU_UI_Components.model$CircleIconOptionsRec", "ShopperPortalEU_UI_Components.model$CircleIconIconOptionsRec", "ShopperPortalEU_UI_Components.model$CustomListOptionsRec", "ShopperPortalEU_UI_Components.model$CustomTagOptionsRec", "ShopperPortalEU_UI_Components.model$FlexItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomAlertOptionsRec", "ShopperPortalEU_UI_Components.model$CustomAlertIconOptionsRec", "ShopperPortalEU_UI_Components.model$CustomPopupLayoutOptionsRec", "ShopperPortalEU_UI_Components.model$CustomPopupLayoutHeaderImageOptionsRec", "ShopperPortalEU.controller$ClarityEvent", "ShopperPortalEU.controller$GroupFormsByDate", "ShopperPortalEU_Forms_IS.controller$GetFormList", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", "ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger", "ShopperPortalEU.controller$DefaultErrorMessage", "ShopperPortalEU.controller$HeapIdentify", "ShopperPortalEU.controller$InitAppcues", "ShopperPortalEU.model$ApcuesIdentifyRec", "ShopperPortalEU.controller$ApcuesIdentify"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEU_Forms_ISModel, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUController, ShopperPortalEU_Forms_ISController, ShopperPortalEU_UI_ThemeController, ShopperPortalEU_Layouts_Layout_mvcModel, ShopperPortalEU_LayoutsComponents_Menu_mvcModel, ShopperPortalEU_LayoutsComponents_ApplicationHeader_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCarousel_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CardBackground_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLink_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLinkItem_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCard_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_ProgressBar_mvcModel, ShopperPortalEU_Common_DataLoading_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CircleIcon_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomList_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomTag_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FlexItem_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomAlert_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomPopup_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomPopupLayout_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_BulletsList_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_BulletsListItem_mvcModel) {
var OS = OutSystems.Internal;

var GetApplicationReadyDataDataActRec = (function (_super) {
__extends(GetApplicationReadyDataDataActRec, _super);
function GetApplicationReadyDataDataActRec(defaults) {
_super.apply(this, arguments);
}
GetApplicationReadyDataDataActRec.attributesToDeclare = function () {
return [
this.attr("IsHeapActive", "isHeapActiveOut", "IsHeapActive", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
GetApplicationReadyDataDataActRec.fromStructure = function (str) {
return new GetApplicationReadyDataDataActRec(new GetApplicationReadyDataDataActRec.RecordClass({
isHeapActiveOut: OS.DataTypes.ImmutableBase.getData(str)
}));
};
GetApplicationReadyDataDataActRec.init();
return GetApplicationReadyDataDataActRec;
})(OS.Model.DataSourceRecord);

var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("CantFind_ShowPopup", "cantFind_ShowPopupVar", "CantFind_ShowPopup", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("FormsList_Active", "formsList_ActiveVar", "FormsList_Active", true, false, OS.DataTypes.DataTypes.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEUModel.FormInfo_WrapperList());
}, false, ShopperPortalEUModel.FormInfo_WrapperList), 
this.attr("IsScreenReady", "isScreenReadyVar", "IsScreenReady", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("HasTestUIAvailable", "hasTestUIAvailableVar", "HasTestUIAvailable", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("NrReadyForRefundForms", "nrReadyForRefundFormsVar", "NrReadyForRefundForms", true, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, false), 
this.attr("Carousel", "carouselVar", "Carousel", true, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEUModel.BooleanBooleanRecord());
}, false, ShopperPortalEUModel.BooleanBooleanRecord), 
this.attr("HasClosedRefunds", "hasClosedRefundsVar", "HasClosedRefunds", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("GetApplicationReadyData", "getApplicationReadyDataDataAct", "getApplicationReadyDataDataAct", true, true, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new GetApplicationReadyDataDataActRec());
}, true, GetApplicationReadyDataDataActRec)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Model._hasValidationWidgetsValue = undefined;
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
if((Model._hasValidationWidgetsValue === undefined)) {
Model._hasValidationWidgetsValue = ((((((((((((((((((((((ShopperPortalEU_Layouts_Layout_mvcModel.hasValidationWidgets || ShopperPortalEU_LayoutsComponents_Menu_mvcModel.hasValidationWidgets) || ShopperPortalEU_LayoutsComponents_ApplicationHeader_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCarousel_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CardBackground_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLink_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLinkItem_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCard_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_ProgressBar_mvcModel.hasValidationWidgets) || ShopperPortalEU_Common_DataLoading_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CircleIcon_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomList_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomTag_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FlexItem_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomAlert_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomPopup_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomPopupLayout_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_BulletsList_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_BulletsListItem_mvcModel.hasValidationWidgets);
}

return Model._hasValidationWidgetsValue;
}
});

Model.prototype.setInputs = function (inputs) {
};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "Refund.MyRefunds");
});
define("ShopperPortalEU.Refund.MyRefunds.mvc$view", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_Forms_IS.controller", "ShopperPortalEU_UI_Theme.controller", "react", "OutSystems/ReactView/Main", "ShopperPortalEU.Refund.MyRefunds.mvc$model", "ShopperPortalEU.Refund.MyRefunds.mvc$controller", "ShopperPortalEU.clientVariables", "ShopperPortalEU.Layouts.Layout.mvc$view", "OutSystems/ReactWidgets/Main", "ShopperPortalEU.LayoutsComponents.Menu.mvc$view", "ShopperPortalEU.LayoutsComponents.ApplicationHeader.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CardBackground.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.Flex.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomButton.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomButtonItem.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.FullHeightContent.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomLink.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomLinkItem.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCard.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.ProgressBar.mvc$view", "ShopperPortalEU.Common.DataLoading.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CircleIcon.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomList.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomTag.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.FlexItem.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomAlert.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomPopup.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomPopupLayout.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.BulletsList.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.BulletsListItem.mvc$view", "ShopperPortalEU_Forms_IS.model$FormInfo_WrapperRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Forms_IS", "ShopperPortalEU.model$FormInfo_WrapperList", "ShopperPortalEU.model$BooleanBooleanRecord", "ShopperPortalEU_UI_Theme.model$LayoutOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$LayoutHeaderOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU.model$ApplicationHeaderRec", "ShopperPortalEU_UI_Components.model$CustomCarouselOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$CardBackgroundOptionsRec", "ShopperPortalEU_UI_Components.model$FlexOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconRec", "ShopperPortalEU_UI_Components.model$FullHeightContentOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentTopOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentBottomOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsIconRec", "ShopperPortalEU_UI_Components.model$CustomCardOptionsRec", "ShopperPortalEU_UI_Components.model$ProgressBarOptionsRec", "ShopperPortalEU_UI_Components.model$CircleIconOptionsRec", "ShopperPortalEU_UI_Components.model$CircleIconIconOptionsRec", "ShopperPortalEU_UI_Components.model$CustomListOptionsRec", "ShopperPortalEU_UI_Components.model$CustomTagOptionsRec", "ShopperPortalEU_UI_Components.model$FlexItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomAlertOptionsRec", "ShopperPortalEU_UI_Components.model$CustomAlertIconOptionsRec", "ShopperPortalEU_UI_Components.model$CustomPopupLayoutOptionsRec", "ShopperPortalEU_UI_Components.model$CustomPopupLayoutHeaderImageOptionsRec", "ShopperPortalEU.controller$ClarityEvent", "ShopperPortalEU.controller$GroupFormsByDate", "ShopperPortalEU_Forms_IS.controller$GetFormList", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", "ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger", "ShopperPortalEU.controller$DefaultErrorMessage", "ShopperPortalEU.controller$HeapIdentify", "ShopperPortalEU.controller$InitAppcues", "ShopperPortalEU.model$ApcuesIdentifyRec", "ShopperPortalEU.controller$ApcuesIdentify"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_Forms_ISModel, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_Forms_ISController, ShopperPortalEU_UI_ThemeController, React, OSView, ShopperPortalEU_Refund_MyRefunds_mvc_model, ShopperPortalEU_Refund_MyRefunds_mvc_controller, ShopperPortalEUClientVariables, ShopperPortalEU_Layouts_Layout_mvc_view, OSWidgets, ShopperPortalEU_LayoutsComponents_Menu_mvc_view, ShopperPortalEU_LayoutsComponents_ApplicationHeader_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCarousel_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CardBackground_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLink_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLinkItem_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCard_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_ProgressBar_mvc_view, ShopperPortalEU_Common_DataLoading_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CircleIcon_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomList_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomTag_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FlexItem_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomAlert_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomPopup_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomPopupLayout_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_BulletsList_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_BulletsListItem_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            var thisIsInstanceOfSuper = this instanceof _super;
            if (thisIsInstanceOfSuper == false) {
                return;
            }

            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "Refund.MyRefunds";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css", "css/ShopperPortalEU_UI_Theme.ShopperPortalEUUITheme.css", "css/ShopperPortalEU.ShopperPortalEU.css", "css/ShopperPortalEU_UI_Theme.ShopperPortalEUUITheme.extra.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [ShopperPortalEU_Layouts_Layout_mvc_view, ShopperPortalEU_LayoutsComponents_Menu_mvc_view, ShopperPortalEU_LayoutsComponents_ApplicationHeader_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCarousel_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CardBackground_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLink_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLinkItem_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCard_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_ProgressBar_mvc_view, ShopperPortalEU_Common_DataLoading_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CircleIcon_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomList_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomTag_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FlexItem_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomAlert_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomPopup_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomPopupLayout_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_BulletsList_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_BulletsListItem_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return ShopperPortalEU_Refund_MyRefunds_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return ShopperPortalEU_Refund_MyRefunds_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "Shopper Portal EU - My refunds";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(ShopperPortalEU_Layouts_Layout_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
afterAuthentication$Action: function (isAuthenticatedIn) {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Layouts/Layout AfterAuthentication");
return controller.layoutAfterAuthentication$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "0",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
headerLeft: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_LayoutsComponents_Menu_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "1",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}),
headerCenter: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_LayoutsComponents_ApplicationHeader_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("KCPOXuUpTkKPRMI+S1ly2g.Options"), function () {
return function () {
var rec = new ShopperPortalEUModel.ApplicationHeaderRec();
rec.scrollTitleAttr = "My refunds";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "2",
alias: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}),
headerRight: PlaceholderContent.Empty,
headerBottom: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "heading6 text-align-center",
visible: true,
_idProps: {
service: idService,
uuid: "3"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "PersonalGreeting"
},
value: model.getCachedValue(idService.getId("mUrAXWAPIk21VZPFsX7u3Q.Value"), function () {
return ("Hello " + ((((ShopperPortalEUClientVariables.getShopperName()) !== (""))) ? (((((OS.BuiltinFunctions.index(ShopperPortalEUClientVariables.getShopperName(), " ", 0, false, false)) !== (-1))) ? ((((OS.BuiltinFunctions.length(OS.BuiltinFunctions.substr(ShopperPortalEUClientVariables.getShopperName(), 0, OS.BuiltinFunctions.index(ShopperPortalEUClientVariables.getShopperName(), " ", 0, false, false))) > 20)) ? ("") : (OS.BuiltinFunctions.substr(ShopperPortalEUClientVariables.getShopperName(), 0, OS.BuiltinFunctions.index(ShopperPortalEUClientVariables.getShopperName(), " ", 0, false, false))))) : ((((OS.BuiltinFunctions.length(ShopperPortalEUClientVariables.getShopperName()) > 20)) ? ("") : (ShopperPortalEUClientVariables.getShopperName()))))) : ("")));
}, function () {
return ShopperPortalEUClientVariables.getShopperName();
}),
_idProps: {
service: idService,
uuid: "4"
},
_widgetRecordProvider: widgetsRecordProvider
})), $if((model.variables.isScreenReadyVar && (model.variables.carouselVar.addCreditCardAttr || model.variables.carouselVar.showProfileAttr)), false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCarousel_mvc_view, {
inputs: {
ExtendedClass: "margin-top-05",
Options: model.getCachedValue(idService.getId("Bmkp3nhbqk2c+u9Y7BD1sQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomCarouselOptionsRec();
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "5",
alias: "4"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
items: new PlaceholderContent(function () {
return [$if(model.variables.carouselVar.addCreditCardAttr, false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CardBackground_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("l0dcBHDidE2_o4ABEOma5w.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CardBackgroundOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.cardBackgroundType.refund;
rec.testIdAttr = "AddCardCarousselCard";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "6",
alias: "5"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
title: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("8+DhgG7KGUCO775ilh_eMA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.alignAttr = ShopperPortalEUModel.staticEntities.flexAlign.center;
rec.justifyAttr = ShopperPortalEUModel.staticEntities.flexJustify.spaceBetween;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
rec.wrapAttr = false;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "7",
alias: "6"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "AddCArdforRefundLabel"
},
style: "subhead-1 text-primary-black",
value: "Add your card for a quick refund!",
_idProps: {
service: idService,
uuid: "8"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("8gh_361x+kmMarPPKUWP4A.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRec();
rec.testIdAttr = "CloseProfileCardButton";
rec.typeAttr = ShopperPortalEUModel.staticEntities.customButtonType.linkSecondary;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "9",
alias: "7"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
button: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: false,
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Refund/MyRefunds/Button OnClick");
controller.closeAddCardOnClick$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn",
visible: true,
_idProps: {
service: idService,
uuid: "10"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("Bge5Ag28yEiMBiAx3vApYQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonItemOptionsRec();
rec.iconAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsIconRec();
rec.nameAttr = "close";
return rec;
}();
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "11",
alias: "8"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: PlaceholderContent.Empty
},
_dependencies: []
}))];
})
},
_dependencies: []
})];
})
},
_dependencies: []
})];
}),
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("0IEclto1u0ScJikRjItdcA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FullHeightContentOptionsRec();
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space4;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "12",
alias: "9"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
top: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "AddCardLabel"
},
style: "body-3",
value: "Speed up your refund. Add your card to get your money.",
_idProps: {
service: idService,
uuid: "13"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
bottom: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLink_mvc_view, {
inputs: {
ExtendedClass: "body-3",
Options: model.getCachedValue(idService.getId("aqQ9lmabsUWO1tsPrBKAuA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomLinkOptionsRec();
rec.testIdAttr = "CarousselAddCardLink";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "14",
alias: "10"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
link: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Link, {
enabled: true,
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Refund/MyRefunds/Link OnClick");
controller.addCard$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
visible: true,
_idProps: {
service: idService,
uuid: "15"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLinkItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "16",
alias: "11"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Add card",
_idProps: {
service: idService,
uuid: "17"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
})];
})
},
_dependencies: []
})];
})
},
_dependencies: []
})];
}, function () {
return [];
}), $if(model.variables.carouselVar.showProfileAttr, false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCard_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("pEx0RnQlH0mBIKnXManJ6w.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomCardOptionsRec();
rec.testIdAttr = "ProfileCarousselCard";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "18",
alias: "12"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("3KZmndvm70idPpW+70B9KQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FullHeightContentOptionsRec();
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space4;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "19",
alias: "13"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
top: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("BEh3qCGWeEqWxV0EQ0EnOw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.alignAttr = ShopperPortalEUModel.staticEntities.flexAlign.center;
rec.justifyAttr = ShopperPortalEUModel.staticEntities.flexJustify.spaceBetween;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
rec.wrapAttr = false;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "20",
alias: "14"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "PercentageProfileComplete"
},
style: "subhead-1",
value: (("Profile " + OS.BuiltinFunctions.decimalToText(ShopperPortalEUClientVariables.getShopperProfileCompleted())) + "% complete"),
_idProps: {
service: idService,
uuid: "21"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("ClpM6EdxCUCcQaOEx2BjQA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRec();
rec.testIdAttr = "CloseProfileCardButton";
rec.typeAttr = ShopperPortalEUModel.staticEntities.customButtonType.linkSecondary;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "22",
alias: "15"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
button: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: false,
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Refund/MyRefunds/Button OnClick");
controller.closeProfileOnClick$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn",
visible: true,
_idProps: {
service: idService,
uuid: "23"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("RR0upSIU+0WD36yUq5RpfA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonItemOptionsRec();
rec.iconAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsIconRec();
rec.nameAttr = "close";
return rec;
}();
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "24",
alias: "16"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: PlaceholderContent.Empty
},
_dependencies: []
}))];
})
},
_dependencies: []
})];
})
},
_dependencies: [asPrimitiveValue(ShopperPortalEUClientVariables.getShopperProfileCompleted())]
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-top-02",
visible: true,
_idProps: {
service: idService,
uuid: "25"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "ProfileCardLabel"
},
value: "Complete your profile and save time in your tax-free shopping experience.",
_idProps: {
service: idService,
uuid: "26"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_ProgressBar_mvc_view, {
inputs: {
ExtendedClass: "margin-top-04",
Options: model.getCachedValue(idService.getId("SKHmxpxNhkuNq0tsyHK+DQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.ProgressBarOptionsRec();
rec.testIdAttr = "ProfileProgressBar";
rec.progressAttr = ShopperPortalEUClientVariables.getShopperProfileCompleted();
rec.stepsAttr = 4;
return rec;
}();
}, function () {
return ShopperPortalEUClientVariables.getShopperProfileCompleted();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "27",
alias: "17"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}),
bottom: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("UhM4YKNFQkKem0W6jd8VeQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRec();
rec.testIdAttr = "CompleteYourProfileButton";
rec.typeAttr = ShopperPortalEUModel.staticEntities.customButtonType.linkPrimary;
return rec;
}();
}),
ExtendedClass: "body-3"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "28",
alias: "18"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
button: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: false,
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Refund/MyRefunds/Button OnClick");
controller.completeProfile$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn",
visible: true,
_idProps: {
service: idService,
uuid: "29"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "30",
alias: "19"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Complete your profile",
_idProps: {
service: idService,
uuid: "31"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
})];
})
},
_dependencies: [asPrimitiveValue(ShopperPortalEUClientVariables.getShopperProfileCompleted())]
})];
})
},
_dependencies: [asPrimitiveValue(ShopperPortalEUClientVariables.getShopperProfileCompleted())]
})];
}, function () {
return [];
})];
})
},
_dependencies: [asPrimitiveValue(ShopperPortalEUClientVariables.getShopperProfileCompleted()), asPrimitiveValue(model.variables.carouselVar.showProfileAttr), asPrimitiveValue(model.variables.carouselVar.addCreditCardAttr)]
})];
}, function () {
return [];
})];
}),
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_Common_DataLoading_mvc_view, {
inputs: {
IsDataFetched: model.variables.isScreenReadyVar
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "32",
alias: "20"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("JfTYTugyiECzv7_ApThNkg.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FullHeightContentOptionsRec();
rec.topAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FullHeightContentTopOptionsRec();
rec.verticalAlignmentAttr = (((model.variables.formsList_ActiveVar.isEmpty && !(model.variables.hasClosedRefundsVar))) ? (ShopperPortalEUModel.staticEntities.fullHeightContentAlignment.center) : (OS.BuiltinFunctions.nullTextIdentifier()));
rec.horizontalAlignmentAttr = (((model.variables.formsList_ActiveVar.isEmpty && !(model.variables.hasClosedRefundsVar))) ? (ShopperPortalEUModel.staticEntities.fullHeightContentAlignment.center) : (OS.BuiltinFunctions.nullTextIdentifier()));
return rec;
}();
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space7;
return rec;
}();
}, function () {
return model.variables.formsList_ActiveVar.isEmpty;
}, function () {
return model.variables.hasClosedRefundsVar;
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "33",
alias: "21"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
top: new PlaceholderContent(function () {
return [$if((model.variables.formsList_ActiveVar.isEmpty && !(model.variables.hasClosedRefundsVar)), false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "text-align-center",
visible: true,
_idProps: {
service: idService,
uuid: "34"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CircleIcon_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("KIV2mft4EECAJ19r1r_zfw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CircleIconOptionsRec();
rec.iconAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CircleIconIconOptionsRec();
rec.nameAttr = "cash_pictogram";
rec.familyAttr = ShopperPortalEUModel.staticEntities.customIconFamily.planet;
return rec;
}();
rec.sizeAttr = ShopperPortalEUModel.staticEntities.circleIconSize.medium;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "35",
alias: "22"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-top-04",
visible: true,
_idProps: {
service: idService,
uuid: "36"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
style: "heading6 text-primary-black",
value: "No refunds yet",
_idProps: {
service: idService,
uuid: "37"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-top-03",
visible: true,
_idProps: {
service: idService,
uuid: "38"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLink_mvc_view, {
inputs: {
ExtendedClass: "body-3"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "39",
alias: "23"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
link: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Link, {
enabled: true,
extendedProperties: {
target: "_blank"
},
transition: OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.None),
url: OS.Navigation.generateScreenURL("https://www.planetpayment.com", {}),
visible: true,
_idProps: {
service: idService,
uuid: "40"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLinkItem_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("Se51uBetP0+a_o8MmyWW+g.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomLinkItemOptionsRec();
rec.iconAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomLinkOptionsIconRec();
rec.nameAttr = "open_in_new";
rec.alignmentAttr = ShopperPortalEUModel.staticEntities.customLinkIconAlignment.right;
return rec;
}();
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "41",
alias: "24"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Learn more about Tax Free",
_idProps: {
service: idService,
uuid: "42"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
})))];
}, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("OgyAHU0srEeuOCO4ixDYcg.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.alignAttr = ShopperPortalEUModel.staticEntities.flexAlign.center;
rec.justifyAttr = ShopperPortalEUModel.staticEntities.flexJustify.spaceBetween;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "43",
alias: "25"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": ("MyRefunds_Title_" + (model.variables.formsList_ActiveVar.length).toString())
},
style: "heading6 text-primary-black",
value: "My refunds",
_idProps: {
service: idService,
uuid: "44"
},
_widgetRecordProvider: widgetsRecordProvider
}), $if(model.variables.hasClosedRefundsVar, false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLink_mvc_view, {
inputs: {
ExtendedClass: "body-3"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "45",
alias: "26"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
link: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Link, {
enabled: true,
transition: OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default),
url: OS.Navigation.generateScreenURL("ShopperPortalEU", "RefundHistory", {}),
visible: true,
_idProps: {
service: idService,
uuid: "46"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLinkItem_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("DSWI1X8u7EyFQ+e7QSMd5Q.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomLinkItemOptionsRec();
rec.iconAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomLinkOptionsIconRec();
rec.nameAttr = "chevron_right";
rec.alignmentAttr = ShopperPortalEUModel.staticEntities.customLinkIconAlignment.right;
return rec;
}();
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "47",
alias: "27"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "View refund history",
_idProps: {
service: idService,
uuid: "48"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
})];
}, function () {
return [];
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.hasClosedRefundsVar), asPrimitiveValue(model.variables.formsList_ActiveVar.length)]
}), $if((model.variables.nrReadyForRefundFormsVar > 0), false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCard_mvc_view, {
inputs: {
ExtendedClass: "text-align-center margin-top-05",
Options: model.getCachedValue(idService.getId("6+s1b8bThEm+xb50oSN5IQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomCardOptionsRec();
rec.stateAttr = ShopperPortalEUModel.staticEntities.customCardState.warning;
rec.isSharperAttr = true;
rec.hasShadowAttr = true;
rec.testIdAttr = "RequestRefundCard";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "49",
alias: "28"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "text-primary-35",
visible: true,
_idProps: {
service: idService,
uuid: "50"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "FormsReadyForRefund_Msg"
},
value: (("You have " + (model.variables.nrReadyForRefundFormsVar).toString()) + " Tax Free form(s) ready for refund."),
_idProps: {
service: idService,
uuid: "51"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-top-04",
visible: true,
_idProps: {
service: idService,
name: "RequestRefundBtn"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, {
inputs: {
ExtendedClass: "text-align-center",
Options: model.getCachedValue(idService.getId("_krYFgVDI06PHhZCgZ_qRg.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRec();
rec.testIdAttr = "RequestRefundButton";
rec.typeAttr = ShopperPortalEUModel.staticEntities.customButtonType.primary;
rec.isFullWidthAttr = true;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "53",
alias: "29"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
button: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: false,
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Refund/MyRefunds/Button OnClick");
controller.navigateToRequestRefund$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn",
visible: true,
_idProps: {
service: idService,
uuid: "54"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("rj22nNVcKEuYxdP8W1KGNA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonItemOptionsRec();
rec.iconAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsIconRec();
rec.nameAttr = "redeem";
return rec;
}();
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "55",
alias: "30"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "RequestRefundButtonLabel"
},
value: "Request refund",
_idProps: {
service: idService,
uuid: "56"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables.nrReadyForRefundFormsVar)]
})];
}, function () {
return [];
}), $if(!(model.variables.formsList_ActiveVar.isEmpty), false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomList_mvc_view, {
inputs: {
ExtendedClass: "margin-top-05"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "57",
alias: "31"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
list: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.List, {
animateItems: false,
extendedProperties: {
"disable-virtualization": "True",
"data-testid": "FormList"
},
gridProperties: {
classes: "OSFillParent"
},
mode: /*Default*/ 0,
source: model.variables.formsList_ActiveVar,
style: "list list-group",
tag: "div",
_idProps: {
service: idService,
name: "FormList_Active"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new IteratorPlaceholderContent(function (idService, callContext) {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
name: "RefundCard"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.hasTestUIAvailableVar), asPrimitiveValue(model.variables.formsList_ActiveVar.length), asPrimitiveValue(model.variables.formsList_ActiveVar.getCurrentRowNumber(callContext.iterationContext)), asPrimitiveValue(model.variables.formsList_ActiveVar.getCurrent(callContext.iterationContext).refundAmountMessageAttr), asPrimitiveValue(model.variables.formsList_ActiveVar.getCurrent(callContext.iterationContext).refundAmountTxtAttr), asPrimitiveValue(model.variables.formsList_ActiveVar.getCurrent(callContext.iterationContext).refundLabel_UIAttr), asPrimitiveValue(model.variables.formsList_ActiveVar.getCurrent(callContext.iterationContext).merchantNameAttr), asPrimitiveValue(model.variables.formsList_ActiveVar.getCurrent(callContext.iterationContext).formStatusLabelAttr), asPrimitiveValue(model.variables.formsList_ActiveVar.getCurrent(callContext.iterationContext).formTagStateAttr), asPrimitiveValue(model.variables.formsList_ActiveVar.getCurrent(callContext.iterationContext).formNumberAttr), asPrimitiveValue(model.variables.formsList_ActiveVar.getCurrent(callContext.iterationContext).formDateTxtAttr)]
}, $if(((model.variables.formsList_ActiveVar.getCurrent(callContext.iterationContext).formDateTxtAttr) !== ("")), false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
className: model.getCachedValue(idService.getId("RefundDate_Ctn.class"), function () {
return (((model.variables.formsList_ActiveVar.getCurrentRowNumber(callContext.iterationContext) === 0)) ? ("body-4") : ("body-4 margin-top-05"));
}, function () {
return model.variables.formsList_ActiveVar.getCurrentRowNumber(callContext.iterationContext);
})
},
visible: true,
_idProps: {
service: idService,
name: "RefundDate_Ctn"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": ("RefundDate_" + (model.variables.formsList_ActiveVar.getCurrentRowNumber(callContext.iterationContext)).toString())
},
value: model.variables.formsList_ActiveVar.getCurrent(callContext.iterationContext).formDateTxtAttr,
_idProps: {
service: idService,
uuid: "61"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
}, function () {
return [];
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
"data-testid": ("RefundCard_" + (model.variables.formsList_ActiveVar.getCurrentRowNumber(callContext.iterationContext)).toString())
},
style: model.getCachedValue(idService.getId("RefundCard_Ctn.Style"), function () {
return ("margin-top-02" + ((((model.variables.formsList_ActiveVar.getCurrentRowNumber(callContext.iterationContext)) !== ((model.variables.formsList_ActiveVar.length - 1)))) ? (" margin-bottom-04") : ("")));
}, function () {
return model.variables.formsList_ActiveVar.getCurrentRowNumber(callContext.iterationContext);
}, function () {
return model.variables.formsList_ActiveVar.length;
}),
visible: true,
_idProps: {
service: idService,
name: "RefundCard_Ctn"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLink_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("P0faMT+FOESMBsNM9QdMBQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomLinkOptionsRec();
rec.testIdAttr = ("RefundCardLink_" + (model.variables.formsList_ActiveVar.getCurrentRowNumber(callContext.iterationContext)).toString());
rec.typeAttr = ShopperPortalEUModel.staticEntities.customLinkType.ghost;
return rec;
}();
}, function () {
return model.variables.formsList_ActiveVar.getCurrentRowNumber(callContext.iterationContext);
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "63",
alias: "32"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
link: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Link, {
enabled: true,
transition: OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default),
url: OS.Navigation.generateScreenURL("ShopperPortalEU", "RefundDetails", {
FormNumberIn: OS.DataConversion.ServerDataConverter.asString(model.variables.formsList_ActiveVar.getCurrent(callContext.iterationContext).formNumberAttr, OS.DataTypes.DataTypes.Text)
}),
visible: true,
_idProps: {
service: idService,
uuid: "64"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLinkItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "65",
alias: "33"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCard_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("YW623AVpGk+D6mmX4SKGUA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomCardOptionsRec();
rec.clickableAttr = true;
rec.testIdAttr = ("FormCard_" + (model.variables.formsList_ActiveVar.getCurrentRowNumber(callContext.iterationContext)).toString());
return rec;
}();
}, function () {
return model.variables.formsList_ActiveVar.getCurrentRowNumber(callContext.iterationContext);
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "66",
alias: "34"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [$if(model.variables.hasTestUIAvailableVar, false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-bottom-02",
visible: true,
_idProps: {
service: idService,
uuid: "67"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": ("FormNumber_" + (model.variables.formsList_ActiveVar.getCurrentRowNumber(callContext.iterationContext)).toString())
},
style: "body-4",
value: model.variables.formsList_ActiveVar.getCurrent(callContext.iterationContext).formNumberAttr,
_idProps: {
service: idService,
uuid: "68"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
}, function () {
return [];
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "69",
alias: "35"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomTag_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("b_oqiW5OJUaiomyTkWm0hA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomTagOptionsRec();
rec.stateAttr = model.variables.formsList_ActiveVar.getCurrent(callContext.iterationContext).formTagStateAttr;
rec.testIdAttr = ("FormStateTag_" + (model.variables.formsList_ActiveVar.getCurrentRowNumber(callContext.iterationContext)).toString());
return rec;
}();
}, function () {
return model.variables.formsList_ActiveVar.getCurrent(callContext.iterationContext).formTagStateAttr;
}, function () {
return model.variables.formsList_ActiveVar.getCurrentRowNumber(callContext.iterationContext);
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "70",
alias: "36"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": ("RefundStatus_" + (model.variables.formsList_ActiveVar.getCurrentRowNumber(callContext.iterationContext)).toString())
},
value: model.variables.formsList_ActiveVar.getCurrent(callContext.iterationContext).formStatusLabelAttr,
_idProps: {
service: idService,
uuid: "71"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.formsList_ActiveVar.getCurrentRowNumber(callContext.iterationContext)), asPrimitiveValue(model.variables.formsList_ActiveVar.getCurrent(callContext.iterationContext).formStatusLabelAttr)]
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.formsList_ActiveVar.getCurrentRowNumber(callContext.iterationContext)), asPrimitiveValue(model.variables.formsList_ActiveVar.getCurrent(callContext.iterationContext).formStatusLabelAttr), asPrimitiveValue(model.variables.formsList_ActiveVar.getCurrent(callContext.iterationContext).formTagStateAttr)]
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "heading6 margin-top-02 text-primary-0",
visible: true,
_idProps: {
service: idService,
name: "RefundCompany"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": ("RefundMerchantName_" + (model.variables.formsList_ActiveVar.getCurrentRowNumber(callContext.iterationContext)).toString())
},
value: model.variables.formsList_ActiveVar.getCurrent(callContext.iterationContext).merchantNameAttr,
_idProps: {
service: idService,
uuid: "73"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-top-02",
visible: true,
_idProps: {
service: idService,
name: "RefundValues"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("bRq6Env4mUqL10a0jj9LeA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.justifyAttr = ShopperPortalEUModel.staticEntities.flexJustify.spaceBetween;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "75",
alias: "37"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FlexItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "76",
alias: "38"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": ("RefundLabel_" + (model.variables.formsList_ActiveVar.getCurrentRowNumber(callContext.iterationContext)).toString())
},
value: model.variables.formsList_ActiveVar.getCurrent(callContext.iterationContext).refundLabel_UIAttr,
_idProps: {
service: idService,
uuid: "77"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.formsList_ActiveVar.getCurrentRowNumber(callContext.iterationContext)), asPrimitiveValue(model.variables.formsList_ActiveVar.getCurrent(callContext.iterationContext).refundLabel_UIAttr)]
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FlexItem_mvc_view, {
inputs: {
ExtendedClass: "text-align-right"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "78",
alias: "39"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": ("RefundAmount_" + (model.variables.formsList_ActiveVar.getCurrentRowNumber(callContext.iterationContext)).toString())
},
style: "heading6 text-primary-0",
value: model.variables.formsList_ActiveVar.getCurrent(callContext.iterationContext).refundAmountTxtAttr,
_idProps: {
service: idService,
uuid: "79"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "body-4",
visible: true,
_idProps: {
service: idService,
uuid: "80"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": ("RefundAmountMessage_" + (model.variables.formsList_ActiveVar.getCurrentRowNumber(callContext.iterationContext)).toString())
},
value: model.variables.formsList_ActiveVar.getCurrent(callContext.iterationContext).refundAmountMessageAttr,
_idProps: {
service: idService,
uuid: "81"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables.formsList_ActiveVar.getCurrentRowNumber(callContext.iterationContext)), asPrimitiveValue(model.variables.formsList_ActiveVar.getCurrent(callContext.iterationContext).refundAmountMessageAttr), asPrimitiveValue(model.variables.formsList_ActiveVar.getCurrent(callContext.iterationContext).refundAmountTxtAttr)]
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.formsList_ActiveVar.getCurrentRowNumber(callContext.iterationContext)), asPrimitiveValue(model.variables.formsList_ActiveVar.getCurrent(callContext.iterationContext).refundAmountMessageAttr), asPrimitiveValue(model.variables.formsList_ActiveVar.getCurrent(callContext.iterationContext).refundAmountTxtAttr), asPrimitiveValue(model.variables.formsList_ActiveVar.getCurrent(callContext.iterationContext).refundLabel_UIAttr)]
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables.formsList_ActiveVar.getCurrentRowNumber(callContext.iterationContext)), asPrimitiveValue(model.variables.formsList_ActiveVar.getCurrent(callContext.iterationContext).refundAmountMessageAttr), asPrimitiveValue(model.variables.formsList_ActiveVar.getCurrent(callContext.iterationContext).refundAmountTxtAttr), asPrimitiveValue(model.variables.formsList_ActiveVar.getCurrent(callContext.iterationContext).refundLabel_UIAttr), asPrimitiveValue(model.variables.formsList_ActiveVar.getCurrent(callContext.iterationContext).merchantNameAttr), asPrimitiveValue(model.variables.formsList_ActiveVar.getCurrent(callContext.iterationContext).formStatusLabelAttr), asPrimitiveValue(model.variables.formsList_ActiveVar.getCurrent(callContext.iterationContext).formTagStateAttr), asPrimitiveValue(model.variables.formsList_ActiveVar.getCurrent(callContext.iterationContext).formNumberAttr), asPrimitiveValue(model.variables.hasTestUIAvailableVar)]
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.hasTestUIAvailableVar), asPrimitiveValue(model.variables.formsList_ActiveVar.getCurrent(callContext.iterationContext).refundAmountMessageAttr), asPrimitiveValue(model.variables.formsList_ActiveVar.getCurrent(callContext.iterationContext).refundAmountTxtAttr), asPrimitiveValue(model.variables.formsList_ActiveVar.getCurrent(callContext.iterationContext).refundLabel_UIAttr), asPrimitiveValue(model.variables.formsList_ActiveVar.getCurrent(callContext.iterationContext).merchantNameAttr), asPrimitiveValue(model.variables.formsList_ActiveVar.getCurrent(callContext.iterationContext).formStatusLabelAttr), asPrimitiveValue(model.variables.formsList_ActiveVar.getCurrent(callContext.iterationContext).formTagStateAttr), asPrimitiveValue(model.variables.formsList_ActiveVar.getCurrent(callContext.iterationContext).formNumberAttr), asPrimitiveValue(model.variables.formsList_ActiveVar.getCurrentRowNumber(callContext.iterationContext))]
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables.hasTestUIAvailableVar), asPrimitiveValue(model.variables.formsList_ActiveVar.getCurrent(callContext.iterationContext).refundAmountMessageAttr), asPrimitiveValue(model.variables.formsList_ActiveVar.getCurrent(callContext.iterationContext).refundAmountTxtAttr), asPrimitiveValue(model.variables.formsList_ActiveVar.getCurrent(callContext.iterationContext).refundLabel_UIAttr), asPrimitiveValue(model.variables.formsList_ActiveVar.getCurrent(callContext.iterationContext).merchantNameAttr), asPrimitiveValue(model.variables.formsList_ActiveVar.getCurrent(callContext.iterationContext).formStatusLabelAttr), asPrimitiveValue(model.variables.formsList_ActiveVar.getCurrent(callContext.iterationContext).formTagStateAttr), asPrimitiveValue(model.variables.formsList_ActiveVar.getCurrent(callContext.iterationContext).formNumberAttr), asPrimitiveValue(model.variables.formsList_ActiveVar.getCurrentRowNumber(callContext.iterationContext))]
})))];
}, callContext, idService, "1")
},
_dependencies: [asPrimitiveValue(model.variables.hasTestUIAvailableVar)]
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.hasTestUIAvailableVar), asPrimitiveValue(model.variables.formsList_ActiveVar)]
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-top-04",
visible: true,
_idProps: {
service: idService,
name: "AddTFFBtn"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("orVr5iH2GUePxbglFSpU2Q.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRec();
rec.testIdAttr = "AddTaxFreeFormButton";
rec.typeAttr = ShopperPortalEUModel.staticEntities.customButtonType.secondary;
rec.isFullWidthAttr = true;
return rec;
}();
}),
ExtendedClass: "text-align-center"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "83",
alias: "40"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
button: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: false,
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Refund/MyRefunds/Button OnClick");
controller.addTaxFreeForm$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn",
visible: true,
_idProps: {
service: idService,
uuid: "84"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("MzyznirObkGizeiejQ_6LA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonItemOptionsRec();
rec.iconAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsIconRec();
rec.nameAttr = "Add";
return rec;
}();
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "85",
alias: "41"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "AddTaxFreeformLabel"
},
value: "Add Tax Free form",
_idProps: {
service: idService,
uuid: "86"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
}))];
}, function () {
return [$if(model.variables.hasClosedRefundsVar, false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomAlert_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("f22nmzmb60Ggr_KxQoBg4g.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomAlertOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customAlertType.neutral;
rec.iconAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomAlertIconOptionsRec();
rec.nameAttr = "shopping_bag";
return rec;
}();
return rec;
}();
}),
ExtendedClass: "margin-top-05"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "87",
alias: "42"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
title: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "FormsNoRefundRequestsTitle"
},
value: "You have no active refund requests",
_idProps: {
service: idService,
uuid: "88"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "FormsNoRefundRequestsContent"
},
value: "Remember to ask for your Planet Tax Free form whenever you shop internationally.",
_idProps: {
service: idService,
uuid: "89"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
})];
}, function () {
return [];
})];
})];
})];
}),
bottom: new PlaceholderContent(function () {
return [$if(model.variables.formsList_ActiveVar.isEmpty, false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
name: "TFFAddCardCtn"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCard_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("TaxFreeFormAddCard.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomCardOptionsRec();
rec.testIdAttr = "TaxFreeFormAddCard";
return rec;
}();
}),
ExtendedClass: "text-align-center margin-top-05"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
name: "TaxFreeFormAddCard",
alias: "43"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "text-primary-35",
visible: true,
_idProps: {
service: idService,
uuid: "92"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "DoYouHaveTFF_Msg"
},
value: "Do you have Tax Free forms?",
_idProps: {
service: idService,
uuid: "93"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-top-04",
visible: true,
_idProps: {
service: idService,
name: "AddTaxFreeFromBtn"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, {
inputs: {
ExtendedClass: "text-align-center",
Options: model.getCachedValue(idService.getId("tB9G3Df9Hku4tv_qmPmIRA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRec();
rec.testIdAttr = "AddTaxFreeForm2ndBtn";
rec.typeAttr = ShopperPortalEUModel.staticEntities.customButtonType.secondary;
rec.isFullWidthAttr = true;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "95",
alias: "44"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
button: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: false,
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Refund/MyRefunds/Button OnClick");
controller.addTaxFreeForm$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn",
visible: true,
_idProps: {
service: idService,
uuid: "96"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("vUKFjpZMz0m4ZyMHpugxlg.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonItemOptionsRec();
rec.iconAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsIconRec();
rec.nameAttr = "Add";
return rec;
}();
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "97",
alias: "45"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "AddTaxFreeformButtonLabel"
},
value: "Add Tax Free form",
_idProps: {
service: idService,
uuid: "98"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
}))];
}, function () {
return [];
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-top-04",
visible: true,
_idProps: {
service: idService,
name: "CantFind_Ctn"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, {
inputs: {
ExtendedClass: "body-3",
Options: model.getCachedValue(idService.getId("emPI0beOeEOFLdd3j8Jmeg.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRec();
rec.testIdAttr = "MissingRefund";
rec.typeAttr = ShopperPortalEUModel.staticEntities.customButtonType.linkPrimary;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "100",
alias: "46"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
button: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: false,
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Refund/MyRefunds/Button OnClick");
controller.toggleCantFindRefundPopup$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn",
visible: true,
_idProps: {
service: idService,
uuid: "101"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("EIvMylai1kW7iLJ5zfvnsg.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonItemOptionsRec();
rec.iconAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsIconRec();
rec.nameAttr = "help";
return rec;
}();
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "102",
alias: "47"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Can\'t find your refund?",
_idProps: {
service: idService,
uuid: "103"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
})), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomPopup_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "104",
alias: "48"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
popup: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Popup, {
showPopup: model.variables.cantFind_ShowPopupVar,
style: "popup-dialog",
_idProps: {
service: idService,
uuid: "105"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomPopupLayout_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onOverlayClick$Action: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ShopperPortalEUUIComponents/CustomPopupLayout OnOverlayClick");
controller.toggleCantFindRefundPopup$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "106",
alias: "49"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
title: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "MyRefundsPopupTitle"
},
value: "Can’t find your refund?",
_idProps: {
service: idService,
uuid: "107"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "MyRefundsPopupText"
},
value: "Some forms may not appear in your list of refunds\r\n",
_idProps: {
service: idService,
uuid: "108"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_BulletsList_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "109",
alias: "50"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
list: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.AdvancedHtml, {
tag: "ul",
_idProps: {
service: idService,
uuid: "110"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_BulletsListItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "111",
alias: "51"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "MyRefundsPopupFirstBullet"
},
value: "If you didn\'t share your passport at the store when shopping",
_idProps: {
service: idService,
uuid: "112"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_BulletsListItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "113",
alias: "52"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "MyRefundsPopupSecondBullet"
},
value: "If you shopped Tax Free outside the EU",
_idProps: {
service: idService,
uuid: "114"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomAlert_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("DlLS84UrWkmcKNvasfndKw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomAlertOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customAlertType.info;
rec.iconAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomAlertIconOptionsRec();
return rec;
}();
return rec;
}();
}),
ExtendedClass: "margin-top-04"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "115",
alias: "53"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
title: PlaceholderContent.Empty,
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "AlertInfo_AddForm"
},
value: "If you shopped Tax Free in the EU but don\'t see the form, you can ",
_idProps: {
service: idService,
uuid: "116"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLink_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("BosLjnj_ske8DIVKyakaCw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomLinkOptionsRec();
rec.testIdAttr = "AddFormlink";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "117",
alias: "54"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
link: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Link, {
enabled: true,
transition: OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Fade),
url: OS.Navigation.generateScreenURL("ShopperPortalEU", "AddTaxFreeForm", {}),
visible: true,
_idProps: {
service: idService,
uuid: "118"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLinkItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "119",
alias: "55"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "add it manually",
_idProps: {
service: idService,
uuid: "120"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
}), React.createElement(OSWidgets.Expression, {
value: ".",
_idProps: {
service: idService,
uuid: "121"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-top-04",
visible: true,
_idProps: {
service: idService,
uuid: "122"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "StillNeedHelpText"
},
value: "Still need help? ",
_idProps: {
service: idService,
uuid: "123"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLink_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("uqhuMC98i0OB0WYohbz4bg.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomLinkOptionsRec();
rec.testIdAttr = "RefundsPlanetSupport";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "124",
alias: "56"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
link: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Link, {
enabled: true,
transition: OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Fade),
url: OS.Navigation.generateScreenURL("ShopperPortalEU", "Help", {}),
visible: true,
_idProps: {
service: idService,
uuid: "125"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLinkItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "126",
alias: "57"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Contact us",
_idProps: {
service: idService,
uuid: "127"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
}))];
}),
actions: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("_TBmLOJhA0+zyRakv73eJQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRec();
rec.testIdAttr = "Close-id";
rec.typeAttr = ShopperPortalEUModel.staticEntities.customButtonType.primary;
rec.isFullWidthAttr = true;
return rec;
}();
}),
ExtendedClass: "text-align-center"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "128",
alias: "58"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
button: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: false,
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Refund/MyRefunds/Button OnClick");
controller.toggleCantFindRefundPopup$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn",
visible: true,
_idProps: {
service: idService,
uuid: "129"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "130",
alias: "59"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Close",
_idProps: {
service: idService,
uuid: "131"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables.cantFind_ShowPopupVar)]
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.cantFind_ShowPopupVar), asPrimitiveValue(model.variables.hasTestUIAvailableVar), asPrimitiveValue(model.variables.nrReadyForRefundFormsVar), asPrimitiveValue(model.variables.hasClosedRefundsVar), asPrimitiveValue(model.variables.formsList_ActiveVar)]
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.cantFind_ShowPopupVar), asPrimitiveValue(model.variables.hasTestUIAvailableVar), asPrimitiveValue(model.variables.nrReadyForRefundFormsVar), asPrimitiveValue(model.variables.hasClosedRefundsVar), asPrimitiveValue(model.variables.formsList_ActiveVar)]
})];
}),
bottom: PlaceholderContent.Empty
},
_dependencies: [asPrimitiveValue(model.variables.cantFind_ShowPopupVar), asPrimitiveValue(model.variables.hasTestUIAvailableVar), asPrimitiveValue(model.variables.nrReadyForRefundFormsVar), asPrimitiveValue(model.variables.hasClosedRefundsVar), asPrimitiveValue(model.variables.formsList_ActiveVar), asPrimitiveValue(ShopperPortalEUClientVariables.getShopperProfileCompleted()), asPrimitiveValue(model.variables.carouselVar.showProfileAttr), asPrimitiveValue(model.variables.carouselVar.addCreditCardAttr), asPrimitiveValue(model.variables.isScreenReadyVar), asPrimitiveValue(ShopperPortalEUClientVariables.getShopperName())]
}));
        };
        return View;
    })(OSView.BaseView.BaseWebScreen);
	
    return View;
});
define("ShopperPortalEU.Refund.MyRefunds.mvc$controller", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_Forms_IS.controller", "ShopperPortalEU_UI_Theme.controller", "ShopperPortalEU.languageResources", "ShopperPortalEU.clientVariables", "ShopperPortalEU.Refund.MyRefunds.mvc$debugger", "ShopperPortalEU.Refund.controller", "ShopperPortalEU_Forms_IS.model$FormInfo_WrapperRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Forms_IS", "ShopperPortalEU.model$FormInfo_WrapperList", "ShopperPortalEU.model$BooleanBooleanRecord", "ShopperPortalEU_UI_Theme.model$LayoutOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$LayoutHeaderOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU.model$ApplicationHeaderRec", "ShopperPortalEU_UI_Components.model$CustomCarouselOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$CardBackgroundOptionsRec", "ShopperPortalEU_UI_Components.model$FlexOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconRec", "ShopperPortalEU_UI_Components.model$FullHeightContentOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentTopOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentBottomOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsIconRec", "ShopperPortalEU_UI_Components.model$CustomCardOptionsRec", "ShopperPortalEU_UI_Components.model$ProgressBarOptionsRec", "ShopperPortalEU_UI_Components.model$CircleIconOptionsRec", "ShopperPortalEU_UI_Components.model$CircleIconIconOptionsRec", "ShopperPortalEU_UI_Components.model$CustomListOptionsRec", "ShopperPortalEU_UI_Components.model$CustomTagOptionsRec", "ShopperPortalEU_UI_Components.model$FlexItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomAlertOptionsRec", "ShopperPortalEU_UI_Components.model$CustomAlertIconOptionsRec", "ShopperPortalEU_UI_Components.model$CustomPopupLayoutOptionsRec", "ShopperPortalEU_UI_Components.model$CustomPopupLayoutHeaderImageOptionsRec", "ShopperPortalEU.controller$ClarityEvent", "ShopperPortalEU.controller$GroupFormsByDate", "ShopperPortalEU_Forms_IS.controller$GetFormList", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", "ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger", "ShopperPortalEU.controller$DefaultErrorMessage", "ShopperPortalEU.controller$HeapIdentify", "ShopperPortalEU.controller$InitAppcues", "ShopperPortalEU.model$ApcuesIdentifyRec", "ShopperPortalEU.controller$ApcuesIdentify"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_Forms_ISModel, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_Forms_ISController, ShopperPortalEU_UI_ThemeController, ShopperPortalEULanguageResources, ShopperPortalEUClientVariables, ShopperPortalEU_Refund_MyRefunds_mvc_Debugger, ShopperPortalEU_RefundController) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {
getApplicationReadyData$DataActRefresh: 0
};
this.dataFetchDependentsGraph = {
getApplicationReadyData$DataActRefresh: []
};
this.shouldSendClientVarsToDataSources = true;
}
// Server Actions

// Aggregates and Data Actions
Controller.prototype.getApplicationReadyData$DataActRefresh = function (callContext) {
var model = this.model;
var controller = this.controller;
var callContext = controller.callContext(callContext);
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:YLV8aKMrKU6R+pydFe9PPg:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.QahGhPpqr0+KA4aE1HEVvw/DataActions.YLV8aKMrKU6R+pydFe9PPg:EUnyu3nQyHyZguRXzPddyw", "ShopperPortalEU", "GetApplicationReadyData", "NRFlows.DataScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.setThreadStartName(callContext.id, "Refund/MyRefunds/GetApplicationReadyData");
return controller.callDataAction("DataActionGetApplicationReadyData", "screenservices/ShopperPortalEU/Refund/MyRefunds/DataActionGetApplicationReadyData", "fuYH_Q4Plu1FG6cutb4Jpg", function (b) {
model.variables.getApplicationReadyDataDataAct.dataFetchStatusAttr = b;
}, function (json) {
model.variables.getApplicationReadyDataDataAct.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getApplicationReadyDataDataAct.constructor));
}, undefined, OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, callContext, ShopperPortalEUClientVariables, false);

}, function () {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:YLV8aKMrKU6R+pydFe9PPg", callContext.id);
controller.popDebuggerContext(callContext);

});
};

Controller.prototype.dataFetchActionNames = ["getApplicationReadyData$DataActRefresh"];
// Client Actions
Controller.prototype._closeAddCardOnClick$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("CloseAddCardOnClick");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:BzhITc4A2Ey4mJUHR4YspA:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.QahGhPpqr0+KA4aE1HEVvw/ClientActions.BzhITc4A2Ey4mJUHR4YspA:h7x0khhFUOwFmiDrtP0zUg", "ShopperPortalEU", "CloseAddCardOnClick", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:+VMmDfTIGEaTSdMPav+wVw", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ysUo+AvVCU+_dfTcjEAeXA", callContext.id);
// Carousel.AddCreditCard = False
model.variables.carouselVar.addCreditCardAttr = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:rbKuumL660Kpydotb7HH9g", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:BzhITc4A2Ey4mJUHR4YspA", callContext.id);
}

};
Controller.prototype._navigateToRequestRefund$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("NavigateToRequestRefund");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:wgSTWVLf8Uu74Bb1jvbNSQ:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.QahGhPpqr0+KA4aE1HEVvw/ClientActions.wgSTWVLf8Uu74Bb1jvbNSQ:Hi_pXV2WHABuw65yAVoexw", "ShopperPortalEU", "NavigateToRequestRefund", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:wI+46M_qaE60rNZQ2ByuWA", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Fa2uANhki06fZBIEXMxfEw", callContext.id);
// Execute Action: ClarityEvent
ShopperPortalEUController.default.clarityEvent$Action("RequestRefundFromList_btn", callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:G2i80+7QDkKms6DfOMhU4w", callContext.id);
// Destination: /ShopperPortalEU/RequestRefund
return OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "RequestRefund", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:wgSTWVLf8Uu74Bb1jvbNSQ", callContext.id);
}

};
Controller.prototype._layoutAfterAuthentication$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("LayoutAfterAuthentication");
callContext = controller.callContext(callContext);
var listFilter_ClosedVar = new OS.DataTypes.VariableHolder();
var listFilter_ActiveVar = new OS.DataTypes.VariableHolder();
var listFilterVar = new OS.DataTypes.VariableHolder();
var groupFormsByDate_ActiveVar = new OS.DataTypes.VariableHolder();
var getFormListVar = new OS.DataTypes.VariableHolder();
var listFilter_ReadyForRefundVar = new OS.DataTypes.VariableHolder();
var jSONSerializeFormInfoListVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.JSONSerializeOutputType());
varBag.callContext = callContext;
varBag.listFilter_ClosedVar = listFilter_ClosedVar;
varBag.listFilter_ActiveVar = listFilter_ActiveVar;
varBag.listFilterVar = listFilterVar;
varBag.groupFormsByDate_ActiveVar = groupFormsByDate_ActiveVar;
varBag.getFormListVar = getFormListVar;
varBag.listFilter_ReadyForRefundVar = listFilter_ReadyForRefundVar;
varBag.jSONSerializeFormInfoListVar = jSONSerializeFormInfoListVar;
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:I1FvcreCHEm1vMOVgsBoaA:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.QahGhPpqr0+KA4aE1HEVvw/ClientActions.I1FvcreCHEm1vMOVgsBoaA:Twm0o3KS6r6YGNbJHNRlgA", "ShopperPortalEU", "LayoutAfterAuthentication", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:QTBqeEC_HEKGaQXyv+xsmg", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:DV_gwLWrx0aWs5x3VTXGgg", callContext.id);
// Execute Action: GetFormList
model.flush();
return ShopperPortalEU_Forms_ISController.default.getFormList$Action(callContext).then(function (value) {
getFormListVar.value = value;
}).then(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:o54rvRfUh0elSUx+hb3pKg", callContext.id) && getFormListVar.value.successOut)) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:txBegOrVpECXTBMT2ea4EQ", callContext.id);
// JSON Serialize: JSONSerializeFormInfoList
jSONSerializeFormInfoListVar.value.jSONOut = OS.JSONUtils.serializeToJSON(getFormListVar.value.formInfoListOut, false, false);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:TAszQunWW0ONURDbqG_LIA", callContext.id);
// FormInfoListJSON = JSONSerializeFormInfoList.JSON
ShopperPortalEUClientVariables.setFormInfoListJSON(jSONSerializeFormInfoListVar.value.jSONOut);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:9JZoWDmJukCVoz_yLPsmKQ", callContext.id);
// Execute Action: ListFilter_Active
listFilter_ActiveVar.value = OS.SystemActions.listFilter(getFormListVar.value.formInfoListOut, function (p) {
return p.isActiveAttr;
}, callContext);

OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:fRtblnoQXUesGQRKg18dtw", callContext.id);
// Execute Action: GroupFormsByDate_Active
groupFormsByDate_ActiveVar.value = ShopperPortalEUController.default.groupFormsByDate$Action(listFilter_ActiveVar.value.filteredListOut, callContext);

OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ARn+R6Sr_E28bBu2YZbGww", callContext.id);
// Execute Action: ListFilter_Closed
listFilter_ClosedVar.value = OS.SystemActions.listFilter(getFormListVar.value.formInfoListOut, function (p) {
return p.isClosedAttr;
}, callContext);

OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:oNTE3s1XeEK98ZsJAF5M9w", callContext.id);
// Execute Action: ListFilter_ReadyForRefund
listFilter_ReadyForRefundVar.value = OS.SystemActions.listFilter(getFormListVar.value.formInfoListOut, function (p) {
return p.isReadyForRefundAttr;
}, callContext);

// FormsList
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:5TRa6DuvnUyuxY6jllXt+g", callContext.id);
// FormsList_Active = GroupFormsByDate_Active.FormsList_Output
model.variables.formsList_ActiveVar = groupFormsByDate_ActiveVar.value.formsList_OutputOut;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:5TRa6DuvnUyuxY6jllXt+g", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// HasTestUIAvailable = GetFormList.SiteHasFormNumberEnabled
model.variables.hasTestUIAvailableVar = getFormListVar.value.siteHasFormNumberEnabledOut;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:5TRa6DuvnUyuxY6jllXt+g", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// NrReadyForRefundForms = ListFilter_ReadyForRefund.FilteredList.Length
model.variables.nrReadyForRefundFormsVar = listFilter_ReadyForRefundVar.value.filteredListOut.length;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:5TRa6DuvnUyuxY6jllXt+g", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// HasClosedRefunds = notListFilter_Closed.FilteredList.Empty
model.variables.hasClosedRefundsVar = !(listFilter_ClosedVar.value.filteredListOut.isEmpty);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:EN3_fUFvHUWvy12VA9el9g", callContext.id);
// Execute Action: ListFilter
listFilterVar.value = OS.SystemActions.listFilter(model.variables.formsList_ActiveVar, function (p) {
return (p.formDetailsAttr.formStatusIdAttr === ShopperPortalEUModel.staticEntities.sPFormStatus.postRefundDetailsRequired);
}, callContext);

// FormsActive has RefundDetailsRequired?
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:vZlVf0JNHU+UkuKSUnZKWA", callContext.id) && !(listFilterVar.value.filteredListOut.isEmpty))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:KehsYXGYR0qfR3L_rWJuyQ", callContext.id);
// Carousel.AddCreditCard = False
model.variables.carouselVar.addCreditCardAttr = false;
}

OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Va8farnxsEut6WzV76n5Ug", callContext.id);
// IsScreenReady = True
model.variables.isScreenReadyVar = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:tkd99mg4f0GUpnpXu20Aqw", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:kqZ6wZEENE6oE9iWvontAA", callContext.id);
// IsScreenReady = True
model.variables.isScreenReadyVar = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:xq0mw0Seb020jq65b2XyTA", callContext.id);
// Execute Action: ErrorMessage2
ShopperPortalEU_UI_ThemeController.default.customMessageTrigger$Action(function () {
var rec = new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customMessageType.error;
rec.titleAttr = "We could not load the forms";
rec.contentAttr = OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.defaultErrorMessage$Action(callContext).errorMessageOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
rec.testIdAttr = "Error";
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:V1a2fDrL5k+ieaRiatFHFw", callContext.id);
}

});
}).then(function (res) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:I1FvcreCHEm1vMOVgsBoaA", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:I1FvcreCHEm1vMOVgsBoaA", callContext.id);
throw ex;

});
};
Controller.prototype._closeProfileOnClick$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("CloseProfileOnClick");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:89FNdGZRAkmHeHE8twmEvg:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.QahGhPpqr0+KA4aE1HEVvw/ClientActions.89FNdGZRAkmHeHE8twmEvg:I5qbuVrSXWMtz9qVKqUpOg", "ShopperPortalEU", "CloseProfileOnClick", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:LI2RDaTj1Eym0rNwAx5MCQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:rDJYKzv55EmiCF5RZxcOoQ", callContext.id);
// Carousel.ShowProfile = False
model.variables.carouselVar.showProfileAttr = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:jGyJ8QGyykaCPY7+2RyBQQ", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:89FNdGZRAkmHeHE8twmEvg", callContext.id);
}

};
Controller.prototype._toggleCantFindRefundPopup$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("ToggleCantFindRefundPopup");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:N8fJeZaWIECaHrPdASiozA:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.QahGhPpqr0+KA4aE1HEVvw/ClientActions.N8fJeZaWIECaHrPdASiozA:Uzs+4HJTSvoQ0Ig5Ogg96w", "ShopperPortalEU", "ToggleCantFindRefundPopup", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Y6BFuy6dlk2HIBp3iahx0g", callContext.id);
// toggle popup
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:KJpDA+Q5x069FRrI5u6jig", callContext.id);
// CantFind_ShowPopup = notCantFind_ShowPopup
model.variables.cantFind_ShowPopupVar = !(model.variables.cantFind_ShowPopupVar);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:b74OH65BEUye+ntfvG422A", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:N8fJeZaWIECaHrPdASiozA", callContext.id);
}

};
Controller.prototype._addCard$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("AddCard");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:TEy2gIrotk62rKMX9dL6SA:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.QahGhPpqr0+KA4aE1HEVvw/ClientActions.TEy2gIrotk62rKMX9dL6SA:OPcLNUWB6yKJ2ZrlHxarTA", "ShopperPortalEU", "AddCard", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:5P5d01zfnEuzBejrbOTPAQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:uU_pJShkJ0CWlZgGWwyPrg", callContext.id);
// Execute Action: ClarityEvent
ShopperPortalEUController.default.clarityEvent$Action("AddCard_link", callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:aGF29rh1KkKK5kMEaCSRmA", callContext.id);
// FromCarouselAddCard = True
ShopperPortalEUClientVariables.setFromCarouselAddCard(true);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:t_z8xaSTWU2QCF4ip+SyuQ", callContext.id);
// Destination: /ShopperPortalEU/AddCard
return OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "AddCard", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:TEy2gIrotk62rKMX9dL6SA", callContext.id);
}

};
Controller.prototype._completeProfile$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("CompleteProfile");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:2S2lnXPz8Eqt38PfNkI_ag:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.QahGhPpqr0+KA4aE1HEVvw/ClientActions.2S2lnXPz8Eqt38PfNkI_ag:Pk0OuSOHyZx_ptBH2B1Atg", "ShopperPortalEU", "CompleteProfile", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:DicgpWZi8UWSJDv2cvGpTg", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:yS5hDB6jp0mltpwQ2ute9A", callContext.id);
// IsProfileDetailsNavigation = False
ShopperPortalEUClientVariables.setIsProfileDetailsNavigation(false);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:yDOkQasgvUC4lvtQ2vQEkQ", callContext.id);
// Execute Action: ClarityEvent
ShopperPortalEUController.default.clarityEvent$Action("CompleteYourProfile_link", callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:P1+mfYUAYUmgAbWzjJb5dw", callContext.id);
// Destination: /ShopperPortalEU/CompleteDetails
return OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "CompleteDetails", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:2S2lnXPz8Eqt38PfNkI_ag", callContext.id);
}

};
Controller.prototype._addTaxFreeForm$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("AddTaxFreeForm");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:DDcqucr_EUCIoPkxgxnTOA:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.QahGhPpqr0+KA4aE1HEVvw/ClientActions.DDcqucr_EUCIoPkxgxnTOA:zdV54YyhkuWwriUdw6GK2Q", "ShopperPortalEU", "AddTaxFreeForm", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:cMMMahgVO0OS36Y3FPkc+g", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:5cQM8uJL806Vs2qCkZa9qQ", callContext.id);
// Execute Action: ClarityEvent
ShopperPortalEUController.default.clarityEvent$Action("AddTFF_btn", callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:z9o8pSje6Eis2u1oeT+NYQ", callContext.id);
// Destination: /ShopperPortalEU/AddTaxFreeForm
return OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "AddTaxFreeForm", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.SlideFromBottom), callContext, true);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:DDcqucr_EUCIoPkxgxnTOA", callContext.id);
}

};
Controller.prototype._onInitialize$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnInitialize");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:vqwov8p+j0CmU4r5BtI_Rw:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.QahGhPpqr0+KA4aE1HEVvw/ClientActions.vqwov8p+j0CmU4r5BtI_Rw:t5pdLNImrhXVtgsAWAjGYg", "ShopperPortalEU", "OnInitialize", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:_N+j9WeOnU60xArvV6_AQw", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:1StzHYtaTU2xhV2kbuo8FA", callContext.id);
// IsScreenReady = False
model.variables.isScreenReadyVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:1StzHYtaTU2xhV2kbuo8FA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Carousel.ShowProfile = If
model.variables.carouselVar.showProfileAttr = ((ShopperPortalEUClientVariables.getShopperProfileCompleted().equals(OS.BuiltinFunctions.integerToDecimal(100))) ? (false) : (true));
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:1StzHYtaTU2xhV2kbuo8FA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// Carousel.AddCreditCard = If
model.variables.carouselVar.addCreditCardAttr = (((ShopperPortalEUClientVariables.getShopperCards() > 0)) ? (false) : (true));
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:1StzHYtaTU2xhV2kbuo8FA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// HasClosedRefunds = False
model.variables.hasClosedRefundsVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:1StzHYtaTU2xhV2kbuo8FA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// IsFromFormDetailsOrStepScreen = False
ShopperPortalEUClientVariables.setIsFromFormDetailsOrStepScreen(false);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:1StzHYtaTU2xhV2kbuo8FA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "6");
// FromCarouselAddCard = False
ShopperPortalEUClientVariables.setFromCarouselAddCard(false);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:jwDtd3mYbU+YloXqHvbdBQ", callContext.id);
// Execute Action: HeapIdentify
ShopperPortalEUController.default.heapIdentify$Action(ShopperPortalEUClientVariables.getShopperContact(), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ITH5TxX4E028RfV2qylVMw", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:vqwov8p+j0CmU4r5BtI_Rw", callContext.id);
}

};
Controller.prototype._onReady$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnReady");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:b3OS3O2Th0+NCK2Re4QkEw:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.QahGhPpqr0+KA4aE1HEVvw/ClientActions.b3OS3O2Th0+NCK2Re4QkEw:mgXvM1SLDtX5vY3jMIem7w", "ShopperPortalEU", "OnReady", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ghr+1wLISkKBjDPwefTkdQ", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
// Reset FormNumber vars
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:1_BtvvijkkCRMtWmQnaOJg", callContext.id);
// FormNumberRA1 = ""
ShopperPortalEUClientVariables.setFormNumberRA1("");
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:1_BtvvijkkCRMtWmQnaOJg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// FormNumberVA1 = ""
ShopperPortalEUClientVariables.setFormNumberVA1("");
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:1_BtvvijkkCRMtWmQnaOJg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// FormNumberVA2 = ""
ShopperPortalEUClientVariables.setFormNumberVA2("");
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:1_BtvvijkkCRMtWmQnaOJg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// IsFormRequestRefundTriggered = False
ShopperPortalEUClientVariables.setIsFormRequestRefundTriggered(false);
// IsHeapActive
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:JNfCY0tWOUGUhtVnuaXz_g", callContext.id) && model.variables.getApplicationReadyDataDataAct.isHeapActiveOut)) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:39hPoLtCuUKiAuejkn7fTw", callContext.id);
// Execute Action: AppcuesRequire
model.flush();
return OS.SystemActions.requireScript("https://fast.appcues.com/220902.js", callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:JYZaSylgZ0aW7X9gEXxHJw", callContext.id);
// Execute Action: InitAppcues
ShopperPortalEUController.default.initAppcues$Action(callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:kPpqjDz80ESzR+ChMvs4WQ", callContext.id);
// Execute Action: ApcuesIdentify
ShopperPortalEUController.default.apcuesIdentify$Action(function () {
var rec = new ShopperPortalEUModel.ApcuesIdentifyRec();
rec.guidAttr = ShopperPortalEUClientVariables.getShopperGuid();
rec.nameAttr = ShopperPortalEUClientVariables.getShopperName();
rec.emailAttr = ShopperPortalEUClientVariables.getEmail();
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:tA4QRj4M0USfQ2Tf8a0DoQ", callContext.id);
});
} else {
// < - >
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:EpfrRvAm8kKCYtHNlRGEuA", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:tA4QRj4M0USfQ2Tf8a0DoQ", callContext.id);
}

});
}).then(function (res) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:b3OS3O2Th0+NCK2Re4QkEw", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:b3OS3O2Th0+NCK2Re4QkEw", callContext.id);
throw ex;

});
};

Controller.prototype.closeAddCardOnClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._closeAddCardOnClick$Action, callContext);

};
Controller.prototype.navigateToRequestRefund$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._navigateToRequestRefund$Action, callContext);

};
Controller.prototype.layoutAfterAuthentication$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._layoutAfterAuthentication$Action, callContext);

};
Controller.prototype.closeProfileOnClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._closeProfileOnClick$Action, callContext);

};
Controller.prototype.toggleCantFindRefundPopup$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._toggleCantFindRefundPopup$Action, callContext);

};
Controller.prototype.addCard$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._addCard$Action, callContext);

};
Controller.prototype.completeProfile$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._completeProfile$Action, callContext);

};
Controller.prototype.addTaxFreeForm$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._addTaxFreeForm$Action, callContext);

};
Controller.prototype.onInitialize$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onInitialize$Action, callContext);

};
Controller.prototype.onReady$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onReady$Action, callContext);

};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:VcUw8y2coUi7OQ+l92mkmQ:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ:1Ox1BferNhnfzrugqQ41yg", "ShopperPortalEU", "Refund", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:QahGhPpqr0+KA4aE1HEVvw:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.QahGhPpqr0+KA4aE1HEVvw:XA823bXE0QziF5JYByfYww", "ShopperPortalEU", "MyRefunds", "NRNodes.WebScreen", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:QahGhPpqr0+KA4aE1HEVvw", callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:VcUw8y2coUi7OQ+l92mkmQ", callContext.id);
};
Controller.prototype.onInitializeEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Refund/MyRefunds On Initialize");
return controller.onInitialize$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onReadyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Refund/MyRefunds On Ready");
return controller.onReady$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return ShopperPortalEU_RefundController.default.handleError(ex, this.callContext());
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return ShopperPortalEUController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, ShopperPortalEULanguageResources);
});

define("ShopperPortalEU.Refund.MyRefunds.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"ARn+R6Sr_E28bBu2YZbGww": {
getter: function (varBag, idService) {
return varBag.listFilter_ClosedVar.value;
}
},
"9JZoWDmJukCVoz_yLPsmKQ": {
getter: function (varBag, idService) {
return varBag.listFilter_ActiveVar.value;
}
},
"EN3_fUFvHUWvy12VA9el9g": {
getter: function (varBag, idService) {
return varBag.listFilterVar.value;
}
},
"fRtblnoQXUesGQRKg18dtw": {
getter: function (varBag, idService) {
return varBag.groupFormsByDate_ActiveVar.value;
}
},
"DV_gwLWrx0aWs5x3VTXGgg": {
getter: function (varBag, idService) {
return varBag.getFormListVar.value;
}
},
"oNTE3s1XeEK98ZsJAF5M9w": {
getter: function (varBag, idService) {
return varBag.listFilter_ReadyForRefundVar.value;
}
},
"txBegOrVpECXTBMT2ea4EQ": {
getter: function (varBag, idService) {
return varBag.jSONSerializeFormInfoListVar.value;
}
},
"5CmsqGdTwUSiGyNqDVdEuA": {
getter: function (varBag, idService) {
return varBag.model.variables.cantFind_ShowPopupVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"gbBZeXoN_kqFd2_+8zDvdA": {
getter: function (varBag, idService) {
return varBag.model.variables.formsList_ActiveVar;
}
},
"apr+Erz8vE+1oBIWgfAiAw": {
getter: function (varBag, idService) {
return varBag.model.variables.isScreenReadyVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"mAh3SqwAR0uTRIOOzX5OFw": {
getter: function (varBag, idService) {
return varBag.model.variables.hasTestUIAvailableVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"Iz+KzABjI0qm2f5Xd6tu2g": {
getter: function (varBag, idService) {
return varBag.model.variables.nrReadyForRefundFormsVar;
},
dataType: OS.DataTypes.DataTypes.Integer
},
"ms8oo2LH70e0mkhnJgaqCQ": {
getter: function (varBag, idService) {
return varBag.model.variables.carouselVar;
}
},
"iDjzbKyDb0qSDTW3V_kyYg": {
getter: function (varBag, idService) {
return varBag.model.variables.hasClosedRefundsVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"YLV8aKMrKU6R+pydFe9PPg": {
getter: function (varBag, idService) {
return varBag.model.variables.getApplicationReadyDataDataAct;
}
},
"qdUXOn9C2Eyeg84bcQwRWA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderLeft"));
})(varBag.model, idService);
}
},
"MgUEmkd7TkSIaKxjORc20w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderCenter"));
})(varBag.model, idService);
}
},
"x+HcB33rikWouTb2LCEfRQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderRight"));
})(varBag.model, idService);
}
},
"yqCpeQZPo0ib3gkNK4kpPA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderBottom"));
})(varBag.model, idService);
}
},
"Y662jqwoxkmkSZUtRIv+qg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Items"));
})(varBag.model, idService);
}
},
"hHo0sWDHvU2081QPVP2v+g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"DmOETiP1XUiVibMPVtNZkw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"3DTq+F0fA02z1Pda18MYmQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Button"));
})(varBag.model, idService);
}
},
"OsYYZJVMzESRflqBL1nKNw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"XW4xqk833E6D+3VI9L6B1g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"seDqmPB+8kSP8fxp2gkDBA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Top"));
})(varBag.model, idService);
}
},
"koqlpG9pkkWkiOm4B79WQg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Bottom"));
})(varBag.model, idService);
}
},
"kJ_yuxv0akmwGEFd6fNG1Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Link"));
})(varBag.model, idService);
}
},
"+hkgtODhTk22fDCq2V8t3g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"6fOUz0UfwkisPuz6VC2rpw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"QVmDQ+0vqE6S6I7KFRIAQw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Top"));
})(varBag.model, idService);
}
},
"lj_ilcbKtUySE6BGoY0eSA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"RnbpJTD7D0y49vCGYLhJzg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Button"));
})(varBag.model, idService);
}
},
"sSwPRvDUJUCVLnXEZOu39A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"0hzn7gadMk+rNOc_rlgnYw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Bottom"));
})(varBag.model, idService);
}
},
"qe14zJbh9Eu7WSiO7h+HYQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Button"));
})(varBag.model, idService);
}
},
"Z2xfrgkucEiv2dfkmiJ+Zg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"SgjzNcyOZEKaiYYnOgK4mg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"zHArqiLFe0KAnulhUoPrWQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"hTfiuTwFdEihtjsb_7kz_A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Top"));
})(varBag.model, idService);
}
},
"aG6J2XMaCkyI1aohXrMTbw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Link"));
})(varBag.model, idService);
}
},
"t2GItRBKVEmT0K5Hfo99hQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"BomEmP6JU0mgpPy+xDy1xw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"vO3dET5Vgky7E8NTiovuUQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Link"));
})(varBag.model, idService);
}
},
"QWogdT69s0iGH4lgt2xaig": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"_aEeS5HijEmuPpK9px5YUg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"qiEzqONqb0yL7_6d0ExuxQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("RequestRefundBtn"));
})(varBag.model, idService);
}
},
"nE0KjypdFkmo9Zplq45fFQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Button"));
})(varBag.model, idService);
}
},
"Q8N+qa0PNk2mZIRFm4mfcA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"mit3kk6+5UuAeZ1WOKUW3A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("If_ActiveListNotEmpty"));
})(varBag.model, idService);
}
},
"76SwFUxqNUW7Xp04R1EW3A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("List"));
})(varBag.model, idService);
}
},
"Yr7BSiEKrE2GEHG8GXRhOg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("FormList_Active"));
})(varBag.model, idService);
}
},
"9Qa3+SvCv0az14UdX92g4Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("RefundCard"));
})(varBag.model, idService);
}
},
"lO+OntXMRUOg0AVXm0NP_A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HasDate"));
})(varBag.model, idService);
}
},
"r7GNcAvQ_0u3xA1eRVJTlQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("RefundDate_Ctn"));
})(varBag.model, idService);
}
},
"Cz4mi+NPVUKUjjniHRPxGA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("RefundCard_Ctn"));
})(varBag.model, idService);
}
},
"Kh2xJa32tEGJKXbHE3wGPw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Link"));
})(varBag.model, idService);
}
},
"RkZsfO566Ei2s_GvMveMpg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"n1sXxyKZQUGNo9npeQC3rg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"XiBRZXFOz0WiGWKOir_0bA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HasTestUIAvailable2"));
})(varBag.model, idService);
}
},
"+bWW7TJZNEGgkzQzdhNq3w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"6q62FUH9YUeD5zuBrmIT3A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"fI8MOrvg+EKi7FrS7_jMFw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("RefundCompany"));
})(varBag.model, idService);
}
},
"T1srh1tlZ0SOPtXuOyDFRw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("RefundValues"));
})(varBag.model, idService);
}
},
"h1nEx3Jg0ke6RbP7HiP2sg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"tQbTl8HxDEKKnyo3PZyHZA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"1SzV2XOa_0a6E3agTwIP1A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"xHDHVDTIhUafIsH65pL3rA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("AddTFFBtn"));
})(varBag.model, idService);
}
},
"gMPHJGvk1062KMkik5DmdA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Button"));
})(varBag.model, idService);
}
},
"HjMOeAxe4EKPY2bGckzAJQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"KU8YqD86gUqiYBIFq8Ymxg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"ijhoyb7mv0ShjYStUcbEnA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"aCMqQuX_SkC3akH8iYNBvA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Bottom"));
})(varBag.model, idService);
}
},
"eJJ2E9jcWEi8Vj7Q_hGa7w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("TFFAddCardCtn"));
})(varBag.model, idService);
}
},
"SNB26kpm7kONlnqnoWOgXg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("TaxFreeFormAddCard"));
})(varBag.model, idService);
}
},
"j73hNp+k4k+Lv5FjSfftIg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"Xj3X1hy5fUW93gJit2kHQg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("AddTaxFreeFromBtn"));
})(varBag.model, idService);
}
},
"dPHE1Ha5w0SIej1ikE0Q4g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Button"));
})(varBag.model, idService);
}
},
"9o+4UusUY0Gqzz+rvSs9zw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"Jk0chHZZA0OCr6S9KKFopg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("CantFind_Ctn"));
})(varBag.model, idService);
}
},
"StJFKCAQMU69is9WN5d0vQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Button"));
})(varBag.model, idService);
}
},
"_sEtZIgWaE6n2+OorX74YQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"Z+1r7BJ+9kCLpCQuqqBN5g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Popup"));
})(varBag.model, idService);
}
},
"QIBtp3XUp02zKaTdHTybDg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"R+wUwDFpxEWi8AS9QXfJDg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"g_ObHj5LDUCPXQ1_WJxx3w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("List"));
})(varBag.model, idService);
}
},
"s4UZwUNXXEeF2p0nn11_9A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"1UcdQrT6nUe3FlMw8U6mAQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"opuSm0leIE+K48cTe+9xpA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"rTe93zMaeEOOHg7TQT5asw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"Kff2mHSDwE2pqWU8hJLJaw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Link"));
})(varBag.model, idService);
}
},
"8bqD+VVqMEudGdrhK8sKcw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"D4c+E0yfi0+58j9rZzt62w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Link"));
})(varBag.model, idService);
}
},
"PUam5CfHi0G1L91_lnTq1A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"lKTDyKY2Hka8TNfVL5xMYg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Actions"));
})(varBag.model, idService);
}
},
"lTaPiyl5bEm+rCxSUTTlKA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Button"));
})(varBag.model, idService);
}
},
"Wu1o3V54jEOtPYyB7FvsqA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"u7yUgCsizkWPM_riBOVFVA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Bottom"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
