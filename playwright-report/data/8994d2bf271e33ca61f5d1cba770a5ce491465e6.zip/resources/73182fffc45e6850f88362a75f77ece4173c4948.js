class datePicker {
    constructor(id, options, events) {
        this.class = 'date-picker';
        this.element = document.getElementById(id);
        this.elementsClasses = {
            input: this.class.concat('__input')
        };
        this.elements = {
            label: this.element.firstElementChild.querySelector('label'),
            wrapper: this.element.firstElementChild.nextElementSibling,
            input: this.element.getElementsByClassName(this.elementsClasses.input)[0],
            calendar: {
                element: null,
                value: null,
                monthYear: null,
                navigation: {
                    previous: null,
                    next: null
                },
                daysList: null
            }
        };
        this.stateClasses = {
            open: this.class.concat('--open'),
            view: {
                days: this.class.concat('--view-days'),
                months: this.class.concat('--view-months'),
                years: this.class.concat('--view-years')
            },
            monthSelected: this.class.concat('__months-item--selected'),
            yearSelected: this.class.concat('__years-item--selected'),
            daySelected: this.class.concat('__day--selected'),
            dayCurrent: this.class.concat('__day--current'),
            dayDisabled: this.class.concat('__day--disabled'),
            empty: this.class.concat('--empty')
        };
        this.options = options;
        this.extendedOptions = {
            osNullDate: "1900-01-01",
            format: 'DD/MM/YYYY'
        };
        this.events = events;
        this.listeners = {
            _inputFocus: this._inputFocus.bind(this),
            _inputKeydown: this._inputKeydown.bind(this),
            _inputClick: this._inputClick.bind(this)
        };
        this.mobile = true;
        this._build();
    }
    _resetSelection() {
        this.selection = {
            date: {
                element: null,
                value: null
            },
            month: {
                element: null,
                value: null
            },
            year: {
                element: null,
                value: null
            }
        };
        this.preSelection = null;
    }
    _setRange(r, b = true) {
        switch (r) {
            case 'd':
                this.elements.input.setSelectionRange(0, 2);
                break;
            case 'm':
                this.elements.input.setSelectionRange(3, 5);
                break;
            case 'y':
                this.elements.input.setSelectionRange(6, 10);
                break;
        }
        this.elements.input.dpFirstSelection = b;
    }
    _inputClick(e) {
        e.preventDefault();
        if (!this.mobile) {
            let i = e.target;
            if (i.selectionStart === i.selectionEnd) {
                if (i.selectionStart < 3) {
                    this._setRange('d');
                } else {
                    if (i.selectionStart < 6) {
                        this._setRange('m');
                    } else {
                        this._setRange('y');
                    }
                }
            }
        } else {
            this._open();
        }
    }
    _inputKeydown(e) {
        let _checkInput = () => {
            let v = this.elements.input.value;
            if (/\d\d\/\d\d\/\d\d\d\d/.test(v)) {
                let d = dayjs().year(v.substring(6, 10)).month(Number(v.substring(3, 5)) - 1).date(v.substring(0, 2));
                if (d.isValid()) {
                    this._resetSelection();
                    this.view = d;
                    this.selection.date.value = d;
                    this.selection.month.value = d.month();
                    this.selection.year.value = d.year();
                    this.preSelection = d;
                    this._setValue();
                    this._updateDate();
                }
            }
        };
        let i = e.target,
            v = e.target.value,
            k = e.key;
        if (!(i.selectionStart === 6 && e.key === 'Tab' || e.ctrlKey)) {
            e.preventDefault();
        }
        if (i.selectionStart < 3) {
            if (Number(k) >= 0) {
                if (i.dpFirstSelection) {
                    if (k !== "0") {
                        i.value = "0" + k + v.substring(2, v.length);
                        k > 3 ? this._setRange('m') : this._setRange('d', false);
                    } else {
                        this._setRange('d', false);
                    }
                } else {
                    if (i.dPLastKey === "0") {
                        if (k > 0) {
                            i.value = "0" + k + v.substring(2, v.length);
                            this._setRange('m');
                        }
                    } else {
                        if (v[1] < 3 || (v[1] == 3 & k < 2)) {
                            i.value = v[1] + k + v.substring(2, v.length);
                            this._setRange('m');
                        }
                    }
                }
            } else {
                if (e.key === 'Backspace') {
                    if (i.selectionEnd !== v.length) {
                        i.value = this.extendedOptions.format.substring(0, 2) + v.substring(2, v.length);
                    } else {
                        i.value = this.extendedOptions.format;
                    }
                    this._setRange('d');
                } else {
                    if (e.key === 'ArrowRight' || e.key === 'Tab') {
                        this._setRange('m');
                    } else {
                        if (e.key === "ArrowUp") {
                            let d = Number(v.substring(0, 2));
                            if (d) {
                                d++;
                                if (d > 31) {
                                    d = "01";
                                } else {
                                    if (d < 10) {
                                        d = "0" + d;
                                    }
                                }
                            } else {
                                d = "01";
                            }
                            i.value = d + v.substring(2, v.length);
                            this._setRange('d');
                        } else {
                            if (e.key === "ArrowDown") {
                                let d = Number(v.substring(0, 2));
                                if (d) {
                                    d--;
                                    if (d < 1) {
                                        d = "31";
                                    } else {
                                        if (d < 10) {
                                            d = "0" + d;
                                        }
                                    }
                                } else {
                                    d = "01";
                                }
                                i.value = d + v.substring(2, v.length);
                                this._setRange('d');
                            }
                        }
                    }
                }
            }
        } else {
            if (i.selectionStart < 6) {
                if (Number(k) >= 0) {
                    if (i.dpFirstSelection) {
                        if (k !== '0') {
                            i.value = v.substring(0, 3) + "0" + k + v.substring(5, v.length);
                            k > 1 ? this._setRange('y') : this._setRange('m', false);
                        } else {
                            this._setRange('m', false);
                        }
                    } else {
                        if (v[4] === "1" && k < 3) {
                            i.value = v.substring(0, 3) + v[4] + k + v.substring(5, v.length);
                            this._setRange('y');
                        } else {
                            if (i.dPLastKey == "0" && k > 0) {
                                i.value = v.substring(0, 3) + "0" + k + v.substring(5, v.length);
                                this._setRange('y');
                            }
                        }
                    }
                } else {
                    if (e.key === 'Backspace') {
                        i.value = v.substring(0, 3) + this.extendedOptions.format.substring(3, 5) + v.substring(5, v.length);
                        this._setRange('m');
                    } else {
                        if (e.key === 'ArrowRight' || e.key === 'Tab') {
                            this._setRange('y');
                        } else {
                            if (e.key === 'ArrowLeft') {
                                this._setRange('d');
                            } else {
                                if (e.key === "ArrowUp") {
                                    let d = Number(v.substring(3, 5));
                                    if (d) {
                                        d++;
                                        if (d > 12) {
                                            d = "01";
                                        } else {
                                            if (d < 10) {
                                                d = "0" + d;
                                            }
                                        }
                                    } else {
                                        d = "01";
                                    }
                                    i.value = v.substring(0, 3) + d + v.substring(5, v.length);
                                    this._setRange('m');
                                } else {
                                    if (e.key === "ArrowDown") {
                                        let d = Number(v.substring(3, 5));
                                        if (d) {
                                            d--;
                                            if (d < 1) {
                                                d = "12";
                                            } else {
                                                if (d < 10) {
                                                    d = "0" + d;
                                                }
                                            }
                                        } else {
                                            d = "01";
                                        }
                                        i.value = v.substring(0, 3) + d + v.substring(5, v.length);
                                        this._setRange('m');
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (Number(k) >= 0) {
                    if (i.dpFirstSelection || i.dpYearCounter === 4) {
                        i.value = v.substring(0, 6) + "000" + k;
                        this._setRange('y', k == 0);
                        i.dpYearCounter = 1;
                    } else {
                        switch (i.dpYearCounter) {
                            case 1:
                                i.value = v.substring(0, 8) + v.substring(9, 10) + k;
                                break;
                            case 2:
                                i.value = v.substring(0, 7) + v.substring(8, 10) + k;
                                break;
                            case 3:
                                i.value = v.substring(0, 6) + v.substring(7, 10) + k;
                                break;
                        }
                        i.dpYearCounter++;
                        this._setRange('y', false);
                    }
                } else {
                    if (e.key === 'Backspace') {
                        i.value = v.substring(0, 6) + this.extendedOptions.format.substring(6, 10);
                        this._setRange('y');
                    } else {
                        if (e.key === 'ArrowLeft') {
                            this._setRange('m');
                        } else {
                            if (e.key === "ArrowUp") {
                                let d = Number(v.substring(6, 10));
                                if (d) {
                                    d++;
                                    if (d > 2099) {
                                        d = "1900";
                                    }
                                } else {
                                    d = dayjs().year();
                                }
                                i.value = v.substring(0, 6) + d;
                                this._setRange('y');
                            } else {
                                if (e.key === "ArrowDown") {
                                    let d = Number(v.substring(6, 10));
                                    if (d) {
                                        d--;
                                        if (d < 1900) {
                                            d = "2099";
                                        }
                                    } else {
                                        d = dayjs().year();
                                    }
                                    i.value = v.substring(0, 6) + d;
                                    this._setRange('y');
                                }
                            }
                        }
                    }
                }
            }
        }
        i.dPLastKey = k;
        _checkInput();
    }
    _inputFocus(e) {
        if (!this.mobile) {
            if (this.elements.input.value === "") {
                this.elements.input.value = this.extendedOptions.format;
            }
            this._setRange('d');
        } else {
            this._open();
        }
    }
    _setPos() {
        let pos = this.elements.input.getBoundingClientRect();
        this.elements.calendar.element.style.setProperty('--dp-top', pos.top + 'px');
        this.elements.calendar.element.style.setProperty('--dp-left', pos.left + 'px');
        this.elements.calendar.element.style.setProperty('--dp-height', pos.height + 'px');
    }
    _updateDate(t = true) {
        this.events.change(JSON.stringify({
            date: this.selection.date.value ? this.selection.date.value.toDate() : this.extendedOptions.osNullDate,
            formattedDate: this.selection.date.value ? this.selection.date.value.format(this.extendedOptions.format) : '',
            trigger: t
        }));
    }
    _setDate() {
        this._resetSelection();
        if (this.options.date !== this.extendedOptions.osNullDate) {
            this.selection.date.value = dayjs(this.options.date);
            this.selection.month.value = this.selection.date.value.month();
            this.selection.year.value = this.selection.date.value.year();
            this.view = this.selection.date.value;
            this.preSelection = this.selection.date.value;
        } else {
            this.view = dayjs(this.options.viewDate !== this.extendedOptions.osNullDate ? this.options.viewDate : new Date());
            if (this.view.isBefore(this.extendedOptions.minDate)) {
                this.view = this.extendedOptions.minDate;
            } else {
                if (this.view.isAfter(this.extendedOptions.maxDate)) {
                    this.view = this.extendedOptions.maxDate;
                }
            }
            this.selection.month.value = this.view.month();
            this.selection.year.value = this.view.year();
            this.preSelection = this.view;
        }
        this._updateDate(false);
    }
    _selectDate() {
        this.selection.month.value = this.preSelection.month();
        this.selection.year.value = this.preSelection.year();
        this.selection.date.value = this.preSelection;
        this._updateDate();
        this._close();
    }
    _setDays() {
        this.elements.calendar.daysList.innerHTML = '';
        for (let i = 0; i < this.view.date(1).day(); i++) {
            let de = document.createElement('div');
            de.classList.add(this.class.concat('__day'), this.class.concat('__day--empty'));
            this.elements.calendar.daysList.append(de);
        }
        for (let i = 1; i <= this.view.daysInMonth(); i++) {
            let db = document.createElement('button');
            db.classList.add(this.class.concat('__day'));
            db.innerText = i;
            db.dataset.day = i;
            let _d = dayjs().set('year', this.view.year()).set('month', this.view.month()).set('date', i),
                _cd = dayjs();
            if (_d.day() === 0 || _d.day() === 6) {
                db.classList.add(this.class.concat('__day--weekend'));
            }
            this.elements.calendar.daysList.append(db);
            if (this.preSelection) {
                if (_cd.diff(_d, 'day') === 0) {
                    db.classList.add(this.stateClasses.dayCurrent);
                }
                if (this.selection.date.value && i === this.preSelection.date() && this.preSelection.month() === this.view.month() && this.preSelection.year() === this.view.year()) {
                    this.selection.date.element = db;
                    this.selection.date.element.classList.add(this.stateClasses.daySelected);
                }
            }
            if (_d.isBefore(this.extendedOptions.minDate, 'day') || _d.isAfter(this.extendedOptions.maxDate, 'day')) {
                db.classList.add(this.stateClasses.dayDisabled);
            }
            db.addEventListener('click', (e) => {
                if (this.selection.date.element) {
                    this.selection.date.element.classList.remove(this.stateClasses.daySelected);
                }
                this.preSelection = dayjs().set('year', this.view.year()).set('month', this.view.month()).set('date', e.target.dataset.day);
                this.selection.date.element = e.target;
                this.selection.date.element.classList.add(this.stateClasses.daySelected);
                this._setValue();
                if (!this.mobile) {
                    this._selectDate();
                }
            });
        }
    }
    _setValue() {
        this.elements.calendar.value.innerText = this.preSelection.format('ddd, MMM D');
    }
    _setMonthYear() {
        this.elements.calendar.monthYear.innerText = this.view.format('MMMM') + ' ' + this.view.format('YYYY');
    }
    _create() {
        //Title
        let l = document.createElement('div');
        l.classList.add(this.class.concat('__header-title-label'));
        l.innerText = this.options.label.title;
        this.elements.calendar.value = document.createElement('div');
        this.elements.calendar.value.classList.add(this.class.concat('__header-title-value'));
        this._setValue();
        //Month year button
        this.elements.calendar.monthYear = document.createElement('button');
        this.elements.calendar.monthYear.classList.add(this.class.concat('__month-year'));
        this._setMonthYear();
        this.elements.calendar.monthYear.addEventListener('click', (e) => {
            let c = this.elements.calendar.element;
            e.stopPropagation();
            if (c.classList.contains(this.stateClasses.view.days)) {
                c.classList.remove(this.stateClasses.view.days);
                c.classList.add(this.stateClasses.view.years);
                if (this.selection.year.element) {
                    this.selection.year.element.scrollIntoView();
                } else {
                    let d = c.querySelector('.' + this.class.concat('__years-item') + `[data-year="${this.view.year()}"]`);
                    if (d) {
                        d.scrollIntoView();
                    }
                }
            } else {
                c.classList.remove(this.stateClasses.view.months, this.stateClasses.view.years);
                c.classList.add(this.stateClasses.view.days);
            }
        });
        this.elements.calendar.navigation.previous = document.createElement('button');
        this.elements.calendar.navigation.previous.classList.add(this.class.concat('__previous'));
        this.elements.calendar.navigation.previous.innerHTML = '<span class="material-symbols-outlined">chevron_left</span>';
        this.elements.calendar.navigation.previous.addEventListener('click', (e) => {
            e.stopPropagation();
            this.view = this.view.subtract(1, 'month').set('date', 1);
            this._setDays();
            this._setMonthYear();
            this.elements.calendar.element.classList.remove(this.stateClasses.view.years, this.stateClasses.view.months);
            this.elements.calendar.element.classList.add(this.stateClasses.view.days);
        });
        this.elements.calendar.navigation.next = document.createElement('button');
        this.elements.calendar.navigation.next.classList.add(this.class.concat('__next'));
        this.elements.calendar.navigation.next.innerHTML = '<span class="material-symbols-outlined">chevron_right</span>';
        this.elements.calendar.navigation.next.addEventListener('click', (e) => {
            e.stopPropagation();
            this.view = this.view.add(1, 'month');
            this._setDays();
            this._setMonthYear();
            this.elements.calendar.element.classList.remove(this.stateClasses.view.years, this.stateClasses.view.months);
            this.elements.calendar.element.classList.add(this.stateClasses.view.days);
        });
        //Header
        let h = document.createElement('div'),
            hc = document.createElement('div'),
            ht = document.createElement('div'),
            hl = document.createElement('div'),
            hr = document.createElement('div');
        h.classList.add(this.class.concat('__header'));
        hc.classList.add(this.class.concat('__header-controls'));
        ht.classList.add(this.class.concat('__header-title'));
        hl.classList.add(this.class.concat('__header-left'));
        hr.classList.add(this.class.concat('__header-right'));
        hl.append(this.elements.calendar.monthYear);
        hr.append(this.elements.calendar.navigation.previous);
        hr.append(this.elements.calendar.navigation.next);
        hc.append(hl);
        hc.append(hr);
        ht.append(l);
        ht.append(this.elements.calendar.value);
        h.append(ht);
        h.append(hc);
        //Content
        let c = document.createElement('div'),
            w = document.createElement('div'),
            ds = document.createElement('div'),
            m = document.createElement('div'),
            y = document.createElement('div');
        this.elements.calendar.daysList = document.createElement('div');
        c.classList.add(this.class.concat('__content'));
        w.classList.add(this.class.concat('__weekdays'));
        ds.classList.add(this.class.concat('__days'));
        this.elements.calendar.daysList.classList.add(this.class.concat('__days-list'));
        m.classList.add(this.class.concat('__months'));
        y.classList.add(this.class.concat('__years'));
        //Days
        let wds = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
        for (let i of wds) {
            let wd = document.createElement('div');
            wd.classList.add(this.class.concat('__weekdays-item'));
            wd.innerText = i;
            w.append(wd);
        }
        ds.append(w);
        this._setDays();
        ds.append(this.elements.calendar.daysList);
        c.append(ds);
        //Years
        for (let i = this.extendedOptions.minDate.year(); i <= this.extendedOptions.maxDate.year(); i++) {
            let yi = document.createElement('button');
            yi.classList.add(this.class.concat('__years-item'));
            yi.innerText = i;
            yi.dataset.year = i;
            if (i === this.selection.year.value) {
                if (this.selection.year.element) {
                    this.selection.year.element.classList.remove(this.stateClasses.yearSelected);
                }
                yi.classList.add(this.stateClasses.yearSelected);
                this.selection.year.element = yi;
                this.selection.year.value = i;
            }
            yi.addEventListener('click', (e) => {
                e.stopPropagation();
                if (this.selection.year.element) {
                    this.selection.year.element.classList.remove(this.stateClasses.yearSelected);
                }
                let el = this.elements.calendar.element;
                el.classList.remove(this.stateClasses.view.years);
                el.classList.add(this.stateClasses.view.months);
                this.selection.year.element = e.target;
                this.selection.year.value = e.target.dataset.year;
                this.selection.year.element.classList.add(this.stateClasses.yearSelected);
                this.view = this.view.year(this.selection.year.value);
                this._setMonthYear();
                if (e.target.nextElementSibling == null) {
                    this.extendedOptions.maxDate.set('year', this.extendedOptions.minDate.year() + 100);
                } else {
                    if (e.target.previousElementSibling == null) {
                        this.extendedOptions.minDate.set('year', this.extendedOptions.minDate.year() - 100);
                    }
                }
            });
            y.append(yi);
        }
        c.append(y);
        //Months
        for (let i = 0; i < 12; i++) {
            let mi = document.createElement('button');
            mi.classList.add(this.class.concat('__months-item'));
            mi.innerText = dayjs().month(i).format('MMM');
            mi.dataset.month = i;
            if (i === this.selection.month.value) {
                if (this.selection.month.element) {
                    this.selection.month.element.classList.remove(this.stateClasses.monthSelected);
                }
                mi.classList.add(this.stateClasses.monthSelected);
                this.selection.month.element = mi;
                this.selection.month.value = i;
            }
            mi.addEventListener('click', (e) => {
                e.stopPropagation();
                if (this.selection.month.element) {
                    this.selection.month.element.classList.remove(this.stateClasses.monthSelected);
                }
                let el = this.elements.calendar.element;
                el.classList.remove(this.stateClasses.view.months);
                el.classList.add(this.stateClasses.view.days);
                this.selection.month.element = e.target;
                this.selection.month.value = e.target.dataset.month;
                this.selection.month.element.classList.add(this.stateClasses.monthSelected);
                this.view = this.view.month(this.selection.month.value);
                this._setMonthYear();
                this._setDays();
            });
            m.append(mi);
        }
        c.append(m);
        //Footer
        let f = document.createElement('div'),
            fc = document.createElement('button'),
            fok = document.createElement('button');
        f.classList.add(this.class.concat('__footer'));
        fc.classList.add(this.class.concat('__footer-cancel'));
        fok.classList.add(this.class.concat('__footer-ok'));
        fc.setAttribute('type', 'button');
        fok.setAttribute('type', 'button');
        fc.innerText = this.options.label.cancel;
        fok.innerText = this.options.label.ok;
        fc.addEventListener('click', (e) => {
            this._close();
        });
        fok.addEventListener('click', (e) => {
            this._selectDate();
        });
        f.append(fc);
        f.append(fok);
        //Element
        let o = document.createElement('div'),
            ma = document.createElement('div');
        o.classList.add(this.class.concat('__overlay'));
        ma.classList.add(this.class.concat('__main'));
        o.addEventListener('click', (e) => {
            this._close();
        })
        this.elements.calendar.element = document.createElement('div');
        this.elements.calendar.element.classList.add(this.class.concat('__calendar'), this.stateClasses.view.days);
        this.elements.calendar.element.classList.add(this.class.concat('__calendar--').concat(this.mobile ? 'mobile' : 'desktop'));
        ma.append(h);
        ma.append(c);
        ma.append(f);
        this.elements.calendar.element.append(ma);
        this.elements.calendar.element.append(o);
        this._setPos();
        document.body.append(this.elements.calendar.element);
    }
    _setExtendedOptions() {
        this.extendedOptions.minDate = this.options.minDate !== this.extendedOptions.osNullDate ? dayjs(new Date(this.options.minDate)) : dayjs().set('date', 1).set('month', 0).set('year', 1900);
        this.extendedOptions.maxDate = this.options.maxDate !== this.extendedOptions.osNullDate ? dayjs(new Date(this.options.maxDate)) : dayjs().set('date', 1).set('month', 0).set('year', 2099);
    }
    _setDefaultClasses() {
        this.mobile ? this.element.classList.add(this.class.concat('--mobile')) : this.element.classList.add(this.class.concat('--desktop'));
    }
    _close() {
        this.elements.calendar.element.remove();
        this.element.classList.remove(this.stateClasses.open);
        this._setDate();
    }
    _open() {
        if (!this.element.classList.contains(this.stateClasses.open)) {
            this._create();
            this.element.classList.add(this.stateClasses.open);
            if (this.selection.date.element) {
                this.selection.date.element.focus();
            }
        }

    }
    _build() {
        this.elements.input.placeholder = this.extendedOptions.format;
        this.elements.input.autocomplete = "off";
        this.elements.input.spellcheck = false;
        if (this.extendedOptions.format.length) {
            this.elements.input.maxLength = this.extendedOptions.format.length;
        }
        if (this.elements.label) {
            this.elements.label.setAttribute('for', this.elements.input.id);
            if (this.options.mandatory) {
                this.elements.label.classList.add('mandatory');
            }
        }
        this.elements.input.addEventListener('focus', this.listeners._inputFocus);
        if (this.mobile) {
            this.element.classList.add(this.class.concat('--mobile'));
            this.elements.wrapper.addEventListener('click', this.listeners._inputClick);
        } else {
            this.element.classList.add(this.class.concat('--desktop'));
            this.elements.input.addEventListener('keydown', this.listeners._inputKeydown);
            this.elements.input.addEventListener('click', this.listeners._inputClick);
        }
        if (this.options.testId) {
            if (this.elements.label) {
                this.elements.label.setAttribute('data-testid', this.options.testId + 'Label');
            }
            if (this.elements.input) {
                this.elements.input.setAttribute('data-testid', this.options.testId + 'Input');
            }
        }
        this._setExtendedOptions();
        this._setDate();
    }
    render() {
        this._setDefaultClasses();
    }
    iconClick() {
        this.element.classList.contains(this.stateClasses.open) ? this._close() : this._open();
    }
    parametersChanged(options) {
        this.options = options;
        this._setExtendedOptions();
        this._setDate();
    }
}