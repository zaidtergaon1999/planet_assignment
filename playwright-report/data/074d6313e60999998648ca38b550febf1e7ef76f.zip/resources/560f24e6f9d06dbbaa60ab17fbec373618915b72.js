class flexItem {
  constructor(id, options) {
    this.element = document.getElementById(id);
    this.options = options;
    this._build();
  }
  _setCSSVariables() {
    this.options.flex ? this.element.style.setProperty('--flex', this.options.flex) : this.element.style.removeProperty('--flex');
    this.options.order ? this.element.style.setProperty('--order', this.options.order) : this.element.style.removeProperty('--order');
  }
  _build() {
    this._setCSSVariables();
  }
  parametersChanged(options) {
    this.options = options;
    this._setCSSVariables();
  }
}