define("ShopperPortalEU_Forms_IS.referencesHealth$Auth_Europe", [], function () {
// Reference to producer 'Auth_Europe' is OK.
});
define("ShopperPortalEU_Forms_IS.referencesHealth$ServiceCenter", [], function () {
// Reference to producer 'ServiceCenter' is OK.
});
define("ShopperPortalEU_Forms_IS.referencesHealth$ShopperPortalEU_CS", [], function () {
// Reference to producer 'ShopperPortalEU_CS' is OK.
});
define("ShopperPortalEU_Forms_IS.referencesHealth$ShopperPortalEU_Shopper_IS", [], function () {
// Reference to producer 'ShopperPortalEU_Shopper_IS' is OK.
});
define("ShopperPortalEU_Forms_IS.referencesHealth$ShopperPortalEU_UI_Components", [], function () {
// Reference to producer 'ShopperPortalEU_UI_Components' is OK.
});
define("ShopperPortalEU_Forms_IS.referencesHealth$Text", [], function () {
// Reference to producer 'Text' is OK.
});
define("ShopperPortalEU_Forms_IS.referencesHealth$Users", [], function () {
// Reference to producer 'Users' is OK.
});
define("ShopperPortalEU_Forms_IS.referencesHealth", [], function () {
});
