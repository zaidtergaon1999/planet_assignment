define("ShopperPortalEU.Common.NotFound.mvc$model", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.model", "Custom404Plugin.controller", "ShopperPortalEU.Layouts.Layout.mvc$model", "ShopperPortalEU.LayoutsComponents.ApplicationHeader.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.FullHeightContent.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomIcon.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomLink.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomLinkItem.mvc$model", "ShopperPortalEU_UI_Theme.model$LayoutOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$LayoutHeaderOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU.model$ApplicationHeaderRec", "ShopperPortalEU_UI_Components.model$FullHeightContentOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$FullHeightContentTopOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentBottomOptionsRec", "ShopperPortalEU_UI_Components.model$CustomIconOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsIconRec", "Custom404Plugin.controller$NotFoundOnDestroy", "ShopperPortalEU.referencesHealth$Custom404Plugin"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ComponentsModel, Custom404PluginController, ShopperPortalEU_Layouts_Layout_mvcModel, ShopperPortalEU_LayoutsComponents_ApplicationHeader_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomIcon_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLink_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLinkItem_mvcModel) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Model._hasValidationWidgetsValue = undefined;
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
if((Model._hasValidationWidgetsValue === undefined)) {
Model._hasValidationWidgetsValue = (((((ShopperPortalEU_Layouts_Layout_mvcModel.hasValidationWidgets || ShopperPortalEU_LayoutsComponents_ApplicationHeader_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomIcon_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLink_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLinkItem_mvcModel.hasValidationWidgets);
}

return Model._hasValidationWidgetsValue;
}
});

Model.prototype.setInputs = function (inputs) {
};
return Model;
})(OS.Model.VariablelessViewModel);
return new OS.Model.ModelFactory(Model, "Common.NotFound");
});
define("ShopperPortalEU.Common.NotFound.mvc$view", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.model", "Custom404Plugin.controller", "react", "OutSystems/ReactView/Main", "ShopperPortalEU.Common.NotFound.mvc$model", "ShopperPortalEU.Common.NotFound.mvc$controller", "ShopperPortalEU.clientVariables", "ShopperPortalEU.Layouts.Layout.mvc$view", "OutSystems/ReactWidgets/Main", "ShopperPortalEU.LayoutsComponents.ApplicationHeader.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.FullHeightContent.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomIcon.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomLink.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomLinkItem.mvc$view", "ShopperPortalEU_UI_Theme.model$LayoutOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$LayoutHeaderOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU.model$ApplicationHeaderRec", "ShopperPortalEU_UI_Components.model$FullHeightContentOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$FullHeightContentTopOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentBottomOptionsRec", "ShopperPortalEU_UI_Components.model$CustomIconOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsIconRec", "Custom404Plugin.controller$NotFoundOnDestroy", "ShopperPortalEU.referencesHealth$Custom404Plugin"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ComponentsModel, Custom404PluginController, React, OSView, ShopperPortalEU_Common_NotFound_mvc_model, ShopperPortalEU_Common_NotFound_mvc_controller, ShopperPortalEUClientVariables, ShopperPortalEU_Layouts_Layout_mvc_view, OSWidgets, ShopperPortalEU_LayoutsComponents_ApplicationHeader_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomIcon_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLink_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLinkItem_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            var thisIsInstanceOfSuper = this instanceof _super;
            if (thisIsInstanceOfSuper == false) {
                return;
            }

            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "Common.NotFound";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css", "css/ShopperPortalEU_UI_Theme.ShopperPortalEUUITheme.css", "css/ShopperPortalEU.ShopperPortalEU.css", "css/ShopperPortalEU_UI_Theme.ShopperPortalEUUITheme.extra.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [ShopperPortalEU_Layouts_Layout_mvc_view, ShopperPortalEU_LayoutsComponents_ApplicationHeader_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomIcon_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLink_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLinkItem_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return ShopperPortalEU_Common_NotFound_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return ShopperPortalEU_Common_NotFound_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "Shopper Portal EU - Not Found";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(ShopperPortalEU_Layouts_Layout_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("7Fi+1z+XMk2GkdvWPbvF6Q.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ThemeModel.LayoutOptionsRec();
rec.headerAttr = function () {
var rec = new ShopperPortalEU_UI_ThemeModel.LayoutHeaderOptionsRec();
rec.isCenteredAttr = true;
return rec;
}();
return rec;
}();
}),
Auth: model.getCachedValue(idService.getId("7Fi+1z+XMk2GkdvWPbvF6Q.Auth"), function () {
return function () {
var rec = new ShopperPortalEUModel.LayoutAuthenticationRec();
rec.isToUseAuthAttr = false;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "0",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
headerLeft: PlaceholderContent.Empty,
headerCenter: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_LayoutsComponents_ApplicationHeader_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("rAez1Sr820+Okzs_Mw3YhA.Options"), function () {
return function () {
var rec = new ShopperPortalEUModel.ApplicationHeaderRec();
rec.isLargerLogoAttr = true;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "1",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}),
headerRight: PlaceholderContent.Empty,
headerBottom: PlaceholderContent.Empty,
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvc_view, {
inputs: {
ExtendedClass: "text-align-center",
Options: model.getCachedValue(idService.getId("6zRIf3kAy0yTOw4emAyKyQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FullHeightContentOptionsRec();
rec.topAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FullHeightContentTopOptionsRec();
rec.verticalAlignmentAttr = ShopperPortalEUModel.staticEntities.fullHeightContentAlignment.center;
rec.horizontalAlignmentAttr = ShopperPortalEUModel.staticEntities.fullHeightContentAlignment.center;
return rec;
}();
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.none;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "2",
alias: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
top: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomIcon_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("aNi0MIwlgUeIk46MTLRHJA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomIconOptionsRec();
rec.nameAttr = "error";
rec.sizeAttr = ShopperPortalEUModel.staticEntities.customIconSize.large;
rec.colorAttr = "var(--color-error-70)";
rec.isFilledAttr = true;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "3",
alias: "4"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-top-05  text-align-center",
visible: true,
_idProps: {
service: idService,
uuid: "4"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "heading5 text-primary-black",
visible: true,
_idProps: {
service: idService,
uuid: "5"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
value: model.getCachedValue(idService.getId("4ZaeXtSdekGVtZhB7tqVIg.Value"), function () {
return ((((ShopperPortalEUClientVariables.getErrorMessage()) !== (""))) ? (ShopperPortalEUClientVariables.getErrorMessage()) : ("Sorry, this page is not available"));
}, function () {
return ShopperPortalEUClientVariables.getErrorMessage();
}),
_idProps: {
service: idService,
uuid: "6"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-top-02",
visible: true,
_idProps: {
service: idService,
uuid: "7"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
value: "Please try again or ",
_idProps: {
service: idService,
uuid: "8"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLink_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "9",
alias: "5"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
link: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Link, {
enabled: true,
extendedProperties: {
target: "_blank"
},
transition: OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default),
url: OS.Navigation.generateScreenURL("https://www.planetpayment.com/contact-us", {}),
visible: true,
_idProps: {
service: idService,
uuid: "10"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLinkItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "11",
alias: "6"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "contact Customer Support",
_idProps: {
service: idService,
uuid: "12"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
}), React.createElement(OSWidgets.Expression, {
value: " for assistance.",
_idProps: {
service: idService,
uuid: "13"
},
_widgetRecordProvider: widgetsRecordProvider
})))];
}),
bottom: PlaceholderContent.Empty
},
_dependencies: [asPrimitiveValue(ShopperPortalEUClientVariables.getErrorMessage())]
})];
}),
bottom: PlaceholderContent.Empty
},
_dependencies: [asPrimitiveValue(ShopperPortalEUClientVariables.getErrorMessage())]
}));
        };
        return View;
    })(OSView.BaseView.BaseWebScreen);
	
    return View;
});
define("ShopperPortalEU.Common.NotFound.mvc$controller", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.model", "Custom404Plugin.controller", "ShopperPortalEU.languageResources", "ShopperPortalEU.clientVariables", "ShopperPortalEU.Common.NotFound.mvc$debugger", "ShopperPortalEU.Common.controller", "ShopperPortalEU_UI_Theme.model$LayoutOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$LayoutHeaderOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU.model$ApplicationHeaderRec", "ShopperPortalEU_UI_Components.model$FullHeightContentOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$FullHeightContentTopOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentBottomOptionsRec", "ShopperPortalEU_UI_Components.model$CustomIconOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsIconRec", "Custom404Plugin.controller$NotFoundOnDestroy", "ShopperPortalEU.referencesHealth$Custom404Plugin"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ComponentsModel, Custom404PluginController, ShopperPortalEULanguageResources, ShopperPortalEUClientVariables, ShopperPortalEU_Common_NotFound_mvc_Debugger, ShopperPortalEU_CommonController) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = true;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._onDestroy$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnDestroy");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:6aJ_WOt70kiUfaMUfZqqww:/NRWebFlows.B4kRGvrnOEmQonA8ir4Pyg/NodesShownInESpaceTree.QUyXSm6ndEqSeqAMT4uuxQ/ClientActions.6aJ_WOt70kiUfaMUfZqqww:S_7t5cdKtwh5boFbM+eevw", "ShopperPortalEU", "OnDestroy", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:U4SqKnVmx0uTcrWsmcYZAQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:OfmDyc23rEecn90UJPSy6A", callContext.id);
// Execute Action: NotFoundOnDestroy
Custom404PluginController.default.notFoundOnDestroy$Action(callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:+0Qh_psdy0e9HeQHpmfUIQ", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:6aJ_WOt70kiUfaMUfZqqww", callContext.id);
}

};

Controller.prototype.onDestroy$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onDestroy$Action, callContext);

};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:B4kRGvrnOEmQonA8ir4Pyg:/NRWebFlows.B4kRGvrnOEmQonA8ir4Pyg:SzbSE76vSJUYiPdzujZAFw", "ShopperPortalEU", "Common", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:QUyXSm6ndEqSeqAMT4uuxQ:/NRWebFlows.B4kRGvrnOEmQonA8ir4Pyg/NodesShownInESpaceTree.QUyXSm6ndEqSeqAMT4uuxQ:TD+g6xOOdz7Q7dHDabAFCg", "ShopperPortalEU", "NotFound", "NRNodes.WebScreen", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:QUyXSm6ndEqSeqAMT4uuxQ", callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:B4kRGvrnOEmQonA8ir4Pyg", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Common/NotFound On Destroy");
return controller.onDestroy$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return ShopperPortalEU_CommonController.default.handleError(ex, this.callContext());
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return ShopperPortalEUController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, ShopperPortalEULanguageResources);
});

define("ShopperPortalEU.Common.NotFound.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"VhYUy+V4yUCrcIXydXD4hQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderLeft"));
})(varBag.model, idService);
}
},
"RUbehl7mxUaDarhlQ0CBKA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderCenter"));
})(varBag.model, idService);
}
},
"VwEdh8OLsU61szc05+6_gA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderRight"));
})(varBag.model, idService);
}
},
"tlQItEQ+sEGWdGkVIr1HYw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderBottom"));
})(varBag.model, idService);
}
},
"Jjqp6N5UAk+Gp30vlbHDhA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"G4to4pR8gUqWnLK4FnebuQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Top"));
})(varBag.model, idService);
}
},
"CxO6XIIct0yGJ4bP4SKYQg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Link"));
})(varBag.model, idService);
}
},
"ZTrlGyBCLUi3ZxktyhSsWQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"+qn05SLEc02latc5viyWjg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Bottom"));
})(varBag.model, idService);
}
},
"J2ZbnEbr4UuzzWEPwZhhpw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Bottom"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
