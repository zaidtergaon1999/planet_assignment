class customBarcode {
  constructor(id, options) {
    this.class = 'custom-barcode';
    this.element = document.getElementById(id);
    this.elementsClasses = {
      barcode: this.class.concat('__barcode')
    };
    this.elements = {
      barcode: null
    };
    this.options = options;
    this._build();
  }
  _generate() {
    JsBarcode(this.elements.barcode, this.options.data, {
      displayValue: false,
      width: 6,
      height: 120
    });
  }
  _build() {
    this.elements.barcode = document.createElement('img');
    this.elements.barcode.classList.add(this.elementsClasses.barcode);
    if (this.options.testId) {
      this.elements.barcode.setAttribute('data-testid', this.options.testId);
    }
    this.element.prepend(this.elements.barcode);
    this._generate();
  }
  parametersChanged(options) {
    this.options = options;
    this._generate();
  }

}