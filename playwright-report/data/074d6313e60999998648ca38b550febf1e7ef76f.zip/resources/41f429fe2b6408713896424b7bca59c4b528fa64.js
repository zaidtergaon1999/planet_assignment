define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomDropdownList.mvc$model", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomDropdownListOptionsRec", "ShopperPortalEU_UI_Components.model$CustomIconOptionsRec", "ShopperPortalEU_UI_Components.model$CustomDropdownListValueOptionsRec"], function (OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("SearchVar", "searchVarVar", "SearchVar", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, false), 
this.attr("Obj", "objVar", "Obj", true, false, OS.DataTypes.DataTypes.Object, function () {
return null;
}, false), 
this.attr("IsVisible", "isVisibleVar", "IsVisible", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("Options", "optionsIn", "Options", true, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomDropdownListOptionsRec());
}, false, ShopperPortalEU_UI_ComponentsModel.CustomDropdownListOptionsRec), 
this.attr("_optionsInDataFetchStatus", "_optionsInDataFetchStatus", "_optionsInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("ExtendedClass", "extendedClassIn", "ExtendedClass", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, false), 
this.attr("_extendedClassInDataFetchStatus", "_extendedClassInDataFetchStatus", "_extendedClassInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {
Input_Search: OS.Model.ValidationWidgetRecord
};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return true;
}
});

Model.prototype.setInputs = function (inputs) {
if("Options" in inputs) {
this.variables.optionsIn = inputs.Options;
if("_optionsInDataFetchStatus" in inputs) {
this.variables._optionsInDataFetchStatus = inputs._optionsInDataFetchStatus;
}

}

if("ExtendedClass" in inputs) {
this.variables.extendedClassIn = inputs.ExtendedClass;
if("_extendedClassInDataFetchStatus" in inputs) {
this.variables._extendedClassInDataFetchStatus = inputs._extendedClassInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "ShopperPortalEUUIComponents.CustomDropdownList");
});
define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomDropdownList.mvc$view", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.controller", "react", "OutSystems/ReactView/Main", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomDropdownList.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomDropdownList.mvc$controller", "OutSystems/ReactWidgets/Main", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomIcon.mvc$view", "ShopperPortalEU_UI_Components.model$CustomDropdownListOptionsRec", "ShopperPortalEU_UI_Components.model$CustomIconOptionsRec", "ShopperPortalEU_UI_Components.model$CustomDropdownListValueOptionsRec"], function (OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ComponentsController, React, OSView, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomDropdownList_mvc_model, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomDropdownList_mvc_controller, OSWidgets, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomIcon_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            var thisIsInstanceOfSuper = this instanceof _super;
            if (thisIsInstanceOfSuper == false) {
                return;
            }

            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "ShopperPortalEUUIComponents.CustomDropdownList";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css"];
        };
        View.getJsDependencies = function() {
            return ["scripts/ShopperPortalEU_UI_Components.customDropdownList.js"];
        };
        View.getBlocks = function() {
            return [ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomIcon_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomDropdownList_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomDropdownList_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
"data-value": model.variables.optionsIn.selectedAttr,
"data-testid": model.variables.optionsIn.testIdAttr
},
style: model.getCachedValue(idService.getId("Element.Style"), function () {
return (((("custom-dropdown-list" + ((!(model.variables.optionsIn.isDisabledAttr)) ? ("") : (" custom-dropdown-list--disabled"))) + ((!(model.variables.optionsIn.isMandatoryAttr)) ? ("") : (" custom-dropdown-list--mandatory"))) + (((model.variables.optionsIn.validationAttr.stateAttr === OS.BuiltinFunctions.nullTextIdentifier())) ? ("") : ((" custom-dropdown-list--" + model.variables.optionsIn.validationAttr.stateAttr)))) + (((model.variables.extendedClassIn === "")) ? ("") : ((" " + model.variables.extendedClassIn))));
}, function () {
return model.variables.optionsIn.isDisabledAttr;
}, function () {
return model.variables.optionsIn.isMandatoryAttr;
}, function () {
return model.variables.optionsIn.validationAttr.stateAttr;
}, function () {
return model.variables.extendedClassIn;
}),
visible: true,
_idProps: {
service: idService,
name: "Element"
},
_widgetRecordProvider: widgetsRecordProvider,
style_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._optionsInDataFetchStatus, model.variables._extendedClassInDataFetchStatus)
}, React.createElement(OSWidgets.Placeholder, {
align: /*Default*/ 0,
content: _this.props.placeholders.label,
extendedEvents: {
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ShopperPortalEUUIComponents/CustomDropdownList/Label onclick");
controller.toggle$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
style: "custom-dropdown-list__label ph",
_idProps: {
service: idService,
name: "Label"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "custom-dropdown-list__content",
visible: true,
_idProps: {
service: idService,
uuid: "2"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedEvents: {
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ShopperPortalEUUIComponents/CustomDropdownList/Container onclick");
controller.toggle$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
extendedProperties: {
tabIndex: "0"
},
style: "custom-dropdown-list__value",
visible: true,
_idProps: {
service: idService,
uuid: "3"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Placeholder, {
align: /*Default*/ 0,
content: _this.props.placeholders.selected,
style: "custom-dropdown-list__current-value",
_idProps: {
service: idService,
name: "Selected"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "custom-dropdown-list__toggle-icon",
visible: true,
_idProps: {
service: idService,
uuid: "5"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomIcon_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("Q9QETEHT3UGPxRQLn0fp+A.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomIconOptionsRec();
rec.nameAttr = "expand_more";
rec.sizeAttr = ShopperPortalEU_UI_ComponentsModel.staticEntities.customIconSize.small;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "6",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}))), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "custom-dropdown-list__dropdown",
visible: model.variables.isVisibleVar,
_idProps: {
service: idService,
uuid: "7"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "custom-dropdown-list__header",
visible: true,
_idProps: {
service: idService,
uuid: "8"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "custom-dropdown-list__header-title",
visible: true,
_idProps: {
service: idService,
uuid: "9"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": model.getCachedValue(idService.getId("5JqbI3vNU02_TrIAYTybdw.data-testid"), function () {
return ((((model.variables.optionsIn.testIdAttr) !== (""))) ? ((model.variables.optionsIn.testIdAttr + "OpenedLabel")) : (""));
}, function () {
return model.variables.optionsIn.testIdAttr;
})
},
value: model.variables.optionsIn.labelAttr,
_idProps: {
service: idService,
uuid: "10"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._optionsInDataFetchStatus)
})), React.createElement(OSWidgets.Button, {
enabled: true,
extendedProperties: {
"data-testid": model.getCachedValue(idService.getId("alMElfNnuEmOkwTKyDYWwQ.data-testid"), function () {
return ((((model.variables.optionsIn.testIdAttr) !== (""))) ? ((model.variables.optionsIn.testIdAttr + "Close")) : (""));
}, function () {
return model.variables.optionsIn.testIdAttr;
})
},
isDefault: false,
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ShopperPortalEUUIComponents/CustomDropdownList/Button OnClick");
controller.toggle$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "custom-dropdown-list__close",
visible: true,
_idProps: {
service: idService,
uuid: "11"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomIcon_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("JppTBEsxz0S7rMJiDqlVXg.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomIconOptionsRec();
rec.nameAttr = "close";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "12",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})), $if((model.variables.optionsIn.descriptionAttr === ""), false, this, function () {
return [];
}, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "custom-dropdown-list__header-description",
visible: true,
_idProps: {
service: idService,
uuid: "13"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": model.getCachedValue(idService.getId("RUcgiDk8JkOIh0aqZnU_5w.data-testid"), function () {
return ((((model.variables.optionsIn.testIdAttr) !== (""))) ? ((model.variables.optionsIn.testIdAttr + "OpenedDescription")) : (""));
}, function () {
return model.variables.optionsIn.testIdAttr;
})
},
value: model.variables.optionsIn.descriptionAttr,
_idProps: {
service: idService,
uuid: "14"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._optionsInDataFetchStatus)
}))];
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "custom-dropdown-list__search",
visible: true,
_idProps: {
service: idService,
uuid: "15"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Input, {
_validationProps: {
validationService: validationService
},
enabled: true,
extendedEvents: {
"componentDidMount": function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ShopperPortalEUUIComponents/CustomDropdownList/Input_Search componentDidMount");
controller.dropdownRendered$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
extendedProperties: {
spellCheck: "false",
"data-testid": model.getCachedValue(idService.getId("Input_Search.data-testid"), function () {
return (((model.variables.optionsIn.testIdAttr === "")) ? ("") : ((model.variables.optionsIn.testIdAttr + "SearchInput")));
}, function () {
return model.variables.optionsIn.testIdAttr;
})
},
gridProperties: {
classes: "OSFillParent"
},
inputType: /*Search*/ 8,
mandatory: false,
maxLength: 50,
onChange: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ShopperPortalEUUIComponents/CustomDropdownList/Input_Search OnChange");
controller.search$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
prompt: model.variables.optionsIn.searchAttr.placeholderAttr,
style: "form-control",
variable: model.createVariable(OS.DataTypes.DataTypes.Text, model.variables.searchVarVar, function (value) {
model.variables.searchVarVar = value;
}),
_idProps: {
service: idService,
name: "Input_Search"
},
_widgetRecordProvider: widgetsRecordProvider,
prompt_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._optionsInDataFetchStatus)
})), React.createElement(OSWidgets.Placeholder, {
align: /*Default*/ 0,
content: _this.props.placeholders.list,
style: "custom-dropdown-list__list",
_idProps: {
service: idService,
name: "List"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "custom-dropdown-list__empty-message",
visible: true,
_idProps: {
service: idService,
uuid: "18"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "custom-dropdown-list__empty-message-title",
visible: true,
_idProps: {
service: idService,
uuid: "19"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": model.getCachedValue(idService.getId("xvQno1b9wUK1TyN5fadWAQ.data-testid"), function () {
return (((model.variables.optionsIn.testIdAttr === "")) ? ("") : ((model.variables.optionsIn.testIdAttr + "EmptyMessageTitle")));
}, function () {
return model.variables.optionsIn.testIdAttr;
})
},
value: model.variables.optionsIn.searchAttr.emptyMessageAttr,
_idProps: {
service: idService,
uuid: "20"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._optionsInDataFetchStatus)
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "custom-dropdown-list__empty-message-description",
visible: true,
_idProps: {
service: idService,
uuid: "21"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": model.getCachedValue(idService.getId("6byGhFjPA0S8ZOu6Z1YteQ.data-testid"), function () {
return (((model.variables.optionsIn.testIdAttr === "")) ? ("") : ((model.variables.optionsIn.testIdAttr + "EmptyMessageDescription")));
}, function () {
return model.variables.optionsIn.testIdAttr;
})
},
value: model.variables.optionsIn.searchAttr.emptyDescriptionAttr,
_idProps: {
service: idService,
uuid: "22"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._optionsInDataFetchStatus)
}))))), $if((model.variables.optionsIn.validationAttr.stateAttr === OS.BuiltinFunctions.nullTextIdentifier()), false, this, function () {
return [];
}, function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": model.getCachedValue(idService.getId("F4nBPcgCJEeeBQkBcWGYzg.data-testid"), function () {
return (((model.variables.optionsIn.testIdAttr === "")) ? ("") : ((model.variables.optionsIn.testIdAttr + "ValidationMessage")));
}, function () {
return model.variables.optionsIn.testIdAttr;
})
},
style: "validation-message",
value: model.variables.optionsIn.validationAttr.messageAttr,
_idProps: {
service: idService,
uuid: "23"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._optionsInDataFetchStatus)
})];
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "custom-dropdown-list__overlay",
visible: true,
_idProps: {
service: idService,
uuid: "24"
},
_widgetRecordProvider: widgetsRecordProvider
})));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomDropdownList.mvc$controller", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.controller", "ShopperPortalEU_UI_Components.languageResources", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomDropdownList.mvc$debugger", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomDropdownList.mvc$controller.DropdownRendered.DropdownRenderedJS", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomDropdownList.mvc$controller.OnRender.RenderJS", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomDropdownList.mvc$controller.OnParametersChanged.ParametersChangedJS", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomDropdownList.mvc$controller.Toggle.ToggleJS", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomDropdownList.mvc$controller.Search.SearchJS", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomDropdownList.mvc$controller.OnReady.InitializeJS", "ShopperPortalEU_UI_Components.model$CustomDropdownListOptionsRec", "ShopperPortalEU_UI_Components.model$CustomIconOptionsRec", "ShopperPortalEU_UI_Components.model$CustomDropdownListValueOptionsRec"], function (OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ComponentsController, ShopperPortalEU_UI_ComponentsLanguageResources, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomDropdownList_mvc_Debugger, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomDropdownList_mvc_controller_DropdownRendered_DropdownRenderedJS, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomDropdownList_mvc_controller_OnRender_RenderJS, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomDropdownList_mvc_controller_OnParametersChanged_ParametersChangedJS, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomDropdownList_mvc_controller_Toggle_ToggleJS, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomDropdownList_mvc_controller_Search_SearchJS, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomDropdownList_mvc_controller_OnReady_InitializeJS) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {
change$Action: function (currentValueIn) {
currentValueIn = (currentValueIn === undefined) ? "" : currentValueIn;
return controller.executeActionInsideJSNode(controller._change$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(currentValueIn, OS.DataTypes.DataTypes.Text)), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "Change");
},
toggle$Action: function () {
return controller.executeActionInsideJSNode(controller._toggle$Action.bind(controller), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "Toggle");
},
close$Action: function () {
return controller.executeActionInsideJSNode(controller._close$Action.bind(controller), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "Close");
}
};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = false;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._dropdownRendered$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("DropdownRendered");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:63QXEObdQ06ASD_AksVflQ:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.+STfuEk74kGPzVw1lCHt8g/ClientActions.63QXEObdQ06ASD_AksVflQ:jV6TsuxP831jbkr9Bj6JtQ", "ShopperPortalEU_UI_Components", "DropdownRendered", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:Km09WNscU0Wz9eiI_8wNhg", callContext.id);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:HACBHz2nAEOIvzbsljeB3g", callContext.id);
// DropdownRendered method.
controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomDropdownList_mvc_controller_DropdownRendered_DropdownRenderedJS, "DropdownRendered", "DropdownRendered", {
Obj: OS.DataConversion.JSNodeParamConverter.to(model.variables.objVar, OS.DataTypes.DataTypes.Object)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:BvZ42cuDsU6lRWLo5VK9zg", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:63QXEObdQ06ASD_AksVflQ", callContext.id);
}

};
Controller.prototype._onRender$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnRender");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:OPb9SnmM502KoCr5Ddpf5g:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.+STfuEk74kGPzVw1lCHt8g/ClientActions.OPb9SnmM502KoCr5Ddpf5g:vQ4m6W64m0RYUPhFA9Xz6Q", "ShopperPortalEU_UI_Components", "OnRender", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:QeXODrlUj0G+LmAywt1KhA", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:_N9zLs4MGEqQqji5bjCqfQ", callContext.id) && ((model.variables.objVar) !== (OS.BuiltinFunctions.nullObject())))) {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:WXehsBM520qDbJk7jIkivw", callContext.id);
// Component render method.
controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomDropdownList_mvc_controller_OnRender_RenderJS, "Render", "OnRender", {
Obj: OS.DataConversion.JSNodeParamConverter.to(model.variables.objVar, OS.DataTypes.DataTypes.Object)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:FUwTGToU2k6hfPyH_S1C3g", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:B2zjAkx6P06j316ZGZzqVQ", callContext.id);
}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:OPb9SnmM502KoCr5Ddpf5g", callContext.id);
}

};
Controller.prototype._onParametersChanged$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnParametersChanged");
callContext = controller.callContext(callContext);
var optionsJSONVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.JSONSerializeOutputType());
varBag.callContext = callContext;
varBag.optionsJSONVar = optionsJSONVar;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:4ngeTJzPLUS28F+7LxwyKg:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.+STfuEk74kGPzVw1lCHt8g/ClientActions.4ngeTJzPLUS28F+7LxwyKg:13pe9xTnyih5hFbDYZ+6AA", "ShopperPortalEU_UI_Components", "OnParametersChanged", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:1kgk1X4wz0u4nF3Q07PSfA", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:hmIC641jvE+AWg+HK5Pv+A", callContext.id) && ((model.variables.objVar) !== (OS.BuiltinFunctions.nullObject())))) {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:WyaUy+iS1EKsgL7bPQomXQ", callContext.id);
// JSON Serialize: OptionsJSON
optionsJSONVar.value.jSONOut = OS.JSONUtils.serializeToJSON(model.variables.optionsIn, true, false);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:eb4DmmjOtkyfQ3eo6xz2IQ", callContext.id);
// Parameters change method.
controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomDropdownList_mvc_controller_OnParametersChanged_ParametersChangedJS, "ParametersChanged", "OnParametersChanged", {
Obj: OS.DataConversion.JSNodeParamConverter.to(model.variables.objVar, OS.DataTypes.DataTypes.Object),
Options: OS.DataConversion.JSNodeParamConverter.to(optionsJSONVar.value.jSONOut, OS.DataTypes.DataTypes.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:LtxCFucsLE2phwPEKeE7lg", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:X5kDKq7WIU69TEY0I54hhQ", callContext.id);
}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:4ngeTJzPLUS28F+7LxwyKg", callContext.id);
}

};
Controller.prototype._toggle$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Toggle");
callContext = controller.callContext(callContext);
var toggleJSResult = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.toggleJSResult = toggleJSResult;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:KX2yjAMl80eedQNKQy0pKw:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.+STfuEk74kGPzVw1lCHt8g/ClientActions.KX2yjAMl80eedQNKQy0pKw:J8EDU+Euma964PXiEg1nVw", "ShopperPortalEU_UI_Components", "Toggle", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:8_h3WWngEkapaVv6lUhE8g", callContext.id);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:j2FIXgq9AUCTc9V2ec8DCA", callContext.id);
// Toggle method.
toggleJSResult.value = controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomDropdownList_mvc_controller_Toggle_ToggleJS, "Toggle", "Toggle", {
Obj: OS.DataConversion.JSNodeParamConverter.to(model.variables.objVar, OS.DataTypes.DataTypes.Object),
Open: OS.DataConversion.JSNodeParamConverter.to(false, OS.DataTypes.DataTypes.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomDropdownList.Toggle$toggleJSResult"))();
jsNodeResult.openOut = OS.DataConversion.JSNodeParamConverter.from($parameters.Open, OS.DataTypes.DataTypes.Boolean);
return jsNodeResult;
}, {}, {});
if((OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:OZE1JRiiXUubFMMtjoLdkg", callContext.id) && toggleJSResult.value.openOut)) {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:YX3eRpV5ZUOj1frZJnAptA", callContext.id);
// IsVisible = Toggle.Open
model.variables.isVisibleVar = toggleJSResult.value.openOut;
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:zn+DxiPQrU+TZD7zz95Y1A", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:8SPHQMs0fkSiTuQ_YTAXvg", callContext.id);
}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:KX2yjAMl80eedQNKQy0pKw", callContext.id);
}

};
Controller.registerVariableGroupType("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomDropdownList.Toggle$toggleJSResult", [{
name: "Open",
attrName: "openOut",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Boolean,
defaultValue: function () {
return false;
}
}]);
Controller.prototype._change$Action = function (currentValueIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Change");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomDropdownList.Change$vars"))());
vars.value.currentValueInLocal = currentValueIn;
var optionsValueStructureVar = new OS.DataTypes.VariableHolder(new (OS.Controller.BaseController.getJSONDeserializeOutputType(ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValueOptionsRec))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.optionsValueStructureVar = optionsValueStructureVar;
OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:j+0Okyr29kmvE4ZL+gS4zw:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.+STfuEk74kGPzVw1lCHt8g/ClientActions.j+0Okyr29kmvE4ZL+gS4zw:T1k91yQr_i+SdKumgMjrOA", "ShopperPortalEU_UI_Components", "Change", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:IUJJ2kMFA0OkwarwRmk6LA", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:NQLPKVmAF0mvla+8Asm0+w", callContext.id);
// JSON Deserialize: OptionsValueStructure
optionsValueStructureVar.value.dataOut = OS.JSONUtils.deserializeFromJSON(vars.value.currentValueInLocal, ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValueOptionsRec, false);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:efnCSuwDn0eBadoGpmxC2w", callContext.id);
// Trigger Event: OnChange
return controller.onChange$Action(optionsValueStructureVar.value.dataOut, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:xSPYwV04jUitLsRGhMlJDg", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:j+0Okyr29kmvE4ZL+gS4zw", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:j+0Okyr29kmvE4ZL+gS4zw", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomDropdownList.Change$vars", [{
name: "CurrentValue",
attrName: "currentValueInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
Controller.prototype._search$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Search");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:Uz13nQHk3kenK+DZwMZ89A:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.+STfuEk74kGPzVw1lCHt8g/ClientActions.Uz13nQHk3kenK+DZwMZ89A:2QNNuzlRGLyrIGgzZHy5+Q", "ShopperPortalEU_UI_Components", "Search", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:YjLNtyrGoUakzssBZmjEvw", callContext.id);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:2RCmJGnhnkuDLLgBTzIw+Q", callContext.id);
// Search method.
controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomDropdownList_mvc_controller_Search_SearchJS, "Search", "Search", {
Obj: OS.DataConversion.JSNodeParamConverter.to(model.variables.objVar, OS.DataTypes.DataTypes.Object),
SearchVar: OS.DataConversion.JSNodeParamConverter.to(model.variables.searchVarVar, OS.DataTypes.DataTypes.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:hvut64bMNUeUjQW4CnUDrg", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:Uz13nQHk3kenK+DZwMZ89A", callContext.id);
}

};
Controller.prototype._close$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Close");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:oK9Qs4n_NEOz23a_wHxSKA:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.+STfuEk74kGPzVw1lCHt8g/ClientActions.oK9Qs4n_NEOz23a_wHxSKA:xEngDU2JLTven0eooF091Q", "ShopperPortalEU_UI_Components", "Close", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:bWu7oNEHXEmW9mBM_7xJMA", callContext.id);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:NmFMCwUtXUa4lh+Ek60OxA", callContext.id);
// IsVisible = False
model.variables.isVisibleVar = false;
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:pFcM4DycRkuWMFQu+8oqIg", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:oK9Qs4n_NEOz23a_wHxSKA", callContext.id);
}

};
Controller.prototype._onReady$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnReady");
callContext = controller.callContext(callContext);
var initializeJSResult = new OS.DataTypes.VariableHolder();
var optionsJSONVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.JSONSerializeOutputType());
varBag.callContext = callContext;
varBag.initializeJSResult = initializeJSResult;
varBag.optionsJSONVar = optionsJSONVar;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:RzME6Y49rEaF8UR_PbznJA:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.+STfuEk74kGPzVw1lCHt8g/ClientActions.RzME6Y49rEaF8UR_PbznJA:U_7CJowc7lq7ffqSnCcmlg", "ShopperPortalEU_UI_Components", "OnReady", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:gfnvI8zkB0SCaU1EdIr1Ww", callContext.id);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:SN1n0ksQZEWtUXCCAu_sfQ", callContext.id);
// JSON Serialize: OptionsJSON
optionsJSONVar.value.jSONOut = OS.JSONUtils.serializeToJSON(model.variables.optionsIn, true, false);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:vqwaGMZfdEiWlFASkBDkfA", callContext.id);
// Initialize component.
initializeJSResult.value = controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomDropdownList_mvc_controller_OnReady_InitializeJS, "Initialize", "OnReady", {
Options: OS.DataConversion.JSNodeParamConverter.to(optionsJSONVar.value.jSONOut, OS.DataTypes.DataTypes.Text),
ElementId: OS.DataConversion.JSNodeParamConverter.to(idService.getId("Element"), OS.DataTypes.DataTypes.Text),
Obj: OS.DataConversion.JSNodeParamConverter.to(null, OS.DataTypes.DataTypes.Object)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomDropdownList.OnReady$initializeJSResult"))();
jsNodeResult.objOut = OS.DataConversion.JSNodeParamConverter.from($parameters.Obj, OS.DataTypes.DataTypes.Object);
return jsNodeResult;
}, {
Change: controller.clientActionProxies.change$Action,
Toggle: controller.clientActionProxies.toggle$Action,
Close: controller.clientActionProxies.close$Action
}, {});
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:IpZu5Mvtakm2AMYqdPfEmg", callContext.id);
// Obj = Initialize.Obj
model.variables.objVar = initializeJSResult.value.objOut;
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:G1vD11RBzkG1_m_dC66KTg", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:RzME6Y49rEaF8UR_PbznJA", callContext.id);
}

};
Controller.registerVariableGroupType("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomDropdownList.OnReady$initializeJSResult", [{
name: "Obj",
attrName: "objOut",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Object,
defaultValue: function () {
return null;
}
}]);

Controller.prototype.dropdownRendered$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._dropdownRendered$Action, callContext);

};
Controller.prototype.onRender$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onRender$Action, callContext);

};
Controller.prototype.onParametersChanged$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onParametersChanged$Action, callContext);

};
Controller.prototype.toggle$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._toggle$Action, callContext);

};
Controller.prototype.change$Action = function (currentValueIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._change$Action, callContext, currentValueIn);

};
Controller.prototype.search$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._search$Action, callContext);

};
Controller.prototype.close$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._close$Action, callContext);

};
Controller.prototype.onReady$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onReady$Action, callContext);

};
Controller.prototype.onChange$Action = function () {
return Promise.resolve();
};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:7hC2bHqrKEmxvEuPSzIN0Q:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q:g5BtT+X6uN+vFl8t9PMqCQ", "ShopperPortalEU_UI_Components", "ShopperPortalEUUIComponents", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:+STfuEk74kGPzVw1lCHt8g:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.+STfuEk74kGPzVw1lCHt8g:JfrAuzhTKv6aEgo_M2sCJw", "ShopperPortalEU_UI_Components", "CustomDropdownList", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:+STfuEk74kGPzVw1lCHt8g", callContext.id);
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:7hC2bHqrKEmxvEuPSzIN0Q", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "ShopperPortalEUUIComponents/CustomDropdownList On Ready");
return controller.onReady$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onRenderEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "ShopperPortalEUUIComponents/CustomDropdownList On Render");
return controller.onRender$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "ShopperPortalEUUIComponents/CustomDropdownList On Parameters Changed");
return controller.onParametersChanged$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return ShopperPortalEU_UI_ComponentsController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, ShopperPortalEU_UI_ComponentsLanguageResources);
});
define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomDropdownList.mvc$controller.DropdownRendered.DropdownRenderedJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.Obj.dropdownRendered();
};
});
define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomDropdownList.mvc$controller.OnRender.RenderJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.Obj.render();
};
});
define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomDropdownList.mvc$controller.OnParametersChanged.ParametersChangedJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.Obj.parametersChanged(JSON.parse($parameters.Options));
};
});
define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomDropdownList.mvc$controller.Toggle.ToggleJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.Open = $parameters.Obj.toggle();
};
});
define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomDropdownList.mvc$controller.Search.SearchJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.Obj.search($parameters.SearchVar);
};
});
define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomDropdownList.mvc$controller.OnReady.InitializeJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.Obj = new customDropdownList($parameters.ElementId,JSON.parse($parameters.Options),{
    change:$actions.Change,
    toggle:$actions.Toggle,
    close:$actions.Close
});
};
});

define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomDropdownList.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"HACBHz2nAEOIvzbsljeB3g": {
getter: function (varBag, idService) {
return varBag.dropdownRenderedJSResult.value;
}
},
"WXehsBM520qDbJk7jIkivw": {
getter: function (varBag, idService) {
return varBag.renderJSResult.value;
}
},
"WyaUy+iS1EKsgL7bPQomXQ": {
getter: function (varBag, idService) {
return varBag.optionsJSONVar.value;
}
},
"eb4DmmjOtkyfQ3eo6xz2IQ": {
getter: function (varBag, idService) {
return varBag.parametersChangedJSResult.value;
}
},
"j2FIXgq9AUCTc9V2ec8DCA": {
getter: function (varBag, idService) {
return varBag.toggleJSResult.value;
}
},
"JLmrtP5yLEeXbm3e+81quw": {
getter: function (varBag, idService) {
return varBag.vars.value.currentValueInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"NQLPKVmAF0mvla+8Asm0+w": {
getter: function (varBag, idService) {
return varBag.optionsValueStructureVar.value;
}
},
"2RCmJGnhnkuDLLgBTzIw+Q": {
getter: function (varBag, idService) {
return varBag.searchJSResult.value;
}
},
"SN1n0ksQZEWtUXCCAu_sfQ": {
getter: function (varBag, idService) {
return varBag.optionsJSONVar.value;
}
},
"vqwaGMZfdEiWlFASkBDkfA": {
getter: function (varBag, idService) {
return varBag.initializeJSResult.value;
}
},
"sR6qtFmZh0y9kFpexI0laQ": {
getter: function (varBag, idService) {
return varBag.model.variables.searchVarVar;
},
dataType: OS.DataTypes.DataTypes.Text
},
"Vsw6EAgVF0ywRilxd0W0tw": {
getter: function (varBag, idService) {
return varBag.model.variables.objVar;
},
dataType: OS.DataTypes.DataTypes.Object
},
"zy8NgbW+RU6esWh+8AZoiQ": {
getter: function (varBag, idService) {
return varBag.model.variables.isVisibleVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"UI+h1dZiCUyS5VeZID5paQ": {
getter: function (varBag, idService) {
return varBag.model.variables.optionsIn;
}
},
"ErMYS94J3U2AZZ1_cTj0dw": {
getter: function (varBag, idService) {
return varBag.model.variables.extendedClassIn;
},
dataType: OS.DataTypes.DataTypes.Text
},
"ErTMov_9WUu_C7C7kpF_9g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Element"));
})(varBag.model, idService);
}
},
"qF65hlZVuUKfnPrBE5KaEw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Label"));
})(varBag.model, idService);
}
},
"LBAYPkoad0OuNpLPHWTAEQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Selected"));
})(varBag.model, idService);
}
},
"YohJ9Vxu2E2oGLlBUMeHfg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input_Search"));
})(varBag.model, idService);
}
},
"6c1+0NDc3kSUElaQbHLCkQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("List"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
