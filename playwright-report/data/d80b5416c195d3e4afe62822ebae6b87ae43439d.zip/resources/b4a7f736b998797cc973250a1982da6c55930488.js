define("RichWidgets.referencesHealth$HTTPRequestHandler", [], function () {
// Reference to producer 'HTTPRequestHandler' is OK.
});
define("RichWidgets.referencesHealth$Sanitization", [], function () {
// Reference to producer 'Sanitization' is OK.
});
define("RichWidgets.referencesHealth$ServiceCenter", [], function () {
// Reference to producer 'ServiceCenter' is OK.
});
define("RichWidgets.referencesHealth$Text", [], function () {
// Reference to producer 'Text' is OK.
});
define("RichWidgets.referencesHealth$Users", [], function () {
// Reference to producer 'Users' is OK.
});
define("RichWidgets.referencesHealth", [], function () {
});
