define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.mvc$model", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.Private.TouchEvents.mvc$model", "ShopperPortalEU_UI_Components.Private.MouseEvents.mvc$model", "ShopperPortalEU_UI_Components.model$CustomCarouselOptionsRec"], function (OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_Components_Private_TouchEvents_mvcModel, ShopperPortalEU_UI_Components_Private_MouseEvents_mvcModel) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("CarouselObj", "carouselObjVar", "CarouselObj", true, false, OS.DataTypes.DataTypes.Object, function () {
return null;
}, false), 
this.attr("Velocity", "velocityVar", "Velocity", true, false, OS.DataTypes.DataTypes.Decimal, function () {
return (new OS.DataTypes.Decimal("0.3"));
}, false), 
this.attr("IsAnimating", "isAnimatingVar", "IsAnimating", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("ContainsClass", "containsClassVar", "ContainsClass", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("DragDirection", "dragDirectionVar", "DragDirection", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, false), 
this.attr("AddDragEvents", "addDragEventsVar", "AddDragEvents", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("Options", "optionsIn", "Options", true, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomCarouselOptionsRec());
}, false, ShopperPortalEU_UI_ComponentsModel.CustomCarouselOptionsRec), 
this.attr("_optionsInDataFetchStatus", "_optionsInDataFetchStatus", "_optionsInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("ExtendedClass", "extendedClassIn", "ExtendedClass", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, false), 
this.attr("_extendedClassInDataFetchStatus", "_extendedClassInDataFetchStatus", "_extendedClassInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Model._hasValidationWidgetsValue = undefined;
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
if((Model._hasValidationWidgetsValue === undefined)) {
Model._hasValidationWidgetsValue = (ShopperPortalEU_UI_Components_Private_TouchEvents_mvcModel.hasValidationWidgets || ShopperPortalEU_UI_Components_Private_MouseEvents_mvcModel.hasValidationWidgets);
}

return Model._hasValidationWidgetsValue;
}
});

Model.prototype.setInputs = function (inputs) {
if("Options" in inputs) {
this.variables.optionsIn = inputs.Options;
if("_optionsInDataFetchStatus" in inputs) {
this.variables._optionsInDataFetchStatus = inputs._optionsInDataFetchStatus;
}

}

if("ExtendedClass" in inputs) {
this.variables.extendedClassIn = inputs.ExtendedClass;
if("_extendedClassInDataFetchStatus" in inputs) {
this.variables._extendedClassInDataFetchStatus = inputs._extendedClassInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "ShopperPortalEUUIComponents.CustomCarousel");
});
define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.mvc$view", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.controller", "react", "OutSystems/ReactView/Main", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.mvc$controller", "OutSystems/ReactWidgets/Main", "ShopperPortalEU_UI_Components.Private.TouchEvents.mvc$view", "ShopperPortalEU_UI_Components.Private.MouseEvents.mvc$view", "ShopperPortalEU_UI_Components.model$CustomCarouselOptionsRec"], function (OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ComponentsController, React, OSView, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCarousel_mvc_model, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCarousel_mvc_controller, OSWidgets, ShopperPortalEU_UI_Components_Private_TouchEvents_mvc_view, ShopperPortalEU_UI_Components_Private_MouseEvents_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            var thisIsInstanceOfSuper = this instanceof _super;
            if (thisIsInstanceOfSuper == false) {
                return;
            }

            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "ShopperPortalEUUIComponents.CustomCarousel";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css"];
        };
        View.getJsDependencies = function() {
            return ["scripts/ShopperPortalEU_UI_Components.customCarousel.js"];
        };
        View.getBlocks = function() {
            return [ShopperPortalEU_UI_Components_Private_TouchEvents_mvc_view, ShopperPortalEU_UI_Components_Private_MouseEvents_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCarousel_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCarousel_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: model.getCachedValue(idService.getId("AGq7frE+v0maGrNG2YojIQ.Style"), function () {
return ("custom-carousel" + (((model.variables.extendedClassIn === "")) ? ("") : ((" " + model.variables.extendedClassIn))));
}, function () {
return model.variables.extendedClassIn;
}),
visible: true,
_idProps: {
service: idService,
uuid: "0"
},
_widgetRecordProvider: widgetsRecordProvider,
style_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._extendedClassInDataFetchStatus)
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
"aria-live": "polite",
"aria-atomic": "True"
},
style: "carousel init",
visible: true,
_idProps: {
service: idService,
name: "carousel"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "carousel-container",
visible: true,
_idProps: {
service: idService,
uuid: "2"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Placeholder, {
align: /*Default*/ 0,
content: _this.props.placeholders.items,
extendedProperties: {
tabIndex: "0",
"aria-live": "off",
"aria-atomic": "false"
},
style: "carousel-container-content",
_idProps: {
service: idService,
name: "Items"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
role: "navigation"
},
style: "carousel-dots-container",
visible: true,
_idProps: {
service: idService,
uuid: "4"
},
_widgetRecordProvider: widgetsRecordProvider
}, $if(false, false, this, function () {
return [];
}, function () {
return [];
}))), $if(false, false, this, function () {
return [];
}, function () {
return [$if(model.variables.addDragEventsVar, false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_Private_TouchEvents_mvc_view, {
inputs: {
WidgetId: idService.getId("carousel")
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
start$Action: function (xIn, yIn) {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Private/TouchEvents Start");
controller.gestureStart$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
end$Action: function (xIn, yIn, offsetXIn, offsetYIn, timeTakenIn) {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Private/TouchEvents End");
controller.gestureEnd$Action(offsetXIn, timeTakenIn, 0, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
move$Action: function (xIn, yIn, offsetXIn, offsetYIn, evtIn) {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Private/TouchEvents Move");
controller.gestureMove$Action(offsetXIn, evtIn, offsetYIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "5",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}), React.createElement(ShopperPortalEU_UI_Components_Private_MouseEvents_mvc_view, {
inputs: {
WidgetId: idService.getId("carousel")
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
start$Action: function (xIn, yIn) {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Private/MouseEvents Start");
controller.gestureStart$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
move$Action: function (xIn, yIn, offsetXIn, offsetYIn, evtIn) {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Private/MouseEvents Move");
controller.gestureMove$Action(offsetXIn, evtIn, offsetYIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
end$Action: function (xIn, yIn, offsetXIn, offsetYIn, timeTakenIn) {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Private/MouseEvents End");
controller.gestureEnd$Action(offsetXIn, timeTakenIn, 0, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "6",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}, function () {
return [];
})];
})));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.mvc$controller", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.controller", "ShopperPortalEU_UI_Components.languageResources", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.mvc$debugger", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.mvc$controller.Next.NextJS", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.mvc$controller.GestureStart.AddNoTransitionClassesJS", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.mvc$controller.GestureStart.RemoveNoTransitionJS", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.mvc$controller.GestureStart.CheckIfContainsClassJS", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.mvc$controller.OnReady.CallingInitJS", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.mvc$controller.OnDestroy.RemoveListnerOnOrientationJS", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.mvc$controller.OnOrientationChange.OnOrientationChangeJS", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.mvc$controller.Update.UpdateJS", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.mvc$controller.GoTo.GetMaxElementsJS", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.mvc$controller.GoTo.GoToTargetJS", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.mvc$controller.GoTo.GoToLastJS", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.mvc$controller.GestureEnd.PrepareElementsJS", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.mvc$controller.GestureEnd.ChangeIsAnimatingStatusJS", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.mvc$controller.GestureEnd.BackToMiddleJS", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.mvc$controller.GestureMove.TransformUiJS", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.mvc$controller.GestureMove.AddNoTransitionClassesJS", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.mvc$controller.Previous.PreviousJS", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.mvc$controller.Init.InitCarouselJS", "ShopperPortalEU_UI_Components.model$CustomCarouselOptionsRec"], function (OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ComponentsController, ShopperPortalEU_UI_ComponentsLanguageResources, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCarousel_mvc_Debugger, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCarousel_mvc_controller_Next_NextJS, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCarousel_mvc_controller_GestureStart_AddNoTransitionClassesJS, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCarousel_mvc_controller_GestureStart_RemoveNoTransitionJS, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCarousel_mvc_controller_GestureStart_CheckIfContainsClassJS, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCarousel_mvc_controller_OnReady_CallingInitJS, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCarousel_mvc_controller_OnDestroy_RemoveListnerOnOrientationJS, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCarousel_mvc_controller_OnOrientationChange_OnOrientationChangeJS, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCarousel_mvc_controller_Update_UpdateJS, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCarousel_mvc_controller_GoTo_GetMaxElementsJS, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCarousel_mvc_controller_GoTo_GoToTargetJS, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCarousel_mvc_controller_GoTo_GoToLastJS, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCarousel_mvc_controller_GestureEnd_PrepareElementsJS, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCarousel_mvc_controller_GestureEnd_ChangeIsAnimatingStatusJS, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCarousel_mvc_controller_GestureEnd_BackToMiddleJS, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCarousel_mvc_controller_GestureMove_TransformUiJS, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCarousel_mvc_controller_GestureMove_AddNoTransitionClassesJS, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCarousel_mvc_controller_Previous_PreviousJS, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCarousel_mvc_controller_Init_InitCarouselJS) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {
onOrientationChange$Action: function () {
return controller.executeActionInsideJSNode(controller._onOrientationChange$Action.bind(controller), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "OnOrientationChange");
},
init$Action: function () {
return controller.executeActionInsideJSNode(controller._init$Action.bind(controller), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "Init");
},
goTo$Action: function (targetIn) {
targetIn = (targetIn === undefined) ? 0 : targetIn;
return controller.executeActionInsideJSNode(controller._goTo$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(targetIn, OS.DataTypes.DataTypes.Integer)), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "GoTo");
},
setEventsStatus$Action: function (addEventsIn) {
addEventsIn = (addEventsIn === undefined) ? false : addEventsIn;
return controller.executeActionInsideJSNode(controller._setEventsStatus$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(addEventsIn, OS.DataTypes.DataTypes.Boolean)), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "SetEventsStatus");
},
changeIsAnimatingStatus$Action: function () {
return controller.executeActionInsideJSNode(controller._changeIsAnimatingStatus$Action.bind(controller), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "ChangeIsAnimatingStatus");
},
previous$Action: function () {
return controller.executeActionInsideJSNode(controller._previous$Action.bind(controller), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "Previous");
},
next$Action: function () {
return controller.executeActionInsideJSNode(controller._next$Action.bind(controller), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "Next");
},
update$Action: function () {
return controller.executeActionInsideJSNode(controller._update$Action.bind(controller), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "Update");
}
};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = false;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._onParametersChanged$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnParametersChanged");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:HBjQTolsXEOW4R9DOMJvzw:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.46DiDReT8k2RTrxf91EQTg/ClientActions.HBjQTolsXEOW4R9DOMJvzw:uBKKxt4UIPIvq34QMdFPhg", "ShopperPortalEU_UI_Components", "OnParametersChanged", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:cy3ZwIWG7UeNt1GqscXtUg", callContext.id);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:w1Fbh03UAk+GRbnsD4lU2g", callContext.id);
// Execute Action: Update
controller._update$Action(callContext);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:2CtXUJWWckW8U9nn1Z45Yw", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:HBjQTolsXEOW4R9DOMJvzw", callContext.id);
}

};
Controller.prototype._setEventsStatus$Action = function (addEventsIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("SetEventsStatus");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.SetEventsStatus$vars"))());
vars.value.addEventsInLocal = addEventsIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:AcpBU3M_CESTzGuwHNqeTA:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.46DiDReT8k2RTrxf91EQTg/ClientActions.AcpBU3M_CESTzGuwHNqeTA:_VVzMhkdPBmKawNcfVk1qA", "ShopperPortalEU_UI_Components", "SetEventsStatus", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:4hVQ4EDjtEGMRaQfM_7O4A", callContext.id);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:sqMSagcICkmjf2W+bxdcKQ", callContext.id);
// AddDragEvents = AddEvents
model.variables.addDragEventsVar = vars.value.addEventsInLocal;
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:3cmyD43yMk2Bm7N0UhYS4g", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:AcpBU3M_CESTzGuwHNqeTA", callContext.id);
}

};
Controller.registerVariableGroupType("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.SetEventsStatus$vars", [{
name: "AddEvents",
attrName: "addEventsInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Boolean,
defaultValue: function () {
return false;
}
}]);
Controller.prototype._next$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Next");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:SX6KZgbCHUaTSuF08V0Tag:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.46DiDReT8k2RTrxf91EQTg/ClientActions.SX6KZgbCHUaTSuF08V0Tag:tlyYHhDl6d46vsk17dBIqg", "ShopperPortalEU_UI_Components", "Next", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:lbxjfoHXTEOzyz0vVtMllg", callContext.id);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:gIfraVrDlkGUz96uJTSEdQ", callContext.id);
controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCarousel_mvc_controller_Next_NextJS, "Next", "Next", {
CarouselObj: OS.DataConversion.JSNodeParamConverter.to(model.variables.carouselObjVar, OS.DataTypes.DataTypes.Object)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:ak6eSKLxo0K2XociGWquIA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:SX6KZgbCHUaTSuF08V0Tag", callContext.id);
}

};
Controller.prototype._gestureStart$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("GestureStart");
callContext = controller.callContext(callContext);
var checkIfContainsClassJSResult = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.checkIfContainsClassJSResult = checkIfContainsClassJSResult;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:6FwljVQDREC5BBPxzDBZ+w:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.46DiDReT8k2RTrxf91EQTg/ClientActions.6FwljVQDREC5BBPxzDBZ+w:G8QWF33BBEOSIWjJn8lrow", "ShopperPortalEU_UI_Components", "GestureStart", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:7t_DxgvgqEW5i6RK1USERQ", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:M3HZhzooxU6U1OU1axTe6w", callContext.id) && model.variables.isAnimatingVar)) {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:_NVQpNYxMkuiXdb9GC28RQ", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:HvrDw2d0t02_i9fu3eqOzA", callContext.id);
checkIfContainsClassJSResult.value = controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCarousel_mvc_controller_GestureStart_CheckIfContainsClassJS, "CheckIfContainsClass", "GestureStart", {
CarouselId: OS.DataConversion.JSNodeParamConverter.to(idService.getId("carousel"), OS.DataTypes.DataTypes.Text),
ContainsClass: OS.DataConversion.JSNodeParamConverter.to(false, OS.DataTypes.DataTypes.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.GestureStart$checkIfContainsClassJSResult"))();
jsNodeResult.containsClassOut = OS.DataConversion.JSNodeParamConverter.from($parameters.ContainsClass, OS.DataTypes.DataTypes.Boolean);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:hWo4Ah2HpUGEpB1Vm+zYuQ", callContext.id);
// ContainsClass = CheckIfContainsClass.ContainsClass
model.variables.containsClassVar = checkIfContainsClassJSResult.value.containsClassOut;
if((OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:5QqvMIAb2kunv62wPKBdrQ", callContext.id) && model.variables.containsClassVar)) {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:Ht1ktBiZ5kq07PfsELLDWw", callContext.id);
controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCarousel_mvc_controller_GestureStart_RemoveNoTransitionJS, "RemoveNoTransition", "GestureStart", {
Id: OS.DataConversion.JSNodeParamConverter.to(idService.getId("carousel"), OS.DataTypes.DataTypes.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:Y_ylwv7yUkKPnIQegVMytQ", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:KE+0fX41sEGIcXtnb6tTAA", callContext.id);
controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCarousel_mvc_controller_GestureStart_AddNoTransitionClassesJS, "AddNoTransitionClasses", "GestureStart", {
CarouselObj: OS.DataConversion.JSNodeParamConverter.to(model.variables.carouselObjVar, OS.DataTypes.DataTypes.Object)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:Y_ylwv7yUkKPnIQegVMytQ", callContext.id);
}

}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:6FwljVQDREC5BBPxzDBZ+w", callContext.id);
}

};
Controller.registerVariableGroupType("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.GestureStart$checkIfContainsClassJSResult", [{
name: "ContainsClass",
attrName: "containsClassOut",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Boolean,
defaultValue: function () {
return false;
}
}]);
Controller.prototype._onReady$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnReady");
callContext = controller.callContext(callContext);
var callingInitJSResult = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.callingInitJSResult = callingInitJSResult;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:mO9olx4fs0aySQHoHvmXqA:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.46DiDReT8k2RTrxf91EQTg/ClientActions.mO9olx4fs0aySQHoHvmXqA:_zLVM4eebaxC3uPDdc8CFQ", "ShopperPortalEU_UI_Components", "OnReady", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:_UHIBoYSDUKbOPGPkTOWMg", callContext.id);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:9XeswM3u9k6CJpxBTpDIpA", callContext.id);
callingInitJSResult.value = controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCarousel_mvc_controller_OnReady_CallingInitJS, "CallingInit", "OnReady", {
WidgetId: OS.DataConversion.JSNodeParamConverter.to(idService.getId("carousel"), OS.DataTypes.DataTypes.Text),
Items: OS.DataConversion.JSNodeParamConverter.to(model.variables.optionsIn.itemsAttr, OS.DataTypes.DataTypes.Integer),
CarouselObj: OS.DataConversion.JSNodeParamConverter.to(null, OS.DataTypes.DataTypes.Object)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.OnReady$callingInitJSResult"))();
jsNodeResult.carouselObjOut = OS.DataConversion.JSNodeParamConverter.from($parameters.CarouselObj, OS.DataTypes.DataTypes.Object);
return jsNodeResult;
}, {
OnOrientationChange: controller.clientActionProxies.onOrientationChange$Action,
Init: controller.clientActionProxies.init$Action,
GoTo: controller.clientActionProxies.goTo$Action,
SetEventsStatus: controller.clientActionProxies.setEventsStatus$Action
}, {});
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:3OtQmz360E2gJiJeZGx4Cw", callContext.id);
// CarouselObj = CallingInit.CarouselObj
model.variables.carouselObjVar = callingInitJSResult.value.carouselObjOut;
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:wF4kA_5WekC+4+Rs2FkO0g", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:mO9olx4fs0aySQHoHvmXqA", callContext.id);
}

};
Controller.registerVariableGroupType("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.OnReady$callingInitJSResult", [{
name: "CarouselObj",
attrName: "carouselObjOut",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Object,
defaultValue: function () {
return null;
}
}]);
Controller.prototype._onDestroy$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnDestroy");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:qCJYmPQbl0+wgMPqG4W49A:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.46DiDReT8k2RTrxf91EQTg/ClientActions.qCJYmPQbl0+wgMPqG4W49A:yrZOOqyfaH858DfnksMK9w", "ShopperPortalEU_UI_Components", "OnDestroy", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:uHWvppSfOky5pWGku3YFtw", callContext.id);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:W1t6BBxd00C1nhMP5EASow", callContext.id);
// JS Node to remove EventListner orientationchange
controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCarousel_mvc_controller_OnDestroy_RemoveListnerOnOrientationJS, "RemoveListnerOnOrientation", "OnDestroy", null, function ($parameters) {
}, {
OnOrientationChange: controller.clientActionProxies.onOrientationChange$Action
}, {});
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:c72zJ2QBwkqJqjdemJZxnQ", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:qCJYmPQbl0+wgMPqG4W49A", callContext.id);
}

};
Controller.prototype._changeIsAnimatingStatus$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("ChangeIsAnimatingStatus");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:g72+oHo6gEaGTIrWl_nI+g:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.46DiDReT8k2RTrxf91EQTg/ClientActions.g72+oHo6gEaGTIrWl_nI+g:JX8TIMMqFQyJ4rKSo8vpZg", "ShopperPortalEU_UI_Components", "ChangeIsAnimatingStatus", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:L_CEZDD1gk23Pk_0hY1fJg", callContext.id);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:Ec4X3phS+02dshsMMM9awA", callContext.id);
// IsAnimating = False
model.variables.isAnimatingVar = false;
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:Bp9xhQ79OUKD0d0NZ7C16Q", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:g72+oHo6gEaGTIrWl_nI+g", callContext.id);
}

};
Controller.prototype._onOrientationChange$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnOrientationChange");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:gT3Mp9z0DEW6ZUxC26j0hQ:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.46DiDReT8k2RTrxf91EQTg/ClientActions.gT3Mp9z0DEW6ZUxC26j0hQ:3SScobKhK1lrBZ3Eatz5sQ", "ShopperPortalEU_UI_Components", "OnOrientationChange", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:hVWvzwCI_keugz1zLjr5cg", callContext.id);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:sP9971wFE0iJ2neXGKFthw", callContext.id);
controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCarousel_mvc_controller_OnOrientationChange_OnOrientationChangeJS, "OnOrientationChange", "OnOrientationChange", {
CarouselObj: OS.DataConversion.JSNodeParamConverter.to(model.variables.carouselObjVar, OS.DataTypes.DataTypes.Object)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:ccFsQV28Z0e2uZFibokiIg", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:gT3Mp9z0DEW6ZUxC26j0hQ", callContext.id);
}

};
Controller.prototype._update$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Update");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:qLCsssR6dkiJBoiBB70vZw:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.46DiDReT8k2RTrxf91EQTg/ClientActions.qLCsssR6dkiJBoiBB70vZw:8x0ybNfhvAmKQL5Az_jIPw", "ShopperPortalEU_UI_Components", "Update", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:hvI3_4BpYkG9QK82xTIQ8A", callContext.id);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:I4_KJ7V0P0mEEeZEJUG1Cg", callContext.id);
controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCarousel_mvc_controller_Update_UpdateJS, "Update", "Update", {
CarouselObj: OS.DataConversion.JSNodeParamConverter.to(model.variables.carouselObjVar, OS.DataTypes.DataTypes.Object)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:1VTv_Z8cbkaaVz8WH7wNXQ", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:qLCsssR6dkiJBoiBB70vZw", callContext.id);
}

};
Controller.prototype._goTo$Action = function (targetIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("GoTo");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.GoTo$vars"))());
vars.value.targetInLocal = targetIn;
var getMaxElementsJSResult = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.vars = vars;
varBag.getMaxElementsJSResult = getMaxElementsJSResult;
OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:wQZVtcSwk0Stmdo1vpEf2Q:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.46DiDReT8k2RTrxf91EQTg/ClientActions.wQZVtcSwk0Stmdo1vpEf2Q:cEpLzcZYSlB36D4wvlGfbg", "ShopperPortalEU_UI_Components", "GoTo", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:MeVnhun3YkSq3zJHTXgroQ", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:G3I7K60GLkKgRc2i1YV41w", callContext.id);
getMaxElementsJSResult.value = controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCarousel_mvc_controller_GoTo_GetMaxElementsJS, "GetMaxElements", "GoTo", {
CarouselObj: OS.DataConversion.JSNodeParamConverter.to(model.variables.carouselObjVar, OS.DataTypes.DataTypes.Object),
MaxElements: OS.DataConversion.JSNodeParamConverter.to(0, OS.DataTypes.DataTypes.Integer)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.GoTo$getMaxElementsJSResult"))();
jsNodeResult.maxElementsOut = OS.DataConversion.JSNodeParamConverter.from($parameters.MaxElements, OS.DataTypes.DataTypes.Integer);
return jsNodeResult;
}, {}, {});
// elementExists?
if((OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:aKNrelVmwkKqFtQECYSNcg", callContext.id) && (vars.value.targetInLocal >= getMaxElementsJSResult.value.maxElementsOut))) {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:p_Tex__UG0yQrRHPI7yd5w", callContext.id);
controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCarousel_mvc_controller_GoTo_GoToLastJS, "GoToLast", "GoTo", {
Target: OS.DataConversion.JSNodeParamConverter.to((getMaxElementsJSResult.value.maxElementsOut - 1), OS.DataTypes.DataTypes.Integer),
CarouselObj: OS.DataConversion.JSNodeParamConverter.to(model.variables.carouselObjVar, OS.DataTypes.DataTypes.Object)
}, function ($parameters) {
}, {}, {});
} else {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:3Q_mKzxeeEawbke77N4jbQ", callContext.id);
controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCarousel_mvc_controller_GoTo_GoToTargetJS, "GoToTarget", "GoTo", {
Target: OS.DataConversion.JSNodeParamConverter.to(vars.value.targetInLocal, OS.DataTypes.DataTypes.Integer),
CarouselObj: OS.DataConversion.JSNodeParamConverter.to(model.variables.carouselObjVar, OS.DataTypes.DataTypes.Object)
}, function ($parameters) {
}, {}, {});
}

OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:qtrY8004_UK+uAvnax9aIA", callContext.id);
// Trigger Event: OnItemChange
return controller.onItemChange$Action(vars.value.targetInLocal, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:lnzXEP2Ad0axg7JXkmafdA", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:wQZVtcSwk0Stmdo1vpEf2Q", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:wQZVtcSwk0Stmdo1vpEf2Q", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.GoTo$vars", [{
name: "Target",
attrName: "targetInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Integer,
defaultValue: function () {
return 0;
}
}]);
Controller.registerVariableGroupType("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.GoTo$getMaxElementsJSResult", [{
name: "MaxElements",
attrName: "maxElementsOut",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Integer,
defaultValue: function () {
return 0;
}
}]);
Controller.prototype._gestureEnd$Action = function (offsetXIn, timeTakenIn, elementhWidthIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("GestureEnd");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.GestureEnd$vars"))());
vars.value.offsetXInLocal = offsetXIn;
vars.value.timeTakenInLocal = timeTakenIn;
vars.value.elementhWidthInLocal = elementhWidthIn;
var prepareElementsJSResult = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.vars = vars;
varBag.prepareElementsJSResult = prepareElementsJSResult;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:5nsVyblWoEe1YElX9+RKAA:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.46DiDReT8k2RTrxf91EQTg/ClientActions.5nsVyblWoEe1YElX9+RKAA:IJgtIuKoO2Wr_tLjRiAnpA", "ShopperPortalEU_UI_Components", "GestureEnd", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:+6dOcJfc8Um8+rq3t6T_XA", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:uF5vHGDqjEaR5sjvccD6yA", callContext.id) && model.variables.isAnimatingVar)) {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:ikXbDM5KBEec2fM96sGhDg", callContext.id);
} else {
if((OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:eAKIJmMXRUGUMP9yWJGGLw", callContext.id) && model.variables.containsClassVar)) {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:TyZRFSy9KU68WRU0GCkJug", callContext.id);
// ContainsClass = True
model.variables.containsClassVar = true;
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:ikXbDM5KBEec2fM96sGhDg", callContext.id);
} else {
do {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:DW9wXLPz5EyPZ5KUAH9AJQ", callContext.id);
// RemoveNoTransitionClasses and GetElementWidth
prepareElementsJSResult.value = controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCarousel_mvc_controller_GestureEnd_PrepareElementsJS, "PrepareElements", "GestureEnd", {
CarouselObj: OS.DataConversion.JSNodeParamConverter.to(model.variables.carouselObjVar, OS.DataTypes.DataTypes.Object),
ElementWidth: OS.DataConversion.JSNodeParamConverter.to(0, OS.DataTypes.DataTypes.Integer)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.GestureEnd$prepareElementsJSResult"))();
jsNodeResult.elementWidthOut = OS.DataConversion.JSNodeParamConverter.from($parameters.ElementWidth, OS.DataTypes.DataTypes.Integer);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:cCyqayWMOUunyG4kv6A4ew", callContext.id);
// ElementhWidth = PrepareElements.ElementWidth
vars.value.elementhWidthInLocal = prepareElementsJSResult.value.elementWidthOut;
if((OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:VAc+d1dKVkiYi55JU07hOA", callContext.id) && vars.value.offsetXInLocal.gt(OS.BuiltinFunctions.integerToDecimal(0)))) {
// DidItPassHalf?
if((OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:3QWp85tVUU+jhh66JID0Sw", callContext.id) && (vars.value.offsetXInLocal.gt(OS.BuiltinFunctions.integerToDecimal(vars.value.elementhWidthInLocal).div(OS.BuiltinFunctions.integerToDecimal(3))) || OS.BuiltinFunctions.abs(vars.value.offsetXInLocal).div(vars.value.timeTakenInLocal).gt(model.variables.velocityVar)))) {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:eHtpI+xEiEaAZM8jI_m7rw", callContext.id);
// Execute Action: Previous
controller._previous$Action(callContext);
break;
}

} else {
if(vars.value.offsetXInLocal.lt(OS.BuiltinFunctions.integerToDecimal(0))) {
// DidItPassHalf?
if((OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:jJRAuWq5wEm__HhnwELLWg", callContext.id) && (vars.value.offsetXInLocal.lt(OS.BuiltinFunctions.integerToDecimal(vars.value.elementhWidthInLocal).div(OS.BuiltinFunctions.integerToDecimal(3)).times(OS.BuiltinFunctions.integerToDecimal(-1))) || OS.BuiltinFunctions.abs(vars.value.offsetXInLocal).div(vars.value.timeTakenInLocal).gt(model.variables.velocityVar)))) {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:iFUtMosZkkufVn+wEaS1Gg", callContext.id);
// Execute Action: Next
controller._next$Action(callContext);
break;
}

}

}

OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:+gsp3wqmp0mj6oNrQ3bsaQ", callContext.id);
controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCarousel_mvc_controller_GestureEnd_BackToMiddleJS, "BackToMiddle", "GestureEnd", {
CarouselObj: OS.DataConversion.JSNodeParamConverter.to(model.variables.carouselObjVar, OS.DataTypes.DataTypes.Object)
}, function ($parameters) {
}, {}, {});
} while(false)
;
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:JjZTcN15aE6c8lLF3HE1Bw", callContext.id);
// IsAnimating = True
model.variables.isAnimatingVar = true;
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:3xUvYNWufESezJLHFHyheQ", callContext.id);
controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCarousel_mvc_controller_GestureEnd_ChangeIsAnimatingStatusJS, "ChangeIsAnimatingStatus", "GestureEnd", null, function ($parameters) {
}, {
ChangeIsAnimatingStatus: controller.clientActionProxies.changeIsAnimatingStatus$Action
}, {});
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:pfL_sREQAECKAVB4GvXEHw", callContext.id);
}

}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:5nsVyblWoEe1YElX9+RKAA", callContext.id);
}

};
Controller.registerVariableGroupType("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.GestureEnd$vars", [{
name: "OffsetX",
attrName: "offsetXInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Decimal,
defaultValue: function () {
return OS.DataTypes.Decimal.defaultValue;
}
}, {
name: "TimeTaken",
attrName: "timeTakenInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Decimal,
defaultValue: function () {
return OS.DataTypes.Decimal.defaultValue;
}
}, {
name: "ElementhWidth",
attrName: "elementhWidthInLocal",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Integer,
defaultValue: function () {
return 0;
}
}]);
Controller.registerVariableGroupType("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.GestureEnd$prepareElementsJSResult", [{
name: "ElementWidth",
attrName: "elementWidthOut",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Integer,
defaultValue: function () {
return 0;
}
}]);
Controller.prototype._gestureMove$Action = function (offsetXIn, evtIn, offsetYIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("GestureMove");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.GestureMove$vars"))());
vars.value.offsetXInLocal = offsetXIn;
vars.value.evtInLocal = evtIn;
vars.value.offsetYInLocal = offsetYIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:wn38zUZJJkmC3+CMXUuXgQ:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.46DiDReT8k2RTrxf91EQTg/ClientActions.wn38zUZJJkmC3+CMXUuXgQ:0jbfmEzD5ynMMxQnjq8KMg", "ShopperPortalEU_UI_Components", "GestureMove", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:blCXD11510eD8fSwgKSncw", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:ze50tOsGWUqVEYt2XUIGTg", callContext.id) && model.variables.isAnimatingVar)) {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:PsO0b5DrB0S+yWi5qKaubQ", callContext.id);
} else {
if((OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:Xt79uwAh_kSsjKq_Bn1kiw", callContext.id) && model.variables.containsClassVar)) {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:8x95k7SYD0KTTsl+89mpGQ", callContext.id);
// ContainsClass = True
model.variables.containsClassVar = true;
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:PsO0b5DrB0S+yWi5qKaubQ", callContext.id);
} else {
// No direction set?
do {
// No direction set?
if((OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:WYMVfJf2g02nYOMyhMAiJQ", callContext.id) && (model.variables.dragDirectionVar === ""))) {
// Set drag direction
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:kZQR+ZvaUEqsm2cCLiJt6Q", callContext.id);
// DragDirection = If
model.variables.dragDirectionVar = ((OS.BuiltinFunctions.abs(vars.value.offsetXInLocal).gte(OS.BuiltinFunctions.abs(vars.value.offsetYInLocal))) ? ("horizontal") : ("vertical"));
// Is vertical?
if((OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:NMtTggn7p0mbr81xXMk4+g", callContext.id) && (model.variables.dragDirectionVar === "vertical"))) {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:6zj0pPZqm0eGLjdm5MSGcw", callContext.id);
controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCarousel_mvc_controller_GestureMove_AddNoTransitionClassesJS, "AddNoTransitionClasses", "GestureMove", {
CarouselObj: OS.DataConversion.JSNodeParamConverter.to(model.variables.carouselObjVar, OS.DataTypes.DataTypes.Object)
}, function ($parameters) {
}, {}, {});
break;
}

}

OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:4SDtB0lWHUW5_BiGczG3jQ", callContext.id);
controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCarousel_mvc_controller_GestureMove_TransformUiJS, "TransformUi", "GestureMove", {
OffsetX: OS.DataConversion.JSNodeParamConverter.to(vars.value.offsetXInLocal, OS.DataTypes.DataTypes.Decimal),
CarouselObj: OS.DataConversion.JSNodeParamConverter.to(model.variables.carouselObjVar, OS.DataTypes.DataTypes.Object),
Evt: OS.DataConversion.JSNodeParamConverter.to(vars.value.evtInLocal, OS.DataTypes.DataTypes.Object)
}, function ($parameters) {
}, {}, {});
} while(false)
;
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:ombG1wvkMkSITeTj3A1Lug", callContext.id);
// DragDirection = ""
model.variables.dragDirectionVar = "";
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:Ck3ttprrF0+8U7P_w8LaSw", callContext.id);
}

}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:wn38zUZJJkmC3+CMXUuXgQ", callContext.id);
}

};
Controller.registerVariableGroupType("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.GestureMove$vars", [{
name: "OffsetX",
attrName: "offsetXInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Decimal,
defaultValue: function () {
return OS.DataTypes.Decimal.defaultValue;
}
}, {
name: "Evt",
attrName: "evtInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Object,
defaultValue: function () {
return null;
}
}, {
name: "OffsetY",
attrName: "offsetYInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Decimal,
defaultValue: function () {
return OS.DataTypes.Decimal.defaultValue;
}
}]);
Controller.prototype._previous$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Previous");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:Y6Pg0UlBBUiIBGbvsNkI1g:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.46DiDReT8k2RTrxf91EQTg/ClientActions.Y6Pg0UlBBUiIBGbvsNkI1g:890cw5t48xd1bibwM0q1RQ", "ShopperPortalEU_UI_Components", "Previous", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:YgGYZl4mck+QyFzKdi1VBA", callContext.id);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:MjtW46K3jEupwGpJKFHVMQ", callContext.id);
controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCarousel_mvc_controller_Previous_PreviousJS, "Previous", "Previous", {
CarouselObj: OS.DataConversion.JSNodeParamConverter.to(model.variables.carouselObjVar, OS.DataTypes.DataTypes.Object)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:x4D4TbH3X0i4nzDiphA+aw", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:Y6Pg0UlBBUiIBGbvsNkI1g", callContext.id);
}

};
Controller.prototype._init$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Init");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:VTkN3JkAOEWs1ZfxGfd1QQ:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.46DiDReT8k2RTrxf91EQTg/ClientActions.VTkN3JkAOEWs1ZfxGfd1QQ:jIizB_p3Adpzaxe7i7s7+g", "ShopperPortalEU_UI_Components", "Init", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:ia97JkFp5kKFWyjAJwTcXQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:D2CO6dGsRk2Fs_KHVNQrgA", callContext.id);
controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCarousel_mvc_controller_Init_InitCarouselJS, "InitCarousel", "Init", {
WidgetId: OS.DataConversion.JSNodeParamConverter.to(idService.getId("carousel"), OS.DataTypes.DataTypes.Text)
}, function ($parameters) {
}, {
Previous: controller.clientActionProxies.previous$Action,
Next: controller.clientActionProxies.next$Action,
GoTo: controller.clientActionProxies.goTo$Action,
Update: controller.clientActionProxies.update$Action
}, {});
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:fPkdELPVeEKyty6PWuef9g", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:VTkN3JkAOEWs1ZfxGfd1QQ", callContext.id);
}

};
Controller.prototype._onInitialize$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnInitialize");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:U5LG8tidF0yQ9EIXI27oEQ:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.46DiDReT8k2RTrxf91EQTg/ClientActions.U5LG8tidF0yQ9EIXI27oEQ:m8CZhPnLF3Lktu6LpPEkog", "ShopperPortalEU_UI_Components", "OnInitialize", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:1VXMG80wwUeFH0NjGbUQHg", callContext.id);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:gUd6+ZaJ4Uy6SEWl758znA", callContext.id);
// IsAnimating = False
model.variables.isAnimatingVar = false;
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:K44+c4kPk0a4OePuKsRL0A", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:U5LG8tidF0yQ9EIXI27oEQ", callContext.id);
}

};

Controller.prototype.onParametersChanged$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onParametersChanged$Action, callContext);

};
Controller.prototype.setEventsStatus$Action = function (addEventsIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._setEventsStatus$Action, callContext, addEventsIn);

};
Controller.prototype.next$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._next$Action, callContext);

};
Controller.prototype.gestureStart$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._gestureStart$Action, callContext);

};
Controller.prototype.onReady$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onReady$Action, callContext);

};
Controller.prototype.onDestroy$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onDestroy$Action, callContext);

};
Controller.prototype.changeIsAnimatingStatus$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._changeIsAnimatingStatus$Action, callContext);

};
Controller.prototype.onOrientationChange$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onOrientationChange$Action, callContext);

};
Controller.prototype.update$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._update$Action, callContext);

};
Controller.prototype.goTo$Action = function (targetIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._goTo$Action, callContext, targetIn);

};
Controller.prototype.gestureEnd$Action = function (offsetXIn, timeTakenIn, elementhWidthIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._gestureEnd$Action, callContext, offsetXIn, timeTakenIn, elementhWidthIn);

};
Controller.prototype.gestureMove$Action = function (offsetXIn, evtIn, offsetYIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._gestureMove$Action, callContext, offsetXIn, evtIn, offsetYIn);

};
Controller.prototype.previous$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._previous$Action, callContext);

};
Controller.prototype.init$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._init$Action, callContext);

};
Controller.prototype.onInitialize$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onInitialize$Action, callContext);

};
Controller.prototype.onItemChange$Action = function () {
return Promise.resolve();
};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:7hC2bHqrKEmxvEuPSzIN0Q:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q:g5BtT+X6uN+vFl8t9PMqCQ", "ShopperPortalEU_UI_Components", "ShopperPortalEUUIComponents", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:46DiDReT8k2RTrxf91EQTg:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.46DiDReT8k2RTrxf91EQTg:PDRY8ALMdOCyOmPq9ELRBg", "ShopperPortalEU_UI_Components", "CustomCarousel", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:46DiDReT8k2RTrxf91EQTg", callContext.id);
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:7hC2bHqrKEmxvEuPSzIN0Q", callContext.id);
};
Controller.prototype.onInitializeEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "ShopperPortalEUUIComponents/CustomCarousel On Initialize");
return controller.onInitialize$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onReadyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "ShopperPortalEUUIComponents/CustomCarousel On Ready");
return controller.onReady$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "ShopperPortalEUUIComponents/CustomCarousel On Destroy");
return controller.onDestroy$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onParametersChangedEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "ShopperPortalEUUIComponents/CustomCarousel On Parameters Changed");
return controller.onParametersChanged$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return ShopperPortalEU_UI_ComponentsController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, ShopperPortalEU_UI_ComponentsLanguageResources);
});
define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.mvc$controller.Next.NextJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
if(document.body.classList.contains('is-rtl')) {
    $parameters.CarouselObj.previous();
} else {
    $parameters.CarouselObj.next();
}
};
});
define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.mvc$controller.GestureStart.AddNoTransitionClassesJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.CarouselObj.addNoTransitionClasses();
};
});
define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.mvc$controller.GestureStart.RemoveNoTransitionJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var el = document.getElementById($parameters.Id);
var carouselContent = el.querySelector(".carousel-container-content");

carouselContent.classList.remove("no-transition");
};
});
define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.mvc$controller.GestureStart.CheckIfContainsClassJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var carouselSwipe = document.getElementById($parameters.CarouselId);

if(carouselSwipe.classList.contains('no-swipe')){
    $parameters.ContainsClass = true;
} else {
    $parameters.ContainsClass = false;
}
};
});
define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.mvc$controller.OnReady.CallingInitJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
window.addEventListener('orientationchange', $actions.OnOrientationChange);
$parameters.CarouselObj = new newCarousel();
$parameters.CarouselObj.init({
    widgetId: $parameters.WidgetId,
    margin: 8,
    initialPosition: 0,
    itemsPhone: $parameters.Items,
    itemsTablet: $parameters.Items,
    itemsDesktop: $parameters.Items,
    center: false,
    scale: false,
    loop: false,
    dots: true,
    currentDevice: 'phone',
    isRTL: document.body.classList.contains('is-rtl'),
    //OS actions
    initAction: $actions.Init(),
    goToAction: $actions.GoTo,
    setEventsStatus: $actions.SetEventsStatus
});
};
});
define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.mvc$controller.OnDestroy.RemoveListnerOnOrientationJS", [], function () {
return function ($actions, $roles, $public) {
window.removeEventListener('orientationchange', $actions.OnOrientationChange);
};
});
define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.mvc$controller.OnOrientationChange.OnOrientationChangeJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.CarouselObj.onOrientationChange();
};
});
define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.mvc$controller.Update.UpdateJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.CarouselObj.updateCarousel();
};
});
define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.mvc$controller.GoTo.GetMaxElementsJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.MaxElements = $parameters.CarouselObj.getMaxElements();
};
});
define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.mvc$controller.GoTo.GoToTargetJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.CarouselObj.goTo($parameters.Target);
};
});
define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.mvc$controller.GoTo.GoToLastJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.CarouselObj.goTo($parameters.Target);
};
});
define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.mvc$controller.GestureEnd.PrepareElementsJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.CarouselObj.removeNoTransitionClasses();
$parameters.ElementWidth = $parameters.CarouselObj.getNodeWidth();
};
});
define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.mvc$controller.GestureEnd.ChangeIsAnimatingStatusJS", [], function () {
return function ($actions, $roles, $public) {
var TimeoutClear = setTimeout(function(){
    $actions.ChangeIsAnimatingStatus();
    clearTimeout(TimeoutClear);
},300);
};
});
define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.mvc$controller.GestureEnd.BackToMiddleJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.CarouselObj.backToMiddle();
};
});
define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.mvc$controller.GestureMove.TransformUiJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.CarouselObj.gestureMove($parameters.OffsetX);
$parameters.Evt.preventDefault();
};
});
define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.mvc$controller.GestureMove.AddNoTransitionClassesJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.CarouselObj.addNoTransitionClasses();
};
});
define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.mvc$controller.Previous.PreviousJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
if(document.body.classList.contains('is-rtl')) {
    $parameters.CarouselObj.next();
} else {
    $parameters.CarouselObj.previous();
}
};
});
define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.mvc$controller.Init.InitCarouselJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var element = document.getElementById($parameters.WidgetId);
element = element.querySelector('.carousel-container-content');
var isRTL = document.body.classList.contains('is-rtl');

// Add actions
element.next = function() { isRTL ? $actions.Previous() : $actions.Next() };
element.previous = function() { isRTL ? $actions.Next() : $actions.Previous() };
element.goto = function(i) { $actions.GoTo(i); };
element.updateCarousel = function() { $actions.Update(); };

};
});

define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCarousel.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"aTsij9jad06n9dJvJLOI+Q": {
getter: function (varBag, idService) {
return varBag.vars.value.addEventsInLocal;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"gIfraVrDlkGUz96uJTSEdQ": {
getter: function (varBag, idService) {
return varBag.nextJSResult.value;
}
},
"KE+0fX41sEGIcXtnb6tTAA": {
getter: function (varBag, idService) {
return varBag.addNoTransitionClassesJSResult.value;
}
},
"Ht1ktBiZ5kq07PfsELLDWw": {
getter: function (varBag, idService) {
return varBag.removeNoTransitionJSResult.value;
}
},
"HvrDw2d0t02_i9fu3eqOzA": {
getter: function (varBag, idService) {
return varBag.checkIfContainsClassJSResult.value;
}
},
"9XeswM3u9k6CJpxBTpDIpA": {
getter: function (varBag, idService) {
return varBag.callingInitJSResult.value;
}
},
"W1t6BBxd00C1nhMP5EASow": {
getter: function (varBag, idService) {
return varBag.removeListnerOnOrientationJSResult.value;
}
},
"sP9971wFE0iJ2neXGKFthw": {
getter: function (varBag, idService) {
return varBag.onOrientationChangeJSResult.value;
}
},
"I4_KJ7V0P0mEEeZEJUG1Cg": {
getter: function (varBag, idService) {
return varBag.updateJSResult.value;
}
},
"Aq7BzAAq10OatUbXvzbAjA": {
getter: function (varBag, idService) {
return varBag.vars.value.targetInLocal;
},
dataType: OS.DataTypes.DataTypes.Integer
},
"G3I7K60GLkKgRc2i1YV41w": {
getter: function (varBag, idService) {
return varBag.getMaxElementsJSResult.value;
}
},
"3Q_mKzxeeEawbke77N4jbQ": {
getter: function (varBag, idService) {
return varBag.goToTargetJSResult.value;
}
},
"p_Tex__UG0yQrRHPI7yd5w": {
getter: function (varBag, idService) {
return varBag.goToLastJSResult.value;
}
},
"phVuJqBvWE+aI5ylUylUOw": {
getter: function (varBag, idService) {
return varBag.vars.value.offsetXInLocal;
},
dataType: OS.DataTypes.DataTypes.Decimal
},
"Y+PqUuJULEyW7s6O4BC+8A": {
getter: function (varBag, idService) {
return varBag.vars.value.timeTakenInLocal;
},
dataType: OS.DataTypes.DataTypes.Decimal
},
"97HO7JYxDkqfY9lGmmMraQ": {
getter: function (varBag, idService) {
return varBag.vars.value.elementhWidthInLocal;
},
dataType: OS.DataTypes.DataTypes.Integer
},
"DW9wXLPz5EyPZ5KUAH9AJQ": {
getter: function (varBag, idService) {
return varBag.prepareElementsJSResult.value;
}
},
"3xUvYNWufESezJLHFHyheQ": {
getter: function (varBag, idService) {
return varBag.changeIsAnimatingStatusJSResult.value;
}
},
"+gsp3wqmp0mj6oNrQ3bsaQ": {
getter: function (varBag, idService) {
return varBag.backToMiddleJSResult.value;
}
},
"yiTlWdms4U29+bzVA4QpLA": {
getter: function (varBag, idService) {
return varBag.vars.value.offsetXInLocal;
},
dataType: OS.DataTypes.DataTypes.Decimal
},
"V4nbXWZ53kumcSrGOKnSqw": {
getter: function (varBag, idService) {
return varBag.vars.value.evtInLocal;
},
dataType: OS.DataTypes.DataTypes.Object
},
"KTm0_BDz2kys_lGyfPL_xw": {
getter: function (varBag, idService) {
return varBag.vars.value.offsetYInLocal;
},
dataType: OS.DataTypes.DataTypes.Decimal
},
"4SDtB0lWHUW5_BiGczG3jQ": {
getter: function (varBag, idService) {
return varBag.transformUiJSResult.value;
}
},
"6zj0pPZqm0eGLjdm5MSGcw": {
getter: function (varBag, idService) {
return varBag.addNoTransitionClassesJSResult.value;
}
},
"MjtW46K3jEupwGpJKFHVMQ": {
getter: function (varBag, idService) {
return varBag.previousJSResult.value;
}
},
"D2CO6dGsRk2Fs_KHVNQrgA": {
getter: function (varBag, idService) {
return varBag.initCarouselJSResult.value;
}
},
"08_dkn942k2NgKTWsCrpsQ": {
getter: function (varBag, idService) {
return varBag.model.variables.carouselObjVar;
},
dataType: OS.DataTypes.DataTypes.Object
},
"uMZtIW_9AUqM4GyIvaxeUA": {
getter: function (varBag, idService) {
return varBag.model.variables.velocityVar;
},
dataType: OS.DataTypes.DataTypes.Decimal
},
"tW7FgFnCRkCf2twqjVOaSQ": {
getter: function (varBag, idService) {
return varBag.model.variables.isAnimatingVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"AIs4lGqq8UG5UzHGRRleRg": {
getter: function (varBag, idService) {
return varBag.model.variables.containsClassVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"HeqsvZ1BVE+BjAVFCUys2g": {
getter: function (varBag, idService) {
return varBag.model.variables.dragDirectionVar;
},
dataType: OS.DataTypes.DataTypes.Text
},
"a9likR6Ru02KUsAxnDietA": {
getter: function (varBag, idService) {
return varBag.model.variables.addDragEventsVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"jvpdNm0C6kKIH6CVm5+t7g": {
getter: function (varBag, idService) {
return varBag.model.variables.optionsIn;
}
},
"wt1sQPIhuUmNS+3ZsHU89w": {
getter: function (varBag, idService) {
return varBag.model.variables.extendedClassIn;
},
dataType: OS.DataTypes.DataTypes.Text
},
"kwAkjf3slEmQnW3zN2HG8Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("carousel"));
})(varBag.model, idService);
}
},
"qDhgVOZ1JU2q8yAHSKhRag": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Items"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
