define("ShopperPortalEU_UI_Components.model$CustomListItemClickableOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomListItemClickableOptionsRec = (function (_super) {
__extends(CustomListItemClickableOptionsRec, _super);
function CustomListItemClickableOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomListItemClickableOptionsRec.attributesToDeclare = function () {
return [
this.attr("Clickable", "clickableAttr", "clickable", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("HideIcon", "hideIconAttr", "hideIcon", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("Icon", "iconAttr", "icon", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomListItemClickableOptionsRec.init();
return CustomListItemClickableOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomListItemClickableOptionsRec = CustomListItemClickableOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomListItemOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomListItemClickableOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomListItemOptionsRec = (function (_super) {
__extends(CustomListItemOptionsRec, _super);
function CustomListItemOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomListItemOptionsRec.attributesToDeclare = function () {
return [
this.attr("TestId", "testIdAttr", "testId", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("IsDisabled", "isDisabledAttr", "disabled", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("Clickable", "clickableAttr", "clickable", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomListItemClickableOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomListItemClickableOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomListItemOptionsRec.init();
return CustomListItemOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomListItemOptionsRec = CustomListItemOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomListItemOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomListItemOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomListItemOptionsRecord = (function (_super) {
__extends(CustomListItemOptionsRecord, _super);
function CustomListItemOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomListItemOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomListItemOptions", "customListItemOptionsAttr", "CustomListItemOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomListItemOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomListItemOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomListItemOptionsRecord.fromStructure = function (str) {
return new CustomListItemOptionsRecord(new CustomListItemOptionsRecord.RecordClass({
customListItemOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomListItemOptionsRecord._isAnonymousRecord = true;
CustomListItemOptionsRecord.UniqueId = "00254d6f-7d70-27ff-8218-83d7da5437ac";
CustomListItemOptionsRecord.init();
return CustomListItemOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomListItemOptionsRecord = CustomListItemOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$MonthYearInputValidationOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var MonthYearInputValidationOptionsRec = (function (_super) {
__extends(MonthYearInputValidationOptionsRec, _super);
function MonthYearInputValidationOptionsRec(defaults) {
_super.apply(this, arguments);
}
MonthYearInputValidationOptionsRec.attributesToDeclare = function () {
return [
this.attr("State", "stateAttr", "state", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Message", "messageAttr", "message", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
MonthYearInputValidationOptionsRec.init();
return MonthYearInputValidationOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.MonthYearInputValidationOptionsRec = MonthYearInputValidationOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$MonthYearInputValidationOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$MonthYearInputValidationOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var MonthYearInputValidationOptionsRecord = (function (_super) {
__extends(MonthYearInputValidationOptionsRecord, _super);
function MonthYearInputValidationOptionsRecord(defaults) {
_super.apply(this, arguments);
}
MonthYearInputValidationOptionsRecord.attributesToDeclare = function () {
return [
this.attr("MonthYearInputValidationOptions", "monthYearInputValidationOptionsAttr", "MonthYearInputValidationOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.MonthYearInputValidationOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.MonthYearInputValidationOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
MonthYearInputValidationOptionsRecord.fromStructure = function (str) {
return new MonthYearInputValidationOptionsRecord(new MonthYearInputValidationOptionsRecord.RecordClass({
monthYearInputValidationOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
MonthYearInputValidationOptionsRecord._isAnonymousRecord = true;
MonthYearInputValidationOptionsRecord.UniqueId = "00ad801d-8e61-15ba-3af3-671621c02459";
MonthYearInputValidationOptionsRecord.init();
return MonthYearInputValidationOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.MonthYearInputValidationOptionsRecord = MonthYearInputValidationOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomListItemClickableOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomListItemClickableOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomListItemClickableOptionsList = (function (_super) {
__extends(CustomListItemClickableOptionsList, _super);
function CustomListItemClickableOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomListItemClickableOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomListItemClickableOptionsRec;
return CustomListItemClickableOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomListItemClickableOptionsList = CustomListItemClickableOptionsList;

});
define("ShopperPortalEU_UI_Components.model$DatePickerLabelOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var DatePickerLabelOptionsRec = (function (_super) {
__extends(DatePickerLabelOptionsRec, _super);
function DatePickerLabelOptionsRec(defaults) {
_super.apply(this, arguments);
}
DatePickerLabelOptionsRec.attributesToDeclare = function () {
return [
this.attr("Title", "titleAttr", "title", false, false, OS.DataTypes.DataTypes.Text, function () {
return "Select date";
}, true), 
this.attr("Cancel", "cancelAttr", "cancel", false, false, OS.DataTypes.DataTypes.Text, function () {
return "Cancel";
}, true), 
this.attr("Ok", "okAttr", "ok", false, false, OS.DataTypes.DataTypes.Text, function () {
return "Ok";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
DatePickerLabelOptionsRec.init();
return DatePickerLabelOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.DatePickerLabelOptionsRec = DatePickerLabelOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$ScanBarcodeErrorRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var ScanBarcodeErrorRec = (function (_super) {
__extends(ScanBarcodeErrorRec, _super);
function ScanBarcodeErrorRec(defaults) {
_super.apply(this, arguments);
}
ScanBarcodeErrorRec.attributesToDeclare = function () {
return [
this.attr("Code", "codeAttr", "code", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Message", "messageAttr", "message", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ScanBarcodeErrorRec.init();
return ScanBarcodeErrorRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.ScanBarcodeErrorRec = ScanBarcodeErrorRec;

});
define("ShopperPortalEU_UI_Components.model$ScanBarcodeErrorList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$ScanBarcodeErrorRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var ScanBarcodeErrorList = (function (_super) {
__extends(ScanBarcodeErrorList, _super);
function ScanBarcodeErrorList(defaults) {
_super.apply(this, arguments);
}
ScanBarcodeErrorList.itemType = ShopperPortalEU_UI_ComponentsModel.ScanBarcodeErrorRec;
return ScanBarcodeErrorList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.ScanBarcodeErrorList = ScanBarcodeErrorList;

});
define("ShopperPortalEU_UI_Components.model$PhoneNumberInputCountryOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var PhoneNumberInputCountryOptionsRec = (function (_super) {
__extends(PhoneNumberInputCountryOptionsRec, _super);
function PhoneNumberInputCountryOptionsRec(defaults) {
_super.apply(this, arguments);
}
PhoneNumberInputCountryOptionsRec.attributesToDeclare = function () {
return [
this.attr("Code", "codeAttr", "code", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Name", "nameAttr", "name", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("DialCode", "dialCodeAttr", "dialCode", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PhoneNumberInputCountryOptionsRec.init();
return PhoneNumberInputCountryOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputCountryOptionsRec = PhoneNumberInputCountryOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$PhoneNumberInputChangeOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$PhoneNumberInputCountryOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var PhoneNumberInputChangeOptionsRec = (function (_super) {
__extends(PhoneNumberInputChangeOptionsRec, _super);
function PhoneNumberInputChangeOptionsRec(defaults) {
_super.apply(this, arguments);
}
PhoneNumberInputChangeOptionsRec.attributesToDeclare = function () {
return [
this.attr("PhoneNumber", "phoneNumberAttr", "phoneNumber", false, false, OS.DataTypes.DataTypes.PhoneNumber, function () {
return "";
}, true), 
this.attr("FormattedPhoneNumber", "formattedPhoneNumberAttr", "formattedPhoneNumber", false, false, OS.DataTypes.DataTypes.PhoneNumber, function () {
return "";
}, true), 
this.attr("Valid", "validAttr", "valid", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("Country", "countryAttr", "country", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputCountryOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputCountryOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
PhoneNumberInputChangeOptionsRec.init();
return PhoneNumberInputChangeOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputChangeOptionsRec = PhoneNumberInputChangeOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$PhoneNumberInputChangeOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$PhoneNumberInputChangeOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var PhoneNumberInputChangeOptionsList = (function (_super) {
__extends(PhoneNumberInputChangeOptionsList, _super);
function PhoneNumberInputChangeOptionsList(defaults) {
_super.apply(this, arguments);
}
PhoneNumberInputChangeOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputChangeOptionsRec;
return PhoneNumberInputChangeOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputChangeOptionsList = PhoneNumberInputChangeOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomTagOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomTagOptionsRec = (function (_super) {
__extends(CustomTagOptionsRec, _super);
function CustomTagOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomTagOptionsRec.attributesToDeclare = function () {
return [
this.attr("TestId", "testIdAttr", "testId", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("State", "stateAttr", "state", false, false, OS.DataTypes.DataTypes.Text, function () {
return ShopperPortalEU_UI_ComponentsModel.staticEntities.customTagState.success;
}, true), 
this.attr("IsInline", "isInlineAttr", "isInline", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomTagOptionsRec.init();
return CustomTagOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomTagOptionsRec = CustomTagOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomTagOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomTagOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomTagOptionsList = (function (_super) {
__extends(CustomTagOptionsList, _super);
function CustomTagOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomTagOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomTagOptionsRec;
return CustomTagOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomTagOptionsList = CustomTagOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomLinkOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomLinkOptionsRec = (function (_super) {
__extends(CustomLinkOptionsRec, _super);
function CustomLinkOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomLinkOptionsRec.attributesToDeclare = function () {
return [
this.attr("TestId", "testIdAttr", "testId", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Type", "typeAttr", "type", false, false, OS.DataTypes.DataTypes.Text, function () {
return ShopperPortalEU_UI_ComponentsModel.staticEntities.customLinkType.primary;
}, true), 
this.attr("State", "stateAttr", "state", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("IsLoading", "isLoadingAttr", "loading", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("IsFullWidth", "isFullWidthAttr", "fullWidth", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomLinkOptionsRec.init();
return CustomLinkOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomLinkOptionsRec = CustomLinkOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomLinkOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomLinkOptionsList = (function (_super) {
__extends(CustomLinkOptionsList, _super);
function CustomLinkOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomLinkOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomLinkOptionsRec;
return CustomLinkOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomLinkOptionsList = CustomLinkOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomUploadFileOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomUploadFileOptionsRec = (function (_super) {
__extends(CustomUploadFileOptionsRec, _super);
function CustomUploadFileOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomUploadFileOptionsRec.attributesToDeclare = function () {
return [
this.attr("Content", "contentAttr", "content", false, false, OS.DataTypes.DataTypes.BinaryData, function () {
return OS.DataTypes.BinaryData.defaultValue;
}, true), 
this.attr("Name", "nameAttr", "name", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Type", "typeAttr", "type", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomUploadFileOptionsRec.init();
return CustomUploadFileOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomUploadFileOptionsRec = CustomUploadFileOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomUploadFileOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomUploadFileOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomUploadFileOptionsList = (function (_super) {
__extends(CustomUploadFileOptionsList, _super);
function CustomUploadFileOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomUploadFileOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomUploadFileOptionsRec;
return CustomUploadFileOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomUploadFileOptionsList = CustomUploadFileOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomUploadCameraOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomUploadCameraOptionsRec = (function (_super) {
__extends(CustomUploadCameraOptionsRec, _super);
function CustomUploadCameraOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomUploadCameraOptionsRec.attributesToDeclare = function () {
return [
this.attr("Trigger", "triggerAttr", "trigger", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("Icon", "iconAttr", "Icon", false, false, OS.DataTypes.DataTypes.Text, function () {
return "icon-planet-deprecated-camera";
}, true), 
this.attr("Label", "labelAttr", "Label", false, false, OS.DataTypes.DataTypes.Text, function () {
return "Take a photo";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomUploadCameraOptionsRec.init();
return CustomUploadCameraOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomUploadCameraOptionsRec = CustomUploadCameraOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomUploadOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomUploadFileOptionsList", "ShopperPortalEU_UI_Components.model$CustomUploadCameraOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomUploadOptionsRec = (function (_super) {
__extends(CustomUploadOptionsRec, _super);
function CustomUploadOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomUploadOptionsRec.attributesToDeclare = function () {
return [
this.attr("Files", "filesAttr", "files", false, false, OS.DataTypes.DataTypes.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomUploadFileOptionsList());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomUploadFileOptionsList), 
this.attr("Accept", "acceptAttr", "accept", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("MultipleFiles", "multipleFilesAttr", "multiple", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("Icon", "iconAttr", "icon", false, false, OS.DataTypes.DataTypes.Text, function () {
return "attach_file";
}, true), 
this.attr("DisableItemClick", "disableItemClickAttr", "disableItemClick", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("HideList", "hideListAttr", "hideList", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("Camera", "cameraAttr", "camera", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomUploadCameraOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomUploadCameraOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomUploadOptionsRec.init();
return CustomUploadOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomUploadOptionsRec = CustomUploadOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomUploadOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomUploadOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomUploadOptionsList = (function (_super) {
__extends(CustomUploadOptionsList, _super);
function CustomUploadOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomUploadOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomUploadOptionsRec;
return CustomUploadOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomUploadOptionsList = CustomUploadOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownListValidationOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownListValidationOptionsRec = (function (_super) {
__extends(CustomDropdownListValidationOptionsRec, _super);
function CustomDropdownListValidationOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomDropdownListValidationOptionsRec.attributesToDeclare = function () {
return [
this.attr("State", "stateAttr", "state", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Message", "messageAttr", "message", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomDropdownListValidationOptionsRec.init();
return CustomDropdownListValidationOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValidationOptionsRec = CustomDropdownListValidationOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownListValidationOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomDropdownListValidationOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownListValidationOptionsRecord = (function (_super) {
__extends(CustomDropdownListValidationOptionsRecord, _super);
function CustomDropdownListValidationOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomDropdownListValidationOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomDropdownListValidationOptions", "customDropdownListValidationOptionsAttr", "CustomDropdownListValidationOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValidationOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValidationOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomDropdownListValidationOptionsRecord.fromStructure = function (str) {
return new CustomDropdownListValidationOptionsRecord(new CustomDropdownListValidationOptionsRecord.RecordClass({
customDropdownListValidationOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomDropdownListValidationOptionsRecord._isAnonymousRecord = true;
CustomDropdownListValidationOptionsRecord.UniqueId = "03c542a1-666f-a38b-797e-c900dd937fce";
CustomDropdownListValidationOptionsRecord.init();
return CustomDropdownListValidationOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValidationOptionsRecord = CustomDropdownListValidationOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$ProgressBarOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var ProgressBarOptionsRec = (function (_super) {
__extends(ProgressBarOptionsRec, _super);
function ProgressBarOptionsRec(defaults) {
_super.apply(this, arguments);
}
ProgressBarOptionsRec.attributesToDeclare = function () {
return [
this.attr("TestId", "testIdAttr", "testId", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Progress", "progressAttr", "progress", true, false, OS.DataTypes.DataTypes.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("Steps", "stepsAttr", "steps", false, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ProgressBarOptionsRec.init();
return ProgressBarOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.ProgressBarOptionsRec = ProgressBarOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$ProgressBarOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$ProgressBarOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var ProgressBarOptionsRecord = (function (_super) {
__extends(ProgressBarOptionsRecord, _super);
function ProgressBarOptionsRecord(defaults) {
_super.apply(this, arguments);
}
ProgressBarOptionsRecord.attributesToDeclare = function () {
return [
this.attr("ProgressBarOptions", "progressBarOptionsAttr", "ProgressBarOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.ProgressBarOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.ProgressBarOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
ProgressBarOptionsRecord.fromStructure = function (str) {
return new ProgressBarOptionsRecord(new ProgressBarOptionsRecord.RecordClass({
progressBarOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ProgressBarOptionsRecord._isAnonymousRecord = true;
ProgressBarOptionsRecord.UniqueId = "1700a48e-e34c-4f19-2a0c-cbcc96f0afed";
ProgressBarOptionsRecord.init();
return ProgressBarOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.ProgressBarOptionsRecord = ProgressBarOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$ProgressBarOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$ProgressBarOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var ProgressBarOptionsRecordList = (function (_super) {
__extends(ProgressBarOptionsRecordList, _super);
function ProgressBarOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
ProgressBarOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.ProgressBarOptionsRecord;
return ProgressBarOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.ProgressBarOptionsRecordList = ProgressBarOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$FullHeightContentTopOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var FullHeightContentTopOptionsRec = (function (_super) {
__extends(FullHeightContentTopOptionsRec, _super);
function FullHeightContentTopOptionsRec(defaults) {
_super.apply(this, arguments);
}
FullHeightContentTopOptionsRec.attributesToDeclare = function () {
return [
this.attr("VerticalAlignment", "verticalAlignmentAttr", "verticalAlignment", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("HorizontalAlignment", "horizontalAlignmentAttr", "horizontalAlignment", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("HasPadding", "hasPaddingAttr", "hasPadding", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
FullHeightContentTopOptionsRec.init();
return FullHeightContentTopOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.FullHeightContentTopOptionsRec = FullHeightContentTopOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomCarouselOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomCarouselOptionsRec = (function (_super) {
__extends(CustomCarouselOptionsRec, _super);
function CustomCarouselOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomCarouselOptionsRec.attributesToDeclare = function () {
return [
this.attr("Items", "itemsAttr", "items", false, false, OS.DataTypes.DataTypes.Integer, function () {
return 1;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomCarouselOptionsRec.fromStructure = function (str) {
return new CustomCarouselOptionsRec(new CustomCarouselOptionsRec.RecordClass({
itemsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomCarouselOptionsRec.init();
return CustomCarouselOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomCarouselOptionsRec = CustomCarouselOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomCarouselOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomCarouselOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomCarouselOptionsRecord = (function (_super) {
__extends(CustomCarouselOptionsRecord, _super);
function CustomCarouselOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomCarouselOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomCarouselOptions", "customCarouselOptionsAttr", "CustomCarouselOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomCarouselOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomCarouselOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomCarouselOptionsRecord.fromStructure = function (str) {
return new CustomCarouselOptionsRecord(new CustomCarouselOptionsRecord.RecordClass({
customCarouselOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomCarouselOptionsRecord._isAnonymousRecord = true;
CustomCarouselOptionsRecord.UniqueId = "04f946c7-498b-8efa-b431-1a3e2da81bc7";
CustomCarouselOptionsRecord.init();
return CustomCarouselOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomCarouselOptionsRecord = CustomCarouselOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$ButtonOptionTypeRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var ButtonOptionTypeRec = (function (_super) {
__extends(ButtonOptionTypeRec, _super);
function ButtonOptionTypeRec(defaults) {
_super.apply(this, arguments);
}
ButtonOptionTypeRec.attributesToDeclare = function () {
return [
this.attr("Class", "classAttr", "Class", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ButtonOptionTypeRec.fromStructure = function (str) {
return new ButtonOptionTypeRec(new ButtonOptionTypeRec.RecordClass({
classAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ButtonOptionTypeRec.init();
return ButtonOptionTypeRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.ButtonOptionTypeRec = ButtonOptionTypeRec;

});
define("ShopperPortalEU_UI_Components.model$ButtonOptionTypeRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$ButtonOptionTypeRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var ButtonOptionTypeRecord = (function (_super) {
__extends(ButtonOptionTypeRecord, _super);
function ButtonOptionTypeRecord(defaults) {
_super.apply(this, arguments);
}
ButtonOptionTypeRecord.attributesToDeclare = function () {
return [
this.attr("ButtonOptionType", "buttonOptionTypeAttr", "ButtonOptionType", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.ButtonOptionTypeRec());
}, true, ShopperPortalEU_UI_ComponentsModel.ButtonOptionTypeRec)
].concat(_super.attributesToDeclare.call(this));
};
ButtonOptionTypeRecord.fromStructure = function (str) {
return new ButtonOptionTypeRecord(new ButtonOptionTypeRecord.RecordClass({
buttonOptionTypeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ButtonOptionTypeRecord._isAnonymousRecord = true;
ButtonOptionTypeRecord.UniqueId = "bd7a406d-df0c-62e1-fa88-57d85d9b1060";
ButtonOptionTypeRecord.init();
return ButtonOptionTypeRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.ButtonOptionTypeRecord = ButtonOptionTypeRecord;

});
define("ShopperPortalEU_UI_Components.model$ButtonOptionTypeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$ButtonOptionTypeRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var ButtonOptionTypeRecordList = (function (_super) {
__extends(ButtonOptionTypeRecordList, _super);
function ButtonOptionTypeRecordList(defaults) {
_super.apply(this, arguments);
}
ButtonOptionTypeRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.ButtonOptionTypeRecord;
return ButtonOptionTypeRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.ButtonOptionTypeRecordList = ButtonOptionTypeRecordList;

});
define("ShopperPortalEU_UI_Components.model$OpenPDFOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var OpenPDFOptionsRec = (function (_super) {
__extends(OpenPDFOptionsRec, _super);
function OpenPDFOptionsRec(defaults) {
_super.apply(this, arguments);
}
OpenPDFOptionsRec.attributesToDeclare = function () {
return [
this.attr("PDF", "pDFAttr", "pdf", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
OpenPDFOptionsRec.fromStructure = function (str) {
return new OpenPDFOptionsRec(new OpenPDFOptionsRec.RecordClass({
pDFAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
OpenPDFOptionsRec.init();
return OpenPDFOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.OpenPDFOptionsRec = OpenPDFOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$OpenPDFOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$OpenPDFOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var OpenPDFOptionsRecord = (function (_super) {
__extends(OpenPDFOptionsRecord, _super);
function OpenPDFOptionsRecord(defaults) {
_super.apply(this, arguments);
}
OpenPDFOptionsRecord.attributesToDeclare = function () {
return [
this.attr("OpenPDFOptions", "openPDFOptionsAttr", "OpenPDFOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.OpenPDFOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.OpenPDFOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
OpenPDFOptionsRecord.fromStructure = function (str) {
return new OpenPDFOptionsRecord(new OpenPDFOptionsRecord.RecordClass({
openPDFOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
OpenPDFOptionsRecord._isAnonymousRecord = true;
OpenPDFOptionsRecord.UniqueId = "05a0130e-844c-1ea6-7927-9b822b1d1325";
OpenPDFOptionsRecord.init();
return OpenPDFOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.OpenPDFOptionsRecord = OpenPDFOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomInputIconOptionRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomInputIconOptionRec = (function (_super) {
__extends(CustomInputIconOptionRec, _super);
function CustomInputIconOptionRec(defaults) {
_super.apply(this, arguments);
}
CustomInputIconOptionRec.attributesToDeclare = function () {
return [
this.attr("Name", "nameAttr", "name", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Family", "familyAttr", "family", false, false, OS.DataTypes.DataTypes.Text, function () {
return ShopperPortalEU_UI_ComponentsModel.staticEntities.customIconFamily.material;
}, true), 
this.attr("IsClickable", "isClickableAttr", "clickable", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("IsFilled", "isFilledAttr", "filled", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomInputIconOptionRec.init();
return CustomInputIconOptionRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomInputIconOptionRec = CustomInputIconOptionRec;

});
define("ShopperPortalEU_UI_Components.model$CustomInputValidationOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomInputValidationOptionsRec = (function (_super) {
__extends(CustomInputValidationOptionsRec, _super);
function CustomInputValidationOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomInputValidationOptionsRec.attributesToDeclare = function () {
return [
this.attr("State", "stateAttr", "state", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Message", "messageAttr", "message", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("IsValidationMessageAbsolute", "isValidationMessageAbsoluteAttr", "validationMessageAbsolute", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomInputValidationOptionsRec.init();
return CustomInputValidationOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomInputValidationOptionsRec = CustomInputValidationOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomInputOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomInputIconOptionRec", "ShopperPortalEU_UI_Components.model$CustomInputValidationOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomInputOptionsRec = (function (_super) {
__extends(CustomInputOptionsRec, _super);
function CustomInputOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomInputOptionsRec.attributesToDeclare = function () {
return [
this.attr("TestId", "testIdAttr", "testId", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("HasMaxLengthCounter", "hasMaxLengthCounterAttr", "maxLengthCounter", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("Alignment", "alignmentAttr", "alignment", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("TopLabel", "topLabelAttr", "topLabel", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return true;
}, true), 
this.attr("Icon", "iconAttr", "icon", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomInputIconOptionRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomInputIconOptionRec), 
this.attr("IconSecondary", "iconSecondaryAttr", "iconSecondary", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomInputIconOptionRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomInputIconOptionRec), 
this.attr("Validation", "validationAttr", "validation", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomInputValidationOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomInputValidationOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomInputOptionsRec.init();
return CustomInputOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomInputOptionsRec = CustomInputOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomButtonStateRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomButtonStateRec = (function (_super) {
__extends(CustomButtonStateRec, _super);
function CustomButtonStateRec(defaults) {
_super.apply(this, arguments);
}
CustomButtonStateRec.attributesToDeclare = function () {
return [
this.attr("Class", "classAttr", "Class", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomButtonStateRec.fromStructure = function (str) {
return new CustomButtonStateRec(new CustomButtonStateRec.RecordClass({
classAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomButtonStateRec.init();
return CustomButtonStateRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomButtonStateRec = CustomButtonStateRec;

});
define("ShopperPortalEU_UI_Components.model$CustomButtonStateList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomButtonStateRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomButtonStateList = (function (_super) {
__extends(CustomButtonStateList, _super);
function CustomButtonStateList(defaults) {
_super.apply(this, arguments);
}
CustomButtonStateList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomButtonStateRec;
return CustomButtonStateList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomButtonStateList = CustomButtonStateList;

});
define("ShopperPortalEU_UI_Components.model$CardStateOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CardStateOptionsRec = (function (_super) {
__extends(CardStateOptionsRec, _super);
function CardStateOptionsRec(defaults) {
_super.apply(this, arguments);
}
CardStateOptionsRec.attributesToDeclare = function () {
return [
this.attr("TestId", "testIdAttr", "testId", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Type", "typeAttr", "type", false, false, OS.DataTypes.DataTypes.Text, function () {
return ShopperPortalEU_UI_ComponentsModel.staticEntities.cardStateType.info;
}, true), 
this.attr("Clickable", "clickableAttr", "clickable", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CardStateOptionsRec.init();
return CardStateOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CardStateOptionsRec = CardStateOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CardStateOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CardStateOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CardStateOptionsRecord = (function (_super) {
__extends(CardStateOptionsRecord, _super);
function CardStateOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CardStateOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CardStateOptions", "cardStateOptionsAttr", "CardStateOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CardStateOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CardStateOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CardStateOptionsRecord.fromStructure = function (str) {
return new CardStateOptionsRecord(new CardStateOptionsRecord.RecordClass({
cardStateOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CardStateOptionsRecord._isAnonymousRecord = true;
CardStateOptionsRecord.UniqueId = "68932cad-17b9-73cf-5bdb-acde7e3be66f";
CardStateOptionsRecord.init();
return CardStateOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CardStateOptionsRecord = CardStateOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CardStateOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CardStateOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CardStateOptionsRecordList = (function (_super) {
__extends(CardStateOptionsRecordList, _super);
function CardStateOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CardStateOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CardStateOptionsRecord;
return CardStateOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CardStateOptionsRecordList = CardStateOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownSearchOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownSearchOptionsRec = (function (_super) {
__extends(CustomDropdownSearchOptionsRec, _super);
function CustomDropdownSearchOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomDropdownSearchOptionsRec.attributesToDeclare = function () {
return [
this.attr("Placeholder", "placeholderAttr", "placeholder", false, false, OS.DataTypes.DataTypes.Text, function () {
return "Search";
}, true), 
this.attr("EmptyMessage", "emptyMessageAttr", "emptyMessage", false, false, OS.DataTypes.DataTypes.Text, function () {
return "No results found";
}, true), 
this.attr("EmptyDescription", "emptyDescriptionAttr", "emptyDescription", false, false, OS.DataTypes.DataTypes.Text, function () {
return "Try search for something else.";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomDropdownSearchOptionsRec.init();
return CustomDropdownSearchOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownSearchOptionsRec = CustomDropdownSearchOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownSearchOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomDropdownSearchOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownSearchOptionsRecord = (function (_super) {
__extends(CustomDropdownSearchOptionsRecord, _super);
function CustomDropdownSearchOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomDropdownSearchOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomDropdownSearchOptions", "customDropdownSearchOptionsAttr", "CustomDropdownSearchOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomDropdownSearchOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomDropdownSearchOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomDropdownSearchOptionsRecord.fromStructure = function (str) {
return new CustomDropdownSearchOptionsRecord(new CustomDropdownSearchOptionsRecord.RecordClass({
customDropdownSearchOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomDropdownSearchOptionsRecord._isAnonymousRecord = true;
CustomDropdownSearchOptionsRecord.UniqueId = "1983924b-5f5d-c36b-652c-58ae05f45c86";
CustomDropdownSearchOptionsRecord.init();
return CustomDropdownSearchOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownSearchOptionsRecord = CustomDropdownSearchOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownSearchOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomDropdownSearchOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownSearchOptionsRecordList = (function (_super) {
__extends(CustomDropdownSearchOptionsRecordList, _super);
function CustomDropdownSearchOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownSearchOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomDropdownSearchOptionsRecord;
return CustomDropdownSearchOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownSearchOptionsRecordList = CustomDropdownSearchOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$PaddingSideOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var PaddingSideOptionsRec = (function (_super) {
__extends(PaddingSideOptionsRec, _super);
function PaddingSideOptionsRec(defaults) {
_super.apply(this, arguments);
}
PaddingSideOptionsRec.attributesToDeclare = function () {
return [
this.attr("Layout", "layoutAttr", "Layout", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("Spacing", "spacingAttr", "spacing", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PaddingSideOptionsRec.init();
return PaddingSideOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.PaddingSideOptionsRec = PaddingSideOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$PaddingRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$PaddingSideOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var PaddingRec = (function (_super) {
__extends(PaddingRec, _super);
function PaddingRec(defaults) {
_super.apply(this, arguments);
}
PaddingRec.attributesToDeclare = function () {
return [
this.attr("Top", "topAttr", "top", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.PaddingSideOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.PaddingSideOptionsRec), 
this.attr("Right", "rightAttr", "right", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.PaddingSideOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.PaddingSideOptionsRec), 
this.attr("Bottom", "bottomAttr", "bottom", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.PaddingSideOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.PaddingSideOptionsRec), 
this.attr("Left", "leftAttr", "left", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.PaddingSideOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.PaddingSideOptionsRec), 
this.attr("FullHeight", "fullHeightAttr", "fullHeight", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PaddingRec.init();
return PaddingRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.PaddingRec = PaddingRec;

});
define("ShopperPortalEU_UI_Components.model$ScanBarcodeDataRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var ScanBarcodeDataRec = (function (_super) {
__extends(ScanBarcodeDataRec, _super);
function ScanBarcodeDataRec(defaults) {
_super.apply(this, arguments);
}
ScanBarcodeDataRec.attributesToDeclare = function () {
return [
this.attr("Value", "valueAttr", "value", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Format", "formatAttr", "format", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ScanBarcodeDataRec.init();
return ScanBarcodeDataRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.ScanBarcodeDataRec = ScanBarcodeDataRec;

});
define("ShopperPortalEU_UI_Components.model$TextEllipsisReadMoreOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var TextEllipsisReadMoreOptionsRec = (function (_super) {
__extends(TextEllipsisReadMoreOptionsRec, _super);
function TextEllipsisReadMoreOptionsRec(defaults) {
_super.apply(this, arguments);
}
TextEllipsisReadMoreOptionsRec.attributesToDeclare = function () {
return [
this.attr("Label", "labelAttr", "label", false, false, OS.DataTypes.DataTypes.Text, function () {
return "Read more";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
TextEllipsisReadMoreOptionsRec.fromStructure = function (str) {
return new TextEllipsisReadMoreOptionsRec(new TextEllipsisReadMoreOptionsRec.RecordClass({
labelAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
TextEllipsisReadMoreOptionsRec.init();
return TextEllipsisReadMoreOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.TextEllipsisReadMoreOptionsRec = TextEllipsisReadMoreOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomButtonGroupOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomButtonGroupOptionsRec = (function (_super) {
__extends(CustomButtonGroupOptionsRec, _super);
function CustomButtonGroupOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomButtonGroupOptionsRec.attributesToDeclare = function () {
return [
this.attr("Orientation", "orientationAttr", "orientation", false, false, OS.DataTypes.DataTypes.Text, function () {
return ShopperPortalEU_UI_ComponentsModel.staticEntities.customButtonGroupOrientation.horizontal;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomButtonGroupOptionsRec.fromStructure = function (str) {
return new CustomButtonGroupOptionsRec(new CustomButtonGroupOptionsRec.RecordClass({
orientationAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomButtonGroupOptionsRec.init();
return CustomButtonGroupOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomButtonGroupOptionsRec = CustomButtonGroupOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomButtonGroupOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomButtonGroupOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomButtonGroupOptionsRecord = (function (_super) {
__extends(CustomButtonGroupOptionsRecord, _super);
function CustomButtonGroupOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomButtonGroupOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomButtonGroupOptions", "customButtonGroupOptionsAttr", "CustomButtonGroupOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomButtonGroupOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomButtonGroupOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomButtonGroupOptionsRecord.fromStructure = function (str) {
return new CustomButtonGroupOptionsRecord(new CustomButtonGroupOptionsRecord.RecordClass({
customButtonGroupOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomButtonGroupOptionsRecord._isAnonymousRecord = true;
CustomButtonGroupOptionsRecord.UniqueId = "7ea98077-35c9-1190-eff4-794483f83713";
CustomButtonGroupOptionsRecord.init();
return CustomButtonGroupOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomButtonGroupOptionsRecord = CustomButtonGroupOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomButtonGroupOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomButtonGroupOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomButtonGroupOptionsRecordList = (function (_super) {
__extends(CustomButtonGroupOptionsRecordList, _super);
function CustomButtonGroupOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomButtonGroupOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomButtonGroupOptionsRecord;
return CustomButtonGroupOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomButtonGroupOptionsRecordList = CustomButtonGroupOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomSwitchStateRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomSwitchStateRec = (function (_super) {
__extends(CustomSwitchStateRec, _super);
function CustomSwitchStateRec(defaults) {
_super.apply(this, arguments);
}
CustomSwitchStateRec.attributesToDeclare = function () {
return [
this.attr("Class", "classAttr", "Class", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomSwitchStateRec.fromStructure = function (str) {
return new CustomSwitchStateRec(new CustomSwitchStateRec.RecordClass({
classAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomSwitchStateRec.init();
return CustomSwitchStateRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomSwitchStateRec = CustomSwitchStateRec;

});
define("ShopperPortalEU_UI_Components.model$CustomSwitchStateList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomSwitchStateRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomSwitchStateList = (function (_super) {
__extends(CustomSwitchStateList, _super);
function CustomSwitchStateList(defaults) {
_super.apply(this, arguments);
}
CustomSwitchStateList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomSwitchStateRec;
return CustomSwitchStateList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomSwitchStateList = CustomSwitchStateList;

});
define("ShopperPortalEU_UI_Components.model$CustomAlertTypeRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomAlertTypeRec = (function (_super) {
__extends(CustomAlertTypeRec, _super);
function CustomAlertTypeRec(defaults) {
_super.apply(this, arguments);
}
CustomAlertTypeRec.attributesToDeclare = function () {
return [
this.attr("Class", "classAttr", "Class", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomAlertTypeRec.fromStructure = function (str) {
return new CustomAlertTypeRec(new CustomAlertTypeRec.RecordClass({
classAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomAlertTypeRec.init();
return CustomAlertTypeRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomAlertTypeRec = CustomAlertTypeRec;

});
define("ShopperPortalEU_UI_Components.model$CustomAlertTypeRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomAlertTypeRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomAlertTypeRecord = (function (_super) {
__extends(CustomAlertTypeRecord, _super);
function CustomAlertTypeRecord(defaults) {
_super.apply(this, arguments);
}
CustomAlertTypeRecord.attributesToDeclare = function () {
return [
this.attr("CustomAlertType", "customAlertTypeAttr", "CustomAlertType", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomAlertTypeRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomAlertTypeRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomAlertTypeRecord.fromStructure = function (str) {
return new CustomAlertTypeRecord(new CustomAlertTypeRecord.RecordClass({
customAlertTypeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomAlertTypeRecord._isAnonymousRecord = true;
CustomAlertTypeRecord.UniqueId = "bd432fd8-7b42-5fb5-77f5-3529eb02b994";
CustomAlertTypeRecord.init();
return CustomAlertTypeRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomAlertTypeRecord = CustomAlertTypeRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomAlertTypeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomAlertTypeRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomAlertTypeRecordList = (function (_super) {
__extends(CustomAlertTypeRecordList, _super);
function CustomAlertTypeRecordList(defaults) {
_super.apply(this, arguments);
}
CustomAlertTypeRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomAlertTypeRecord;
return CustomAlertTypeRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomAlertTypeRecordList = CustomAlertTypeRecordList;

});
define("ShopperPortalEU_UI_Components.model$PaddingSideOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$PaddingSideOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var PaddingSideOptionsList = (function (_super) {
__extends(PaddingSideOptionsList, _super);
function PaddingSideOptionsList(defaults) {
_super.apply(this, arguments);
}
PaddingSideOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.PaddingSideOptionsRec;
return PaddingSideOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.PaddingSideOptionsList = PaddingSideOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomButtonOptionsIconRec = (function (_super) {
__extends(CustomButtonOptionsIconRec, _super);
function CustomButtonOptionsIconRec(defaults) {
_super.apply(this, arguments);
}
CustomButtonOptionsIconRec.attributesToDeclare = function () {
return [
this.attr("Name", "nameAttr", "name", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Family", "familyAttr", "family", false, false, OS.DataTypes.DataTypes.Text, function () {
return ShopperPortalEU_UI_ComponentsModel.staticEntities.customIconFamily.material;
}, true), 
this.attr("Alignment", "alignmentAttr", "alignment", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("IsFilled", "isFilledAttr", "filled", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomButtonOptionsIconRec.init();
return CustomButtonOptionsIconRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsIconRec = CustomButtonOptionsIconRec;

});
define("ShopperPortalEU_UI_Components.model$CustomButtonItemOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomButtonItemOptionsRec = (function (_super) {
__extends(CustomButtonItemOptionsRec, _super);
function CustomButtonItemOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomButtonItemOptionsRec.attributesToDeclare = function () {
return [
this.attr("Icon", "iconAttr", "icon", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsIconRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsIconRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomButtonItemOptionsRec.fromStructure = function (str) {
return new CustomButtonItemOptionsRec(new CustomButtonItemOptionsRec.RecordClass({
iconAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomButtonItemOptionsRec.init();
return CustomButtonItemOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomButtonItemOptionsRec = CustomButtonItemOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomLinkStateRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomLinkStateRec = (function (_super) {
__extends(CustomLinkStateRec, _super);
function CustomLinkStateRec(defaults) {
_super.apply(this, arguments);
}
CustomLinkStateRec.attributesToDeclare = function () {
return [
this.attr("Class", "classAttr", "Class", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomLinkStateRec.fromStructure = function (str) {
return new CustomLinkStateRec(new CustomLinkStateRec.RecordClass({
classAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomLinkStateRec.init();
return CustomLinkStateRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomLinkStateRec = CustomLinkStateRec;

});
define("ShopperPortalEU_UI_Components.model$CustomLinkStateList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomLinkStateRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomLinkStateList = (function (_super) {
__extends(CustomLinkStateList, _super);
function CustomLinkStateList(defaults) {
_super.apply(this, arguments);
}
CustomLinkStateList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomLinkStateRec;
return CustomLinkStateList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomLinkStateList = CustomLinkStateList;

});
define("ShopperPortalEU_UI_Components.model$TextEllipsisOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$TextEllipsisReadMoreOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var TextEllipsisOptionsRec = (function (_super) {
__extends(TextEllipsisOptionsRec, _super);
function TextEllipsisOptionsRec(defaults) {
_super.apply(this, arguments);
}
TextEllipsisOptionsRec.attributesToDeclare = function () {
return [
this.attr("Lines", "linesAttr", "lines", false, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true), 
this.attr("ReadMore", "readMoreAttr", "readMore", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.TextEllipsisReadMoreOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.TextEllipsisReadMoreOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
TextEllipsisOptionsRec.init();
return TextEllipsisOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.TextEllipsisOptionsRec = TextEllipsisOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$TextEllipsisOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$TextEllipsisOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var TextEllipsisOptionsList = (function (_super) {
__extends(TextEllipsisOptionsList, _super);
function TextEllipsisOptionsList(defaults) {
_super.apply(this, arguments);
}
TextEllipsisOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.TextEllipsisOptionsRec;
return TextEllipsisOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.TextEllipsisOptionsList = TextEllipsisOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomAlertIconOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomAlertIconOptionsRec = (function (_super) {
__extends(CustomAlertIconOptionsRec, _super);
function CustomAlertIconOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomAlertIconOptionsRec.attributesToDeclare = function () {
return [
this.attr("Name", "nameAttr", "name", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Family", "familyAttr", "family", false, false, OS.DataTypes.DataTypes.Text, function () {
return ShopperPortalEU_UI_ComponentsModel.staticEntities.customIconFamily.material;
}, true), 
this.attr("IsFilled", "isFilledAttr", "filled", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomAlertIconOptionsRec.init();
return CustomAlertIconOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomAlertIconOptionsRec = CustomAlertIconOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomCardOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomCardOptionsRec = (function (_super) {
__extends(CustomCardOptionsRec, _super);
function CustomCardOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomCardOptionsRec.attributesToDeclare = function () {
return [
this.attr("TestId", "testIdAttr", "testId", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("FullHeight", "fullHeightAttr", "fullHeight", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("Clickable", "clickableAttr", "clickable", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("State", "stateAttr", "state", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("IsLighter", "isLighterAttr", "lighter", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("IsSmaller", "isSmallerAttr", "smaller", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("NoPadding", "noPaddingAttr", "noPadding", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("IsSharper", "isSharperAttr", "sharper", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("HasShadow", "hasShadowAttr", "shadow", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomCardOptionsRec.init();
return CustomCardOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomCardOptionsRec = CustomCardOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomRadioGroupStateRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomRadioGroupStateRec = (function (_super) {
__extends(CustomRadioGroupStateRec, _super);
function CustomRadioGroupStateRec(defaults) {
_super.apply(this, arguments);
}
CustomRadioGroupStateRec.attributesToDeclare = function () {
return [
this.attr("Class", "classAttr", "Class", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomRadioGroupStateRec.fromStructure = function (str) {
return new CustomRadioGroupStateRec(new CustomRadioGroupStateRec.RecordClass({
classAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomRadioGroupStateRec.init();
return CustomRadioGroupStateRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomRadioGroupStateRec = CustomRadioGroupStateRec;

});
define("ShopperPortalEU_UI_Components.model$CustomRadioGroupStateList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomRadioGroupStateRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomRadioGroupStateList = (function (_super) {
__extends(CustomRadioGroupStateList, _super);
function CustomRadioGroupStateList(defaults) {
_super.apply(this, arguments);
}
CustomRadioGroupStateList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomRadioGroupStateRec;
return CustomRadioGroupStateList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomRadioGroupStateList = CustomRadioGroupStateList;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownListValueOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownListValueOptionsRec = (function (_super) {
__extends(CustomDropdownListValueOptionsRec, _super);
function CustomDropdownListValueOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomDropdownListValueOptionsRec.attributesToDeclare = function () {
return [
this.attr("Text", "textAttr", "text", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Value", "valueAttr", "value", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomDropdownListValueOptionsRec.init();
return CustomDropdownListValueOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValueOptionsRec = CustomDropdownListValueOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownListSubItemOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomDropdownListValueOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownListSubItemOptionsRec = (function (_super) {
__extends(CustomDropdownListSubItemOptionsRec, _super);
function CustomDropdownListSubItemOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomDropdownListSubItemOptionsRec.attributesToDeclare = function () {
return [
this.attr("TestId", "testIdAttr", "testId", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("IsDisabled", "isDisabledAttr", "disabled", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("Value", "valueAttr", "value", true, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValueOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValueOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomDropdownListSubItemOptionsRec.init();
return CustomDropdownListSubItemOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownListSubItemOptionsRec = CustomDropdownListSubItemOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownListSubItemOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomDropdownListSubItemOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownListSubItemOptionsList = (function (_super) {
__extends(CustomDropdownListSubItemOptionsList, _super);
function CustomDropdownListSubItemOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownListSubItemOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomDropdownListSubItemOptionsRec;
return CustomDropdownListSubItemOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownListSubItemOptionsList = CustomDropdownListSubItemOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownListSearchOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownListSearchOptionsRec = (function (_super) {
__extends(CustomDropdownListSearchOptionsRec, _super);
function CustomDropdownListSearchOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomDropdownListSearchOptionsRec.attributesToDeclare = function () {
return [
this.attr("Placeholder", "placeholderAttr", "placeholder", false, false, OS.DataTypes.DataTypes.Text, function () {
return "Search";
}, true), 
this.attr("EmptyMessage", "emptyMessageAttr", "emptyMessage", false, false, OS.DataTypes.DataTypes.Text, function () {
return "No results found";
}, true), 
this.attr("EmptyDescription", "emptyDescriptionAttr", "emptyDescription", false, false, OS.DataTypes.DataTypes.Text, function () {
return "Try search for something else.";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomDropdownListSearchOptionsRec.init();
return CustomDropdownListSearchOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownListSearchOptionsRec = CustomDropdownListSearchOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownListOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomDropdownListSearchOptionsRec", "ShopperPortalEU_UI_Components.model$CustomDropdownListValidationOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownListOptionsRec = (function (_super) {
__extends(CustomDropdownListOptionsRec, _super);
function CustomDropdownListOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomDropdownListOptionsRec.attributesToDeclare = function () {
return [
this.attr("TestId", "testIdAttr", "testId", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Selected", "selectedAttr", "selected", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("NullValue", "nullValueAttr", "nullValue", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Search", "searchAttr", "search", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomDropdownListSearchOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomDropdownListSearchOptionsRec), 
this.attr("Label", "labelAttr", "label", false, false, OS.DataTypes.DataTypes.Text, function () {
return "Select";
}, true), 
this.attr("Description", "descriptionAttr", "description", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("IsDisabled", "isDisabledAttr", "disabled", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("IsMandatory", "isMandatoryAttr", "mandatory", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("Validation", "validationAttr", "validation", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValidationOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValidationOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomDropdownListOptionsRec.init();
return CustomDropdownListOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownListOptionsRec = CustomDropdownListOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownListOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomDropdownListOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownListOptionsRecord = (function (_super) {
__extends(CustomDropdownListOptionsRecord, _super);
function CustomDropdownListOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomDropdownListOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomDropdownListOptions", "customDropdownListOptionsAttr", "CustomDropdownListOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomDropdownListOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomDropdownListOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomDropdownListOptionsRecord.fromStructure = function (str) {
return new CustomDropdownListOptionsRecord(new CustomDropdownListOptionsRecord.RecordClass({
customDropdownListOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomDropdownListOptionsRecord._isAnonymousRecord = true;
CustomDropdownListOptionsRecord.UniqueId = "b077a351-3174-f1d2-c45d-d1fda0d55b93";
CustomDropdownListOptionsRecord.init();
return CustomDropdownListOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownListOptionsRecord = CustomDropdownListOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownListOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomDropdownListOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownListOptionsRecordList = (function (_super) {
__extends(CustomDropdownListOptionsRecordList, _super);
function CustomDropdownListOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownListOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomDropdownListOptionsRecord;
return CustomDropdownListOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownListOptionsRecordList = CustomDropdownListOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$PhoneNumberInputCountryOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$PhoneNumberInputCountryOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var PhoneNumberInputCountryOptionsRecord = (function (_super) {
__extends(PhoneNumberInputCountryOptionsRecord, _super);
function PhoneNumberInputCountryOptionsRecord(defaults) {
_super.apply(this, arguments);
}
PhoneNumberInputCountryOptionsRecord.attributesToDeclare = function () {
return [
this.attr("PhoneNumberInputCountryOptions", "phoneNumberInputCountryOptionsAttr", "PhoneNumberInputCountryOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputCountryOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputCountryOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
PhoneNumberInputCountryOptionsRecord.fromStructure = function (str) {
return new PhoneNumberInputCountryOptionsRecord(new PhoneNumberInputCountryOptionsRecord.RecordClass({
phoneNumberInputCountryOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
PhoneNumberInputCountryOptionsRecord._isAnonymousRecord = true;
PhoneNumberInputCountryOptionsRecord.UniqueId = "0cecba8f-7930-b607-0579-4771472db3ba";
PhoneNumberInputCountryOptionsRecord.init();
return PhoneNumberInputCountryOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputCountryOptionsRecord = PhoneNumberInputCountryOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$PaddingRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$PaddingRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var PaddingRecord = (function (_super) {
__extends(PaddingRecord, _super);
function PaddingRecord(defaults) {
_super.apply(this, arguments);
}
PaddingRecord.attributesToDeclare = function () {
return [
this.attr("Padding", "paddingAttr", "Padding", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.PaddingRec());
}, true, ShopperPortalEU_UI_ComponentsModel.PaddingRec)
].concat(_super.attributesToDeclare.call(this));
};
PaddingRecord.fromStructure = function (str) {
return new PaddingRecord(new PaddingRecord.RecordClass({
paddingAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
PaddingRecord._isAnonymousRecord = true;
PaddingRecord.UniqueId = "ca8a7587-d77b-ee35-aa61-5af66f82ccce";
PaddingRecord.init();
return PaddingRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.PaddingRecord = PaddingRecord;

});
define("ShopperPortalEU_UI_Components.model$PaddingRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$PaddingRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var PaddingRecordList = (function (_super) {
__extends(PaddingRecordList, _super);
function PaddingRecordList(defaults) {
_super.apply(this, arguments);
}
PaddingRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.PaddingRecord;
return PaddingRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.PaddingRecordList = PaddingRecordList;

});
define("ShopperPortalEU_UI_Components.model$UnescapedHTMLOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var UnescapedHTMLOptionsRec = (function (_super) {
__extends(UnescapedHTMLOptionsRec, _super);
function UnescapedHTMLOptionsRec(defaults) {
_super.apply(this, arguments);
}
UnescapedHTMLOptionsRec.attributesToDeclare = function () {
return [
this.attr("TestId", "testIdAttr", "testId", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("HTML", "hTMLAttr", "html", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
UnescapedHTMLOptionsRec.init();
return UnescapedHTMLOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.UnescapedHTMLOptionsRec = UnescapedHTMLOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomButtonOptionsIconRecord = (function (_super) {
__extends(CustomButtonOptionsIconRecord, _super);
function CustomButtonOptionsIconRecord(defaults) {
_super.apply(this, arguments);
}
CustomButtonOptionsIconRecord.attributesToDeclare = function () {
return [
this.attr("CustomButtonOptionsIcon", "customButtonOptionsIconAttr", "CustomButtonOptionsIcon", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsIconRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsIconRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomButtonOptionsIconRecord.fromStructure = function (str) {
return new CustomButtonOptionsIconRecord(new CustomButtonOptionsIconRecord.RecordClass({
customButtonOptionsIconAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomButtonOptionsIconRecord._isAnonymousRecord = true;
CustomButtonOptionsIconRecord.UniqueId = "95ac214c-4bbb-93aa-a566-93e12ce167e0";
CustomButtonOptionsIconRecord.init();
return CustomButtonOptionsIconRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsIconRecord = CustomButtonOptionsIconRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomButtonOptionsIconRecordList = (function (_super) {
__extends(CustomButtonOptionsIconRecordList, _super);
function CustomButtonOptionsIconRecordList(defaults) {
_super.apply(this, arguments);
}
CustomButtonOptionsIconRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsIconRecord;
return CustomButtonOptionsIconRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsIconRecordList = CustomButtonOptionsIconRecordList;

});
define("ShopperPortalEU_UI_Components.model$DatePickerLabelOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$DatePickerLabelOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var DatePickerLabelOptionsRecord = (function (_super) {
__extends(DatePickerLabelOptionsRecord, _super);
function DatePickerLabelOptionsRecord(defaults) {
_super.apply(this, arguments);
}
DatePickerLabelOptionsRecord.attributesToDeclare = function () {
return [
this.attr("DatePickerLabelOptions", "datePickerLabelOptionsAttr", "DatePickerLabelOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.DatePickerLabelOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.DatePickerLabelOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
DatePickerLabelOptionsRecord.fromStructure = function (str) {
return new DatePickerLabelOptionsRecord(new DatePickerLabelOptionsRecord.RecordClass({
datePickerLabelOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
DatePickerLabelOptionsRecord._isAnonymousRecord = true;
DatePickerLabelOptionsRecord.UniqueId = "0da201aa-e13f-92d1-a845-516b82f10faa";
DatePickerLabelOptionsRecord.init();
return DatePickerLabelOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.DatePickerLabelOptionsRecord = DatePickerLabelOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$BarcodeOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var BarcodeOptionsRec = (function (_super) {
__extends(BarcodeOptionsRec, _super);
function BarcodeOptionsRec(defaults) {
_super.apply(this, arguments);
}
BarcodeOptionsRec.attributesToDeclare = function () {
return [
this.attr("TestId", "testIdAttr", "testId", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Data", "dataAttr", "data", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
BarcodeOptionsRec.init();
return BarcodeOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.BarcodeOptionsRec = BarcodeOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$BarcodeOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$BarcodeOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var BarcodeOptionsRecord = (function (_super) {
__extends(BarcodeOptionsRecord, _super);
function BarcodeOptionsRecord(defaults) {
_super.apply(this, arguments);
}
BarcodeOptionsRecord.attributesToDeclare = function () {
return [
this.attr("BarcodeOptions", "barcodeOptionsAttr", "BarcodeOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.BarcodeOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.BarcodeOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
BarcodeOptionsRecord.fromStructure = function (str) {
return new BarcodeOptionsRecord(new BarcodeOptionsRecord.RecordClass({
barcodeOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
BarcodeOptionsRecord._isAnonymousRecord = true;
BarcodeOptionsRecord.UniqueId = "0fd30fdb-aead-ea13-02b9-e277d1c50713";
BarcodeOptionsRecord.init();
return BarcodeOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.BarcodeOptionsRecord = BarcodeOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomPaginationOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomPaginationOptionsRec = (function (_super) {
__extends(CustomPaginationOptionsRec, _super);
function CustomPaginationOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomPaginationOptionsRec.attributesToDeclare = function () {
return [
this.attr("TestId", "testIdAttr", "testId", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("StartIndex", "startIndexAttr", "startIndex", true, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true), 
this.attr("MaxRecords", "maxRecordsAttr", "maxRecords", true, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true), 
this.attr("TotalCount", "totalCountAttr", "totalCount", true, false, OS.DataTypes.DataTypes.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomPaginationOptionsRec.init();
return CustomPaginationOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomPaginationOptionsRec = CustomPaginationOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomPaginationOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomPaginationOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomPaginationOptionsRecord = (function (_super) {
__extends(CustomPaginationOptionsRecord, _super);
function CustomPaginationOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomPaginationOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomPaginationOptions", "customPaginationOptionsAttr", "CustomPaginationOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomPaginationOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomPaginationOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomPaginationOptionsRecord.fromStructure = function (str) {
return new CustomPaginationOptionsRecord(new CustomPaginationOptionsRecord.RecordClass({
customPaginationOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomPaginationOptionsRecord._isAnonymousRecord = true;
CustomPaginationOptionsRecord.UniqueId = "113e7234-6040-1b63-809a-f934d3267b39";
CustomPaginationOptionsRecord.init();
return CustomPaginationOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomPaginationOptionsRecord = CustomPaginationOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomInputMaskOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomInputMaskOptionsRec = (function (_super) {
__extends(CustomInputMaskOptionsRec, _super);
function CustomInputMaskOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomInputMaskOptionsRec.attributesToDeclare = function () {
return [
this.attr("Type", "typeAttr", "type", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomInputMaskOptionsRec.fromStructure = function (str) {
return new CustomInputMaskOptionsRec(new CustomInputMaskOptionsRec.RecordClass({
typeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomInputMaskOptionsRec.init();
return CustomInputMaskOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomInputMaskOptionsRec = CustomInputMaskOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomInputMaskOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomInputMaskOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomInputMaskOptionsRecord = (function (_super) {
__extends(CustomInputMaskOptionsRecord, _super);
function CustomInputMaskOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomInputMaskOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomInputMaskOptions", "customInputMaskOptionsAttr", "CustomInputMaskOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomInputMaskOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomInputMaskOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomInputMaskOptionsRecord.fromStructure = function (str) {
return new CustomInputMaskOptionsRecord(new CustomInputMaskOptionsRecord.RecordClass({
customInputMaskOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomInputMaskOptionsRecord._isAnonymousRecord = true;
CustomInputMaskOptionsRecord.UniqueId = "ed00132e-803f-6cdc-ce11-e5dd48054a99";
CustomInputMaskOptionsRecord.init();
return CustomInputMaskOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomInputMaskOptionsRecord = CustomInputMaskOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomInputMaskOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomInputMaskOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomInputMaskOptionsRecordList = (function (_super) {
__extends(CustomInputMaskOptionsRecordList, _super);
function CustomInputMaskOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomInputMaskOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomInputMaskOptionsRecord;
return CustomInputMaskOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomInputMaskOptionsRecordList = CustomInputMaskOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomRadioGroupOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomRadioGroupOptionsRec = (function (_super) {
__extends(CustomRadioGroupOptionsRec, _super);
function CustomRadioGroupOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomRadioGroupOptionsRec.attributesToDeclare = function () {
return [
this.attr("TestId", "testIdAttr", "testId", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Value", "valueAttr", "value", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomRadioGroupOptionsRec.init();
return CustomRadioGroupOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomRadioGroupOptionsRec = CustomRadioGroupOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomTextAreaValidationOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomTextAreaValidationOptionsRec = (function (_super) {
__extends(CustomTextAreaValidationOptionsRec, _super);
function CustomTextAreaValidationOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomTextAreaValidationOptionsRec.attributesToDeclare = function () {
return [
this.attr("State", "stateAttr", "state", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Message", "messageAttr", "message", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomTextAreaValidationOptionsRec.init();
return CustomTextAreaValidationOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomTextAreaValidationOptionsRec = CustomTextAreaValidationOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomTextAreaOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomTextAreaValidationOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomTextAreaOptionsRec = (function (_super) {
__extends(CustomTextAreaOptionsRec, _super);
function CustomTextAreaOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomTextAreaOptionsRec.attributesToDeclare = function () {
return [
this.attr("TestId", "testIdAttr", "testId", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("AutoResize", "autoResizeAttr", "autoResize", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("HasMaxLengthCounter", "hasMaxLengthCounterAttr", "maxLengthCounter", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("TopLabel", "topLabelAttr", "topLabel", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return true;
}, true), 
this.attr("Validation", "validationAttr", "validation", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomTextAreaValidationOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomTextAreaValidationOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomTextAreaOptionsRec.init();
return CustomTextAreaOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomTextAreaOptionsRec = CustomTextAreaOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomTextAreaOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomTextAreaOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomTextAreaOptionsRecord = (function (_super) {
__extends(CustomTextAreaOptionsRecord, _super);
function CustomTextAreaOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomTextAreaOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomTextAreaOptions", "customTextAreaOptionsAttr", "CustomTextAreaOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomTextAreaOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomTextAreaOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomTextAreaOptionsRecord.fromStructure = function (str) {
return new CustomTextAreaOptionsRecord(new CustomTextAreaOptionsRecord.RecordClass({
customTextAreaOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomTextAreaOptionsRecord._isAnonymousRecord = true;
CustomTextAreaOptionsRecord.UniqueId = "853a4c7f-bacd-127c-25c1-9446a70cd9c2";
CustomTextAreaOptionsRecord.init();
return CustomTextAreaOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomTextAreaOptionsRecord = CustomTextAreaOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomTextAreaOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomTextAreaOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomTextAreaOptionsRecordList = (function (_super) {
__extends(CustomTextAreaOptionsRecordList, _super);
function CustomTextAreaOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomTextAreaOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomTextAreaOptionsRecord;
return CustomTextAreaOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomTextAreaOptionsRecordList = CustomTextAreaOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomIconSizeRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomIconSizeRec = (function (_super) {
__extends(CustomIconSizeRec, _super);
function CustomIconSizeRec(defaults) {
_super.apply(this, arguments);
}
CustomIconSizeRec.attributesToDeclare = function () {
return [
this.attr("Class", "classAttr", "Class", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Label", "labelAttr", "Label", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", false, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomIconSizeRec.init();
return CustomIconSizeRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomIconSizeRec = CustomIconSizeRec;

});
define("ShopperPortalEU_UI_Components.model$CustomIconSizeRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomIconSizeRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomIconSizeRecord = (function (_super) {
__extends(CustomIconSizeRecord, _super);
function CustomIconSizeRecord(defaults) {
_super.apply(this, arguments);
}
CustomIconSizeRecord.attributesToDeclare = function () {
return [
this.attr("CustomIconSize", "customIconSizeAttr", "CustomIconSize", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomIconSizeRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomIconSizeRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomIconSizeRecord.fromStructure = function (str) {
return new CustomIconSizeRecord(new CustomIconSizeRecord.RecordClass({
customIconSizeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomIconSizeRecord._isAnonymousRecord = true;
CustomIconSizeRecord.UniqueId = "1471df4f-b04a-f4b0-9793-30bd82154efb";
CustomIconSizeRecord.init();
return CustomIconSizeRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomIconSizeRecord = CustomIconSizeRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomIconSizeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomIconSizeRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomIconSizeRecordList = (function (_super) {
__extends(CustomIconSizeRecordList, _super);
function CustomIconSizeRecordList(defaults) {
_super.apply(this, arguments);
}
CustomIconSizeRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomIconSizeRecord;
return CustomIconSizeRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomIconSizeRecordList = CustomIconSizeRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomPaginationOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomPaginationOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomPaginationOptionsRecordList = (function (_super) {
__extends(CustomPaginationOptionsRecordList, _super);
function CustomPaginationOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomPaginationOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomPaginationOptionsRecord;
return CustomPaginationOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomPaginationOptionsRecordList = CustomPaginationOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomWizardItemOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomWizardItemOptionsRec = (function (_super) {
__extends(CustomWizardItemOptionsRec, _super);
function CustomWizardItemOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomWizardItemOptionsRec.attributesToDeclare = function () {
return [
this.attr("TestId", "testIdAttr", "testId", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("State", "stateAttr", "state", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomWizardItemOptionsRec.init();
return CustomWizardItemOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomWizardItemOptionsRec = CustomWizardItemOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$FlexItemOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var FlexItemOptionsRec = (function (_super) {
__extends(FlexItemOptionsRec, _super);
function FlexItemOptionsRec(defaults) {
_super.apply(this, arguments);
}
FlexItemOptionsRec.attributesToDeclare = function () {
return [
this.attr("Align", "alignAttr", "align", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Flex", "flexAttr", "flex", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "order", false, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
FlexItemOptionsRec.init();
return FlexItemOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.FlexItemOptionsRec = FlexItemOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$DatePickerChangeOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var DatePickerChangeOptionsRec = (function (_super) {
__extends(DatePickerChangeOptionsRec, _super);
function DatePickerChangeOptionsRec(defaults) {
_super.apply(this, arguments);
}
DatePickerChangeOptionsRec.attributesToDeclare = function () {
return [
this.attr("Date", "dateAttr", "date", true, false, OS.DataTypes.DataTypes.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("FormattedDate", "formattedDateAttr", "formattedDate", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Trigger", "triggerAttr", "trigger", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
DatePickerChangeOptionsRec.init();
return DatePickerChangeOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.DatePickerChangeOptionsRec = DatePickerChangeOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$DatePickerChangeOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$DatePickerChangeOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var DatePickerChangeOptionsList = (function (_super) {
__extends(DatePickerChangeOptionsList, _super);
function DatePickerChangeOptionsList(defaults) {
_super.apply(this, arguments);
}
DatePickerChangeOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.DatePickerChangeOptionsRec;
return DatePickerChangeOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.DatePickerChangeOptionsList = DatePickerChangeOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CircleIconIconOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CircleIconIconOptionsRec = (function (_super) {
__extends(CircleIconIconOptionsRec, _super);
function CircleIconIconOptionsRec(defaults) {
_super.apply(this, arguments);
}
CircleIconIconOptionsRec.attributesToDeclare = function () {
return [
this.attr("Name", "nameAttr", "name", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Family", "familyAttr", "family", false, false, OS.DataTypes.DataTypes.Text, function () {
return ShopperPortalEU_UI_ComponentsModel.staticEntities.customIconFamily.material;
}, true), 
this.attr("IsFilled", "isFilledAttr", "filled", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("Color", "colorAttr", "color", false, false, OS.DataTypes.DataTypes.Text, function () {
return "var(--color-primary-black)";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CircleIconIconOptionsRec.init();
return CircleIconIconOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CircleIconIconOptionsRec = CircleIconIconOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CircleIconIconOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CircleIconIconOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CircleIconIconOptionsRecord = (function (_super) {
__extends(CircleIconIconOptionsRecord, _super);
function CircleIconIconOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CircleIconIconOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CircleIconIconOptions", "circleIconIconOptionsAttr", "CircleIconIconOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CircleIconIconOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CircleIconIconOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CircleIconIconOptionsRecord.fromStructure = function (str) {
return new CircleIconIconOptionsRecord(new CircleIconIconOptionsRecord.RecordClass({
circleIconIconOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CircleIconIconOptionsRecord._isAnonymousRecord = true;
CircleIconIconOptionsRecord.UniqueId = "169aef85-1e8a-f9df-20bb-b8e9ce06d1e8";
CircleIconIconOptionsRecord.init();
return CircleIconIconOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CircleIconIconOptionsRecord = CircleIconIconOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomSeparatorLabelOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomSeparatorLabelOptionsRec = (function (_super) {
__extends(CustomSeparatorLabelOptionsRec, _super);
function CustomSeparatorLabelOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomSeparatorLabelOptionsRec.attributesToDeclare = function () {
return [
this.attr("Show", "showAttr", "show", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("Text", "textAttr", "text", false, false, OS.DataTypes.DataTypes.Text, function () {
return "or";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomSeparatorLabelOptionsRec.init();
return CustomSeparatorLabelOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomSeparatorLabelOptionsRec = CustomSeparatorLabelOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomSeparatorOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomSeparatorLabelOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomSeparatorOptionsRec = (function (_super) {
__extends(CustomSeparatorOptionsRec, _super);
function CustomSeparatorOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomSeparatorOptionsRec.attributesToDeclare = function () {
return [
this.attr("MarginTop", "marginTopAttr", "marginTop", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("MarginBottom", "marginBottomAttr", "marginBottom", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("State", "stateAttr", "state", false, false, OS.DataTypes.DataTypes.Text, function () {
return ShopperPortalEU_UI_ComponentsModel.staticEntities.customSeparatorState.default;
}, true), 
this.attr("Label", "labelAttr", "label", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomSeparatorLabelOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomSeparatorLabelOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomSeparatorOptionsRec.init();
return CustomSeparatorOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomSeparatorOptionsRec = CustomSeparatorOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownValidationOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownValidationOptionsRec = (function (_super) {
__extends(CustomDropdownValidationOptionsRec, _super);
function CustomDropdownValidationOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomDropdownValidationOptionsRec.attributesToDeclare = function () {
return [
this.attr("State", "stateAttr", "state", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Message", "messageAttr", "message", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("IsValidationMessageAbsolute", "isValidationMessageAbsoluteAttr", "validationMessageAbsolute", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomDropdownValidationOptionsRec.init();
return CustomDropdownValidationOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownValidationOptionsRec = CustomDropdownValidationOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownValidationOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomDropdownValidationOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownValidationOptionsRecord = (function (_super) {
__extends(CustomDropdownValidationOptionsRecord, _super);
function CustomDropdownValidationOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomDropdownValidationOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomDropdownValidationOptions", "customDropdownValidationOptionsAttr", "CustomDropdownValidationOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomDropdownValidationOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomDropdownValidationOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomDropdownValidationOptionsRecord.fromStructure = function (str) {
return new CustomDropdownValidationOptionsRecord(new CustomDropdownValidationOptionsRecord.RecordClass({
customDropdownValidationOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomDropdownValidationOptionsRecord._isAnonymousRecord = true;
CustomDropdownValidationOptionsRecord.UniqueId = "176a1b05-3610-8d56-c491-a7a9dc0e4d0a";
CustomDropdownValidationOptionsRecord.init();
return CustomDropdownValidationOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownValidationOptionsRecord = CustomDropdownValidationOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomLinkIconAlignmentRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomLinkIconAlignmentRec = (function (_super) {
__extends(CustomLinkIconAlignmentRec, _super);
function CustomLinkIconAlignmentRec(defaults) {
_super.apply(this, arguments);
}
CustomLinkIconAlignmentRec.attributesToDeclare = function () {
return [
this.attr("Class", "classAttr", "Class", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomLinkIconAlignmentRec.fromStructure = function (str) {
return new CustomLinkIconAlignmentRec(new CustomLinkIconAlignmentRec.RecordClass({
classAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomLinkIconAlignmentRec.init();
return CustomLinkIconAlignmentRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomLinkIconAlignmentRec = CustomLinkIconAlignmentRec;

});
define("ShopperPortalEU_UI_Components.model$CustomLinkIconAlignmentRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomLinkIconAlignmentRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomLinkIconAlignmentRecord = (function (_super) {
__extends(CustomLinkIconAlignmentRecord, _super);
function CustomLinkIconAlignmentRecord(defaults) {
_super.apply(this, arguments);
}
CustomLinkIconAlignmentRecord.attributesToDeclare = function () {
return [
this.attr("CustomLinkIconAlignment", "customLinkIconAlignmentAttr", "CustomLinkIconAlignment", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomLinkIconAlignmentRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomLinkIconAlignmentRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomLinkIconAlignmentRecord.fromStructure = function (str) {
return new CustomLinkIconAlignmentRecord(new CustomLinkIconAlignmentRecord.RecordClass({
customLinkIconAlignmentAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomLinkIconAlignmentRecord._isAnonymousRecord = true;
CustomLinkIconAlignmentRecord.UniqueId = "ace63999-aa40-0027-4a2e-0cc9a95f0bf2";
CustomLinkIconAlignmentRecord.init();
return CustomLinkIconAlignmentRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomLinkIconAlignmentRecord = CustomLinkIconAlignmentRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomLinkIconAlignmentRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomLinkIconAlignmentRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomLinkIconAlignmentRecordList = (function (_super) {
__extends(CustomLinkIconAlignmentRecordList, _super);
function CustomLinkIconAlignmentRecordList(defaults) {
_super.apply(this, arguments);
}
CustomLinkIconAlignmentRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomLinkIconAlignmentRecord;
return CustomLinkIconAlignmentRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomLinkIconAlignmentRecordList = CustomLinkIconAlignmentRecordList;

});
define("ShopperPortalEU_UI_Components.model$FlexDirectionRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var FlexDirectionRec = (function (_super) {
__extends(FlexDirectionRec, _super);
function FlexDirectionRec(defaults) {
_super.apply(this, arguments);
}
FlexDirectionRec.attributesToDeclare = function () {
return [
this.attr("Class", "classAttr", "Class", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
FlexDirectionRec.fromStructure = function (str) {
return new FlexDirectionRec(new FlexDirectionRec.RecordClass({
classAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
FlexDirectionRec.init();
return FlexDirectionRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.FlexDirectionRec = FlexDirectionRec;

});
define("ShopperPortalEU_UI_Components.model$FlexDirectionRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$FlexDirectionRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var FlexDirectionRecord = (function (_super) {
__extends(FlexDirectionRecord, _super);
function FlexDirectionRecord(defaults) {
_super.apply(this, arguments);
}
FlexDirectionRecord.attributesToDeclare = function () {
return [
this.attr("FlexDirection", "flexDirectionAttr", "FlexDirection", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.FlexDirectionRec());
}, true, ShopperPortalEU_UI_ComponentsModel.FlexDirectionRec)
].concat(_super.attributesToDeclare.call(this));
};
FlexDirectionRecord.fromStructure = function (str) {
return new FlexDirectionRecord(new FlexDirectionRecord.RecordClass({
flexDirectionAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
FlexDirectionRecord._isAnonymousRecord = true;
FlexDirectionRecord.UniqueId = "eb8e4d74-b289-661e-eeb1-78f81109c0d8";
FlexDirectionRecord.init();
return FlexDirectionRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.FlexDirectionRecord = FlexDirectionRecord;

});
define("ShopperPortalEU_UI_Components.model$FlexDirectionRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$FlexDirectionRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var FlexDirectionRecordList = (function (_super) {
__extends(FlexDirectionRecordList, _super);
function FlexDirectionRecordList(defaults) {
_super.apply(this, arguments);
}
FlexDirectionRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.FlexDirectionRecord;
return FlexDirectionRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.FlexDirectionRecordList = FlexDirectionRecordList;

});
define("ShopperPortalEU_UI_Components.model$BottomDrawerRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var BottomDrawerRec = (function (_super) {
__extends(BottomDrawerRec, _super);
function BottomDrawerRec(defaults) {
_super.apply(this, arguments);
}
BottomDrawerRec.attributesToDeclare = function () {
return [
this.attr("TestId", "testIdAttr", "testId", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("IsOpen", "isOpenAttr", "open", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
BottomDrawerRec.init();
return BottomDrawerRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.BottomDrawerRec = BottomDrawerRec;

});
define("ShopperPortalEU_UI_Components.model$BottomDrawerRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$BottomDrawerRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var BottomDrawerRecord = (function (_super) {
__extends(BottomDrawerRecord, _super);
function BottomDrawerRecord(defaults) {
_super.apply(this, arguments);
}
BottomDrawerRecord.attributesToDeclare = function () {
return [
this.attr("BottomDrawer", "bottomDrawerAttr", "BottomDrawer", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.BottomDrawerRec());
}, true, ShopperPortalEU_UI_ComponentsModel.BottomDrawerRec)
].concat(_super.attributesToDeclare.call(this));
};
BottomDrawerRecord.fromStructure = function (str) {
return new BottomDrawerRecord(new BottomDrawerRecord.RecordClass({
bottomDrawerAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
BottomDrawerRecord._isAnonymousRecord = true;
BottomDrawerRecord.UniqueId = "181708c1-7064-4e07-343d-69cb33d7e193";
BottomDrawerRecord.init();
return BottomDrawerRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.BottomDrawerRecord = BottomDrawerRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomLinkOptionsIconRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomLinkOptionsIconRec = (function (_super) {
__extends(CustomLinkOptionsIconRec, _super);
function CustomLinkOptionsIconRec(defaults) {
_super.apply(this, arguments);
}
CustomLinkOptionsIconRec.attributesToDeclare = function () {
return [
this.attr("Name", "nameAttr", "name", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Family", "familyAttr", "family", false, false, OS.DataTypes.DataTypes.Text, function () {
return ShopperPortalEU_UI_ComponentsModel.staticEntities.customIconFamily.material;
}, true), 
this.attr("Alignment", "alignmentAttr", "alignment", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomLinkOptionsIconRec.init();
return CustomLinkOptionsIconRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomLinkOptionsIconRec = CustomLinkOptionsIconRec;

});
define("ShopperPortalEU_UI_Components.model$CustomLinkItemOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsIconRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomLinkItemOptionsRec = (function (_super) {
__extends(CustomLinkItemOptionsRec, _super);
function CustomLinkItemOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomLinkItemOptionsRec.attributesToDeclare = function () {
return [
this.attr("Icon", "iconAttr", "icon", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomLinkOptionsIconRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomLinkOptionsIconRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomLinkItemOptionsRec.fromStructure = function (str) {
return new CustomLinkItemOptionsRec(new CustomLinkItemOptionsRec.RecordClass({
iconAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomLinkItemOptionsRec.init();
return CustomLinkItemOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomLinkItemOptionsRec = CustomLinkItemOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomLinkItemOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomLinkItemOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomLinkItemOptionsRecord = (function (_super) {
__extends(CustomLinkItemOptionsRecord, _super);
function CustomLinkItemOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomLinkItemOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomLinkItemOptions", "customLinkItemOptionsAttr", "CustomLinkItemOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomLinkItemOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomLinkItemOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomLinkItemOptionsRecord.fromStructure = function (str) {
return new CustomLinkItemOptionsRecord(new CustomLinkItemOptionsRecord.RecordClass({
customLinkItemOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomLinkItemOptionsRecord._isAnonymousRecord = true;
CustomLinkItemOptionsRecord.UniqueId = "19115453-898b-a8fb-7918-3e6dcaea8082";
CustomLinkItemOptionsRecord.init();
return CustomLinkItemOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomLinkItemOptionsRecord = CustomLinkItemOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$DatatransCardChangeOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var DatatransCardChangeOptionsRec = (function (_super) {
__extends(DatatransCardChangeOptionsRec, _super);
function DatatransCardChangeOptionsRec(defaults) {
_super.apply(this, arguments);
}
DatatransCardChangeOptionsRec.attributesToDeclare = function () {
return [
this.attr("Length", "lengthAttr", "length", false, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true), 
this.attr("PaymentMethod", "paymentMethodAttr", "paymentMethod", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("IsValid", "isValidAttr", "valid", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("ExpiryDate", "expiryDateAttr", "expiryDate", false, false, OS.DataTypes.DataTypes.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("CardHolderName", "cardHolderNameAttr", "cardHolderName", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
DatatransCardChangeOptionsRec.init();
return DatatransCardChangeOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.DatatransCardChangeOptionsRec = DatatransCardChangeOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$DatatransCardChangeOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$DatatransCardChangeOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var DatatransCardChangeOptionsList = (function (_super) {
__extends(DatatransCardChangeOptionsList, _super);
function DatatransCardChangeOptionsList(defaults) {
_super.apply(this, arguments);
}
DatatransCardChangeOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.DatatransCardChangeOptionsRec;
return DatatransCardChangeOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.DatatransCardChangeOptionsList = DatatransCardChangeOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomInputOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomInputOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomInputOptionsRecord = (function (_super) {
__extends(CustomInputOptionsRecord, _super);
function CustomInputOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomInputOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomInputOptions", "customInputOptionsAttr", "CustomInputOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomInputOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomInputOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomInputOptionsRecord.fromStructure = function (str) {
return new CustomInputOptionsRecord(new CustomInputOptionsRecord.RecordClass({
customInputOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomInputOptionsRecord._isAnonymousRecord = true;
CustomInputOptionsRecord.UniqueId = "1ac7de67-9364-5830-0e59-b60f4bb176d2";
CustomInputOptionsRecord.init();
return CustomInputOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomInputOptionsRecord = CustomInputOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownListSelectedItemOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownListSelectedItemOptionsRec = (function (_super) {
__extends(CustomDropdownListSelectedItemOptionsRec, _super);
function CustomDropdownListSelectedItemOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomDropdownListSelectedItemOptionsRec.attributesToDeclare = function () {
return [
this.attr("IsPlaceholder", "isPlaceholderAttr", "placeholder", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomDropdownListSelectedItemOptionsRec.fromStructure = function (str) {
return new CustomDropdownListSelectedItemOptionsRec(new CustomDropdownListSelectedItemOptionsRec.RecordClass({
isPlaceholderAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomDropdownListSelectedItemOptionsRec.init();
return CustomDropdownListSelectedItemOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownListSelectedItemOptionsRec = CustomDropdownListSelectedItemOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownListSelectedItemOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomDropdownListSelectedItemOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownListSelectedItemOptionsRecord = (function (_super) {
__extends(CustomDropdownListSelectedItemOptionsRecord, _super);
function CustomDropdownListSelectedItemOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomDropdownListSelectedItemOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomDropdownListSelectedItemOptions", "customDropdownListSelectedItemOptionsAttr", "CustomDropdownListSelectedItemOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomDropdownListSelectedItemOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomDropdownListSelectedItemOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomDropdownListSelectedItemOptionsRecord.fromStructure = function (str) {
return new CustomDropdownListSelectedItemOptionsRecord(new CustomDropdownListSelectedItemOptionsRecord.RecordClass({
customDropdownListSelectedItemOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomDropdownListSelectedItemOptionsRecord._isAnonymousRecord = true;
CustomDropdownListSelectedItemOptionsRecord.UniqueId = "af439dbe-5799-71e6-94b7-d2fa2475855b";
CustomDropdownListSelectedItemOptionsRecord.init();
return CustomDropdownListSelectedItemOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownListSelectedItemOptionsRecord = CustomDropdownListSelectedItemOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownListSelectedItemOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomDropdownListSelectedItemOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownListSelectedItemOptionsRecordList = (function (_super) {
__extends(CustomDropdownListSelectedItemOptionsRecordList, _super);
function CustomDropdownListSelectedItemOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownListSelectedItemOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomDropdownListSelectedItemOptionsRecord;
return CustomDropdownListSelectedItemOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownListSelectedItemOptionsRecordList = CustomDropdownListSelectedItemOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$OpenPDFOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$OpenPDFOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var OpenPDFOptionsRecordList = (function (_super) {
__extends(OpenPDFOptionsRecordList, _super);
function OpenPDFOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
OpenPDFOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.OpenPDFOptionsRecord;
return OpenPDFOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.OpenPDFOptionsRecordList = OpenPDFOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$JustifyRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var JustifyRec = (function (_super) {
__extends(JustifyRec, _super);
function JustifyRec(defaults) {
_super.apply(this, arguments);
}
JustifyRec.attributesToDeclare = function () {
return [
this.attr("Label", "labelAttr", "Label", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
JustifyRec.fromStructure = function (str) {
return new JustifyRec(new JustifyRec.RecordClass({
labelAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
JustifyRec.init();
return JustifyRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.JustifyRec = JustifyRec;

});
define("ShopperPortalEU_UI_Components.model$JustifyList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$JustifyRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var JustifyList = (function (_super) {
__extends(JustifyList, _super);
function JustifyList(defaults) {
_super.apply(this, arguments);
}
JustifyList.itemType = ShopperPortalEU_UI_ComponentsModel.JustifyRec;
return JustifyList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.JustifyList = JustifyList;

});
define("ShopperPortalEU_UI_Components.model$CustomInputValidationOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomInputValidationOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomInputValidationOptionsRecord = (function (_super) {
__extends(CustomInputValidationOptionsRecord, _super);
function CustomInputValidationOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomInputValidationOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomInputValidationOptions", "customInputValidationOptionsAttr", "CustomInputValidationOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomInputValidationOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomInputValidationOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomInputValidationOptionsRecord.fromStructure = function (str) {
return new CustomInputValidationOptionsRecord(new CustomInputValidationOptionsRecord.RecordClass({
customInputValidationOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomInputValidationOptionsRecord._isAnonymousRecord = true;
CustomInputValidationOptionsRecord.UniqueId = "1dc5b917-c3b5-d95e-825d-6ccc37ab1546";
CustomInputValidationOptionsRecord.init();
return CustomInputValidationOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomInputValidationOptionsRecord = CustomInputValidationOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomCardOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomCardOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomCardOptionsRecord = (function (_super) {
__extends(CustomCardOptionsRecord, _super);
function CustomCardOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomCardOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomCardOptions", "customCardOptionsAttr", "CustomCardOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomCardOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomCardOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomCardOptionsRecord.fromStructure = function (str) {
return new CustomCardOptionsRecord(new CustomCardOptionsRecord.RecordClass({
customCardOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomCardOptionsRecord._isAnonymousRecord = true;
CustomCardOptionsRecord.UniqueId = "1f966b4e-6ea9-1909-e8fe-94733ed2a61b";
CustomCardOptionsRecord.init();
return CustomCardOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomCardOptionsRecord = CustomCardOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownSearchOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomDropdownSearchOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownSearchOptionsList = (function (_super) {
__extends(CustomDropdownSearchOptionsList, _super);
function CustomDropdownSearchOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownSearchOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomDropdownSearchOptionsRec;
return CustomDropdownSearchOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownSearchOptionsList = CustomDropdownSearchOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomIconOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomIconOptionsRec = (function (_super) {
__extends(CustomIconOptionsRec, _super);
function CustomIconOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomIconOptionsRec.attributesToDeclare = function () {
return [
this.attr("TestId", "testIdAttr", "testId", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Name", "nameAttr", "name", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Family", "familyAttr", "family", false, false, OS.DataTypes.DataTypes.Text, function () {
return ShopperPortalEU_UI_ComponentsModel.staticEntities.customIconFamily.material;
}, true), 
this.attr("Size", "sizeAttr", "size", false, false, OS.DataTypes.DataTypes.Text, function () {
return ShopperPortalEU_UI_ComponentsModel.staticEntities.customIconSize.base;
}, true), 
this.attr("Color", "colorAttr", "color", false, false, OS.DataTypes.DataTypes.Text, function () {
return "var(--color-primary-black)";
}, true), 
this.attr("IsFilled", "isFilledAttr", "filled", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomIconOptionsRec.init();
return CustomIconOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomIconOptionsRec = CustomIconOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomIconOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomIconOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomIconOptionsRecord = (function (_super) {
__extends(CustomIconOptionsRecord, _super);
function CustomIconOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomIconOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomIconOptions", "customIconOptionsAttr", "CustomIconOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomIconOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomIconOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomIconOptionsRecord.fromStructure = function (str) {
return new CustomIconOptionsRecord(new CustomIconOptionsRecord.RecordClass({
customIconOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomIconOptionsRecord._isAnonymousRecord = true;
CustomIconOptionsRecord.UniqueId = "ec3a9701-ff9a-7eb1-9cc0-07d487764911";
CustomIconOptionsRecord.init();
return CustomIconOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomIconOptionsRecord = CustomIconOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomIconOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomIconOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomIconOptionsRecordList = (function (_super) {
__extends(CustomIconOptionsRecordList, _super);
function CustomIconOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomIconOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomIconOptionsRecord;
return CustomIconOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomIconOptionsRecordList = CustomIconOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomLinkTypeRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomLinkTypeRec = (function (_super) {
__extends(CustomLinkTypeRec, _super);
function CustomLinkTypeRec(defaults) {
_super.apply(this, arguments);
}
CustomLinkTypeRec.attributesToDeclare = function () {
return [
this.attr("Class", "classAttr", "Class", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", true, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomLinkTypeRec.init();
return CustomLinkTypeRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomLinkTypeRec = CustomLinkTypeRec;

});
define("ShopperPortalEU_UI_Components.model$CustomLinkTypeRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomLinkTypeRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomLinkTypeRecord = (function (_super) {
__extends(CustomLinkTypeRecord, _super);
function CustomLinkTypeRecord(defaults) {
_super.apply(this, arguments);
}
CustomLinkTypeRecord.attributesToDeclare = function () {
return [
this.attr("CustomLinkType", "customLinkTypeAttr", "CustomLinkType", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomLinkTypeRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomLinkTypeRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomLinkTypeRecord.fromStructure = function (str) {
return new CustomLinkTypeRecord(new CustomLinkTypeRecord.RecordClass({
customLinkTypeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomLinkTypeRecord._isAnonymousRecord = true;
CustomLinkTypeRecord.UniqueId = "a4c2b7e1-219b-da6d-ad09-3fcec0e6925a";
CustomLinkTypeRecord.init();
return CustomLinkTypeRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomLinkTypeRecord = CustomLinkTypeRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomLinkTypeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomLinkTypeRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomLinkTypeRecordList = (function (_super) {
__extends(CustomLinkTypeRecordList, _super);
function CustomLinkTypeRecordList(defaults) {
_super.apply(this, arguments);
}
CustomLinkTypeRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomLinkTypeRecord;
return CustomLinkTypeRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomLinkTypeRecordList = CustomLinkTypeRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomCardStateRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomCardStateRec = (function (_super) {
__extends(CustomCardStateRec, _super);
function CustomCardStateRec(defaults) {
_super.apply(this, arguments);
}
CustomCardStateRec.attributesToDeclare = function () {
return [
this.attr("Class", "classAttr", "Class", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomCardStateRec.fromStructure = function (str) {
return new CustomCardStateRec(new CustomCardStateRec.RecordClass({
classAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomCardStateRec.init();
return CustomCardStateRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomCardStateRec = CustomCardStateRec;

});
define("ShopperPortalEU_UI_Components.model$CustomTimelineTypeRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomTimelineTypeRec = (function (_super) {
__extends(CustomTimelineTypeRec, _super);
function CustomTimelineTypeRec(defaults) {
_super.apply(this, arguments);
}
CustomTimelineTypeRec.attributesToDeclare = function () {
return [
this.attr("Class", "classAttr", "Class", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", false, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomTimelineTypeRec.init();
return CustomTimelineTypeRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomTimelineTypeRec = CustomTimelineTypeRec;

});
define("ShopperPortalEU_UI_Components.model$CustomTimelineTypeList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomTimelineTypeRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomTimelineTypeList = (function (_super) {
__extends(CustomTimelineTypeList, _super);
function CustomTimelineTypeList(defaults) {
_super.apply(this, arguments);
}
CustomTimelineTypeList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomTimelineTypeRec;
return CustomTimelineTypeList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomTimelineTypeList = CustomTimelineTypeList;

});
define("ShopperPortalEU_UI_Components.model$CardStateTypeRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CardStateTypeRec = (function (_super) {
__extends(CardStateTypeRec, _super);
function CardStateTypeRec(defaults) {
_super.apply(this, arguments);
}
CardStateTypeRec.attributesToDeclare = function () {
return [
this.attr("Class", "classAttr", "Class", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CardStateTypeRec.fromStructure = function (str) {
return new CardStateTypeRec(new CardStateTypeRec.RecordClass({
classAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CardStateTypeRec.init();
return CardStateTypeRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CardStateTypeRec = CardStateTypeRec;

});
define("ShopperPortalEU_UI_Components.model$CardStateTypeList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CardStateTypeRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CardStateTypeList = (function (_super) {
__extends(CardStateTypeList, _super);
function CardStateTypeList(defaults) {
_super.apply(this, arguments);
}
CardStateTypeList.itemType = ShopperPortalEU_UI_ComponentsModel.CardStateTypeRec;
return CardStateTypeList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CardStateTypeList = CardStateTypeList;

});
define("ShopperPortalEU_UI_Components.model$GetOSBrowserOptionRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var GetOSBrowserOptionRec = (function (_super) {
__extends(GetOSBrowserOptionRec, _super);
function GetOSBrowserOptionRec(defaults) {
_super.apply(this, arguments);
}
GetOSBrowserOptionRec.attributesToDeclare = function () {
return [
this.attr("Name", "nameAttr", "name", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Version", "versionAttr", "version", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
GetOSBrowserOptionRec.init();
return GetOSBrowserOptionRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.GetOSBrowserOptionRec = GetOSBrowserOptionRec;

});
define("ShopperPortalEU_UI_Components.model$GetOSOptionRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var GetOSOptionRec = (function (_super) {
__extends(GetOSOptionRec, _super);
function GetOSOptionRec(defaults) {
_super.apply(this, arguments);
}
GetOSOptionRec.attributesToDeclare = function () {
return [
this.attr("Name", "nameAttr", "name", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Version", "versionAttr", "version", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
GetOSOptionRec.init();
return GetOSOptionRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.GetOSOptionRec = GetOSOptionRec;

});
define("ShopperPortalEU_UI_Components.model$GetOSRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$GetOSBrowserOptionRec", "ShopperPortalEU_UI_Components.model$GetOSOptionRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var GetOSRec = (function (_super) {
__extends(GetOSRec, _super);
function GetOSRec(defaults) {
_super.apply(this, arguments);
}
GetOSRec.attributesToDeclare = function () {
return [
this.attr("Browser", "browserAttr", "browser", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.GetOSBrowserOptionRec());
}, true, ShopperPortalEU_UI_ComponentsModel.GetOSBrowserOptionRec), 
this.attr("OS", "oSAttr", "os", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.GetOSOptionRec());
}, true, ShopperPortalEU_UI_ComponentsModel.GetOSOptionRec)
].concat(_super.attributesToDeclare.call(this));
};
GetOSRec.init();
return GetOSRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.GetOSRec = GetOSRec;

});
define("ShopperPortalEU_UI_Components.model$GetOSRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$GetOSRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var GetOSRecord = (function (_super) {
__extends(GetOSRecord, _super);
function GetOSRecord(defaults) {
_super.apply(this, arguments);
}
GetOSRecord.attributesToDeclare = function () {
return [
this.attr("GetOS", "getOSAttr", "GetOS", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.GetOSRec());
}, true, ShopperPortalEU_UI_ComponentsModel.GetOSRec)
].concat(_super.attributesToDeclare.call(this));
};
GetOSRecord.fromStructure = function (str) {
return new GetOSRecord(new GetOSRecord.RecordClass({
getOSAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
GetOSRecord._isAnonymousRecord = true;
GetOSRecord.UniqueId = "219a09a5-d480-10e0-80ba-b5a63e8d5470";
GetOSRecord.init();
return GetOSRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.GetOSRecord = GetOSRecord;

});
define("ShopperPortalEU_UI_Components.model$BottomDrawerList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$BottomDrawerRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var BottomDrawerList = (function (_super) {
__extends(BottomDrawerList, _super);
function BottomDrawerList(defaults) {
_super.apply(this, arguments);
}
BottomDrawerList.itemType = ShopperPortalEU_UI_ComponentsModel.BottomDrawerRec;
return BottomDrawerList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.BottomDrawerList = BottomDrawerList;

});
define("ShopperPortalEU_UI_Components.model$GetOSOptionRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$GetOSOptionRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var GetOSOptionRecord = (function (_super) {
__extends(GetOSOptionRecord, _super);
function GetOSOptionRecord(defaults) {
_super.apply(this, arguments);
}
GetOSOptionRecord.attributesToDeclare = function () {
return [
this.attr("GetOSOption", "getOSOptionAttr", "GetOSOption", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.GetOSOptionRec());
}, true, ShopperPortalEU_UI_ComponentsModel.GetOSOptionRec)
].concat(_super.attributesToDeclare.call(this));
};
GetOSOptionRecord.fromStructure = function (str) {
return new GetOSOptionRecord(new GetOSOptionRecord.RecordClass({
getOSOptionAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
GetOSOptionRecord._isAnonymousRecord = true;
GetOSOptionRecord.UniqueId = "23022557-8dcf-fa8c-9f56-e5bc76ce87a9";
GetOSOptionRecord.init();
return GetOSOptionRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.GetOSOptionRecord = GetOSOptionRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomButtonTypeRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomButtonTypeRec = (function (_super) {
__extends(CustomButtonTypeRec, _super);
function CustomButtonTypeRec(defaults) {
_super.apply(this, arguments);
}
CustomButtonTypeRec.attributesToDeclare = function () {
return [
this.attr("Class", "classAttr", "Class", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", true, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomButtonTypeRec.init();
return CustomButtonTypeRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomButtonTypeRec = CustomButtonTypeRec;

});
define("ShopperPortalEU_UI_Components.model$CustomButtonTypeRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomButtonTypeRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomButtonTypeRecord = (function (_super) {
__extends(CustomButtonTypeRecord, _super);
function CustomButtonTypeRecord(defaults) {
_super.apply(this, arguments);
}
CustomButtonTypeRecord.attributesToDeclare = function () {
return [
this.attr("CustomButtonType", "customButtonTypeAttr", "CustomButtonType", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomButtonTypeRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomButtonTypeRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomButtonTypeRecord.fromStructure = function (str) {
return new CustomButtonTypeRecord(new CustomButtonTypeRecord.RecordClass({
customButtonTypeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomButtonTypeRecord._isAnonymousRecord = true;
CustomButtonTypeRecord.UniqueId = "5deb5baa-9211-f244-214a-232ef1a5ccb3";
CustomButtonTypeRecord.init();
return CustomButtonTypeRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomButtonTypeRecord = CustomButtonTypeRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomButtonTypeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomButtonTypeRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomButtonTypeRecordList = (function (_super) {
__extends(CustomButtonTypeRecordList, _super);
function CustomButtonTypeRecordList(defaults) {
_super.apply(this, arguments);
}
CustomButtonTypeRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomButtonTypeRecord;
return CustomButtonTypeRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomButtonTypeRecordList = CustomButtonTypeRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomTabsOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomTabsOptionsRec = (function (_super) {
__extends(CustomTabsOptionsRec, _super);
function CustomTabsOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomTabsOptionsRec.attributesToDeclare = function () {
return [
this.attr("Active", "activeAttr", "active", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomTabsOptionsRec.fromStructure = function (str) {
return new CustomTabsOptionsRec(new CustomTabsOptionsRec.RecordClass({
activeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomTabsOptionsRec.init();
return CustomTabsOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomTabsOptionsRec = CustomTabsOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomTabsOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomTabsOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomTabsOptionsList = (function (_super) {
__extends(CustomTabsOptionsList, _super);
function CustomTabsOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomTabsOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomTabsOptionsRec;
return CustomTabsOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomTabsOptionsList = CustomTabsOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomBlankSlateIconOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomBlankSlateIconOptionsRec = (function (_super) {
__extends(CustomBlankSlateIconOptionsRec, _super);
function CustomBlankSlateIconOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomBlankSlateIconOptionsRec.attributesToDeclare = function () {
return [
this.attr("Name", "nameAttr", "name", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("IsFilled", "isFilledAttr", "filled", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomBlankSlateIconOptionsRec.init();
return CustomBlankSlateIconOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomBlankSlateIconOptionsRec = CustomBlankSlateIconOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomBlankSlateOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomBlankSlateIconOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomBlankSlateOptionsRec = (function (_super) {
__extends(CustomBlankSlateOptionsRec, _super);
function CustomBlankSlateOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomBlankSlateOptionsRec.attributesToDeclare = function () {
return [
this.attr("Icon", "iconAttr", "icon", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomBlankSlateIconOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomBlankSlateIconOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomBlankSlateOptionsRec.fromStructure = function (str) {
return new CustomBlankSlateOptionsRec(new CustomBlankSlateOptionsRec.RecordClass({
iconAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomBlankSlateOptionsRec.init();
return CustomBlankSlateOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomBlankSlateOptionsRec = CustomBlankSlateOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomBlankSlateOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomBlankSlateOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomBlankSlateOptionsRecord = (function (_super) {
__extends(CustomBlankSlateOptionsRecord, _super);
function CustomBlankSlateOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomBlankSlateOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomBlankSlateOptions", "customBlankSlateOptionsAttr", "CustomBlankSlateOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomBlankSlateOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomBlankSlateOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomBlankSlateOptionsRecord.fromStructure = function (str) {
return new CustomBlankSlateOptionsRecord(new CustomBlankSlateOptionsRecord.RecordClass({
customBlankSlateOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomBlankSlateOptionsRecord._isAnonymousRecord = true;
CustomBlankSlateOptionsRecord.UniqueId = "248fd8ee-bc5e-2ebd-37ca-d18067228e6a";
CustomBlankSlateOptionsRecord.init();
return CustomBlankSlateOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomBlankSlateOptionsRecord = CustomBlankSlateOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomAlertOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomAlertIconOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomAlertOptionsRec = (function (_super) {
__extends(CustomAlertOptionsRec, _super);
function CustomAlertOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomAlertOptionsRec.attributesToDeclare = function () {
return [
this.attr("Type", "typeAttr", "type", false, false, OS.DataTypes.DataTypes.Text, function () {
return ShopperPortalEU_UI_ComponentsModel.staticEntities.customAlertType.info;
}, true), 
this.attr("Icon", "iconAttr", "icon", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomAlertIconOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomAlertIconOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomAlertOptionsRec.init();
return CustomAlertOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomAlertOptionsRec = CustomAlertOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomAlertOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomAlertOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomAlertOptionsList = (function (_super) {
__extends(CustomAlertOptionsList, _super);
function CustomAlertOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomAlertOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomAlertOptionsRec;
return CustomAlertOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomAlertOptionsList = CustomAlertOptionsList;

});
define("ShopperPortalEU_UI_Components.model$PaddingList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$PaddingRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var PaddingList = (function (_super) {
__extends(PaddingList, _super);
function PaddingList(defaults) {
_super.apply(this, arguments);
}
PaddingList.itemType = ShopperPortalEU_UI_ComponentsModel.PaddingRec;
return PaddingList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.PaddingList = PaddingList;

});
define("ShopperPortalEU_UI_Components.model$CustomTagStateRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomTagStateRec = (function (_super) {
__extends(CustomTagStateRec, _super);
function CustomTagStateRec(defaults) {
_super.apply(this, arguments);
}
CustomTagStateRec.attributesToDeclare = function () {
return [
this.attr("Class", "classAttr", "Class", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomTagStateRec.fromStructure = function (str) {
return new CustomTagStateRec(new CustomTagStateRec.RecordClass({
classAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomTagStateRec.init();
return CustomTagStateRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomTagStateRec = CustomTagStateRec;

});
define("ShopperPortalEU_UI_Components.model$CustomTagStateRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomTagStateRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomTagStateRecord = (function (_super) {
__extends(CustomTagStateRecord, _super);
function CustomTagStateRecord(defaults) {
_super.apply(this, arguments);
}
CustomTagStateRecord.attributesToDeclare = function () {
return [
this.attr("CustomTagState", "customTagStateAttr", "CustomTagState", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomTagStateRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomTagStateRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomTagStateRecord.fromStructure = function (str) {
return new CustomTagStateRecord(new CustomTagStateRecord.RecordClass({
customTagStateAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomTagStateRecord._isAnonymousRecord = true;
CustomTagStateRecord.UniqueId = "257bb42e-a6a8-1fb0-b051-e88ca4f96cd4";
CustomTagStateRecord.init();
return CustomTagStateRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomTagStateRecord = CustomTagStateRecord;

});
define("ShopperPortalEU_UI_Components.model$CardBackgroundOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CardBackgroundOptionsRec = (function (_super) {
__extends(CardBackgroundOptionsRec, _super);
function CardBackgroundOptionsRec(defaults) {
_super.apply(this, arguments);
}
CardBackgroundOptionsRec.attributesToDeclare = function () {
return [
this.attr("TestId", "testIdAttr", "testId", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Type", "typeAttr", "type", false, false, OS.DataTypes.DataTypes.Text, function () {
return ShopperPortalEU_UI_ComponentsModel.staticEntities.cardBackgroundType.refund;
}, true), 
this.attr("FullHeight", "fullHeightAttr", "fullHeight", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("Clickable", "clickableAttr", "clickable", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CardBackgroundOptionsRec.init();
return CardBackgroundOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CardBackgroundOptionsRec = CardBackgroundOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CardBackgroundOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CardBackgroundOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CardBackgroundOptionsList = (function (_super) {
__extends(CardBackgroundOptionsList, _super);
function CardBackgroundOptionsList(defaults) {
_super.apply(this, arguments);
}
CardBackgroundOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CardBackgroundOptionsRec;
return CardBackgroundOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CardBackgroundOptionsList = CardBackgroundOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomTextAreaOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomTextAreaOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomTextAreaOptionsList = (function (_super) {
__extends(CustomTextAreaOptionsList, _super);
function CustomTextAreaOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomTextAreaOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomTextAreaOptionsRec;
return CustomTextAreaOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomTextAreaOptionsList = CustomTextAreaOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomTablePaginationOptionRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomTablePaginationOptionRec = (function (_super) {
__extends(CustomTablePaginationOptionRec, _super);
function CustomTablePaginationOptionRec(defaults) {
_super.apply(this, arguments);
}
CustomTablePaginationOptionRec.attributesToDeclare = function () {
return [
this.attr("Hide", "hideAttr", "hide", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("OnlyBottom", "onlyBottomAttr", "onlyBottom", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("StartIndex", "startIndexAttr", "StartIndex", false, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true), 
this.attr("MaxRecords", "maxRecordsAttr", "MaxRecords", false, false, OS.DataTypes.DataTypes.Integer, function () {
return 10;
}, true), 
this.attr("TotalCount", "totalCountAttr", "TotalCount", false, false, OS.DataTypes.DataTypes.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomTablePaginationOptionRec.init();
return CustomTablePaginationOptionRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomTablePaginationOptionRec = CustomTablePaginationOptionRec;

});
define("ShopperPortalEU_UI_Components.model$CustomTablePaginationOptionRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomTablePaginationOptionRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomTablePaginationOptionRecord = (function (_super) {
__extends(CustomTablePaginationOptionRecord, _super);
function CustomTablePaginationOptionRecord(defaults) {
_super.apply(this, arguments);
}
CustomTablePaginationOptionRecord.attributesToDeclare = function () {
return [
this.attr("CustomTablePaginationOption", "customTablePaginationOptionAttr", "CustomTablePaginationOption", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomTablePaginationOptionRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomTablePaginationOptionRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomTablePaginationOptionRecord.fromStructure = function (str) {
return new CustomTablePaginationOptionRecord(new CustomTablePaginationOptionRecord.RecordClass({
customTablePaginationOptionAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomTablePaginationOptionRecord._isAnonymousRecord = true;
CustomTablePaginationOptionRecord.UniqueId = "6fccc036-b1ac-a76a-53aa-197e33b6f1c2";
CustomTablePaginationOptionRecord.init();
return CustomTablePaginationOptionRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomTablePaginationOptionRecord = CustomTablePaginationOptionRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomTablePaginationOptionRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomTablePaginationOptionRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomTablePaginationOptionRecordList = (function (_super) {
__extends(CustomTablePaginationOptionRecordList, _super);
function CustomTablePaginationOptionRecordList(defaults) {
_super.apply(this, arguments);
}
CustomTablePaginationOptionRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomTablePaginationOptionRecord;
return CustomTablePaginationOptionRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomTablePaginationOptionRecordList = CustomTablePaginationOptionRecordList;

});
define("ShopperPortalEU_UI_Components.model$DatePickerValidationOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var DatePickerValidationOptionsRec = (function (_super) {
__extends(DatePickerValidationOptionsRec, _super);
function DatePickerValidationOptionsRec(defaults) {
_super.apply(this, arguments);
}
DatePickerValidationOptionsRec.attributesToDeclare = function () {
return [
this.attr("State", "stateAttr", "state", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Message", "messageAttr", "message", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
DatePickerValidationOptionsRec.init();
return DatePickerValidationOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.DatePickerValidationOptionsRec = DatePickerValidationOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$DatePickerOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$DatePickerLabelOptionsRec", "ShopperPortalEU_UI_Components.model$DatePickerValidationOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var DatePickerOptionsRec = (function (_super) {
__extends(DatePickerOptionsRec, _super);
function DatePickerOptionsRec(defaults) {
_super.apply(this, arguments);
}
DatePickerOptionsRec.attributesToDeclare = function () {
return [
this.attr("TestId", "testIdAttr", "testId", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Date", "dateAttr", "date", false, false, OS.DataTypes.DataTypes.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("ViewDate", "viewDateAttr", "viewDate", false, false, OS.DataTypes.DataTypes.Date, function () {
return OS.BuiltinFunctions.currDate();
}, true), 
this.attr("IsMandatory", "isMandatoryAttr", "mandatory", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("IsDisabled", "isDisabledAttr", "disabled", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("MinDate", "minDateAttr", "minDate", false, false, OS.DataTypes.DataTypes.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("MaxDate", "maxDateAttr", "maxDate", false, false, OS.DataTypes.DataTypes.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("IsFullWidth", "isFullWidthAttr", "fullWidth", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("Label", "labelAttr", "label", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.DatePickerLabelOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.DatePickerLabelOptionsRec), 
this.attr("Validation", "validationAttr", "validation", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.DatePickerValidationOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.DatePickerValidationOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
DatePickerOptionsRec.init();
return DatePickerOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.DatePickerOptionsRec = DatePickerOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$DatePickerOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$DatePickerOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var DatePickerOptionsRecord = (function (_super) {
__extends(DatePickerOptionsRecord, _super);
function DatePickerOptionsRecord(defaults) {
_super.apply(this, arguments);
}
DatePickerOptionsRecord.attributesToDeclare = function () {
return [
this.attr("DatePickerOptions", "datePickerOptionsAttr", "DatePickerOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.DatePickerOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.DatePickerOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
DatePickerOptionsRecord.fromStructure = function (str) {
return new DatePickerOptionsRecord(new DatePickerOptionsRecord.RecordClass({
datePickerOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
DatePickerOptionsRecord._isAnonymousRecord = true;
DatePickerOptionsRecord.UniqueId = "2663b02c-8d3a-d8dd-bd98-604b72105e7f";
DatePickerOptionsRecord.init();
return DatePickerOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.DatePickerOptionsRecord = DatePickerOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomBlankSlateIconOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomBlankSlateIconOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomBlankSlateIconOptionsRecord = (function (_super) {
__extends(CustomBlankSlateIconOptionsRecord, _super);
function CustomBlankSlateIconOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomBlankSlateIconOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomBlankSlateIconOptions", "customBlankSlateIconOptionsAttr", "CustomBlankSlateIconOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomBlankSlateIconOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomBlankSlateIconOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomBlankSlateIconOptionsRecord.fromStructure = function (str) {
return new CustomBlankSlateIconOptionsRecord(new CustomBlankSlateIconOptionsRecord.RecordClass({
customBlankSlateIconOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomBlankSlateIconOptionsRecord._isAnonymousRecord = true;
CustomBlankSlateIconOptionsRecord.UniqueId = "26a14fbd-1b42-a634-6f1f-1c5bcfbb89e1";
CustomBlankSlateIconOptionsRecord.init();
return CustomBlankSlateIconOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomBlankSlateIconOptionsRecord = CustomBlankSlateIconOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$PhoneNumberInputSearchOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var PhoneNumberInputSearchOptionsRec = (function (_super) {
__extends(PhoneNumberInputSearchOptionsRec, _super);
function PhoneNumberInputSearchOptionsRec(defaults) {
_super.apply(this, arguments);
}
PhoneNumberInputSearchOptionsRec.attributesToDeclare = function () {
return [
this.attr("Placeholder", "placeholderAttr", "placeholder", false, false, OS.DataTypes.DataTypes.Text, function () {
return "Search";
}, true), 
this.attr("EmptyMessage", "emptyMessageAttr", "emptyMessage", false, false, OS.DataTypes.DataTypes.Text, function () {
return "No results found";
}, true), 
this.attr("EmptyDescription", "emptyDescriptionAttr", "emptyDescription", false, false, OS.DataTypes.DataTypes.Text, function () {
return "Try search for something else.";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PhoneNumberInputSearchOptionsRec.init();
return PhoneNumberInputSearchOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputSearchOptionsRec = PhoneNumberInputSearchOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$PhoneNumberInputSearchOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$PhoneNumberInputSearchOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var PhoneNumberInputSearchOptionsRecord = (function (_super) {
__extends(PhoneNumberInputSearchOptionsRecord, _super);
function PhoneNumberInputSearchOptionsRecord(defaults) {
_super.apply(this, arguments);
}
PhoneNumberInputSearchOptionsRecord.attributesToDeclare = function () {
return [
this.attr("PhoneNumberInputSearchOptions", "phoneNumberInputSearchOptionsAttr", "PhoneNumberInputSearchOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputSearchOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputSearchOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
PhoneNumberInputSearchOptionsRecord.fromStructure = function (str) {
return new PhoneNumberInputSearchOptionsRecord(new PhoneNumberInputSearchOptionsRecord.RecordClass({
phoneNumberInputSearchOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
PhoneNumberInputSearchOptionsRecord._isAnonymousRecord = true;
PhoneNumberInputSearchOptionsRecord.UniqueId = "2748b348-b7f1-ee07-8e42-cf5a83a6bca9";
PhoneNumberInputSearchOptionsRecord.init();
return PhoneNumberInputSearchOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputSearchOptionsRecord = PhoneNumberInputSearchOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$DatatransCardChangeOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$DatatransCardChangeOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var DatatransCardChangeOptionsRecord = (function (_super) {
__extends(DatatransCardChangeOptionsRecord, _super);
function DatatransCardChangeOptionsRecord(defaults) {
_super.apply(this, arguments);
}
DatatransCardChangeOptionsRecord.attributesToDeclare = function () {
return [
this.attr("DatatransCardChangeOptions", "datatransCardChangeOptionsAttr", "DatatransCardChangeOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.DatatransCardChangeOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.DatatransCardChangeOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
DatatransCardChangeOptionsRecord.fromStructure = function (str) {
return new DatatransCardChangeOptionsRecord(new DatatransCardChangeOptionsRecord.RecordClass({
datatransCardChangeOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
DatatransCardChangeOptionsRecord._isAnonymousRecord = true;
DatatransCardChangeOptionsRecord.UniqueId = "28dad260-4c18-d507-944a-54e23309dbc9";
DatatransCardChangeOptionsRecord.init();
return DatatransCardChangeOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.DatatransCardChangeOptionsRecord = DatatransCardChangeOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomValidationMessageOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomValidationMessageOptionsRec = (function (_super) {
__extends(CustomValidationMessageOptionsRec, _super);
function CustomValidationMessageOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomValidationMessageOptionsRec.attributesToDeclare = function () {
return [
this.attr("State", "stateAttr", "state", false, false, OS.DataTypes.DataTypes.Text, function () {
return ShopperPortalEU_UI_ComponentsModel.staticEntities.customValidationMessageState.error;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomValidationMessageOptionsRec.fromStructure = function (str) {
return new CustomValidationMessageOptionsRec(new CustomValidationMessageOptionsRec.RecordClass({
stateAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomValidationMessageOptionsRec.init();
return CustomValidationMessageOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomValidationMessageOptionsRec = CustomValidationMessageOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomInputIconOptionRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomInputIconOptionRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomInputIconOptionRecord = (function (_super) {
__extends(CustomInputIconOptionRecord, _super);
function CustomInputIconOptionRecord(defaults) {
_super.apply(this, arguments);
}
CustomInputIconOptionRecord.attributesToDeclare = function () {
return [
this.attr("CustomInputIconOption", "customInputIconOptionAttr", "CustomInputIconOption", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomInputIconOptionRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomInputIconOptionRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomInputIconOptionRecord.fromStructure = function (str) {
return new CustomInputIconOptionRecord(new CustomInputIconOptionRecord.RecordClass({
customInputIconOptionAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomInputIconOptionRecord._isAnonymousRecord = true;
CustomInputIconOptionRecord.UniqueId = "64a2bbde-39b5-a619-6695-5ae977b5d9e2";
CustomInputIconOptionRecord.init();
return CustomInputIconOptionRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomInputIconOptionRecord = CustomInputIconOptionRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomInputIconOptionRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomInputIconOptionRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomInputIconOptionRecordList = (function (_super) {
__extends(CustomInputIconOptionRecordList, _super);
function CustomInputIconOptionRecordList(defaults) {
_super.apply(this, arguments);
}
CustomInputIconOptionRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomInputIconOptionRecord;
return CustomInputIconOptionRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomInputIconOptionRecordList = CustomInputIconOptionRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomRadioGroupOrientationRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomRadioGroupOrientationRec = (function (_super) {
__extends(CustomRadioGroupOrientationRec, _super);
function CustomRadioGroupOrientationRec(defaults) {
_super.apply(this, arguments);
}
CustomRadioGroupOrientationRec.attributesToDeclare = function () {
return [
this.attr("Class", "classAttr", "Class", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomRadioGroupOrientationRec.fromStructure = function (str) {
return new CustomRadioGroupOrientationRec(new CustomRadioGroupOrientationRec.RecordClass({
classAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomRadioGroupOrientationRec.init();
return CustomRadioGroupOrientationRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomRadioGroupOrientationRec = CustomRadioGroupOrientationRec;

});
define("ShopperPortalEU_UI_Components.model$StateBadgeOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var StateBadgeOptionsRec = (function (_super) {
__extends(StateBadgeOptionsRec, _super);
function StateBadgeOptionsRec(defaults) {
_super.apply(this, arguments);
}
StateBadgeOptionsRec.attributesToDeclare = function () {
return [
this.attr("Type", "typeAttr", "type", false, false, OS.DataTypes.DataTypes.Text, function () {
return ShopperPortalEU_UI_ComponentsModel.staticEntities.stateBadgeType.warning;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
StateBadgeOptionsRec.fromStructure = function (str) {
return new StateBadgeOptionsRec(new StateBadgeOptionsRec.RecordClass({
typeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
StateBadgeOptionsRec.init();
return StateBadgeOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.StateBadgeOptionsRec = StateBadgeOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$StateBadgeOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$StateBadgeOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var StateBadgeOptionsRecord = (function (_super) {
__extends(StateBadgeOptionsRecord, _super);
function StateBadgeOptionsRecord(defaults) {
_super.apply(this, arguments);
}
StateBadgeOptionsRecord.attributesToDeclare = function () {
return [
this.attr("StateBadgeOptions", "stateBadgeOptionsAttr", "StateBadgeOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.StateBadgeOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.StateBadgeOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
StateBadgeOptionsRecord.fromStructure = function (str) {
return new StateBadgeOptionsRecord(new StateBadgeOptionsRecord.RecordClass({
stateBadgeOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
StateBadgeOptionsRecord._isAnonymousRecord = true;
StateBadgeOptionsRecord.UniqueId = "78d67c8a-f44a-3dbd-aa53-f658c2e5ebba";
StateBadgeOptionsRecord.init();
return StateBadgeOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.StateBadgeOptionsRecord = StateBadgeOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$StateBadgeOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$StateBadgeOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var StateBadgeOptionsRecordList = (function (_super) {
__extends(StateBadgeOptionsRecordList, _super);
function StateBadgeOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
StateBadgeOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.StateBadgeOptionsRecord;
return StateBadgeOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.StateBadgeOptionsRecordList = StateBadgeOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomLinkOptionsIconRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsIconRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomLinkOptionsIconRecord = (function (_super) {
__extends(CustomLinkOptionsIconRecord, _super);
function CustomLinkOptionsIconRecord(defaults) {
_super.apply(this, arguments);
}
CustomLinkOptionsIconRecord.attributesToDeclare = function () {
return [
this.attr("CustomLinkOptionsIcon", "customLinkOptionsIconAttr", "CustomLinkOptionsIcon", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomLinkOptionsIconRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomLinkOptionsIconRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomLinkOptionsIconRecord.fromStructure = function (str) {
return new CustomLinkOptionsIconRecord(new CustomLinkOptionsIconRecord.RecordClass({
customLinkOptionsIconAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomLinkOptionsIconRecord._isAnonymousRecord = true;
CustomLinkOptionsIconRecord.UniqueId = "2e019d4d-cf37-19e2-5f5f-ccc0c48f9067";
CustomLinkOptionsIconRecord.init();
return CustomLinkOptionsIconRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomLinkOptionsIconRecord = CustomLinkOptionsIconRecord;

});
define("ShopperPortalEU_UI_Components.model$CodeInputStateRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CodeInputStateRec = (function (_super) {
__extends(CodeInputStateRec, _super);
function CodeInputStateRec(defaults) {
_super.apply(this, arguments);
}
CodeInputStateRec.attributesToDeclare = function () {
return [
this.attr("Class", "classAttr", "Class", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CodeInputStateRec.fromStructure = function (str) {
return new CodeInputStateRec(new CodeInputStateRec.RecordClass({
classAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CodeInputStateRec.init();
return CodeInputStateRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CodeInputStateRec = CodeInputStateRec;

});
define("ShopperPortalEU_UI_Components.model$CodeInputStateRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CodeInputStateRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CodeInputStateRecord = (function (_super) {
__extends(CodeInputStateRecord, _super);
function CodeInputStateRecord(defaults) {
_super.apply(this, arguments);
}
CodeInputStateRecord.attributesToDeclare = function () {
return [
this.attr("CodeInputState", "codeInputStateAttr", "CodeInputState", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CodeInputStateRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CodeInputStateRec)
].concat(_super.attributesToDeclare.call(this));
};
CodeInputStateRecord.fromStructure = function (str) {
return new CodeInputStateRecord(new CodeInputStateRecord.RecordClass({
codeInputStateAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CodeInputStateRecord._isAnonymousRecord = true;
CodeInputStateRecord.UniqueId = "2e188e1f-f6e1-e282-0751-f03a3843fc88";
CodeInputStateRecord.init();
return CodeInputStateRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CodeInputStateRecord = CodeInputStateRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomImageOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomImageOptionsRec = (function (_super) {
__extends(CustomImageOptionsRec, _super);
function CustomImageOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomImageOptionsRec.attributesToDeclare = function () {
return [
this.attr("TestId", "testIdAttr", "testId", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("IsFullWidth", "isFullWidthAttr", "fullWidth", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("Width", "widthAttr", "width", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("IsFullHeight", "isFullHeightAttr", "fullHeight", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("Height", "heightAttr", "height", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Inline", "inlineAttr", "inline", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomImageOptionsRec.init();
return CustomImageOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomImageOptionsRec = CustomImageOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomImageOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomImageOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomImageOptionsList = (function (_super) {
__extends(CustomImageOptionsList, _super);
function CustomImageOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomImageOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomImageOptionsRec;
return CustomImageOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomImageOptionsList = CustomImageOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomTabsHeaderItemOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomTabsHeaderItemOptionsRec = (function (_super) {
__extends(CustomTabsHeaderItemOptionsRec, _super);
function CustomTabsHeaderItemOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomTabsHeaderItemOptionsRec.attributesToDeclare = function () {
return [
this.attr("TestId", "testIdAttr", "testId", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Value", "valueAttr", "value", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomTabsHeaderItemOptionsRec.init();
return CustomTabsHeaderItemOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomTabsHeaderItemOptionsRec = CustomTabsHeaderItemOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomTabsHeaderItemOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomTabsHeaderItemOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomTabsHeaderItemOptionsList = (function (_super) {
__extends(CustomTabsHeaderItemOptionsList, _super);
function CustomTabsHeaderItemOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomTabsHeaderItemOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomTabsHeaderItemOptionsRec;
return CustomTabsHeaderItemOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomTabsHeaderItemOptionsList = CustomTabsHeaderItemOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomWizardItemStateRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomWizardItemStateRec = (function (_super) {
__extends(CustomWizardItemStateRec, _super);
function CustomWizardItemStateRec(defaults) {
_super.apply(this, arguments);
}
CustomWizardItemStateRec.attributesToDeclare = function () {
return [
this.attr("Class", "classAttr", "Class", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", false, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomWizardItemStateRec.init();
return CustomWizardItemStateRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomWizardItemStateRec = CustomWizardItemStateRec;

});
define("ShopperPortalEU_UI_Components.model$CustomWizardItemStateRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomWizardItemStateRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomWizardItemStateRecord = (function (_super) {
__extends(CustomWizardItemStateRecord, _super);
function CustomWizardItemStateRecord(defaults) {
_super.apply(this, arguments);
}
CustomWizardItemStateRecord.attributesToDeclare = function () {
return [
this.attr("CustomWizardItemState", "customWizardItemStateAttr", "CustomWizardItemState", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomWizardItemStateRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomWizardItemStateRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomWizardItemStateRecord.fromStructure = function (str) {
return new CustomWizardItemStateRecord(new CustomWizardItemStateRecord.RecordClass({
customWizardItemStateAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomWizardItemStateRecord._isAnonymousRecord = true;
CustomWizardItemStateRecord.UniqueId = "2f0c5bfd-2aea-da8b-5b57-5b8026582b22";
CustomWizardItemStateRecord.init();
return CustomWizardItemStateRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomWizardItemStateRecord = CustomWizardItemStateRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownListItemOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomDropdownListValueOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownListItemOptionsRec = (function (_super) {
__extends(CustomDropdownListItemOptionsRec, _super);
function CustomDropdownListItemOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomDropdownListItemOptionsRec.attributesToDeclare = function () {
return [
this.attr("IsDisabled", "isDisabledAttr", "disabled", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("IsPlaceholder", "isPlaceholderAttr", "placeholder", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("Value", "valueAttr", "value", true, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValueOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValueOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomDropdownListItemOptionsRec.init();
return CustomDropdownListItemOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownListItemOptionsRec = CustomDropdownListItemOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownListItemOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomDropdownListItemOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownListItemOptionsRecord = (function (_super) {
__extends(CustomDropdownListItemOptionsRecord, _super);
function CustomDropdownListItemOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomDropdownListItemOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomDropdownListItemOptions", "customDropdownListItemOptionsAttr", "CustomDropdownListItemOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomDropdownListItemOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomDropdownListItemOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomDropdownListItemOptionsRecord.fromStructure = function (str) {
return new CustomDropdownListItemOptionsRecord(new CustomDropdownListItemOptionsRecord.RecordClass({
customDropdownListItemOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomDropdownListItemOptionsRecord._isAnonymousRecord = true;
CustomDropdownListItemOptionsRecord.UniqueId = "638f81a9-e8ae-8c9e-8b68-2a1762d3ac1f";
CustomDropdownListItemOptionsRecord.init();
return CustomDropdownListItemOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownListItemOptionsRecord = CustomDropdownListItemOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownListItemOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomDropdownListItemOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownListItemOptionsRecordList = (function (_super) {
__extends(CustomDropdownListItemOptionsRecordList, _super);
function CustomDropdownListItemOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownListItemOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomDropdownListItemOptionsRecord;
return CustomDropdownListItemOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownListItemOptionsRecordList = CustomDropdownListItemOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomCardStateList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomCardStateRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomCardStateList = (function (_super) {
__extends(CustomCardStateList, _super);
function CustomCardStateList(defaults) {
_super.apply(this, arguments);
}
CustomCardStateList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomCardStateRec;
return CustomCardStateList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomCardStateList = CustomCardStateList;

});
define("ShopperPortalEU_UI_Components.model$DatatransCardGetCardInfoDataOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var DatatransCardGetCardInfoDataOptionsRec = (function (_super) {
__extends(DatatransCardGetCardInfoDataOptionsRec, _super);
function DatatransCardGetCardInfoDataOptionsRec(defaults) {
_super.apply(this, arguments);
}
DatatransCardGetCardInfoDataOptionsRec.attributesToDeclare = function () {
return [
this.attr("Brand", "brandAttr", "brand", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Type", "typeAttr", "type", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Usage", "usageAttr", "usage", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Country", "countryAttr", "country", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Issuer", "issuerAttr", "issuer", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
DatatransCardGetCardInfoDataOptionsRec.init();
return DatatransCardGetCardInfoDataOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.DatatransCardGetCardInfoDataOptionsRec = DatatransCardGetCardInfoDataOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$DatatransCardGetCardInfoDataOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$DatatransCardGetCardInfoDataOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var DatatransCardGetCardInfoDataOptionsList = (function (_super) {
__extends(DatatransCardGetCardInfoDataOptionsList, _super);
function DatatransCardGetCardInfoDataOptionsList(defaults) {
_super.apply(this, arguments);
}
DatatransCardGetCardInfoDataOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.DatatransCardGetCardInfoDataOptionsRec;
return DatatransCardGetCardInfoDataOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.DatatransCardGetCardInfoDataOptionsList = DatatransCardGetCardInfoDataOptionsList;

});
define("ShopperPortalEU_UI_Components.model$ButtonOptionOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var ButtonOptionOptionsRec = (function (_super) {
__extends(ButtonOptionOptionsRec, _super);
function ButtonOptionOptionsRec(defaults) {
_super.apply(this, arguments);
}
ButtonOptionOptionsRec.attributesToDeclare = function () {
return [
this.attr("Type", "typeAttr", "type", false, false, OS.DataTypes.DataTypes.Text, function () {
return ShopperPortalEU_UI_ComponentsModel.staticEntities.buttonOptionType.primary;
}, true), 
this.attr("State", "stateAttr", "state", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("IsDisabled", "isDisabledAttr", "disabled", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("IsFullWidth", "isFullWidthAttr", "fullWidth", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ButtonOptionOptionsRec.init();
return ButtonOptionOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.ButtonOptionOptionsRec = ButtonOptionOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$ButtonOptionOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$ButtonOptionOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var ButtonOptionOptionsList = (function (_super) {
__extends(ButtonOptionOptionsList, _super);
function ButtonOptionOptionsList(defaults) {
_super.apply(this, arguments);
}
ButtonOptionOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.ButtonOptionOptionsRec;
return ButtonOptionOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.ButtonOptionOptionsList = ButtonOptionOptionsList;

});
define("ShopperPortalEU_UI_Components.model$FullHeightContentAlignmentRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var FullHeightContentAlignmentRec = (function (_super) {
__extends(FullHeightContentAlignmentRec, _super);
function FullHeightContentAlignmentRec(defaults) {
_super.apply(this, arguments);
}
FullHeightContentAlignmentRec.attributesToDeclare = function () {
return [
this.attr("Label", "labelAttr", "Label", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
FullHeightContentAlignmentRec.fromStructure = function (str) {
return new FullHeightContentAlignmentRec(new FullHeightContentAlignmentRec.RecordClass({
labelAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
FullHeightContentAlignmentRec.init();
return FullHeightContentAlignmentRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.FullHeightContentAlignmentRec = FullHeightContentAlignmentRec;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownListValidationOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomDropdownListValidationOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownListValidationOptionsList = (function (_super) {
__extends(CustomDropdownListValidationOptionsList, _super);
function CustomDropdownListValidationOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownListValidationOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValidationOptionsRec;
return CustomDropdownListValidationOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValidationOptionsList = CustomDropdownListValidationOptionsList;

});
define("ShopperPortalEU_UI_Components.model$ButtonOptionStateRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var ButtonOptionStateRec = (function (_super) {
__extends(ButtonOptionStateRec, _super);
function ButtonOptionStateRec(defaults) {
_super.apply(this, arguments);
}
ButtonOptionStateRec.attributesToDeclare = function () {
return [
this.attr("Class", "classAttr", "Class", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ButtonOptionStateRec.fromStructure = function (str) {
return new ButtonOptionStateRec(new ButtonOptionStateRec.RecordClass({
classAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ButtonOptionStateRec.init();
return ButtonOptionStateRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.ButtonOptionStateRec = ButtonOptionStateRec;

});
define("ShopperPortalEU_UI_Components.model$ButtonOptionStateRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$ButtonOptionStateRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var ButtonOptionStateRecord = (function (_super) {
__extends(ButtonOptionStateRecord, _super);
function ButtonOptionStateRecord(defaults) {
_super.apply(this, arguments);
}
ButtonOptionStateRecord.attributesToDeclare = function () {
return [
this.attr("ButtonOptionState", "buttonOptionStateAttr", "ButtonOptionState", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.ButtonOptionStateRec());
}, true, ShopperPortalEU_UI_ComponentsModel.ButtonOptionStateRec)
].concat(_super.attributesToDeclare.call(this));
};
ButtonOptionStateRecord.fromStructure = function (str) {
return new ButtonOptionStateRecord(new ButtonOptionStateRecord.RecordClass({
buttonOptionStateAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ButtonOptionStateRecord._isAnonymousRecord = true;
ButtonOptionStateRecord.UniqueId = "31cd1bc3-d75a-84cd-04fa-8c084b387a7f";
ButtonOptionStateRecord.init();
return ButtonOptionStateRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.ButtonOptionStateRecord = ButtonOptionStateRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomSwitchOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomSwitchOptionsRec = (function (_super) {
__extends(CustomSwitchOptionsRec, _super);
function CustomSwitchOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomSwitchOptionsRec.attributesToDeclare = function () {
return [
this.attr("TestId", "testIdAttr", "testId", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("State", "stateAttr", "state", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("TopLabel", "topLabelAttr", "topLabel", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomSwitchOptionsRec.init();
return CustomSwitchOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomSwitchOptionsRec = CustomSwitchOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomSwitchOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomSwitchOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomSwitchOptionsList = (function (_super) {
__extends(CustomSwitchOptionsList, _super);
function CustomSwitchOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomSwitchOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomSwitchOptionsRec;
return CustomSwitchOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomSwitchOptionsList = CustomSwitchOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomListOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomListOptionsRec = (function (_super) {
__extends(CustomListOptionsRec, _super);
function CustomListOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomListOptionsRec.attributesToDeclare = function () {
return [
this.attr("HorizontalPadding", "horizontalPaddingAttr", "HorizontalPadding", false, false, OS.DataTypes.DataTypes.Text, function () {
return ShopperPortalEU_UI_ComponentsModel.staticEntities.spacing.none;
}, true), 
this.attr("NoSeparator", "noSeparatorAttr", "noSeparator", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomListOptionsRec.init();
return CustomListOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomListOptionsRec = CustomListOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomListOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomListOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomListOptionsRecord = (function (_super) {
__extends(CustomListOptionsRecord, _super);
function CustomListOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomListOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomListOptions", "customListOptionsAttr", "CustomListOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomListOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomListOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomListOptionsRecord.fromStructure = function (str) {
return new CustomListOptionsRecord(new CustomListOptionsRecord.RecordClass({
customListOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomListOptionsRecord._isAnonymousRecord = true;
CustomListOptionsRecord.UniqueId = "a1400fca-edb5-5272-3b04-5c4be9f99386";
CustomListOptionsRecord.init();
return CustomListOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomListOptionsRecord = CustomListOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomListOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomListOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomListOptionsRecordList = (function (_super) {
__extends(CustomListOptionsRecordList, _super);
function CustomListOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomListOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomListOptionsRecord;
return CustomListOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomListOptionsRecordList = CustomListOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownCustomOptionRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomDropdownSearchOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownCustomOptionRec = (function (_super) {
__extends(CustomDropdownCustomOptionRec, _super);
function CustomDropdownCustomOptionRec(defaults) {
_super.apply(this, arguments);
}
CustomDropdownCustomOptionRec.attributesToDeclare = function () {
return [
this.attr("Search", "searchAttr", "text", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomDropdownSearchOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomDropdownSearchOptionsRec), 
this.attr("Label", "labelAttr", "label", false, false, OS.DataTypes.DataTypes.Text, function () {
return "Select";
}, true), 
this.attr("Description", "descriptionAttr", "description", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomDropdownCustomOptionRec.init();
return CustomDropdownCustomOptionRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownCustomOptionRec = CustomDropdownCustomOptionRec;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownNullOptionRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownNullOptionRec = (function (_super) {
__extends(CustomDropdownNullOptionRec, _super);
function CustomDropdownNullOptionRec(defaults) {
_super.apply(this, arguments);
}
CustomDropdownNullOptionRec.attributesToDeclare = function () {
return [
this.attr("Text", "textAttr", "text", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Value", "valueAttr", "value", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomDropdownNullOptionRec.init();
return CustomDropdownNullOptionRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownNullOptionRec = CustomDropdownNullOptionRec;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomDropdownCustomOptionRec", "ShopperPortalEU_UI_Components.model$CustomDropdownNullOptionRec", "ShopperPortalEU_UI_Components.model$CustomDropdownValidationOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownOptionsRec = (function (_super) {
__extends(CustomDropdownOptionsRec, _super);
function CustomDropdownOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomDropdownOptionsRec.attributesToDeclare = function () {
return [
this.attr("TestId", "testIdAttr", "testId", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("IsNative", "isNativeAttr", "native", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("TopLabel", "topLabelAttr", "topLabel", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return true;
}, true), 
this.attr("Custom", "customAttr", "custom", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomDropdownCustomOptionRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomDropdownCustomOptionRec), 
this.attr("Null", "nullAttr", "null", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomDropdownNullOptionRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomDropdownNullOptionRec), 
this.attr("Validation", "validationAttr", "validation", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomDropdownValidationOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomDropdownValidationOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomDropdownOptionsRec.init();
return CustomDropdownOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownOptionsRec = CustomDropdownOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomDropdownOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownOptionsList = (function (_super) {
__extends(CustomDropdownOptionsList, _super);
function CustomDropdownOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomDropdownOptionsRec;
return CustomDropdownOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownOptionsList = CustomDropdownOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomSeparatorStateRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomSeparatorStateRec = (function (_super) {
__extends(CustomSeparatorStateRec, _super);
function CustomSeparatorStateRec(defaults) {
_super.apply(this, arguments);
}
CustomSeparatorStateRec.attributesToDeclare = function () {
return [
this.attr("Class", "classAttr", "Class", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomSeparatorStateRec.fromStructure = function (str) {
return new CustomSeparatorStateRec(new CustomSeparatorStateRec.RecordClass({
classAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomSeparatorStateRec.init();
return CustomSeparatorStateRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomSeparatorStateRec = CustomSeparatorStateRec;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownAlignmentRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownAlignmentRec = (function (_super) {
__extends(CustomDropdownAlignmentRec, _super);
function CustomDropdownAlignmentRec(defaults) {
_super.apply(this, arguments);
}
CustomDropdownAlignmentRec.attributesToDeclare = function () {
return [
this.attr("Class", "classAttr", "Class", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomDropdownAlignmentRec.fromStructure = function (str) {
return new CustomDropdownAlignmentRec(new CustomDropdownAlignmentRec.RecordClass({
classAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomDropdownAlignmentRec.init();
return CustomDropdownAlignmentRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownAlignmentRec = CustomDropdownAlignmentRec;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownAlignmentRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomDropdownAlignmentRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownAlignmentRecord = (function (_super) {
__extends(CustomDropdownAlignmentRecord, _super);
function CustomDropdownAlignmentRecord(defaults) {
_super.apply(this, arguments);
}
CustomDropdownAlignmentRecord.attributesToDeclare = function () {
return [
this.attr("CustomDropdownAlignment", "customDropdownAlignmentAttr", "CustomDropdownAlignment", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomDropdownAlignmentRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomDropdownAlignmentRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomDropdownAlignmentRecord.fromStructure = function (str) {
return new CustomDropdownAlignmentRecord(new CustomDropdownAlignmentRecord.RecordClass({
customDropdownAlignmentAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomDropdownAlignmentRecord._isAnonymousRecord = true;
CustomDropdownAlignmentRecord.UniqueId = "ce2f850b-12dd-7f45-363b-e37ffa9ddb6b";
CustomDropdownAlignmentRecord.init();
return CustomDropdownAlignmentRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownAlignmentRecord = CustomDropdownAlignmentRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownAlignmentRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomDropdownAlignmentRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownAlignmentRecordList = (function (_super) {
__extends(CustomDropdownAlignmentRecordList, _super);
function CustomDropdownAlignmentRecordList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownAlignmentRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomDropdownAlignmentRecord;
return CustomDropdownAlignmentRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownAlignmentRecordList = CustomDropdownAlignmentRecordList;

});
define("ShopperPortalEU_UI_Components.model$CircleIconIconOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CircleIconIconOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CircleIconIconOptionsList = (function (_super) {
__extends(CircleIconIconOptionsList, _super);
function CircleIconIconOptionsList(defaults) {
_super.apply(this, arguments);
}
CircleIconIconOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CircleIconIconOptionsRec;
return CircleIconIconOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CircleIconIconOptionsList = CircleIconIconOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomButtonItemOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomButtonItemOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomButtonItemOptionsList = (function (_super) {
__extends(CustomButtonItemOptionsList, _super);
function CustomButtonItemOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomButtonItemOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomButtonItemOptionsRec;
return CustomButtonItemOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomButtonItemOptionsList = CustomButtonItemOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownCustomOptionRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomDropdownCustomOptionRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownCustomOptionRecord = (function (_super) {
__extends(CustomDropdownCustomOptionRecord, _super);
function CustomDropdownCustomOptionRecord(defaults) {
_super.apply(this, arguments);
}
CustomDropdownCustomOptionRecord.attributesToDeclare = function () {
return [
this.attr("CustomDropdownCustomOption", "customDropdownCustomOptionAttr", "CustomDropdownCustomOption", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomDropdownCustomOptionRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomDropdownCustomOptionRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomDropdownCustomOptionRecord.fromStructure = function (str) {
return new CustomDropdownCustomOptionRecord(new CustomDropdownCustomOptionRecord.RecordClass({
customDropdownCustomOptionAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomDropdownCustomOptionRecord._isAnonymousRecord = true;
CustomDropdownCustomOptionRecord.UniqueId = "3687a322-d2ea-5254-1480-006e32a7ad41";
CustomDropdownCustomOptionRecord.init();
return CustomDropdownCustomOptionRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownCustomOptionRecord = CustomDropdownCustomOptionRecord;

});
define("ShopperPortalEU_UI_Components.model$FlexOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var FlexOptionsRec = (function (_super) {
__extends(FlexOptionsRec, _super);
function FlexOptionsRec(defaults) {
_super.apply(this, arguments);
}
FlexOptionsRec.attributesToDeclare = function () {
return [
this.attr("Align", "alignAttr", "align", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Justify", "justifyAttr", "justify", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Direction", "directionAttr", "direction", false, false, OS.DataTypes.DataTypes.Text, function () {
return ShopperPortalEU_UI_ComponentsModel.staticEntities.flexDirection.row;
}, true), 
this.attr("Spacing", "spacingAttr", "spacing", false, false, OS.DataTypes.DataTypes.Text, function () {
return ShopperPortalEU_UI_ComponentsModel.staticEntities.spacing.space4;
}, true), 
this.attr("Wrap", "wrapAttr", "wrap", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return true;
}, true), 
this.attr("FullHeight", "fullHeightAttr", "fullHeight", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("LineHeightReset", "lineHeightResetAttr", "lineHeightReset", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
FlexOptionsRec.init();
return FlexOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec = FlexOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$FlexOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$FlexOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var FlexOptionsRecord = (function (_super) {
__extends(FlexOptionsRecord, _super);
function FlexOptionsRecord(defaults) {
_super.apply(this, arguments);
}
FlexOptionsRecord.attributesToDeclare = function () {
return [
this.attr("FlexOptions", "flexOptionsAttr", "FlexOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
FlexOptionsRecord.fromStructure = function (str) {
return new FlexOptionsRecord(new FlexOptionsRecord.RecordClass({
flexOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
FlexOptionsRecord._isAnonymousRecord = true;
FlexOptionsRecord.UniqueId = "36d7e934-918c-291e-bc60-83ca9eb7f388";
FlexOptionsRecord.init();
return FlexOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.FlexOptionsRecord = FlexOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownNullOptionRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomDropdownNullOptionRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownNullOptionRecord = (function (_super) {
__extends(CustomDropdownNullOptionRecord, _super);
function CustomDropdownNullOptionRecord(defaults) {
_super.apply(this, arguments);
}
CustomDropdownNullOptionRecord.attributesToDeclare = function () {
return [
this.attr("CustomDropdownNullOption", "customDropdownNullOptionAttr", "CustomDropdownNullOption", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomDropdownNullOptionRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomDropdownNullOptionRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomDropdownNullOptionRecord.fromStructure = function (str) {
return new CustomDropdownNullOptionRecord(new CustomDropdownNullOptionRecord.RecordClass({
customDropdownNullOptionAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomDropdownNullOptionRecord._isAnonymousRecord = true;
CustomDropdownNullOptionRecord.UniqueId = "6cfdb0e0-93fb-4738-d809-3d3ce42db1ee";
CustomDropdownNullOptionRecord.init();
return CustomDropdownNullOptionRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownNullOptionRecord = CustomDropdownNullOptionRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownNullOptionRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomDropdownNullOptionRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownNullOptionRecordList = (function (_super) {
__extends(CustomDropdownNullOptionRecordList, _super);
function CustomDropdownNullOptionRecordList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownNullOptionRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomDropdownNullOptionRecord;
return CustomDropdownNullOptionRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownNullOptionRecordList = CustomDropdownNullOptionRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownListSubItemOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomDropdownListSubItemOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownListSubItemOptionsRecord = (function (_super) {
__extends(CustomDropdownListSubItemOptionsRecord, _super);
function CustomDropdownListSubItemOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomDropdownListSubItemOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomDropdownListSubItemOptions", "customDropdownListSubItemOptionsAttr", "CustomDropdownListSubItemOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomDropdownListSubItemOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomDropdownListSubItemOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomDropdownListSubItemOptionsRecord.fromStructure = function (str) {
return new CustomDropdownListSubItemOptionsRecord(new CustomDropdownListSubItemOptionsRecord.RecordClass({
customDropdownListSubItemOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomDropdownListSubItemOptionsRecord._isAnonymousRecord = true;
CustomDropdownListSubItemOptionsRecord.UniqueId = "b43e7ae4-c231-e2b7-04d5-5d3befdbfa6e";
CustomDropdownListSubItemOptionsRecord.init();
return CustomDropdownListSubItemOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownListSubItemOptionsRecord = CustomDropdownListSubItemOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownListSubItemOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomDropdownListSubItemOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownListSubItemOptionsRecordList = (function (_super) {
__extends(CustomDropdownListSubItemOptionsRecordList, _super);
function CustomDropdownListSubItemOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownListSubItemOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomDropdownListSubItemOptionsRecord;
return CustomDropdownListSubItemOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownListSubItemOptionsRecordList = CustomDropdownListSubItemOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$TextBreakOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var TextBreakOptionsRec = (function (_super) {
__extends(TextBreakOptionsRec, _super);
function TextBreakOptionsRec(defaults) {
_super.apply(this, arguments);
}
TextBreakOptionsRec.attributesToDeclare = function () {
return [
this.attr("Break", "breakAttr", "break", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return true;
}, true), 
this.attr("NumberOfCharacters", "numberOfCharactersAttr", "characters", false, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
TextBreakOptionsRec.init();
return TextBreakOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.TextBreakOptionsRec = TextBreakOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$TextBreakOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$TextBreakOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var TextBreakOptionsRecord = (function (_super) {
__extends(TextBreakOptionsRecord, _super);
function TextBreakOptionsRecord(defaults) {
_super.apply(this, arguments);
}
TextBreakOptionsRecord.attributesToDeclare = function () {
return [
this.attr("TextBreakOptions", "textBreakOptionsAttr", "TextBreakOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.TextBreakOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.TextBreakOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
TextBreakOptionsRecord.fromStructure = function (str) {
return new TextBreakOptionsRecord(new TextBreakOptionsRecord.RecordClass({
textBreakOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
TextBreakOptionsRecord._isAnonymousRecord = true;
TextBreakOptionsRecord.UniqueId = "a4de4a01-7ef3-13a1-f7c7-7b319f1d2f23";
TextBreakOptionsRecord.init();
return TextBreakOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.TextBreakOptionsRecord = TextBreakOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$TextBreakOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$TextBreakOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var TextBreakOptionsRecordList = (function (_super) {
__extends(TextBreakOptionsRecordList, _super);
function TextBreakOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
TextBreakOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.TextBreakOptionsRecord;
return TextBreakOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.TextBreakOptionsRecordList = TextBreakOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownNullOptionList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomDropdownNullOptionRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownNullOptionList = (function (_super) {
__extends(CustomDropdownNullOptionList, _super);
function CustomDropdownNullOptionList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownNullOptionList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomDropdownNullOptionRec;
return CustomDropdownNullOptionList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownNullOptionList = CustomDropdownNullOptionList;

});
define("ShopperPortalEU_UI_Components.model$CustomButtonGroupOrientationRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomButtonGroupOrientationRec = (function (_super) {
__extends(CustomButtonGroupOrientationRec, _super);
function CustomButtonGroupOrientationRec(defaults) {
_super.apply(this, arguments);
}
CustomButtonGroupOrientationRec.attributesToDeclare = function () {
return [
this.attr("Class", "classAttr", "Class", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomButtonGroupOrientationRec.fromStructure = function (str) {
return new CustomButtonGroupOrientationRec(new CustomButtonGroupOrientationRec.RecordClass({
classAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomButtonGroupOrientationRec.init();
return CustomButtonGroupOrientationRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomButtonGroupOrientationRec = CustomButtonGroupOrientationRec;

});
define("ShopperPortalEU_UI_Components.model$CustomButtonGroupOrientationRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomButtonGroupOrientationRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomButtonGroupOrientationRecord = (function (_super) {
__extends(CustomButtonGroupOrientationRecord, _super);
function CustomButtonGroupOrientationRecord(defaults) {
_super.apply(this, arguments);
}
CustomButtonGroupOrientationRecord.attributesToDeclare = function () {
return [
this.attr("CustomButtonGroupOrientation", "customButtonGroupOrientationAttr", "CustomButtonGroupOrientation", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomButtonGroupOrientationRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomButtonGroupOrientationRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomButtonGroupOrientationRecord.fromStructure = function (str) {
return new CustomButtonGroupOrientationRecord(new CustomButtonGroupOrientationRecord.RecordClass({
customButtonGroupOrientationAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomButtonGroupOrientationRecord._isAnonymousRecord = true;
CustomButtonGroupOrientationRecord.UniqueId = "8e2c8609-ecf3-3d30-a95b-b648c03415b9";
CustomButtonGroupOrientationRecord.init();
return CustomButtonGroupOrientationRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomButtonGroupOrientationRecord = CustomButtonGroupOrientationRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomButtonGroupOrientationRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomButtonGroupOrientationRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomButtonGroupOrientationRecordList = (function (_super) {
__extends(CustomButtonGroupOrientationRecordList, _super);
function CustomButtonGroupOrientationRecordList(defaults) {
_super.apply(this, arguments);
}
CustomButtonGroupOrientationRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomButtonGroupOrientationRecord;
return CustomButtonGroupOrientationRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomButtonGroupOrientationRecordList = CustomButtonGroupOrientationRecordList;

});
define("ShopperPortalEU_UI_Components.model$MonthYearInputOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$MonthYearInputValidationOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var MonthYearInputOptionsRec = (function (_super) {
__extends(MonthYearInputOptionsRec, _super);
function MonthYearInputOptionsRec(defaults) {
_super.apply(this, arguments);
}
MonthYearInputOptionsRec.attributesToDeclare = function () {
return [
this.attr("TestId", "testIdAttr", "testId", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Date", "dateAttr", "date", false, false, OS.DataTypes.DataTypes.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("UseMask", "useMaskAttr", "useMask", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("IsCCType", "isCCTypeAttr", "ccType", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("IsMandatory", "isMandatoryAttr", "mandatory", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("IsDisabled", "isDisabledAttr", "disabled", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("Validation", "validationAttr", "validation", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.MonthYearInputValidationOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.MonthYearInputValidationOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
MonthYearInputOptionsRec.init();
return MonthYearInputOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.MonthYearInputOptionsRec = MonthYearInputOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownListSearchOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomDropdownListSearchOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownListSearchOptionsRecord = (function (_super) {
__extends(CustomDropdownListSearchOptionsRecord, _super);
function CustomDropdownListSearchOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomDropdownListSearchOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomDropdownListSearchOptions", "customDropdownListSearchOptionsAttr", "CustomDropdownListSearchOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomDropdownListSearchOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomDropdownListSearchOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomDropdownListSearchOptionsRecord.fromStructure = function (str) {
return new CustomDropdownListSearchOptionsRecord(new CustomDropdownListSearchOptionsRecord.RecordClass({
customDropdownListSearchOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomDropdownListSearchOptionsRecord._isAnonymousRecord = true;
CustomDropdownListSearchOptionsRecord.UniqueId = "a9b0268d-037a-07ad-4b71-9610c88fde47";
CustomDropdownListSearchOptionsRecord.init();
return CustomDropdownListSearchOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownListSearchOptionsRecord = CustomDropdownListSearchOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownListSearchOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomDropdownListSearchOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownListSearchOptionsRecordList = (function (_super) {
__extends(CustomDropdownListSearchOptionsRecordList, _super);
function CustomDropdownListSearchOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownListSearchOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomDropdownListSearchOptionsRecord;
return CustomDropdownListSearchOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownListSearchOptionsRecordList = CustomDropdownListSearchOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$UnescapedHTMLOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$UnescapedHTMLOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var UnescapedHTMLOptionsRecord = (function (_super) {
__extends(UnescapedHTMLOptionsRecord, _super);
function UnescapedHTMLOptionsRecord(defaults) {
_super.apply(this, arguments);
}
UnescapedHTMLOptionsRecord.attributesToDeclare = function () {
return [
this.attr("UnescapedHTMLOptions", "unescapedHTMLOptionsAttr", "UnescapedHTMLOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.UnescapedHTMLOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.UnescapedHTMLOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
UnescapedHTMLOptionsRecord.fromStructure = function (str) {
return new UnescapedHTMLOptionsRecord(new UnescapedHTMLOptionsRecord.RecordClass({
unescapedHTMLOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
UnescapedHTMLOptionsRecord._isAnonymousRecord = true;
UnescapedHTMLOptionsRecord.UniqueId = "3c413115-6718-323c-b804-e37b70c13b19";
UnescapedHTMLOptionsRecord.init();
return UnescapedHTMLOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.UnescapedHTMLOptionsRecord = UnescapedHTMLOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$SpacingRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var SpacingRec = (function (_super) {
__extends(SpacingRec, _super);
function SpacingRec(defaults) {
_super.apply(this, arguments);
}
SpacingRec.attributesToDeclare = function () {
return [
this.attr("Class", "classAttr", "Class", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", true, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
SpacingRec.init();
return SpacingRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.SpacingRec = SpacingRec;

});
define("ShopperPortalEU_UI_Components.model$SpacingRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$SpacingRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var SpacingRecord = (function (_super) {
__extends(SpacingRecord, _super);
function SpacingRecord(defaults) {
_super.apply(this, arguments);
}
SpacingRecord.attributesToDeclare = function () {
return [
this.attr("Spacing", "spacingAttr", "Spacing", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.SpacingRec());
}, true, ShopperPortalEU_UI_ComponentsModel.SpacingRec)
].concat(_super.attributesToDeclare.call(this));
};
SpacingRecord.fromStructure = function (str) {
return new SpacingRecord(new SpacingRecord.RecordClass({
spacingAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
SpacingRecord._isAnonymousRecord = true;
SpacingRecord.UniqueId = "3c4eb9c7-9376-5b56-adf7-a4018c42b0e8";
SpacingRecord.init();
return SpacingRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.SpacingRecord = SpacingRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomTimelineOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomTimelineOptionsRec = (function (_super) {
__extends(CustomTimelineOptionsRec, _super);
function CustomTimelineOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomTimelineOptionsRec.attributesToDeclare = function () {
return [
this.attr("State", "stateAttr", "state", false, false, OS.DataTypes.DataTypes.Text, function () {
return ShopperPortalEU_UI_ComponentsModel.staticEntities.customTimelineType.past;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomTimelineOptionsRec.fromStructure = function (str) {
return new CustomTimelineOptionsRec(new CustomTimelineOptionsRec.RecordClass({
stateAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomTimelineOptionsRec.init();
return CustomTimelineOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomTimelineOptionsRec = CustomTimelineOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$FlexItemOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$FlexItemOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var FlexItemOptionsRecord = (function (_super) {
__extends(FlexItemOptionsRecord, _super);
function FlexItemOptionsRecord(defaults) {
_super.apply(this, arguments);
}
FlexItemOptionsRecord.attributesToDeclare = function () {
return [
this.attr("FlexItemOptions", "flexItemOptionsAttr", "FlexItemOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.FlexItemOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.FlexItemOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
FlexItemOptionsRecord.fromStructure = function (str) {
return new FlexItemOptionsRecord(new FlexItemOptionsRecord.RecordClass({
flexItemOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
FlexItemOptionsRecord._isAnonymousRecord = true;
FlexItemOptionsRecord.UniqueId = "990c2662-1e4a-d6aa-17e3-dddc0179d52b";
FlexItemOptionsRecord.init();
return FlexItemOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.FlexItemOptionsRecord = FlexItemOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$FlexItemOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$FlexItemOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var FlexItemOptionsRecordList = (function (_super) {
__extends(FlexItemOptionsRecordList, _super);
function FlexItemOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
FlexItemOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.FlexItemOptionsRecord;
return FlexItemOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.FlexItemOptionsRecordList = FlexItemOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownValidationOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomDropdownValidationOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownValidationOptionsList = (function (_super) {
__extends(CustomDropdownValidationOptionsList, _super);
function CustomDropdownValidationOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownValidationOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomDropdownValidationOptionsRec;
return CustomDropdownValidationOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownValidationOptionsList = CustomDropdownValidationOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CodeInputStateList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CodeInputStateRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CodeInputStateList = (function (_super) {
__extends(CodeInputStateList, _super);
function CodeInputStateList(defaults) {
_super.apply(this, arguments);
}
CodeInputStateList.itemType = ShopperPortalEU_UI_ComponentsModel.CodeInputStateRec;
return CodeInputStateList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CodeInputStateList = CodeInputStateList;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomDropdownOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownOptionsRecord = (function (_super) {
__extends(CustomDropdownOptionsRecord, _super);
function CustomDropdownOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomDropdownOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomDropdownOptions", "customDropdownOptionsAttr", "CustomDropdownOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomDropdownOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomDropdownOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomDropdownOptionsRecord.fromStructure = function (str) {
return new CustomDropdownOptionsRecord(new CustomDropdownOptionsRecord.RecordClass({
customDropdownOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomDropdownOptionsRecord._isAnonymousRecord = true;
CustomDropdownOptionsRecord.UniqueId = "3df1d35d-e5e1-cdca-1a81-6dd845f565bc";
CustomDropdownOptionsRecord.init();
return CustomDropdownOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownOptionsRecord = CustomDropdownOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomCheckboxOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomCheckboxOptionsRec = (function (_super) {
__extends(CustomCheckboxOptionsRec, _super);
function CustomCheckboxOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomCheckboxOptionsRec.attributesToDeclare = function () {
return [
this.attr("TestId", "testIdAttr", "testId", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("IsMandatory", "isMandatoryAttr", "mandatory", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("State", "stateAttr", "state", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("TopLabel", "topLabelAttr", "topLabel", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomCheckboxOptionsRec.init();
return CustomCheckboxOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomCheckboxOptionsRec = CustomCheckboxOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomCheckboxOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomCheckboxOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomCheckboxOptionsRecord = (function (_super) {
__extends(CustomCheckboxOptionsRecord, _super);
function CustomCheckboxOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomCheckboxOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomCheckboxOptions", "customCheckboxOptionsAttr", "CustomCheckboxOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomCheckboxOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomCheckboxOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomCheckboxOptionsRecord.fromStructure = function (str) {
return new CustomCheckboxOptionsRecord(new CustomCheckboxOptionsRecord.RecordClass({
customCheckboxOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomCheckboxOptionsRecord._isAnonymousRecord = true;
CustomCheckboxOptionsRecord.UniqueId = "3e5aafc3-6899-6995-b076-b9e41bbe107f";
CustomCheckboxOptionsRecord.init();
return CustomCheckboxOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomCheckboxOptionsRecord = CustomCheckboxOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$ScanBarcodePropertiesRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var ScanBarcodePropertiesRec = (function (_super) {
__extends(ScanBarcodePropertiesRec, _super);
function ScanBarcodePropertiesRec(defaults) {
_super.apply(this, arguments);
}
ScanBarcodePropertiesRec.attributesToDeclare = function () {
return [
this.attr("License", "licenseAttr", "license", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ScanBarcodePropertiesRec.fromStructure = function (str) {
return new ScanBarcodePropertiesRec(new ScanBarcodePropertiesRec.RecordClass({
licenseAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ScanBarcodePropertiesRec.init();
return ScanBarcodePropertiesRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.ScanBarcodePropertiesRec = ScanBarcodePropertiesRec;

});
define("ShopperPortalEU_UI_Components.model$ScanBarcodePropertiesRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$ScanBarcodePropertiesRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var ScanBarcodePropertiesRecord = (function (_super) {
__extends(ScanBarcodePropertiesRecord, _super);
function ScanBarcodePropertiesRecord(defaults) {
_super.apply(this, arguments);
}
ScanBarcodePropertiesRecord.attributesToDeclare = function () {
return [
this.attr("ScanBarcodeProperties", "scanBarcodePropertiesAttr", "ScanBarcodeProperties", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.ScanBarcodePropertiesRec());
}, true, ShopperPortalEU_UI_ComponentsModel.ScanBarcodePropertiesRec)
].concat(_super.attributesToDeclare.call(this));
};
ScanBarcodePropertiesRecord.fromStructure = function (str) {
return new ScanBarcodePropertiesRecord(new ScanBarcodePropertiesRecord.RecordClass({
scanBarcodePropertiesAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ScanBarcodePropertiesRecord._isAnonymousRecord = true;
ScanBarcodePropertiesRecord.UniqueId = "5af8523e-b6e6-cd76-15cc-a9da684acaa1";
ScanBarcodePropertiesRecord.init();
return ScanBarcodePropertiesRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.ScanBarcodePropertiesRecord = ScanBarcodePropertiesRecord;

});
define("ShopperPortalEU_UI_Components.model$ScanBarcodePropertiesRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$ScanBarcodePropertiesRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var ScanBarcodePropertiesRecordList = (function (_super) {
__extends(ScanBarcodePropertiesRecordList, _super);
function ScanBarcodePropertiesRecordList(defaults) {
_super.apply(this, arguments);
}
ScanBarcodePropertiesRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.ScanBarcodePropertiesRecord;
return ScanBarcodePropertiesRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.ScanBarcodePropertiesRecordList = ScanBarcodePropertiesRecordList;

});
define("ShopperPortalEU_UI_Components.model$DatePickerChangeOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$DatePickerChangeOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var DatePickerChangeOptionsRecord = (function (_super) {
__extends(DatePickerChangeOptionsRecord, _super);
function DatePickerChangeOptionsRecord(defaults) {
_super.apply(this, arguments);
}
DatePickerChangeOptionsRecord.attributesToDeclare = function () {
return [
this.attr("DatePickerChangeOptions", "datePickerChangeOptionsAttr", "DatePickerChangeOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.DatePickerChangeOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.DatePickerChangeOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
DatePickerChangeOptionsRecord.fromStructure = function (str) {
return new DatePickerChangeOptionsRecord(new DatePickerChangeOptionsRecord.RecordClass({
datePickerChangeOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
DatePickerChangeOptionsRecord._isAnonymousRecord = true;
DatePickerChangeOptionsRecord.UniqueId = "4019731a-d502-050e-34a5-d480875bf46c";
DatePickerChangeOptionsRecord.init();
return DatePickerChangeOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.DatePickerChangeOptionsRecord = DatePickerChangeOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CardBackgroundOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CardBackgroundOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CardBackgroundOptionsRecord = (function (_super) {
__extends(CardBackgroundOptionsRecord, _super);
function CardBackgroundOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CardBackgroundOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CardBackgroundOptions", "cardBackgroundOptionsAttr", "CardBackgroundOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CardBackgroundOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CardBackgroundOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CardBackgroundOptionsRecord.fromStructure = function (str) {
return new CardBackgroundOptionsRecord(new CardBackgroundOptionsRecord.RecordClass({
cardBackgroundOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CardBackgroundOptionsRecord._isAnonymousRecord = true;
CardBackgroundOptionsRecord.UniqueId = "853c3fa9-2a8f-9ac6-db38-a696a50334a5";
CardBackgroundOptionsRecord.init();
return CardBackgroundOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CardBackgroundOptionsRecord = CardBackgroundOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CardBackgroundOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CardBackgroundOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CardBackgroundOptionsRecordList = (function (_super) {
__extends(CardBackgroundOptionsRecordList, _super);
function CardBackgroundOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CardBackgroundOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CardBackgroundOptionsRecord;
return CardBackgroundOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CardBackgroundOptionsRecordList = CardBackgroundOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomButtonIconAlignmentRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomButtonIconAlignmentRec = (function (_super) {
__extends(CustomButtonIconAlignmentRec, _super);
function CustomButtonIconAlignmentRec(defaults) {
_super.apply(this, arguments);
}
CustomButtonIconAlignmentRec.attributesToDeclare = function () {
return [
this.attr("Class", "classAttr", "Class", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomButtonIconAlignmentRec.fromStructure = function (str) {
return new CustomButtonIconAlignmentRec(new CustomButtonIconAlignmentRec.RecordClass({
classAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomButtonIconAlignmentRec.init();
return CustomButtonIconAlignmentRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomButtonIconAlignmentRec = CustomButtonIconAlignmentRec;

});
define("ShopperPortalEU_UI_Components.model$ScanPassportErrorRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var ScanPassportErrorRec = (function (_super) {
__extends(ScanPassportErrorRec, _super);
function ScanPassportErrorRec(defaults) {
_super.apply(this, arguments);
}
ScanPassportErrorRec.attributesToDeclare = function () {
return [
this.attr("Code", "codeAttr", "code", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Message", "messageAttr", "message", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ScanPassportErrorRec.init();
return ScanPassportErrorRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.ScanPassportErrorRec = ScanPassportErrorRec;

});
define("ShopperPortalEU_UI_Components.model$ScanPassportErrorRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$ScanPassportErrorRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var ScanPassportErrorRecord = (function (_super) {
__extends(ScanPassportErrorRecord, _super);
function ScanPassportErrorRecord(defaults) {
_super.apply(this, arguments);
}
ScanPassportErrorRecord.attributesToDeclare = function () {
return [
this.attr("ScanPassportError", "scanPassportErrorAttr", "ScanPassportError", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.ScanPassportErrorRec());
}, true, ShopperPortalEU_UI_ComponentsModel.ScanPassportErrorRec)
].concat(_super.attributesToDeclare.call(this));
};
ScanPassportErrorRecord.fromStructure = function (str) {
return new ScanPassportErrorRecord(new ScanPassportErrorRecord.RecordClass({
scanPassportErrorAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ScanPassportErrorRecord._isAnonymousRecord = true;
ScanPassportErrorRecord.UniqueId = "9d5293ab-759e-d5d4-2408-25074a96272a";
ScanPassportErrorRecord.init();
return ScanPassportErrorRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.ScanPassportErrorRecord = ScanPassportErrorRecord;

});
define("ShopperPortalEU_UI_Components.model$ScanPassportErrorRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$ScanPassportErrorRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var ScanPassportErrorRecordList = (function (_super) {
__extends(ScanPassportErrorRecordList, _super);
function ScanPassportErrorRecordList(defaults) {
_super.apply(this, arguments);
}
ScanPassportErrorRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.ScanPassportErrorRecord;
return ScanPassportErrorRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.ScanPassportErrorRecordList = ScanPassportErrorRecordList;

});
define("ShopperPortalEU_UI_Components.model$CodeInputChangeOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CodeInputChangeOptionsRec = (function (_super) {
__extends(CodeInputChangeOptionsRec, _super);
function CodeInputChangeOptionsRec(defaults) {
_super.apply(this, arguments);
}
CodeInputChangeOptionsRec.attributesToDeclare = function () {
return [
this.attr("Code", "codeAttr", "code", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("IsFilled", "isFilledAttr", "filled", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CodeInputChangeOptionsRec.init();
return CodeInputChangeOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CodeInputChangeOptionsRec = CodeInputChangeOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CodeInputChangeOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CodeInputChangeOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CodeInputChangeOptionsList = (function (_super) {
__extends(CodeInputChangeOptionsList, _super);
function CodeInputChangeOptionsList(defaults) {
_super.apply(this, arguments);
}
CodeInputChangeOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CodeInputChangeOptionsRec;
return CodeInputChangeOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CodeInputChangeOptionsList = CodeInputChangeOptionsList;

});
define("ShopperPortalEU_UI_Components.model$FullHeightContentBottomOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var FullHeightContentBottomOptionsRec = (function (_super) {
__extends(FullHeightContentBottomOptionsRec, _super);
function FullHeightContentBottomOptionsRec(defaults) {
_super.apply(this, arguments);
}
FullHeightContentBottomOptionsRec.attributesToDeclare = function () {
return [
this.attr("VerticalAlignment", "verticalAlignmentAttr", "verticalAlignment", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("HorizontalAlignment", "horizontalAlignmentAttr", "horizontalAlignment", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("HasPadding", "hasPaddingAttr", "hasPadding", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
FullHeightContentBottomOptionsRec.init();
return FullHeightContentBottomOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.FullHeightContentBottomOptionsRec = FullHeightContentBottomOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$DatatransCardOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var DatatransCardOptionsRec = (function (_super) {
__extends(DatatransCardOptionsRec, _super);
function DatatransCardOptionsRec(defaults) {
_super.apply(this, arguments);
}
DatatransCardOptionsRec.attributesToDeclare = function () {
return [
this.attr("TestId", "testIdAttr", "testId", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("MerchantId", "merchantIdAttr", "merchantId", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("IsProdEnvironment", "isProdEnvironmentAttr", "isProdEnvironment", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("Label", "labelAttr", "label", false, false, OS.DataTypes.DataTypes.Text, function () {
return "Card information";
}, true), 
this.attr("IsMandatory", "isMandatoryAttr", "mandatory", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("Placeholder", "placeholderAttr", "placeholder", false, false, OS.DataTypes.DataTypes.Text, function () {
return "Debit or credit card number";
}, true), 
this.attr("IncludeExpiryDate", "includeExpiryDateAttr", "includeExpiryDate", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("ExpiryDate", "expiryDateAttr", "expiryDate", false, false, OS.DataTypes.DataTypes.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("ErrorMessage", "errorMessageAttr", "errorMessage", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
DatatransCardOptionsRec.init();
return DatatransCardOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.DatatransCardOptionsRec = DatatransCardOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$DatatransCardOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$DatatransCardOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var DatatransCardOptionsRecord = (function (_super) {
__extends(DatatransCardOptionsRecord, _super);
function DatatransCardOptionsRecord(defaults) {
_super.apply(this, arguments);
}
DatatransCardOptionsRecord.attributesToDeclare = function () {
return [
this.attr("DatatransCardOptions", "datatransCardOptionsAttr", "DatatransCardOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.DatatransCardOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.DatatransCardOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
DatatransCardOptionsRecord.fromStructure = function (str) {
return new DatatransCardOptionsRecord(new DatatransCardOptionsRecord.RecordClass({
datatransCardOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
DatatransCardOptionsRecord._isAnonymousRecord = true;
DatatransCardOptionsRecord.UniqueId = "f7081994-1aad-fe2b-050a-e1a1bd9b31a3";
DatatransCardOptionsRecord.init();
return DatatransCardOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.DatatransCardOptionsRecord = DatatransCardOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$DatatransCardOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$DatatransCardOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var DatatransCardOptionsRecordList = (function (_super) {
__extends(DatatransCardOptionsRecordList, _super);
function DatatransCardOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
DatatransCardOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.DatatransCardOptionsRecord;
return DatatransCardOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.DatatransCardOptionsRecordList = DatatransCardOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomFormOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomFormOptionsRec = (function (_super) {
__extends(CustomFormOptionsRec, _super);
function CustomFormOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomFormOptionsRec.attributesToDeclare = function () {
return [
this.attr("IsFullHeight", "isFullHeightAttr", "fullHeight", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomFormOptionsRec.fromStructure = function (str) {
return new CustomFormOptionsRec(new CustomFormOptionsRec.RecordClass({
isFullHeightAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomFormOptionsRec.init();
return CustomFormOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomFormOptionsRec = CustomFormOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomRadioButtonStateRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomRadioButtonStateRec = (function (_super) {
__extends(CustomRadioButtonStateRec, _super);
function CustomRadioButtonStateRec(defaults) {
_super.apply(this, arguments);
}
CustomRadioButtonStateRec.attributesToDeclare = function () {
return [
this.attr("Class", "classAttr", "Class", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomRadioButtonStateRec.fromStructure = function (str) {
return new CustomRadioButtonStateRec(new CustomRadioButtonStateRec.RecordClass({
classAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomRadioButtonStateRec.init();
return CustomRadioButtonStateRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomRadioButtonStateRec = CustomRadioButtonStateRec;

});
define("ShopperPortalEU_UI_Components.model$CustomRadioButtonStateRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomRadioButtonStateRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomRadioButtonStateRecord = (function (_super) {
__extends(CustomRadioButtonStateRecord, _super);
function CustomRadioButtonStateRecord(defaults) {
_super.apply(this, arguments);
}
CustomRadioButtonStateRecord.attributesToDeclare = function () {
return [
this.attr("CustomRadioButtonState", "customRadioButtonStateAttr", "CustomRadioButtonState", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomRadioButtonStateRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomRadioButtonStateRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomRadioButtonStateRecord.fromStructure = function (str) {
return new CustomRadioButtonStateRecord(new CustomRadioButtonStateRecord.RecordClass({
customRadioButtonStateAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomRadioButtonStateRecord._isAnonymousRecord = true;
CustomRadioButtonStateRecord.UniqueId = "42e12caa-8f5c-bef5-d77d-5afb78d1e0cf";
CustomRadioButtonStateRecord.init();
return CustomRadioButtonStateRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomRadioButtonStateRecord = CustomRadioButtonStateRecord;

});
define("ShopperPortalEU_UI_Components.model$PaddingSideOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$PaddingSideOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var PaddingSideOptionsRecord = (function (_super) {
__extends(PaddingSideOptionsRecord, _super);
function PaddingSideOptionsRecord(defaults) {
_super.apply(this, arguments);
}
PaddingSideOptionsRecord.attributesToDeclare = function () {
return [
this.attr("PaddingSideOptions", "paddingSideOptionsAttr", "PaddingSideOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.PaddingSideOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.PaddingSideOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
PaddingSideOptionsRecord.fromStructure = function (str) {
return new PaddingSideOptionsRecord(new PaddingSideOptionsRecord.RecordClass({
paddingSideOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
PaddingSideOptionsRecord._isAnonymousRecord = true;
PaddingSideOptionsRecord.UniqueId = "431bdd9e-e57c-95cb-849a-3dd39314c220";
PaddingSideOptionsRecord.init();
return PaddingSideOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.PaddingSideOptionsRecord = PaddingSideOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$MonthYearInputOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$MonthYearInputOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var MonthYearInputOptionsRecord = (function (_super) {
__extends(MonthYearInputOptionsRecord, _super);
function MonthYearInputOptionsRecord(defaults) {
_super.apply(this, arguments);
}
MonthYearInputOptionsRecord.attributesToDeclare = function () {
return [
this.attr("MonthYearInputOptions", "monthYearInputOptionsAttr", "MonthYearInputOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.MonthYearInputOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.MonthYearInputOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
MonthYearInputOptionsRecord.fromStructure = function (str) {
return new MonthYearInputOptionsRecord(new MonthYearInputOptionsRecord.RecordClass({
monthYearInputOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
MonthYearInputOptionsRecord._isAnonymousRecord = true;
MonthYearInputOptionsRecord.UniqueId = "4d37c0c2-a95f-e62c-36fb-feec927f598e";
MonthYearInputOptionsRecord.init();
return MonthYearInputOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.MonthYearInputOptionsRecord = MonthYearInputOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$MonthYearInputOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$MonthYearInputOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var MonthYearInputOptionsRecordList = (function (_super) {
__extends(MonthYearInputOptionsRecordList, _super);
function MonthYearInputOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
MonthYearInputOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.MonthYearInputOptionsRecord;
return MonthYearInputOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.MonthYearInputOptionsRecordList = MonthYearInputOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$ScanPassportErrorList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$ScanPassportErrorRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var ScanPassportErrorList = (function (_super) {
__extends(ScanPassportErrorList, _super);
function ScanPassportErrorList(defaults) {
_super.apply(this, arguments);
}
ScanPassportErrorList.itemType = ShopperPortalEU_UI_ComponentsModel.ScanPassportErrorRec;
return ScanPassportErrorList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.ScanPassportErrorList = ScanPassportErrorList;

});
define("ShopperPortalEU_UI_Components.model$CustomInputValidationOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomInputValidationOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomInputValidationOptionsList = (function (_super) {
__extends(CustomInputValidationOptionsList, _super);
function CustomInputValidationOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomInputValidationOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomInputValidationOptionsRec;
return CustomInputValidationOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomInputValidationOptionsList = CustomInputValidationOptionsList;

});
define("ShopperPortalEU_UI_Components.model$ScanPassportDataRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var ScanPassportDataRec = (function (_super) {
__extends(ScanPassportDataRec, _super);
function ScanPassportDataRec(defaults) {
_super.apply(this, arguments);
}
ScanPassportDataRec.attributesToDeclare = function () {
return [
this.attr("AllCheckDigitsValid", "allCheckDigitsValidAttr", "allCheckDigitsValid", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("CheckDigitDateOfBirth", "checkDigitDateOfBirthAttr", "checkDigitDateOfBirth", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("CheckDigitDateOfExpiry", "checkDigitDateOfExpiryAttr", "checkDigitDateOfExpiry", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("CheckDigitDocumentNumber", "checkDigitDocumentNumberAttr", "checkDigitDocumentNumber", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("CheckDigitFinal", "checkDigitFinalAttr", "checkDigitFinal", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("CheckDigitPersonalNumber", "checkDigitPersonalNumberAttr", "checkDigitPersonalNumber", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("DateOfBirth", "dateOfBirthAttr", "dateOfBirth", false, false, OS.DataTypes.DataTypes.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("DateOfExpiry", "dateOfExpiryAttr", "dateOfExpiry", false, false, OS.DataTypes.DataTypes.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("DocumentNumber", "documentNumberAttr", "documentNumber", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("DocumentType", "documentTypeAttr", "documentType", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("GivenNames", "givenNamesAttr", "givenNames", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Surname", "surnameAttr", "surname", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("IssuingCountryCode", "issuingCountryCodeAttr", "issuingCountryCode", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("MRZString", "mRZStringAttr", "mrzString", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("NationalityCountryCode", "nationalityCountryCodeAttr", "nationalityCountryCode", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("OptionalData", "optionalDataAttr", "optionalData", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("PersonalNumber", "personalNumberAttr", "personalNumber", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Sex", "sexAttr", "sex", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ScanPassportDataRec.init();
return ScanPassportDataRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.ScanPassportDataRec = ScanPassportDataRec;

});
define("ShopperPortalEU_UI_Components.model$ScanPassportDataRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$ScanPassportDataRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var ScanPassportDataRecord = (function (_super) {
__extends(ScanPassportDataRecord, _super);
function ScanPassportDataRecord(defaults) {
_super.apply(this, arguments);
}
ScanPassportDataRecord.attributesToDeclare = function () {
return [
this.attr("ScanPassportData", "scanPassportDataAttr", "ScanPassportData", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.ScanPassportDataRec());
}, true, ShopperPortalEU_UI_ComponentsModel.ScanPassportDataRec)
].concat(_super.attributesToDeclare.call(this));
};
ScanPassportDataRecord.fromStructure = function (str) {
return new ScanPassportDataRecord(new ScanPassportDataRecord.RecordClass({
scanPassportDataAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ScanPassportDataRecord._isAnonymousRecord = true;
ScanPassportDataRecord.UniqueId = "a545501d-baa2-1d95-5a5a-e7b648eb97dd";
ScanPassportDataRecord.init();
return ScanPassportDataRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.ScanPassportDataRecord = ScanPassportDataRecord;

});
define("ShopperPortalEU_UI_Components.model$ScanPassportDataRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$ScanPassportDataRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var ScanPassportDataRecordList = (function (_super) {
__extends(ScanPassportDataRecordList, _super);
function ScanPassportDataRecordList(defaults) {
_super.apply(this, arguments);
}
ScanPassportDataRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.ScanPassportDataRecord;
return ScanPassportDataRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.ScanPassportDataRecordList = ScanPassportDataRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomWizardItemStateRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomWizardItemStateRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomWizardItemStateRecordList = (function (_super) {
__extends(CustomWizardItemStateRecordList, _super);
function CustomWizardItemStateRecordList(defaults) {
_super.apply(this, arguments);
}
CustomWizardItemStateRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomWizardItemStateRecord;
return CustomWizardItemStateRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomWizardItemStateRecordList = CustomWizardItemStateRecordList;

});
define("ShopperPortalEU_UI_Components.model$StateBadgeTypeRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var StateBadgeTypeRec = (function (_super) {
__extends(StateBadgeTypeRec, _super);
function StateBadgeTypeRec(defaults) {
_super.apply(this, arguments);
}
StateBadgeTypeRec.attributesToDeclare = function () {
return [
this.attr("Class", "classAttr", "Class", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
StateBadgeTypeRec.fromStructure = function (str) {
return new StateBadgeTypeRec(new StateBadgeTypeRec.RecordClass({
classAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
StateBadgeTypeRec.init();
return StateBadgeTypeRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.StateBadgeTypeRec = StateBadgeTypeRec;

});
define("ShopperPortalEU_UI_Components.model$StateBadgeTypeList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$StateBadgeTypeRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var StateBadgeTypeList = (function (_super) {
__extends(StateBadgeTypeList, _super);
function StateBadgeTypeList(defaults) {
_super.apply(this, arguments);
}
StateBadgeTypeList.itemType = ShopperPortalEU_UI_ComponentsModel.StateBadgeTypeRec;
return StateBadgeTypeList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.StateBadgeTypeList = StateBadgeTypeList;

});
define("ShopperPortalEU_UI_Components.model$CustomListOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomListOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomListOptionsList = (function (_super) {
__extends(CustomListOptionsList, _super);
function CustomListOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomListOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomListOptionsRec;
return CustomListOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomListOptionsList = CustomListOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomCarouselOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomCarouselOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomCarouselOptionsList = (function (_super) {
__extends(CustomCarouselOptionsList, _super);
function CustomCarouselOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomCarouselOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomCarouselOptionsRec;
return CustomCarouselOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomCarouselOptionsList = CustomCarouselOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownSizeRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownSizeRec = (function (_super) {
__extends(CustomDropdownSizeRec, _super);
function CustomDropdownSizeRec(defaults) {
_super.apply(this, arguments);
}
CustomDropdownSizeRec.attributesToDeclare = function () {
return [
this.attr("Class", "classAttr", "Class", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomDropdownSizeRec.fromStructure = function (str) {
return new CustomDropdownSizeRec(new CustomDropdownSizeRec.RecordClass({
classAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomDropdownSizeRec.init();
return CustomDropdownSizeRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownSizeRec = CustomDropdownSizeRec;

});
define("ShopperPortalEU_UI_Components.model$OpenPDFOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$OpenPDFOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var OpenPDFOptionsList = (function (_super) {
__extends(OpenPDFOptionsList, _super);
function OpenPDFOptionsList(defaults) {
_super.apply(this, arguments);
}
OpenPDFOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.OpenPDFOptionsRec;
return OpenPDFOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.OpenPDFOptionsList = OpenPDFOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CodeInputValidationOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CodeInputValidationOptionsRec = (function (_super) {
__extends(CodeInputValidationOptionsRec, _super);
function CodeInputValidationOptionsRec(defaults) {
_super.apply(this, arguments);
}
CodeInputValidationOptionsRec.attributesToDeclare = function () {
return [
this.attr("State", "stateAttr", "state", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Message", "messageAttr", "message", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CodeInputValidationOptionsRec.init();
return CodeInputValidationOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CodeInputValidationOptionsRec = CodeInputValidationOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CodeInputValidationOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CodeInputValidationOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CodeInputValidationOptionsRecord = (function (_super) {
__extends(CodeInputValidationOptionsRecord, _super);
function CodeInputValidationOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CodeInputValidationOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CodeInputValidationOptions", "codeInputValidationOptionsAttr", "CodeInputValidationOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CodeInputValidationOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CodeInputValidationOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CodeInputValidationOptionsRecord.fromStructure = function (str) {
return new CodeInputValidationOptionsRecord(new CodeInputValidationOptionsRecord.RecordClass({
codeInputValidationOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CodeInputValidationOptionsRecord._isAnonymousRecord = true;
CodeInputValidationOptionsRecord.UniqueId = "92d540a8-d40e-01c7-36a3-f5d94a693375";
CodeInputValidationOptionsRecord.init();
return CodeInputValidationOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CodeInputValidationOptionsRecord = CodeInputValidationOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CodeInputValidationOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CodeInputValidationOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CodeInputValidationOptionsRecordList = (function (_super) {
__extends(CodeInputValidationOptionsRecordList, _super);
function CodeInputValidationOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CodeInputValidationOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CodeInputValidationOptionsRecord;
return CodeInputValidationOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CodeInputValidationOptionsRecordList = CodeInputValidationOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomUploadCameraOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomUploadCameraOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomUploadCameraOptionsList = (function (_super) {
__extends(CustomUploadCameraOptionsList, _super);
function CustomUploadCameraOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomUploadCameraOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomUploadCameraOptionsRec;
return CustomUploadCameraOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomUploadCameraOptionsList = CustomUploadCameraOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomTableEmptyOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomTableEmptyOptionsRec = (function (_super) {
__extends(CustomTableEmptyOptionsRec, _super);
function CustomTableEmptyOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomTableEmptyOptionsRec.attributesToDeclare = function () {
return [
this.attr("TitleTestId", "titleTestIdAttr", "titleTestId", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("IsEmpty", "isEmptyAttr", "isEmpty", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("Icon", "iconAttr", "icon", false, false, OS.DataTypes.DataTypes.Text, function () {
return "folder";
}, true), 
this.attr("Title", "titleAttr", "title", false, false, OS.DataTypes.DataTypes.Text, function () {
return "No items to show...";
}, true), 
this.attr("Description", "descriptionAttr", "description", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomTableEmptyOptionsRec.init();
return CustomTableEmptyOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomTableEmptyOptionsRec = CustomTableEmptyOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomBlankSlateOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomBlankSlateOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomBlankSlateOptionsList = (function (_super) {
__extends(CustomBlankSlateOptionsList, _super);
function CustomBlankSlateOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomBlankSlateOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomBlankSlateOptionsRec;
return CustomBlankSlateOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomBlankSlateOptionsList = CustomBlankSlateOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomInputValidationOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomInputValidationOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomInputValidationOptionsRecordList = (function (_super) {
__extends(CustomInputValidationOptionsRecordList, _super);
function CustomInputValidationOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomInputValidationOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomInputValidationOptionsRecord;
return CustomInputValidationOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomInputValidationOptionsRecordList = CustomInputValidationOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomTableOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomTableEmptyOptionsRec", "ShopperPortalEU_UI_Components.model$CustomTablePaginationOptionRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomTableOptionsRec = (function (_super) {
__extends(CustomTableOptionsRec, _super);
function CustomTableOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomTableOptionsRec.attributesToDeclare = function () {
return [
this.attr("TestId", "testIdAttr", "testId", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("IsLoading", "isLoadingAttr", "isLoading", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("TableSort", "tableSortAttr", "tableSort", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Empty", "emptyAttr", "empty", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomTableEmptyOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomTableEmptyOptionsRec), 
this.attr("Pagination", "paginationAttr", "pagination", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomTablePaginationOptionRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomTablePaginationOptionRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomTableOptionsRec.init();
return CustomTableOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomTableOptionsRec = CustomTableOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$ProgressBarOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$ProgressBarOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var ProgressBarOptionsList = (function (_super) {
__extends(ProgressBarOptionsList, _super);
function ProgressBarOptionsList(defaults) {
_super.apply(this, arguments);
}
ProgressBarOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.ProgressBarOptionsRec;
return ProgressBarOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.ProgressBarOptionsList = ProgressBarOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownCustomOptionList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomDropdownCustomOptionRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownCustomOptionList = (function (_super) {
__extends(CustomDropdownCustomOptionList, _super);
function CustomDropdownCustomOptionList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownCustomOptionList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomDropdownCustomOptionRec;
return CustomDropdownCustomOptionList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownCustomOptionList = CustomDropdownCustomOptionList;

});
define("ShopperPortalEU_UI_Components.model$CustomButtonItemOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomButtonItemOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomButtonItemOptionsRecord = (function (_super) {
__extends(CustomButtonItemOptionsRecord, _super);
function CustomButtonItemOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomButtonItemOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomButtonItemOptions", "customButtonItemOptionsAttr", "CustomButtonItemOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomButtonItemOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomButtonItemOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomButtonItemOptionsRecord.fromStructure = function (str) {
return new CustomButtonItemOptionsRecord(new CustomButtonItemOptionsRecord.RecordClass({
customButtonItemOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomButtonItemOptionsRecord._isAnonymousRecord = true;
CustomButtonItemOptionsRecord.UniqueId = "4fd97a60-dbd6-0302-787d-21a705380777";
CustomButtonItemOptionsRecord.init();
return CustomButtonItemOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomButtonItemOptionsRecord = CustomButtonItemOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$FullHeightContentOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$FullHeightContentTopOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentBottomOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var FullHeightContentOptionsRec = (function (_super) {
__extends(FullHeightContentOptionsRec, _super);
function FullHeightContentOptionsRec(defaults) {
_super.apply(this, arguments);
}
FullHeightContentOptionsRec.attributesToDeclare = function () {
return [
this.attr("Top", "topAttr", "top", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.FullHeightContentTopOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.FullHeightContentTopOptionsRec), 
this.attr("Bottom", "bottomAttr", "bottom", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.FullHeightContentBottomOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.FullHeightContentBottomOptionsRec), 
this.attr("GrowBottom", "growBottomAttr", "growBottom", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("Spacing", "spacingAttr", "spacing", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
FullHeightContentOptionsRec.init();
return FullHeightContentOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.FullHeightContentOptionsRec = FullHeightContentOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$FullHeightContentOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$FullHeightContentOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var FullHeightContentOptionsRecord = (function (_super) {
__extends(FullHeightContentOptionsRecord, _super);
function FullHeightContentOptionsRecord(defaults) {
_super.apply(this, arguments);
}
FullHeightContentOptionsRecord.attributesToDeclare = function () {
return [
this.attr("FullHeightContentOptions", "fullHeightContentOptionsAttr", "FullHeightContentOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.FullHeightContentOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.FullHeightContentOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
FullHeightContentOptionsRecord.fromStructure = function (str) {
return new FullHeightContentOptionsRecord(new FullHeightContentOptionsRecord.RecordClass({
fullHeightContentOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
FullHeightContentOptionsRecord._isAnonymousRecord = true;
FullHeightContentOptionsRecord.UniqueId = "4ff0cf98-6580-2aa1-828d-93be2e3ede93";
FullHeightContentOptionsRecord.init();
return FullHeightContentOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.FullHeightContentOptionsRecord = FullHeightContentOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomPaginationOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomPaginationOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomPaginationOptionsList = (function (_super) {
__extends(CustomPaginationOptionsList, _super);
function CustomPaginationOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomPaginationOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomPaginationOptionsRec;
return CustomPaginationOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomPaginationOptionsList = CustomPaginationOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomRadioGroupOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomRadioGroupOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomRadioGroupOptionsRecord = (function (_super) {
__extends(CustomRadioGroupOptionsRecord, _super);
function CustomRadioGroupOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomRadioGroupOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomRadioGroupOptions", "customRadioGroupOptionsAttr", "CustomRadioGroupOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomRadioGroupOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomRadioGroupOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomRadioGroupOptionsRecord.fromStructure = function (str) {
return new CustomRadioGroupOptionsRecord(new CustomRadioGroupOptionsRecord.RecordClass({
customRadioGroupOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomRadioGroupOptionsRecord._isAnonymousRecord = true;
CustomRadioGroupOptionsRecord.UniqueId = "962b038f-5f74-231a-7f64-8a4b5c0bda40";
CustomRadioGroupOptionsRecord.init();
return CustomRadioGroupOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomRadioGroupOptionsRecord = CustomRadioGroupOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomRadioGroupOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomRadioGroupOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomRadioGroupOptionsRecordList = (function (_super) {
__extends(CustomRadioGroupOptionsRecordList, _super);
function CustomRadioGroupOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomRadioGroupOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomRadioGroupOptionsRecord;
return CustomRadioGroupOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomRadioGroupOptionsRecordList = CustomRadioGroupOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomButtonStateRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomButtonStateRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomButtonStateRecord = (function (_super) {
__extends(CustomButtonStateRecord, _super);
function CustomButtonStateRecord(defaults) {
_super.apply(this, arguments);
}
CustomButtonStateRecord.attributesToDeclare = function () {
return [
this.attr("CustomButtonState", "customButtonStateAttr", "CustomButtonState", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomButtonStateRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomButtonStateRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomButtonStateRecord.fromStructure = function (str) {
return new CustomButtonStateRecord(new CustomButtonStateRecord.RecordClass({
customButtonStateAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomButtonStateRecord._isAnonymousRecord = true;
CustomButtonStateRecord.UniqueId = "50d4a692-7ce0-b24a-6267-b730d4bd35f3";
CustomButtonStateRecord.init();
return CustomButtonStateRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomButtonStateRecord = CustomButtonStateRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomWizardItemOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomWizardItemOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomWizardItemOptionsRecord = (function (_super) {
__extends(CustomWizardItemOptionsRecord, _super);
function CustomWizardItemOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomWizardItemOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomWizardItemOptions", "customWizardItemOptionsAttr", "CustomWizardItemOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomWizardItemOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomWizardItemOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomWizardItemOptionsRecord.fromStructure = function (str) {
return new CustomWizardItemOptionsRecord(new CustomWizardItemOptionsRecord.RecordClass({
customWizardItemOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomWizardItemOptionsRecord._isAnonymousRecord = true;
CustomWizardItemOptionsRecord.UniqueId = "932bdcef-d9ef-a1ca-c846-4ef0342f66fb";
CustomWizardItemOptionsRecord.init();
return CustomWizardItemOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomWizardItemOptionsRecord = CustomWizardItemOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomWizardItemOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomWizardItemOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomWizardItemOptionsRecordList = (function (_super) {
__extends(CustomWizardItemOptionsRecordList, _super);
function CustomWizardItemOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomWizardItemOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomWizardItemOptionsRecord;
return CustomWizardItemOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomWizardItemOptionsRecordList = CustomWizardItemOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$TextEllipsisOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$TextEllipsisOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var TextEllipsisOptionsRecord = (function (_super) {
__extends(TextEllipsisOptionsRecord, _super);
function TextEllipsisOptionsRecord(defaults) {
_super.apply(this, arguments);
}
TextEllipsisOptionsRecord.attributesToDeclare = function () {
return [
this.attr("TextEllipsisOptions", "textEllipsisOptionsAttr", "TextEllipsisOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.TextEllipsisOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.TextEllipsisOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
TextEllipsisOptionsRecord.fromStructure = function (str) {
return new TextEllipsisOptionsRecord(new TextEllipsisOptionsRecord.RecordClass({
textEllipsisOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
TextEllipsisOptionsRecord._isAnonymousRecord = true;
TextEllipsisOptionsRecord.UniqueId = "51f44412-2ef6-4c13-b027-eec7d12af7f9";
TextEllipsisOptionsRecord.init();
return TextEllipsisOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.TextEllipsisOptionsRecord = TextEllipsisOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$FlexOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$FlexOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var FlexOptionsList = (function (_super) {
__extends(FlexOptionsList, _super);
function FlexOptionsList(defaults) {
_super.apply(this, arguments);
}
FlexOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec;
return FlexOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.FlexOptionsList = FlexOptionsList;

});
define("ShopperPortalEU_UI_Components.model$FullHeightContentAlignmentList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$FullHeightContentAlignmentRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var FullHeightContentAlignmentList = (function (_super) {
__extends(FullHeightContentAlignmentList, _super);
function FullHeightContentAlignmentList(defaults) {
_super.apply(this, arguments);
}
FullHeightContentAlignmentList.itemType = ShopperPortalEU_UI_ComponentsModel.FullHeightContentAlignmentRec;
return FullHeightContentAlignmentList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.FullHeightContentAlignmentList = FullHeightContentAlignmentList;

});
define("ShopperPortalEU_UI_Components.model$CustomTimelineOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomTimelineOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomTimelineOptionsRecord = (function (_super) {
__extends(CustomTimelineOptionsRecord, _super);
function CustomTimelineOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomTimelineOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomTimelineOptions", "customTimelineOptionsAttr", "CustomTimelineOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomTimelineOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomTimelineOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomTimelineOptionsRecord.fromStructure = function (str) {
return new CustomTimelineOptionsRecord(new CustomTimelineOptionsRecord.RecordClass({
customTimelineOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomTimelineOptionsRecord._isAnonymousRecord = true;
CustomTimelineOptionsRecord.UniqueId = "8a4edb1e-7a1a-b0bd-6229-0c91214c78eb";
CustomTimelineOptionsRecord.init();
return CustomTimelineOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomTimelineOptionsRecord = CustomTimelineOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomTimelineOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomTimelineOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomTimelineOptionsRecordList = (function (_super) {
__extends(CustomTimelineOptionsRecordList, _super);
function CustomTimelineOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomTimelineOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomTimelineOptionsRecord;
return CustomTimelineOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomTimelineOptionsRecordList = CustomTimelineOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomCheckboxStateRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomCheckboxStateRec = (function (_super) {
__extends(CustomCheckboxStateRec, _super);
function CustomCheckboxStateRec(defaults) {
_super.apply(this, arguments);
}
CustomCheckboxStateRec.attributesToDeclare = function () {
return [
this.attr("Class", "classAttr", "Class", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomCheckboxStateRec.fromStructure = function (str) {
return new CustomCheckboxStateRec(new CustomCheckboxStateRec.RecordClass({
classAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomCheckboxStateRec.init();
return CustomCheckboxStateRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomCheckboxStateRec = CustomCheckboxStateRec;

});
define("ShopperPortalEU_UI_Components.model$LabelValueOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var LabelValueOptionsRec = (function (_super) {
__extends(LabelValueOptionsRec, _super);
function LabelValueOptionsRec(defaults) {
_super.apply(this, arguments);
}
LabelValueOptionsRec.attributesToDeclare = function () {
return [
this.attr("TestId", "testIdAttr", "testId", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("TopLabel", "topLabelAttr", "topLabel", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return true;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
LabelValueOptionsRec.init();
return LabelValueOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.LabelValueOptionsRec = LabelValueOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$LabelValueOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$LabelValueOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var LabelValueOptionsRecord = (function (_super) {
__extends(LabelValueOptionsRecord, _super);
function LabelValueOptionsRecord(defaults) {
_super.apply(this, arguments);
}
LabelValueOptionsRecord.attributesToDeclare = function () {
return [
this.attr("LabelValueOptions", "labelValueOptionsAttr", "LabelValueOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.LabelValueOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.LabelValueOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
LabelValueOptionsRecord.fromStructure = function (str) {
return new LabelValueOptionsRecord(new LabelValueOptionsRecord.RecordClass({
labelValueOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
LabelValueOptionsRecord._isAnonymousRecord = true;
LabelValueOptionsRecord.UniqueId = "53052aae-d28f-779c-0576-d2eb2ed88001";
LabelValueOptionsRecord.init();
return LabelValueOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.LabelValueOptionsRecord = LabelValueOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomListItemClickableOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomListItemClickableOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomListItemClickableOptionsRecord = (function (_super) {
__extends(CustomListItemClickableOptionsRecord, _super);
function CustomListItemClickableOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomListItemClickableOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomListItemClickableOptions", "customListItemClickableOptionsAttr", "CustomListItemClickableOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomListItemClickableOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomListItemClickableOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomListItemClickableOptionsRecord.fromStructure = function (str) {
return new CustomListItemClickableOptionsRecord(new CustomListItemClickableOptionsRecord.RecordClass({
customListItemClickableOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomListItemClickableOptionsRecord._isAnonymousRecord = true;
CustomListItemClickableOptionsRecord.UniqueId = "d4e3c7f9-85af-94f7-94ec-fedeab4b4ed9";
CustomListItemClickableOptionsRecord.init();
return CustomListItemClickableOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomListItemClickableOptionsRecord = CustomListItemClickableOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomListItemClickableOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomListItemClickableOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomListItemClickableOptionsRecordList = (function (_super) {
__extends(CustomListItemClickableOptionsRecordList, _super);
function CustomListItemClickableOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomListItemClickableOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomListItemClickableOptionsRecord;
return CustomListItemClickableOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomListItemClickableOptionsRecordList = CustomListItemClickableOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownCustomOptionRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomDropdownCustomOptionRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownCustomOptionRecordList = (function (_super) {
__extends(CustomDropdownCustomOptionRecordList, _super);
function CustomDropdownCustomOptionRecordList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownCustomOptionRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomDropdownCustomOptionRecord;
return CustomDropdownCustomOptionRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownCustomOptionRecordList = CustomDropdownCustomOptionRecordList;

});
define("ShopperPortalEU_UI_Components.model$DatePickerValidationOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$DatePickerValidationOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var DatePickerValidationOptionsList = (function (_super) {
__extends(DatePickerValidationOptionsList, _super);
function DatePickerValidationOptionsList(defaults) {
_super.apply(this, arguments);
}
DatePickerValidationOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.DatePickerValidationOptionsRec;
return DatePickerValidationOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.DatePickerValidationOptionsList = DatePickerValidationOptionsList;

});
define("ShopperPortalEU_UI_Components.model$DatePickerChangeOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$DatePickerChangeOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var DatePickerChangeOptionsRecordList = (function (_super) {
__extends(DatePickerChangeOptionsRecordList, _super);
function DatePickerChangeOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
DatePickerChangeOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.DatePickerChangeOptionsRecord;
return DatePickerChangeOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.DatePickerChangeOptionsRecordList = DatePickerChangeOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$DatePickerValidationOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$DatePickerValidationOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var DatePickerValidationOptionsRecord = (function (_super) {
__extends(DatePickerValidationOptionsRecord, _super);
function DatePickerValidationOptionsRecord(defaults) {
_super.apply(this, arguments);
}
DatePickerValidationOptionsRecord.attributesToDeclare = function () {
return [
this.attr("DatePickerValidationOptions", "datePickerValidationOptionsAttr", "DatePickerValidationOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.DatePickerValidationOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.DatePickerValidationOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
DatePickerValidationOptionsRecord.fromStructure = function (str) {
return new DatePickerValidationOptionsRecord(new DatePickerValidationOptionsRecord.RecordClass({
datePickerValidationOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
DatePickerValidationOptionsRecord._isAnonymousRecord = true;
DatePickerValidationOptionsRecord.UniqueId = "fb32c8f6-5f1e-940d-2004-040fbcfe6154";
DatePickerValidationOptionsRecord.init();
return DatePickerValidationOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.DatePickerValidationOptionsRecord = DatePickerValidationOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$DatePickerValidationOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$DatePickerValidationOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var DatePickerValidationOptionsRecordList = (function (_super) {
__extends(DatePickerValidationOptionsRecordList, _super);
function DatePickerValidationOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
DatePickerValidationOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.DatePickerValidationOptionsRecord;
return DatePickerValidationOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.DatePickerValidationOptionsRecordList = DatePickerValidationOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomLinkItemOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomLinkItemOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomLinkItemOptionsList = (function (_super) {
__extends(CustomLinkItemOptionsList, _super);
function CustomLinkItemOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomLinkItemOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomLinkItemOptionsRec;
return CustomLinkItemOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomLinkItemOptionsList = CustomLinkItemOptionsList;

});
define("ShopperPortalEU_UI_Components.model$PhoneNumberInputChangeOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$PhoneNumberInputChangeOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var PhoneNumberInputChangeOptionsRecord = (function (_super) {
__extends(PhoneNumberInputChangeOptionsRecord, _super);
function PhoneNumberInputChangeOptionsRecord(defaults) {
_super.apply(this, arguments);
}
PhoneNumberInputChangeOptionsRecord.attributesToDeclare = function () {
return [
this.attr("PhoneNumberInputChangeOptions", "phoneNumberInputChangeOptionsAttr", "PhoneNumberInputChangeOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputChangeOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputChangeOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
PhoneNumberInputChangeOptionsRecord.fromStructure = function (str) {
return new PhoneNumberInputChangeOptionsRecord(new PhoneNumberInputChangeOptionsRecord.RecordClass({
phoneNumberInputChangeOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
PhoneNumberInputChangeOptionsRecord._isAnonymousRecord = true;
PhoneNumberInputChangeOptionsRecord.UniqueId = "c7a7fece-d8b2-7099-12d6-345f1560791f";
PhoneNumberInputChangeOptionsRecord.init();
return PhoneNumberInputChangeOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputChangeOptionsRecord = PhoneNumberInputChangeOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$PhoneNumberInputChangeOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$PhoneNumberInputChangeOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var PhoneNumberInputChangeOptionsRecordList = (function (_super) {
__extends(PhoneNumberInputChangeOptionsRecordList, _super);
function PhoneNumberInputChangeOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
PhoneNumberInputChangeOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputChangeOptionsRecord;
return PhoneNumberInputChangeOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputChangeOptionsRecordList = PhoneNumberInputChangeOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$ScanBarcodeDataList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$ScanBarcodeDataRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var ScanBarcodeDataList = (function (_super) {
__extends(ScanBarcodeDataList, _super);
function ScanBarcodeDataList(defaults) {
_super.apply(this, arguments);
}
ScanBarcodeDataList.itemType = ShopperPortalEU_UI_ComponentsModel.ScanBarcodeDataRec;
return ScanBarcodeDataList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.ScanBarcodeDataList = ScanBarcodeDataList;

});
define("ShopperPortalEU_UI_Components.model$CreditCardSwipeOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CreditCardSwipeOptionsRec = (function (_super) {
__extends(CreditCardSwipeOptionsRec, _super);
function CreditCardSwipeOptionsRec(defaults) {
_super.apply(this, arguments);
}
CreditCardSwipeOptionsRec.attributesToDeclare = function () {
return [
this.attr("SwipeToDelete", "swipeToDeleteAttr", "swipeToDelete", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("Label", "labelAttr", "label", false, false, OS.DataTypes.DataTypes.Text, function () {
return "Delete";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CreditCardSwipeOptionsRec.init();
return CreditCardSwipeOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CreditCardSwipeOptionsRec = CreditCardSwipeOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomButtonStateRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomButtonStateRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomButtonStateRecordList = (function (_super) {
__extends(CustomButtonStateRecordList, _super);
function CustomButtonStateRecordList(defaults) {
_super.apply(this, arguments);
}
CustomButtonStateRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomButtonStateRecord;
return CustomButtonStateRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomButtonStateRecordList = CustomButtonStateRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomTabsOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomTabsOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomTabsOptionsRecord = (function (_super) {
__extends(CustomTabsOptionsRecord, _super);
function CustomTabsOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomTabsOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomTabsOptions", "customTabsOptionsAttr", "CustomTabsOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomTabsOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomTabsOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomTabsOptionsRecord.fromStructure = function (str) {
return new CustomTabsOptionsRecord(new CustomTabsOptionsRecord.RecordClass({
customTabsOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomTabsOptionsRecord._isAnonymousRecord = true;
CustomTabsOptionsRecord.UniqueId = "bd197374-d559-f3df-8bee-49155c11ab6e";
CustomTabsOptionsRecord.init();
return CustomTabsOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomTabsOptionsRecord = CustomTabsOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomTabsOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomTabsOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomTabsOptionsRecordList = (function (_super) {
__extends(CustomTabsOptionsRecordList, _super);
function CustomTabsOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomTabsOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomTabsOptionsRecord;
return CustomTabsOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomTabsOptionsRecordList = CustomTabsOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CodeInputOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CodeInputValidationOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CodeInputOptionsRec = (function (_super) {
__extends(CodeInputOptionsRec, _super);
function CodeInputOptionsRec(defaults) {
_super.apply(this, arguments);
}
CodeInputOptionsRec.attributesToDeclare = function () {
return [
this.attr("TestId", "testIdAttr", "testId", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Code", "codeAttr", "code", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Length", "lengthAttr", "length", false, false, OS.DataTypes.DataTypes.Integer, function () {
return 6;
}, true), 
this.attr("FocusOnStart", "focusOnStartAttr", "focusOnStart", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return true;
}, true), 
this.attr("IsDisabled", "isDisabledAttr", "disabled", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("Validation", "validationAttr", "validation", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CodeInputValidationOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CodeInputValidationOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CodeInputOptionsRec.init();
return CodeInputOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CodeInputOptionsRec = CodeInputOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CodeInputOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CodeInputOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CodeInputOptionsRecord = (function (_super) {
__extends(CodeInputOptionsRecord, _super);
function CodeInputOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CodeInputOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CodeInputOptions", "codeInputOptionsAttr", "CodeInputOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CodeInputOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CodeInputOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CodeInputOptionsRecord.fromStructure = function (str) {
return new CodeInputOptionsRecord(new CodeInputOptionsRecord.RecordClass({
codeInputOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CodeInputOptionsRecord._isAnonymousRecord = true;
CodeInputOptionsRecord.UniqueId = "6c3a2e79-7911-d4b0-15a7-0e7c51f36896";
CodeInputOptionsRecord.init();
return CodeInputOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CodeInputOptionsRecord = CodeInputOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CodeInputOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CodeInputOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CodeInputOptionsRecordList = (function (_super) {
__extends(CodeInputOptionsRecordList, _super);
function CodeInputOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CodeInputOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CodeInputOptionsRecord;
return CodeInputOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CodeInputOptionsRecordList = CodeInputOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomTableOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomTableOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomTableOptionsList = (function (_super) {
__extends(CustomTableOptionsList, _super);
function CustomTableOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomTableOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomTableOptionsRec;
return CustomTableOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomTableOptionsList = CustomTableOptionsList;

});
define("ShopperPortalEU_UI_Components.model$FlexAlignRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var FlexAlignRec = (function (_super) {
__extends(FlexAlignRec, _super);
function FlexAlignRec(defaults) {
_super.apply(this, arguments);
}
FlexAlignRec.attributesToDeclare = function () {
return [
this.attr("Class", "classAttr", "Class", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
FlexAlignRec.fromStructure = function (str) {
return new FlexAlignRec(new FlexAlignRec.RecordClass({
classAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
FlexAlignRec.init();
return FlexAlignRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.FlexAlignRec = FlexAlignRec;

});
define("ShopperPortalEU_UI_Components.model$CustomPopupLayoutHeaderImageOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomPopupLayoutHeaderImageOptionsRec = (function (_super) {
__extends(CustomPopupLayoutHeaderImageOptionsRec, _super);
function CustomPopupLayoutHeaderImageOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomPopupLayoutHeaderImageOptionsRec.attributesToDeclare = function () {
return [
this.attr("URL", "uRLAttr", "url", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomPopupLayoutHeaderImageOptionsRec.fromStructure = function (str) {
return new CustomPopupLayoutHeaderImageOptionsRec(new CustomPopupLayoutHeaderImageOptionsRec.RecordClass({
uRLAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomPopupLayoutHeaderImageOptionsRec.init();
return CustomPopupLayoutHeaderImageOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomPopupLayoutHeaderImageOptionsRec = CustomPopupLayoutHeaderImageOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomRadioButtonStateList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomRadioButtonStateRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomRadioButtonStateList = (function (_super) {
__extends(CustomRadioButtonStateList, _super);
function CustomRadioButtonStateList(defaults) {
_super.apply(this, arguments);
}
CustomRadioButtonStateList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomRadioButtonStateRec;
return CustomRadioButtonStateList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomRadioButtonStateList = CustomRadioButtonStateList;

});
define("ShopperPortalEU_UI_Components.model$ScanPassportPropertiesRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var ScanPassportPropertiesRec = (function (_super) {
__extends(ScanPassportPropertiesRec, _super);
function ScanPassportPropertiesRec(defaults) {
_super.apply(this, arguments);
}
ScanPassportPropertiesRec.attributesToDeclare = function () {
return [
this.attr("License", "licenseAttr", "license", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ScanPassportPropertiesRec.fromStructure = function (str) {
return new ScanPassportPropertiesRec(new ScanPassportPropertiesRec.RecordClass({
licenseAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ScanPassportPropertiesRec.init();
return ScanPassportPropertiesRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.ScanPassportPropertiesRec = ScanPassportPropertiesRec;

});
define("ShopperPortalEU_UI_Components.model$CodeInputChangeOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CodeInputChangeOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CodeInputChangeOptionsRecord = (function (_super) {
__extends(CodeInputChangeOptionsRecord, _super);
function CodeInputChangeOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CodeInputChangeOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CodeInputChangeOptions", "codeInputChangeOptionsAttr", "CodeInputChangeOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CodeInputChangeOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CodeInputChangeOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CodeInputChangeOptionsRecord.fromStructure = function (str) {
return new CodeInputChangeOptionsRecord(new CodeInputChangeOptionsRecord.RecordClass({
codeInputChangeOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CodeInputChangeOptionsRecord._isAnonymousRecord = true;
CodeInputChangeOptionsRecord.UniqueId = "5b98598a-c143-8cb2-6bdc-4047cc074f96";
CodeInputChangeOptionsRecord.init();
return CodeInputChangeOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CodeInputChangeOptionsRecord = CodeInputChangeOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomLinkItemOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomLinkItemOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomLinkItemOptionsRecordList = (function (_super) {
__extends(CustomLinkItemOptionsRecordList, _super);
function CustomLinkItemOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomLinkItemOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomLinkItemOptionsRecord;
return CustomLinkItemOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomLinkItemOptionsRecordList = CustomLinkItemOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomIconFamilyRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomIconFamilyRec = (function (_super) {
__extends(CustomIconFamilyRec, _super);
function CustomIconFamilyRec(defaults) {
_super.apply(this, arguments);
}
CustomIconFamilyRec.attributesToDeclare = function () {
return [
this.attr("Class", "classAttr", "Class", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Label", "labelAttr", "Label", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", false, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomIconFamilyRec.init();
return CustomIconFamilyRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomIconFamilyRec = CustomIconFamilyRec;

});
define("ShopperPortalEU_UI_Components.model$CustomIconFamilyList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomIconFamilyRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomIconFamilyList = (function (_super) {
__extends(CustomIconFamilyList, _super);
function CustomIconFamilyList(defaults) {
_super.apply(this, arguments);
}
CustomIconFamilyList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomIconFamilyRec;
return CustomIconFamilyList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomIconFamilyList = CustomIconFamilyList;

});
define("ShopperPortalEU_UI_Components.model$CustomTableEmptyOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomTableEmptyOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomTableEmptyOptionsRecord = (function (_super) {
__extends(CustomTableEmptyOptionsRecord, _super);
function CustomTableEmptyOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomTableEmptyOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomTableEmptyOptions", "customTableEmptyOptionsAttr", "CustomTableEmptyOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomTableEmptyOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomTableEmptyOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomTableEmptyOptionsRecord.fromStructure = function (str) {
return new CustomTableEmptyOptionsRecord(new CustomTableEmptyOptionsRecord.RecordClass({
customTableEmptyOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomTableEmptyOptionsRecord._isAnonymousRecord = true;
CustomTableEmptyOptionsRecord.UniqueId = "f32df97e-e522-a313-4302-5297c46f8a92";
CustomTableEmptyOptionsRecord.init();
return CustomTableEmptyOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomTableEmptyOptionsRecord = CustomTableEmptyOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomTableEmptyOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomTableEmptyOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomTableEmptyOptionsRecordList = (function (_super) {
__extends(CustomTableEmptyOptionsRecordList, _super);
function CustomTableEmptyOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomTableEmptyOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomTableEmptyOptionsRecord;
return CustomTableEmptyOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomTableEmptyOptionsRecordList = CustomTableEmptyOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomRadioButtonOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomRadioButtonOptionsRec = (function (_super) {
__extends(CustomRadioButtonOptionsRec, _super);
function CustomRadioButtonOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomRadioButtonOptionsRec.attributesToDeclare = function () {
return [
this.attr("TestId", "testIdAttr", "testId", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Value", "valueAttr", "value", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("IsSeparated", "isSeparatedAttr", "separated", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomRadioButtonOptionsRec.init();
return CustomRadioButtonOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomRadioButtonOptionsRec = CustomRadioButtonOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomRadioButtonOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomRadioButtonOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomRadioButtonOptionsRecord = (function (_super) {
__extends(CustomRadioButtonOptionsRecord, _super);
function CustomRadioButtonOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomRadioButtonOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomRadioButtonOptions", "customRadioButtonOptionsAttr", "CustomRadioButtonOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomRadioButtonOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomRadioButtonOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomRadioButtonOptionsRecord.fromStructure = function (str) {
return new CustomRadioButtonOptionsRecord(new CustomRadioButtonOptionsRecord.RecordClass({
customRadioButtonOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomRadioButtonOptionsRecord._isAnonymousRecord = true;
CustomRadioButtonOptionsRecord.UniqueId = "9e2a971c-60e5-6bf3-ba1a-f412a3275e31";
CustomRadioButtonOptionsRecord.init();
return CustomRadioButtonOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomRadioButtonOptionsRecord = CustomRadioButtonOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomRadioButtonOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomRadioButtonOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomRadioButtonOptionsRecordList = (function (_super) {
__extends(CustomRadioButtonOptionsRecordList, _super);
function CustomRadioButtonOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomRadioButtonOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomRadioButtonOptionsRecord;
return CustomRadioButtonOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomRadioButtonOptionsRecordList = CustomRadioButtonOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$PaddingSideOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$PaddingSideOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var PaddingSideOptionsRecordList = (function (_super) {
__extends(PaddingSideOptionsRecordList, _super);
function PaddingSideOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
PaddingSideOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.PaddingSideOptionsRecord;
return PaddingSideOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.PaddingSideOptionsRecordList = PaddingSideOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$BarcodeOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$BarcodeOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var BarcodeOptionsRecordList = (function (_super) {
__extends(BarcodeOptionsRecordList, _super);
function BarcodeOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
BarcodeOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.BarcodeOptionsRecord;
return BarcodeOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.BarcodeOptionsRecordList = BarcodeOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomFlagOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomFlagOptionsRec = (function (_super) {
__extends(CustomFlagOptionsRec, _super);
function CustomFlagOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomFlagOptionsRec.attributesToDeclare = function () {
return [
this.attr("TestId", "testIdAttr", "testId", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Flag", "flagAttr", "flag", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("IsDisabled", "isDisabledAttr", "disabled", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomFlagOptionsRec.init();
return CustomFlagOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomFlagOptionsRec = CustomFlagOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$FlexDirectionList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$FlexDirectionRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var FlexDirectionList = (function (_super) {
__extends(FlexDirectionList, _super);
function FlexDirectionList(defaults) {
_super.apply(this, arguments);
}
FlexDirectionList.itemType = ShopperPortalEU_UI_ComponentsModel.FlexDirectionRec;
return FlexDirectionList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.FlexDirectionList = FlexDirectionList;

});
define("ShopperPortalEU_UI_Components.model$DatatransCardGetCardInfoOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$DatatransCardGetCardInfoDataOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var DatatransCardGetCardInfoOptionsRec = (function (_super) {
__extends(DatatransCardGetCardInfoOptionsRec, _super);
function DatatransCardGetCardInfoOptionsRec(defaults) {
_super.apply(this, arguments);
}
DatatransCardGetCardInfoOptionsRec.attributesToDeclare = function () {
return [
this.attr("Data", "dataAttr", "data", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.DatatransCardGetCardInfoDataOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.DatatransCardGetCardInfoDataOptionsRec), 
this.attr("MaskedCard", "maskedCardAttr", "maskedCard", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("PaymentMethod", "paymentMethodAttr", "paymentMethod", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
DatatransCardGetCardInfoOptionsRec.init();
return DatatransCardGetCardInfoOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.DatatransCardGetCardInfoOptionsRec = DatatransCardGetCardInfoOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$DatatransCardGetCardInfoOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$DatatransCardGetCardInfoOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var DatatransCardGetCardInfoOptionsRecord = (function (_super) {
__extends(DatatransCardGetCardInfoOptionsRecord, _super);
function DatatransCardGetCardInfoOptionsRecord(defaults) {
_super.apply(this, arguments);
}
DatatransCardGetCardInfoOptionsRecord.attributesToDeclare = function () {
return [
this.attr("DatatransCardGetCardInfoOptions", "datatransCardGetCardInfoOptionsAttr", "DatatransCardGetCardInfoOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.DatatransCardGetCardInfoOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.DatatransCardGetCardInfoOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
DatatransCardGetCardInfoOptionsRecord.fromStructure = function (str) {
return new DatatransCardGetCardInfoOptionsRecord(new DatatransCardGetCardInfoOptionsRecord.RecordClass({
datatransCardGetCardInfoOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
DatatransCardGetCardInfoOptionsRecord._isAnonymousRecord = true;
DatatransCardGetCardInfoOptionsRecord.UniqueId = "cae69dc8-47e8-a684-b8e3-b5841b3d6209";
DatatransCardGetCardInfoOptionsRecord.init();
return DatatransCardGetCardInfoOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.DatatransCardGetCardInfoOptionsRecord = DatatransCardGetCardInfoOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$DatatransCardGetCardInfoOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$DatatransCardGetCardInfoOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var DatatransCardGetCardInfoOptionsRecordList = (function (_super) {
__extends(DatatransCardGetCardInfoOptionsRecordList, _super);
function DatatransCardGetCardInfoOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
DatatransCardGetCardInfoOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.DatatransCardGetCardInfoOptionsRecord;
return DatatransCardGetCardInfoOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.DatatransCardGetCardInfoOptionsRecordList = DatatransCardGetCardInfoOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$FlexJustifyRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var FlexJustifyRec = (function (_super) {
__extends(FlexJustifyRec, _super);
function FlexJustifyRec(defaults) {
_super.apply(this, arguments);
}
FlexJustifyRec.attributesToDeclare = function () {
return [
this.attr("Class", "classAttr", "Class", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
FlexJustifyRec.fromStructure = function (str) {
return new FlexJustifyRec(new FlexJustifyRec.RecordClass({
classAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
FlexJustifyRec.init();
return FlexJustifyRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.FlexJustifyRec = FlexJustifyRec;

});
define("ShopperPortalEU_UI_Components.model$FlexJustifyRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$FlexJustifyRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var FlexJustifyRecord = (function (_super) {
__extends(FlexJustifyRecord, _super);
function FlexJustifyRecord(defaults) {
_super.apply(this, arguments);
}
FlexJustifyRecord.attributesToDeclare = function () {
return [
this.attr("FlexJustify", "flexJustifyAttr", "FlexJustify", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.FlexJustifyRec());
}, true, ShopperPortalEU_UI_ComponentsModel.FlexJustifyRec)
].concat(_super.attributesToDeclare.call(this));
};
FlexJustifyRecord.fromStructure = function (str) {
return new FlexJustifyRecord(new FlexJustifyRecord.RecordClass({
flexJustifyAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
FlexJustifyRecord._isAnonymousRecord = true;
FlexJustifyRecord.UniqueId = "618b6741-e963-0839-9844-1cc2ba59f3ca";
FlexJustifyRecord.init();
return FlexJustifyRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.FlexJustifyRecord = FlexJustifyRecord;

});
define("ShopperPortalEU_UI_Components.model$ButtonOptionStateRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$ButtonOptionStateRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var ButtonOptionStateRecordList = (function (_super) {
__extends(ButtonOptionStateRecordList, _super);
function ButtonOptionStateRecordList(defaults) {
_super.apply(this, arguments);
}
ButtonOptionStateRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.ButtonOptionStateRecord;
return ButtonOptionStateRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.ButtonOptionStateRecordList = ButtonOptionStateRecordList;

});
define("ShopperPortalEU_UI_Components.model$PhoneNumberInputSearchOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$PhoneNumberInputSearchOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var PhoneNumberInputSearchOptionsList = (function (_super) {
__extends(PhoneNumberInputSearchOptionsList, _super);
function PhoneNumberInputSearchOptionsList(defaults) {
_super.apply(this, arguments);
}
PhoneNumberInputSearchOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputSearchOptionsRec;
return PhoneNumberInputSearchOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputSearchOptionsList = PhoneNumberInputSearchOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomPopupLayoutHeaderImageOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomPopupLayoutHeaderImageOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomPopupLayoutHeaderImageOptionsRecord = (function (_super) {
__extends(CustomPopupLayoutHeaderImageOptionsRecord, _super);
function CustomPopupLayoutHeaderImageOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomPopupLayoutHeaderImageOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomPopupLayoutHeaderImageOptions", "customPopupLayoutHeaderImageOptionsAttr", "CustomPopupLayoutHeaderImageOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomPopupLayoutHeaderImageOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomPopupLayoutHeaderImageOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomPopupLayoutHeaderImageOptionsRecord.fromStructure = function (str) {
return new CustomPopupLayoutHeaderImageOptionsRecord(new CustomPopupLayoutHeaderImageOptionsRecord.RecordClass({
customPopupLayoutHeaderImageOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomPopupLayoutHeaderImageOptionsRecord._isAnonymousRecord = true;
CustomPopupLayoutHeaderImageOptionsRecord.UniqueId = "f1b1471e-aa02-29ab-38f7-7e440e879aff";
CustomPopupLayoutHeaderImageOptionsRecord.init();
return CustomPopupLayoutHeaderImageOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomPopupLayoutHeaderImageOptionsRecord = CustomPopupLayoutHeaderImageOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomPopupLayoutHeaderImageOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomPopupLayoutHeaderImageOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomPopupLayoutHeaderImageOptionsRecordList = (function (_super) {
__extends(CustomPopupLayoutHeaderImageOptionsRecordList, _super);
function CustomPopupLayoutHeaderImageOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomPopupLayoutHeaderImageOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomPopupLayoutHeaderImageOptionsRecord;
return CustomPopupLayoutHeaderImageOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomPopupLayoutHeaderImageOptionsRecordList = CustomPopupLayoutHeaderImageOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CardBackgroundTypeRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CardBackgroundTypeRec = (function (_super) {
__extends(CardBackgroundTypeRec, _super);
function CardBackgroundTypeRec(defaults) {
_super.apply(this, arguments);
}
CardBackgroundTypeRec.attributesToDeclare = function () {
return [
this.attr("Class", "classAttr", "Class", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CardBackgroundTypeRec.fromStructure = function (str) {
return new CardBackgroundTypeRec(new CardBackgroundTypeRec.RecordClass({
classAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CardBackgroundTypeRec.init();
return CardBackgroundTypeRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CardBackgroundTypeRec = CardBackgroundTypeRec;

});
define("ShopperPortalEU_UI_Components.model$CardBackgroundTypeList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CardBackgroundTypeRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CardBackgroundTypeList = (function (_super) {
__extends(CardBackgroundTypeList, _super);
function CardBackgroundTypeList(defaults) {
_super.apply(this, arguments);
}
CardBackgroundTypeList.itemType = ShopperPortalEU_UI_ComponentsModel.CardBackgroundTypeRec;
return CardBackgroundTypeList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CardBackgroundTypeList = CardBackgroundTypeList;

});
define("ShopperPortalEU_UI_Components.model$CustomBottomBarOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomBottomBarOptionsRec = (function (_super) {
__extends(CustomBottomBarOptionsRec, _super);
function CustomBottomBarOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomBottomBarOptionsRec.attributesToDeclare = function () {
return [
this.attr("HasShadow", "hasShadowAttr", "shadow", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomBottomBarOptionsRec.fromStructure = function (str) {
return new CustomBottomBarOptionsRec(new CustomBottomBarOptionsRec.RecordClass({
hasShadowAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomBottomBarOptionsRec.init();
return CustomBottomBarOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomBottomBarOptionsRec = CustomBottomBarOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomBottomBarOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomBottomBarOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomBottomBarOptionsRecord = (function (_super) {
__extends(CustomBottomBarOptionsRecord, _super);
function CustomBottomBarOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomBottomBarOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomBottomBarOptions", "customBottomBarOptionsAttr", "CustomBottomBarOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomBottomBarOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomBottomBarOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomBottomBarOptionsRecord.fromStructure = function (str) {
return new CustomBottomBarOptionsRecord(new CustomBottomBarOptionsRecord.RecordClass({
customBottomBarOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomBottomBarOptionsRecord._isAnonymousRecord = true;
CustomBottomBarOptionsRecord.UniqueId = "db20f11b-7f12-4650-0d55-53aa294e1829";
CustomBottomBarOptionsRecord.init();
return CustomBottomBarOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomBottomBarOptionsRecord = CustomBottomBarOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomBottomBarOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomBottomBarOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomBottomBarOptionsRecordList = (function (_super) {
__extends(CustomBottomBarOptionsRecordList, _super);
function CustomBottomBarOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomBottomBarOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomBottomBarOptionsRecord;
return CustomBottomBarOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomBottomBarOptionsRecordList = CustomBottomBarOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomLinkTypeList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomLinkTypeRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomLinkTypeList = (function (_super) {
__extends(CustomLinkTypeList, _super);
function CustomLinkTypeList(defaults) {
_super.apply(this, arguments);
}
CustomLinkTypeList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomLinkTypeRec;
return CustomLinkTypeList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomLinkTypeList = CustomLinkTypeList;

});
define("ShopperPortalEU_UI_Components.model$TextEllipsisOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$TextEllipsisOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var TextEllipsisOptionsRecordList = (function (_super) {
__extends(TextEllipsisOptionsRecordList, _super);
function TextEllipsisOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
TextEllipsisOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.TextEllipsisOptionsRecord;
return TextEllipsisOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.TextEllipsisOptionsRecordList = TextEllipsisOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomSeparatorOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomSeparatorOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomSeparatorOptionsRecord = (function (_super) {
__extends(CustomSeparatorOptionsRecord, _super);
function CustomSeparatorOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomSeparatorOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomSeparatorOptions", "customSeparatorOptionsAttr", "CustomSeparatorOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomSeparatorOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomSeparatorOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomSeparatorOptionsRecord.fromStructure = function (str) {
return new CustomSeparatorOptionsRecord(new CustomSeparatorOptionsRecord.RecordClass({
customSeparatorOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomSeparatorOptionsRecord._isAnonymousRecord = true;
CustomSeparatorOptionsRecord.UniqueId = "92368d99-861b-4d23-9c43-bb6e81b82ed8";
CustomSeparatorOptionsRecord.init();
return CustomSeparatorOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomSeparatorOptionsRecord = CustomSeparatorOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomSeparatorOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomSeparatorOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomSeparatorOptionsRecordList = (function (_super) {
__extends(CustomSeparatorOptionsRecordList, _super);
function CustomSeparatorOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomSeparatorOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomSeparatorOptionsRecord;
return CustomSeparatorOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomSeparatorOptionsRecordList = CustomSeparatorOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$ButtonOptionStateList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$ButtonOptionStateRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var ButtonOptionStateList = (function (_super) {
__extends(ButtonOptionStateList, _super);
function ButtonOptionStateList(defaults) {
_super.apply(this, arguments);
}
ButtonOptionStateList.itemType = ShopperPortalEU_UI_ComponentsModel.ButtonOptionStateRec;
return ButtonOptionStateList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.ButtonOptionStateList = ButtonOptionStateList;

});
define("ShopperPortalEU_UI_Components.model$CustomRadioGroupStateRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomRadioGroupStateRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomRadioGroupStateRecord = (function (_super) {
__extends(CustomRadioGroupStateRecord, _super);
function CustomRadioGroupStateRecord(defaults) {
_super.apply(this, arguments);
}
CustomRadioGroupStateRecord.attributesToDeclare = function () {
return [
this.attr("CustomRadioGroupState", "customRadioGroupStateAttr", "CustomRadioGroupState", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomRadioGroupStateRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomRadioGroupStateRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomRadioGroupStateRecord.fromStructure = function (str) {
return new CustomRadioGroupStateRecord(new CustomRadioGroupStateRecord.RecordClass({
customRadioGroupStateAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomRadioGroupStateRecord._isAnonymousRecord = true;
CustomRadioGroupStateRecord.UniqueId = "6835f9d3-22ce-cbd9-4d92-6452956cb3c1";
CustomRadioGroupStateRecord.init();
return CustomRadioGroupStateRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomRadioGroupStateRecord = CustomRadioGroupStateRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomRadioGroupStateRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomRadioGroupStateRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomRadioGroupStateRecordList = (function (_super) {
__extends(CustomRadioGroupStateRecordList, _super);
function CustomRadioGroupStateRecordList(defaults) {
_super.apply(this, arguments);
}
CustomRadioGroupStateRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomRadioGroupStateRecord;
return CustomRadioGroupStateRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomRadioGroupStateRecordList = CustomRadioGroupStateRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownCustomValueOptionRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownCustomValueOptionRec = (function (_super) {
__extends(CustomDropdownCustomValueOptionRec, _super);
function CustomDropdownCustomValueOptionRec(defaults) {
_super.apply(this, arguments);
}
CustomDropdownCustomValueOptionRec.attributesToDeclare = function () {
return [
this.attr("Text", "textAttr", "text", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Value", "valueAttr", "value", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomDropdownCustomValueOptionRec.init();
return CustomDropdownCustomValueOptionRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownCustomValueOptionRec = CustomDropdownCustomValueOptionRec;

});
define("ShopperPortalEU_UI_Components.model$CustomPopupLayoutOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomPopupLayoutHeaderImageOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomPopupLayoutOptionsRec = (function (_super) {
__extends(CustomPopupLayoutOptionsRec, _super);
function CustomPopupLayoutOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomPopupLayoutOptionsRec.attributesToDeclare = function () {
return [
this.attr("ShowClose", "showCloseAttr", "close", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("HeaderImage", "headerImageAttr", "headerImage", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomPopupLayoutHeaderImageOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomPopupLayoutHeaderImageOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomPopupLayoutOptionsRec.init();
return CustomPopupLayoutOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomPopupLayoutOptionsRec = CustomPopupLayoutOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomPopupLayoutOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomPopupLayoutOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomPopupLayoutOptionsRecord = (function (_super) {
__extends(CustomPopupLayoutOptionsRecord, _super);
function CustomPopupLayoutOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomPopupLayoutOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomPopupLayoutOptions", "customPopupLayoutOptionsAttr", "CustomPopupLayoutOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomPopupLayoutOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomPopupLayoutOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomPopupLayoutOptionsRecord.fromStructure = function (str) {
return new CustomPopupLayoutOptionsRecord(new CustomPopupLayoutOptionsRecord.RecordClass({
customPopupLayoutOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomPopupLayoutOptionsRecord._isAnonymousRecord = true;
CustomPopupLayoutOptionsRecord.UniqueId = "67980467-8b15-58ee-c638-94ef3d3b33d5";
CustomPopupLayoutOptionsRecord.init();
return CustomPopupLayoutOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomPopupLayoutOptionsRecord = CustomPopupLayoutOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$FullHeightContentTopOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$FullHeightContentTopOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var FullHeightContentTopOptionsRecord = (function (_super) {
__extends(FullHeightContentTopOptionsRecord, _super);
function FullHeightContentTopOptionsRecord(defaults) {
_super.apply(this, arguments);
}
FullHeightContentTopOptionsRecord.attributesToDeclare = function () {
return [
this.attr("FullHeightContentTopOptions", "fullHeightContentTopOptionsAttr", "FullHeightContentTopOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.FullHeightContentTopOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.FullHeightContentTopOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
FullHeightContentTopOptionsRecord.fromStructure = function (str) {
return new FullHeightContentTopOptionsRecord(new FullHeightContentTopOptionsRecord.RecordClass({
fullHeightContentTopOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
FullHeightContentTopOptionsRecord._isAnonymousRecord = true;
FullHeightContentTopOptionsRecord.UniqueId = "67e79585-48db-9c33-2800-1d2d0ac3e9b6";
FullHeightContentTopOptionsRecord.init();
return FullHeightContentTopOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.FullHeightContentTopOptionsRecord = FullHeightContentTopOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$FlexItemOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$FlexItemOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var FlexItemOptionsList = (function (_super) {
__extends(FlexItemOptionsList, _super);
function FlexItemOptionsList(defaults) {
_super.apply(this, arguments);
}
FlexItemOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.FlexItemOptionsRec;
return FlexItemOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.FlexItemOptionsList = FlexItemOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownListSelectedItemOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomDropdownListSelectedItemOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownListSelectedItemOptionsList = (function (_super) {
__extends(CustomDropdownListSelectedItemOptionsList, _super);
function CustomDropdownListSelectedItemOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownListSelectedItemOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomDropdownListSelectedItemOptionsRec;
return CustomDropdownListSelectedItemOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownListSelectedItemOptionsList = CustomDropdownListSelectedItemOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomButtonOptionsIconList = (function (_super) {
__extends(CustomButtonOptionsIconList, _super);
function CustomButtonOptionsIconList(defaults) {
_super.apply(this, arguments);
}
CustomButtonOptionsIconList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsIconRec;
return CustomButtonOptionsIconList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsIconList = CustomButtonOptionsIconList;

});
define("ShopperPortalEU_UI_Components.model$CustomTagStateRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomTagStateRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomTagStateRecordList = (function (_super) {
__extends(CustomTagStateRecordList, _super);
function CustomTagStateRecordList(defaults) {
_super.apply(this, arguments);
}
CustomTagStateRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomTagStateRecord;
return CustomTagStateRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomTagStateRecordList = CustomTagStateRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomCardStateRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomCardStateRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomCardStateRecord = (function (_super) {
__extends(CustomCardStateRecord, _super);
function CustomCardStateRecord(defaults) {
_super.apply(this, arguments);
}
CustomCardStateRecord.attributesToDeclare = function () {
return [
this.attr("CustomCardState", "customCardStateAttr", "CustomCardState", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomCardStateRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomCardStateRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomCardStateRecord.fromStructure = function (str) {
return new CustomCardStateRecord(new CustomCardStateRecord.RecordClass({
customCardStateAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomCardStateRecord._isAnonymousRecord = true;
CustomCardStateRecord.UniqueId = "738e8e4d-5c00-5798-690f-86c52ce82f88";
CustomCardStateRecord.init();
return CustomCardStateRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomCardStateRecord = CustomCardStateRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomCardStateRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomCardStateRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomCardStateRecordList = (function (_super) {
__extends(CustomCardStateRecordList, _super);
function CustomCardStateRecordList(defaults) {
_super.apply(this, arguments);
}
CustomCardStateRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomCardStateRecord;
return CustomCardStateRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomCardStateRecordList = CustomCardStateRecordList;

});
define("ShopperPortalEU_UI_Components.model$CardStateTypeRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CardStateTypeRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CardStateTypeRecord = (function (_super) {
__extends(CardStateTypeRecord, _super);
function CardStateTypeRecord(defaults) {
_super.apply(this, arguments);
}
CardStateTypeRecord.attributesToDeclare = function () {
return [
this.attr("CardStateType", "cardStateTypeAttr", "CardStateType", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CardStateTypeRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CardStateTypeRec)
].concat(_super.attributesToDeclare.call(this));
};
CardStateTypeRecord.fromStructure = function (str) {
return new CardStateTypeRecord(new CardStateTypeRecord.RecordClass({
cardStateTypeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CardStateTypeRecord._isAnonymousRecord = true;
CardStateTypeRecord.UniqueId = "b7d7feb7-5b30-ca61-c992-48b012ab0684";
CardStateTypeRecord.init();
return CardStateTypeRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CardStateTypeRecord = CardStateTypeRecord;

});
define("ShopperPortalEU_UI_Components.model$CardStateTypeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CardStateTypeRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CardStateTypeRecordList = (function (_super) {
__extends(CardStateTypeRecordList, _super);
function CardStateTypeRecordList(defaults) {
_super.apply(this, arguments);
}
CardStateTypeRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CardStateTypeRecord;
return CardStateTypeRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CardStateTypeRecordList = CardStateTypeRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomSeparatorStateRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomSeparatorStateRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomSeparatorStateRecord = (function (_super) {
__extends(CustomSeparatorStateRecord, _super);
function CustomSeparatorStateRecord(defaults) {
_super.apply(this, arguments);
}
CustomSeparatorStateRecord.attributesToDeclare = function () {
return [
this.attr("CustomSeparatorState", "customSeparatorStateAttr", "CustomSeparatorState", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomSeparatorStateRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomSeparatorStateRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomSeparatorStateRecord.fromStructure = function (str) {
return new CustomSeparatorStateRecord(new CustomSeparatorStateRecord.RecordClass({
customSeparatorStateAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomSeparatorStateRecord._isAnonymousRecord = true;
CustomSeparatorStateRecord.UniqueId = "6ae9036b-dacb-bc2f-5a59-8da4a3cd1222";
CustomSeparatorStateRecord.init();
return CustomSeparatorStateRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomSeparatorStateRecord = CustomSeparatorStateRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomWizardItemOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomWizardItemOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomWizardItemOptionsList = (function (_super) {
__extends(CustomWizardItemOptionsList, _super);
function CustomWizardItemOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomWizardItemOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomWizardItemOptionsRec;
return CustomWizardItemOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomWizardItemOptionsList = CustomWizardItemOptionsList;

});
define("ShopperPortalEU_UI_Components.model$JustifyRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$JustifyRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var JustifyRecord = (function (_super) {
__extends(JustifyRecord, _super);
function JustifyRecord(defaults) {
_super.apply(this, arguments);
}
JustifyRecord.attributesToDeclare = function () {
return [
this.attr("Justify", "justifyAttr", "Justify", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.JustifyRec());
}, true, ShopperPortalEU_UI_ComponentsModel.JustifyRec)
].concat(_super.attributesToDeclare.call(this));
};
JustifyRecord.fromStructure = function (str) {
return new JustifyRecord(new JustifyRecord.RecordClass({
justifyAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
JustifyRecord._isAnonymousRecord = true;
JustifyRecord.UniqueId = "6b90c8b6-6cd5-9e52-610d-399ec523877a";
JustifyRecord.init();
return JustifyRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.JustifyRecord = JustifyRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomImageOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomImageOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomImageOptionsRecord = (function (_super) {
__extends(CustomImageOptionsRecord, _super);
function CustomImageOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomImageOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomImageOptions", "customImageOptionsAttr", "CustomImageOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomImageOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomImageOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomImageOptionsRecord.fromStructure = function (str) {
return new CustomImageOptionsRecord(new CustomImageOptionsRecord.RecordClass({
customImageOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomImageOptionsRecord._isAnonymousRecord = true;
CustomImageOptionsRecord.UniqueId = "6d62359a-099d-f43a-257f-8bd5e345c82b";
CustomImageOptionsRecord.init();
return CustomImageOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomImageOptionsRecord = CustomImageOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$ScanBarcodeErrorRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$ScanBarcodeErrorRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var ScanBarcodeErrorRecord = (function (_super) {
__extends(ScanBarcodeErrorRecord, _super);
function ScanBarcodeErrorRecord(defaults) {
_super.apply(this, arguments);
}
ScanBarcodeErrorRecord.attributesToDeclare = function () {
return [
this.attr("ScanBarcodeError", "scanBarcodeErrorAttr", "ScanBarcodeError", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.ScanBarcodeErrorRec());
}, true, ShopperPortalEU_UI_ComponentsModel.ScanBarcodeErrorRec)
].concat(_super.attributesToDeclare.call(this));
};
ScanBarcodeErrorRecord.fromStructure = function (str) {
return new ScanBarcodeErrorRecord(new ScanBarcodeErrorRecord.RecordClass({
scanBarcodeErrorAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ScanBarcodeErrorRecord._isAnonymousRecord = true;
ScanBarcodeErrorRecord.UniqueId = "83b7b38b-de8c-7fe9-1d2e-2a90d4f634d8";
ScanBarcodeErrorRecord.init();
return ScanBarcodeErrorRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.ScanBarcodeErrorRecord = ScanBarcodeErrorRecord;

});
define("ShopperPortalEU_UI_Components.model$ScanBarcodeErrorRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$ScanBarcodeErrorRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var ScanBarcodeErrorRecordList = (function (_super) {
__extends(ScanBarcodeErrorRecordList, _super);
function ScanBarcodeErrorRecordList(defaults) {
_super.apply(this, arguments);
}
ScanBarcodeErrorRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.ScanBarcodeErrorRecord;
return ScanBarcodeErrorRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.ScanBarcodeErrorRecordList = ScanBarcodeErrorRecordList;

});
define("ShopperPortalEU_UI_Components.model$JustifyRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$JustifyRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var JustifyRecordList = (function (_super) {
__extends(JustifyRecordList, _super);
function JustifyRecordList(defaults) {
_super.apply(this, arguments);
}
JustifyRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.JustifyRecord;
return JustifyRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.JustifyRecordList = JustifyRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomValidationMessageStateRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomValidationMessageStateRec = (function (_super) {
__extends(CustomValidationMessageStateRec, _super);
function CustomValidationMessageStateRec(defaults) {
_super.apply(this, arguments);
}
CustomValidationMessageStateRec.attributesToDeclare = function () {
return [
this.attr("Class", "classAttr", "Class", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomValidationMessageStateRec.fromStructure = function (str) {
return new CustomValidationMessageStateRec(new CustomValidationMessageStateRec.RecordClass({
classAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomValidationMessageStateRec.init();
return CustomValidationMessageStateRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomValidationMessageStateRec = CustomValidationMessageStateRec;

});
define("ShopperPortalEU_UI_Components.model$CustomValidationMessageStateRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomValidationMessageStateRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomValidationMessageStateRecord = (function (_super) {
__extends(CustomValidationMessageStateRecord, _super);
function CustomValidationMessageStateRecord(defaults) {
_super.apply(this, arguments);
}
CustomValidationMessageStateRecord.attributesToDeclare = function () {
return [
this.attr("CustomValidationMessageState", "customValidationMessageStateAttr", "CustomValidationMessageState", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomValidationMessageStateRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomValidationMessageStateRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomValidationMessageStateRecord.fromStructure = function (str) {
return new CustomValidationMessageStateRecord(new CustomValidationMessageStateRecord.RecordClass({
customValidationMessageStateAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomValidationMessageStateRecord._isAnonymousRecord = true;
CustomValidationMessageStateRecord.UniqueId = "8bd44d05-41d5-a18f-9058-8e1bdbf0b716";
CustomValidationMessageStateRecord.init();
return CustomValidationMessageStateRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomValidationMessageStateRecord = CustomValidationMessageStateRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomValidationMessageStateRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomValidationMessageStateRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomValidationMessageStateRecordList = (function (_super) {
__extends(CustomValidationMessageStateRecordList, _super);
function CustomValidationMessageStateRecordList(defaults) {
_super.apply(this, arguments);
}
CustomValidationMessageStateRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomValidationMessageStateRecord;
return CustomValidationMessageStateRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomValidationMessageStateRecordList = CustomValidationMessageStateRecordList;

});
define("ShopperPortalEU_UI_Components.model$FlexAlignRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$FlexAlignRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var FlexAlignRecord = (function (_super) {
__extends(FlexAlignRecord, _super);
function FlexAlignRecord(defaults) {
_super.apply(this, arguments);
}
FlexAlignRecord.attributesToDeclare = function () {
return [
this.attr("FlexAlign", "flexAlignAttr", "FlexAlign", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.FlexAlignRec());
}, true, ShopperPortalEU_UI_ComponentsModel.FlexAlignRec)
].concat(_super.attributesToDeclare.call(this));
};
FlexAlignRecord.fromStructure = function (str) {
return new FlexAlignRecord(new FlexAlignRecord.RecordClass({
flexAlignAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
FlexAlignRecord._isAnonymousRecord = true;
FlexAlignRecord.UniqueId = "70505c3e-d9c1-09e1-7b33-d412e5e6f0b5";
FlexAlignRecord.init();
return FlexAlignRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.FlexAlignRecord = FlexAlignRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomTableOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomTableOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomTableOptionsRecord = (function (_super) {
__extends(CustomTableOptionsRecord, _super);
function CustomTableOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomTableOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomTableOptions", "customTableOptionsAttr", "CustomTableOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomTableOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomTableOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomTableOptionsRecord.fromStructure = function (str) {
return new CustomTableOptionsRecord(new CustomTableOptionsRecord.RecordClass({
customTableOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomTableOptionsRecord._isAnonymousRecord = true;
CustomTableOptionsRecord.UniqueId = "d30dca86-417f-8839-9da3-bbff6e41bbcb";
CustomTableOptionsRecord.init();
return CustomTableOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomTableOptionsRecord = CustomTableOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomTableOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomTableOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomTableOptionsRecordList = (function (_super) {
__extends(CustomTableOptionsRecordList, _super);
function CustomTableOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomTableOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomTableOptionsRecord;
return CustomTableOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomTableOptionsRecordList = CustomTableOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomTablePaginationOptionList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomTablePaginationOptionRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomTablePaginationOptionList = (function (_super) {
__extends(CustomTablePaginationOptionList, _super);
function CustomTablePaginationOptionList(defaults) {
_super.apply(this, arguments);
}
CustomTablePaginationOptionList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomTablePaginationOptionRec;
return CustomTablePaginationOptionList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomTablePaginationOptionList = CustomTablePaginationOptionList;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownCustomValueOptionList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomDropdownCustomValueOptionRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownCustomValueOptionList = (function (_super) {
__extends(CustomDropdownCustomValueOptionList, _super);
function CustomDropdownCustomValueOptionList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownCustomValueOptionList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomDropdownCustomValueOptionRec;
return CustomDropdownCustomValueOptionList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownCustomValueOptionList = CustomDropdownCustomValueOptionList;

});
define("ShopperPortalEU_UI_Components.model$CodeInputOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CodeInputOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CodeInputOptionsList = (function (_super) {
__extends(CodeInputOptionsList, _super);
function CodeInputOptionsList(defaults) {
_super.apply(this, arguments);
}
CodeInputOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CodeInputOptionsRec;
return CodeInputOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CodeInputOptionsList = CodeInputOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CreditCardOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CreditCardSwipeOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CreditCardOptionsRec = (function (_super) {
__extends(CreditCardOptionsRec, _super);
function CreditCardOptionsRec(defaults) {
_super.apply(this, arguments);
}
CreditCardOptionsRec.attributesToDeclare = function () {
return [
this.attr("TestId", "testIdAttr", "testId", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Type", "typeAttr", "type", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("IsEmpty", "isEmptyAttr", "empty", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("Swipe", "swipeAttr", "swipe", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CreditCardSwipeOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CreditCardSwipeOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CreditCardOptionsRec.init();
return CreditCardOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CreditCardOptionsRec = CreditCardOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CreditCardOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CreditCardOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CreditCardOptionsRecord = (function (_super) {
__extends(CreditCardOptionsRecord, _super);
function CreditCardOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CreditCardOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CreditCardOptions", "creditCardOptionsAttr", "CreditCardOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CreditCardOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CreditCardOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CreditCardOptionsRecord.fromStructure = function (str) {
return new CreditCardOptionsRecord(new CreditCardOptionsRecord.RecordClass({
creditCardOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CreditCardOptionsRecord._isAnonymousRecord = true;
CreditCardOptionsRecord.UniqueId = "dec11bd0-7c39-4566-0d16-6deb70cb0d7e";
CreditCardOptionsRecord.init();
return CreditCardOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CreditCardOptionsRecord = CreditCardOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CreditCardOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CreditCardOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CreditCardOptionsRecordList = (function (_super) {
__extends(CreditCardOptionsRecordList, _super);
function CreditCardOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CreditCardOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CreditCardOptionsRecord;
return CreditCardOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CreditCardOptionsRecordList = CreditCardOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomRadioGroupOrientationRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomRadioGroupOrientationRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomRadioGroupOrientationRecord = (function (_super) {
__extends(CustomRadioGroupOrientationRecord, _super);
function CustomRadioGroupOrientationRecord(defaults) {
_super.apply(this, arguments);
}
CustomRadioGroupOrientationRecord.attributesToDeclare = function () {
return [
this.attr("CustomRadioGroupOrientation", "customRadioGroupOrientationAttr", "CustomRadioGroupOrientation", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomRadioGroupOrientationRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomRadioGroupOrientationRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomRadioGroupOrientationRecord.fromStructure = function (str) {
return new CustomRadioGroupOrientationRecord(new CustomRadioGroupOrientationRecord.RecordClass({
customRadioGroupOrientationAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomRadioGroupOrientationRecord._isAnonymousRecord = true;
CustomRadioGroupOrientationRecord.UniqueId = "e6c6ddb8-9643-f218-a2d8-f1c0f894fdfe";
CustomRadioGroupOrientationRecord.init();
return CustomRadioGroupOrientationRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomRadioGroupOrientationRecord = CustomRadioGroupOrientationRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomRadioGroupOrientationRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomRadioGroupOrientationRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomRadioGroupOrientationRecordList = (function (_super) {
__extends(CustomRadioGroupOrientationRecordList, _super);
function CustomRadioGroupOrientationRecordList(defaults) {
_super.apply(this, arguments);
}
CustomRadioGroupOrientationRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomRadioGroupOrientationRecord;
return CustomRadioGroupOrientationRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomRadioGroupOrientationRecordList = CustomRadioGroupOrientationRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomSVGOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomSVGOptionsRec = (function (_super) {
__extends(CustomSVGOptionsRec, _super);
function CustomSVGOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomSVGOptionsRec.attributesToDeclare = function () {
return [
this.attr("SVG", "sVGAttr", "svg", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("IsFullWidth", "isFullWidthAttr", "fullWidth", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("Width", "widthAttr", "width", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("IsFullHeight", "isFullHeightAttr", "fullHeight", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("Height", "heightAttr", "height", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomSVGOptionsRec.init();
return CustomSVGOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomSVGOptionsRec = CustomSVGOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomTableEmptyOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomTableEmptyOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomTableEmptyOptionsList = (function (_super) {
__extends(CustomTableEmptyOptionsList, _super);
function CustomTableEmptyOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomTableEmptyOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomTableEmptyOptionsRec;
return CustomTableEmptyOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomTableEmptyOptionsList = CustomTableEmptyOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomInputIconOptionList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomInputIconOptionRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomInputIconOptionList = (function (_super) {
__extends(CustomInputIconOptionList, _super);
function CustomInputIconOptionList(defaults) {
_super.apply(this, arguments);
}
CustomInputIconOptionList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomInputIconOptionRec;
return CustomInputIconOptionList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomInputIconOptionList = CustomInputIconOptionList;

});
define("ShopperPortalEU_UI_Components.model$ScanPassportPropertiesRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$ScanPassportPropertiesRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var ScanPassportPropertiesRecord = (function (_super) {
__extends(ScanPassportPropertiesRecord, _super);
function ScanPassportPropertiesRecord(defaults) {
_super.apply(this, arguments);
}
ScanPassportPropertiesRecord.attributesToDeclare = function () {
return [
this.attr("ScanPassportProperties", "scanPassportPropertiesAttr", "ScanPassportProperties", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.ScanPassportPropertiesRec());
}, true, ShopperPortalEU_UI_ComponentsModel.ScanPassportPropertiesRec)
].concat(_super.attributesToDeclare.call(this));
};
ScanPassportPropertiesRecord.fromStructure = function (str) {
return new ScanPassportPropertiesRecord(new ScanPassportPropertiesRecord.RecordClass({
scanPassportPropertiesAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ScanPassportPropertiesRecord._isAnonymousRecord = true;
ScanPassportPropertiesRecord.UniqueId = "fd22d6f7-3634-06aa-5cd0-06d5939eb65f";
ScanPassportPropertiesRecord.init();
return ScanPassportPropertiesRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.ScanPassportPropertiesRecord = ScanPassportPropertiesRecord;

});
define("ShopperPortalEU_UI_Components.model$ScanPassportPropertiesRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$ScanPassportPropertiesRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var ScanPassportPropertiesRecordList = (function (_super) {
__extends(ScanPassportPropertiesRecordList, _super);
function ScanPassportPropertiesRecordList(defaults) {
_super.apply(this, arguments);
}
ScanPassportPropertiesRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.ScanPassportPropertiesRecord;
return ScanPassportPropertiesRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.ScanPassportPropertiesRecordList = ScanPassportPropertiesRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomColumnsItemOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomColumnsItemOptionsRec = (function (_super) {
__extends(CustomColumnsItemOptionsRec, _super);
function CustomColumnsItemOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomColumnsItemOptionsRec.attributesToDeclare = function () {
return [
this.attr("Span", "spanAttr", "span", false, false, OS.DataTypes.DataTypes.Integer, function () {
return 1;
}, true), 
this.attr("Align", "alignAttr", "align", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Justify", "justifyAttr", "justify", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomColumnsItemOptionsRec.init();
return CustomColumnsItemOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomColumnsItemOptionsRec = CustomColumnsItemOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomColumnsItemOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomColumnsItemOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomColumnsItemOptionsRecord = (function (_super) {
__extends(CustomColumnsItemOptionsRecord, _super);
function CustomColumnsItemOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomColumnsItemOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomColumnsItemOptions", "customColumnsItemOptionsAttr", "CustomColumnsItemOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomColumnsItemOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomColumnsItemOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomColumnsItemOptionsRecord.fromStructure = function (str) {
return new CustomColumnsItemOptionsRecord(new CustomColumnsItemOptionsRecord.RecordClass({
customColumnsItemOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomColumnsItemOptionsRecord._isAnonymousRecord = true;
CustomColumnsItemOptionsRecord.UniqueId = "773960df-fa9c-834e-ef84-9693c03790ef";
CustomColumnsItemOptionsRecord.init();
return CustomColumnsItemOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomColumnsItemOptionsRecord = CustomColumnsItemOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$FullHeightContentBottomOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$FullHeightContentBottomOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var FullHeightContentBottomOptionsRecord = (function (_super) {
__extends(FullHeightContentBottomOptionsRecord, _super);
function FullHeightContentBottomOptionsRecord(defaults) {
_super.apply(this, arguments);
}
FullHeightContentBottomOptionsRecord.attributesToDeclare = function () {
return [
this.attr("FullHeightContentBottomOptions", "fullHeightContentBottomOptionsAttr", "FullHeightContentBottomOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.FullHeightContentBottomOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.FullHeightContentBottomOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
FullHeightContentBottomOptionsRecord.fromStructure = function (str) {
return new FullHeightContentBottomOptionsRecord(new FullHeightContentBottomOptionsRecord.RecordClass({
fullHeightContentBottomOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
FullHeightContentBottomOptionsRecord._isAnonymousRecord = true;
FullHeightContentBottomOptionsRecord.UniqueId = "77821e6d-1b60-9ae0-404e-eb923da4a3d4";
FullHeightContentBottomOptionsRecord.init();
return FullHeightContentBottomOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.FullHeightContentBottomOptionsRecord = FullHeightContentBottomOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomTagStateList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomTagStateRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomTagStateList = (function (_super) {
__extends(CustomTagStateList, _super);
function CustomTagStateList(defaults) {
_super.apply(this, arguments);
}
CustomTagStateList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomTagStateRec;
return CustomTagStateList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomTagStateList = CustomTagStateList;

});
define("ShopperPortalEU_UI_Components.model$DatePickerLabelOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$DatePickerLabelOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var DatePickerLabelOptionsRecordList = (function (_super) {
__extends(DatePickerLabelOptionsRecordList, _super);
function DatePickerLabelOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
DatePickerLabelOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.DatePickerLabelOptionsRecord;
return DatePickerLabelOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.DatePickerLabelOptionsRecordList = DatePickerLabelOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$FullHeightContentOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$FullHeightContentOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var FullHeightContentOptionsRecordList = (function (_super) {
__extends(FullHeightContentOptionsRecordList, _super);
function FullHeightContentOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
FullHeightContentOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.FullHeightContentOptionsRecord;
return FullHeightContentOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.FullHeightContentOptionsRecordList = FullHeightContentOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$AvatarOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var AvatarOptionsRec = (function (_super) {
__extends(AvatarOptionsRec, _super);
function AvatarOptionsRec(defaults) {
_super.apply(this, arguments);
}
AvatarOptionsRec.attributesToDeclare = function () {
return [
this.attr("TestId", "testIdAttr", "testId", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Name", "nameAttr", "name", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
AvatarOptionsRec.init();
return AvatarOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.AvatarOptionsRec = AvatarOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$AvatarOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$AvatarOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var AvatarOptionsList = (function (_super) {
__extends(AvatarOptionsList, _super);
function AvatarOptionsList(defaults) {
_super.apply(this, arguments);
}
AvatarOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.AvatarOptionsRec;
return AvatarOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.AvatarOptionsList = AvatarOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CircleIconOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CircleIconIconOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CircleIconOptionsRec = (function (_super) {
__extends(CircleIconOptionsRec, _super);
function CircleIconOptionsRec(defaults) {
_super.apply(this, arguments);
}
CircleIconOptionsRec.attributesToDeclare = function () {
return [
this.attr("TestId", "testIdAttr", "testId", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("BackgroundColor", "backgroundColorAttr", "background", false, false, OS.DataTypes.DataTypes.Text, function () {
return "var(--color-accent-80)";
}, true), 
this.attr("Icon", "iconAttr", "icon", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CircleIconIconOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CircleIconIconOptionsRec), 
this.attr("Size", "sizeAttr", "size", false, false, OS.DataTypes.DataTypes.Text, function () {
return ShopperPortalEU_UI_ComponentsModel.staticEntities.circleIconSize.default;
}, true), 
this.attr("SoftRadius", "softRadiusAttr", "softRadius", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CircleIconOptionsRec.init();
return CircleIconOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CircleIconOptionsRec = CircleIconOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CircleIconOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CircleIconOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CircleIconOptionsRecord = (function (_super) {
__extends(CircleIconOptionsRecord, _super);
function CircleIconOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CircleIconOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CircleIconOptions", "circleIconOptionsAttr", "CircleIconOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CircleIconOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CircleIconOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CircleIconOptionsRecord.fromStructure = function (str) {
return new CircleIconOptionsRecord(new CircleIconOptionsRecord.RecordClass({
circleIconOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CircleIconOptionsRecord._isAnonymousRecord = true;
CircleIconOptionsRecord.UniqueId = "d8c7b417-6e5c-8842-0b05-c912029a778b";
CircleIconOptionsRecord.init();
return CircleIconOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CircleIconOptionsRecord = CircleIconOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CircleIconOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CircleIconOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CircleIconOptionsRecordList = (function (_super) {
__extends(CircleIconOptionsRecordList, _super);
function CircleIconOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CircleIconOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CircleIconOptionsRecord;
return CircleIconOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CircleIconOptionsRecordList = CircleIconOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$FullHeightContentTopOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$FullHeightContentTopOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var FullHeightContentTopOptionsRecordList = (function (_super) {
__extends(FullHeightContentTopOptionsRecordList, _super);
function FullHeightContentTopOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
FullHeightContentTopOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.FullHeightContentTopOptionsRecord;
return FullHeightContentTopOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.FullHeightContentTopOptionsRecordList = FullHeightContentTopOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$DatatransCardOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$DatatransCardOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var DatatransCardOptionsList = (function (_super) {
__extends(DatatransCardOptionsList, _super);
function DatatransCardOptionsList(defaults) {
_super.apply(this, arguments);
}
DatatransCardOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.DatatransCardOptionsRec;
return DatatransCardOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.DatatransCardOptionsList = DatatransCardOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomUploadFileOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomUploadFileOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomUploadFileOptionsRecord = (function (_super) {
__extends(CustomUploadFileOptionsRecord, _super);
function CustomUploadFileOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomUploadFileOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomUploadFileOptions", "customUploadFileOptionsAttr", "CustomUploadFileOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomUploadFileOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomUploadFileOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomUploadFileOptionsRecord.fromStructure = function (str) {
return new CustomUploadFileOptionsRecord(new CustomUploadFileOptionsRecord.RecordClass({
customUploadFileOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomUploadFileOptionsRecord._isAnonymousRecord = true;
CustomUploadFileOptionsRecord.UniqueId = "da68a77e-44b1-009f-7f45-cabbe01d77b8";
CustomUploadFileOptionsRecord.init();
return CustomUploadFileOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomUploadFileOptionsRecord = CustomUploadFileOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomUploadFileOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomUploadFileOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomUploadFileOptionsRecordList = (function (_super) {
__extends(CustomUploadFileOptionsRecordList, _super);
function CustomUploadFileOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomUploadFileOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomUploadFileOptionsRecord;
return CustomUploadFileOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomUploadFileOptionsRecordList = CustomUploadFileOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomSwitchOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomSwitchOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomSwitchOptionsRecord = (function (_super) {
__extends(CustomSwitchOptionsRecord, _super);
function CustomSwitchOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomSwitchOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomSwitchOptions", "customSwitchOptionsAttr", "CustomSwitchOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomSwitchOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomSwitchOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomSwitchOptionsRecord.fromStructure = function (str) {
return new CustomSwitchOptionsRecord(new CustomSwitchOptionsRecord.RecordClass({
customSwitchOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomSwitchOptionsRecord._isAnonymousRecord = true;
CustomSwitchOptionsRecord.UniqueId = "7ba8714f-d841-5fdb-db21-e03825219d77";
CustomSwitchOptionsRecord.init();
return CustomSwitchOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomSwitchOptionsRecord = CustomSwitchOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CardBackgroundTypeRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CardBackgroundTypeRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CardBackgroundTypeRecord = (function (_super) {
__extends(CardBackgroundTypeRecord, _super);
function CardBackgroundTypeRecord(defaults) {
_super.apply(this, arguments);
}
CardBackgroundTypeRecord.attributesToDeclare = function () {
return [
this.attr("CardBackgroundType", "cardBackgroundTypeAttr", "CardBackgroundType", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CardBackgroundTypeRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CardBackgroundTypeRec)
].concat(_super.attributesToDeclare.call(this));
};
CardBackgroundTypeRecord.fromStructure = function (str) {
return new CardBackgroundTypeRecord(new CardBackgroundTypeRecord.RecordClass({
cardBackgroundTypeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CardBackgroundTypeRecord._isAnonymousRecord = true;
CardBackgroundTypeRecord.UniqueId = "b8ec40b3-3a7a-19f4-23d7-8f3c0053af42";
CardBackgroundTypeRecord.init();
return CardBackgroundTypeRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CardBackgroundTypeRecord = CardBackgroundTypeRecord;

});
define("ShopperPortalEU_UI_Components.model$CardBackgroundTypeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CardBackgroundTypeRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CardBackgroundTypeRecordList = (function (_super) {
__extends(CardBackgroundTypeRecordList, _super);
function CardBackgroundTypeRecordList(defaults) {
_super.apply(this, arguments);
}
CardBackgroundTypeRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CardBackgroundTypeRecord;
return CardBackgroundTypeRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CardBackgroundTypeRecordList = CardBackgroundTypeRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomFlagOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomFlagOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomFlagOptionsRecord = (function (_super) {
__extends(CustomFlagOptionsRecord, _super);
function CustomFlagOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomFlagOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomFlagOptions", "customFlagOptionsAttr", "CustomFlagOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomFlagOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomFlagOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomFlagOptionsRecord.fromStructure = function (str) {
return new CustomFlagOptionsRecord(new CustomFlagOptionsRecord.RecordClass({
customFlagOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomFlagOptionsRecord._isAnonymousRecord = true;
CustomFlagOptionsRecord.UniqueId = "7cef2456-9b73-7348-8553-e2840b8a1f47";
CustomFlagOptionsRecord.init();
return CustomFlagOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomFlagOptionsRecord = CustomFlagOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomValidationMessageOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomValidationMessageOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomValidationMessageOptionsRecord = (function (_super) {
__extends(CustomValidationMessageOptionsRecord, _super);
function CustomValidationMessageOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomValidationMessageOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomValidationMessageOptions", "customValidationMessageOptionsAttr", "CustomValidationMessageOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomValidationMessageOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomValidationMessageOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomValidationMessageOptionsRecord.fromStructure = function (str) {
return new CustomValidationMessageOptionsRecord(new CustomValidationMessageOptionsRecord.RecordClass({
customValidationMessageOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomValidationMessageOptionsRecord._isAnonymousRecord = true;
CustomValidationMessageOptionsRecord.UniqueId = "9b216a9f-bc34-7ace-5b4d-239f72cda6a6";
CustomValidationMessageOptionsRecord.init();
return CustomValidationMessageOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomValidationMessageOptionsRecord = CustomValidationMessageOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomValidationMessageOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomValidationMessageOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomValidationMessageOptionsRecordList = (function (_super) {
__extends(CustomValidationMessageOptionsRecordList, _super);
function CustomValidationMessageOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomValidationMessageOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomValidationMessageOptionsRecord;
return CustomValidationMessageOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomValidationMessageOptionsRecordList = CustomValidationMessageOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomUploadCameraOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomUploadCameraOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomUploadCameraOptionsRecord = (function (_super) {
__extends(CustomUploadCameraOptionsRecord, _super);
function CustomUploadCameraOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomUploadCameraOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomUploadCameraOptions", "customUploadCameraOptionsAttr", "CustomUploadCameraOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomUploadCameraOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomUploadCameraOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomUploadCameraOptionsRecord.fromStructure = function (str) {
return new CustomUploadCameraOptionsRecord(new CustomUploadCameraOptionsRecord.RecordClass({
customUploadCameraOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomUploadCameraOptionsRecord._isAnonymousRecord = true;
CustomUploadCameraOptionsRecord.UniqueId = "bd713947-151a-33c8-38d9-c8235d60ac1d";
CustomUploadCameraOptionsRecord.init();
return CustomUploadCameraOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomUploadCameraOptionsRecord = CustomUploadCameraOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomUploadCameraOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomUploadCameraOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomUploadCameraOptionsRecordList = (function (_super) {
__extends(CustomUploadCameraOptionsRecordList, _super);
function CustomUploadCameraOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomUploadCameraOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomUploadCameraOptionsRecord;
return CustomUploadCameraOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomUploadCameraOptionsRecordList = CustomUploadCameraOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomColumnsOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomColumnsOptionsRec = (function (_super) {
__extends(CustomColumnsOptionsRec, _super);
function CustomColumnsOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomColumnsOptionsRec.attributesToDeclare = function () {
return [
this.attr("Columns", "columnsAttr", "columns", false, false, OS.DataTypes.DataTypes.Integer, function () {
return 2;
}, true), 
this.attr("Spacing", "spacingAttr", "spacing", false, false, OS.DataTypes.DataTypes.Text, function () {
return ShopperPortalEU_UI_ComponentsModel.staticEntities.spacing.space4;
}, true), 
this.attr("FullHeight", "fullHeightAttr", "fullHeight", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("Justify", "justifyAttr", "justify", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("DisableAutoGridItems", "disableAutoGridItemsAttr", "disableAutoGridItems", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomColumnsOptionsRec.init();
return CustomColumnsOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomColumnsOptionsRec = CustomColumnsOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomColumnsOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomColumnsOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomColumnsOptionsRecord = (function (_super) {
__extends(CustomColumnsOptionsRecord, _super);
function CustomColumnsOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomColumnsOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomColumnsOptions", "customColumnsOptionsAttr", "CustomColumnsOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomColumnsOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomColumnsOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomColumnsOptionsRecord.fromStructure = function (str) {
return new CustomColumnsOptionsRecord(new CustomColumnsOptionsRecord.RecordClass({
customColumnsOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomColumnsOptionsRecord._isAnonymousRecord = true;
CustomColumnsOptionsRecord.UniqueId = "80510748-bfcb-3f63-e1cf-56d102d07849";
CustomColumnsOptionsRecord.init();
return CustomColumnsOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomColumnsOptionsRecord = CustomColumnsOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomTimelineTypeRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomTimelineTypeRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomTimelineTypeRecord = (function (_super) {
__extends(CustomTimelineTypeRecord, _super);
function CustomTimelineTypeRecord(defaults) {
_super.apply(this, arguments);
}
CustomTimelineTypeRecord.attributesToDeclare = function () {
return [
this.attr("CustomTimelineType", "customTimelineTypeAttr", "CustomTimelineType", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomTimelineTypeRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomTimelineTypeRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomTimelineTypeRecord.fromStructure = function (str) {
return new CustomTimelineTypeRecord(new CustomTimelineTypeRecord.RecordClass({
customTimelineTypeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomTimelineTypeRecord._isAnonymousRecord = true;
CustomTimelineTypeRecord.UniqueId = "812b9d97-c951-8dce-3b0c-b27b261b45ee";
CustomTimelineTypeRecord.init();
return CustomTimelineTypeRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomTimelineTypeRecord = CustomTimelineTypeRecord;

});
define("ShopperPortalEU_UI_Components.model$AlignRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var AlignRec = (function (_super) {
__extends(AlignRec, _super);
function AlignRec(defaults) {
_super.apply(this, arguments);
}
AlignRec.attributesToDeclare = function () {
return [
this.attr("Label", "labelAttr", "Label", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
AlignRec.fromStructure = function (str) {
return new AlignRec(new AlignRec.RecordClass({
labelAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
AlignRec.init();
return AlignRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.AlignRec = AlignRec;

});
define("ShopperPortalEU_UI_Components.model$AlignList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$AlignRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var AlignList = (function (_super) {
__extends(AlignList, _super);
function AlignList(defaults) {
_super.apply(this, arguments);
}
AlignList.itemType = ShopperPortalEU_UI_ComponentsModel.AlignRec;
return AlignList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.AlignList = AlignList;

});
define("ShopperPortalEU_UI_Components.model$GetOSBrowserOptionList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$GetOSBrowserOptionRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var GetOSBrowserOptionList = (function (_super) {
__extends(GetOSBrowserOptionList, _super);
function GetOSBrowserOptionList(defaults) {
_super.apply(this, arguments);
}
GetOSBrowserOptionList.itemType = ShopperPortalEU_UI_ComponentsModel.GetOSBrowserOptionRec;
return GetOSBrowserOptionList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.GetOSBrowserOptionList = GetOSBrowserOptionList;

});
define("ShopperPortalEU_UI_Components.model$CardStateOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CardStateOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CardStateOptionsList = (function (_super) {
__extends(CardStateOptionsList, _super);
function CardStateOptionsList(defaults) {
_super.apply(this, arguments);
}
CardStateOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CardStateOptionsRec;
return CardStateOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CardStateOptionsList = CardStateOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomOpacityOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomOpacityOptionsRec = (function (_super) {
__extends(CustomOpacityOptionsRec, _super);
function CustomOpacityOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomOpacityOptionsRec.attributesToDeclare = function () {
return [
this.attr("Value", "valueAttr", "value", false, false, OS.DataTypes.DataTypes.Decimal, function () {
return (new OS.DataTypes.Decimal("0.5"));
}, true), 
this.attr("IsAnimated", "isAnimatedAttr", "animated", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomOpacityOptionsRec.init();
return CustomOpacityOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomOpacityOptionsRec = CustomOpacityOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomButtonGroupOrientationList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomButtonGroupOrientationRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomButtonGroupOrientationList = (function (_super) {
__extends(CustomButtonGroupOrientationList, _super);
function CustomButtonGroupOrientationList(defaults) {
_super.apply(this, arguments);
}
CustomButtonGroupOrientationList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomButtonGroupOrientationRec;
return CustomButtonGroupOrientationList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomButtonGroupOrientationList = CustomButtonGroupOrientationList;

});
define("ShopperPortalEU_UI_Components.model$CardExpandableOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CardExpandableOptionsRec = (function (_super) {
__extends(CardExpandableOptionsRec, _super);
function CardExpandableOptionsRec(defaults) {
_super.apply(this, arguments);
}
CardExpandableOptionsRec.attributesToDeclare = function () {
return [
this.attr("ExpandedDisabled", "expandedDisabledAttr", "expandedDisabled", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("IsExpanded", "isExpandedAttr", "expanded", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("IsInline", "isInlineAttr", "isInline", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CardExpandableOptionsRec.init();
return CardExpandableOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CardExpandableOptionsRec = CardExpandableOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CardExpandableOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CardExpandableOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CardExpandableOptionsRecord = (function (_super) {
__extends(CardExpandableOptionsRecord, _super);
function CardExpandableOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CardExpandableOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CardExpandableOptions", "cardExpandableOptionsAttr", "CardExpandableOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CardExpandableOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CardExpandableOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CardExpandableOptionsRecord.fromStructure = function (str) {
return new CardExpandableOptionsRecord(new CardExpandableOptionsRecord.RecordClass({
cardExpandableOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CardExpandableOptionsRecord._isAnonymousRecord = true;
CardExpandableOptionsRecord.UniqueId = "93dab75e-a046-82db-9ad1-9c6eae5ab22d";
CardExpandableOptionsRecord.init();
return CardExpandableOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CardExpandableOptionsRecord = CardExpandableOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CardExpandableOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CardExpandableOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CardExpandableOptionsRecordList = (function (_super) {
__extends(CardExpandableOptionsRecordList, _super);
function CardExpandableOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CardExpandableOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CardExpandableOptionsRecord;
return CardExpandableOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CardExpandableOptionsRecordList = CardExpandableOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomSVGOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomSVGOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomSVGOptionsRecord = (function (_super) {
__extends(CustomSVGOptionsRecord, _super);
function CustomSVGOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomSVGOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomSVGOptions", "customSVGOptionsAttr", "CustomSVGOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomSVGOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomSVGOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomSVGOptionsRecord.fromStructure = function (str) {
return new CustomSVGOptionsRecord(new CustomSVGOptionsRecord.RecordClass({
customSVGOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomSVGOptionsRecord._isAnonymousRecord = true;
CustomSVGOptionsRecord.UniqueId = "d652ec0d-7614-c413-fc56-599170dd2785";
CustomSVGOptionsRecord.init();
return CustomSVGOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomSVGOptionsRecord = CustomSVGOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomSVGOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomSVGOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomSVGOptionsRecordList = (function (_super) {
__extends(CustomSVGOptionsRecordList, _super);
function CustomSVGOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomSVGOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomSVGOptionsRecord;
return CustomSVGOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomSVGOptionsRecordList = CustomSVGOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownSizeRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomDropdownSizeRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownSizeRecord = (function (_super) {
__extends(CustomDropdownSizeRecord, _super);
function CustomDropdownSizeRecord(defaults) {
_super.apply(this, arguments);
}
CustomDropdownSizeRecord.attributesToDeclare = function () {
return [
this.attr("CustomDropdownSize", "customDropdownSizeAttr", "CustomDropdownSize", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomDropdownSizeRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomDropdownSizeRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomDropdownSizeRecord.fromStructure = function (str) {
return new CustomDropdownSizeRecord(new CustomDropdownSizeRecord.RecordClass({
customDropdownSizeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomDropdownSizeRecord._isAnonymousRecord = true;
CustomDropdownSizeRecord.UniqueId = "aa378e73-6d77-cb26-d299-5d48c8b77133";
CustomDropdownSizeRecord.init();
return CustomDropdownSizeRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownSizeRecord = CustomDropdownSizeRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownSizeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomDropdownSizeRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownSizeRecordList = (function (_super) {
__extends(CustomDropdownSizeRecordList, _super);
function CustomDropdownSizeRecordList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownSizeRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomDropdownSizeRecord;
return CustomDropdownSizeRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownSizeRecordList = CustomDropdownSizeRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomInputAlignmentRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomInputAlignmentRec = (function (_super) {
__extends(CustomInputAlignmentRec, _super);
function CustomInputAlignmentRec(defaults) {
_super.apply(this, arguments);
}
CustomInputAlignmentRec.attributesToDeclare = function () {
return [
this.attr("Class", "classAttr", "Class", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomInputAlignmentRec.fromStructure = function (str) {
return new CustomInputAlignmentRec(new CustomInputAlignmentRec.RecordClass({
classAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomInputAlignmentRec.init();
return CustomInputAlignmentRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomInputAlignmentRec = CustomInputAlignmentRec;

});
define("ShopperPortalEU_UI_Components.model$CircleIconOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CircleIconOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CircleIconOptionsList = (function (_super) {
__extends(CircleIconOptionsList, _super);
function CircleIconOptionsList(defaults) {
_super.apply(this, arguments);
}
CircleIconOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CircleIconOptionsRec;
return CircleIconOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CircleIconOptionsList = CircleIconOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomValidationMessageStateList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomValidationMessageStateRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomValidationMessageStateList = (function (_super) {
__extends(CustomValidationMessageStateList, _super);
function CustomValidationMessageStateList(defaults) {
_super.apply(this, arguments);
}
CustomValidationMessageStateList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomValidationMessageStateRec;
return CustomValidationMessageStateList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomValidationMessageStateList = CustomValidationMessageStateList;

});
define("ShopperPortalEU_UI_Components.model$CustomFlagOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomFlagOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomFlagOptionsList = (function (_super) {
__extends(CustomFlagOptionsList, _super);
function CustomFlagOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomFlagOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomFlagOptionsRec;
return CustomFlagOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomFlagOptionsList = CustomFlagOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomSwitchStateRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomSwitchStateRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomSwitchStateRecord = (function (_super) {
__extends(CustomSwitchStateRecord, _super);
function CustomSwitchStateRecord(defaults) {
_super.apply(this, arguments);
}
CustomSwitchStateRecord.attributesToDeclare = function () {
return [
this.attr("CustomSwitchState", "customSwitchStateAttr", "CustomSwitchState", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomSwitchStateRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomSwitchStateRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomSwitchStateRecord.fromStructure = function (str) {
return new CustomSwitchStateRecord(new CustomSwitchStateRecord.RecordClass({
customSwitchStateAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomSwitchStateRecord._isAnonymousRecord = true;
CustomSwitchStateRecord.UniqueId = "8af62ab1-0a5d-0cc7-5fbe-157f69267f33";
CustomSwitchStateRecord.init();
return CustomSwitchStateRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomSwitchStateRecord = CustomSwitchStateRecord;

});
define("ShopperPortalEU_UI_Components.model$DatatransCardChangeOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$DatatransCardChangeOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var DatatransCardChangeOptionsRecordList = (function (_super) {
__extends(DatatransCardChangeOptionsRecordList, _super);
function DatatransCardChangeOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
DatatransCardChangeOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.DatatransCardChangeOptionsRecord;
return DatatransCardChangeOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.DatatransCardChangeOptionsRecordList = DatatransCardChangeOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomAlertTypeList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomAlertTypeRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomAlertTypeList = (function (_super) {
__extends(CustomAlertTypeList, _super);
function CustomAlertTypeList(defaults) {
_super.apply(this, arguments);
}
CustomAlertTypeList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomAlertTypeRec;
return CustomAlertTypeList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomAlertTypeList = CustomAlertTypeList;

});
define("ShopperPortalEU_UI_Components.model$TextEllipsisReadMoreOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$TextEllipsisReadMoreOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var TextEllipsisReadMoreOptionsRecord = (function (_super) {
__extends(TextEllipsisReadMoreOptionsRecord, _super);
function TextEllipsisReadMoreOptionsRecord(defaults) {
_super.apply(this, arguments);
}
TextEllipsisReadMoreOptionsRecord.attributesToDeclare = function () {
return [
this.attr("TextEllipsisReadMoreOptions", "textEllipsisReadMoreOptionsAttr", "TextEllipsisReadMoreOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.TextEllipsisReadMoreOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.TextEllipsisReadMoreOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
TextEllipsisReadMoreOptionsRecord.fromStructure = function (str) {
return new TextEllipsisReadMoreOptionsRecord(new TextEllipsisReadMoreOptionsRecord.RecordClass({
textEllipsisReadMoreOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
TextEllipsisReadMoreOptionsRecord._isAnonymousRecord = true;
TextEllipsisReadMoreOptionsRecord.UniqueId = "e8ce543c-fbc3-3a9c-7d15-c1446b1bff5e";
TextEllipsisReadMoreOptionsRecord.init();
return TextEllipsisReadMoreOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.TextEllipsisReadMoreOptionsRecord = TextEllipsisReadMoreOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$TextEllipsisReadMoreOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$TextEllipsisReadMoreOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var TextEllipsisReadMoreOptionsRecordList = (function (_super) {
__extends(TextEllipsisReadMoreOptionsRecordList, _super);
function TextEllipsisReadMoreOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
TextEllipsisReadMoreOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.TextEllipsisReadMoreOptionsRecord;
return TextEllipsisReadMoreOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.TextEllipsisReadMoreOptionsRecordList = TextEllipsisReadMoreOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$FullHeightContentAlignmentRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$FullHeightContentAlignmentRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var FullHeightContentAlignmentRecord = (function (_super) {
__extends(FullHeightContentAlignmentRecord, _super);
function FullHeightContentAlignmentRecord(defaults) {
_super.apply(this, arguments);
}
FullHeightContentAlignmentRecord.attributesToDeclare = function () {
return [
this.attr("FullHeightContentAlignment", "fullHeightContentAlignmentAttr", "FullHeightContentAlignment", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.FullHeightContentAlignmentRec());
}, true, ShopperPortalEU_UI_ComponentsModel.FullHeightContentAlignmentRec)
].concat(_super.attributesToDeclare.call(this));
};
FullHeightContentAlignmentRecord.fromStructure = function (str) {
return new FullHeightContentAlignmentRecord(new FullHeightContentAlignmentRecord.RecordClass({
fullHeightContentAlignmentAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
FullHeightContentAlignmentRecord._isAnonymousRecord = true;
FullHeightContentAlignmentRecord.UniqueId = "e56e5290-74cb-5b14-23b8-47bb4e6088ee";
FullHeightContentAlignmentRecord.init();
return FullHeightContentAlignmentRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.FullHeightContentAlignmentRecord = FullHeightContentAlignmentRecord;

});
define("ShopperPortalEU_UI_Components.model$FullHeightContentAlignmentRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$FullHeightContentAlignmentRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var FullHeightContentAlignmentRecordList = (function (_super) {
__extends(FullHeightContentAlignmentRecordList, _super);
function FullHeightContentAlignmentRecordList(defaults) {
_super.apply(this, arguments);
}
FullHeightContentAlignmentRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.FullHeightContentAlignmentRecord;
return FullHeightContentAlignmentRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.FullHeightContentAlignmentRecordList = FullHeightContentAlignmentRecordList;

});
define("ShopperPortalEU_UI_Components.model$AlignRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$AlignRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var AlignRecord = (function (_super) {
__extends(AlignRecord, _super);
function AlignRecord(defaults) {
_super.apply(this, arguments);
}
AlignRecord.attributesToDeclare = function () {
return [
this.attr("Align", "alignAttr", "Align", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.AlignRec());
}, true, ShopperPortalEU_UI_ComponentsModel.AlignRec)
].concat(_super.attributesToDeclare.call(this));
};
AlignRecord.fromStructure = function (str) {
return new AlignRecord(new AlignRecord.RecordClass({
alignAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
AlignRecord._isAnonymousRecord = true;
AlignRecord.UniqueId = "8c669ce6-83c4-468e-bae2-57e5e28df7f5";
AlignRecord.init();
return AlignRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.AlignRecord = AlignRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomLinkOptionsIconRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsIconRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomLinkOptionsIconRecordList = (function (_super) {
__extends(CustomLinkOptionsIconRecordList, _super);
function CustomLinkOptionsIconRecordList(defaults) {
_super.apply(this, arguments);
}
CustomLinkOptionsIconRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomLinkOptionsIconRecord;
return CustomLinkOptionsIconRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomLinkOptionsIconRecordList = CustomLinkOptionsIconRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomButtonOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomButtonOptionsRec = (function (_super) {
__extends(CustomButtonOptionsRec, _super);
function CustomButtonOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomButtonOptionsRec.attributesToDeclare = function () {
return [
this.attr("TestId", "testIdAttr", "testId", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Type", "typeAttr", "type", false, false, OS.DataTypes.DataTypes.Text, function () {
return ShopperPortalEU_UI_ComponentsModel.staticEntities.customButtonType.secondary;
}, true), 
this.attr("State", "stateAttr", "state", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("IsLoading", "isLoadingAttr", "loading", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("IsFullWidth", "isFullWidthAttr", "fullWidth", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomButtonOptionsRec.init();
return CustomButtonOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRec = CustomButtonOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomButtonOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomButtonOptionsRecord = (function (_super) {
__extends(CustomButtonOptionsRecord, _super);
function CustomButtonOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomButtonOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomButtonOptions", "customButtonOptionsAttr", "CustomButtonOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomButtonOptionsRecord.fromStructure = function (str) {
return new CustomButtonOptionsRecord(new CustomButtonOptionsRecord.RecordClass({
customButtonOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomButtonOptionsRecord._isAnonymousRecord = true;
CustomButtonOptionsRecord.UniqueId = "c1c71989-9f61-b71a-d94b-f45b523c7551";
CustomButtonOptionsRecord.init();
return CustomButtonOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRecord = CustomButtonOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomButtonOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomButtonOptionsRecordList = (function (_super) {
__extends(CustomButtonOptionsRecordList, _super);
function CustomButtonOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomButtonOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRecord;
return CustomButtonOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRecordList = CustomButtonOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CircleIconSizeRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CircleIconSizeRec = (function (_super) {
__extends(CircleIconSizeRec, _super);
function CircleIconSizeRec(defaults) {
_super.apply(this, arguments);
}
CircleIconSizeRec.attributesToDeclare = function () {
return [
this.attr("Class", "classAttr", "Class", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", true, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CircleIconSizeRec.init();
return CircleIconSizeRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CircleIconSizeRec = CircleIconSizeRec;

});
define("ShopperPortalEU_UI_Components.model$CircleIconSizeList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CircleIconSizeRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CircleIconSizeList = (function (_super) {
__extends(CircleIconSizeList, _super);
function CircleIconSizeList(defaults) {
_super.apply(this, arguments);
}
CircleIconSizeList.itemType = ShopperPortalEU_UI_ComponentsModel.CircleIconSizeRec;
return CircleIconSizeList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CircleIconSizeList = CircleIconSizeList;

});
define("ShopperPortalEU_UI_Components.model$CustomCardOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomCardOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomCardOptionsList = (function (_super) {
__extends(CustomCardOptionsList, _super);
function CustomCardOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomCardOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomCardOptionsRec;
return CustomCardOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomCardOptionsList = CustomCardOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomWizardItemStateList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomWizardItemStateRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomWizardItemStateList = (function (_super) {
__extends(CustomWizardItemStateList, _super);
function CustomWizardItemStateList(defaults) {
_super.apply(this, arguments);
}
CustomWizardItemStateList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomWizardItemStateRec;
return CustomWizardItemStateList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomWizardItemStateList = CustomWizardItemStateList;

});
define("ShopperPortalEU_UI_Components.model$CodeInputChangeOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CodeInputChangeOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CodeInputChangeOptionsRecordList = (function (_super) {
__extends(CodeInputChangeOptionsRecordList, _super);
function CodeInputChangeOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CodeInputChangeOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CodeInputChangeOptionsRecord;
return CodeInputChangeOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CodeInputChangeOptionsRecordList = CodeInputChangeOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomCheckboxOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomCheckboxOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomCheckboxOptionsList = (function (_super) {
__extends(CustomCheckboxOptionsList, _super);
function CustomCheckboxOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomCheckboxOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomCheckboxOptionsRec;
return CustomCheckboxOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomCheckboxOptionsList = CustomCheckboxOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomListItemOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomListItemOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomListItemOptionsRecordList = (function (_super) {
__extends(CustomListItemOptionsRecordList, _super);
function CustomListItemOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomListItemOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomListItemOptionsRecord;
return CustomListItemOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomListItemOptionsRecordList = CustomListItemOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomAlertIconOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomAlertIconOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomAlertIconOptionsList = (function (_super) {
__extends(CustomAlertIconOptionsList, _super);
function CustomAlertIconOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomAlertIconOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomAlertIconOptionsRec;
return CustomAlertIconOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomAlertIconOptionsList = CustomAlertIconOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownSizeList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomDropdownSizeRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownSizeList = (function (_super) {
__extends(CustomDropdownSizeList, _super);
function CustomDropdownSizeList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownSizeList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomDropdownSizeRec;
return CustomDropdownSizeList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownSizeList = CustomDropdownSizeList;

});
define("ShopperPortalEU_UI_Components.model$CustomCarouselOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomCarouselOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomCarouselOptionsRecordList = (function (_super) {
__extends(CustomCarouselOptionsRecordList, _super);
function CustomCarouselOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomCarouselOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomCarouselOptionsRecord;
return CustomCarouselOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomCarouselOptionsRecordList = CustomCarouselOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$ButtonOptionOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$ButtonOptionOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var ButtonOptionOptionsRecord = (function (_super) {
__extends(ButtonOptionOptionsRecord, _super);
function ButtonOptionOptionsRecord(defaults) {
_super.apply(this, arguments);
}
ButtonOptionOptionsRecord.attributesToDeclare = function () {
return [
this.attr("ButtonOptionOptions", "buttonOptionOptionsAttr", "ButtonOptionOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.ButtonOptionOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.ButtonOptionOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
ButtonOptionOptionsRecord.fromStructure = function (str) {
return new ButtonOptionOptionsRecord(new ButtonOptionOptionsRecord.RecordClass({
buttonOptionOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ButtonOptionOptionsRecord._isAnonymousRecord = true;
ButtonOptionOptionsRecord.UniqueId = "9609ad90-a772-2e28-e166-1c86a102a919";
ButtonOptionOptionsRecord.init();
return ButtonOptionOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.ButtonOptionOptionsRecord = ButtonOptionOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$MonthYearInputChangeOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var MonthYearInputChangeOptionsRec = (function (_super) {
__extends(MonthYearInputChangeOptionsRec, _super);
function MonthYearInputChangeOptionsRec(defaults) {
_super.apply(this, arguments);
}
MonthYearInputChangeOptionsRec.attributesToDeclare = function () {
return [
this.attr("Date", "dateAttr", "date", false, false, OS.DataTypes.DataTypes.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("Month", "monthAttr", "month", false, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true), 
this.attr("Year", "yearAttr", "year", false, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
MonthYearInputChangeOptionsRec.init();
return MonthYearInputChangeOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.MonthYearInputChangeOptionsRec = MonthYearInputChangeOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$MonthYearInputChangeOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$MonthYearInputChangeOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var MonthYearInputChangeOptionsRecord = (function (_super) {
__extends(MonthYearInputChangeOptionsRecord, _super);
function MonthYearInputChangeOptionsRecord(defaults) {
_super.apply(this, arguments);
}
MonthYearInputChangeOptionsRecord.attributesToDeclare = function () {
return [
this.attr("MonthYearInputChangeOptions", "monthYearInputChangeOptionsAttr", "MonthYearInputChangeOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.MonthYearInputChangeOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.MonthYearInputChangeOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
MonthYearInputChangeOptionsRecord.fromStructure = function (str) {
return new MonthYearInputChangeOptionsRecord(new MonthYearInputChangeOptionsRecord.RecordClass({
monthYearInputChangeOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
MonthYearInputChangeOptionsRecord._isAnonymousRecord = true;
MonthYearInputChangeOptionsRecord.UniqueId = "966ac8fa-2030-7616-d6be-0217acae8090";
MonthYearInputChangeOptionsRecord.init();
return MonthYearInputChangeOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.MonthYearInputChangeOptionsRecord = MonthYearInputChangeOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomButtonItemOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomButtonItemOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomButtonItemOptionsRecordList = (function (_super) {
__extends(CustomButtonItemOptionsRecordList, _super);
function CustomButtonItemOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomButtonItemOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomButtonItemOptionsRecord;
return CustomButtonItemOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomButtonItemOptionsRecordList = CustomButtonItemOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$MonthYearInputValidationOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$MonthYearInputValidationOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var MonthYearInputValidationOptionsList = (function (_super) {
__extends(MonthYearInputValidationOptionsList, _super);
function MonthYearInputValidationOptionsList(defaults) {
_super.apply(this, arguments);
}
MonthYearInputValidationOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.MonthYearInputValidationOptionsRec;
return MonthYearInputValidationOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.MonthYearInputValidationOptionsList = MonthYearInputValidationOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomPopupLayoutHeaderImageOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomPopupLayoutHeaderImageOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomPopupLayoutHeaderImageOptionsList = (function (_super) {
__extends(CustomPopupLayoutHeaderImageOptionsList, _super);
function CustomPopupLayoutHeaderImageOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomPopupLayoutHeaderImageOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomPopupLayoutHeaderImageOptionsRec;
return CustomPopupLayoutHeaderImageOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomPopupLayoutHeaderImageOptionsList = CustomPopupLayoutHeaderImageOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownListItemOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomDropdownListItemOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownListItemOptionsList = (function (_super) {
__extends(CustomDropdownListItemOptionsList, _super);
function CustomDropdownListItemOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownListItemOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomDropdownListItemOptionsRec;
return CustomDropdownListItemOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownListItemOptionsList = CustomDropdownListItemOptionsList;

});
define("ShopperPortalEU_UI_Components.model$ScanPassportDataList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$ScanPassportDataRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var ScanPassportDataList = (function (_super) {
__extends(ScanPassportDataList, _super);
function ScanPassportDataList(defaults) {
_super.apply(this, arguments);
}
ScanPassportDataList.itemType = ShopperPortalEU_UI_ComponentsModel.ScanPassportDataRec;
return ScanPassportDataList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.ScanPassportDataList = ScanPassportDataList;

});
define("ShopperPortalEU_UI_Components.model$CustomUploadOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomUploadOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomUploadOptionsRecord = (function (_super) {
__extends(CustomUploadOptionsRecord, _super);
function CustomUploadOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomUploadOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomUploadOptions", "customUploadOptionsAttr", "CustomUploadOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomUploadOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomUploadOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomUploadOptionsRecord.fromStructure = function (str) {
return new CustomUploadOptionsRecord(new CustomUploadOptionsRecord.RecordClass({
customUploadOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomUploadOptionsRecord._isAnonymousRecord = true;
CustomUploadOptionsRecord.UniqueId = "995d0138-660e-c513-45e5-6128d4636deb";
CustomUploadOptionsRecord.init();
return CustomUploadOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomUploadOptionsRecord = CustomUploadOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomLinkStateRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomLinkStateRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomLinkStateRecord = (function (_super) {
__extends(CustomLinkStateRecord, _super);
function CustomLinkStateRecord(defaults) {
_super.apply(this, arguments);
}
CustomLinkStateRecord.attributesToDeclare = function () {
return [
this.attr("CustomLinkState", "customLinkStateAttr", "CustomLinkState", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomLinkStateRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomLinkStateRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomLinkStateRecord.fromStructure = function (str) {
return new CustomLinkStateRecord(new CustomLinkStateRecord.RecordClass({
customLinkStateAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomLinkStateRecord._isAnonymousRecord = true;
CustomLinkStateRecord.UniqueId = "99b25a68-e71f-c7ab-86b5-bb8b521dee5b";
CustomLinkStateRecord.init();
return CustomLinkStateRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomLinkStateRecord = CustomLinkStateRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomInputOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomInputOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomInputOptionsList = (function (_super) {
__extends(CustomInputOptionsList, _super);
function CustomInputOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomInputOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomInputOptionsRec;
return CustomInputOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomInputOptionsList = CustomInputOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomBlankSlateIconOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomBlankSlateIconOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomBlankSlateIconOptionsList = (function (_super) {
__extends(CustomBlankSlateIconOptionsList, _super);
function CustomBlankSlateIconOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomBlankSlateIconOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomBlankSlateIconOptionsRec;
return CustomBlankSlateIconOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomBlankSlateIconOptionsList = CustomBlankSlateIconOptionsList;

});
define("ShopperPortalEU_UI_Components.model$MonthYearInputChangeOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$MonthYearInputChangeOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var MonthYearInputChangeOptionsRecordList = (function (_super) {
__extends(MonthYearInputChangeOptionsRecordList, _super);
function MonthYearInputChangeOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
MonthYearInputChangeOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.MonthYearInputChangeOptionsRecord;
return MonthYearInputChangeOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.MonthYearInputChangeOptionsRecordList = MonthYearInputChangeOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$ButtonOptionTypeList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$ButtonOptionTypeRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var ButtonOptionTypeList = (function (_super) {
__extends(ButtonOptionTypeList, _super);
function ButtonOptionTypeList(defaults) {
_super.apply(this, arguments);
}
ButtonOptionTypeList.itemType = ShopperPortalEU_UI_ComponentsModel.ButtonOptionTypeRec;
return ButtonOptionTypeList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.ButtonOptionTypeList = ButtonOptionTypeList;

});
define("ShopperPortalEU_UI_Components.model$CustomIconFamilyRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomIconFamilyRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomIconFamilyRecord = (function (_super) {
__extends(CustomIconFamilyRecord, _super);
function CustomIconFamilyRecord(defaults) {
_super.apply(this, arguments);
}
CustomIconFamilyRecord.attributesToDeclare = function () {
return [
this.attr("CustomIconFamily", "customIconFamilyAttr", "CustomIconFamily", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomIconFamilyRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomIconFamilyRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomIconFamilyRecord.fromStructure = function (str) {
return new CustomIconFamilyRecord(new CustomIconFamilyRecord.RecordClass({
customIconFamilyAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomIconFamilyRecord._isAnonymousRecord = true;
CustomIconFamilyRecord.UniqueId = "9fc51a4a-fa2f-d647-1909-b8f8c0bf9224";
CustomIconFamilyRecord.init();
return CustomIconFamilyRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomIconFamilyRecord = CustomIconFamilyRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomCheckboxStateList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomCheckboxStateRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomCheckboxStateList = (function (_super) {
__extends(CustomCheckboxStateList, _super);
function CustomCheckboxStateList(defaults) {
_super.apply(this, arguments);
}
CustomCheckboxStateList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomCheckboxStateRec;
return CustomCheckboxStateList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomCheckboxStateList = CustomCheckboxStateList;

});
define("ShopperPortalEU_UI_Components.model$CustomCheckboxOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomCheckboxOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomCheckboxOptionsRecordList = (function (_super) {
__extends(CustomCheckboxOptionsRecordList, _super);
function CustomCheckboxOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomCheckboxOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomCheckboxOptionsRecord;
return CustomCheckboxOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomCheckboxOptionsRecordList = CustomCheckboxOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomBottomBarOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomBottomBarOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomBottomBarOptionsList = (function (_super) {
__extends(CustomBottomBarOptionsList, _super);
function CustomBottomBarOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomBottomBarOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomBottomBarOptionsRec;
return CustomBottomBarOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomBottomBarOptionsList = CustomBottomBarOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomSeparatorOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomSeparatorOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomSeparatorOptionsList = (function (_super) {
__extends(CustomSeparatorOptionsList, _super);
function CustomSeparatorOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomSeparatorOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomSeparatorOptionsRec;
return CustomSeparatorOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomSeparatorOptionsList = CustomSeparatorOptionsList;

});
define("ShopperPortalEU_UI_Components.model$FullHeightContentTopOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$FullHeightContentTopOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var FullHeightContentTopOptionsList = (function (_super) {
__extends(FullHeightContentTopOptionsList, _super);
function FullHeightContentTopOptionsList(defaults) {
_super.apply(this, arguments);
}
FullHeightContentTopOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.FullHeightContentTopOptionsRec;
return FullHeightContentTopOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.FullHeightContentTopOptionsList = FullHeightContentTopOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownListValueOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomDropdownListValueOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownListValueOptionsRecord = (function (_super) {
__extends(CustomDropdownListValueOptionsRecord, _super);
function CustomDropdownListValueOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomDropdownListValueOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomDropdownListValueOptions", "customDropdownListValueOptionsAttr", "CustomDropdownListValueOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValueOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValueOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomDropdownListValueOptionsRecord.fromStructure = function (str) {
return new CustomDropdownListValueOptionsRecord(new CustomDropdownListValueOptionsRecord.RecordClass({
customDropdownListValueOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomDropdownListValueOptionsRecord._isAnonymousRecord = true;
CustomDropdownListValueOptionsRecord.UniqueId = "a41ccd9a-afc7-1231-96be-c3182b0c5b18";
CustomDropdownListValueOptionsRecord.init();
return CustomDropdownListValueOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValueOptionsRecord = CustomDropdownListValueOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomTextAreaValidationOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomTextAreaValidationOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomTextAreaValidationOptionsRecord = (function (_super) {
__extends(CustomTextAreaValidationOptionsRecord, _super);
function CustomTextAreaValidationOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomTextAreaValidationOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomTextAreaValidationOptions", "customTextAreaValidationOptionsAttr", "CustomTextAreaValidationOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomTextAreaValidationOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomTextAreaValidationOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomTextAreaValidationOptionsRecord.fromStructure = function (str) {
return new CustomTextAreaValidationOptionsRecord(new CustomTextAreaValidationOptionsRecord.RecordClass({
customTextAreaValidationOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomTextAreaValidationOptionsRecord._isAnonymousRecord = true;
CustomTextAreaValidationOptionsRecord.UniqueId = "a6c34f5d-cf76-d3fa-29e9-f78cfee22059";
CustomTextAreaValidationOptionsRecord.init();
return CustomTextAreaValidationOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomTextAreaValidationOptionsRecord = CustomTextAreaValidationOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomInputOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomInputOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomInputOptionsRecordList = (function (_super) {
__extends(CustomInputOptionsRecordList, _super);
function CustomInputOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomInputOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomInputOptionsRecord;
return CustomInputOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomInputOptionsRecordList = CustomInputOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomCheckboxStateRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomCheckboxStateRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomCheckboxStateRecord = (function (_super) {
__extends(CustomCheckboxStateRecord, _super);
function CustomCheckboxStateRecord(defaults) {
_super.apply(this, arguments);
}
CustomCheckboxStateRecord.attributesToDeclare = function () {
return [
this.attr("CustomCheckboxState", "customCheckboxStateAttr", "CustomCheckboxState", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomCheckboxStateRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomCheckboxStateRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomCheckboxStateRecord.fromStructure = function (str) {
return new CustomCheckboxStateRecord(new CustomCheckboxStateRecord.RecordClass({
customCheckboxStateAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomCheckboxStateRecord._isAnonymousRecord = true;
CustomCheckboxStateRecord.UniqueId = "c2336c77-9611-c842-6dfc-f5e65653939a";
CustomCheckboxStateRecord.init();
return CustomCheckboxStateRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomCheckboxStateRecord = CustomCheckboxStateRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomCheckboxStateRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomCheckboxStateRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomCheckboxStateRecordList = (function (_super) {
__extends(CustomCheckboxStateRecordList, _super);
function CustomCheckboxStateRecordList(defaults) {
_super.apply(this, arguments);
}
CustomCheckboxStateRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomCheckboxStateRecord;
return CustomCheckboxStateRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomCheckboxStateRecordList = CustomCheckboxStateRecordList;

});
define("ShopperPortalEU_UI_Components.model$TextEllipsisReadMoreOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$TextEllipsisReadMoreOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var TextEllipsisReadMoreOptionsList = (function (_super) {
__extends(TextEllipsisReadMoreOptionsList, _super);
function TextEllipsisReadMoreOptionsList(defaults) {
_super.apply(this, arguments);
}
TextEllipsisReadMoreOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.TextEllipsisReadMoreOptionsRec;
return TextEllipsisReadMoreOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.TextEllipsisReadMoreOptionsList = TextEllipsisReadMoreOptionsList;

});
define("ShopperPortalEU_UI_Components.model$LabelValueOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$LabelValueOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var LabelValueOptionsRecordList = (function (_super) {
__extends(LabelValueOptionsRecordList, _super);
function LabelValueOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
LabelValueOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.LabelValueOptionsRecord;
return LabelValueOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.LabelValueOptionsRecordList = LabelValueOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$ScanBarcodeDataRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$ScanBarcodeDataRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var ScanBarcodeDataRecord = (function (_super) {
__extends(ScanBarcodeDataRecord, _super);
function ScanBarcodeDataRecord(defaults) {
_super.apply(this, arguments);
}
ScanBarcodeDataRecord.attributesToDeclare = function () {
return [
this.attr("ScanBarcodeData", "scanBarcodeDataAttr", "ScanBarcodeData", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.ScanBarcodeDataRec());
}, true, ShopperPortalEU_UI_ComponentsModel.ScanBarcodeDataRec)
].concat(_super.attributesToDeclare.call(this));
};
ScanBarcodeDataRecord.fromStructure = function (str) {
return new ScanBarcodeDataRecord(new ScanBarcodeDataRecord.RecordClass({
scanBarcodeDataAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ScanBarcodeDataRecord._isAnonymousRecord = true;
ScanBarcodeDataRecord.UniqueId = "ab4e2636-7b94-c906-2ea8-ffc8bea49921";
ScanBarcodeDataRecord.init();
return ScanBarcodeDataRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.ScanBarcodeDataRecord = ScanBarcodeDataRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomFlagOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomFlagOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomFlagOptionsRecordList = (function (_super) {
__extends(CustomFlagOptionsRecordList, _super);
function CustomFlagOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomFlagOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomFlagOptionsRecord;
return CustomFlagOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomFlagOptionsRecordList = CustomFlagOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$PhoneNumberInputCountryOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$PhoneNumberInputCountryOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var PhoneNumberInputCountryOptionsRecordList = (function (_super) {
__extends(PhoneNumberInputCountryOptionsRecordList, _super);
function PhoneNumberInputCountryOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
PhoneNumberInputCountryOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputCountryOptionsRecord;
return PhoneNumberInputCountryOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputCountryOptionsRecordList = PhoneNumberInputCountryOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownValidationOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomDropdownValidationOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownValidationOptionsRecordList = (function (_super) {
__extends(CustomDropdownValidationOptionsRecordList, _super);
function CustomDropdownValidationOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownValidationOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomDropdownValidationOptionsRecord;
return CustomDropdownValidationOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownValidationOptionsRecordList = CustomDropdownValidationOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomRadioGroupOrientationList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomRadioGroupOrientationRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomRadioGroupOrientationList = (function (_super) {
__extends(CustomRadioGroupOrientationList, _super);
function CustomRadioGroupOrientationList(defaults) {
_super.apply(this, arguments);
}
CustomRadioGroupOrientationList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomRadioGroupOrientationRec;
return CustomRadioGroupOrientationList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomRadioGroupOrientationList = CustomRadioGroupOrientationList;

});
define("ShopperPortalEU_UI_Components.model$CustomLoadingOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomLoadingOptionsRec = (function (_super) {
__extends(CustomLoadingOptionsRec, _super);
function CustomLoadingOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomLoadingOptionsRec.attributesToDeclare = function () {
return [
this.attr("Show", "showAttr", "show", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("Text", "textAttr", "text", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("IsFullHeight", "isFullHeightAttr", "fullHeight", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("IsFullScreen", "isFullScreenAttr", "fullScreen", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomLoadingOptionsRec.init();
return CustomLoadingOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomLoadingOptionsRec = CustomLoadingOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$CustomLoadingOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomLoadingOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomLoadingOptionsList = (function (_super) {
__extends(CustomLoadingOptionsList, _super);
function CustomLoadingOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomLoadingOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomLoadingOptionsRec;
return CustomLoadingOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomLoadingOptionsList = CustomLoadingOptionsList;

});
define("ShopperPortalEU_UI_Components.model$GetOSBrowserOptionRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$GetOSBrowserOptionRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var GetOSBrowserOptionRecord = (function (_super) {
__extends(GetOSBrowserOptionRecord, _super);
function GetOSBrowserOptionRecord(defaults) {
_super.apply(this, arguments);
}
GetOSBrowserOptionRecord.attributesToDeclare = function () {
return [
this.attr("GetOSBrowserOption", "getOSBrowserOptionAttr", "GetOSBrowserOption", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.GetOSBrowserOptionRec());
}, true, ShopperPortalEU_UI_ComponentsModel.GetOSBrowserOptionRec)
].concat(_super.attributesToDeclare.call(this));
};
GetOSBrowserOptionRecord.fromStructure = function (str) {
return new GetOSBrowserOptionRecord(new GetOSBrowserOptionRecord.RecordClass({
getOSBrowserOptionAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
GetOSBrowserOptionRecord._isAnonymousRecord = true;
GetOSBrowserOptionRecord.UniqueId = "af01889a-10cd-7c1d-318e-a99a5a90c59a";
GetOSBrowserOptionRecord.init();
return GetOSBrowserOptionRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.GetOSBrowserOptionRecord = GetOSBrowserOptionRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomFormOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomFormOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomFormOptionsRecord = (function (_super) {
__extends(CustomFormOptionsRecord, _super);
function CustomFormOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomFormOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomFormOptions", "customFormOptionsAttr", "CustomFormOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomFormOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomFormOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomFormOptionsRecord.fromStructure = function (str) {
return new CustomFormOptionsRecord(new CustomFormOptionsRecord.RecordClass({
customFormOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomFormOptionsRecord._isAnonymousRecord = true;
CustomFormOptionsRecord.UniqueId = "c9cd1982-bef8-6871-7102-5ab6268c5317";
CustomFormOptionsRecord.init();
return CustomFormOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomFormOptionsRecord = CustomFormOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomFormOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomFormOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomFormOptionsRecordList = (function (_super) {
__extends(CustomFormOptionsRecordList, _super);
function CustomFormOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomFormOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomFormOptionsRecord;
return CustomFormOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomFormOptionsRecordList = CustomFormOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$GetOSOptionRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$GetOSOptionRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var GetOSOptionRecordList = (function (_super) {
__extends(GetOSOptionRecordList, _super);
function GetOSOptionRecordList(defaults) {
_super.apply(this, arguments);
}
GetOSOptionRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.GetOSOptionRecord;
return GetOSOptionRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.GetOSOptionRecordList = GetOSOptionRecordList;

});
define("ShopperPortalEU_UI_Components.model$PhoneNumberInputOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$PhoneNumberInputSearchOptionsRec", "ShopperPortalEU_UI_Components.model$CustomInputValidationOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var PhoneNumberInputOptionsRec = (function (_super) {
__extends(PhoneNumberInputOptionsRec, _super);
function PhoneNumberInputOptionsRec(defaults) {
_super.apply(this, arguments);
}
PhoneNumberInputOptionsRec.attributesToDeclare = function () {
return [
this.attr("TestId", "testIdAttr", "testId", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("PhoneNumber", "phoneNumberAttr", "phoneNumber", false, false, OS.DataTypes.DataTypes.PhoneNumber, function () {
return "";
}, true), 
this.attr("Label", "labelAttr", "label", false, false, OS.DataTypes.DataTypes.Text, function () {
return "Mobile number";
}, true), 
this.attr("DropdownLabel", "dropdownLabelAttr", "dropdownLabel", false, false, OS.DataTypes.DataTypes.Text, function () {
return "Select country";
}, true), 
this.attr("IsMandatory", "isMandatoryAttr", "mandatory", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("IsDisabled", "isDisabledAttr", "disabled", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("IsReadOnly", "isReadOnlyAttr", "readOnly", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("Search", "searchAttr", "search", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputSearchOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputSearchOptionsRec), 
this.attr("Validation", "validationAttr", "validation", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomInputValidationOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomInputValidationOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
PhoneNumberInputOptionsRec.init();
return PhoneNumberInputOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputOptionsRec = PhoneNumberInputOptionsRec;

});
define("ShopperPortalEU_UI_Components.model$PhoneNumberInputOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$PhoneNumberInputOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var PhoneNumberInputOptionsList = (function (_super) {
__extends(PhoneNumberInputOptionsList, _super);
function PhoneNumberInputOptionsList(defaults) {
_super.apply(this, arguments);
}
PhoneNumberInputOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputOptionsRec;
return PhoneNumberInputOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputOptionsList = PhoneNumberInputOptionsList;

});
define("ShopperPortalEU_UI_Components.model$DatatransCardGetCardInfoDataOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$DatatransCardGetCardInfoDataOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var DatatransCardGetCardInfoDataOptionsRecord = (function (_super) {
__extends(DatatransCardGetCardInfoDataOptionsRecord, _super);
function DatatransCardGetCardInfoDataOptionsRecord(defaults) {
_super.apply(this, arguments);
}
DatatransCardGetCardInfoDataOptionsRecord.attributesToDeclare = function () {
return [
this.attr("DatatransCardGetCardInfoDataOptions", "datatransCardGetCardInfoDataOptionsAttr", "DatatransCardGetCardInfoDataOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.DatatransCardGetCardInfoDataOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.DatatransCardGetCardInfoDataOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
DatatransCardGetCardInfoDataOptionsRecord.fromStructure = function (str) {
return new DatatransCardGetCardInfoDataOptionsRecord(new DatatransCardGetCardInfoDataOptionsRecord.RecordClass({
datatransCardGetCardInfoDataOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
DatatransCardGetCardInfoDataOptionsRecord._isAnonymousRecord = true;
DatatransCardGetCardInfoDataOptionsRecord.UniqueId = "d96bb604-5259-b7b2-4495-486306ac2958";
DatatransCardGetCardInfoDataOptionsRecord.init();
return DatatransCardGetCardInfoDataOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.DatatransCardGetCardInfoDataOptionsRecord = DatatransCardGetCardInfoDataOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$DatatransCardGetCardInfoDataOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$DatatransCardGetCardInfoDataOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var DatatransCardGetCardInfoDataOptionsRecordList = (function (_super) {
__extends(DatatransCardGetCardInfoDataOptionsRecordList, _super);
function DatatransCardGetCardInfoDataOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
DatatransCardGetCardInfoDataOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.DatatransCardGetCardInfoDataOptionsRecord;
return DatatransCardGetCardInfoDataOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.DatatransCardGetCardInfoDataOptionsRecordList = DatatransCardGetCardInfoDataOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomIconFamilyRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomIconFamilyRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomIconFamilyRecordList = (function (_super) {
__extends(CustomIconFamilyRecordList, _super);
function CustomIconFamilyRecordList(defaults) {
_super.apply(this, arguments);
}
CustomIconFamilyRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomIconFamilyRecord;
return CustomIconFamilyRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomIconFamilyRecordList = CustomIconFamilyRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownListValidationOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomDropdownListValidationOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownListValidationOptionsRecordList = (function (_super) {
__extends(CustomDropdownListValidationOptionsRecordList, _super);
function CustomDropdownListValidationOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownListValidationOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValidationOptionsRecord;
return CustomDropdownListValidationOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValidationOptionsRecordList = CustomDropdownListValidationOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$FullHeightContentBottomOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$FullHeightContentBottomOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var FullHeightContentBottomOptionsRecordList = (function (_super) {
__extends(FullHeightContentBottomOptionsRecordList, _super);
function FullHeightContentBottomOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
FullHeightContentBottomOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.FullHeightContentBottomOptionsRecord;
return FullHeightContentBottomOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.FullHeightContentBottomOptionsRecordList = FullHeightContentBottomOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownListOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomDropdownListOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownListOptionsList = (function (_super) {
__extends(CustomDropdownListOptionsList, _super);
function CustomDropdownListOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownListOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomDropdownListOptionsRec;
return CustomDropdownListOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownListOptionsList = CustomDropdownListOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomSeparatorLabelOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomSeparatorLabelOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomSeparatorLabelOptionsList = (function (_super) {
__extends(CustomSeparatorLabelOptionsList, _super);
function CustomSeparatorLabelOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomSeparatorLabelOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomSeparatorLabelOptionsRec;
return CustomSeparatorLabelOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomSeparatorLabelOptionsList = CustomSeparatorLabelOptionsList;

});
define("ShopperPortalEU_UI_Components.model$PhoneNumberInputCountryOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$PhoneNumberInputCountryOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var PhoneNumberInputCountryOptionsList = (function (_super) {
__extends(PhoneNumberInputCountryOptionsList, _super);
function PhoneNumberInputCountryOptionsList(defaults) {
_super.apply(this, arguments);
}
PhoneNumberInputCountryOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputCountryOptionsRec;
return PhoneNumberInputCountryOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputCountryOptionsList = PhoneNumberInputCountryOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomLinkIconAlignmentList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomLinkIconAlignmentRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomLinkIconAlignmentList = (function (_super) {
__extends(CustomLinkIconAlignmentList, _super);
function CustomLinkIconAlignmentList(defaults) {
_super.apply(this, arguments);
}
CustomLinkIconAlignmentList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomLinkIconAlignmentRec;
return CustomLinkIconAlignmentList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomLinkIconAlignmentList = CustomLinkIconAlignmentList;

});
define("ShopperPortalEU_UI_Components.model$CustomButtonIconAlignmentRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomButtonIconAlignmentRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomButtonIconAlignmentRecord = (function (_super) {
__extends(CustomButtonIconAlignmentRecord, _super);
function CustomButtonIconAlignmentRecord(defaults) {
_super.apply(this, arguments);
}
CustomButtonIconAlignmentRecord.attributesToDeclare = function () {
return [
this.attr("CustomButtonIconAlignment", "customButtonIconAlignmentAttr", "CustomButtonIconAlignment", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomButtonIconAlignmentRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomButtonIconAlignmentRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomButtonIconAlignmentRecord.fromStructure = function (str) {
return new CustomButtonIconAlignmentRecord(new CustomButtonIconAlignmentRecord.RecordClass({
customButtonIconAlignmentAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomButtonIconAlignmentRecord._isAnonymousRecord = true;
CustomButtonIconAlignmentRecord.UniqueId = "b6c89ce1-fc47-84f4-dab1-55a9efea3489";
CustomButtonIconAlignmentRecord.init();
return CustomButtonIconAlignmentRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomButtonIconAlignmentRecord = CustomButtonIconAlignmentRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomLoadingOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomLoadingOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomLoadingOptionsRecord = (function (_super) {
__extends(CustomLoadingOptionsRecord, _super);
function CustomLoadingOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomLoadingOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomLoadingOptions", "customLoadingOptionsAttr", "CustomLoadingOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomLoadingOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomLoadingOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomLoadingOptionsRecord.fromStructure = function (str) {
return new CustomLoadingOptionsRecord(new CustomLoadingOptionsRecord.RecordClass({
customLoadingOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomLoadingOptionsRecord._isAnonymousRecord = true;
CustomLoadingOptionsRecord.UniqueId = "ebc677c9-b8b0-9c98-ea26-376582f23c2a";
CustomLoadingOptionsRecord.init();
return CustomLoadingOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomLoadingOptionsRecord = CustomLoadingOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomLoadingOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomLoadingOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomLoadingOptionsRecordList = (function (_super) {
__extends(CustomLoadingOptionsRecordList, _super);
function CustomLoadingOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomLoadingOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomLoadingOptionsRecord;
return CustomLoadingOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomLoadingOptionsRecordList = CustomLoadingOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$DatatransCardGetCardInfoOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$DatatransCardGetCardInfoOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var DatatransCardGetCardInfoOptionsList = (function (_super) {
__extends(DatatransCardGetCardInfoOptionsList, _super);
function DatatransCardGetCardInfoOptionsList(defaults) {
_super.apply(this, arguments);
}
DatatransCardGetCardInfoOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.DatatransCardGetCardInfoOptionsRec;
return DatatransCardGetCardInfoOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.DatatransCardGetCardInfoOptionsList = DatatransCardGetCardInfoOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownCustomValueOptionRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomDropdownCustomValueOptionRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownCustomValueOptionRecord = (function (_super) {
__extends(CustomDropdownCustomValueOptionRecord, _super);
function CustomDropdownCustomValueOptionRecord(defaults) {
_super.apply(this, arguments);
}
CustomDropdownCustomValueOptionRecord.attributesToDeclare = function () {
return [
this.attr("CustomDropdownCustomValueOption", "customDropdownCustomValueOptionAttr", "CustomDropdownCustomValueOption", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomDropdownCustomValueOptionRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomDropdownCustomValueOptionRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomDropdownCustomValueOptionRecord.fromStructure = function (str) {
return new CustomDropdownCustomValueOptionRecord(new CustomDropdownCustomValueOptionRecord.RecordClass({
customDropdownCustomValueOptionAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomDropdownCustomValueOptionRecord._isAnonymousRecord = true;
CustomDropdownCustomValueOptionRecord.UniqueId = "b7331f1e-ac60-fdfb-5015-f3bf20385d17";
CustomDropdownCustomValueOptionRecord.init();
return CustomDropdownCustomValueOptionRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownCustomValueOptionRecord = CustomDropdownCustomValueOptionRecord;

});
define("ShopperPortalEU_UI_Components.model$SpacingRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$SpacingRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var SpacingRecordList = (function (_super) {
__extends(SpacingRecordList, _super);
function SpacingRecordList(defaults) {
_super.apply(this, arguments);
}
SpacingRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.SpacingRecord;
return SpacingRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.SpacingRecordList = SpacingRecordList;

});
define("ShopperPortalEU_UI_Components.model$UnescapedHTMLOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$UnescapedHTMLOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var UnescapedHTMLOptionsRecordList = (function (_super) {
__extends(UnescapedHTMLOptionsRecordList, _super);
function UnescapedHTMLOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
UnescapedHTMLOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.UnescapedHTMLOptionsRecord;
return UnescapedHTMLOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.UnescapedHTMLOptionsRecordList = UnescapedHTMLOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomTagOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomTagOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomTagOptionsRecord = (function (_super) {
__extends(CustomTagOptionsRecord, _super);
function CustomTagOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomTagOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomTagOptions", "customTagOptionsAttr", "CustomTagOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomTagOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomTagOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomTagOptionsRecord.fromStructure = function (str) {
return new CustomTagOptionsRecord(new CustomTagOptionsRecord.RecordClass({
customTagOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomTagOptionsRecord._isAnonymousRecord = true;
CustomTagOptionsRecord.UniqueId = "b93fabe1-2a5a-dd45-bc14-ca9eb0393b97";
CustomTagOptionsRecord.init();
return CustomTagOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomTagOptionsRecord = CustomTagOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$DatePickerLabelOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$DatePickerLabelOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var DatePickerLabelOptionsList = (function (_super) {
__extends(DatePickerLabelOptionsList, _super);
function DatePickerLabelOptionsList(defaults) {
_super.apply(this, arguments);
}
DatePickerLabelOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.DatePickerLabelOptionsRec;
return DatePickerLabelOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.DatePickerLabelOptionsList = DatePickerLabelOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CreditCardOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CreditCardOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CreditCardOptionsList = (function (_super) {
__extends(CreditCardOptionsList, _super);
function CreditCardOptionsList(defaults) {
_super.apply(this, arguments);
}
CreditCardOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CreditCardOptionsRec;
return CreditCardOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CreditCardOptionsList = CreditCardOptionsList;

});
define("ShopperPortalEU_UI_Components.model$FlexJustifyList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$FlexJustifyRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var FlexJustifyList = (function (_super) {
__extends(FlexJustifyList, _super);
function FlexJustifyList(defaults) {
_super.apply(this, arguments);
}
FlexJustifyList.itemType = ShopperPortalEU_UI_ComponentsModel.FlexJustifyRec;
return FlexJustifyList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.FlexJustifyList = FlexJustifyList;

});
define("ShopperPortalEU_UI_Components.model$CustomSeparatorLabelOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomSeparatorLabelOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomSeparatorLabelOptionsRecord = (function (_super) {
__extends(CustomSeparatorLabelOptionsRecord, _super);
function CustomSeparatorLabelOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomSeparatorLabelOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomSeparatorLabelOptions", "customSeparatorLabelOptionsAttr", "CustomSeparatorLabelOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomSeparatorLabelOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomSeparatorLabelOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomSeparatorLabelOptionsRecord.fromStructure = function (str) {
return new CustomSeparatorLabelOptionsRecord(new CustomSeparatorLabelOptionsRecord.RecordClass({
customSeparatorLabelOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomSeparatorLabelOptionsRecord._isAnonymousRecord = true;
CustomSeparatorLabelOptionsRecord.UniqueId = "c70bbeb2-8e00-5a88-ca09-3f44957cc933";
CustomSeparatorLabelOptionsRecord.init();
return CustomSeparatorLabelOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomSeparatorLabelOptionsRecord = CustomSeparatorLabelOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomSeparatorLabelOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomSeparatorLabelOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomSeparatorLabelOptionsRecordList = (function (_super) {
__extends(CustomSeparatorLabelOptionsRecordList, _super);
function CustomSeparatorLabelOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomSeparatorLabelOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomSeparatorLabelOptionsRecord;
return CustomSeparatorLabelOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomSeparatorLabelOptionsRecordList = CustomSeparatorLabelOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CircleIconSizeRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CircleIconSizeRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CircleIconSizeRecord = (function (_super) {
__extends(CircleIconSizeRecord, _super);
function CircleIconSizeRecord(defaults) {
_super.apply(this, arguments);
}
CircleIconSizeRecord.attributesToDeclare = function () {
return [
this.attr("CircleIconSize", "circleIconSizeAttr", "CircleIconSize", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CircleIconSizeRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CircleIconSizeRec)
].concat(_super.attributesToDeclare.call(this));
};
CircleIconSizeRecord.fromStructure = function (str) {
return new CircleIconSizeRecord(new CircleIconSizeRecord.RecordClass({
circleIconSizeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CircleIconSizeRecord._isAnonymousRecord = true;
CircleIconSizeRecord.UniqueId = "bddc3ada-0a86-0a35-3606-6f845feda09e";
CircleIconSizeRecord.init();
return CircleIconSizeRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CircleIconSizeRecord = CircleIconSizeRecord;

});
define("ShopperPortalEU_UI_Components.model$SpacingList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$SpacingRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var SpacingList = (function (_super) {
__extends(SpacingList, _super);
function SpacingList(defaults) {
_super.apply(this, arguments);
}
SpacingList.itemType = ShopperPortalEU_UI_ComponentsModel.SpacingRec;
return SpacingList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.SpacingList = SpacingList;

});
define("ShopperPortalEU_UI_Components.model$AvatarOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$AvatarOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var AvatarOptionsRecord = (function (_super) {
__extends(AvatarOptionsRecord, _super);
function AvatarOptionsRecord(defaults) {
_super.apply(this, arguments);
}
AvatarOptionsRecord.attributesToDeclare = function () {
return [
this.attr("AvatarOptions", "avatarOptionsAttr", "AvatarOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.AvatarOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.AvatarOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
AvatarOptionsRecord.fromStructure = function (str) {
return new AvatarOptionsRecord(new AvatarOptionsRecord.RecordClass({
avatarOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
AvatarOptionsRecord._isAnonymousRecord = true;
AvatarOptionsRecord.UniqueId = "f2104811-e735-d6e4-8802-0b6d192df54d";
AvatarOptionsRecord.init();
return AvatarOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.AvatarOptionsRecord = AvatarOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$AvatarOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$AvatarOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var AvatarOptionsRecordList = (function (_super) {
__extends(AvatarOptionsRecordList, _super);
function AvatarOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
AvatarOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.AvatarOptionsRecord;
return AvatarOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.AvatarOptionsRecordList = AvatarOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomTabsHeaderItemOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomTabsHeaderItemOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomTabsHeaderItemOptionsRecord = (function (_super) {
__extends(CustomTabsHeaderItemOptionsRecord, _super);
function CustomTabsHeaderItemOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomTabsHeaderItemOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomTabsHeaderItemOptions", "customTabsHeaderItemOptionsAttr", "CustomTabsHeaderItemOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomTabsHeaderItemOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomTabsHeaderItemOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomTabsHeaderItemOptionsRecord.fromStructure = function (str) {
return new CustomTabsHeaderItemOptionsRecord(new CustomTabsHeaderItemOptionsRecord.RecordClass({
customTabsHeaderItemOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomTabsHeaderItemOptionsRecord._isAnonymousRecord = true;
CustomTabsHeaderItemOptionsRecord.UniqueId = "ebf9e6c2-8020-0cb1-3be1-49a424de6fdb";
CustomTabsHeaderItemOptionsRecord.init();
return CustomTabsHeaderItemOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomTabsHeaderItemOptionsRecord = CustomTabsHeaderItemOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomTabsHeaderItemOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomTabsHeaderItemOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomTabsHeaderItemOptionsRecordList = (function (_super) {
__extends(CustomTabsHeaderItemOptionsRecordList, _super);
function CustomTabsHeaderItemOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomTabsHeaderItemOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomTabsHeaderItemOptionsRecord;
return CustomTabsHeaderItemOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomTabsHeaderItemOptionsRecordList = CustomTabsHeaderItemOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$FlexAlignRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$FlexAlignRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var FlexAlignRecordList = (function (_super) {
__extends(FlexAlignRecordList, _super);
function FlexAlignRecordList(defaults) {
_super.apply(this, arguments);
}
FlexAlignRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.FlexAlignRecord;
return FlexAlignRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.FlexAlignRecordList = FlexAlignRecordList;

});
define("ShopperPortalEU_UI_Components.model$CreditCardSwipeOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CreditCardSwipeOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CreditCardSwipeOptionsList = (function (_super) {
__extends(CreditCardSwipeOptionsList, _super);
function CreditCardSwipeOptionsList(defaults) {
_super.apply(this, arguments);
}
CreditCardSwipeOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CreditCardSwipeOptionsRec;
return CreditCardSwipeOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CreditCardSwipeOptionsList = CreditCardSwipeOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CreditCardSwipeOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CreditCardSwipeOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CreditCardSwipeOptionsRecord = (function (_super) {
__extends(CreditCardSwipeOptionsRecord, _super);
function CreditCardSwipeOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CreditCardSwipeOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CreditCardSwipeOptions", "creditCardSwipeOptionsAttr", "CreditCardSwipeOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CreditCardSwipeOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CreditCardSwipeOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CreditCardSwipeOptionsRecord.fromStructure = function (str) {
return new CreditCardSwipeOptionsRecord(new CreditCardSwipeOptionsRecord.RecordClass({
creditCardSwipeOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CreditCardSwipeOptionsRecord._isAnonymousRecord = true;
CreditCardSwipeOptionsRecord.UniqueId = "c0d3f1f3-edd6-58e3-3223-7b329f1b797c";
CreditCardSwipeOptionsRecord.init();
return CreditCardSwipeOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CreditCardSwipeOptionsRecord = CreditCardSwipeOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomAlertIconOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomAlertIconOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomAlertIconOptionsRecord = (function (_super) {
__extends(CustomAlertIconOptionsRecord, _super);
function CustomAlertIconOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomAlertIconOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomAlertIconOptions", "customAlertIconOptionsAttr", "CustomAlertIconOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomAlertIconOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomAlertIconOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomAlertIconOptionsRecord.fromStructure = function (str) {
return new CustomAlertIconOptionsRecord(new CustomAlertIconOptionsRecord.RecordClass({
customAlertIconOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomAlertIconOptionsRecord._isAnonymousRecord = true;
CustomAlertIconOptionsRecord.UniqueId = "ff317186-7d52-091d-6b49-f22c7fe7e4d2";
CustomAlertIconOptionsRecord.init();
return CustomAlertIconOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomAlertIconOptionsRecord = CustomAlertIconOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomAlertIconOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomAlertIconOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomAlertIconOptionsRecordList = (function (_super) {
__extends(CustomAlertIconOptionsRecordList, _super);
function CustomAlertIconOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomAlertIconOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomAlertIconOptionsRecord;
return CustomAlertIconOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomAlertIconOptionsRecordList = CustomAlertIconOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomListItemOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomListItemOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomListItemOptionsList = (function (_super) {
__extends(CustomListItemOptionsList, _super);
function CustomListItemOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomListItemOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomListItemOptionsRec;
return CustomListItemOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomListItemOptionsList = CustomListItemOptionsList;

});
define("ShopperPortalEU_UI_Components.model$GetOSRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$GetOSRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var GetOSRecordList = (function (_super) {
__extends(GetOSRecordList, _super);
function GetOSRecordList(defaults) {
_super.apply(this, arguments);
}
GetOSRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.GetOSRecord;
return GetOSRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.GetOSRecordList = GetOSRecordList;

});
define("ShopperPortalEU_UI_Components.model$MonthYearInputOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$MonthYearInputOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var MonthYearInputOptionsList = (function (_super) {
__extends(MonthYearInputOptionsList, _super);
function MonthYearInputOptionsList(defaults) {
_super.apply(this, arguments);
}
MonthYearInputOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.MonthYearInputOptionsRec;
return MonthYearInputOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.MonthYearInputOptionsList = MonthYearInputOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomColumnsOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomColumnsOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomColumnsOptionsList = (function (_super) {
__extends(CustomColumnsOptionsList, _super);
function CustomColumnsOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomColumnsOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomColumnsOptionsRec;
return CustomColumnsOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomColumnsOptionsList = CustomColumnsOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomCardOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomCardOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomCardOptionsRecordList = (function (_super) {
__extends(CustomCardOptionsRecordList, _super);
function CustomCardOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomCardOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomCardOptionsRecord;
return CustomCardOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomCardOptionsRecordList = CustomCardOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CodeInputStateRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CodeInputStateRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CodeInputStateRecordList = (function (_super) {
__extends(CodeInputStateRecordList, _super);
function CodeInputStateRecordList(defaults) {
_super.apply(this, arguments);
}
CodeInputStateRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CodeInputStateRecord;
return CodeInputStateRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CodeInputStateRecordList = CodeInputStateRecordList;

});
define("ShopperPortalEU_UI_Components.model$MonthYearInputValidationOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$MonthYearInputValidationOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var MonthYearInputValidationOptionsRecordList = (function (_super) {
__extends(MonthYearInputValidationOptionsRecordList, _super);
function MonthYearInputValidationOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
MonthYearInputValidationOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.MonthYearInputValidationOptionsRecord;
return MonthYearInputValidationOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.MonthYearInputValidationOptionsRecordList = MonthYearInputValidationOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomIconSizeList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomIconSizeRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomIconSizeList = (function (_super) {
__extends(CustomIconSizeList, _super);
function CustomIconSizeList(defaults) {
_super.apply(this, arguments);
}
CustomIconSizeList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomIconSizeRec;
return CustomIconSizeList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomIconSizeList = CustomIconSizeList;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomDropdownOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownOptionsRecordList = (function (_super) {
__extends(CustomDropdownOptionsRecordList, _super);
function CustomDropdownOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomDropdownOptionsRecord;
return CustomDropdownOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownOptionsRecordList = CustomDropdownOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$StateBadgeTypeRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$StateBadgeTypeRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var StateBadgeTypeRecord = (function (_super) {
__extends(StateBadgeTypeRecord, _super);
function StateBadgeTypeRecord(defaults) {
_super.apply(this, arguments);
}
StateBadgeTypeRecord.attributesToDeclare = function () {
return [
this.attr("StateBadgeType", "stateBadgeTypeAttr", "StateBadgeType", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.StateBadgeTypeRec());
}, true, ShopperPortalEU_UI_ComponentsModel.StateBadgeTypeRec)
].concat(_super.attributesToDeclare.call(this));
};
StateBadgeTypeRecord.fromStructure = function (str) {
return new StateBadgeTypeRecord(new StateBadgeTypeRecord.RecordClass({
stateBadgeTypeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
StateBadgeTypeRecord._isAnonymousRecord = true;
StateBadgeTypeRecord.UniqueId = "ce3c9445-bc8f-c1f9-5ba1-0608bbd5068c";
StateBadgeTypeRecord.init();
return StateBadgeTypeRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.StateBadgeTypeRecord = StateBadgeTypeRecord;

});
define("ShopperPortalEU_UI_Components.model$DatePickerOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$DatePickerOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var DatePickerOptionsList = (function (_super) {
__extends(DatePickerOptionsList, _super);
function DatePickerOptionsList(defaults) {
_super.apply(this, arguments);
}
DatePickerOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.DatePickerOptionsRec;
return DatePickerOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.DatePickerOptionsList = DatePickerOptionsList;

});
define("ShopperPortalEU_UI_Components.model$AlignRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$AlignRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var AlignRecordList = (function (_super) {
__extends(AlignRecordList, _super);
function AlignRecordList(defaults) {
_super.apply(this, arguments);
}
AlignRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.AlignRecord;
return AlignRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.AlignRecordList = AlignRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomRadioButtonStateRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomRadioButtonStateRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomRadioButtonStateRecordList = (function (_super) {
__extends(CustomRadioButtonStateRecordList, _super);
function CustomRadioButtonStateRecordList(defaults) {
_super.apply(this, arguments);
}
CustomRadioButtonStateRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomRadioButtonStateRecord;
return CustomRadioButtonStateRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomRadioButtonStateRecordList = CustomRadioButtonStateRecordList;

});
define("ShopperPortalEU_UI_Components.model$PhoneNumberInputOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$PhoneNumberInputOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var PhoneNumberInputOptionsRecord = (function (_super) {
__extends(PhoneNumberInputOptionsRecord, _super);
function PhoneNumberInputOptionsRecord(defaults) {
_super.apply(this, arguments);
}
PhoneNumberInputOptionsRecord.attributesToDeclare = function () {
return [
this.attr("PhoneNumberInputOptions", "phoneNumberInputOptionsAttr", "PhoneNumberInputOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
PhoneNumberInputOptionsRecord.fromStructure = function (str) {
return new PhoneNumberInputOptionsRecord(new PhoneNumberInputOptionsRecord.RecordClass({
phoneNumberInputOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
PhoneNumberInputOptionsRecord._isAnonymousRecord = true;
PhoneNumberInputOptionsRecord.UniqueId = "cf47b8ae-2d86-70b4-8e58-e2af18b79a46";
PhoneNumberInputOptionsRecord.init();
return PhoneNumberInputOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputOptionsRecord = PhoneNumberInputOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomInputAlignmentRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomInputAlignmentRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomInputAlignmentRecord = (function (_super) {
__extends(CustomInputAlignmentRecord, _super);
function CustomInputAlignmentRecord(defaults) {
_super.apply(this, arguments);
}
CustomInputAlignmentRecord.attributesToDeclare = function () {
return [
this.attr("CustomInputAlignment", "customInputAlignmentAttr", "CustomInputAlignment", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomInputAlignmentRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomInputAlignmentRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomInputAlignmentRecord.fromStructure = function (str) {
return new CustomInputAlignmentRecord(new CustomInputAlignmentRecord.RecordClass({
customInputAlignmentAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomInputAlignmentRecord._isAnonymousRecord = true;
CustomInputAlignmentRecord.UniqueId = "cf759aae-280c-38f3-fd8c-f441c9cbd57b";
CustomInputAlignmentRecord.init();
return CustomInputAlignmentRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomInputAlignmentRecord = CustomInputAlignmentRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomOpacityOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomOpacityOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomOpacityOptionsRecord = (function (_super) {
__extends(CustomOpacityOptionsRecord, _super);
function CustomOpacityOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomOpacityOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomOpacityOptions", "customOpacityOptionsAttr", "CustomOpacityOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomOpacityOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomOpacityOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomOpacityOptionsRecord.fromStructure = function (str) {
return new CustomOpacityOptionsRecord(new CustomOpacityOptionsRecord.RecordClass({
customOpacityOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomOpacityOptionsRecord._isAnonymousRecord = true;
CustomOpacityOptionsRecord.UniqueId = "dd31c204-8f3a-0cca-e32b-f0c9aff8536d";
CustomOpacityOptionsRecord.init();
return CustomOpacityOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomOpacityOptionsRecord = CustomOpacityOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomOpacityOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomOpacityOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomOpacityOptionsRecordList = (function (_super) {
__extends(CustomOpacityOptionsRecordList, _super);
function CustomOpacityOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomOpacityOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomOpacityOptionsRecord;
return CustomOpacityOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomOpacityOptionsRecordList = CustomOpacityOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomAlertOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomAlertOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomAlertOptionsRecord = (function (_super) {
__extends(CustomAlertOptionsRecord, _super);
function CustomAlertOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomAlertOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomAlertOptions", "customAlertOptionsAttr", "CustomAlertOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomAlertOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomAlertOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomAlertOptionsRecord.fromStructure = function (str) {
return new CustomAlertOptionsRecord(new CustomAlertOptionsRecord.RecordClass({
customAlertOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomAlertOptionsRecord._isAnonymousRecord = true;
CustomAlertOptionsRecord.UniqueId = "f79064ce-5d85-efc7-46d7-684bfd60db7a";
CustomAlertOptionsRecord.init();
return CustomAlertOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomAlertOptionsRecord = CustomAlertOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomAlertOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomAlertOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomAlertOptionsRecordList = (function (_super) {
__extends(CustomAlertOptionsRecordList, _super);
function CustomAlertOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomAlertOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomAlertOptionsRecord;
return CustomAlertOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomAlertOptionsRecordList = CustomAlertOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomTimelineOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomTimelineOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomTimelineOptionsList = (function (_super) {
__extends(CustomTimelineOptionsList, _super);
function CustomTimelineOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomTimelineOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomTimelineOptionsRec;
return CustomTimelineOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomTimelineOptionsList = CustomTimelineOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownListSearchOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomDropdownListSearchOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownListSearchOptionsList = (function (_super) {
__extends(CustomDropdownListSearchOptionsList, _super);
function CustomDropdownListSearchOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownListSearchOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomDropdownListSearchOptionsRec;
return CustomDropdownListSearchOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownListSearchOptionsList = CustomDropdownListSearchOptionsList;

});
define("ShopperPortalEU_UI_Components.model$StateBadgeOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$StateBadgeOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var StateBadgeOptionsList = (function (_super) {
__extends(StateBadgeOptionsList, _super);
function StateBadgeOptionsList(defaults) {
_super.apply(this, arguments);
}
StateBadgeOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.StateBadgeOptionsRec;
return StateBadgeOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.StateBadgeOptionsList = StateBadgeOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomLinkOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomLinkOptionsRecord = (function (_super) {
__extends(CustomLinkOptionsRecord, _super);
function CustomLinkOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomLinkOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomLinkOptions", "customLinkOptionsAttr", "CustomLinkOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomLinkOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomLinkOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomLinkOptionsRecord.fromStructure = function (str) {
return new CustomLinkOptionsRecord(new CustomLinkOptionsRecord.RecordClass({
customLinkOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomLinkOptionsRecord._isAnonymousRecord = true;
CustomLinkOptionsRecord.UniqueId = "d2597cc5-d0b0-a559-c0a6-089a78c28a11";
CustomLinkOptionsRecord.init();
return CustomLinkOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ComponentsModel.CustomLinkOptionsRecord = CustomLinkOptionsRecord;

});
define("ShopperPortalEU_UI_Components.model$CustomInputAlignmentRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomInputAlignmentRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomInputAlignmentRecordList = (function (_super) {
__extends(CustomInputAlignmentRecordList, _super);
function CustomInputAlignmentRecordList(defaults) {
_super.apply(this, arguments);
}
CustomInputAlignmentRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomInputAlignmentRecord;
return CustomInputAlignmentRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomInputAlignmentRecordList = CustomInputAlignmentRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownListValueOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomDropdownListValueOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownListValueOptionsRecordList = (function (_super) {
__extends(CustomDropdownListValueOptionsRecordList, _super);
function CustomDropdownListValueOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownListValueOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValueOptionsRecord;
return CustomDropdownListValueOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValueOptionsRecordList = CustomDropdownListValueOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomPopupLayoutOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomPopupLayoutOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomPopupLayoutOptionsRecordList = (function (_super) {
__extends(CustomPopupLayoutOptionsRecordList, _super);
function CustomPopupLayoutOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomPopupLayoutOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomPopupLayoutOptionsRecord;
return CustomPopupLayoutOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomPopupLayoutOptionsRecordList = CustomPopupLayoutOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomColumnsOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomColumnsOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomColumnsOptionsRecordList = (function (_super) {
__extends(CustomColumnsOptionsRecordList, _super);
function CustomColumnsOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomColumnsOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomColumnsOptionsRecord;
return CustomColumnsOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomColumnsOptionsRecordList = CustomColumnsOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$StateBadgeTypeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$StateBadgeTypeRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var StateBadgeTypeRecordList = (function (_super) {
__extends(StateBadgeTypeRecordList, _super);
function StateBadgeTypeRecordList(defaults) {
_super.apply(this, arguments);
}
StateBadgeTypeRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.StateBadgeTypeRecord;
return StateBadgeTypeRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.StateBadgeTypeRecordList = StateBadgeTypeRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomColumnsItemOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomColumnsItemOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomColumnsItemOptionsRecordList = (function (_super) {
__extends(CustomColumnsItemOptionsRecordList, _super);
function CustomColumnsItemOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomColumnsItemOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomColumnsItemOptionsRecord;
return CustomColumnsItemOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomColumnsItemOptionsRecordList = CustomColumnsItemOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomButtonGroupOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomButtonGroupOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomButtonGroupOptionsList = (function (_super) {
__extends(CustomButtonGroupOptionsList, _super);
function CustomButtonGroupOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomButtonGroupOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomButtonGroupOptionsRec;
return CustomButtonGroupOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomButtonGroupOptionsList = CustomButtonGroupOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomSVGOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomSVGOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomSVGOptionsList = (function (_super) {
__extends(CustomSVGOptionsList, _super);
function CustomSVGOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomSVGOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomSVGOptionsRec;
return CustomSVGOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomSVGOptionsList = CustomSVGOptionsList;

});
define("ShopperPortalEU_UI_Components.model$FullHeightContentOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$FullHeightContentOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var FullHeightContentOptionsList = (function (_super) {
__extends(FullHeightContentOptionsList, _super);
function FullHeightContentOptionsList(defaults) {
_super.apply(this, arguments);
}
FullHeightContentOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.FullHeightContentOptionsRec;
return FullHeightContentOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.FullHeightContentOptionsList = FullHeightContentOptionsList;

});
define("ShopperPortalEU_UI_Components.model$TextBreakOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$TextBreakOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var TextBreakOptionsList = (function (_super) {
__extends(TextBreakOptionsList, _super);
function TextBreakOptionsList(defaults) {
_super.apply(this, arguments);
}
TextBreakOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.TextBreakOptionsRec;
return TextBreakOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.TextBreakOptionsList = TextBreakOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CircleIconIconOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CircleIconIconOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CircleIconIconOptionsRecordList = (function (_super) {
__extends(CircleIconIconOptionsRecordList, _super);
function CircleIconIconOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CircleIconIconOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CircleIconIconOptionsRecord;
return CircleIconIconOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CircleIconIconOptionsRecordList = CircleIconIconOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$ScanBarcodeDataRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$ScanBarcodeDataRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var ScanBarcodeDataRecordList = (function (_super) {
__extends(ScanBarcodeDataRecordList, _super);
function ScanBarcodeDataRecordList(defaults) {
_super.apply(this, arguments);
}
ScanBarcodeDataRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.ScanBarcodeDataRecord;
return ScanBarcodeDataRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.ScanBarcodeDataRecordList = ScanBarcodeDataRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomFormOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomFormOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomFormOptionsList = (function (_super) {
__extends(CustomFormOptionsList, _super);
function CustomFormOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomFormOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomFormOptionsRec;
return CustomFormOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomFormOptionsList = CustomFormOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomInputAlignmentList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomInputAlignmentRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomInputAlignmentList = (function (_super) {
__extends(CustomInputAlignmentList, _super);
function CustomInputAlignmentList(defaults) {
_super.apply(this, arguments);
}
CustomInputAlignmentList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomInputAlignmentRec;
return CustomInputAlignmentList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomInputAlignmentList = CustomInputAlignmentList;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownCustomValueOptionRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomDropdownCustomValueOptionRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownCustomValueOptionRecordList = (function (_super) {
__extends(CustomDropdownCustomValueOptionRecordList, _super);
function CustomDropdownCustomValueOptionRecordList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownCustomValueOptionRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomDropdownCustomValueOptionRecord;
return CustomDropdownCustomValueOptionRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownCustomValueOptionRecordList = CustomDropdownCustomValueOptionRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomTagOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomTagOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomTagOptionsRecordList = (function (_super) {
__extends(CustomTagOptionsRecordList, _super);
function CustomTagOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomTagOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomTagOptionsRecord;
return CustomTagOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomTagOptionsRecordList = CustomTagOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$MonthYearInputChangeOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$MonthYearInputChangeOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var MonthYearInputChangeOptionsList = (function (_super) {
__extends(MonthYearInputChangeOptionsList, _super);
function MonthYearInputChangeOptionsList(defaults) {
_super.apply(this, arguments);
}
MonthYearInputChangeOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.MonthYearInputChangeOptionsRec;
return MonthYearInputChangeOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.MonthYearInputChangeOptionsList = MonthYearInputChangeOptionsList;

});
define("ShopperPortalEU_UI_Components.model$FullHeightContentBottomOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$FullHeightContentBottomOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var FullHeightContentBottomOptionsList = (function (_super) {
__extends(FullHeightContentBottomOptionsList, _super);
function FullHeightContentBottomOptionsList(defaults) {
_super.apply(this, arguments);
}
FullHeightContentBottomOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.FullHeightContentBottomOptionsRec;
return FullHeightContentBottomOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.FullHeightContentBottomOptionsList = FullHeightContentBottomOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomBlankSlateIconOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomBlankSlateIconOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomBlankSlateIconOptionsRecordList = (function (_super) {
__extends(CustomBlankSlateIconOptionsRecordList, _super);
function CustomBlankSlateIconOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomBlankSlateIconOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomBlankSlateIconOptionsRecord;
return CustomBlankSlateIconOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomBlankSlateIconOptionsRecordList = CustomBlankSlateIconOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomSwitchOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomSwitchOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomSwitchOptionsRecordList = (function (_super) {
__extends(CustomSwitchOptionsRecordList, _super);
function CustomSwitchOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomSwitchOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomSwitchOptionsRecord;
return CustomSwitchOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomSwitchOptionsRecordList = CustomSwitchOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomUploadOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomUploadOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomUploadOptionsRecordList = (function (_super) {
__extends(CustomUploadOptionsRecordList, _super);
function CustomUploadOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomUploadOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomUploadOptionsRecord;
return CustomUploadOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomUploadOptionsRecordList = CustomUploadOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomLinkOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomLinkOptionsRecordList = (function (_super) {
__extends(CustomLinkOptionsRecordList, _super);
function CustomLinkOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomLinkOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomLinkOptionsRecord;
return CustomLinkOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomLinkOptionsRecordList = CustomLinkOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$ButtonOptionOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$ButtonOptionOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var ButtonOptionOptionsRecordList = (function (_super) {
__extends(ButtonOptionOptionsRecordList, _super);
function ButtonOptionOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
ButtonOptionOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.ButtonOptionOptionsRecord;
return ButtonOptionOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.ButtonOptionOptionsRecordList = ButtonOptionOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomBlankSlateOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomBlankSlateOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomBlankSlateOptionsRecordList = (function (_super) {
__extends(CustomBlankSlateOptionsRecordList, _super);
function CustomBlankSlateOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomBlankSlateOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomBlankSlateOptionsRecord;
return CustomBlankSlateOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomBlankSlateOptionsRecordList = CustomBlankSlateOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$GetOSOptionList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$GetOSOptionRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var GetOSOptionList = (function (_super) {
__extends(GetOSOptionList, _super);
function GetOSOptionList(defaults) {
_super.apply(this, arguments);
}
GetOSOptionList.itemType = ShopperPortalEU_UI_ComponentsModel.GetOSOptionRec;
return GetOSOptionList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.GetOSOptionList = GetOSOptionList;

});
define("ShopperPortalEU_UI_Components.model$FlexJustifyRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$FlexJustifyRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var FlexJustifyRecordList = (function (_super) {
__extends(FlexJustifyRecordList, _super);
function FlexJustifyRecordList(defaults) {
_super.apply(this, arguments);
}
FlexJustifyRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.FlexJustifyRecord;
return FlexJustifyRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.FlexJustifyRecordList = FlexJustifyRecordList;

});
define("ShopperPortalEU_UI_Components.model$ScanBarcodePropertiesList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$ScanBarcodePropertiesRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var ScanBarcodePropertiesList = (function (_super) {
__extends(ScanBarcodePropertiesList, _super);
function ScanBarcodePropertiesList(defaults) {
_super.apply(this, arguments);
}
ScanBarcodePropertiesList.itemType = ShopperPortalEU_UI_ComponentsModel.ScanBarcodePropertiesRec;
return ScanBarcodePropertiesList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.ScanBarcodePropertiesList = ScanBarcodePropertiesList;

});
define("ShopperPortalEU_UI_Components.model$GetOSList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$GetOSRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var GetOSList = (function (_super) {
__extends(GetOSList, _super);
function GetOSList(defaults) {
_super.apply(this, arguments);
}
GetOSList.itemType = ShopperPortalEU_UI_ComponentsModel.GetOSRec;
return GetOSList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.GetOSList = GetOSList;

});
define("ShopperPortalEU_UI_Components.model$CardExpandableOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CardExpandableOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CardExpandableOptionsList = (function (_super) {
__extends(CardExpandableOptionsList, _super);
function CardExpandableOptionsList(defaults) {
_super.apply(this, arguments);
}
CardExpandableOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CardExpandableOptionsRec;
return CardExpandableOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CardExpandableOptionsList = CardExpandableOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomRadioButtonOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomRadioButtonOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomRadioButtonOptionsList = (function (_super) {
__extends(CustomRadioButtonOptionsList, _super);
function CustomRadioButtonOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomRadioButtonOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomRadioButtonOptionsRec;
return CustomRadioButtonOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomRadioButtonOptionsList = CustomRadioButtonOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomOpacityOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomOpacityOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomOpacityOptionsList = (function (_super) {
__extends(CustomOpacityOptionsList, _super);
function CustomOpacityOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomOpacityOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomOpacityOptionsRec;
return CustomOpacityOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomOpacityOptionsList = CustomOpacityOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomButtonTypeList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomButtonTypeRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomButtonTypeList = (function (_super) {
__extends(CustomButtonTypeList, _super);
function CustomButtonTypeList(defaults) {
_super.apply(this, arguments);
}
CustomButtonTypeList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomButtonTypeRec;
return CustomButtonTypeList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomButtonTypeList = CustomButtonTypeList;

});
define("ShopperPortalEU_UI_Components.model$BottomDrawerRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$BottomDrawerRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var BottomDrawerRecordList = (function (_super) {
__extends(BottomDrawerRecordList, _super);
function BottomDrawerRecordList(defaults) {
_super.apply(this, arguments);
}
BottomDrawerRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.BottomDrawerRecord;
return BottomDrawerRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.BottomDrawerRecordList = BottomDrawerRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomTimelineTypeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomTimelineTypeRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomTimelineTypeRecordList = (function (_super) {
__extends(CustomTimelineTypeRecordList, _super);
function CustomTimelineTypeRecordList(defaults) {
_super.apply(this, arguments);
}
CustomTimelineTypeRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomTimelineTypeRecord;
return CustomTimelineTypeRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomTimelineTypeRecordList = CustomTimelineTypeRecordList;

});
define("ShopperPortalEU_UI_Components.model$GetOSBrowserOptionRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$GetOSBrowserOptionRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var GetOSBrowserOptionRecordList = (function (_super) {
__extends(GetOSBrowserOptionRecordList, _super);
function GetOSBrowserOptionRecordList(defaults) {
_super.apply(this, arguments);
}
GetOSBrowserOptionRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.GetOSBrowserOptionRecord;
return GetOSBrowserOptionRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.GetOSBrowserOptionRecordList = GetOSBrowserOptionRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomButtonOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomButtonOptionsList = (function (_super) {
__extends(CustomButtonOptionsList, _super);
function CustomButtonOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomButtonOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRec;
return CustomButtonOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsList = CustomButtonOptionsList;

});
define("ShopperPortalEU_UI_Components.model$PhoneNumberInputSearchOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$PhoneNumberInputSearchOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var PhoneNumberInputSearchOptionsRecordList = (function (_super) {
__extends(PhoneNumberInputSearchOptionsRecordList, _super);
function PhoneNumberInputSearchOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
PhoneNumberInputSearchOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputSearchOptionsRecord;
return PhoneNumberInputSearchOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputSearchOptionsRecordList = PhoneNumberInputSearchOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomSeparatorStateRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomSeparatorStateRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomSeparatorStateRecordList = (function (_super) {
__extends(CustomSeparatorStateRecordList, _super);
function CustomSeparatorStateRecordList(defaults) {
_super.apply(this, arguments);
}
CustomSeparatorStateRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomSeparatorStateRecord;
return CustomSeparatorStateRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomSeparatorStateRecordList = CustomSeparatorStateRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomLinkOptionsIconList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsIconRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomLinkOptionsIconList = (function (_super) {
__extends(CustomLinkOptionsIconList, _super);
function CustomLinkOptionsIconList(defaults) {
_super.apply(this, arguments);
}
CustomLinkOptionsIconList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomLinkOptionsIconRec;
return CustomLinkOptionsIconList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomLinkOptionsIconList = CustomLinkOptionsIconList;

});
define("ShopperPortalEU_UI_Components.model$UnescapedHTMLOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$UnescapedHTMLOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var UnescapedHTMLOptionsList = (function (_super) {
__extends(UnescapedHTMLOptionsList, _super);
function UnescapedHTMLOptionsList(defaults) {
_super.apply(this, arguments);
}
UnescapedHTMLOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.UnescapedHTMLOptionsRec;
return UnescapedHTMLOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.UnescapedHTMLOptionsList = UnescapedHTMLOptionsList;

});
define("ShopperPortalEU_UI_Components.model$DatePickerOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$DatePickerOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var DatePickerOptionsRecordList = (function (_super) {
__extends(DatePickerOptionsRecordList, _super);
function DatePickerOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
DatePickerOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.DatePickerOptionsRecord;
return DatePickerOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.DatePickerOptionsRecordList = DatePickerOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CreditCardSwipeOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CreditCardSwipeOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CreditCardSwipeOptionsRecordList = (function (_super) {
__extends(CreditCardSwipeOptionsRecordList, _super);
function CreditCardSwipeOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CreditCardSwipeOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CreditCardSwipeOptionsRecord;
return CreditCardSwipeOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CreditCardSwipeOptionsRecordList = CreditCardSwipeOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CircleIconSizeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CircleIconSizeRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CircleIconSizeRecordList = (function (_super) {
__extends(CircleIconSizeRecordList, _super);
function CircleIconSizeRecordList(defaults) {
_super.apply(this, arguments);
}
CircleIconSizeRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CircleIconSizeRecord;
return CircleIconSizeRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CircleIconSizeRecordList = CircleIconSizeRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomLinkStateRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomLinkStateRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomLinkStateRecordList = (function (_super) {
__extends(CustomLinkStateRecordList, _super);
function CustomLinkStateRecordList(defaults) {
_super.apply(this, arguments);
}
CustomLinkStateRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomLinkStateRecord;
return CustomLinkStateRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomLinkStateRecordList = CustomLinkStateRecordList;

});
define("ShopperPortalEU_UI_Components.model$LabelValueOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$LabelValueOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var LabelValueOptionsList = (function (_super) {
__extends(LabelValueOptionsList, _super);
function LabelValueOptionsList(defaults) {
_super.apply(this, arguments);
}
LabelValueOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.LabelValueOptionsRec;
return LabelValueOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.LabelValueOptionsList = LabelValueOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomRadioGroupOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomRadioGroupOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomRadioGroupOptionsList = (function (_super) {
__extends(CustomRadioGroupOptionsList, _super);
function CustomRadioGroupOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomRadioGroupOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomRadioGroupOptionsRec;
return CustomRadioGroupOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomRadioGroupOptionsList = CustomRadioGroupOptionsList;

});
define("ShopperPortalEU_UI_Components.model$FlexAlignList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$FlexAlignRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var FlexAlignList = (function (_super) {
__extends(FlexAlignList, _super);
function FlexAlignList(defaults) {
_super.apply(this, arguments);
}
FlexAlignList.itemType = ShopperPortalEU_UI_ComponentsModel.FlexAlignRec;
return FlexAlignList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.FlexAlignList = FlexAlignList;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownAlignmentList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomDropdownAlignmentRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownAlignmentList = (function (_super) {
__extends(CustomDropdownAlignmentList, _super);
function CustomDropdownAlignmentList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownAlignmentList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomDropdownAlignmentRec;
return CustomDropdownAlignmentList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownAlignmentList = CustomDropdownAlignmentList;

});
define("ShopperPortalEU_UI_Components.model$BarcodeOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$BarcodeOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var BarcodeOptionsList = (function (_super) {
__extends(BarcodeOptionsList, _super);
function BarcodeOptionsList(defaults) {
_super.apply(this, arguments);
}
BarcodeOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.BarcodeOptionsRec;
return BarcodeOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.BarcodeOptionsList = BarcodeOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomSwitchStateRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomSwitchStateRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomSwitchStateRecordList = (function (_super) {
__extends(CustomSwitchStateRecordList, _super);
function CustomSwitchStateRecordList(defaults) {
_super.apply(this, arguments);
}
CustomSwitchStateRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomSwitchStateRecord;
return CustomSwitchStateRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomSwitchStateRecordList = CustomSwitchStateRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomColumnsItemOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomColumnsItemOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomColumnsItemOptionsList = (function (_super) {
__extends(CustomColumnsItemOptionsList, _super);
function CustomColumnsItemOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomColumnsItemOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomColumnsItemOptionsRec;
return CustomColumnsItemOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomColumnsItemOptionsList = CustomColumnsItemOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomDropdownListValueOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomDropdownListValueOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomDropdownListValueOptionsList = (function (_super) {
__extends(CustomDropdownListValueOptionsList, _super);
function CustomDropdownListValueOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownListValueOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValueOptionsRec;
return CustomDropdownListValueOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValueOptionsList = CustomDropdownListValueOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomButtonIconAlignmentRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomButtonIconAlignmentRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomButtonIconAlignmentRecordList = (function (_super) {
__extends(CustomButtonIconAlignmentRecordList, _super);
function CustomButtonIconAlignmentRecordList(defaults) {
_super.apply(this, arguments);
}
CustomButtonIconAlignmentRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomButtonIconAlignmentRecord;
return CustomButtonIconAlignmentRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomButtonIconAlignmentRecordList = CustomButtonIconAlignmentRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomButtonIconAlignmentList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomButtonIconAlignmentRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomButtonIconAlignmentList = (function (_super) {
__extends(CustomButtonIconAlignmentList, _super);
function CustomButtonIconAlignmentList(defaults) {
_super.apply(this, arguments);
}
CustomButtonIconAlignmentList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomButtonIconAlignmentRec;
return CustomButtonIconAlignmentList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomButtonIconAlignmentList = CustomButtonIconAlignmentList;

});
define("ShopperPortalEU_UI_Components.model$ScanPassportPropertiesList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$ScanPassportPropertiesRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var ScanPassportPropertiesList = (function (_super) {
__extends(ScanPassportPropertiesList, _super);
function ScanPassportPropertiesList(defaults) {
_super.apply(this, arguments);
}
ScanPassportPropertiesList.itemType = ShopperPortalEU_UI_ComponentsModel.ScanPassportPropertiesRec;
return ScanPassportPropertiesList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.ScanPassportPropertiesList = ScanPassportPropertiesList;

});
define("ShopperPortalEU_UI_Components.model$CustomImageOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomImageOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomImageOptionsRecordList = (function (_super) {
__extends(CustomImageOptionsRecordList, _super);
function CustomImageOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomImageOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomImageOptionsRecord;
return CustomImageOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomImageOptionsRecordList = CustomImageOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$FlexOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$FlexOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var FlexOptionsRecordList = (function (_super) {
__extends(FlexOptionsRecordList, _super);
function FlexOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
FlexOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.FlexOptionsRecord;
return FlexOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.FlexOptionsRecordList = FlexOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CodeInputValidationOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CodeInputValidationOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CodeInputValidationOptionsList = (function (_super) {
__extends(CodeInputValidationOptionsList, _super);
function CodeInputValidationOptionsList(defaults) {
_super.apply(this, arguments);
}
CodeInputValidationOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CodeInputValidationOptionsRec;
return CodeInputValidationOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CodeInputValidationOptionsList = CodeInputValidationOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomPopupLayoutOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomPopupLayoutOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomPopupLayoutOptionsList = (function (_super) {
__extends(CustomPopupLayoutOptionsList, _super);
function CustomPopupLayoutOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomPopupLayoutOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomPopupLayoutOptionsRec;
return CustomPopupLayoutOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomPopupLayoutOptionsList = CustomPopupLayoutOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomInputMaskOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomInputMaskOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomInputMaskOptionsList = (function (_super) {
__extends(CustomInputMaskOptionsList, _super);
function CustomInputMaskOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomInputMaskOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomInputMaskOptionsRec;
return CustomInputMaskOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomInputMaskOptionsList = CustomInputMaskOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomTextAreaValidationOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomTextAreaValidationOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomTextAreaValidationOptionsRecordList = (function (_super) {
__extends(CustomTextAreaValidationOptionsRecordList, _super);
function CustomTextAreaValidationOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomTextAreaValidationOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomTextAreaValidationOptionsRecord;
return CustomTextAreaValidationOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomTextAreaValidationOptionsRecordList = CustomTextAreaValidationOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomSeparatorStateList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomSeparatorStateRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomSeparatorStateList = (function (_super) {
__extends(CustomSeparatorStateList, _super);
function CustomSeparatorStateList(defaults) {
_super.apply(this, arguments);
}
CustomSeparatorStateList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomSeparatorStateRec;
return CustomSeparatorStateList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomSeparatorStateList = CustomSeparatorStateList;

});
define("ShopperPortalEU_UI_Components.model$PhoneNumberInputOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$PhoneNumberInputOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var PhoneNumberInputOptionsRecordList = (function (_super) {
__extends(PhoneNumberInputOptionsRecordList, _super);
function PhoneNumberInputOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
PhoneNumberInputOptionsRecordList.itemType = ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputOptionsRecord;
return PhoneNumberInputOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputOptionsRecordList = PhoneNumberInputOptionsRecordList;

});
define("ShopperPortalEU_UI_Components.model$CustomTextAreaValidationOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomTextAreaValidationOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomTextAreaValidationOptionsList = (function (_super) {
__extends(CustomTextAreaValidationOptionsList, _super);
function CustomTextAreaValidationOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomTextAreaValidationOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomTextAreaValidationOptionsRec;
return CustomTextAreaValidationOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomTextAreaValidationOptionsList = CustomTextAreaValidationOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomValidationMessageOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomValidationMessageOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomValidationMessageOptionsList = (function (_super) {
__extends(CustomValidationMessageOptionsList, _super);
function CustomValidationMessageOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomValidationMessageOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomValidationMessageOptionsRec;
return CustomValidationMessageOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomValidationMessageOptionsList = CustomValidationMessageOptionsList;

});
define("ShopperPortalEU_UI_Components.model$CustomIconOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$CustomIconOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;
var CustomIconOptionsList = (function (_super) {
__extends(CustomIconOptionsList, _super);
function CustomIconOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomIconOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomIconOptionsRec;
return CustomIconOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ComponentsModel.CustomIconOptionsList = CustomIconOptionsList;

});
define("ShopperPortalEU_UI_Components.model", ["exports", "OutSystems/ClientRuntime/Main"], function (exports, OutSystems) {
var OS = OutSystems.Internal;
var ShopperPortalEU_UI_ComponentsModel = exports;
Object.defineProperty(ShopperPortalEU_UI_ComponentsModel, "module", {
get: function () {
return OS.ApplicationInfo.getModules()["e7bb7e26-af64-4f69-9436-0768d54ea01b"];
}
});

ShopperPortalEU_UI_ComponentsModel.staticEntities = {};
ShopperPortalEU_UI_ComponentsModel.staticEntities.customDropdownAlignment = {};
var getCustomDropdownAlignmentRecord = function (record) {
return ShopperPortalEU_UI_ComponentsModel.module.staticEntities["06db5a1c-2062-4058-9b24-167b0cc23707"][record];
};
Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customDropdownAlignment, "left", {
get: function () {
return getCustomDropdownAlignmentRecord("168e6ea2-1207-497a-9d7a-065362633320");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customDropdownAlignment, "center", {
get: function () {
return getCustomDropdownAlignmentRecord("1f041bcf-b5c4-4a42-bdd8-3814da278d43");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customDropdownAlignment, "right", {
get: function () {
return getCustomDropdownAlignmentRecord("bb21fb6c-e3cc-4ced-8b74-85256d4f3ee3");
}
});

ShopperPortalEU_UI_ComponentsModel.staticEntities.buttonOptionType = {};
var getButtonOptionTypeRecord = function (record) {
return ShopperPortalEU_UI_ComponentsModel.module.staticEntities["074e8fc5-fa13-490d-9756-8bb73ee48de9"][record];
};
Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.buttonOptionType, "primary", {
get: function () {
return getButtonOptionTypeRecord("4a8509ed-5392-4b03-90d0-f5df2c656ef3");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.buttonOptionType, "secondary", {
get: function () {
return getButtonOptionTypeRecord("7701f568-2004-419d-98dc-dff38949ce12");
}
});

ShopperPortalEU_UI_ComponentsModel.staticEntities.customTagState = {};
var getCustomTagStateRecord = function (record) {
return ShopperPortalEU_UI_ComponentsModel.module.staticEntities["0ecb397c-3ce5-471f-b18f-87158598df3a"][record];
};
Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customTagState, "error", {
get: function () {
return getCustomTagStateRecord("04940de8-397c-4994-96fc-567cc3bb20b1");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customTagState, "new", {
get: function () {
return getCustomTagStateRecord("2155d0da-5bf6-4aa3-93ff-4b1503152d74");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customTagState, "success", {
get: function () {
return getCustomTagStateRecord("3ee16a50-b2ad-406b-957c-64848a014a00");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customTagState, "neutral", {
get: function () {
return getCustomTagStateRecord("c0f27e66-d8bf-42e4-9a1a-3513dce3a21d");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customTagState, "info", {
get: function () {
return getCustomTagStateRecord("c0f66ae5-a24d-4d28-ad01-728a7a41fea0");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customTagState, "warning", {
get: function () {
return getCustomTagStateRecord("ccc52884-abd4-414f-bdfb-97412fa5bd64");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customTagState, "neutralDark", {
get: function () {
return getCustomTagStateRecord("d89d1c3c-871e-4b16-8580-f20a79b9c223");
}
});

ShopperPortalEU_UI_ComponentsModel.staticEntities.customRadioGroupState = {};
var getCustomRadioGroupStateRecord = function (record) {
return ShopperPortalEU_UI_ComponentsModel.module.staticEntities["1975978c-8d6a-492d-befc-51a42fcc8f8c"][record];
};
Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customRadioGroupState, "disabled", {
get: function () {
return getCustomRadioGroupStateRecord("b504d750-dec2-43cd-a5a3-829e1ffcfe2b");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customRadioGroupState, "readOnly", {
get: function () {
return getCustomRadioGroupStateRecord("e6062cd0-56be-486e-b2b1-2d337f6c9937");
}
});

ShopperPortalEU_UI_ComponentsModel.staticEntities.fullHeightContentAlignment = {};
var getFullHeightContentAlignmentRecord = function (record) {
return ShopperPortalEU_UI_ComponentsModel.module.staticEntities["275b2903-24c0-41da-bfca-19e4261c515f"][record];
};
Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.fullHeightContentAlignment, "end", {
get: function () {
return getFullHeightContentAlignmentRecord("1a4a4a52-89af-420b-826e-870139e0a764");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.fullHeightContentAlignment, "start", {
get: function () {
return getFullHeightContentAlignmentRecord("442c5a48-536b-4d15-9ceb-e0c0f8de7b89");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.fullHeightContentAlignment, "center", {
get: function () {
return getFullHeightContentAlignmentRecord("896ea577-e650-407b-99c3-a8e7a5a1d3a2");
}
});

ShopperPortalEU_UI_ComponentsModel.staticEntities.customLinkIconAlignment = {};
var getCustomLinkIconAlignmentRecord = function (record) {
return ShopperPortalEU_UI_ComponentsModel.module.staticEntities["27df98a3-902b-455f-9703-410f19c4e19f"][record];
};
Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customLinkIconAlignment, "right", {
get: function () {
return getCustomLinkIconAlignmentRecord("239358b2-c3ff-4402-b772-29f76cf4471e");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customLinkIconAlignment, "left", {
get: function () {
return getCustomLinkIconAlignmentRecord("9f35fcbf-1ba0-4c3c-bb32-35d9ea26c3fc");
}
});

ShopperPortalEU_UI_ComponentsModel.staticEntities.customIconFamily = {};
var getCustomIconFamilyRecord = function (record) {
return ShopperPortalEU_UI_ComponentsModel.module.staticEntities["3cac8f18-453c-4266-bac7-1e6a4c9a927d"][record];
};
Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customIconFamily, "material", {
get: function () {
return getCustomIconFamilyRecord("6174a3e0-352f-4bd6-a3d8-02e7c57b11bc");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customIconFamily, "planet", {
get: function () {
return getCustomIconFamilyRecord("df8e6450-0b1f-4ee9-b565-0c9de741e710");
}
});

ShopperPortalEU_UI_ComponentsModel.staticEntities.customLinkType = {};
var getCustomLinkTypeRecord = function (record) {
return ShopperPortalEU_UI_ComponentsModel.module.staticEntities["3ded79d0-1eeb-4afc-9820-e2a9cd2f07ad"][record];
};
Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customLinkType, "buttonPrimary", {
get: function () {
return getCustomLinkTypeRecord("26dc0d36-7d32-408a-b62e-57db318984b3");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customLinkType, "buttonSecondary", {
get: function () {
return getCustomLinkTypeRecord("933bcf14-9342-44d1-b4d5-ea1788895732");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customLinkType, "primary", {
get: function () {
return getCustomLinkTypeRecord("a60f4830-69c1-4149-b2f0-9dd655ee4749");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customLinkType, "buttonReverse", {
get: function () {
return getCustomLinkTypeRecord("b6dd4bf3-2e25-4c18-a0b5-29c05e017b50");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customLinkType, "ghost", {
get: function () {
return getCustomLinkTypeRecord("cf404bd0-1fb5-407c-8dd6-0b94939919ac");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customLinkType, "secondary", {
get: function () {
return getCustomLinkTypeRecord("f665bf28-64f7-424d-9bc1-b7670a4a30f8");
}
});

ShopperPortalEU_UI_ComponentsModel.staticEntities.customTimelineType = {};
var getCustomTimelineTypeRecord = function (record) {
return ShopperPortalEU_UI_ComponentsModel.module.staticEntities["4823f731-14b1-4c91-a901-6ef6cbf22f33"][record];
};
Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customTimelineType, "redo", {
get: function () {
return getCustomTimelineTypeRecord("2b8fd845-df5b-4fa1-9da0-dcc51029cfb3");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customTimelineType, "next", {
get: function () {
return getCustomTimelineTypeRecord("41004cbd-08c1-429e-8581-6b9bac99fa77");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customTimelineType, "current", {
get: function () {
return getCustomTimelineTypeRecord("4f558cb6-300a-475e-be6c-93b45faf97e6");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customTimelineType, "past", {
get: function () {
return getCustomTimelineTypeRecord("92d0b3aa-6c37-409c-8e33-d4084f94f11e");
}
});

ShopperPortalEU_UI_ComponentsModel.staticEntities.customRadioButtonState = {};
var getCustomRadioButtonStateRecord = function (record) {
return ShopperPortalEU_UI_ComponentsModel.module.staticEntities["537a5406-4d27-469a-bfd7-4391c91db942"][record];
};
Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customRadioButtonState, "disabled", {
get: function () {
return getCustomRadioButtonStateRecord("d6f5c26c-29f0-4412-82f9-9b3a3ce8bf43");
}
});

ShopperPortalEU_UI_ComponentsModel.staticEntities.justify = {};
var getJustifyRecord = function (record) {
return ShopperPortalEU_UI_ComponentsModel.module.staticEntities["611abea5-5a8a-4090-84d3-aa7203275f0b"][record];
};
Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.justify, "start", {
get: function () {
return getJustifyRecord("1b9b0ffb-2c5c-45d5-91ad-de6e564943fc");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.justify, "center", {
get: function () {
return getJustifyRecord("4e4a5e9d-6bbc-4cce-9d99-54c7b6abbbb7");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.justify, "end", {
get: function () {
return getJustifyRecord("c80bab53-af52-48b1-a544-95aa15113f22");
}
});

ShopperPortalEU_UI_ComponentsModel.staticEntities.customIconSize = {};
var getCustomIconSizeRecord = function (record) {
return ShopperPortalEU_UI_ComponentsModel.module.staticEntities["61ccda77-5a92-45e8-9d19-9a6741575ccf"][record];
};
Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customIconSize, "large", {
get: function () {
return getCustomIconSizeRecord("59be3f66-dacf-482a-8f70-2f16fe36af65");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customIconSize, "extraSmall", {
get: function () {
return getCustomIconSizeRecord("6b0d7c1e-80e7-45f4-9532-04cf71317cf9");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customIconSize, "small", {
get: function () {
return getCustomIconSizeRecord("a61035e3-7d0f-416c-9242-af27cde5b6ee");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customIconSize, "base", {
get: function () {
return getCustomIconSizeRecord("de82cee7-2ecd-46fe-a554-5f2b265579c9");
}
});

ShopperPortalEU_UI_ComponentsModel.staticEntities.customLinkState = {};
var getCustomLinkStateRecord = function (record) {
return ShopperPortalEU_UI_ComponentsModel.module.staticEntities["7c64bdb6-fc37-4fb1-9451-121ad1dbc22e"][record];
};
Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customLinkState, "danger", {
get: function () {
return getCustomLinkStateRecord("2e521704-9eee-45b2-a57f-a56f19d6e677");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customLinkState, "warning", {
get: function () {
return getCustomLinkStateRecord("90db5b14-f165-4a25-8be0-9621bb22a7e0");
}
});

ShopperPortalEU_UI_ComponentsModel.staticEntities.customSwitchState = {};
var getCustomSwitchStateRecord = function (record) {
return ShopperPortalEU_UI_ComponentsModel.module.staticEntities["841a8058-faae-42c4-818c-a4c5bf5cf21f"][record];
};
Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customSwitchState, "readOnly", {
get: function () {
return getCustomSwitchStateRecord("b2bf584b-65a3-471f-b5da-c3de173618c3");
}
});

ShopperPortalEU_UI_ComponentsModel.staticEntities.customButtonState = {};
var getCustomButtonStateRecord = function (record) {
return ShopperPortalEU_UI_ComponentsModel.module.staticEntities["8b04d908-50f0-4f5a-952b-2f22c38a7acf"][record];
};
Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customButtonState, "danger", {
get: function () {
return getCustomButtonStateRecord("3d3d7afd-db9e-44ca-aca3-808f1aaf320b");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customButtonState, "warning", {
get: function () {
return getCustomButtonStateRecord("ca4d4eeb-e0c6-435f-b85b-c6a9f5d1efe2");
}
});

ShopperPortalEU_UI_ComponentsModel.staticEntities.customButtonType = {};
var getCustomButtonTypeRecord = function (record) {
return ShopperPortalEU_UI_ComponentsModel.module.staticEntities["8c5a83db-2664-4f8f-8019-2297fbe82e1a"][record];
};
Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customButtonType, "reverse", {
get: function () {
return getCustomButtonTypeRecord("1bd1b1dc-b4b5-48b7-86c8-759eee56a01e");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customButtonType, "linkPrimary", {
get: function () {
return getCustomButtonTypeRecord("24f80528-798e-4118-b7ab-b91e4c8d27ea");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customButtonType, "primary", {
get: function () {
return getCustomButtonTypeRecord("6d7431ba-62ac-4878-876c-0bde65e81bc6");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customButtonType, "ghost", {
get: function () {
return getCustomButtonTypeRecord("7f50385b-81c3-4e07-bbb1-fa0d7a0cfaff");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customButtonType, "linkSecondary", {
get: function () {
return getCustomButtonTypeRecord("87fc3e98-f356-4f50-85d2-e2798190fdd4");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customButtonType, "secondary", {
get: function () {
return getCustomButtonTypeRecord("a3589a12-16b2-4aac-8068-e53e17db2fd8");
}
});

ShopperPortalEU_UI_ComponentsModel.staticEntities.cardBackgroundType = {};
var getCardBackgroundTypeRecord = function (record) {
return ShopperPortalEU_UI_ComponentsModel.module.staticEntities["8d02131d-8a23-4884-8dca-814a70ac6143"][record];
};
Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.cardBackgroundType, "flight", {
get: function () {
return getCardBackgroundTypeRecord("714aa0d8-22e4-4608-95be-3b55efde18a2");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.cardBackgroundType, "refund", {
get: function () {
return getCardBackgroundTypeRecord("a4d45485-d42d-47ce-ac4e-6d374dc5b7ca");
}
});

ShopperPortalEU_UI_ComponentsModel.staticEntities.customCheckboxState = {};
var getCustomCheckboxStateRecord = function (record) {
return ShopperPortalEU_UI_ComponentsModel.module.staticEntities["91b35c35-56d7-49f9-a952-ba6f32917074"][record];
};
Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customCheckboxState, "readOnly", {
get: function () {
return getCustomCheckboxStateRecord("4a9c373c-79fe-4267-bf9a-9717997462ec");
}
});

ShopperPortalEU_UI_ComponentsModel.staticEntities.customAlertType = {};
var getCustomAlertTypeRecord = function (record) {
return ShopperPortalEU_UI_ComponentsModel.module.staticEntities["9b912be9-9a66-474a-8adc-c5b38eefd9dd"][record];
};
Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customAlertType, "neutral", {
get: function () {
return getCustomAlertTypeRecord("3d27974b-5ac6-45cc-afff-1473eadf8e5b");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customAlertType, "success", {
get: function () {
return getCustomAlertTypeRecord("468b8403-942b-462e-b083-61b605c82abc");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customAlertType, "error", {
get: function () {
return getCustomAlertTypeRecord("9be40092-2833-4c83-a952-4489b0703689");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customAlertType, "warning", {
get: function () {
return getCustomAlertTypeRecord("c2dcecda-b999-4d18-a4cc-2e023db2826a");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customAlertType, "info", {
get: function () {
return getCustomAlertTypeRecord("f6e56421-8df1-4572-9835-9c2ba19a4cc7");
}
});

ShopperPortalEU_UI_ComponentsModel.staticEntities.customButtonGroupOrientation = {};
var getCustomButtonGroupOrientationRecord = function (record) {
return ShopperPortalEU_UI_ComponentsModel.module.staticEntities["a5e2e9c4-c98d-4380-9a9f-b3d0705fc34c"][record];
};
Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customButtonGroupOrientation, "vertical", {
get: function () {
return getCustomButtonGroupOrientationRecord("575d3c55-eef2-4f91-848c-ff3c23a23ae3");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customButtonGroupOrientation, "horizontal", {
get: function () {
return getCustomButtonGroupOrientationRecord("8c04fb74-8816-41e6-876c-bf16ccf439bb");
}
});

ShopperPortalEU_UI_ComponentsModel.staticEntities.circleIconSize = {};
var getCircleIconSizeRecord = function (record) {
return ShopperPortalEU_UI_ComponentsModel.module.staticEntities["b1869945-d2a5-4b6a-89cf-e4eb715d9fa7"][record];
};
Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.circleIconSize, "medium", {
get: function () {
return getCircleIconSizeRecord("a8d31fdd-40e0-4aa2-95fc-f7b637c3ea4d");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.circleIconSize, "large", {
get: function () {
return getCircleIconSizeRecord("bbed6181-4810-4df0-8d38-ff1229a33589");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.circleIconSize, "default", {
get: function () {
return getCircleIconSizeRecord("fa8ec6d0-0025-4dee-b81b-86c4e3f34c7d");
}
});

ShopperPortalEU_UI_ComponentsModel.staticEntities.flexAlign = {};
var getFlexAlignRecord = function (record) {
return ShopperPortalEU_UI_ComponentsModel.module.staticEntities["b8e9386b-1b91-418d-9b78-e9d0fab2dbe8"][record];
};
Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.flexAlign, "center", {
get: function () {
return getFlexAlignRecord("9d2f074f-fee8-40cb-8295-186b001830c9");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.flexAlign, "start", {
get: function () {
return getFlexAlignRecord("cf0f97bd-db28-4fde-98a8-15d8d84e712b");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.flexAlign, "end", {
get: function () {
return getFlexAlignRecord("d11edd7a-4cb2-4027-b4b0-7ac006b3f796");
}
});

ShopperPortalEU_UI_ComponentsModel.staticEntities.customSeparatorState = {};
var getCustomSeparatorStateRecord = function (record) {
return ShopperPortalEU_UI_ComponentsModel.module.staticEntities["c17edeb0-858e-475b-b1b8-37f726bcd95e"][record];
};
Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customSeparatorState, "default", {
get: function () {
return getCustomSeparatorStateRecord("686aeb51-da93-4999-8b15-6aa3418ce28c");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customSeparatorState, "lighter", {
get: function () {
return getCustomSeparatorStateRecord("7914e06d-14c2-4ab7-9fbd-a5c765e1052c");
}
});

ShopperPortalEU_UI_ComponentsModel.staticEntities.customDropdownSize = {};
var getCustomDropdownSizeRecord = function (record) {
return ShopperPortalEU_UI_ComponentsModel.module.staticEntities["c3c2b6f8-4bd2-400c-8a1e-61a665ee6cad"][record];
};
Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customDropdownSize, "large", {
get: function () {
return getCustomDropdownSizeRecord("d9399ed1-c9e7-4ed7-a3cd-f3eb6747af5b");
}
});

ShopperPortalEU_UI_ComponentsModel.staticEntities.flexDirection = {};
var getFlexDirectionRecord = function (record) {
return ShopperPortalEU_UI_ComponentsModel.module.staticEntities["c8f9728d-d6df-4153-8f27-e61678ea77a0"][record];
};
Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.flexDirection, "row", {
get: function () {
return getFlexDirectionRecord("3ae4da0b-63ea-492d-b71f-f775e3f93288");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.flexDirection, "columnReverse", {
get: function () {
return getFlexDirectionRecord("4d0cfd93-b5fe-4ac1-b9d9-a9ca9f64de31");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.flexDirection, "rowReverse", {
get: function () {
return getFlexDirectionRecord("bbd4c36d-5035-470c-8469-e830db667660");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.flexDirection, "column", {
get: function () {
return getFlexDirectionRecord("f461ffff-e107-428a-8ff1-11e997c220a5");
}
});

ShopperPortalEU_UI_ComponentsModel.staticEntities.customValidationMessageState = {};
var getCustomValidationMessageStateRecord = function (record) {
return ShopperPortalEU_UI_ComponentsModel.module.staticEntities["cd28deba-4841-4daf-a31b-226171324958"][record];
};
Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customValidationMessageState, "warning", {
get: function () {
return getCustomValidationMessageStateRecord("5f444ee1-234f-4bc0-9bc7-eb62ad095369");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customValidationMessageState, "error", {
get: function () {
return getCustomValidationMessageStateRecord("76a3c1de-6513-4a8b-8299-0b7537b04735");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customValidationMessageState, "success", {
get: function () {
return getCustomValidationMessageStateRecord("915a0210-dc25-4c06-a249-cb3d90441fe2");
}
});

ShopperPortalEU_UI_ComponentsModel.staticEntities.cardStateType = {};
var getCardStateTypeRecord = function (record) {
return ShopperPortalEU_UI_ComponentsModel.module.staticEntities["cda633b3-44e4-4d03-b041-4ee42266a05a"][record];
};
Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.cardStateType, "warning", {
get: function () {
return getCardStateTypeRecord("2267ce4f-86c5-4534-9a05-9bc4c1a2b8a6");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.cardStateType, "success", {
get: function () {
return getCardStateTypeRecord("3358c40b-9c87-49f1-8f5a-cd589557c30e");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.cardStateType, "info", {
get: function () {
return getCardStateTypeRecord("9dce627a-d246-40cc-a52b-296c2b8e66e5");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.cardStateType, "error", {
get: function () {
return getCardStateTypeRecord("cb221e47-9ec7-4a77-af8c-f1208585d4c4");
}
});

ShopperPortalEU_UI_ComponentsModel.staticEntities.codeInputState = {};
var getCodeInputStateRecord = function (record) {
return ShopperPortalEU_UI_ComponentsModel.module.staticEntities["ce00e3a6-a3cd-4660-89c4-de0800674aef"][record];
};
Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.codeInputState, "error", {
get: function () {
return getCodeInputStateRecord("30337f78-a9d9-4669-8c35-e38d7a62a512");
}
});

ShopperPortalEU_UI_ComponentsModel.staticEntities.buttonOptionState = {};
var getButtonOptionStateRecord = function (record) {
return ShopperPortalEU_UI_ComponentsModel.module.staticEntities["df9b2907-53bd-4672-bfbc-58fc84d4a14f"][record];
};
Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.buttonOptionState, "danger", {
get: function () {
return getButtonOptionStateRecord("5594cfd1-5e97-4f6a-a77b-98999e635b76");
}
});

ShopperPortalEU_UI_ComponentsModel.staticEntities.customButtonIconAlignment = {};
var getCustomButtonIconAlignmentRecord = function (record) {
return ShopperPortalEU_UI_ComponentsModel.module.staticEntities["e1049605-6162-45c0-85f6-6dd6976bc502"][record];
};
Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customButtonIconAlignment, "right", {
get: function () {
return getCustomButtonIconAlignmentRecord("28784f91-9d54-4ace-bfc0-9fb69b8ac54e");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customButtonIconAlignment, "left", {
get: function () {
return getCustomButtonIconAlignmentRecord("3e6ab0aa-bf1d-475c-bdb1-fb5d7a2c8ee0");
}
});

ShopperPortalEU_UI_ComponentsModel.staticEntities.stateBadgeType = {};
var getStateBadgeTypeRecord = function (record) {
return ShopperPortalEU_UI_ComponentsModel.module.staticEntities["e25eb90f-ca17-4969-98d8-31621c542f63"][record];
};
Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.stateBadgeType, "success", {
get: function () {
return getStateBadgeTypeRecord("3db9a288-88cb-48e2-aad0-1a91b5c34a99");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.stateBadgeType, "error", {
get: function () {
return getStateBadgeTypeRecord("8f7e6ae7-1750-477b-91f2-8e079bdc4a5c");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.stateBadgeType, "info", {
get: function () {
return getStateBadgeTypeRecord("ea77381b-feeb-4f75-9978-425612ab8a7c");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.stateBadgeType, "warning", {
get: function () {
return getStateBadgeTypeRecord("fb099e12-e4c3-4cb9-9ee2-3f431813ad37");
}
});

ShopperPortalEU_UI_ComponentsModel.staticEntities.customInputAlignment = {};
var getCustomInputAlignmentRecord = function (record) {
return ShopperPortalEU_UI_ComponentsModel.module.staticEntities["ec2451cf-be71-47f2-b9dd-3285b941dafb"][record];
};
Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customInputAlignment, "right", {
get: function () {
return getCustomInputAlignmentRecord("0d1dbf94-80f6-4fc2-b3ec-ad21eda284d7");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customInputAlignment, "center", {
get: function () {
return getCustomInputAlignmentRecord("ebd102d3-8599-4d4d-9a6d-b2e033f438ee");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customInputAlignment, "left", {
get: function () {
return getCustomInputAlignmentRecord("f08a937e-d0ad-41c1-9e43-8e24286b5404");
}
});

ShopperPortalEU_UI_ComponentsModel.staticEntities.customWizardItemState = {};
var getCustomWizardItemStateRecord = function (record) {
return ShopperPortalEU_UI_ComponentsModel.module.staticEntities["ee64f27c-c48a-4654-aebb-fd1864871edf"][record];
};
Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customWizardItemState, "current", {
get: function () {
return getCustomWizardItemStateRecord("7e927b98-5810-4efc-b217-e3ee41a21325");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customWizardItemState, "past", {
get: function () {
return getCustomWizardItemStateRecord("9cfb735a-6dbb-4442-bf50-b5c3869e7d8b");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customWizardItemState, "next", {
get: function () {
return getCustomWizardItemStateRecord("e20c86e0-f62f-4901-ba83-14075c7f4e4d");
}
});

ShopperPortalEU_UI_ComponentsModel.staticEntities.flexJustify = {};
var getFlexJustifyRecord = function (record) {
return ShopperPortalEU_UI_ComponentsModel.module.staticEntities["f0ae093d-265f-4f7c-9a9d-b1e6fc1c462e"][record];
};
Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.flexJustify, "spaceEvenly", {
get: function () {
return getFlexJustifyRecord("1841bbb4-f242-4e5a-a8e4-316b4f46d16f");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.flexJustify, "end", {
get: function () {
return getFlexJustifyRecord("2c834e3e-828b-444a-89c1-07d3a80fde5b");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.flexJustify, "spaceBetween", {
get: function () {
return getFlexJustifyRecord("337f5727-2160-4a6a-bf56-d3b0ce06d600");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.flexJustify, "start", {
get: function () {
return getFlexJustifyRecord("a18f1ed7-49c1-4621-ba05-878b7755951f");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.flexJustify, "center", {
get: function () {
return getFlexJustifyRecord("dfd66d6c-751a-4d79-833a-7a0bac1e8f97");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.flexJustify, "spaceAround", {
get: function () {
return getFlexJustifyRecord("ed58348f-9e1a-46c3-91a4-fac6ea8b0bfd");
}
});

ShopperPortalEU_UI_ComponentsModel.staticEntities.customCardState = {};
var getCustomCardStateRecord = function (record) {
return ShopperPortalEU_UI_ComponentsModel.module.staticEntities["f7cf750e-f7cb-49ce-a9c0-60616b0a93f7"][record];
};
Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customCardState, "info", {
get: function () {
return getCustomCardStateRecord("4485603b-f17d-439f-925e-e0785d10d8b7");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customCardState, "error", {
get: function () {
return getCustomCardStateRecord("44dd481a-40e6-4b83-8346-58e06a8a633f");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customCardState, "success", {
get: function () {
return getCustomCardStateRecord("b110272d-4692-4414-802b-47142369262b");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customCardState, "inactive", {
get: function () {
return getCustomCardStateRecord("ba500e36-41d1-40b6-91e5-4c0cfdd50e05");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customCardState, "warning", {
get: function () {
return getCustomCardStateRecord("dfe090fc-c277-47d0-a449-830e7270426b");
}
});

ShopperPortalEU_UI_ComponentsModel.staticEntities.customRadioGroupOrientation = {};
var getCustomRadioGroupOrientationRecord = function (record) {
return ShopperPortalEU_UI_ComponentsModel.module.staticEntities["faf7165b-e408-4f26-9140-e7256c6e2838"][record];
};
Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customRadioGroupOrientation, "horizontal", {
get: function () {
return getCustomRadioGroupOrientationRecord("292a4b84-7940-4f70-b13f-88173e254dca");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.customRadioGroupOrientation, "vertical", {
get: function () {
return getCustomRadioGroupOrientationRecord("3dfe1875-de40-4a59-88ca-4c9104cebb81");
}
});

ShopperPortalEU_UI_ComponentsModel.staticEntities.align = {};
var getAlignRecord = function (record) {
return ShopperPortalEU_UI_ComponentsModel.module.staticEntities["fbce9827-f76d-4350-bfe8-152e2854d8b2"][record];
};
Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.align, "start", {
get: function () {
return getAlignRecord("d85ffc10-cc7b-4f47-9c3b-cadcfcb492eb");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.align, "center", {
get: function () {
return getAlignRecord("e23d045e-084b-4c72-92b2-c5d687f53f98");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.align, "end", {
get: function () {
return getAlignRecord("f5de2d6a-8484-4af7-966b-c6cb0d1c8f57");
}
});

ShopperPortalEU_UI_ComponentsModel.staticEntities.spacing = {};
var getSpacingRecord = function (record) {
return ShopperPortalEU_UI_ComponentsModel.module.staticEntities["fc23d15e-13f5-404c-960e-61d739e364fd"][record];
};
Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.spacing, "space6", {
get: function () {
return getSpacingRecord("0ecce298-a52a-4e15-b4cc-adad15e3614c");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.spacing, "space11", {
get: function () {
return getSpacingRecord("10bbed59-20f9-4c08-8390-7d7dd0c13779");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.spacing, "space9", {
get: function () {
return getSpacingRecord("30ea0ec9-d4db-498c-9462-f8ae7bb7a417");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.spacing, "space4", {
get: function () {
return getSpacingRecord("43217c61-8425-4bd8-bf20-364b8f21786a");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.spacing, "space1", {
get: function () {
return getSpacingRecord("86e5d5c7-011c-43ed-80ed-90d7080be0e6");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.spacing, "space3", {
get: function () {
return getSpacingRecord("8778abb9-572e-4cfa-8a1a-181350f6a7c2");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.spacing, "space8", {
get: function () {
return getSpacingRecord("88882ef4-8e95-4422-9ce2-6db61a769b76");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.spacing, "space12", {
get: function () {
return getSpacingRecord("8d947462-0124-4b32-b7fc-249f8995c8c4");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.spacing, "space10", {
get: function () {
return getSpacingRecord("99e552d0-70f0-4225-b5af-454f6231fc6b");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.spacing, "none", {
get: function () {
return getSpacingRecord("c9ea514c-8e2a-425e-9b4f-3542dd14d75f");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.spacing, "space5", {
get: function () {
return getSpacingRecord("ca0ae05c-3f6f-4ce2-a63e-2345ed4ab914");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.spacing, "space2", {
get: function () {
return getSpacingRecord("ee48a7d2-7f38-45c6-ad79-f9482625a1f2");
}
});

Object.defineProperty(ShopperPortalEU_UI_ComponentsModel.staticEntities.spacing, "space7", {
get: function () {
return getSpacingRecord("f88ed216-e852-4a68-8f5e-c87f8ac31967");
}
});

});
