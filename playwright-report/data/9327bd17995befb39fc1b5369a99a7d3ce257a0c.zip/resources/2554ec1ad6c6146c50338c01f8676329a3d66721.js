define("ShopperPortalEU.controller$AddAnonymousFormToString", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU.clientVariables", "ShopperPortalEU.model$AnonymousFormsList", "ShopperPortalEU.controller$GetAnonymousFormsList", "ShopperPortalEU.controller$UpdateAnonymousFormAttempt"], function (exports, OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEUClientVariables) {
var OS = OutSystems.Internal;
ShopperPortalEUController.default.addAnonymousFormToString$Action = function (anonymousFormNumberIn, nrOfAttemptsIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.AddAnonymousFormToString$vars"))());
vars.value.anonymousFormNumberInLocal = anonymousFormNumberIn;
vars.value.nrOfAttemptsInLocal = nrOfAttemptsIn;
var listFilterVar = new OS.DataTypes.VariableHolder();
var getAnonymousFormsListVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.vars = vars;
varBag.listFilterVar = listFilterVar;
varBag.getAnonymousFormsListVar = getAnonymousFormsListVar;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:Z4Eqay_zGkuobEYebayo8g:/ClientActionFlows.Z4Eqay_zGkuobEYebayo8g:BLeDBpKsRa+Y1W5uB9xE3g", "ShopperPortalEU", "AddAnonymousFormToString", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:IpYBwh8kjUChWr1GIYI22g", callContext.id);
// LessThan3attemps?
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:F+9sx8ZGy0e_1eDV6LF96Q", callContext.id) && (OS.BuiltinFunctions.textToInteger(vars.value.nrOfAttemptsInLocal) <= 3))) {
// FormNumber_AttemptNr
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ujOWiK8Uo06pywHhdffwDA", callContext.id);
// FormNumber_AttemptNr = AnonymousFormNumber + "_" + NrOfAttempts
vars.value.formNumber_AttemptNrVar = ((vars.value.anonymousFormNumberInLocal + "_") + vars.value.nrOfAttemptsInLocal);
// Client var AnonymousFormList not empty?
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:0fqJ7EjjkkOTkVuB5y5Alg", callContext.id) && ((ShopperPortalEUClientVariables.getAnonymousFormList()) !== ("")))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:hkI2oxO+yEmuGgD+tL1IbA", callContext.id);
// Execute Action: GetAnonymousFormsList
getAnonymousFormsListVar.value = ShopperPortalEUController.default.getAnonymousFormsList$Action(ShopperPortalEUClientVariables.getAnonymousFormList(), callContext);

OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:fj3GdrLj1EuTOEPg+LUN5g", callContext.id);
// Execute Action: ListFilter
listFilterVar.value = OS.SystemActions.listFilter(getAnonymousFormsListVar.value.anonymousFormsListOut, function (p) {
return (p.formNumberAttr === vars.value.anonymousFormNumberInLocal);
}, callContext);

// Found Form?
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:2Yv98sSk70KYjS086XAyGg", callContext.id) && !(listFilterVar.value.filteredListOut.isEmpty))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:yEJIykdFzU2lJJJHg85clw", callContext.id);
// Execute Action: UpdateAnonymousFormAttempt
ShopperPortalEUController.default.updateAnonymousFormAttempt$Action(listFilterVar.value.filteredListOut.getCurrent(callContext.iterationContext).formNumberAttr, vars.value.nrOfAttemptsInLocal, getAnonymousFormsListVar.value.anonymousFormsListOut, callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:tF2sifHMSEiLI3ud7WaqpA", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:+kQWfl65MEazNyQIq5ELNQ", callContext.id);
// AnonymousFormList = If
ShopperPortalEUClientVariables.setAnonymousFormList((((ShopperPortalEUClientVariables.getAnonymousFormList() === "")) ? (vars.value.formNumber_AttemptNrVar) : (((ShopperPortalEUClientVariables.getAnonymousFormList() + ",") + vars.value.formNumber_AttemptNrVar))));
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:200AJKI4W0ObnLCFh3+yAg", callContext.id);
}

} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:4_dnIXRsGUeH+4eP2+3F9w", callContext.id);
// AnonymousFormList = If
ShopperPortalEUClientVariables.setAnonymousFormList((((ShopperPortalEUClientVariables.getAnonymousFormList() === "")) ? (vars.value.formNumber_AttemptNrVar) : (((ShopperPortalEUClientVariables.getAnonymousFormList() + ",") + vars.value.formNumber_AttemptNrVar))));
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:C1qfUJypiUGQeI7aPWXwwA", callContext.id);
}

} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:b3dYkGekEkKbjK56mVBP+Q", callContext.id);
}

return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:Z4Eqay_zGkuobEYebayo8g", callContext.id);
}

};
var controller = ShopperPortalEUController.default;
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.AddAnonymousFormToString$vars", [{
name: "AnonymousFormNumber",
attrName: "anonymousFormNumberInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}, {
name: "NrOfAttempts",
attrName: "nrOfAttemptsInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}, {
name: "FormNumber_AttemptNr",
attrName: "formNumber_AttemptNrVar",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEUController.default.clientActionProxies.addAnonymousFormToString$Action = function (anonymousFormNumberIn, nrOfAttemptsIn) {
anonymousFormNumberIn = (anonymousFormNumberIn === undefined) ? "" : anonymousFormNumberIn;
nrOfAttemptsIn = (nrOfAttemptsIn === undefined) ? "" : nrOfAttemptsIn;
return controller.executeActionInsideJSNode(ShopperPortalEUController.default.addAnonymousFormToString$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(anonymousFormNumberIn, OS.DataTypes.DataTypes.Text), OS.DataConversion.JSNodeParamConverter.from(nrOfAttemptsIn, OS.DataTypes.DataTypes.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});

define("ShopperPortalEU.controller$ApcuesIdentify", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU.controller$ApcuesIdentify.IdentifyJS", "ShopperPortalEU.clientVariables", "ShopperPortalEU.model$ApcuesIdentifyRec"], function (exports, OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_controller_ApcuesIdentify_IdentifyJS, ShopperPortalEUClientVariables) {
var OS = OutSystems.Internal;
ShopperPortalEUController.default.apcuesIdentify$Action = function (apcuesIdentifyIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.ApcuesIdentify$vars"))());
vars.value.apcuesIdentifyInLocal = apcuesIdentifyIn.clone();
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:HMR2R17c2EGSKWgMlxnxFA:/ClientActionFlows.HMR2R17c2EGSKWgMlxnxFA:LlSSRNfnKFJ4x0K79GcxXw", "ShopperPortalEU", "ApcuesIdentify", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:tbxbRNj3T0uhpxKYUSuUug", callContext.id);
// Has userID ?
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:QZzFnaSJcUiFrOFD8LdgDQ", callContext.id) && ((vars.value.apcuesIdentifyInLocal.guidAttr) !== ("")))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:oHLvWNVNykebNygQaMD0pQ", callContext.id);
controller.safeExecuteJSNode(ShopperPortalEU_controller_ApcuesIdentify_IdentifyJS, "Identify", "ApcuesIdentify", {
Email: OS.DataConversion.JSNodeParamConverter.to(vars.value.apcuesIdentifyInLocal.emailAttr, OS.DataTypes.DataTypes.Text),
UserID: OS.DataConversion.JSNodeParamConverter.to(vars.value.apcuesIdentifyInLocal.guidAttr, OS.DataTypes.DataTypes.Text),
Name: OS.DataConversion.JSNodeParamConverter.to(vars.value.apcuesIdentifyInLocal.nameAttr, OS.DataTypes.DataTypes.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:1yqv7ELO8ESowyw++cuTeA", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:WZJpe1uC6UyVAmUFkcmKdA", callContext.id);
}

return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:HMR2R17c2EGSKWgMlxnxFA", callContext.id);
}

};
var controller = ShopperPortalEUController.default;
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.ApcuesIdentify$vars", [{
name: "ApcuesIdentify",
attrName: "apcuesIdentifyInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Record,
defaultValue: function () {
return new ShopperPortalEUModel.ApcuesIdentifyRec();
},
complexType: ShopperPortalEUModel.ApcuesIdentifyRec
}]);
ShopperPortalEUController.default.clientActionProxies.apcuesIdentify$Action = function (apcuesIdentifyIn) {
apcuesIdentifyIn = (apcuesIdentifyIn === undefined) ? new ShopperPortalEUModel.ApcuesIdentifyRec() : apcuesIdentifyIn;
return controller.executeActionInsideJSNode(ShopperPortalEUController.default.apcuesIdentify$Action.bind(controller, apcuesIdentifyIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("ShopperPortalEU.controller$ApcuesIdentify.IdentifyJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
if (typeof window.Appcues !== "undefined") {
Appcues.identify($parameters.UserID, {
  name: $parameters.Name,
  email: $parameters.Email
});
}
};
});

define("ShopperPortalEU.controller$Authenticate", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_Shopper_IS.controller", "ShopperPortalEU.clientVariables", "ShopperPortalEU_Shopper_IS.controller$SignupShopper", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS"], function (exports, OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_Shopper_ISController, ShopperPortalEUClientVariables) {
var OS = OutSystems.Internal;
ShopperPortalEUController.default.authenticate$Action = function (usernameIn, isGenericLoginIn, captchaTokenIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.Authenticate$vars"))());
vars.value.usernameInLocal = usernameIn;
vars.value.isGenericLoginInLocal = isGenericLoginIn;
vars.value.captchaTokenInLocal = captchaTokenIn;
var signupShopper2Var = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.Authenticate$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.signupShopper2Var = signupShopper2Var;
varBag.outVars = outVars;
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:NczhhnKrtEeh6bkYlQ97Bw:/ClientActionFlows.NczhhnKrtEeh6bkYlQ97Bw:bIglQNk1_TDFBa3l8CdJUg", "ShopperPortalEU", "Authenticate", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:GZfg5aI4DkOivNzOXW6WWg", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:7W61fxO_AEqK9UhkMgZjlw", callContext.id) && ((vars.value.usernameInLocal) !== ("")))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:7iDpmhVyukWRHxuXtC8ncA", callContext.id);
// Execute Action: SignupShopper2
return ShopperPortalEU_Shopper_ISController.default.signupShopper$Action(vars.value.usernameInLocal, "", vars.value.captchaTokenInLocal, callContext).then(function (value) {
signupShopper2Var.value = value;
}).then(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ioq+lbXwvkGGWCyISb8t1w", callContext.id) && signupShopper2Var.value.isSuccessOut)) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:gy1tChdn30yiIYK52kH+WQ", callContext.id);
} else {
// ErrorMessage
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:LuntGop0aUywE7KEvwTVzw", callContext.id);
// Success = False
outVars.value.successOut = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:LuntGop0aUywE7KEvwTVzw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// ErrorMessage = SignupShopper2.ErrorMessage
outVars.value.errorMessageOut = signupShopper2Var.value.errorMessageOut;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:nUQ82yOTWEOjvBXBEt7umw", callContext.id);
}

});
} else {
// ErrorMessage
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:4bklV1NZ5kGCxVWOh7xrAQ", callContext.id);
// ErrorMessage = "Enter a valid email address"
outVars.value.errorMessageOut = "Enter a valid email address";
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:4bklV1NZ5kGCxVWOh7xrAQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Success = False
outVars.value.successOut = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:QyJXbrCqE0G1SVtcGvkgcQ", callContext.id);
}

});
}).then(function () {
return outVars.value;
}).then(function (res) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:NczhhnKrtEeh6bkYlQ97Bw", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:NczhhnKrtEeh6bkYlQ97Bw", callContext.id);
throw ex;

});
};
var controller = ShopperPortalEUController.default;
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.Authenticate$vars", [{
name: "Username",
attrName: "usernameInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}, {
name: "IsGenericLogin",
attrName: "isGenericLoginInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "CaptchaToken",
attrName: "captchaTokenInLocal",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}, {
name: "Attempt",
attrName: "attemptVar",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Integer,
defaultValue: function () {
return 0;
}
}]);
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.Authenticate$outVars", [{
name: "Success",
attrName: "successOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Boolean,
defaultValue: function () {
return true;
}
}, {
name: "ErrorMessage",
attrName: "errorMessageOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEUController.default.clientActionProxies.authenticate$Action = function (usernameIn, isGenericLoginIn, captchaTokenIn) {
usernameIn = (usernameIn === undefined) ? "" : usernameIn;
isGenericLoginIn = (isGenericLoginIn === undefined) ? false : isGenericLoginIn;
captchaTokenIn = (captchaTokenIn === undefined) ? "" : captchaTokenIn;
return controller.executeActionInsideJSNode(ShopperPortalEUController.default.authenticate$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(usernameIn, OS.DataTypes.DataTypes.Text), OS.DataConversion.JSNodeParamConverter.from(isGenericLoginIn, OS.DataTypes.DataTypes.Boolean), OS.DataConversion.JSNodeParamConverter.from(captchaTokenIn, OS.DataTypes.DataTypes.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Success: OS.DataConversion.JSNodeParamConverter.to(actionResults.successOut, OS.DataTypes.DataTypes.Boolean),
ErrorMessage: OS.DataConversion.JSNodeParamConverter.to(actionResults.errorMessageOut, OS.DataTypes.DataTypes.Text)
};
});
};
});

define("ShopperPortalEU.controller$CheckAuthentication", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "Auth_Europe.model", "Auth_Europe.controller", "ShopperPortalEU.clientVariables", "Auth_Europe.model$AccessInfoRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$Auth_Europe", "Auth_Europe.controller$IsAuthenticated"], function (exports, OutSystems, ShopperPortalEUModel, ShopperPortalEUController, Auth_EuropeModel, Auth_EuropeController, ShopperPortalEUClientVariables) {
var OS = OutSystems.Internal;
ShopperPortalEUController.default.checkAuthentication$Action = function (notRedirectIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.CheckAuthentication$vars"))());
vars.value.notRedirectInLocal = notRedirectIn;
var authenticatedVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.CheckAuthentication$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.authenticatedVar = authenticatedVar;
varBag.outVars = outVars;
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:CFnIgs9Ekk6eNgSayN56Yg:/ClientActionFlows.CFnIgs9Ekk6eNgSayN56Yg:UODw5uz6+Ito7qUIurqs+g", "ShopperPortalEU", "CheckAuthentication", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ey5Iw6eWq0qlJ+EGzauzEQ", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:9OL6cohsB0mQnMY0qjLMhw", callContext.id);
// Execute Action: Authenticated
return Auth_EuropeController.default.isAuthenticated$Action(callContext).then(function (value) {
authenticatedVar.value = value;
}).then(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:XhEekoIP602_NC30kdBOIg", callContext.id);
// ShopperGuid = Authenticated.AccessInfo.ShopperGuid
ShopperPortalEUClientVariables.setShopperGuid(authenticatedVar.value.accessInfoOut.shopperGuidAttr);
}).then(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ehbVc9tgIkWccs2EOno44g", callContext.id) && authenticatedVar.value.isAuthenticatedOut)) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:4WQn_VTP20Wxk4PqwNm7tA", callContext.id);
// IsAuthenticated = True
outVars.value.isAuthenticatedOut = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Aw9R7RqeTkWuHxGivEhg9Q", callContext.id);
} else {
// Reset 
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:En9huoSLEUyA5JeyBbgp9Q", callContext.id);
// ShopperGuid = ""
ShopperPortalEUClientVariables.setShopperGuid("");
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:En9huoSLEUyA5JeyBbgp9Q", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// IsAuthenticated = False
outVars.value.isAuthenticatedOut = false;
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:qgBcmR5OLUyH2y5l8UBGJw", callContext.id) && vars.value.notRedirectInLocal)) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:68oHEIZf3029lXKUad6IDg", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:grsyEBe_mkqQ1_ptytiGrA", callContext.id);
// Raise Error: NotRegistered
throw new OS.Exceptions.Exceptions.NotRegisteredException("NotRegistered", "");
}

}

});
}).then(function () {
return outVars.value;
}).then(function (res) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:CFnIgs9Ekk6eNgSayN56Yg", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:CFnIgs9Ekk6eNgSayN56Yg", callContext.id);
throw ex;

});
};
var controller = ShopperPortalEUController.default;
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.CheckAuthentication$vars", [{
name: "NotRedirect",
attrName: "notRedirectInLocal",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Boolean,
defaultValue: function () {
return false;
}
}]);
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.CheckAuthentication$outVars", [{
name: "IsAuthenticated",
attrName: "isAuthenticatedOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Boolean,
defaultValue: function () {
return false;
}
}]);
ShopperPortalEUController.default.clientActionProxies.checkAuthentication$Action = function (notRedirectIn) {
notRedirectIn = (notRedirectIn === undefined) ? false : notRedirectIn;
return controller.executeActionInsideJSNode(ShopperPortalEUController.default.checkAuthentication$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(notRedirectIn, OS.DataTypes.DataTypes.Boolean)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
IsAuthenticated: OS.DataConversion.JSNodeParamConverter.to(actionResults.isAuthenticatedOut, OS.DataTypes.DataTypes.Boolean)
};
});
};
});

define("ShopperPortalEU.controller$CheckOnlyLetters", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU.controller$CheckOnlyLetters.CheckOnlyLettersJS", "ShopperPortalEU.clientVariables"], function (exports, OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_controller_CheckOnlyLetters_CheckOnlyLettersJS, ShopperPortalEUClientVariables) {
var OS = OutSystems.Internal;
ShopperPortalEUController.default.checkOnlyLetters$Action = function (stringIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.CheckOnlyLetters$vars"))());
vars.value.stringInLocal = stringIn;
var checkOnlyLettersJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.CheckOnlyLetters$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.checkOnlyLettersJSResult = checkOnlyLettersJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:Kg4TzPIdgkWrET8dUL04hw:/ClientActionFlows.Kg4TzPIdgkWrET8dUL04hw:xI1Cra88a9FgdEwb899D+Q", "ShopperPortalEU", "CheckOnlyLetters", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ckv0erK9Q0y8IEEVBZcl5A", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:8jul5Jk_iEiBFgQnB7GGgQ", callContext.id);
// Check if a certain string lonly contains letters.
checkOnlyLettersJSResult.value = controller.safeExecuteJSNode(ShopperPortalEU_controller_CheckOnlyLetters_CheckOnlyLettersJS, "CheckOnlyLetters", "CheckOnlyLetters", {
String: OS.DataConversion.JSNodeParamConverter.to(vars.value.stringInLocal, OS.DataTypes.DataTypes.Text),
Invalid: OS.DataConversion.JSNodeParamConverter.to(false, OS.DataTypes.DataTypes.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("ShopperPortalEU.CheckOnlyLetters$checkOnlyLettersJSResult"))();
jsNodeResult.invalidOut = OS.DataConversion.JSNodeParamConverter.from($parameters.Invalid, OS.DataTypes.DataTypes.Boolean);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:H+u9VYPJLUOC_q2813pSJg", callContext.id);
// IsValid = notCheckOnlyLetters.Invalid
outVars.value.isValidOut = !(checkOnlyLettersJSResult.value.invalidOut);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:IW4zYsg4RkyZBUNNdVajsw", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:Kg4TzPIdgkWrET8dUL04hw", callContext.id);
}

};
var controller = ShopperPortalEUController.default;
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.CheckOnlyLetters$vars", [{
name: "String",
attrName: "stringInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.CheckOnlyLetters$checkOnlyLettersJSResult", [{
name: "Invalid",
attrName: "invalidOut",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Boolean,
defaultValue: function () {
return false;
}
}]);
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.CheckOnlyLetters$outVars", [{
name: "IsValid",
attrName: "isValidOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Boolean,
defaultValue: function () {
return false;
}
}]);
ShopperPortalEUController.default.clientActionProxies.checkOnlyLetters$Action = function (stringIn) {
stringIn = (stringIn === undefined) ? "" : stringIn;
return controller.executeActionInsideJSNode(ShopperPortalEUController.default.checkOnlyLetters$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(stringIn, OS.DataTypes.DataTypes.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
IsValid: OS.DataConversion.JSNodeParamConverter.to(actionResults.isValidOut, OS.DataTypes.DataTypes.Boolean)
};
});
};
});
define("ShopperPortalEU.controller$CheckOnlyLetters.CheckOnlyLettersJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.Invalid = /[^A-Za-zÀ-ÿ ]+/g.test($parameters.String)
};
});

define("ShopperPortalEU.controller$CheckRedirectShopper", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.controller", "ShopperPortalEU.clientVariables", "ShopperPortalEU_Shopper_IS.model$GetShopperResponseRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS", "ShopperPortalEU.controller$SetShopperClientVariables", "ShopperPortalEU_Shopper_IS.controller$GetShopper", "ShopperPortalEU.controller$RedirectShopper"], function (exports, OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_Shopper_ISModel, ShopperPortalEU_Shopper_ISController, ShopperPortalEUClientVariables) {
var OS = OutSystems.Internal;
ShopperPortalEUController.default.checkRedirectShopper$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var allExceptionsVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.ErrorHandlerOutputType());
var getShopperVar = new OS.DataTypes.VariableHolder();
var redirectShopperVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.CheckRedirectShopper$outVars"))());
varBag.callContext = callContext;
varBag.allExceptionsVar = allExceptionsVar;
varBag.getShopperVar = getShopperVar;
varBag.redirectShopperVar = redirectShopperVar;
varBag.outVars = outVars;
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:I0KkDSFqsEyTwyfdcIZYDQ:/ClientActionFlows.I0KkDSFqsEyTwyfdcIZYDQ:HctupfeG7ClLHNsfVoQTvg", "ShopperPortalEU", "CheckRedirectShopper", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Ig5k+3ycD0Sm0j+yCHNzgg", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Iw_kdFEmdE2eGvrhst86_A", callContext.id);
// Execute Action: GetShopper
return ShopperPortalEU_Shopper_ISController.default.getShopper$Action(ShopperPortalEUClientVariables.getShopperGuid(), callContext).then(function (value) {
getShopperVar.value = value;
}).then(function () {
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:kUWC7BazjU6eMOXULGe88w", callContext.id) && getShopperVar.value.isSuccessOut)) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:n__gcLstw0i55aJFmbLnWQ", callContext.id);
// Execute Action: SetShopperClientVariables
return ShopperPortalEUController.default.setShopperClientVariables$Action(getShopperVar.value.shopperOut, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:CI3n+9nvGUei5n4WdNvdvg", callContext.id);
// Execute Action: RedirectShopper
redirectShopperVar.value = ShopperPortalEUController.default.redirectShopper$Action(getShopperVar.value.shopperOut, callContext);

OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:7yOF39QnJEqePwQb7aNs7Q", callContext.id);
// ShopperChecked = True
ShopperPortalEUClientVariables.setShopperChecked(true);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:7yOF39QnJEqePwQb7aNs7Q", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// AnonymousFormList = ""
ShopperPortalEUClientVariables.setAnonymousFormList("");
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:7yOF39QnJEqePwQb7aNs7Q", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// Redirect = RedirectShopper.Redirect
outVars.value.redirectOut = redirectShopperVar.value.redirectOut;
}).then(function () {
// Redirect  to CompleteDetails ?
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:aa76mbudikuNf1qtoGaT1g", callContext.id) && (outVars.value.redirectOut === 4))) {
// Update vars
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:SQeBsXayxkeSaVFwwQwKcw", callContext.id);
// IsProfileDetailsNavigation = False
ShopperPortalEUClientVariables.setIsProfileDetailsNavigation(false);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:i_ETDBsvkE+xamfHRXUtxg", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:04FF7wIdAkWQANg1gGA7YQ", callContext.id);
}

});
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:XaHiiCU_3UiBc8KedgpTCQ", callContext.id);
// HasError = True
outVars.value.hasErrorOut = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:EKOTRap+9U2Top4lLLmCQw", callContext.id);
}

});
});
}).catch(function (ex) {
OS.Logger.trace("CheckRedirectShopper.CheckRedirectShopper", OS.Exceptions.getMessage(ex), ex.name);
// Handle Error: AllExceptions
if(!(OS.Exceptions.isSystem(ex))) {
OS.Logger.error(null, ex);
allExceptionsVar.value.exceptionMessageAttr = OS.Exceptions.getMessage(ex);
OutSystemsDebugger.handleException(allExceptionsVar.value.exceptionMessageAttr, callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:NgQWNcNvx02QvZFgWcj0HA", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:gHxmspwwCUe1Wg6uzU2A6Q", callContext.id);
// HasError = True
outVars.value.hasErrorOut = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:t0iahyZZvkC_3haVkWJAEw", callContext.id);
return OS.Flow.returnAsync(outVars.value);

});
}

throw ex;
}).then(function () {
return outVars.value;
}).then(function (res) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:I0KkDSFqsEyTwyfdcIZYDQ", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:I0KkDSFqsEyTwyfdcIZYDQ", callContext.id);
throw ex;

});
};
var controller = ShopperPortalEUController.default;
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.CheckRedirectShopper$outVars", [{
name: "HasError",
attrName: "hasErrorOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "Redirect",
attrName: "redirectOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Integer,
defaultValue: function () {
return (false ? 1 : 0);
}
}]);
ShopperPortalEUController.default.clientActionProxies.checkRedirectShopper$Action = function () {
return controller.executeActionInsideJSNode(ShopperPortalEUController.default.checkRedirectShopper$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasError: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasErrorOut, OS.DataTypes.DataTypes.Boolean),
Redirect: OS.DataConversion.JSNodeParamConverter.to(actionResults.redirectOut, OS.DataTypes.DataTypes.Integer)
};
});
};
});

define("ShopperPortalEU.controller$CheckValidCard", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.clientVariables", "ShopperPortalEU_UI_Components.model$DatatransCardChangeOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUClientVariables) {
var OS = OutSystems.Internal;
ShopperPortalEUController.default.checkValidCard$Action = function (cardExpiryDateIn, cardDetailsDataIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.CheckValidCard$vars"))());
vars.value.cardExpiryDateInLocal = cardExpiryDateIn;
vars.value.cardDetailsDataInLocal = cardDetailsDataIn.clone();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.CheckValidCard$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:0TaKAaEr9UWi7rP0lUZ+Jw:/ClientActionFlows.0TaKAaEr9UWi7rP0lUZ+Jw:u4dh96toBaDHUKbtJEKPOg", "ShopperPortalEU", "CheckValidCard", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ukzpOCYXWk+NFKnu6d239w", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ae4fvqSfFUGt_9QLDssDCQ", callContext.id);
// IsValid = True
outVars.value.isValidOut = true;
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:YiW4n6MvhUOHJEw71fPwgA", callContext.id) && vars.value.cardDetailsDataInLocal.isValidAttr)) {
// Valid card type
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:4fSXNwWuYEaNzpcrLIqB0Q", callContext.id) && ((((((vars.value.cardDetailsDataInLocal.paymentMethodAttr === "AMX") || (vars.value.cardDetailsDataInLocal.paymentMethodAttr === "CUP")) || (vars.value.cardDetailsDataInLocal.paymentMethodAttr === "ECA")) || (vars.value.cardDetailsDataInLocal.paymentMethodAttr === "JCB")) || (vars.value.cardDetailsDataInLocal.paymentMethodAttr === "VIS")) || (vars.value.cardDetailsDataInLocal.paymentMethodAttr === "VPI")))) {
// ExpiryDate not null
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:847idEnuMky97kax1TalJg", callContext.id) && !(vars.value.cardExpiryDateInLocal.equals(OS.BuiltinFunctions.nullDate())))) {
// ExpiryDate > CurrDate 
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:OUcOdzlfeUebnQR_aTVEag", callContext.id) && OS.BuiltinFunctions.dateToDateTime(vars.value.cardExpiryDateInLocal).gt(OS.BuiltinFunctions.currDateTime()))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:xlN90jUm7UyCqIFZG5La2w", callContext.id);
} else {
// ErrorMessage
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:SQNHK+y_Q0qP8JLKKztS0g", callContext.id);
// ErrorMessage = "Enter a valid date of expiry"
outVars.value.errorMessageOut = "Enter a valid date of expiry";
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:SQNHK+y_Q0qP8JLKKztS0g", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// IsValid = False
outVars.value.isValidOut = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:SQNHK+y_Q0qP8JLKKztS0g", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// IsExpiryDateError = True
outVars.value.isExpiryDateErrorOut = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:89IB84A5JUqPqHwPsw4R9w", callContext.id);
}

} else {
// ErrorMessage
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:RTIGsOkYAkucqcA6btnWGw", callContext.id);
// ErrorMessage = "Enter the date of expiry"
outVars.value.errorMessageOut = "Enter the date of expiry";
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:RTIGsOkYAkucqcA6btnWGw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// IsValid = False
outVars.value.isValidOut = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:RTIGsOkYAkucqcA6btnWGw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// IsExpiryDateError = True
outVars.value.isExpiryDateErrorOut = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:KFJYUkvtf0mUm8dkcnxmYQ", callContext.id);
}

} else {
// ErrorMessage
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:eM9XFMCuWEeiRt6X6KSfKw", callContext.id);
// IsValid = False
outVars.value.isValidOut = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:eM9XFMCuWEeiRt6X6KSfKw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// ErrorMessage = "This card type is not accepted. Please use Visa, Amex, JCB, Mastercard, or UnionPay."
outVars.value.errorMessageOut = "This card type is not accepted. Please use Visa, Amex, JCB, Mastercard, or UnionPay.";
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:HqaupdyyjE+ygNEybWjy+Q", callContext.id);
}

} else {
// ErrorMessage
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:wFq1jS4IFUK3vCvuOQd5qg", callContext.id);
// IsValid = False
outVars.value.isValidOut = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:wFq1jS4IFUK3vCvuOQd5qg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// ErrorMessage = "Enter a valid card number"
outVars.value.errorMessageOut = "Enter a valid card number";
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:VOhlTyVlFUq_SDImZR5_Tg", callContext.id);
}

return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:0TaKAaEr9UWi7rP0lUZ+Jw", callContext.id);
}

};
var controller = ShopperPortalEUController.default;
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.CheckValidCard$vars", [{
name: "CardExpiryDate",
attrName: "cardExpiryDateInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Date,
defaultValue: function () {
return OS.DataTypes.DateTime.defaultValue;
}
}, {
name: "CardDetailsData",
attrName: "cardDetailsDataInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Record,
defaultValue: function () {
return new ShopperPortalEU_UI_ComponentsModel.DatatransCardChangeOptionsRec();
},
complexType: ShopperPortalEU_UI_ComponentsModel.DatatransCardChangeOptionsRec
}]);
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.CheckValidCard$outVars", [{
name: "IsValid",
attrName: "isValidOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "ErrorMessage",
attrName: "errorMessageOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}, {
name: "IsExpiryDateError",
attrName: "isExpiryDateErrorOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Boolean,
defaultValue: function () {
return false;
}
}]);
ShopperPortalEUController.default.clientActionProxies.checkValidCard$Action = function (cardExpiryDateIn, cardDetailsDataIn) {
cardExpiryDateIn = (cardExpiryDateIn === undefined) ? OS.DataTypes.DateTime.defaultValue : cardExpiryDateIn;
cardDetailsDataIn = (cardDetailsDataIn === undefined) ? new ShopperPortalEU_UI_ComponentsModel.DatatransCardChangeOptionsRec() : cardDetailsDataIn;
return controller.executeActionInsideJSNode(ShopperPortalEUController.default.checkValidCard$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(cardExpiryDateIn, OS.DataTypes.DataTypes.Date), cardDetailsDataIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
IsValid: OS.DataConversion.JSNodeParamConverter.to(actionResults.isValidOut, OS.DataTypes.DataTypes.Boolean),
ErrorMessage: OS.DataConversion.JSNodeParamConverter.to(actionResults.errorMessageOut, OS.DataTypes.DataTypes.Text),
IsExpiryDateError: OS.DataConversion.JSNodeParamConverter.to(actionResults.isExpiryDateErrorOut, OS.DataTypes.DataTypes.Boolean)
};
});
};
});

define("ShopperPortalEU.controller$ClarityEvent", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU.controller$ClarityEvent.ClarityEventJS", "ShopperPortalEU.clientVariables"], function (exports, OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_controller_ClarityEvent_ClarityEventJS, ShopperPortalEUClientVariables) {
var OS = OutSystems.Internal;
ShopperPortalEUController.default.clarityEvent$Action = function (nameIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.ClarityEvent$vars"))());
vars.value.nameInLocal = nameIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:1IJ65mVD_k6FD2PRcKfbbw:/ClientActionFlows.1IJ65mVD_k6FD2PRcKfbbw:w6dIWv1WoQyTETfmqSgC9Q", "ShopperPortalEU", "ClarityEvent", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:zgKX8lEzek2kmMYmK_fyzg", callContext.id);
// Has event name
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:RvDE6EPDdk+8bN0T1psMRg", callContext.id) && ((vars.value.nameInLocal) !== ("")))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:zhA1lsK9Pku99aRL5zopmw", callContext.id);
controller.safeExecuteJSNode(ShopperPortalEU_controller_ClarityEvent_ClarityEventJS, "ClarityEvent", "ClarityEvent", {
Name: OS.DataConversion.JSNodeParamConverter.to(vars.value.nameInLocal, OS.DataTypes.DataTypes.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:SEjupst4l0in1BvB__FuRQ", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:4pYMbpfuAE6MBSdBJmTyzQ", callContext.id);
}

return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:1IJ65mVD_k6FD2PRcKfbbw", callContext.id);
}

};
var controller = ShopperPortalEUController.default;
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.ClarityEvent$vars", [{
name: "Name",
attrName: "nameInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEUController.default.clientActionProxies.clarityEvent$Action = function (nameIn) {
nameIn = (nameIn === undefined) ? "" : nameIn;
return controller.executeActionInsideJSNode(ShopperPortalEUController.default.clarityEvent$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(nameIn, OS.DataTypes.DataTypes.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("ShopperPortalEU.controller$ClarityEvent.ClarityEventJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
if (window.clarity) {
  window.clarity('event', $parameters.Name);
}

};
});

define("ShopperPortalEU.controller$ClarityEventPassportAlreadyExists", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU.clientVariables", "ShopperPortalEU.controller$ClarityEvent"], function (exports, OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEUClientVariables) {
var OS = OutSystems.Internal;
ShopperPortalEUController.default.clarityEventPassportAlreadyExists$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:+UBpsJHKNU+9USt5qDKeAg:/ClientActionFlows.+UBpsJHKNU+9USt5qDKeAg:s9EEBvn0AVzLy6SG8raQpg", "ShopperPortalEU", "ClarityEventPassportAlreadyExists", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:8rUJnspCn0WYpVSwaCQ8bQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:QP5q9mW5aUSWXYkPeeZUIA", callContext.id);
// Execute Action: ClarityPassport
ShopperPortalEUController.default.clarityEvent$Action("PassportAlreadyExists_error", callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:EtsA3vFVh0e_GvOm+buCHg", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:+UBpsJHKNU+9USt5qDKeAg", callContext.id);
}

};
var controller = ShopperPortalEUController.default;
ShopperPortalEUController.default.clientActionProxies.clarityEventPassportAlreadyExists$Action = function () {
return controller.executeActionInsideJSNode(ShopperPortalEUController.default.clarityEventPassportAlreadyExists$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});

define("ShopperPortalEU.controller$DefaultErrorMessage", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU.clientVariables"], function (exports, OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEUClientVariables) {
var OS = OutSystems.Internal;
ShopperPortalEUController.default.defaultErrorMessage$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.DefaultErrorMessage$outVars"))());
varBag.callContext = callContext;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:fv3pPUggb0uQmHMok7kUXA:/ClientActionFlows.fv3pPUggb0uQmHMok7kUXA:GGeLD0Lu0VGJZedKs_5E8g", "ShopperPortalEU", "DefaultErrorMessage", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ZVLDzmYyZEiwskfTFbpFCg", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:dkaTDeS9LkOp7yKo6+_0Yw", callContext.id);
// ErrorMessage = "Please try again or <a href='/ShopperPortalEU/Help'>contact Customer Support</a> for assistance."
outVars.value.errorMessageOut = "Please try again or <a href=\'/ShopperPortalEU/Help\'>contact Customer Support</a> for assistance.";
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:mE9doVMrKkuSBrGun7ArKA", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:fv3pPUggb0uQmHMok7kUXA", callContext.id);
}

};
var controller = ShopperPortalEUController.default;
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.DefaultErrorMessage$outVars", [{
name: "ErrorMessage",
attrName: "errorMessageOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEUController.default.clientActionProxies.defaultErrorMessage$Action = function () {
return controller.executeActionInsideJSNode(ShopperPortalEUController.default.defaultErrorMessage$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
ErrorMessage: OS.DataConversion.JSNodeParamConverter.to(actionResults.errorMessageOut, OS.DataTypes.DataTypes.Text)
};
});
};
});

define("ShopperPortalEU.controller$FormatCardHolderName", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU.controller$FormatCardHolderName.RegexCardHolderNameInputJS", "ShopperPortalEU.clientVariables"], function (exports, OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_controller_FormatCardHolderName_RegexCardHolderNameInputJS, ShopperPortalEUClientVariables) {
var OS = OutSystems.Internal;
ShopperPortalEUController.default.formatCardHolderName$Action = function (inputIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.FormatCardHolderName$vars"))());
vars.value.inputInLocal = inputIn;
var regexCardHolderNameInputJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.FormatCardHolderName$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.regexCardHolderNameInputJSResult = regexCardHolderNameInputJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:HvFiR4EaBkaxU76TSddvYg:/ClientActionFlows.HvFiR4EaBkaxU76TSddvYg:q+Og4k2jSvb6_c4KtD_Ryg", "ShopperPortalEU", "FormatCardHolderName", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:fabzAo0dMk6Edp1+YnDu8A", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:9uCWj3HMwkeSgRHTsxvLEA", callContext.id);
regexCardHolderNameInputJSResult.value = controller.safeExecuteJSNode(ShopperPortalEU_controller_FormatCardHolderName_RegexCardHolderNameInputJS, "RegexCardHolderNameInput", "FormatCardHolderName", {
Input: OS.DataConversion.JSNodeParamConverter.to(vars.value.inputInLocal, OS.DataTypes.DataTypes.Text),
RegexResult: OS.DataConversion.JSNodeParamConverter.to("", OS.DataTypes.DataTypes.Text)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("ShopperPortalEU.FormatCardHolderName$regexCardHolderNameInputJSResult"))();
jsNodeResult.regexResultOut = OS.DataConversion.JSNodeParamConverter.from($parameters.RegexResult, OS.DataTypes.DataTypes.Text);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:53M3uCIiL0ypCiCYSroXXg", callContext.id);
// Output = RegexCardHolderNameInput.RegexResult
outVars.value.outputOut = regexCardHolderNameInputJSResult.value.regexResultOut;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:3vMZVv_y40O9zetA4lF0XA", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:HvFiR4EaBkaxU76TSddvYg", callContext.id);
}

};
var controller = ShopperPortalEUController.default;
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.FormatCardHolderName$vars", [{
name: "Input",
attrName: "inputInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.FormatCardHolderName$regexCardHolderNameInputJSResult", [{
name: "RegexResult",
attrName: "regexResultOut",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.FormatCardHolderName$outVars", [{
name: "Output",
attrName: "outputOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEUController.default.clientActionProxies.formatCardHolderName$Action = function (inputIn) {
inputIn = (inputIn === undefined) ? "" : inputIn;
return controller.executeActionInsideJSNode(ShopperPortalEUController.default.formatCardHolderName$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(inputIn, OS.DataTypes.DataTypes.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Output: OS.DataConversion.JSNodeParamConverter.to(actionResults.outputOut, OS.DataTypes.DataTypes.Text)
};
});
};
});
define("ShopperPortalEU.controller$FormatCardHolderName.RegexCardHolderNameInputJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.RegexResult  = $parameters.Input.replace(/[^a-zA-Z ]/g,'');
};
});

define("ShopperPortalEU.controller$FormatDate", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU.clientVariables", "ShopperPortalEU.controller$FormatEmptyString"], function (exports, OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEUClientVariables) {
var OS = OutSystems.Internal;
ShopperPortalEUController.default.formatDate$Action = function (dateIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.FormatDate$vars"))());
vars.value.dateInLocal = dateIn;
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.FormatDate$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:4U3JlefSh06uM2hP+YK5mA:/ClientActionFlows.4U3JlefSh06uM2hP+YK5mA:L8Nh83XrjAg9dzrbVYPhLA", "ShopperPortalEU", "FormatDate", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:0cdhvcksqkCtFPwy3GhurA", callContext.id);
// Has date
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:UcFF86k+VkiQK1OzCmyN4A", callContext.id) && !(vars.value.dateInLocal.equals(OS.BuiltinFunctions.nullDate())))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:iVpT2evXr0eKAHQfHRbx+w", callContext.id);
// FormattedDate = FormatDateTime
outVars.value.formattedDateOut = OS.BuiltinFunctions.formatDateTime(vars.value.dateInLocal, "dd/MM/yyyy");
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:i8e_k_SwJ0WZbNYW5coYDQ", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:wzQwwriJ4kSxEF+Gam_M6Q", callContext.id);
// FormattedDate = FormatEmptyString("")
outVars.value.formattedDateOut = OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.formatEmptyString$Action("", callContext).formattedStringOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:X4paD8MO6E2JsCGTX2noTw", callContext.id);
}

return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:4U3JlefSh06uM2hP+YK5mA", callContext.id);
}

};
var controller = ShopperPortalEUController.default;
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.FormatDate$vars", [{
name: "Date",
attrName: "dateInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Date,
defaultValue: function () {
return OS.DataTypes.DateTime.defaultValue;
}
}]);
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.FormatDate$outVars", [{
name: "FormattedDate",
attrName: "formattedDateOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEUController.default.clientActionProxies.formatDate$Action = function (dateIn) {
dateIn = (dateIn === undefined) ? OS.DataTypes.DateTime.defaultValue : dateIn;
return controller.executeActionInsideJSNode(ShopperPortalEUController.default.formatDate$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(dateIn, OS.DataTypes.DataTypes.Date)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
FormattedDate: OS.DataConversion.JSNodeParamConverter.to(actionResults.formattedDateOut, OS.DataTypes.DataTypes.Text)
};
});
};
});

define("ShopperPortalEU.controller$FormatEmptyString", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU.clientVariables"], function (exports, OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEUClientVariables) {
var OS = OutSystems.Internal;
ShopperPortalEUController.default.formatEmptyString$Action = function (stringIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.FormatEmptyString$vars"))());
vars.value.stringInLocal = stringIn;
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.FormatEmptyString$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:ugOqKQAtyE642XLKFK9HSA:/ClientActionFlows.ugOqKQAtyE642XLKFK9HSA:ieWzQ2LwokBfmx+SbmMhFw", "ShopperPortalEU", "FormatEmptyString", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:pa6Fbh3dd0CJdyz8_B4WTA", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:awlNvYWvj0G2LmOzglU_CA", callContext.id);
// FormattedString = If
outVars.value.formattedStringOut = (((OS.BuiltinFunctions.trim(vars.value.stringInLocal) === "")) ? ("—") : (vars.value.stringInLocal));
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:CpSQznR8qUSUiefsprk9rA", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:ugOqKQAtyE642XLKFK9HSA", callContext.id);
}

};
var controller = ShopperPortalEUController.default;
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.FormatEmptyString$vars", [{
name: "String",
attrName: "stringInLocal",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.FormatEmptyString$outVars", [{
name: "FormattedString",
attrName: "formattedStringOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEUController.default.clientActionProxies.formatEmptyString$Action = function (stringIn) {
stringIn = (stringIn === undefined) ? "" : stringIn;
return controller.executeActionInsideJSNode(ShopperPortalEUController.default.formatEmptyString$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(stringIn, OS.DataTypes.DataTypes.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
FormattedString: OS.DataConversion.JSNodeParamConverter.to(actionResults.formattedStringOut, OS.DataTypes.DataTypes.Text)
};
});
};
});

define("ShopperPortalEU.controller$FormatLocationHours", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU.controller$FormatLocationHours.FormatLocationHoursJS", "ShopperPortalEU.clientVariables"], function (exports, OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_controller_FormatLocationHours_FormatLocationHoursJS, ShopperPortalEUClientVariables) {
var OS = OutSystems.Internal;
ShopperPortalEUController.default.formatLocationHours$Action = function (locationHoursIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.FormatLocationHours$vars"))());
vars.value.locationHoursInLocal = locationHoursIn;
var formatLocationHoursJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.FormatLocationHours$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.formatLocationHoursJSResult = formatLocationHoursJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:Rc6WawF9n0Ca4blyiJN8Ww:/ClientActionFlows.Rc6WawF9n0Ca4blyiJN8Ww:E1G0hxbYmo4bOYgqt0QmIg", "ShopperPortalEU", "FormatLocationHours", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:wwvtAFsAHky90AAv8U_3mA", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:q8XpTkOQJUGvajVjWsM19w", callContext.id);
formatLocationHoursJSResult.value = controller.safeExecuteJSNode(ShopperPortalEU_controller_FormatLocationHours_FormatLocationHoursJS, "FormatLocationHours", "FormatLocationHours", {
locationHours: OS.DataConversion.JSNodeParamConverter.to(OS.BuiltinFunctions.replace(vars.value.locationHoursInLocal, " ", ""), OS.DataTypes.DataTypes.Text),
formattedLocationHours: OS.DataConversion.JSNodeParamConverter.to("", OS.DataTypes.DataTypes.Text)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("ShopperPortalEU.FormatLocationHours$formatLocationHoursJSResult"))();
jsNodeResult.formattedLocationHoursOut = OS.DataConversion.JSNodeParamConverter.from($parameters.formattedLocationHours, OS.DataTypes.DataTypes.Text);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:fVm4NAWcwEqB_NOLh0tWQw", callContext.id);
// FormattedLocationHours = FormatLocationHours.formattedLocationHours
outVars.value.formattedLocationHoursOut = formatLocationHoursJSResult.value.formattedLocationHoursOut;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:wBK3yZiJmkeuokzVTYnHsA", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:Rc6WawF9n0Ca4blyiJN8Ww", callContext.id);
}

};
var controller = ShopperPortalEUController.default;
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.FormatLocationHours$vars", [{
name: "LocationHours",
attrName: "locationHoursInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.FormatLocationHours$formatLocationHoursJSResult", [{
name: "formattedLocationHours",
attrName: "formattedLocationHoursOut",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.FormatLocationHours$outVars", [{
name: "FormattedLocationHours",
attrName: "formattedLocationHoursOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEUController.default.clientActionProxies.formatLocationHours$Action = function (locationHoursIn) {
locationHoursIn = (locationHoursIn === undefined) ? "" : locationHoursIn;
return controller.executeActionInsideJSNode(ShopperPortalEUController.default.formatLocationHours$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(locationHoursIn, OS.DataTypes.DataTypes.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
FormattedLocationHours: OS.DataConversion.JSNodeParamConverter.to(actionResults.formattedLocationHoursOut, OS.DataTypes.DataTypes.Text)
};
});
};
});
define("ShopperPortalEU.controller$FormatLocationHours.FormatLocationHoursJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
const input = $parameters.locationHours;

function formatOperationHours(text) {
    return text
        .replace(/0(?=[a-zA-Z])/g, '0<br>')    // Insert <br> after '0' followed by a letter
        .replace(/5(?=[a-zA-Z])/g, '5<br>')    // Insert <br> after '5' followed by a letter
        .replace(/sed/g, 'sed<br>')            // Insert <br> after 'sed'
        .replace(/y:/g, 'y: ');                // Add a space after 'y:'
}

$parameters.formattedLocationHours = formatOperationHours(input);
};
});

define("ShopperPortalEU.controller$FormatMaskedCard", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU.clientVariables"], function (exports, OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEUClientVariables) {
var OS = OutSystems.Internal;
ShopperPortalEUController.default.formatMaskedCard$Action = function (maskedCardIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.FormatMaskedCard$vars"))());
vars.value.maskedCardInLocal = maskedCardIn;
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.FormatMaskedCard$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:rqr0NrTyTkerpo2t50gfVQ:/ClientActionFlows.rqr0NrTyTkerpo2t50gfVQ:wzMIKyVzg1+QCNdB9sKulw", "ShopperPortalEU", "FormatMaskedCard", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:6L4mhW4Y7EOZEThZgAVPBA", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:7nuLfHzUmkaLjZKs27q1qg", callContext.id);
// Output = Substr + " " + Substr + " " + Substr + " " + Substr + " " + Substr
outVars.value.outputOut = ((((((((OS.BuiltinFunctions.substr(vars.value.maskedCardInLocal, 0, 4) + " ") + OS.BuiltinFunctions.substr(vars.value.maskedCardInLocal, 4, 4)) + " ") + OS.BuiltinFunctions.substr(vars.value.maskedCardInLocal, 8, 4)) + " ") + OS.BuiltinFunctions.substr(vars.value.maskedCardInLocal, 12, 4)) + " ") + OS.BuiltinFunctions.substr(vars.value.maskedCardInLocal, 16, 4));
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Mp+HHUPp0EmcA+4NvrUaQA", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:rqr0NrTyTkerpo2t50gfVQ", callContext.id);
}

};
var controller = ShopperPortalEUController.default;
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.FormatMaskedCard$vars", [{
name: "MaskedCard",
attrName: "maskedCardInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.FormatMaskedCard$outVars", [{
name: "Output",
attrName: "outputOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEUController.default.clientActionProxies.formatMaskedCard$Action = function (maskedCardIn) {
maskedCardIn = (maskedCardIn === undefined) ? "" : maskedCardIn;
return controller.executeActionInsideJSNode(ShopperPortalEUController.default.formatMaskedCard$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(maskedCardIn, OS.DataTypes.DataTypes.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Output: OS.DataConversion.JSNodeParamConverter.to(actionResults.outputOut, OS.DataTypes.DataTypes.Text)
};
});
};
});

define("ShopperPortalEU.controller$FormatPassportData", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.clientVariables", "ShopperPortalEU_UI_Components.model$ScanPassportDataRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU.model$ScanPassportRec", "ShopperPortalEU.controller$ServerAction.FormatPassportData"], function (exports, OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUClientVariables) {
var OS = OutSystems.Internal;
ShopperPortalEUController.default.formatPassportData$Action = function (passportIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.FormatPassportData$vars"))());
vars.value.passportInLocal = passportIn.clone();
var formatPassportDataVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.FormatPassportData$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.formatPassportDataVar = formatPassportDataVar;
varBag.outVars = outVars;
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:+fwJSf0DUE21XyXZIyNe7Q:/ClientActionFlows.+fwJSf0DUE21XyXZIyNe7Q:hwVHaUiTxvli8zLG8LbpPw", "ShopperPortalEU", "FormatPassportData", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:4b5Te6c9_0S8OACwTicaAA", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:WQ4Q0OmJBk+n2G7hXqBtNg", callContext.id);
// Execute Action: FormatPassportData
return controller.formatPassportData$ServerAction(vars.value.passportInLocal, callContext).then(function (value) {
formatPassportDataVar.value = value;
}).then(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Dl5GgJGdFkGFGlZBpCPuow", callContext.id);
// FormattedPassport = FormatPassportData.FormattedPassport
outVars.value.formattedPassportOut = formatPassportDataVar.value.formattedPassportOut;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:SgLoSh4WhUm+d69q0807uw", callContext.id);
});
}).then(function () {
return outVars.value;
}).then(function (res) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:+fwJSf0DUE21XyXZIyNe7Q", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:+fwJSf0DUE21XyXZIyNe7Q", callContext.id);
throw ex;

});
};
var controller = ShopperPortalEUController.default;
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.FormatPassportData$vars", [{
name: "Passport",
attrName: "passportInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Record,
defaultValue: function () {
return new ShopperPortalEU_UI_ComponentsModel.ScanPassportDataRec();
},
complexType: ShopperPortalEU_UI_ComponentsModel.ScanPassportDataRec
}]);
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.FormatPassportData$outVars", [{
name: "FormattedPassport",
attrName: "formattedPassportOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Record,
defaultValue: function () {
return new ShopperPortalEUModel.ScanPassportRec();
},
complexType: ShopperPortalEUModel.ScanPassportRec
}]);
ShopperPortalEUController.default.clientActionProxies.formatPassportData$Action = function (passportIn) {
passportIn = (passportIn === undefined) ? new ShopperPortalEU_UI_ComponentsModel.ScanPassportDataRec() : passportIn;
return controller.executeActionInsideJSNode(ShopperPortalEUController.default.formatPassportData$Action.bind(controller, passportIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
FormattedPassport: actionResults.formattedPassportOut
};
});
};
});

define("ShopperPortalEU.controller$FormatShopperName", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU.clientVariables", "ShopperPortalEU.controller$GetFirstLastWord", "ShopperPortalEU.controller$FormatTitleCase"], function (exports, OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEUClientVariables) {
var OS = OutSystems.Internal;
ShopperPortalEUController.default.formatShopperName$Action = function (givenNamesIn, surnameIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.FormatShopperName$vars"))());
vars.value.givenNamesInLocal = givenNamesIn;
vars.value.surnameInLocal = surnameIn;
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.FormatShopperName$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:7UVRAoDAhEOGjC02evOhaQ:/ClientActionFlows.7UVRAoDAhEOGjC02evOhaQ:Wk+K5_C6qnj7ep3desvXHA", "ShopperPortalEU", "FormatShopperName", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:4hTR0G+D6kOmrxZCRBTooQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:0tNZmn_SXEGAwCE37CD8Fg", callContext.id);
// FormattedShopperName = FormatTitleCase(GetFirstLastWord(GivenNames + If))
outVars.value.formattedShopperNameOut = OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.formatTitleCase$Action(OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.getFirstLastWord$Action((vars.value.givenNamesInLocal + ((((vars.value.surnameInLocal) !== (""))) ? ((" " + vars.value.surnameInLocal)) : (""))), callContext).formattedStringOut;
}, OS.DataTypes.DataTypes.Text, callContext.id), callContext).formattedStringOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:6UKKhTAj6kyYtLEh6s5Ypw", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:7UVRAoDAhEOGjC02evOhaQ", callContext.id);
}

};
var controller = ShopperPortalEUController.default;
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.FormatShopperName$vars", [{
name: "GivenNames",
attrName: "givenNamesInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}, {
name: "Surname",
attrName: "surnameInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.FormatShopperName$outVars", [{
name: "FormattedShopperName",
attrName: "formattedShopperNameOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEUController.default.clientActionProxies.formatShopperName$Action = function (givenNamesIn, surnameIn) {
givenNamesIn = (givenNamesIn === undefined) ? "" : givenNamesIn;
surnameIn = (surnameIn === undefined) ? "" : surnameIn;
return controller.executeActionInsideJSNode(ShopperPortalEUController.default.formatShopperName$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(givenNamesIn, OS.DataTypes.DataTypes.Text), OS.DataConversion.JSNodeParamConverter.from(surnameIn, OS.DataTypes.DataTypes.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
FormattedShopperName: OS.DataConversion.JSNodeParamConverter.to(actionResults.formattedShopperNameOut, OS.DataTypes.DataTypes.Text)
};
});
};
});

define("ShopperPortalEU.controller$FormatTitleCase", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU.controller$FormatTitleCase.TitleCaseJS", "ShopperPortalEU.clientVariables"], function (exports, OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_controller_FormatTitleCase_TitleCaseJS, ShopperPortalEUClientVariables) {
var OS = OutSystems.Internal;
ShopperPortalEUController.default.formatTitleCase$Action = function (stringIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.FormatTitleCase$vars"))());
vars.value.stringInLocal = stringIn;
var titleCaseJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.FormatTitleCase$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.titleCaseJSResult = titleCaseJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:AzA924RI_kOBu5fJEYjEGA:/ClientActionFlows.AzA924RI_kOBu5fJEYjEGA:angzB_B7WBTp_WK0eWFYRA", "ShopperPortalEU", "FormatTitleCase", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:bM10MELzy0+rqebY+SA7MQ", callContext.id);
// Has string
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:C9Qv3C58dEmIfFq62gmwwA", callContext.id) && ((OS.BuiltinFunctions.trim(vars.value.stringInLocal)) !== ("")))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:oA9R6Q8mnE2dNjmdVL_ZAg", callContext.id);
// Format string 
titleCaseJSResult.value = controller.safeExecuteJSNode(ShopperPortalEU_controller_FormatTitleCase_TitleCaseJS, "TitleCase", "FormatTitleCase", {
String: OS.DataConversion.JSNodeParamConverter.to(vars.value.stringInLocal, OS.DataTypes.DataTypes.Text),
FormattedString: OS.DataConversion.JSNodeParamConverter.to("", OS.DataTypes.DataTypes.Text)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("ShopperPortalEU.FormatTitleCase$titleCaseJSResult"))();
jsNodeResult.formattedStringOut = OS.DataConversion.JSNodeParamConverter.from($parameters.FormattedString, OS.DataTypes.DataTypes.Text);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:cLlWImBsS0+X8rbmPFERIw", callContext.id);
// FormattedString = TitleCase.FormattedString
outVars.value.formattedStringOut = titleCaseJSResult.value.formattedStringOut;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:WpLPCNkNM0SOrIVz4lU8hw", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:JZrEyKhYakeLn3C_s4e1tA", callContext.id);
}

return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:AzA924RI_kOBu5fJEYjEGA", callContext.id);
}

};
var controller = ShopperPortalEUController.default;
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.FormatTitleCase$vars", [{
name: "String",
attrName: "stringInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.FormatTitleCase$titleCaseJSResult", [{
name: "FormattedString",
attrName: "formattedStringOut",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.FormatTitleCase$outVars", [{
name: "FormattedString",
attrName: "formattedStringOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEUController.default.clientActionProxies.formatTitleCase$Action = function (stringIn) {
stringIn = (stringIn === undefined) ? "" : stringIn;
return controller.executeActionInsideJSNode(ShopperPortalEUController.default.formatTitleCase$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(stringIn, OS.DataTypes.DataTypes.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
FormattedString: OS.DataConversion.JSNodeParamConverter.to(actionResults.formattedStringOut, OS.DataTypes.DataTypes.Text)
};
});
};
});
define("ShopperPortalEU.controller$FormatTitleCase.TitleCaseJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.FormattedString = $parameters.String.toLowerCase().replace(/\b\w/g, s => s.toUpperCase());
};
});

define("ShopperPortalEU.controller$GenericErrorMessage", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU.clientVariables"], function (exports, OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEUClientVariables) {
var OS = OutSystems.Internal;
ShopperPortalEUController.default.genericErrorMessage$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.GenericErrorMessage$outVars"))());
varBag.callContext = callContext;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:gKEuZ4tla0SlYrT3SRGPjw:/ClientActionFlows.gKEuZ4tla0SlYrT3SRGPjw:eY20h49GhxDGZY8TpLYeYA", "ShopperPortalEU", "GenericErrorMessage", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:XmlP8VrHZ0a+IO_ZA0Qk8w", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:f+lM7wN5QU+BdsK5UC90Kg", callContext.id);
// ErrorMessage = "Please try again or <a href='https://www.planetpayment.com/contact-us'>contact Customer Support</a> for assistance."
outVars.value.errorMessageOut = "Please try again or <a href=\'https://www.planetpayment.com/contact-us\'>contact Customer Support</a> for assistance.";
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:5LK4L8qyLU+dbO6T93JLUw", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:gKEuZ4tla0SlYrT3SRGPjw", callContext.id);
}

};
var controller = ShopperPortalEUController.default;
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.GenericErrorMessage$outVars", [{
name: "ErrorMessage",
attrName: "errorMessageOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEUController.default.clientActionProxies.genericErrorMessage$Action = function () {
return controller.executeActionInsideJSNode(ShopperPortalEUController.default.genericErrorMessage$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
ErrorMessage: OS.DataConversion.JSNodeParamConverter.to(actionResults.errorMessageOut, OS.DataTypes.DataTypes.Text)
};
});
};
});

define("ShopperPortalEU.controller$GetAnonymousFormsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU.clientVariables", "ShopperPortalEU.controller$SplitString", "ShopperPortalEU.model$AnonymousFormsRec", "ShopperPortalEU.model$AnonymousFormsList"], function (exports, OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEUClientVariables) {
var OS = OutSystems.Internal;
ShopperPortalEUController.default.getAnonymousFormsList$Action = function (anonymousFormsStirngIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.GetAnonymousFormsList$vars"))());
vars.value.anonymousFormsStirngInLocal = anonymousFormsStirngIn;
var splitStringVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.GetAnonymousFormsList$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.splitStringVar = splitStringVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:Itr68VdUrESGcSiJ9yagrg:/ClientActionFlows.Itr68VdUrESGcSiJ9yagrg:5bCtpL5KhJHKvj_ZjNE6Zw", "ShopperPortalEU", "GetAnonymousFormsList", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:QdixLuC57UGneJtZxVmrow", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:GIAMXEoe+0ak4tYzFoqrcg", callContext.id);
// Execute Action: SplitString
splitStringVar.value = ShopperPortalEUController.default.splitString$Action(vars.value.anonymousFormsStirngInLocal, ",", callContext);

OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:qY5P5i5BpE2nYzkT+nI3hw", callContext.id);
// FormNumber_AttemptNrList = SplitString.List
vars.value.formNumber_AttemptNrListVar = splitStringVar.value.listOut;
// Foreach FormNumber_AttemptNrList
callContext.iterationContext.registerIterationStart(vars.value.formNumber_AttemptNrListVar);
try {var formNumber_AttemptNrListIterator = callContext.iterationContext.getIterator(vars.value.formNumber_AttemptNrListVar);
var formNumber_AttemptNrListIndex = 0;
while ((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:jcteVrQFtUWFGAEizeivbg", callContext.id) && (formNumber_AttemptNrListIndex < vars.value.formNumber_AttemptNrListVar.length))) {
formNumber_AttemptNrListIterator.currentRowNumber = formNumber_AttemptNrListIndex;
// ClearLocal
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:3F4WaEvPwkSENqqBLZXVOg", callContext.id);
// AnonymousForm.FormNumber = ""
vars.value.anonymousFormVar.formNumberAttr = "";
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:3F4WaEvPwkSENqqBLZXVOg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// AnonymousForm.AttempNr = ""
vars.value.anonymousFormVar.attempNrAttr = "";
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:3F4WaEvPwkSENqqBLZXVOg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// FormNumber_AttemptNr = FormNumber_AttemptNrList.Current
vars.value.formNumber_AttemptNrVar = vars.value.formNumber_AttemptNrListVar.getItem(formNumber_AttemptNrListIndex.valueOf());
// Update AnonymousForm
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:368BM1zpoEyboqSiuI36IA", callContext.id);
// AnonymousForm.AttempNr = Substr
vars.value.anonymousFormVar.attempNrAttr = OS.BuiltinFunctions.substr(vars.value.formNumber_AttemptNrListVar.getItem(formNumber_AttemptNrListIndex.valueOf()), (OS.BuiltinFunctions.index(vars.value.formNumber_AttemptNrListVar.getItem(formNumber_AttemptNrListIndex.valueOf()), "_", 0, false, false) + 1), 1);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:368BM1zpoEyboqSiuI36IA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// AnonymousForm.FormNumber = Substr
vars.value.anonymousFormVar.formNumberAttr = OS.BuiltinFunctions.substr(vars.value.formNumber_AttemptNrListVar.getItem(formNumber_AttemptNrListIndex.valueOf()), 0, (OS.BuiltinFunctions.length(vars.value.formNumber_AttemptNrListVar.getItem(formNumber_AttemptNrListIndex.valueOf())) - 2));
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:uFWxmARvrUadN+Njd1WEOQ", callContext.id);
// Execute Action: ListAppend
OS.SystemActions.listAppend(outVars.value.anonymousFormsListOut, function () {
var rec = new ShopperPortalEUModel.AnonymousFormsRec();
rec.formNumberAttr = vars.value.anonymousFormVar.formNumberAttr;
rec.attempNrAttr = vars.value.anonymousFormVar.attempNrAttr;
return rec;
}(), callContext);
formNumber_AttemptNrListIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(vars.value.formNumber_AttemptNrListVar);
}

OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:xPDgND3EcE2jo0RsnrwW0g", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:Itr68VdUrESGcSiJ9yagrg", callContext.id);
}

};
var controller = ShopperPortalEUController.default;
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.GetAnonymousFormsList$vars", [{
name: "AnonymousFormsStirng",
attrName: "anonymousFormsStirngInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}, {
name: "AnonymousForm",
attrName: "anonymousFormVar",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Record,
defaultValue: function () {
return new ShopperPortalEUModel.AnonymousFormsRec();
},
complexType: ShopperPortalEUModel.AnonymousFormsRec
}, {
name: "FormNumber_AttemptNr",
attrName: "formNumber_AttemptNrVar",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}, {
name: "FormNumber_AttemptNrList",
attrName: "formNumber_AttemptNrListVar",
mandatory: false,
dataType: OS.DataTypes.DataTypes.RecordList,
defaultValue: function () {
return new OS.DataTypes.TextList();
},
complexType: OS.DataTypes.TextList
}]);
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.GetAnonymousFormsList$outVars", [{
name: "AnonymousFormsList",
attrName: "anonymousFormsListOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.RecordList,
defaultValue: function () {
return new ShopperPortalEUModel.AnonymousFormsList();
},
complexType: ShopperPortalEUModel.AnonymousFormsList
}]);
ShopperPortalEUController.default.clientActionProxies.getAnonymousFormsList$Action = function (anonymousFormsStirngIn) {
anonymousFormsStirngIn = (anonymousFormsStirngIn === undefined) ? "" : anonymousFormsStirngIn;
return controller.executeActionInsideJSNode(ShopperPortalEUController.default.getAnonymousFormsList$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(anonymousFormsStirngIn, OS.DataTypes.DataTypes.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
AnonymousFormsList: actionResults.anonymousFormsListOut
};
});
};
});

define("ShopperPortalEU.controller$GetCountryName", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU.controller$GetCountryName.getCountryNameJS", "ShopperPortalEU.clientVariables"], function (exports, OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_controller_GetCountryName_getCountryNameJS, ShopperPortalEUClientVariables) {
var OS = OutSystems.Internal;
ShopperPortalEUController.default.getCountryName$Action = function (codeIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.GetCountryName$vars"))());
vars.value.codeInLocal = codeIn;
var getCountryNameJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.GetCountryName$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.getCountryNameJSResult = getCountryNameJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:e+SBDSn+0EK2v7rR9zCUGA:/ClientActionFlows.e+SBDSn+0EK2v7rR9zCUGA:aqyZG6eyohjyQSAxmQ2OQg", "ShopperPortalEU", "GetCountryName", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:gAdWI4CRJESfv4LXLSKXoQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:DkdE+95WKU+1pN_1tdPQdA", callContext.id);
// Call getCountryName method from libCountry
getCountryNameJSResult.value = controller.safeExecuteJSNode(ShopperPortalEU_controller_GetCountryName_getCountryNameJS, "getCountryName", "GetCountryName", {
Code: OS.DataConversion.JSNodeParamConverter.to(vars.value.codeInLocal, OS.DataTypes.DataTypes.Text),
Name: OS.DataConversion.JSNodeParamConverter.to("", OS.DataTypes.DataTypes.Text)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("ShopperPortalEU.GetCountryName$getCountryNameJSResult"))();
jsNodeResult.nameOut = OS.DataConversion.JSNodeParamConverter.from($parameters.Name, OS.DataTypes.DataTypes.Text);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:G8LXjUAuYUeQB6yN6QlOSg", callContext.id);
// Name = getCountryName.Name
outVars.value.nameOut = getCountryNameJSResult.value.nameOut;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:7aXgqNlhxkW8GB20gipJfQ", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:e+SBDSn+0EK2v7rR9zCUGA", callContext.id);
}

};
var controller = ShopperPortalEUController.default;
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.GetCountryName$vars", [{
name: "Code",
attrName: "codeInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.GetCountryName$getCountryNameJSResult", [{
name: "Name",
attrName: "nameOut",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.GetCountryName$outVars", [{
name: "Name",
attrName: "nameOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEUController.default.clientActionProxies.getCountryName$Action = function (codeIn) {
codeIn = (codeIn === undefined) ? "" : codeIn;
return controller.executeActionInsideJSNode(ShopperPortalEUController.default.getCountryName$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(codeIn, OS.DataTypes.DataTypes.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Name: OS.DataConversion.JSNodeParamConverter.to(actionResults.nameOut, OS.DataTypes.DataTypes.Text)
};
});
};
});
define("ShopperPortalEU.controller$GetCountryName.getCountryNameJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
if(libcountry){
    $parameters.Name = libcountry.getCountryName($parameters.Code);
}
};
});

define("ShopperPortalEU.controller$GetCurrentServerURL", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU.controller$GetCurrentServerURL.GetCurrentServerURLJS", "ShopperPortalEU.clientVariables"], function (exports, OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_controller_GetCurrentServerURL_GetCurrentServerURLJS, ShopperPortalEUClientVariables) {
var OS = OutSystems.Internal;
ShopperPortalEUController.default.getCurrentServerURL$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var getCurrentServerURLJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.GetCurrentServerURL$outVars"))());
varBag.callContext = callContext;
varBag.getCurrentServerURLJSResult = getCurrentServerURLJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:A2Zzsgfno0Om1_dXkKcjrA:/ClientActionFlows.A2Zzsgfno0Om1_dXkKcjrA:650vdegSfxPq0Al7R97bAg", "ShopperPortalEU", "GetCurrentServerURL", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:I13114JkxUOPV1a6eK3pZw", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:fnmz54meOkSWgoAvCSPNOw", callContext.id);
// JavaScript function to retrieve the current server URL by using the window.location object. This object provides information about the current URL, including the protocol, hostname, and port.
getCurrentServerURLJSResult.value = controller.safeExecuteJSNode(ShopperPortalEU_controller_GetCurrentServerURL_GetCurrentServerURLJS, "GetCurrentServerURL", "GetCurrentServerURL", {
URL: OS.DataConversion.JSNodeParamConverter.to("", OS.DataTypes.DataTypes.Text)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("ShopperPortalEU.GetCurrentServerURL$getCurrentServerURLJSResult"))();
jsNodeResult.uRLOut = OS.DataConversion.JSNodeParamConverter.from($parameters.URL, OS.DataTypes.DataTypes.Text);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:EzQaykrNU0mAkDlMHGS9GA", callContext.id);
// URL = GetCurrentServerURL.URL
outVars.value.uRLOut = getCurrentServerURLJSResult.value.uRLOut;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:CcwFwgv46kyCl2+J8xDwUA", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:A2Zzsgfno0Om1_dXkKcjrA", callContext.id);
}

};
var controller = ShopperPortalEUController.default;
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.GetCurrentServerURL$getCurrentServerURLJSResult", [{
name: "URL",
attrName: "uRLOut",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.GetCurrentServerURL$outVars", [{
name: "URL",
attrName: "uRLOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEUController.default.clientActionProxies.getCurrentServerURL$Action = function () {
return controller.executeActionInsideJSNode(ShopperPortalEUController.default.getCurrentServerURL$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
URL: OS.DataConversion.JSNodeParamConverter.to(actionResults.uRLOut, OS.DataTypes.DataTypes.Text)
};
});
};
});
define("ShopperPortalEU.controller$GetCurrentServerURL.GetCurrentServerURLJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
function getCurrentServerUrl() {
    const { protocol, hostname, port } = window.location;
    return `${protocol}//${hostname}${port ? `:${port}` : ''}`;
}

$parameters.URL = getCurrentServerUrl();
};
});

define("ShopperPortalEU.controller$GetFirstLastWord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU.controller$GetFirstLastWord.TitleCaseJS", "ShopperPortalEU.clientVariables"], function (exports, OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_controller_GetFirstLastWord_TitleCaseJS, ShopperPortalEUClientVariables) {
var OS = OutSystems.Internal;
ShopperPortalEUController.default.getFirstLastWord$Action = function (stringIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.GetFirstLastWord$vars"))());
vars.value.stringInLocal = stringIn;
var titleCaseJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.GetFirstLastWord$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.titleCaseJSResult = titleCaseJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:fhmM5f7PWkuvjDpNGrtn8w:/ClientActionFlows.fhmM5f7PWkuvjDpNGrtn8w:Nd3vZoJMc7z3Fd8QBKrNvw", "ShopperPortalEU", "GetFirstLastWord", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:bQGW+4d3bEGV_ynHQFZLJg", callContext.id);
// Has string
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:sLkpHFTO30KpH5HNtcHLFw", callContext.id) && ((OS.BuiltinFunctions.trim(vars.value.stringInLocal)) !== ("")))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:NE2Av0Yx+0Cq0l2eXP8XTg", callContext.id);
// Format string 
titleCaseJSResult.value = controller.safeExecuteJSNode(ShopperPortalEU_controller_GetFirstLastWord_TitleCaseJS, "TitleCase", "GetFirstLastWord", {
String: OS.DataConversion.JSNodeParamConverter.to(vars.value.stringInLocal, OS.DataTypes.DataTypes.Text),
FormattedString: OS.DataConversion.JSNodeParamConverter.to("", OS.DataTypes.DataTypes.Text)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("ShopperPortalEU.GetFirstLastWord$titleCaseJSResult"))();
jsNodeResult.formattedStringOut = OS.DataConversion.JSNodeParamConverter.from($parameters.FormattedString, OS.DataTypes.DataTypes.Text);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:LpcsPOVpeUeJGDIhlav+GA", callContext.id);
// FormattedString = TitleCase.FormattedString
outVars.value.formattedStringOut = titleCaseJSResult.value.formattedStringOut;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:F6DIHDNtZUisBa5h_UbrHQ", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:5m6kKk_yA0exrgRrgpbSew", callContext.id);
}

return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:fhmM5f7PWkuvjDpNGrtn8w", callContext.id);
}

};
var controller = ShopperPortalEUController.default;
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.GetFirstLastWord$vars", [{
name: "String",
attrName: "stringInLocal",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.GetFirstLastWord$titleCaseJSResult", [{
name: "FormattedString",
attrName: "formattedStringOut",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.GetFirstLastWord$outVars", [{
name: "FormattedString",
attrName: "formattedStringOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEUController.default.clientActionProxies.getFirstLastWord$Action = function (stringIn) {
stringIn = (stringIn === undefined) ? "" : stringIn;
return controller.executeActionInsideJSNode(ShopperPortalEUController.default.getFirstLastWord$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(stringIn, OS.DataTypes.DataTypes.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
FormattedString: OS.DataConversion.JSNodeParamConverter.to(actionResults.formattedStringOut, OS.DataTypes.DataTypes.Text)
};
});
};
});
define("ShopperPortalEU.controller$GetFirstLastWord.TitleCaseJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
let s = $parameters.String.split(" ");
if (s.length < 2) {
  $parameters.FormattedString = $parameters.String;
} else {
  $parameters.FormattedString = s[0] + " " + s[s.length-1];
}
};
});

define("ShopperPortalEU.controller$GetFormsRefundList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU.clientVariables", "ShopperPortalEU_Forms_IS.model$FormInfo_WrapperRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Forms_IS", "ShopperPortalEU.model$FormInfo_WrapperList", "ShopperPortalEU.model$RefundSummaryRec", "ShopperPortalEU.model$RefundSummaryList"], function (exports, OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_Forms_ISModel, ShopperPortalEUClientVariables) {
var OS = OutSystems.Internal;
ShopperPortalEUController.default.getFormsRefundList$Action = function (formInfoListIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.GetFormsRefundList$vars"))());
vars.value.formInfoListInLocal = formInfoListIn.clone();
var listFilterByRA1Var = new OS.DataTypes.VariableHolder();
var listFilterByVA2Var = new OS.DataTypes.VariableHolder();
var listFilterByVA1Var = new OS.DataTypes.VariableHolder();
var listFilter_ReadyForRefundVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.GetFormsRefundList$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.listFilterByRA1Var = listFilterByRA1Var;
varBag.listFilterByVA2Var = listFilterByVA2Var;
varBag.listFilterByVA1Var = listFilterByVA1Var;
varBag.listFilter_ReadyForRefundVar = listFilter_ReadyForRefundVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:g2o7SYEdrkG+t4djHkrPew:/ClientActionFlows.g2o7SYEdrkG+t4djHkrPew:dogN5L8V7j9Tao_WG2IHZQ", "ShopperPortalEU", "GetFormsRefundList", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:HbRXC2EfgUmBXRoogkS7Mg", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Ysdx_ZvTFUKqddiwg_LQlA", callContext.id);
// Execute Action: ListFilter_ReadyForRefund
listFilter_ReadyForRefundVar.value = OS.SystemActions.listFilter(vars.value.formInfoListInLocal, function (p) {
return p.isReadyForRefundAttr;
}, callContext);

OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:eDyXIItmaU+z3PBV9ePzeQ", callContext.id);
// Execute Action: ListSort
OS.SystemActions.listSort(listFilter_ReadyForRefundVar.value.filteredListOut, function (p) {
return p.refundAmountCurrencyAttr;
}, true, callContext);
// Not SingleForm RA1 ?
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Bi7K18U5xUCm1Sl7wARqJw", callContext.id) && (ShopperPortalEUClientVariables.getFormNumberRA1() === ""))) {
// Not SingleForm VA1 ?
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:gKs+XWB1wkKyUl_h25bg0A", callContext.id) && (ShopperPortalEUClientVariables.getFormNumberVA1() === ""))) {
// Not SingleForm VA2 ?
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:2xHqFbH1ZkisnFY7SGIHew", callContext.id) && (ShopperPortalEUClientVariables.getFormNumberVA2() === ""))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:3jYQZXWlIkiNElSry4gEDw", callContext.id);
// FormsList_ReadyForRefund = ListFilter_ReadyForRefund.FilteredList
outVars.value.formsList_ReadyForRefundOut = listFilter_ReadyForRefundVar.value.filteredListOut;
// ReadyForRefundForms
// Foreach ListFilter_ReadyForRefund.FilteredList
callContext.iterationContext.registerIterationStart(listFilter_ReadyForRefundVar.value.filteredListOut);
try {var filteredListIterator = callContext.iterationContext.getIterator(listFilter_ReadyForRefundVar.value.filteredListOut);
var filteredListIndex = 0;
while ((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:etz6x8Pm9Eqka2nXOBBQMw", callContext.id) && (filteredListIndex < listFilter_ReadyForRefundVar.value.filteredListOut.length))) {
filteredListIterator.currentRowNumber = filteredListIndex;
// new currency ?
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:H5WWxd62IUOkl1HxyHHvzA", callContext.id) && (((listFilter_ReadyForRefundVar.value.filteredListOut.getItem(filteredListIndex.valueOf()).refundAmountCurrencyAttr) !== (vars.value.refundSummaryFormRecVar.currencyAttr)) && ((listFilter_ReadyForRefundVar.value.filteredListOut.getCurrentRowNumber(callContext.iterationContext)) !== (0))))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:qHOcvFRCb0eLUuP+kM0mbA", callContext.id);
// Execute Action: ListAppendCurrencyForm2
OS.SystemActions.listAppend(outVars.value.refundSummaryFormListOut, vars.value.refundSummaryFormRecVar, callContext);
// Reset EstimatedRefund
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:juVWOUFgbkeXttoDTLtu3Q", callContext.id);
// RefundSummaryFormRec.Currency = ""
vars.value.refundSummaryFormRecVar.currencyAttr = "";
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:juVWOUFgbkeXttoDTLtu3Q", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// RefundSummaryFormRec.TotalEstimatedRefund = 0
vars.value.refundSummaryFormRecVar.totalEstimatedRefundAttr = OS.BuiltinFunctions.integerToDecimal(0);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:juVWOUFgbkeXttoDTLtu3Q", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// HasMultipleCurrencies = True
vars.value.hasMultipleCurrenciesVar = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:+fQhsFukKk6tv5LwYj9fhg", callContext.id);
// Execute Action: ListClearRecFormList
OS.SystemActions.listClear(vars.value.refundSummaryFormRecVar.formInfo_WrapperAttr, callContext);
}

OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:zljDriXAUUSm4xZuFPEe1w", callContext.id);
// RefundSummaryFormRec.Currency = ListFilter_ReadyForRefund.FilteredList.Current.RefundAmountCurrency
vars.value.refundSummaryFormRecVar.currencyAttr = listFilter_ReadyForRefundVar.value.filteredListOut.getItem(filteredListIndex.valueOf()).refundAmountCurrencyAttr;
// EstimatedRefund ++
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:AXroqpuAL0mXpUYZlfg7sA", callContext.id);
// RefundSummaryFormRec.TotalEstimatedRefund = RefundSummaryFormRec.TotalEstimatedRefund + ListFilter_ReadyForRefund.FilteredList.Current.RefundAmount
vars.value.refundSummaryFormRecVar.totalEstimatedRefundAttr = vars.value.refundSummaryFormRecVar.totalEstimatedRefundAttr.plus(listFilter_ReadyForRefundVar.value.filteredListOut.getItem(filteredListIndex.valueOf()).refundAmountAttr);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:aZMbeuTjREe8N3fyxIk6DQ", callContext.id);
// Execute Action: ListAppendRefundSummaryForm
OS.SystemActions.listAppend(vars.value.refundSummaryFormRecVar.formInfo_WrapperAttr, listFilter_ReadyForRefundVar.value.filteredListOut.getItem(filteredListIndex.valueOf()), callContext);
filteredListIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(listFilter_ReadyForRefundVar.value.filteredListOut);
}

if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:RQFY519l4kCM8NPpNYrlIw", callContext.id) && (outVars.value.refundSummaryFormListOut.isEmpty || vars.value.hasMultipleCurrenciesVar))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:1qY8lGST60aiKyicJq+D2g", callContext.id);
// Execute Action: ListAppendCurrencyForm
OS.SystemActions.listAppend(outVars.value.refundSummaryFormListOut, vars.value.refundSummaryFormRecVar, callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:_vZ2bqrIaE6wqTo2C+xSeA", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:hgMpbGvstkikPIV1KzmvRw", callContext.id);
}

} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:mKFKLDZJFUy6a4HkO47Jrw", callContext.id);
// Execute Action: ListFilterByVA2
listFilterByVA2Var.value = OS.SystemActions.listFilter(listFilter_ReadyForRefundVar.value.filteredListOut, function (p) {
return (p.formNumberAttr === ShopperPortalEUClientVariables.getFormNumberVA2());
}, callContext);

// RefundSummaryFormRec
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:NHGAXZDZ3kmIG_ga2v0nkg", callContext.id);
// RefundSummaryFormRec.TotalEstimatedRefund = ListFilterByVA2.FilteredList.Current.RefundAmount
vars.value.refundSummaryFormRecVar.totalEstimatedRefundAttr = listFilterByVA2Var.value.filteredListOut.getCurrent(callContext.iterationContext).refundAmountAttr;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:NHGAXZDZ3kmIG_ga2v0nkg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// RefundSummaryFormRec.Currency = ListFilterByVA2.FilteredList.Current.RefundAmountCurrency
vars.value.refundSummaryFormRecVar.currencyAttr = listFilterByVA2Var.value.filteredListOut.getCurrent(callContext.iterationContext).refundAmountCurrencyAttr;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:sCMjL3p1TkSqqmUzE_agUQ", callContext.id);
// Execute Action: ListAppendRefundSummaryForm4
OS.SystemActions.listAppend(vars.value.refundSummaryFormRecVar.formInfo_WrapperAttr, listFilterByVA2Var.value.filteredListOut.getCurrent(callContext.iterationContext), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:MrYMYB7Fn0mZwf9snefk8w", callContext.id);
// Execute Action: ListAppendCurrencyForm5
OS.SystemActions.listAppend(outVars.value.refundSummaryFormListOut, vars.value.refundSummaryFormRecVar, callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:0l_OkHJeOUCeXcDULXSiPg", callContext.id);
// FormsList_ReadyForRefund = ListFilterByVA2.FilteredList
outVars.value.formsList_ReadyForRefundOut = listFilterByVA2Var.value.filteredListOut;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:UEqaiNp3ZEmwhR4bKtOL_A", callContext.id);
}

} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:sfUxeyRxRESi+F5AcR192Q", callContext.id);
// Execute Action: ListFilterByVA1
listFilterByVA1Var.value = OS.SystemActions.listFilter(listFilter_ReadyForRefundVar.value.filteredListOut, function (p) {
return (p.formNumberAttr === ShopperPortalEUClientVariables.getFormNumberVA1());
}, callContext);

// RefundSummaryFormRec
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:uFHoM8eiYUiL3mXZeWphLg", callContext.id);
// RefundSummaryFormRec.TotalEstimatedRefund = ListFilterByVA1.FilteredList.Current.RefundAmount
vars.value.refundSummaryFormRecVar.totalEstimatedRefundAttr = listFilterByVA1Var.value.filteredListOut.getCurrent(callContext.iterationContext).refundAmountAttr;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:uFHoM8eiYUiL3mXZeWphLg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// RefundSummaryFormRec.Currency = ListFilterByVA1.FilteredList.Current.RefundAmountCurrency
vars.value.refundSummaryFormRecVar.currencyAttr = listFilterByVA1Var.value.filteredListOut.getCurrent(callContext.iterationContext).refundAmountCurrencyAttr;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:0imyp6D3qUS0FaPhZUA5SA", callContext.id);
// Execute Action: ListAppendRefundSummaryForm3
OS.SystemActions.listAppend(vars.value.refundSummaryFormRecVar.formInfo_WrapperAttr, listFilterByVA1Var.value.filteredListOut.getCurrent(callContext.iterationContext), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:7BLhUPimcEm4RNCG0Yqh8g", callContext.id);
// Execute Action: ListAppendCurrencyForm4
OS.SystemActions.listAppend(outVars.value.refundSummaryFormListOut, vars.value.refundSummaryFormRecVar, callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:PFNbslkuFUuTFprQHRi_Dw", callContext.id);
// FormsList_ReadyForRefund = ListFilterByVA1.FilteredList
outVars.value.formsList_ReadyForRefundOut = listFilterByVA1Var.value.filteredListOut;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:1ZXT7wJCC0yttFizOOdLxA", callContext.id);
}

} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ZVTDJcYzd0CY8jPKCzFNPQ", callContext.id);
// Execute Action: ListFilterByRA1
listFilterByRA1Var.value = OS.SystemActions.listFilter(listFilter_ReadyForRefundVar.value.filteredListOut, function (p) {
return (p.formNumberAttr === ShopperPortalEUClientVariables.getFormNumberRA1());
}, callContext);

// RefundSummaryFormRec
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:OOz+stwOOkKWCu8mEmQrDw", callContext.id);
// RefundSummaryFormRec.TotalEstimatedRefund = ListFilterByRA1.FilteredList.Current.RefundAmount
vars.value.refundSummaryFormRecVar.totalEstimatedRefundAttr = listFilterByRA1Var.value.filteredListOut.getCurrent(callContext.iterationContext).refundAmountAttr;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:OOz+stwOOkKWCu8mEmQrDw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// RefundSummaryFormRec.Currency = ListFilterByRA1.FilteredList.Current.RefundAmountCurrency
vars.value.refundSummaryFormRecVar.currencyAttr = listFilterByRA1Var.value.filteredListOut.getCurrent(callContext.iterationContext).refundAmountCurrencyAttr;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:LrCLA4G1VE2cgeOFOnZQEA", callContext.id);
// Execute Action: ListAppendRefundSummaryForm2
OS.SystemActions.listAppend(vars.value.refundSummaryFormRecVar.formInfo_WrapperAttr, listFilterByRA1Var.value.filteredListOut.getCurrent(callContext.iterationContext), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:upe5FJ3WrUueOBhnE+KEoQ", callContext.id);
// Execute Action: ListAppendCurrencyForm3
OS.SystemActions.listAppend(outVars.value.refundSummaryFormListOut, vars.value.refundSummaryFormRecVar, callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:WZ7v0X2wh0ysoB9sjtnf2Q", callContext.id);
// FormsList_ReadyForRefund = ListFilterByRA1.FilteredList
outVars.value.formsList_ReadyForRefundOut = listFilterByRA1Var.value.filteredListOut;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ytd24SDJVUimPIjQ10r7hQ", callContext.id);
}

return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:g2o7SYEdrkG+t4djHkrPew", callContext.id);
}

};
var controller = ShopperPortalEUController.default;
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.GetFormsRefundList$vars", [{
name: "FormInfoList",
attrName: "formInfoListInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.RecordList,
defaultValue: function () {
return new ShopperPortalEUModel.FormInfo_WrapperList();
},
complexType: ShopperPortalEUModel.FormInfo_WrapperList
}, {
name: "RefundSummaryFormRec",
attrName: "refundSummaryFormRecVar",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Record,
defaultValue: function () {
return new ShopperPortalEUModel.RefundSummaryRec();
},
complexType: ShopperPortalEUModel.RefundSummaryRec
}, {
name: "HasMultipleCurrencies",
attrName: "hasMultipleCurrenciesVar",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Boolean,
defaultValue: function () {
return false;
}
}]);
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.GetFormsRefundList$outVars", [{
name: "FormsList_ReadyForRefund",
attrName: "formsList_ReadyForRefundOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.RecordList,
defaultValue: function () {
return new ShopperPortalEUModel.FormInfo_WrapperList();
},
complexType: ShopperPortalEUModel.FormInfo_WrapperList
}, {
name: "RefundSummaryFormList",
attrName: "refundSummaryFormListOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.RecordList,
defaultValue: function () {
return new ShopperPortalEUModel.RefundSummaryList();
},
complexType: ShopperPortalEUModel.RefundSummaryList
}]);
ShopperPortalEUController.default.clientActionProxies.getFormsRefundList$Action = function (formInfoListIn) {
formInfoListIn = (formInfoListIn === undefined) ? new ShopperPortalEUModel.FormInfo_WrapperList() : formInfoListIn;
return controller.executeActionInsideJSNode(ShopperPortalEUController.default.getFormsRefundList$Action.bind(controller, formInfoListIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
FormsList_ReadyForRefund: actionResults.formsList_ReadyForRefundOut,
RefundSummaryFormList: actionResults.refundSummaryFormListOut
};
});
};
});

define("ShopperPortalEU.controller$GetPassports", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.controller", "ShopperPortalEU.clientVariables", "ShopperPortalEU_Shopper_IS.model$GetShopperTravelDocumentsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS", "ShopperPortalEU.model$GetShopperTravelDocumentsList", "ShopperPortalEU.model$PassportList", "ShopperPortalEU.controller$ServerAction.FormatPassports", "ShopperPortalEU_Shopper_IS.model$GetShopperResponseRec", "ShopperPortalEU_Shopper_IS.controller$GetShopper"], function (exports, OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_Shopper_ISModel, ShopperPortalEU_Shopper_ISController, ShopperPortalEUClientVariables) {
var OS = OutSystems.Internal;
ShopperPortalEUController.default.getPassports$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var allExceptionsVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.ErrorHandlerOutputType());
var formatPassportsVar = new OS.DataTypes.VariableHolder();
var getShopperVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.GetPassports$outVars"))());
varBag.callContext = callContext;
varBag.allExceptionsVar = allExceptionsVar;
varBag.formatPassportsVar = formatPassportsVar;
varBag.getShopperVar = getShopperVar;
varBag.outVars = outVars;
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:2k9PpyFEhkCFrLZfWHSiOg:/ClientActionFlows.2k9PpyFEhkCFrLZfWHSiOg:Vpag_obWiFWTomy5uU8Vkw", "ShopperPortalEU", "GetPassports", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:aMc8IMQfYEK7tZN0HA2qig", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:BoZEdLpDvkqK95TfOmIjEQ", callContext.id);
// Execute Action: GetShopper
return ShopperPortalEU_Shopper_ISController.default.getShopper$Action(ShopperPortalEUClientVariables.getShopperGuid(), callContext).then(function (value) {
getShopperVar.value = value;
}).then(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:G0oHEXbwaECMmEj1bDjSCg", callContext.id);
// IsSuccess = GetShopper.IsSuccess
outVars.value.isSuccessOut = getShopperVar.value.isSuccessOut;
}).then(function () {
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:JZJQofjLykC+eS6hCd0y8w", callContext.id) && outVars.value.isSuccessOut)) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:o1b2D3GAzkWFb1m4VGiPjQ", callContext.id);
// Execute Action: FormatPassports
return controller.formatPassports$ServerAction(getShopperVar.value.shopperOut.travelDocumentsAttr, callContext).then(function (value) {
formatPassportsVar.value = value;
}).then(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:tjEu7_p7HUexH3ZDuNiYfA", callContext.id);
// Passports = FormatPassports.Passports
outVars.value.passportsOut = formatPassportsVar.value.passportsOut;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ocrSvvQGpk6qAw7fmcRXxg", callContext.id);
});
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:+4q5hEg_ZEyxgCe872IQZw", callContext.id);
}

});
});
}).catch(function (ex) {
OS.Logger.trace("GetPassports.GetPassports", OS.Exceptions.getMessage(ex), ex.name);
// Handle Error: AllExceptions
if(!(OS.Exceptions.isSystem(ex))) {
OS.Logger.error(null, ex);
allExceptionsVar.value.exceptionMessageAttr = OS.Exceptions.getMessage(ex);
OutSystemsDebugger.handleException(allExceptionsVar.value.exceptionMessageAttr, callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:XOVu63jWzUC6NPvNsk2ZKg", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Uh7moEAWz0+St2fibGAtew", callContext.id);
// IsSuccess = False
outVars.value.isSuccessOut = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:8Rfb10IGY06Y5XIm_14QkA", callContext.id);
return OS.Flow.returnAsync(outVars.value);

});
}

throw ex;
}).then(function () {
return outVars.value;
}).then(function (res) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:2k9PpyFEhkCFrLZfWHSiOg", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:2k9PpyFEhkCFrLZfWHSiOg", callContext.id);
throw ex;

});
};
var controller = ShopperPortalEUController.default;
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.GetPassports$outVars", [{
name: "Passports",
attrName: "passportsOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.RecordList,
defaultValue: function () {
return new ShopperPortalEUModel.PassportList();
},
complexType: ShopperPortalEUModel.PassportList
}, {
name: "IsSuccess",
attrName: "isSuccessOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Boolean,
defaultValue: function () {
return false;
}
}]);
ShopperPortalEUController.default.clientActionProxies.getPassports$Action = function () {
return controller.executeActionInsideJSNode(ShopperPortalEUController.default.getPassports$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Passports: actionResults.passportsOut,
IsSuccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.isSuccessOut, OS.DataTypes.DataTypes.Boolean)
};
});
};
});

define("ShopperPortalEU.controller$GroupFormsByDate", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU.clientVariables", "ShopperPortalEU_Forms_IS.model$FormInfo_WrapperRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Forms_IS", "ShopperPortalEU.model$FormInfo_WrapperList", "ShopperPortalEU_Forms_IS.model$UIConfigurationRec", "ShopperPortalEU_Forms_IS.model$RefundDetailsPaymentDetails_UIRec", "ShopperPortalEU_Forms_IS.model$FormDetails_WrapperRec", "ShopperPortalEU_Forms_IS.model$RefundDetails_WrapperRec"], function (exports, OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_Forms_ISModel, ShopperPortalEUClientVariables) {
var OS = OutSystems.Internal;
ShopperPortalEUController.default.groupFormsByDate$Action = function (formsListIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.GroupFormsByDate$vars"))());
vars.value.formsListInLocal = formsListIn.clone();
var listFilter_DateVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.GroupFormsByDate$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.listFilter_DateVar = listFilter_DateVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:_q+3+EKdG0+zddljQyd3Tg:/ClientActionFlows._q+3+EKdG0+zddljQyd3Tg:UEFyAaJf3kZhOzQ13X5xzA", "ShopperPortalEU", "GroupFormsByDate", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ToLYyVeUJUyKFVE6o63IEw", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:WkxbHIdqQ0eFEq7+v+7d+Q", callContext.id) && vars.value.formsListInLocal.isEmpty)) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:6TjdyEMJGUurgEAaLlUjpQ", callContext.id);
} else {
// Foreach FormsList
callContext.iterationContext.registerIterationStart(vars.value.formsListInLocal);
try {var formsListIterator = callContext.iterationContext.getIterator(vars.value.formsListInLocal);
var formsListIndex = 0;
while ((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:QMv3cuREHU6CR19jePjNSw", callContext.id) && (formsListIndex < vars.value.formsListInLocal.length))) {
formsListIterator.currentRowNumber = formsListIndex;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Hzj96OkyzUe7L64rLmeQfg", callContext.id);
// Execute Action: ListFilter_Date
listFilter_DateVar.value = OS.SystemActions.listFilter(outVars.value.formsList_OutputOut, function (p) {
return (p.formDateTxtAttr === vars.value.formsListInLocal.getItem(formsListIndex.valueOf()).formDateTxtAttr);
}, callContext);

OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:n0D_eFNdeUW1r0IBXGAimA", callContext.id);
// Execute Action: ListAppend
OS.SystemActions.listAppend(outVars.value.formsList_OutputOut, function () {
var rec = new ShopperPortalEU_Forms_ISModel.FormInfo_WrapperRec();
rec.formNumberAttr = vars.value.formsListInLocal.getItem(formsListIndex.valueOf()).formNumberAttr;
rec.formNumberFormattedAttr = vars.value.formsListInLocal.getItem(formsListIndex.valueOf()).formNumberFormattedAttr;
rec.merchantNameAttr = vars.value.formsListInLocal.getItem(formsListIndex.valueOf()).merchantNameAttr;
rec.formDateTxtAttr = ((listFilter_DateVar.value.filteredListOut.isEmpty) ? (vars.value.formsListInLocal.getItem(formsListIndex.valueOf()).formDateTxtAttr) : (""));
rec.refundLabel_UIAttr = vars.value.formsListInLocal.getItem(formsListIndex.valueOf()).refundLabel_UIAttr;
rec.refundAmountTxtAttr = vars.value.formsListInLocal.getItem(formsListIndex.valueOf()).refundAmountTxtAttr;
rec.refundAmountMessageAttr = vars.value.formsListInLocal.getItem(formsListIndex.valueOf()).refundAmountMessageAttr;
rec.formStatusLabelAttr = vars.value.formsListInLocal.getItem(formsListIndex.valueOf()).formStatusLabelAttr;
rec.formTagStateAttr = vars.value.formsListInLocal.getItem(formsListIndex.valueOf()).formTagStateAttr;
rec.isActiveAttr = vars.value.formsListInLocal.getItem(formsListIndex.valueOf()).isActiveAttr;
rec.isClosedAttr = vars.value.formsListInLocal.getItem(formsListIndex.valueOf()).isClosedAttr;
rec.isReadyForRefundAttr = vars.value.formsListInLocal.getItem(formsListIndex.valueOf()).isReadyForRefundAttr;
rec.refundDetailsAttr = function () {
var rec = new ShopperPortalEU_Forms_ISModel.RefundDetails_WrapperRec();
rec.currencyIsoAttr = vars.value.formsListInLocal.getItem(formsListIndex.valueOf()).refundDetailsAttr.currencyIsoAttr;
rec.paymentTypeAttr = vars.value.formsListInLocal.getItem(formsListIndex.valueOf()).refundDetailsAttr.paymentTypeAttr;
rec.paymentAccountAttr = vars.value.formsListInLocal.getItem(formsListIndex.valueOf()).refundDetailsAttr.paymentAccountAttr;
rec.paidOnAttr = vars.value.formsListInLocal.getItem(formsListIndex.valueOf()).refundDetailsAttr.paidOnAttr;
rec.acquirerRefAttr = vars.value.formsListInLocal.getItem(formsListIndex.valueOf()).refundDetailsAttr.acquirerRefAttr;
rec.locationAttr = vars.value.formsListInLocal.getItem(formsListIndex.valueOf()).refundDetailsAttr.locationAttr;
return rec;
}();
rec.formDetailsAttr = function () {
var rec = new ShopperPortalEU_Forms_ISModel.FormDetails_WrapperRec();
rec.barcodeAttr = vars.value.formsListInLocal.getItem(formsListIndex.valueOf()).formDetailsAttr.barcodeAttr;
rec.pdfAttr = vars.value.formsListInLocal.getItem(formsListIndex.valueOf()).formDetailsAttr.pdfAttr;
rec.cardStateTypeIdAttr = vars.value.formsListInLocal.getItem(formsListIndex.valueOf()).formDetailsAttr.cardStateTypeIdAttr;
rec.formStatusIdAttr = vars.value.formsListInLocal.getItem(formsListIndex.valueOf()).formDetailsAttr.formStatusIdAttr;
return rec;
}();
rec.uIConfigurationAttr = function () {
var rec = new ShopperPortalEU_Forms_ISModel.UIConfigurationRec();
rec.displayBarcode_UIAttr = vars.value.formsListInLocal.getItem(formsListIndex.valueOf()).uIConfigurationAttr.displayBarcode_UIAttr;
rec.displayViewForm_UIAttr = vars.value.formsListInLocal.getItem(formsListIndex.valueOf()).uIConfigurationAttr.displayViewForm_UIAttr;
rec.displayAdditionalInfo_UIAttr = vars.value.formsListInLocal.getItem(formsListIndex.valueOf()).uIConfigurationAttr.displayAdditionalInfo_UIAttr;
rec.displayRefundPaymentsDetails_UIAttr = vars.value.formsListInLocal.getItem(formsListIndex.valueOf()).uIConfigurationAttr.displayRefundPaymentsDetails_UIAttr;
rec.displayRefundPaymentsInfo_WheresMyRefundAttr = vars.value.formsListInLocal.getItem(formsListIndex.valueOf()).uIConfigurationAttr.displayRefundPaymentsInfo_WheresMyRefundAttr;
rec.hasRefundStepsPageAttr = vars.value.formsListInLocal.getItem(formsListIndex.valueOf()).uIConfigurationAttr.hasRefundStepsPageAttr;
rec.refundDetailsPaymentDetails_UIAttr = function () {
var rec = new ShopperPortalEU_Forms_ISModel.RefundDetailsPaymentDetails_UIRec();
rec.displayPaidOn_UIAttr = vars.value.formsListInLocal.getItem(formsListIndex.valueOf()).uIConfigurationAttr.refundDetailsPaymentDetails_UIAttr.displayPaidOn_UIAttr;
rec.displayLocation_UIAttr = vars.value.formsListInLocal.getItem(formsListIndex.valueOf()).uIConfigurationAttr.refundDetailsPaymentDetails_UIAttr.displayLocation_UIAttr;
rec.displayMethod_UIAttr = vars.value.formsListInLocal.getItem(formsListIndex.valueOf()).uIConfigurationAttr.refundDetailsPaymentDetails_UIAttr.displayMethod_UIAttr;
rec.displayARN_UIAttr = vars.value.formsListInLocal.getItem(formsListIndex.valueOf()).uIConfigurationAttr.refundDetailsPaymentDetails_UIAttr.displayARN_UIAttr;
return rec;
}();
return rec;
}();
return rec;
}(), callContext);
formsListIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(vars.value.formsListInLocal);
}

OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:_9u169RBKEqNVN4wg5kd+Q", callContext.id);
}

return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:_q+3+EKdG0+zddljQyd3Tg", callContext.id);
}

};
var controller = ShopperPortalEUController.default;
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.GroupFormsByDate$vars", [{
name: "FormsList",
attrName: "formsListInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.RecordList,
defaultValue: function () {
return new ShopperPortalEUModel.FormInfo_WrapperList();
},
complexType: ShopperPortalEUModel.FormInfo_WrapperList
}]);
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.GroupFormsByDate$outVars", [{
name: "FormsList_Output",
attrName: "formsList_OutputOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.RecordList,
defaultValue: function () {
return new ShopperPortalEUModel.FormInfo_WrapperList();
},
complexType: ShopperPortalEUModel.FormInfo_WrapperList
}]);
ShopperPortalEUController.default.clientActionProxies.groupFormsByDate$Action = function (formsListIn) {
formsListIn = (formsListIn === undefined) ? new ShopperPortalEUModel.FormInfo_WrapperList() : formsListIn;
return controller.executeActionInsideJSNode(ShopperPortalEUController.default.groupFormsByDate$Action.bind(controller, formsListIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
FormsList_Output: actionResults.formsList_OutputOut
};
});
};
});

define("ShopperPortalEU.controller$HeapIdentify", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU.controller$HeapIdentify.IdentifyJS", "ShopperPortalEU.clientVariables"], function (exports, OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_controller_HeapIdentify_IdentifyJS, ShopperPortalEUClientVariables) {
var OS = OutSystems.Internal;
ShopperPortalEUController.default.heapIdentify$Action = function (userStringIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.HeapIdentify$vars"))());
vars.value.userStringInLocal = userStringIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:WpMkOt7HSECIZ1VJ0gWbkQ:/ClientActionFlows.WpMkOt7HSECIZ1VJ0gWbkQ:6zCPo5Y3KKcLpgpKg4d6yw", "ShopperPortalEU", "HeapIdentify", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:DqntoFAc7kmBKrXTMjDdpg", callContext.id);
// Has userString 
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:fsUCKtIMxEabuXLs6Y5G7Q", callContext.id) && ((vars.value.userStringInLocal) !== ("")))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:+oSDdhwXiEOkYr3x1TkFLw", callContext.id);
// This API allows you to attach a unique identity and maintain user histories across sessions, devices, and browsers under a single profile in Heap.
controller.safeExecuteJSNode(ShopperPortalEU_controller_HeapIdentify_IdentifyJS, "Identify", "HeapIdentify", {
UserString: OS.DataConversion.JSNodeParamConverter.to(vars.value.userStringInLocal, OS.DataTypes.DataTypes.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:2BlqmxHLr0ulBZ6mPwTEaA", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:OPe1sbhocE2wHYpn_fszFg", callContext.id);
}

return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:WpMkOt7HSECIZ1VJ0gWbkQ", callContext.id);
}

};
var controller = ShopperPortalEUController.default;
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.HeapIdentify$vars", [{
name: "UserString",
attrName: "userStringInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEUController.default.clientActionProxies.heapIdentify$Action = function (userStringIn) {
userStringIn = (userStringIn === undefined) ? "" : userStringIn;
return controller.executeActionInsideJSNode(ShopperPortalEUController.default.heapIdentify$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(userStringIn, OS.DataTypes.DataTypes.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("ShopperPortalEU.controller$HeapIdentify.IdentifyJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
if (typeof heap !== "undefined")  {
    heap.identify($parameters.UserString);
}
};
});

define("ShopperPortalEU.controller$InitAppcues", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU.controller$InitAppcues.InitJS", "ShopperPortalEU.clientVariables"], function (exports, OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_controller_InitAppcues_InitJS, ShopperPortalEUClientVariables) {
var OS = OutSystems.Internal;
ShopperPortalEUController.default.initAppcues$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:wyxFfRqU8Ee6vw42d1Ae7Q:/ClientActionFlows.wyxFfRqU8Ee6vw42d1Ae7Q:iJwIW8moUNdc1bn0O2+DBA", "ShopperPortalEU", "InitAppcues", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:xIGQRCjRbkCCU7wZPb5WwA", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:8lLxc0iH2kie0YIPmRga_w", callContext.id);
controller.safeExecuteJSNode(ShopperPortalEU_controller_InitAppcues_InitJS, "Init", "InitAppcues", null, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:3QCrcNIYvE6if2jkJChbiA", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:wyxFfRqU8Ee6vw42d1Ae7Q", callContext.id);
}

};
var controller = ShopperPortalEUController.default;
ShopperPortalEUController.default.clientActionProxies.initAppcues$Action = function () {
return controller.executeActionInsideJSNode(ShopperPortalEUController.default.initAppcues$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("ShopperPortalEU.controller$InitAppcues.InitJS", [], function () {
return function ($actions, $roles, $public) {
 window.AppcuesSettings = { enableURLDetection: true };
};
});

define("ShopperPortalEU.controller$InitClarity", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU.controller$InitClarity.ConsentJS", "ShopperPortalEU.controller$InitClarity.InitJS", "ShopperPortalEU.clientVariables"], function (exports, OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_controller_InitClarity_ConsentJS, ShopperPortalEU_controller_InitClarity_InitJS, ShopperPortalEUClientVariables) {
var OS = OutSystems.Internal;
ShopperPortalEUController.default.initClarity$Action = function (clarityIdIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.InitClarity$vars"))());
vars.value.clarityIdInLocal = clarityIdIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:hBCPzKBmL0GKKQOts6yF6g:/ClientActionFlows.hBCPzKBmL0GKKQOts6yF6g:l0cj4yYGuyLz5bXta9c7qw", "ShopperPortalEU", "InitClarity", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:qz_ib5zHR0+zop5PdvIx9A", callContext.id);
// Has identifier
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:iHB_RVZQxEyDlyWB72bfhg", callContext.id) && ((vars.value.clarityIdInLocal) !== ("")))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:tKHZmFQN1ka_hK4GZba+3Q", callContext.id);
// Initialize microsoft clarity.
controller.safeExecuteJSNode(ShopperPortalEU_controller_InitClarity_InitJS, "Init", "InitClarity", {
ClarityId: OS.DataConversion.JSNodeParamConverter.to(vars.value.clarityIdInLocal, OS.DataTypes.DataTypes.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:DJuMDcqQP0itEfp9DJm5NQ", callContext.id);
// Clarity cookie consent.
controller.safeExecuteJSNode(ShopperPortalEU_controller_InitClarity_ConsentJS, "Consent", "InitClarity", null, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:5A9S2XjCdUGE3HefMs5FvA", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:SaaD1WJW5katbGt6zeKHFw", callContext.id);
}

return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:hBCPzKBmL0GKKQOts6yF6g", callContext.id);
}

};
var controller = ShopperPortalEUController.default;
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.InitClarity$vars", [{
name: "ClarityId",
attrName: "clarityIdInLocal",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEUController.default.clientActionProxies.initClarity$Action = function (clarityIdIn) {
clarityIdIn = (clarityIdIn === undefined) ? "" : clarityIdIn;
return controller.executeActionInsideJSNode(ShopperPortalEUController.default.initClarity$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(clarityIdIn, OS.DataTypes.DataTypes.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("ShopperPortalEU.controller$InitClarity.ConsentJS", [], function () {
return function ($actions, $roles, $public) {
if(window.clarity){
    window.clarity('consent', true);
}
};
});
define("ShopperPortalEU.controller$InitClarity.InitJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
    (function(c,l,a,r,i,t,y){
        c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};
        t=l.createElement(r);t.async=1;t.src="https://www.clarity.ms/tag/"+i;
        y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y);
    })(window, document, "clarity", "script", $parameters.ClarityId);

};
});

define("ShopperPortalEU.controller$InitHeap", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU.controller$InitHeap.InitHeapJS", "ShopperPortalEU.clientVariables"], function (exports, OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_controller_InitHeap_InitHeapJS, ShopperPortalEUClientVariables) {
var OS = OutSystems.Internal;
ShopperPortalEUController.default.initHeap$Action = function (heapApplicationIdIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.InitHeap$vars"))());
vars.value.heapApplicationIdInLocal = heapApplicationIdIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:eOaspQtraESnYLCeLTXjjw:/ClientActionFlows.eOaspQtraESnYLCeLTXjjw:tJbbiG_NGDyBIxLkuNotzg", "ShopperPortalEU", "InitHeap", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:qZT+IcxQAEypwuFg2N+Kqw", callContext.id);
// Has app identifier
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ArMmH7ywL0CL_icgMpFueg", callContext.id) && ((vars.value.heapApplicationIdInLocal) !== ("")))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:nPIaC9DajE+y0wTro6snLQ", callContext.id);
controller.safeExecuteJSNode(ShopperPortalEU_controller_InitHeap_InitHeapJS, "InitHeap", "InitHeap", {
HeapApplicationId: OS.DataConversion.JSNodeParamConverter.to(vars.value.heapApplicationIdInLocal, OS.DataTypes.DataTypes.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:o1gTiLG6jkSM72LQgg8pIw", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:3loV9G2B8EG2dqjBs+goGA", callContext.id);
}

return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:eOaspQtraESnYLCeLTXjjw", callContext.id);
}

};
var controller = ShopperPortalEUController.default;
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.InitHeap$vars", [{
name: "HeapApplicationId",
attrName: "heapApplicationIdInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEUController.default.clientActionProxies.initHeap$Action = function (heapApplicationIdIn) {
heapApplicationIdIn = (heapApplicationIdIn === undefined) ? "" : heapApplicationIdIn;
return controller.executeActionInsideJSNode(ShopperPortalEUController.default.initHeap$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(heapApplicationIdIn, OS.DataTypes.DataTypes.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("ShopperPortalEU.controller$InitHeap.InitHeapJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
window.heapReadyCb = window.heapReadyCb || [], window.heap = window.heap || [], heap.load = function(e, t) {
    window.heap.envId = e, window.heap.clientConfig = t = t || {}, window.heap.clientConfig.shouldFetchServerConfig = !1;
    var a = document.createElement("script");
    a.type = "text/javascript", a.async = !0, a.src = "https://cdn.us.heap-api.com/config/" + e + "/heap_config.js";
    var r = document.getElementsByTagName("script")[0];
    r.parentNode.insertBefore(a, r);
    var n = ["init", "startTracking", "stopTracking", "track", "resetIdentity", "identify", "getSessionId", "getUserId", "getIdentity", "addUserProperties", "addEventProperties", "removeEventProperty", "clearEventProperties", "addAccountProperties", "addAdapter", "addTransformer", "addTransformerFn", "onReady", "addPageviewProperties", "removePageviewProperty", "clearPageviewProperties", "trackPageview"],
        i = function(e) {
            return function() {
                var t = Array.prototype.slice.call(arguments, 0);
                window.heapReadyCb.push({
                    name: e,
                    fn: function() {
                        heap[e] && heap[e].apply(heap, t)
                    }
                })
            }
        };
    for (var p = 0; p < n.length; p++) heap[n[p]] = i(n[p])
};
if (typeof heap !== "undefined")  {
    heap.load($parameters.HeapApplicationId);
}

};
});

define("ShopperPortalEU.controller$IsProfileEmpty", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.controller", "ShopperPortalEU.clientVariables", "ShopperPortalEU_Shopper_IS.model$GetShopperResponseRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS", "ShopperPortalEU_Shopper_IS.controller$GetShopper"], function (exports, OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_Shopper_ISModel, ShopperPortalEU_Shopper_ISController, ShopperPortalEUClientVariables) {
var OS = OutSystems.Internal;
ShopperPortalEUController.default.isProfileEmpty$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var getShopperVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.IsProfileEmpty$outVars"))());
varBag.callContext = callContext;
varBag.getShopperVar = getShopperVar;
varBag.outVars = outVars;
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:mPqzIWbNcEaJ4diodAucdQ:/ClientActionFlows.mPqzIWbNcEaJ4diodAucdQ:LcoV+t89T3E2_Yd22pAdTA", "ShopperPortalEU", "IsProfileEmpty", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:HwgDg4bbh0Srd_HAzSp91w", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Nr9KAJ+FF0SW0F5oNvuj9w", callContext.id);
// Execute Action: GetShopper
return ShopperPortalEU_Shopper_ISController.default.getShopper$Action(ShopperPortalEUClientVariables.getShopperGuid(), callContext).then(function (value) {
getShopperVar.value = value;
}).then(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:q8MbyfM2_UG+hIpWp8cZ4w", callContext.id) && getShopperVar.value.isSuccessOut)) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:xEbwmGjjskmE3x4dlxNf5Q", callContext.id);
// Result = GetShopper.Shopper.Email <> "" or GetShopper.Shopper.MobileNumber <> "" and GetShopper.Shopper.FirstName = "" and GetShopper.Shopper.LastName = "" and GetShopper.Shopper.AddressLineOne = "" and GetShopper.Shopper.AddressLineTwo = "" and GetShopper.Shopper.City = "" and GetShopper.Shopper.PostCode = "" and GetShopper.Shopper.CountryOfResidenceIso = NullIdentifier or GetShopper.Shopper.CountryOfResidenceIso = 0 and GetShopper.Shopper.NationalityIso = NullIdentifier or GetShopper.Shopper.NationalityIso = 0 and GetShopper.Shopper.TravelDocuments.Current.Number = "" and GetShopper.Shopper.DateOfBirth = "" or GetShopper.Shopper.DateOfBirth = NullDate and GetShopper.Shopper.TravelDocuments.Current.ExpirationDate = NullDate or GetShopper.Shopper.TravelDocuments.Current.ExpirationDate = ""
outVars.value.resultOut = ((((((((((((((getShopperVar.value.shopperOut.emailAttr) !== ("")) || ((getShopperVar.value.shopperOut.mobileNumberAttr) !== (""))) && (getShopperVar.value.shopperOut.firstNameAttr === "")) && (getShopperVar.value.shopperOut.lastNameAttr === "")) && (getShopperVar.value.shopperOut.addressLineOneAttr === "")) && (getShopperVar.value.shopperOut.addressLineTwoAttr === "")) && (getShopperVar.value.shopperOut.cityAttr === "")) && (getShopperVar.value.shopperOut.postCodeAttr === "")) && (getShopperVar.value.shopperOut.countryOfResidenceIsoAttr.equals(OS.BuiltinFunctions.integerToLongInteger(OS.BuiltinFunctions.nullIdentifier())) || getShopperVar.value.shopperOut.countryOfResidenceIsoAttr.equals(OS.BuiltinFunctions.integerToLongInteger(0)))) && (getShopperVar.value.shopperOut.nationalityIsoAttr.equals(OS.BuiltinFunctions.integerToLongInteger(OS.BuiltinFunctions.nullIdentifier())) || getShopperVar.value.shopperOut.nationalityIsoAttr.equals(OS.BuiltinFunctions.integerToLongInteger(0)))) && (getShopperVar.value.shopperOut.travelDocumentsAttr.getCurrent(callContext.iterationContext).numberAttr === "")) && ((getShopperVar.value.shopperOut.dateOfBirthAttr === "") || (getShopperVar.value.shopperOut.dateOfBirthAttr === OS.BuiltinFunctions.dateToText(OS.BuiltinFunctions.nullDate())))) && ((getShopperVar.value.shopperOut.travelDocumentsAttr.getCurrent(callContext.iterationContext).expirationDateAttr === OS.BuiltinFunctions.dateToText(OS.BuiltinFunctions.nullDate())) || (getShopperVar.value.shopperOut.travelDocumentsAttr.getCurrent(callContext.iterationContext).expirationDateAttr === "")));
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:sGyzNIqfWku_A6AEifrztw", callContext.id);
// Execute Action: LogMessage
OS.SystemActions.logMessage((((((((((((("1: " + ((((getShopperVar.value.shopperOut.emailAttr) !== ("")) || ((getShopperVar.value.shopperOut.mobileNumberAttr) !== (""))) ? "True" : "False")) + "\r\n") + "2: ") + getShopperVar.value.shopperOut.firstNameAttr) + "\r\n") + "3: ") + getShopperVar.value.shopperOut.lastNameAttr) + "\r\n") + "4: ") + getShopperVar.value.shopperOut.addressLineOneAttr) === (((((((((((((((((((((((("" + "\r\n") + "5: ") + getShopperVar.value.shopperOut.addressLineTwoAttr) + "\r\n") + "6: ") + getShopperVar.value.shopperOut.cityAttr) + "\r\n") + "7: ") + getShopperVar.value.shopperOut.postCodeAttr) + "\r\n") + "8: ") + ((getShopperVar.value.shopperOut.countryOfResidenceIsoAttr.equals(OS.BuiltinFunctions.integerToLongInteger(OS.BuiltinFunctions.nullIdentifier())) || getShopperVar.value.shopperOut.countryOfResidenceIsoAttr.equals(OS.BuiltinFunctions.integerToLongInteger(0))) ? "True" : "False")) + "\r\n") + "9: ") + ((getShopperVar.value.shopperOut.nationalityIsoAttr.equals(OS.BuiltinFunctions.integerToLongInteger(OS.BuiltinFunctions.nullIdentifier())) || getShopperVar.value.shopperOut.nationalityIsoAttr.equals(OS.BuiltinFunctions.integerToLongInteger(0))) ? "True" : "False")) + "\r\n") + "10: ") + getShopperVar.value.shopperOut.travelDocumentsAttr.getCurrent(callContext.iterationContext).numberAttr) + "\r\n") + "11: ") + (((getShopperVar.value.shopperOut.dateOfBirthAttr === "") || (getShopperVar.value.shopperOut.dateOfBirthAttr === OS.BuiltinFunctions.dateToText(OS.BuiltinFunctions.nullDate()))) ? "True" : "False")) + "\r\n") + "12: ") + (((getShopperVar.value.shopperOut.travelDocumentsAttr.getCurrent(callContext.iterationContext).expirationDateAttr === OS.BuiltinFunctions.dateToText(OS.BuiltinFunctions.nullDate())) || (getShopperVar.value.shopperOut.travelDocumentsAttr.getCurrent(callContext.iterationContext).expirationDateAttr === "")) ? "True" : "False"))) ? "True" : "False"), "SPEU", callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:9E6y51aP6EilTU7uOPb5eA", callContext.id);
} else {
// Output
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:eozSDTo5sEy6kr2HQdVo_Q", callContext.id);
// Success = False
outVars.value.successOut = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:eozSDTo5sEy6kr2HQdVo_Q", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// ErrorMessage = GetShopper.ErrorMessage
outVars.value.errorMessageOut = getShopperVar.value.errorMessageOut;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:0qd5nBi9LEmiArDxNBdBVQ", callContext.id);
}

});
}).then(function () {
return outVars.value;
}).then(function (res) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:mPqzIWbNcEaJ4diodAucdQ", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:mPqzIWbNcEaJ4diodAucdQ", callContext.id);
throw ex;

});
};
var controller = ShopperPortalEUController.default;
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.IsProfileEmpty$outVars", [{
name: "Result",
attrName: "resultOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "Success",
attrName: "successOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Boolean,
defaultValue: function () {
return true;
}
}, {
name: "ErrorMessage",
attrName: "errorMessageOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEUController.default.clientActionProxies.isProfileEmpty$Action = function () {
return controller.executeActionInsideJSNode(ShopperPortalEUController.default.isProfileEmpty$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Result: OS.DataConversion.JSNodeParamConverter.to(actionResults.resultOut, OS.DataTypes.DataTypes.Boolean),
Success: OS.DataConversion.JSNodeParamConverter.to(actionResults.successOut, OS.DataTypes.DataTypes.Boolean),
ErrorMessage: OS.DataConversion.JSNodeParamConverter.to(actionResults.errorMessageOut, OS.DataTypes.DataTypes.Text)
};
});
};
});

define("ShopperPortalEU.controller$LayoutCheckAuthentication", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "Auth_Europe.controller", "ShopperPortalEU.clientVariables", "Auth_Europe.controller$InitWebAuth", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$Auth_Europe", "ShopperPortalEU.controller$CheckAuthentication", "ShopperPortalEU.model$LayoutAuthenticationRec"], function (exports, OutSystems, ShopperPortalEUModel, ShopperPortalEUController, Auth_EuropeController, ShopperPortalEUClientVariables) {
var OS = OutSystems.Internal;
ShopperPortalEUController.default.layoutCheckAuthentication$Action = function (layoutAuthenticationIn, domainIn, clientIdIn, redirectURLIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.LayoutCheckAuthentication$vars"))());
vars.value.layoutAuthenticationInLocal = layoutAuthenticationIn.clone();
vars.value.domainInLocal = domainIn;
vars.value.clientIdInLocal = clientIdIn;
vars.value.redirectURLInLocal = redirectURLIn;
var initWebAuthVar = new OS.DataTypes.VariableHolder();
var checkAuthenticationVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.LayoutCheckAuthentication$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.initWebAuthVar = initWebAuthVar;
varBag.checkAuthenticationVar = checkAuthenticationVar;
varBag.outVars = outVars;
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:Yxnn83X2mEeCWLHllGGSJw:/ClientActionFlows.Yxnn83X2mEeCWLHllGGSJw:ExvZLpGIDTnLoTBmMKVX7Q", "ShopperPortalEU", "LayoutCheckAuthentication", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:zum56Ss3Z0KpaYCtg6e4sQ", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:BgADpoVmMUWYBBDt+NmKYA", callContext.id);
// Execute Action: InitWebAuth
return Auth_EuropeController.default.initWebAuth$Action(vars.value.domainInLocal, vars.value.clientIdInLocal, vars.value.redirectURLInLocal, callContext).then(function (value) {
initWebAuthVar.value = value;
}).then(function () {
// IsToUseAuth
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:lfxjIyvjXki8el7_c7y5sw", callContext.id) && vars.value.layoutAuthenticationInLocal.isToUseAuthAttr)) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:yfic+BrPJ0GtnDrH3I5z3A", callContext.id);
// Execute Action: CheckAuthentication
return ShopperPortalEUController.default.checkAuthentication$Action(vars.value.layoutAuthenticationInLocal.notAutomaticallyRedirectAttr, callContext).then(function (value) {
checkAuthenticationVar.value = value;
}).then(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:x7GQIHM_HkO4fYWfiSMS5g", callContext.id);
// IsAuthenticated = CheckAuthentication.IsAuthenticated
outVars.value.isAuthenticatedOut = checkAuthenticationVar.value.isAuthenticatedOut;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Gwha+dDkCkC+d93XiC4Zzw", callContext.id);
});
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:WxSMqjF+d0Ca8hHg0sm3Pg", callContext.id);
// IsAuthenticated = False
outVars.value.isAuthenticatedOut = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:0JcyxibnSk24eMb4o6SgZg", callContext.id);
}

});
});
}).then(function () {
return outVars.value;
}).then(function (res) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:Yxnn83X2mEeCWLHllGGSJw", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:Yxnn83X2mEeCWLHllGGSJw", callContext.id);
throw ex;

});
};
var controller = ShopperPortalEUController.default;
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.LayoutCheckAuthentication$vars", [{
name: "LayoutAuthentication",
attrName: "layoutAuthenticationInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Record,
defaultValue: function () {
return new ShopperPortalEUModel.LayoutAuthenticationRec();
},
complexType: ShopperPortalEUModel.LayoutAuthenticationRec
}, {
name: "Domain",
attrName: "domainInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}, {
name: "ClientId",
attrName: "clientIdInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}, {
name: "RedirectURL",
attrName: "redirectURLInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.LayoutCheckAuthentication$outVars", [{
name: "IsAuthenticated",
attrName: "isAuthenticatedOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Boolean,
defaultValue: function () {
return false;
}
}]);
ShopperPortalEUController.default.clientActionProxies.layoutCheckAuthentication$Action = function (layoutAuthenticationIn, domainIn, clientIdIn, redirectURLIn) {
layoutAuthenticationIn = (layoutAuthenticationIn === undefined) ? new ShopperPortalEUModel.LayoutAuthenticationRec() : layoutAuthenticationIn;
domainIn = (domainIn === undefined) ? "" : domainIn;
clientIdIn = (clientIdIn === undefined) ? "" : clientIdIn;
redirectURLIn = (redirectURLIn === undefined) ? "" : redirectURLIn;
return controller.executeActionInsideJSNode(ShopperPortalEUController.default.layoutCheckAuthentication$Action.bind(controller, layoutAuthenticationIn, OS.DataConversion.JSNodeParamConverter.from(domainIn, OS.DataTypes.DataTypes.Text), OS.DataConversion.JSNodeParamConverter.from(clientIdIn, OS.DataTypes.DataTypes.Text), OS.DataConversion.JSNodeParamConverter.from(redirectURLIn, OS.DataTypes.DataTypes.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
IsAuthenticated: OS.DataConversion.JSNodeParamConverter.to(actionResults.isAuthenticatedOut, OS.DataTypes.DataTypes.Boolean)
};
});
};
});

define("ShopperPortalEU.controller$OnApplicationReady", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Theme.controller", "ShopperPortalEU.clientVariables", "ShopperPortalEU.controller$ServerAction.GetApplicationReadyData", "ShopperPortalEU.controller$InitClarity", "ShopperPortalEU.controller$InitHeap", "ShopperPortalEU_UI_Theme.controller$AddFavicon", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU.controller$InitAppcues"], function (exports, OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_UI_ThemeController, ShopperPortalEUClientVariables) {
var OS = OutSystems.Internal;
ShopperPortalEUController.default.onApplicationReady$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
callContext = controller.callContext(callContext);
var getApplicationReadyDataVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.getApplicationReadyDataVar = getApplicationReadyDataVar;
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:sVWao32nAUKeYxPPAcjqKg.#OnApplicationReady:/SystemClientActions.#OnApplicationReady:wuCcTQAeW2i4oitcuGxZSw", "ShopperPortalEU", "OnApplicationReady", "SystemClientActions.OnApplicationReady", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Ad6hdNdniUOuAIZXpbo3pA", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:rTUqHry7B0uQsdAcaa8y3w", callContext.id);
// Execute Action: Auth0Require
return OS.SystemActions.requireScript("https://cdn.auth0.com/js/auth0/9.18/auth0.min.js", callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:94LE46HHo0S+5GxL_SKxHA", callContext.id);
// Execute Action: AddFavicon
ShopperPortalEU_UI_ThemeController.default.addFavicon$Action("favicon.png", callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:yE9AJ0Qc702iTgSjiD8bpg", callContext.id);
// Execute Action: GetApplicationReadyData
return controller.getApplicationReadyData$ServerAction(callContext).then(function (value) {
getApplicationReadyDataVar.value = value;
});
}).then(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:i2XBP47NvESV+dQeRBNqaQ", callContext.id);
// IsInMaintenance = GetApplicationReadyData.IsInMaintenance
ShopperPortalEUClientVariables.setIsInMaintenance(getApplicationReadyDataVar.value.isInMaintenanceOut);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:i2XBP47NvESV+dQeRBNqaQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// ShopperChecked = False
ShopperPortalEUClientVariables.setShopperChecked(false);
}).then(function () {
// IsHeapActive
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:jGtQkBZ+sESPO5Re3DPzNA", callContext.id) && getApplicationReadyDataVar.value.isHeapActiveOut)) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:nz8b1JOaNkCewBbwpER6vg", callContext.id);
// Execute Action: AppcuesRequire
return OS.SystemActions.requireScript("https://fast.appcues.com/220902.js", callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:HMIVRbgRik2z3m2Glp6yQg", callContext.id);
// Execute Action: InitHeap
ShopperPortalEUController.default.initHeap$Action(getApplicationReadyDataVar.value.heapApplicationIdOut, callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Zkd76OPQUk2g0ubY0hHMxw", callContext.id);
// Execute Action: InitAppcues
ShopperPortalEUController.default.initAppcues$Action(callContext);
});
} else {
// < - >
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:60brxI40wU2E6O3m50sNYg", callContext.id);
}

});
}).then(function () {
// Activate clarity 
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:LUQb_Gws9E6nVtkw4rGz1w", callContext.id) && getApplicationReadyDataVar.value.activeOut)) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:RFp6OnMbakm1OfMj9MfWYg", callContext.id);
// Execute Action: InitClarity
ShopperPortalEUController.default.initClarity$Action(getApplicationReadyDataVar.value.clarityIdOut, callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:aRQO95qAN0eumxoGBrWALQ", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:GZBHufEIMECaW_G4Xzbn6g", callContext.id);
}

});
}).then(function (res) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:sVWao32nAUKeYxPPAcjqKg.#OnApplicationReady", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:sVWao32nAUKeYxPPAcjqKg.#OnApplicationReady", callContext.id);
throw ex;

});
};
var controller = ShopperPortalEUController.default;
ShopperPortalEUController.default.clientActionProxies.onApplicationReady$Action = function () {
return controller.executeActionInsideJSNode(ShopperPortalEUController.default.onApplicationReady$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});

define("ShopperPortalEU.controller$PercentageProfileCalculation", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU.clientVariables", "ShopperPortalEU.model$CompleteDetailsRec"], function (exports, OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEUClientVariables) {
var OS = OutSystems.Internal;
ShopperPortalEUController.default.percentageProfileCalculation$Action = function (detailsIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.PercentageProfileCalculation$vars"))());
vars.value.detailsInLocal = detailsIn.clone();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.PercentageProfileCalculation$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:mW07miTQw06utcn4MGzpbQ:/ClientActionFlows.mW07miTQw06utcn4MGzpbQ:IT29vrbxoc2i4YrQlRC0IQ", "ShopperPortalEU", "PercentageProfileCalculation", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:YkxYh960YUCTxryOCAgntw", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:+qxj1yYJckOUuYQ38LqCeA", callContext.id) && ((vars.value.detailsInLocal.personalDetailsAttr.passportAttr) !== ("")))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:jvv_qarA1kW3QrAeTB3csg", callContext.id);
// Counter = Counter + Step
vars.value.counterVar = vars.value.counterVar.plus(vars.value.stepVar);
}

if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:++PHmw+LhEmS+G5uVubnOg", callContext.id) && (((OS.BuiltinFunctions.dateToText(vars.value.detailsInLocal.personalDetailsAttr.passportExpiryDateAttr)) !== ("")) && !(vars.value.detailsInLocal.personalDetailsAttr.passportExpiryDateAttr.equals(OS.BuiltinFunctions.nullDate()))))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:qkONvWoeS0eacKUtmhb1hA", callContext.id);
// Counter = Counter + Step
vars.value.counterVar = vars.value.counterVar.plus(vars.value.stepVar);
}

if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ZkbVxh66S0O3ndtfhiNVJA", callContext.id) && (((vars.value.detailsInLocal.personalDetailsAttr.passportCountryAttr) !== ("")) && ((vars.value.detailsInLocal.personalDetailsAttr.passportCountryAttr) !== ("0"))))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:+QMO3A6vCEuSOLMU67T2Og", callContext.id);
// Counter = Counter + Step
vars.value.counterVar = vars.value.counterVar.plus(vars.value.stepVar);
}

if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:PlOOlt4_o0O0LvVMb4muVw", callContext.id) && ((vars.value.detailsInLocal.personalDetailsAttr.givenNamesAttr) !== ("")))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:F84Bq4x6GEm_MheTeInAwA", callContext.id);
// Counter = Counter + Step
vars.value.counterVar = vars.value.counterVar.plus(vars.value.stepVar);
}

if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:yFqs6vmwRUS5DrJMxvCruA", callContext.id) && ((vars.value.detailsInLocal.personalDetailsAttr.surnameAttr) !== ("")))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:gGr5LPVGPkSg0GRDpaxqjg", callContext.id);
// Counter = Counter + Step
vars.value.counterVar = vars.value.counterVar.plus(vars.value.stepVar);
}

if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:eMyLlONRK0Kuzolci_LVGg", callContext.id) && (((OS.BuiltinFunctions.dateToText(vars.value.detailsInLocal.personalDetailsAttr.birthDateAttr)) !== ("")) && !(vars.value.detailsInLocal.personalDetailsAttr.birthDateAttr.equals(OS.BuiltinFunctions.nullDate()))))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:5zufwDk4akWHRIJxmXahCQ", callContext.id);
// Counter = Counter + Step
vars.value.counterVar = vars.value.counterVar.plus(vars.value.stepVar);
}

if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:xKgcB3LzOEqkZX7bJRnvPg", callContext.id) && (((vars.value.detailsInLocal.personalDetailsAttr.nationalityAttr) !== ("")) && ((vars.value.detailsInLocal.personalDetailsAttr.nationalityAttr) !== ("0"))))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:yeUeU74++EefLWVIulEm5g", callContext.id);
// Counter = Counter + Step
vars.value.counterVar = vars.value.counterVar.plus(vars.value.stepVar);
}

if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:bTiGfuNsFkuDJfOvjr1BQA", callContext.id) && (((vars.value.detailsInLocal.addressAttr.countryAttr) !== ("")) && ((vars.value.detailsInLocal.addressAttr.countryAttr) !== ("0"))))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:bOXk81pxSkqUioWhuszYTg", callContext.id);
// Counter = Counter + Step
vars.value.counterVar = vars.value.counterVar.plus(vars.value.stepVar);
}

if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:SW03dX4_EEqONCZR5lWt+g", callContext.id) && (((vars.value.detailsInLocal.contactAttr.emailAttr) !== ("")) || ((vars.value.detailsInLocal.contactAttr.mobileNumberAttr) !== (""))))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:nX6SFcODvESQPez9tr7IxA", callContext.id);
// Counter = Counter + Step
vars.value.counterVar = vars.value.counterVar.plus(vars.value.stepVar);
}

OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:k2rGE8gZskyedoMUwIiIHQ", callContext.id);
// CalculatedPercentage = Counter
outVars.value.calculatedPercentageOut = vars.value.counterVar;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:_ysRacASKkKnoRwQenBXvw", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:mW07miTQw06utcn4MGzpbQ", callContext.id);
}

};
var controller = ShopperPortalEUController.default;
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.PercentageProfileCalculation$vars", [{
name: "Details",
attrName: "detailsInLocal",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Record,
defaultValue: function () {
return new ShopperPortalEUModel.CompleteDetailsRec();
},
complexType: ShopperPortalEUModel.CompleteDetailsRec
}, {
name: "Counter",
attrName: "counterVar",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Decimal,
defaultValue: function () {
return OS.BuiltinFunctions.integerToDecimal(0);
}
}, {
name: "Step",
attrName: "stepVar",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Decimal,
defaultValue: function () {
return (new OS.DataTypes.Decimal("11.11"));
}
}]);
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.PercentageProfileCalculation$outVars", [{
name: "CalculatedPercentage",
attrName: "calculatedPercentageOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Decimal,
defaultValue: function () {
return OS.DataTypes.Decimal.defaultValue;
}
}]);
ShopperPortalEUController.default.clientActionProxies.percentageProfileCalculation$Action = function (detailsIn) {
detailsIn = (detailsIn === undefined) ? new ShopperPortalEUModel.CompleteDetailsRec() : detailsIn;
return controller.executeActionInsideJSNode(ShopperPortalEUController.default.percentageProfileCalculation$Action.bind(controller, detailsIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
CalculatedPercentage: OS.DataConversion.JSNodeParamConverter.to(actionResults.calculatedPercentageOut, OS.DataTypes.DataTypes.Decimal)
};
});
};
});

define("ShopperPortalEU.controller$PercentageShopperProfileCompleted", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU.clientVariables", "ShopperPortalEU.model$CompleteDetailsRec", "ShopperPortalEU.controller$PercentageProfileCalculation", "ShopperPortalEU_Shopper_IS.model$GetShopperResponseRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS"], function (exports, OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_Shopper_ISModel, ShopperPortalEUClientVariables) {
var OS = OutSystems.Internal;
ShopperPortalEUController.default.percentageShopperProfileCompleted$Action = function (getShopperResponseIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.PercentageShopperProfileCompleted$vars"))());
vars.value.getShopperResponseInLocal = getShopperResponseIn.clone();
var percentageProfileCalculationVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.PercentageShopperProfileCompleted$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.percentageProfileCalculationVar = percentageProfileCalculationVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:_u_ML+80PkaQtSnpi0WwCg:/ClientActionFlows._u_ML+80PkaQtSnpi0WwCg:gdPbWaCZLfemyig8R_BUAg", "ShopperPortalEU", "PercentageShopperProfileCompleted", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:YBl+OP+XtEe3Gz8ZssfeUg", callContext.id);
// Set Details
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Gc+LCE2G10S9myvgNpPPCg", callContext.id);
// Details.PersonalDetails.Passport = GetShopperResponse.TravelDocuments.Current.Number
vars.value.detailsVar.personalDetailsAttr.passportAttr = vars.value.getShopperResponseInLocal.travelDocumentsAttr.getCurrent(callContext.iterationContext).numberAttr;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Gc+LCE2G10S9myvgNpPPCg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Details.PersonalDetails.PassportExpiryDate = TextToDate
vars.value.detailsVar.personalDetailsAttr.passportExpiryDateAttr = OS.BuiltinFunctions.textToDate(vars.value.getShopperResponseInLocal.travelDocumentsAttr.getCurrent(callContext.iterationContext).expirationDateAttr);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Gc+LCE2G10S9myvgNpPPCg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// Details.PersonalDetails.PassportCountry = GetShopperResponse.TravelDocuments.Current.IssuedByIso
vars.value.detailsVar.personalDetailsAttr.passportCountryAttr = OS.BuiltinFunctions.longIntegerToText(vars.value.getShopperResponseInLocal.travelDocumentsAttr.getCurrent(callContext.iterationContext).issuedByIsoAttr);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Gc+LCE2G10S9myvgNpPPCg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// Details.PersonalDetails.GivenNames = GetShopperResponse.FirstName
vars.value.detailsVar.personalDetailsAttr.givenNamesAttr = vars.value.getShopperResponseInLocal.firstNameAttr;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Gc+LCE2G10S9myvgNpPPCg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// Details.PersonalDetails.Surname = GetShopperResponse.LastName
vars.value.detailsVar.personalDetailsAttr.surnameAttr = vars.value.getShopperResponseInLocal.lastNameAttr;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Gc+LCE2G10S9myvgNpPPCg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "6");
// Details.PersonalDetails.BirthDate = If
vars.value.detailsVar.personalDetailsAttr.birthDateAttr = ((((vars.value.getShopperResponseInLocal.dateOfBirthAttr === "") || (vars.value.getShopperResponseInLocal.dateOfBirthAttr === "0001-01-01"))) ? (OS.BuiltinFunctions.nullDate()) : (OS.BuiltinFunctions.textToDate(vars.value.getShopperResponseInLocal.dateOfBirthAttr)));
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Gc+LCE2G10S9myvgNpPPCg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "7");
// Details.PersonalDetails.Nationality = GetShopperResponse.NationalityIso
vars.value.detailsVar.personalDetailsAttr.nationalityAttr = OS.BuiltinFunctions.longIntegerToText(vars.value.getShopperResponseInLocal.nationalityIsoAttr);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Gc+LCE2G10S9myvgNpPPCg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "8");
// Details.Address.Country = GetShopperResponse.CountryOfResidenceIso
vars.value.detailsVar.addressAttr.countryAttr = OS.BuiltinFunctions.longIntegerToText(vars.value.getShopperResponseInLocal.countryOfResidenceIsoAttr);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Gc+LCE2G10S9myvgNpPPCg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "9");
// Details.Address.AddressLine1 = GetShopperResponse.AddressLineOne
vars.value.detailsVar.addressAttr.addressLine1Attr = vars.value.getShopperResponseInLocal.addressLineOneAttr;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Gc+LCE2G10S9myvgNpPPCg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "10");
// Details.Address.AddressLine2 = GetShopperResponse.AddressLineOne
vars.value.detailsVar.addressAttr.addressLine2Attr = vars.value.getShopperResponseInLocal.addressLineOneAttr;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Gc+LCE2G10S9myvgNpPPCg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "11");
// Details.Address.Postcode = GetShopperResponse.PostCode
vars.value.detailsVar.addressAttr.postcodeAttr = vars.value.getShopperResponseInLocal.postCodeAttr;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Gc+LCE2G10S9myvgNpPPCg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "12");
// Details.Address.City = GetShopperResponse.City
vars.value.detailsVar.addressAttr.cityAttr = vars.value.getShopperResponseInLocal.cityAttr;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Gc+LCE2G10S9myvgNpPPCg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "13");
// Details.Address.State = GetShopperResponse.Region
vars.value.detailsVar.addressAttr.stateAttr = vars.value.getShopperResponseInLocal.regionAttr;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Gc+LCE2G10S9myvgNpPPCg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "14");
// Details.Contact.Email = GetShopperResponse.Email
vars.value.detailsVar.contactAttr.emailAttr = vars.value.getShopperResponseInLocal.emailAttr;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Gc+LCE2G10S9myvgNpPPCg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "15");
// Details.Contact.MobileNumber = GetShopperResponse.MobileNumber
vars.value.detailsVar.contactAttr.mobileNumberAttr = vars.value.getShopperResponseInLocal.mobileNumberAttr;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:5dQoqB1WD0eNwd77Yg7Mtg", callContext.id);
// Execute Action: PercentageProfileCalculation
percentageProfileCalculationVar.value = ShopperPortalEUController.default.percentageProfileCalculation$Action(vars.value.detailsVar, callContext);

OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:5Gzqkwj4K0W7uhNHYAcCqA", callContext.id);
// PercentageProfileComplete = Round
outVars.value.percentageProfileCompleteOut = OS.BuiltinFunctions.round(percentageProfileCalculationVar.value.calculatedPercentageOut, 0);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:FFTzCATj2UypNxcwj6RLeg", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:_u_ML+80PkaQtSnpi0WwCg", callContext.id);
}

};
var controller = ShopperPortalEUController.default;
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.PercentageShopperProfileCompleted$vars", [{
name: "GetShopperResponse",
attrName: "getShopperResponseInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Record,
defaultValue: function () {
return new ShopperPortalEU_Shopper_ISModel.GetShopperResponseRec();
},
complexType: ShopperPortalEU_Shopper_ISModel.GetShopperResponseRec
}, {
name: "Details",
attrName: "detailsVar",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Record,
defaultValue: function () {
return new ShopperPortalEUModel.CompleteDetailsRec();
},
complexType: ShopperPortalEUModel.CompleteDetailsRec
}]);
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.PercentageShopperProfileCompleted$outVars", [{
name: "PercentageProfileComplete",
attrName: "percentageProfileCompleteOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Decimal,
defaultValue: function () {
return OS.DataTypes.Decimal.defaultValue;
}
}]);
ShopperPortalEUController.default.clientActionProxies.percentageShopperProfileCompleted$Action = function (getShopperResponseIn) {
getShopperResponseIn = (getShopperResponseIn === undefined) ? new ShopperPortalEU_Shopper_ISModel.GetShopperResponseRec() : getShopperResponseIn;
return controller.executeActionInsideJSNode(ShopperPortalEUController.default.percentageShopperProfileCompleted$Action.bind(controller, getShopperResponseIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
PercentageProfileComplete: OS.DataConversion.JSNodeParamConverter.to(actionResults.percentageProfileCompleteOut, OS.DataTypes.DataTypes.Decimal)
};
});
};
});

define("ShopperPortalEU.controller$RedirectShopper", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU.clientVariables", "ShopperPortalEU_Shopper_IS.model$GetShopperResponseRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS", "ShopperPortalEU.controller$ShopperCheckMandatoryFields", "ShopperPortalEU.model$ScanPassportRec"], function (exports, OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_Shopper_ISModel, ShopperPortalEUClientVariables) {
var OS = OutSystems.Internal;
ShopperPortalEUController.default.redirectShopper$Action = function (shopperIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.RedirectShopper$vars"))());
vars.value.shopperInLocal = shopperIn.clone();
var shopperCheckMandatoryFieldsVar = new OS.DataTypes.VariableHolder();
var scanPassportFromJSONVar = new OS.DataTypes.VariableHolder(new (OS.Controller.BaseController.getJSONDeserializeOutputType(ShopperPortalEUModel.ScanPassportRec))());
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.RedirectShopper$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.shopperCheckMandatoryFieldsVar = shopperCheckMandatoryFieldsVar;
varBag.scanPassportFromJSONVar = scanPassportFromJSONVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:5iUUDVZecEW_MOtqL8rQ0w:/ClientActionFlows.5iUUDVZecEW_MOtqL8rQ0w:3IU4VE4FtAL8E82_r+9sWA", "ShopperPortalEU", "RedirectShopper", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:tufo6U2W5Em0VqmciLlUuA", callContext.id);
// Terms accepted
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:h8kBOOqIVEiRXbVUwJPI7w", callContext.id) && vars.value.shopperInLocal.eulaAcceptedAttr)) {
// Has passports ?
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ZKqm+0F3vUOskfHxoSzZIw", callContext.id) && !(vars.value.shopperInLocal.travelDocumentsAttr.isEmpty))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ob3qP2fBQE+bQqpD4eXNzA", callContext.id);
// Execute Action: ShopperCheckMandatoryFields
shopperCheckMandatoryFieldsVar.value = ShopperPortalEUController.default.shopperCheckMandatoryFields$Action(vars.value.shopperInLocal, callContext);

// Mandatory fields filled 
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:gZG6mK1zekGlAR0AE_yUig", callContext.id) && shopperCheckMandatoryFieldsVar.value.filledOut)) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:X7NTMlp4AUO41K4_LyTD8A", callContext.id);
} else {
// CompleteDetails
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:DF5jKrK1q02v+dMgj17v7Q", callContext.id);
// Redirect = 4
outVars.value.redirectOut = 4;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:V5r1tNUJZ0+wmWMCopb0nQ", callContext.id);
}

} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:fmjURwsVT0Oq0suwx+xb0Q", callContext.id);
// JSON Deserialize: ScanPassportFromJSON
scanPassportFromJSONVar.value.dataOut = OS.JSONUtils.deserializeFromJSON(ShopperPortalEUClientVariables.getShopperPassportDataTemp(), ShopperPortalEUModel.ScanPassportRec, false);
// Has scan passport data
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:o7sYHIMVYUGPIvyL8bAq5w", callContext.id) && ((((scanPassportFromJSONVar.value.dataOut.documentNumberAttr) !== ("")) && ((scanPassportFromJSONVar.value.dataOut.issuingCountryCodeAttr) !== (""))) && !(scanPassportFromJSONVar.value.dataOut.dateOfExpiryAttr.equals(OS.BuiltinFunctions.nullDate()))))) {
// ConfirmPassport
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:SsjeNXDo40+Z6_CKSsu2ZA", callContext.id);
// Redirect = 3
outVars.value.redirectOut = 3;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Ngxlfkxockar7G4D6RLV_g", callContext.id);
} else {
// PassportDetails
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:35djmE5eskOl5mP+OIyVFg", callContext.id);
// Redirect = 2
outVars.value.redirectOut = 2;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Ngxlfkxockar7G4D6RLV_g", callContext.id);
}

}

} else {
// TermsOfService
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:D6y6ETa650O6SpER_6MF3Q", callContext.id);
// Redirect = 1
outVars.value.redirectOut = 1;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:CXAcTmYf7km4BRbDbgvhaw", callContext.id);
}

return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:5iUUDVZecEW_MOtqL8rQ0w", callContext.id);
}

};
var controller = ShopperPortalEUController.default;
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.RedirectShopper$vars", [{
name: "Shopper",
attrName: "shopperInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Record,
defaultValue: function () {
return new ShopperPortalEU_Shopper_ISModel.GetShopperResponseRec();
},
complexType: ShopperPortalEU_Shopper_ISModel.GetShopperResponseRec
}]);
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.RedirectShopper$outVars", [{
name: "Redirect",
attrName: "redirectOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Integer,
defaultValue: function () {
return (false ? 1 : 0);
}
}]);
ShopperPortalEUController.default.clientActionProxies.redirectShopper$Action = function (shopperIn) {
shopperIn = (shopperIn === undefined) ? new ShopperPortalEU_Shopper_ISModel.GetShopperResponseRec() : shopperIn;
return controller.executeActionInsideJSNode(ShopperPortalEUController.default.redirectShopper$Action.bind(controller, shopperIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Redirect: OS.DataConversion.JSNodeParamConverter.to(actionResults.redirectOut, OS.DataTypes.DataTypes.Integer)
};
});
};
});

define("ShopperPortalEU.controller$ReplaceAllNonLettersOrNumbers", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU.controller$ReplaceAllNonLettersOrNumbers.ReplaceJS", "ShopperPortalEU.clientVariables"], function (exports, OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_controller_ReplaceAllNonLettersOrNumbers_ReplaceJS, ShopperPortalEUClientVariables) {
var OS = OutSystems.Internal;
ShopperPortalEUController.default.replaceAllNonLettersOrNumbers$Action = function (stringIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.ReplaceAllNonLettersOrNumbers$vars"))());
vars.value.stringInLocal = stringIn;
var replaceJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.ReplaceAllNonLettersOrNumbers$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.replaceJSResult = replaceJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:06HT6WKsM0Gu_SxBXvwncQ:/ClientActionFlows.06HT6WKsM0Gu_SxBXvwncQ:UeA8BRkxfx_d0B02NCZpTg", "ShopperPortalEU", "ReplaceAllNonLettersOrNumbers", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:0xqXkXlPWka0cRxKdmQ1sw", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:YWxUa4TNW06oelS9Iz8oJg", callContext.id);
replaceJSResult.value = controller.safeExecuteJSNode(ShopperPortalEU_controller_ReplaceAllNonLettersOrNumbers_ReplaceJS, "Replace", "ReplaceAllNonLettersOrNumbers", {
String: OS.DataConversion.JSNodeParamConverter.to(vars.value.stringInLocal, OS.DataTypes.DataTypes.Text),
StringFormatted: OS.DataConversion.JSNodeParamConverter.to("", OS.DataTypes.DataTypes.Text)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("ShopperPortalEU.ReplaceAllNonLettersOrNumbers$replaceJSResult"))();
jsNodeResult.stringFormattedOut = OS.DataConversion.JSNodeParamConverter.from($parameters.StringFormatted, OS.DataTypes.DataTypes.Text);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:QefAYD89ekK7aTPj1IYpvA", callContext.id);
// StringFormatted = Replace.StringFormatted
outVars.value.stringFormattedOut = replaceJSResult.value.stringFormattedOut;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:L8m1TXZnckuyYVzfo8wbyQ", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:06HT6WKsM0Gu_SxBXvwncQ", callContext.id);
}

};
var controller = ShopperPortalEUController.default;
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.ReplaceAllNonLettersOrNumbers$vars", [{
name: "String",
attrName: "stringInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.ReplaceAllNonLettersOrNumbers$replaceJSResult", [{
name: "StringFormatted",
attrName: "stringFormattedOut",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.ReplaceAllNonLettersOrNumbers$outVars", [{
name: "StringFormatted",
attrName: "stringFormattedOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEUController.default.clientActionProxies.replaceAllNonLettersOrNumbers$Action = function (stringIn) {
stringIn = (stringIn === undefined) ? "" : stringIn;
return controller.executeActionInsideJSNode(ShopperPortalEUController.default.replaceAllNonLettersOrNumbers$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(stringIn, OS.DataTypes.DataTypes.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
StringFormatted: OS.DataConversion.JSNodeParamConverter.to(actionResults.stringFormattedOut, OS.DataTypes.DataTypes.Text)
};
});
};
});
define("ShopperPortalEU.controller$ReplaceAllNonLettersOrNumbers.ReplaceJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.StringFormatted = $parameters.String.replace(/[^a-zA-Z0-9]/g, '');
};
});

define("ShopperPortalEU.controller$SetShopperClientVariables", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.controller", "ShopperPortalEU.clientVariables", "ShopperPortalEU_Shopper_IS.model$GetCardsResponseRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS", "ShopperPortalEU.model$GetCardsResponseList", "ShopperPortalEU_Shopper_IS.controller$GetCards", "ShopperPortalEU_Shopper_IS.model$GetShopperResponseRec", "ShopperPortalEU.controller$PercentageShopperProfileCompleted", "ShopperPortalEU.controller$FormatShopperName"], function (exports, OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_Shopper_ISModel, ShopperPortalEU_Shopper_ISController, ShopperPortalEUClientVariables) {
var OS = OutSystems.Internal;
ShopperPortalEUController.default.setShopperClientVariables$Action = function (shopperIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.SetShopperClientVariables$vars"))());
vars.value.shopperInLocal = shopperIn.clone();
var getCardsVar = new OS.DataTypes.VariableHolder();
var percentageShopperProfileCompletedVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.vars = vars;
varBag.getCardsVar = getCardsVar;
varBag.percentageShopperProfileCompletedVar = percentageShopperProfileCompletedVar;
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:9+b+jGyuxUWJHstRCRK3nA:/ClientActionFlows.9+b+jGyuxUWJHstRCRK3nA:D0Gquk3Yg6MAvdb_2MgOKg", "ShopperPortalEU", "SetShopperClientVariables", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:333eZGqubk+UaSuqwAQv3w", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:XRwnS6+ocUmlkn6dMmWnvA", callContext.id);
// Execute Action: GetCards
return ShopperPortalEU_Shopper_ISController.default.getCards$Action(ShopperPortalEUClientVariables.getShopperGuid(), callContext).then(function (value) {
getCardsVar.value = value;
}).then(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:tFQtzVvmqkGiaV40Vc8s0w", callContext.id);
// Execute Action: PercentageShopperProfileCompleted
percentageShopperProfileCompletedVar.value = ShopperPortalEUController.default.percentageShopperProfileCompleted$Action(vars.value.shopperInLocal, callContext);

// Set client variables
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:aXuJXh11n0eQn6qTTc0DtQ", callContext.id);
// ShopperName = FormatShopperName(Shopper.FirstName, Shopper.LastName)
ShopperPortalEUClientVariables.setShopperName(OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.formatShopperName$Action(vars.value.shopperInLocal.firstNameAttr, vars.value.shopperInLocal.lastNameAttr, callContext).formattedShopperNameOut;
}, OS.DataTypes.DataTypes.Text, callContext.id));
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:aXuJXh11n0eQn6qTTc0DtQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// ShopperContact = If
ShopperPortalEUClientVariables.setShopperContact(((((vars.value.shopperInLocal.emailAttr) !== (""))) ? (vars.value.shopperInLocal.emailAttr) : (vars.value.shopperInLocal.mobileNumberAttr)));
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:aXuJXh11n0eQn6qTTc0DtQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// ShopperProfileCompleted = PercentageShopperProfileCompleted.PercentageProfileComplete
ShopperPortalEUClientVariables.setShopperProfileCompleted(percentageShopperProfileCompletedVar.value.percentageProfileCompleteOut);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:aXuJXh11n0eQn6qTTc0DtQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// ShopperCards = GetCards.Cards.Length
ShopperPortalEUClientVariables.setShopperCards(getCardsVar.value.cardsOut.length);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:aXuJXh11n0eQn6qTTc0DtQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// ShopperPassports = Shopper.TravelDocuments.Length
ShopperPortalEUClientVariables.setShopperPassports(vars.value.shopperInLocal.travelDocumentsAttr.length);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:TYWxLIeX8EOcRdxIQfOWyw", callContext.id);
});
}).then(function () {
return ;
}).then(function (res) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:9+b+jGyuxUWJHstRCRK3nA", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:9+b+jGyuxUWJHstRCRK3nA", callContext.id);
throw ex;

});
};
var controller = ShopperPortalEUController.default;
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.SetShopperClientVariables$vars", [{
name: "Shopper",
attrName: "shopperInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Record,
defaultValue: function () {
return new ShopperPortalEU_Shopper_ISModel.GetShopperResponseRec();
},
complexType: ShopperPortalEU_Shopper_ISModel.GetShopperResponseRec
}]);
ShopperPortalEUController.default.clientActionProxies.setShopperClientVariables$Action = function (shopperIn) {
shopperIn = (shopperIn === undefined) ? new ShopperPortalEU_Shopper_ISModel.GetShopperResponseRec() : shopperIn;
return controller.executeActionInsideJSNode(ShopperPortalEUController.default.setShopperClientVariables$Action.bind(controller, shopperIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});

define("ShopperPortalEU.controller$ShopperCheckMandatoryFields", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU.clientVariables", "ShopperPortalEU_Shopper_IS.model$GetShopperResponseRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS"], function (exports, OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_Shopper_ISModel, ShopperPortalEUClientVariables) {
var OS = OutSystems.Internal;
ShopperPortalEUController.default.shopperCheckMandatoryFields$Action = function (shopperIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.ShopperCheckMandatoryFields$vars"))());
vars.value.shopperInLocal = shopperIn.clone();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.ShopperCheckMandatoryFields$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:iSft+khzoUiJC8zJQmwFHg:/ClientActionFlows.iSft+khzoUiJC8zJQmwFHg:vFPCl8m4t4icyl0f1VFkow", "ShopperPortalEU", "ShopperCheckMandatoryFields", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:bL1PttWJVUWb6cyPJOq_ZA", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:aZTnnFTYREi0SfqEaOiBfQ", callContext.id);
// Filled = Trim <> "" and Trim <> "" and Shopper.CountryOfResidenceIso > 0 and Trim <> "" and Shopper.TravelDocuments.Current.IssuedByIso > 0
outVars.value.filledOut = ((((((OS.BuiltinFunctions.trim(vars.value.shopperInLocal.firstNameAttr)) !== ("")) && ((OS.BuiltinFunctions.trim(vars.value.shopperInLocal.lastNameAttr)) !== (""))) && vars.value.shopperInLocal.countryOfResidenceIsoAttr.gt(OS.BuiltinFunctions.integerToLongInteger(0))) && ((OS.BuiltinFunctions.trim(vars.value.shopperInLocal.travelDocumentsAttr.getCurrent(callContext.iterationContext).numberAttr)) !== (""))) && vars.value.shopperInLocal.travelDocumentsAttr.getCurrent(callContext.iterationContext).issuedByIsoAttr.gt(OS.BuiltinFunctions.integerToLongInteger(0)));
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:eu0PtLyqjEeIucd3GdwNTQ", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:iSft+khzoUiJC8zJQmwFHg", callContext.id);
}

};
var controller = ShopperPortalEUController.default;
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.ShopperCheckMandatoryFields$vars", [{
name: "Shopper",
attrName: "shopperInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Record,
defaultValue: function () {
return new ShopperPortalEU_Shopper_ISModel.GetShopperResponseRec();
},
complexType: ShopperPortalEU_Shopper_ISModel.GetShopperResponseRec
}]);
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.ShopperCheckMandatoryFields$outVars", [{
name: "Filled",
attrName: "filledOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Boolean,
defaultValue: function () {
return false;
}
}]);
ShopperPortalEUController.default.clientActionProxies.shopperCheckMandatoryFields$Action = function (shopperIn) {
shopperIn = (shopperIn === undefined) ? new ShopperPortalEU_Shopper_ISModel.GetShopperResponseRec() : shopperIn;
return controller.executeActionInsideJSNode(ShopperPortalEUController.default.shopperCheckMandatoryFields$Action.bind(controller, shopperIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Filled: OS.DataConversion.JSNodeParamConverter.to(actionResults.filledOut, OS.DataTypes.DataTypes.Boolean)
};
});
};
});

define("ShopperPortalEU.controller$ShopperCreateOrUpdateDetails", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_Shopper_IS.controller", "ShopperPortalEU.controller$ShopperCreateOrUpdateDetails.SetRequestJS", "ShopperPortalEU.clientVariables", "ShopperPortalEU_Shopper_IS.controller$UpdateShopper", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS", "ShopperPortalEU.controller$ClarityEvent", "ShopperPortalEU.model$CompleteDetailsRec"], function (exports, OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_Shopper_ISController, ShopperPortalEU_controller_ShopperCreateOrUpdateDetails_SetRequestJS, ShopperPortalEUClientVariables) {
var OS = OutSystems.Internal;
ShopperPortalEUController.default.shopperCreateOrUpdateDetails$Action = function (detailsIn, initialDetailsIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.ShopperCreateOrUpdateDetails$vars"))());
vars.value.detailsInLocal = detailsIn.clone();
vars.value.initialDetailsInLocal = initialDetailsIn.clone();
var allExceptionsVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.ErrorHandlerOutputType());
var updateShopperVar = new OS.DataTypes.VariableHolder();
var setRequestJSResult = new OS.DataTypes.VariableHolder();
var initialDetailsJSONVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.JSONSerializeOutputType());
var detailsJSONVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.JSONSerializeOutputType());
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.ShopperCreateOrUpdateDetails$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.allExceptionsVar = allExceptionsVar;
varBag.updateShopperVar = updateShopperVar;
varBag.setRequestJSResult = setRequestJSResult;
varBag.initialDetailsJSONVar = initialDetailsJSONVar;
varBag.detailsJSONVar = detailsJSONVar;
varBag.outVars = outVars;
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:EsYwoHgnlECJPWIlKGpQPg:/ClientActionFlows.EsYwoHgnlECJPWIlKGpQPg:9h3JFuQx+GDkm4tLpZ6e3Q", "ShopperPortalEU", "ShopperCreateOrUpdateDetails", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:yhKbMbV_hEa5mLMH2KID0g", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:3PIrcXg+MUycR2_V7KPOgA", callContext.id);
// JSON Serialize: DetailsJSON
detailsJSONVar.value.jSONOut = OS.JSONUtils.serializeToJSON(vars.value.detailsInLocal, true, false);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:VPbQAIma4Uyew8zLN+8DJw", callContext.id);
// JSON Serialize: InitialDetailsJSON
initialDetailsJSONVar.value.jSONOut = OS.JSONUtils.serializeToJSON(vars.value.initialDetailsInLocal, true, false);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:0SkZARK+jEafKBvn+PVoNg", callContext.id);
setRequestJSResult.value = controller.safeExecuteJSNode(ShopperPortalEU_controller_ShopperCreateOrUpdateDetails_SetRequestJS, "SetRequest", "ShopperCreateOrUpdateDetails", {
Details: OS.DataConversion.JSNodeParamConverter.to(detailsJSONVar.value.jSONOut, OS.DataTypes.DataTypes.Text),
InitialDetails: OS.DataConversion.JSNodeParamConverter.to(initialDetailsJSONVar.value.jSONOut, OS.DataTypes.DataTypes.Text),
Request: OS.DataConversion.JSNodeParamConverter.to("", OS.DataTypes.DataTypes.Text)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("ShopperPortalEU.ShopperCreateOrUpdateDetails$setRequestJSResult"))();
jsNodeResult.requestOut = OS.DataConversion.JSNodeParamConverter.from($parameters.Request, OS.DataTypes.DataTypes.Text);
return jsNodeResult;
}, {}, {});
// Nothing to update 
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:gySY3WbYj0WLBeHBIRhWHw", callContext.id) && (setRequestJSResult.value.requestOut === ""))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:wghiT94Y5UKXDhuf3z8KBg", callContext.id);
// IsSuccess = True
outVars.value.isSuccessOut = true;
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:YWy+A6lF5EC_Uu1Hx6WEVg", callContext.id);
// Execute Action: UpdateShopper
return ShopperPortalEU_Shopper_ISController.default.updateShopper$Action(ShopperPortalEUClientVariables.getShopperGuid(), setRequestJSResult.value.requestOut, callContext).then(function (value) {
updateShopperVar.value = value;
}).then(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:+pYJIU2kP0elZxbnFFTDbQ", callContext.id);
// IsSuccess = UpdateShopper.IsSuccess
outVars.value.isSuccessOut = updateShopperVar.value.isSuccessOut;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:+pYJIU2kP0elZxbnFFTDbQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// ErrorMessage = UpdateShopper.ErrorMessage
outVars.value.errorMessageOut = updateShopperVar.value.errorMessageOut;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:+pYJIU2kP0elZxbnFFTDbQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// ErrorCode = UpdateShopper.ErrorCode
outVars.value.errorCodeOut = updateShopperVar.value.errorCodeOut;
});
}

}).then(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:4RPYPbKw_06pgse7wMr0qQ", callContext.id) && outVars.value.isSuccessOut)) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:CgKbZojzZkS4FLdMVpa1Yw", callContext.id);
} else {
// Mobile number already exists error
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:zqhmh8P3BUmHC4mKdrHpDA", callContext.id) && (outVars.value.errorCodeOut === "EM2210"))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:hRfcvV+cf0eJFYil658bFw", callContext.id);
// Execute Action: ClarityMobileNumber
ShopperPortalEUController.default.clarityEvent$Action("MobileAlreadyExists_error", callContext);
}

// Email already exists error
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:OvSzzOCbOUWR0R7AI32KJg", callContext.id) && (outVars.value.errorCodeOut === "EM2209"))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:WX46UoPIxUGlpf7nAdhdyw", callContext.id);
// Execute Action: ClarityEmail
ShopperPortalEUController.default.clarityEvent$Action("EmailAlreadyExists_error", callContext);
}

// ErrorMessage
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:iQD1wLXxXUiXMmqEJTPrpQ", callContext.id);
// IsSuccess = False
outVars.value.isSuccessOut = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:iQD1wLXxXUiXMmqEJTPrpQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// ErrorMessage = If
outVars.value.errorMessageOut = ((ShopperPortalEUClientVariables.getIsProfileDetailsNavigation()) ? ("Unable to save profile details") : ("Error saving details"));
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:qGfmgKtgWE2wrVRTFxg5sw", callContext.id);
// Raise Error: ShopperProfileException
throw new OS.Exceptions.Exceptions.UserException("ShopperPortalEU.ShopperProfileException", outVars.value.errorMessageOut);
}

});
}).catch(function (ex) {
OS.Logger.trace("ShopperCreateOrUpdateDetails.ShopperCreateOrUpdateDetails", OS.Exceptions.getMessage(ex), ex.name);
// Handle Error: AllExceptions
if(!(OS.Exceptions.isSystem(ex))) {
OS.Logger.error(null, ex);
allExceptionsVar.value.exceptionMessageAttr = OS.Exceptions.getMessage(ex);
OutSystemsDebugger.handleException(allExceptionsVar.value.exceptionMessageAttr, callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:b5lc0BCm_U6uEyiyS8trOg", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:+BuJiOoMS0iFLqlsrnflGw", callContext.id);
// IsSuccess = False
outVars.value.isSuccessOut = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:+BuJiOoMS0iFLqlsrnflGw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// ErrorMessage = AllExceptions.ExceptionMessage
outVars.value.errorMessageOut = allExceptionsVar.value.exceptionMessageAttr;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:1BTOrtEE+E+53Bvs_K2Mzw", callContext.id);
return OS.Flow.returnAsync(outVars.value);

});
}

throw ex;
}).then(function () {
return outVars.value;
}).then(function (res) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:EsYwoHgnlECJPWIlKGpQPg", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:EsYwoHgnlECJPWIlKGpQPg", callContext.id);
throw ex;

});
};
var controller = ShopperPortalEUController.default;
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.ShopperCreateOrUpdateDetails$vars", [{
name: "Details",
attrName: "detailsInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Record,
defaultValue: function () {
return new ShopperPortalEUModel.CompleteDetailsRec();
},
complexType: ShopperPortalEUModel.CompleteDetailsRec
}, {
name: "InitialDetails",
attrName: "initialDetailsInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Record,
defaultValue: function () {
return new ShopperPortalEUModel.CompleteDetailsRec();
},
complexType: ShopperPortalEUModel.CompleteDetailsRec
}]);
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.ShopperCreateOrUpdateDetails$setRequestJSResult", [{
name: "Request",
attrName: "requestOut",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.ShopperCreateOrUpdateDetails$outVars", [{
name: "IsSuccess",
attrName: "isSuccessOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "ErrorMessage",
attrName: "errorMessageOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}, {
name: "ErrorCode",
attrName: "errorCodeOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEUController.default.clientActionProxies.shopperCreateOrUpdateDetails$Action = function (detailsIn, initialDetailsIn) {
detailsIn = (detailsIn === undefined) ? new ShopperPortalEUModel.CompleteDetailsRec() : detailsIn;
initialDetailsIn = (initialDetailsIn === undefined) ? new ShopperPortalEUModel.CompleteDetailsRec() : initialDetailsIn;
return controller.executeActionInsideJSNode(ShopperPortalEUController.default.shopperCreateOrUpdateDetails$Action.bind(controller, detailsIn, initialDetailsIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
IsSuccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.isSuccessOut, OS.DataTypes.DataTypes.Boolean),
ErrorMessage: OS.DataConversion.JSNodeParamConverter.to(actionResults.errorMessageOut, OS.DataTypes.DataTypes.Text),
ErrorCode: OS.DataConversion.JSNodeParamConverter.to(actionResults.errorCodeOut, OS.DataTypes.DataTypes.Text)
};
});
};
});
define("ShopperPortalEU.controller$ShopperCreateOrUpdateDetails.SetRequestJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
let d = JSON.parse($parameters.Details),
    id = JSON.parse($parameters.InitialDetails),
    r = [];
if (d.personalDetails.givenNames != id.personalDetails.givenNames) {
    r.push({
        "op": "replace",
        "path": "/FirstName",
        "value": d.personalDetails.givenNames
    });
}
if (d.personalDetails.surname != id.personalDetails.surname) {
    r.push({
        "op": "replace",
        "path": "/LastName",
        "value": d.personalDetails.surname
    });
}
if (d.personalDetails.birthDate != id.personalDetails.birthDate) {
    r.push({
        "op": "replace",
        "path": "/DateOfBirth",
        "value": d.personalDetails.birthDate
    });
}
if (d.personalDetails.nationality != id.personalDetails.nationality) {
    r.push({
        "op": "replace",
        "path": "/NationalityIso",
        "value": d.personalDetails.nationality
    });
}
if (d.address.country != id.address.country) {
    r.push({
        "op": "replace",
        "path": "/CountryOfResidenceIso",
        "value": d.address.country
    });
}
if (d.address.addressLine1 != id.address.addressLine1) {
    r.push({
        "op": "replace",
        "path": "/AddressLineOne",
        "value": d.address.addressLine1
    });
}
if (d.address.addressLine2 != id.address.addressLine2) {
    r.push({
        "op": "replace",
        "path": "/AddressLineTwo",
        "value": d.address.addressLine2
    });
}
if (d.address.postcode != id.address.postcode) {
    r.push({
        "op": "replace",
        "path": "/PostCode",
        "value": d.address.postcode
    });
}
if (d.address.city != id.address.city) {
    r.push({
        "op": "replace",
        "path": "/City",
        "value": d.address.city
    });
}
if (d.address.state != id.address.state) {
    r.push({
        "op": "replace",
        "path": "/Region",
        "value": d.address.state
    });
}
if (d.contact.mobileNumber != id.contact.mobileNumber) {
    r.push({
        "op": "replace",
        "path": "/UserProfile/MobileNumber",
        "value": d.contact.mobileNumber
    });
}
if (d.contact.email != id.contact.email) {
    r.push({
        "op": "replace",
        "path": "/UserProfile/Email",
        "value": d.contact.email
    });
}
if (r.length) {
    $parameters.Request = JSON.stringify(r);
}

};
});

define("ShopperPortalEU.controller$ShopperLogout", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "Auth_Europe.controller", "ShopperPortalEU.clientVariables", "Auth_Europe.controller$Auth0Logout", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$Auth_Europe"], function (exports, OutSystems, ShopperPortalEUModel, ShopperPortalEUController, Auth_EuropeController, ShopperPortalEUClientVariables) {
var OS = OutSystems.Internal;
ShopperPortalEUController.default.shopperLogout$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:39X2gaHZUE2wJjipXCg8EQ:/ClientActionFlows.39X2gaHZUE2wJjipXCg8EQ:DaKfzDUFujJM1w_ThGPPrg", "ShopperPortalEU", "ShopperLogout", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:iyW+WmpD4kuR0BWBs6QOGg", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
// Clean client variables
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:zpKM4+pf80m0sYTOqWLsLw", callContext.id);
// ShopperChecked = False
ShopperPortalEUClientVariables.setShopperChecked(false);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:zpKM4+pf80m0sYTOqWLsLw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// AnonymousFormList = ""
ShopperPortalEUClientVariables.setAnonymousFormList("");
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:zpKM4+pf80m0sYTOqWLsLw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// FormInfoListJSON = ""
ShopperPortalEUClientVariables.setFormInfoListJSON("");
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:zpKM4+pf80m0sYTOqWLsLw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// FormNumberRA1 = ""
ShopperPortalEUClientVariables.setFormNumberRA1("");
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:zpKM4+pf80m0sYTOqWLsLw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// FormNumberVA1 = ""
ShopperPortalEUClientVariables.setFormNumberVA1("");
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:zpKM4+pf80m0sYTOqWLsLw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "6");
// FormNumberVA2 = ""
ShopperPortalEUClientVariables.setFormNumberVA2("");
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:zpKM4+pf80m0sYTOqWLsLw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "7");
// RefundSummaryFormListJSON = ""
ShopperPortalEUClientVariables.setRefundSummaryFormListJSON("");
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:mOp3VxM__k6ZTJ22yrROlg", callContext.id);
// Execute Action: Auth0Logout
return Auth_EuropeController.default.auth0Logout$Action(ShopperPortalEUClientVariables.getLoginURL(), callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:10mnqRyfkU2xQfgGvC0MfA", callContext.id);
});
}).then(function () {
return ;
}).then(function (res) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:39X2gaHZUE2wJjipXCg8EQ", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:39X2gaHZUE2wJjipXCg8EQ", callContext.id);
throw ex;

});
};
var controller = ShopperPortalEUController.default;
ShopperPortalEUController.default.clientActionProxies.shopperLogout$Action = function () {
return controller.executeActionInsideJSNode(ShopperPortalEUController.default.shopperLogout$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});

define("ShopperPortalEU.controller$SplitString", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU.controller$SplitString.StringSplitJS", "ShopperPortalEU.clientVariables"], function (exports, OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_controller_SplitString_StringSplitJS, ShopperPortalEUClientVariables) {
var OS = OutSystems.Internal;
ShopperPortalEUController.default.splitString$Action = function (valueIn, separatorIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.SplitString$vars"))());
vars.value.valueInLocal = valueIn;
vars.value.separatorInLocal = separatorIn;
var stringSplitJSResult = new OS.DataTypes.VariableHolder();
var jSONDeserializeTextListVar = new OS.DataTypes.VariableHolder(new (OS.Controller.BaseController.getJSONDeserializeOutputType(OS.DataTypes.TextList))());
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.SplitString$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.stringSplitJSResult = stringSplitJSResult;
varBag.jSONDeserializeTextListVar = jSONDeserializeTextListVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:HzhdKmjTx0680Su4V867UA:/ClientActionFlows.HzhdKmjTx0680Su4V867UA:MUEaTSUCrIruMmf6SvP4Xg", "ShopperPortalEU", "SplitString", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:5YLcWjJsbkif81wEhwqfbA", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ljLMf01d+EO05BpP13u2Mw", callContext.id);
// JS function that returns a JSON array of strings
stringSplitJSResult.value = controller.safeExecuteJSNode(ShopperPortalEU_controller_SplitString_StringSplitJS, "StringSplit", "SplitString", {
String: OS.DataConversion.JSNodeParamConverter.to(vars.value.valueInLocal, OS.DataTypes.DataTypes.Text),
Delimiter: OS.DataConversion.JSNodeParamConverter.to(vars.value.separatorInLocal, OS.DataTypes.DataTypes.Text),
ListJSON: OS.DataConversion.JSNodeParamConverter.to("", OS.DataTypes.DataTypes.Text)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("ShopperPortalEU.SplitString$stringSplitJSResult"))();
jsNodeResult.listJSONOut = OS.DataConversion.JSNodeParamConverter.from($parameters.ListJSON, OS.DataTypes.DataTypes.Text);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:g1AKODxz2E+RH9nE5boGSA", callContext.id);
// JSON Deserialize: JSONDeserializeTextList
jSONDeserializeTextListVar.value.dataOut = OS.JSONUtils.deserializeFromJSON(stringSplitJSResult.value.listJSONOut, OS.DataTypes.TextList, false);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:YZyXwis5PkqRogauSWKeiQ", callContext.id);
// List = JSONDeserializeTextList.Data
outVars.value.listOut = jSONDeserializeTextListVar.value.dataOut;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:XQT3bTkdVk+BuL7MY1z6Hg", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:HzhdKmjTx0680Su4V867UA", callContext.id);
}

};
var controller = ShopperPortalEUController.default;
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.SplitString$vars", [{
name: "Value",
attrName: "valueInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}, {
name: "Separator",
attrName: "separatorInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.SplitString$stringSplitJSResult", [{
name: "ListJSON",
attrName: "listJSONOut",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.SplitString$outVars", [{
name: "List",
attrName: "listOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.RecordList,
defaultValue: function () {
return new OS.DataTypes.TextList();
},
complexType: OS.DataTypes.TextList
}]);
ShopperPortalEUController.default.clientActionProxies.splitString$Action = function (valueIn, separatorIn) {
valueIn = (valueIn === undefined) ? "" : valueIn;
separatorIn = (separatorIn === undefined) ? "" : separatorIn;
return controller.executeActionInsideJSNode(ShopperPortalEUController.default.splitString$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(valueIn, OS.DataTypes.DataTypes.Text), OS.DataConversion.JSNodeParamConverter.from(separatorIn, OS.DataTypes.DataTypes.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
List: actionResults.listOut
};
});
};
});
define("ShopperPortalEU.controller$SplitString.StringSplitJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
function splitTextToJson(text, delimiters) {
    // Create a regular expression to match any of the delimiter characters
    const regex = new RegExp(`[${delimiters}]`);
    
    // Split the text using the regex and filter out any empty strings
    const result = text.split(regex).filter(Boolean);
    
    // Convert the result array to JSON format
    return JSON.stringify(result);
}

const text = $parameters.String;
const delimiters = $parameters.Delimiter;
$parameters.ListJSON = splitTextToJson(text, delimiters);
};
});

define("ShopperPortalEU.controller$TRuleWrapper", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_DataSync.controller", "ShopperPortalEU.clientVariables", "ShopperPortalEU_DataSync.controller$TCMS", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_DataSync"], function (exports, OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_DataSyncController, ShopperPortalEUClientVariables) {
var OS = OutSystems.Internal;
ShopperPortalEUController.default.tRuleWrapper$Action = function (keyIn, countryCodeIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.TRuleWrapper$vars"))());
vars.value.keyInLocal = keyIn;
vars.value.countryCodeInLocal = countryCodeIn;
var tCMSVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.TRuleWrapper$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.tCMSVar = tCMSVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:UXqj0dL5dE+iWw8NeBL2oQ:/ClientActionFlows.UXqj0dL5dE+iWw8NeBL2oQ:tO41qETHiAwerBnFy444dA", "ShopperPortalEU", "TRuleWrapper", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:0gMGwTGsj0GUUyaZN0IeSg", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:IqxXDZRZXUGZ_8GG9KdbEg", callContext.id);
// Execute Action: TCMS
tCMSVar.value = ShopperPortalEU_DataSyncController.default.tCMS$Action(vars.value.keyInLocal, ((((vars.value.countryCodeInLocal) !== (""))) ? (vars.value.countryCodeInLocal) : ("PT")), callContext);

OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:4vWqVq7FV0OHOM8esUm6fg", callContext.id);
// Text = TCMS.Text
outVars.value.textOut = tCMSVar.value.textOut;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:BOTigerCBkCGf+xJ9hdtXg", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:UXqj0dL5dE+iWw8NeBL2oQ", callContext.id);
}

};
var controller = ShopperPortalEUController.default;
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.TRuleWrapper$vars", [{
name: "Key",
attrName: "keyInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}, {
name: "CountryCode",
attrName: "countryCodeInLocal",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.TRuleWrapper$outVars", [{
name: "Text",
attrName: "textOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEUController.default.clientActionProxies.tRuleWrapper$Action = function (keyIn, countryCodeIn) {
keyIn = (keyIn === undefined) ? "" : keyIn;
countryCodeIn = (countryCodeIn === undefined) ? "" : countryCodeIn;
return controller.executeActionInsideJSNode(ShopperPortalEUController.default.tRuleWrapper$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(keyIn, OS.DataTypes.DataTypes.Text), OS.DataConversion.JSNodeParamConverter.from(countryCodeIn, OS.DataTypes.DataTypes.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Text: OS.DataConversion.JSNodeParamConverter.to(actionResults.textOut, OS.DataTypes.DataTypes.Text)
};
});
};
});

define("ShopperPortalEU.controller$UpdateAnonymousFormAttempt", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU.clientVariables", "ShopperPortalEU.model$AnonymousFormsList", "ShopperPortalEU.model$AnonymousFormsRec"], function (exports, OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEUClientVariables) {
var OS = OutSystems.Internal;
ShopperPortalEUController.default.updateAnonymousFormAttempt$Action = function (anonymousFormsListIn, nrOfAttemptsIn, listOfAnonymousFormsIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.UpdateAnonymousFormAttempt$vars"))());
vars.value.anonymousFormsListInLocal = anonymousFormsListIn;
vars.value.nrOfAttemptsInLocal = nrOfAttemptsIn;
vars.value.listOfAnonymousFormsInLocal = listOfAnonymousFormsIn.clone();
var searchPositionofFormToUpdateVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.vars = vars;
varBag.searchPositionofFormToUpdateVar = searchPositionofFormToUpdateVar;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:+nRhPR_M_UeDxjLI3LDXFA:/ClientActionFlows.+nRhPR_M_UeDxjLI3LDXFA:4azocdUBEKNHMy1Y8Gdc8Q", "ShopperPortalEU", "UpdateAnonymousFormAttempt", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:y3Wk8WLU2k60VIburUCh1w", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:l0icP7g0ekaahz+XnVMzHw", callContext.id);
// FormNumber_AttemptNr.FormNumber = AnonymousFormsList
vars.value.formNumber_AttemptNrVar.formNumberAttr = vars.value.anonymousFormsListInLocal;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:l0icP7g0ekaahz+XnVMzHw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// FormNumber_AttemptNr.AttempNr = NrOfAttempts
vars.value.formNumber_AttemptNrVar.attempNrAttr = vars.value.nrOfAttemptsInLocal;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:isz23JE_xUev0sIG68hL5Q", callContext.id);
// Execute Action: SearchPositionofFormToUpdate
searchPositionofFormToUpdateVar.value = OS.SystemActions.listIndexOf(vars.value.listOfAnonymousFormsInLocal, function (p) {
return (p.formNumberAttr === vars.value.anonymousFormsListInLocal);
}, callContext);

// Found?
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:C1dWd3DxJ0mQCSMF9O+5IQ", callContext.id) && ((searchPositionofFormToUpdateVar.value.positionOut) !== (-1)))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Yq_UMe1Kc0axj0GkNRwzyA", callContext.id);
// ListOfAnonymousForms[SearchPositionofFormToUpdate.Position].AttempNr = FormNumber_AttemptNr.AttempNr
vars.value.listOfAnonymousFormsInLocal.getItem(searchPositionofFormToUpdateVar.value.positionOut).attempNrAttr = vars.value.formNumber_AttemptNrVar.attempNrAttr;
// Foreach ListOfAnonymousForms
callContext.iterationContext.registerIterationStart(vars.value.listOfAnonymousFormsInLocal);
try {var listOfAnonymousFormsIterator = callContext.iterationContext.getIterator(vars.value.listOfAnonymousFormsInLocal);
var listOfAnonymousFormsIndex = 0;
while ((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:VbOh+aiAdUq7ViyYQh_eNA", callContext.id) && (listOfAnonymousFormsIndex < vars.value.listOfAnonymousFormsInLocal.length))) {
listOfAnonymousFormsIterator.currentRowNumber = listOfAnonymousFormsIndex;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:rJR1fpIrfUytSNAomTqeqA", callContext.id);
// FormNumber_AttemptNrString = ListOfAnonymousForms.Current.FormNumber + "_" + ListOfAnonymousForms.Current.AttempNr
vars.value.formNumber_AttemptNrStringVar = ((vars.value.listOfAnonymousFormsInLocal.getItem(listOfAnonymousFormsIndex.valueOf()).formNumberAttr + "_") + vars.value.listOfAnonymousFormsInLocal.getItem(listOfAnonymousFormsIndex.valueOf()).attempNrAttr);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:rJR1fpIrfUytSNAomTqeqA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// AnonymousFormsStirng = If
vars.value.anonymousFormsStirngVar = (((vars.value.anonymousFormsStirngVar === "")) ? (vars.value.formNumber_AttemptNrStringVar) : (((vars.value.anonymousFormsStirngVar + ",") + vars.value.formNumber_AttemptNrStringVar)));
// ClearLocalString
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:mLJ74XfUGE2La58d5j9smw", callContext.id);
// FormNumber_AttemptNrString = ""
vars.value.formNumber_AttemptNrStringVar = "";
listOfAnonymousFormsIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(vars.value.listOfAnonymousFormsInLocal);
}

// Update Client var AnonymousFormList
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:8pCGgb9TxUaGMnRcVrMzZg", callContext.id);
// AnonymousFormList = AnonymousFormsStirng
ShopperPortalEUClientVariables.setAnonymousFormList(vars.value.anonymousFormsStirngVar);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:xgUQNJ70pEaSsfkJ_eFKcw", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Bh+c7PopSE6VuW0LQgcg1w", callContext.id);
}

return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:+nRhPR_M_UeDxjLI3LDXFA", callContext.id);
}

};
var controller = ShopperPortalEUController.default;
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU.UpdateAnonymousFormAttempt$vars", [{
name: "AnonymousFormsList",
attrName: "anonymousFormsListInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}, {
name: "NrOfAttempts",
attrName: "nrOfAttemptsInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}, {
name: "ListOfAnonymousForms",
attrName: "listOfAnonymousFormsInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.RecordList,
defaultValue: function () {
return new ShopperPortalEUModel.AnonymousFormsList();
},
complexType: ShopperPortalEUModel.AnonymousFormsList
}, {
name: "FormNumber_AttemptNr",
attrName: "formNumber_AttemptNrVar",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Record,
defaultValue: function () {
return new ShopperPortalEUModel.AnonymousFormsRec();
},
complexType: ShopperPortalEUModel.AnonymousFormsRec
}, {
name: "AnonymousFormsStirng",
attrName: "anonymousFormsStirngVar",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}, {
name: "FormNumber_AttemptNrString",
attrName: "formNumber_AttemptNrStringVar",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEUController.default.clientActionProxies.updateAnonymousFormAttempt$Action = function (anonymousFormsListIn, nrOfAttemptsIn, listOfAnonymousFormsIn) {
anonymousFormsListIn = (anonymousFormsListIn === undefined) ? "" : anonymousFormsListIn;
nrOfAttemptsIn = (nrOfAttemptsIn === undefined) ? "" : nrOfAttemptsIn;
listOfAnonymousFormsIn = (listOfAnonymousFormsIn === undefined) ? new ShopperPortalEUModel.AnonymousFormsList() : listOfAnonymousFormsIn;
return controller.executeActionInsideJSNode(ShopperPortalEUController.default.updateAnonymousFormAttempt$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(anonymousFormsListIn, OS.DataTypes.DataTypes.Text), OS.DataConversion.JSNodeParamConverter.from(nrOfAttemptsIn, OS.DataTypes.DataTypes.Text), listOfAnonymousFormsIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});

define("ShopperPortalEU.controller$ServerAction.FormatPassportData", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU.model$ScanPassportRec"], function (exports, OutSystems, ShopperPortalEUModel, ShopperPortalEUController) {
var OS = OutSystems.Internal;
ShopperPortalEUController.default.formatPassportData$ServerAction = function (passportIn, callContext) {
var controller = this.controller;
var inputs = {
Passport: OS.DataConversion.ServerDataConverter.to(passportIn, OS.DataTypes.DataTypes.Record)
};
return controller.callServerAction("FormatPassportData", "screenservices/ShopperPortalEU/ActionFormatPassportData", "JCm+EjJwZWCzrbjKObJPAA", inputs, controller.callContext(callContext), OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, false).then(function (outputs) {
var executeServerActionResult = new (controller.constructor.getVariableGroupType("ShopperPortalEU$ActionFormatPassportData"))();
executeServerActionResult.formattedPassportOut = OS.DataConversion.ServerDataConverter.from(outputs.FormattedPassport, ShopperPortalEUModel.ScanPassportRec);
return executeServerActionResult;
});
};
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU$ActionFormatPassportData", [{
name: "FormattedPassport",
attrName: "formattedPassportOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Record,
defaultValue: function () {
return new ShopperPortalEUModel.ScanPassportRec();
},
complexType: ShopperPortalEUModel.ScanPassportRec
}]);
});
define("ShopperPortalEU.controller$ServerAction.FormatPassports", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU.model$PassportList"], function (exports, OutSystems, ShopperPortalEUModel, ShopperPortalEUController) {
var OS = OutSystems.Internal;
ShopperPortalEUController.default.formatPassports$ServerAction = function (travelDocumentsIn, callContext) {
var controller = this.controller;
var inputs = {
TravelDocuments: OS.DataConversion.ServerDataConverter.to(travelDocumentsIn, OS.DataTypes.DataTypes.RecordList)
};
return controller.callServerAction("FormatPassports", "screenservices/ShopperPortalEU/ActionFormatPassports", "OfHll1JbKKptgXT6s5lgpw", inputs, controller.callContext(callContext), OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, false).then(function (outputs) {
var executeServerActionResult = new (controller.constructor.getVariableGroupType("ShopperPortalEU$ActionFormatPassports"))();
executeServerActionResult.passportsOut = OS.DataConversion.ServerDataConverter.from(outputs.Passports, ShopperPortalEUModel.PassportList);
return executeServerActionResult;
});
};
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU$ActionFormatPassports", [{
name: "Passports",
attrName: "passportsOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.RecordList,
defaultValue: function () {
return new ShopperPortalEUModel.PassportList();
},
complexType: ShopperPortalEUModel.PassportList
}]);
});
define("ShopperPortalEU.controller$ServerAction.GetApplicationReadyData", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller"], function (exports, OutSystems, ShopperPortalEUModel, ShopperPortalEUController) {
var OS = OutSystems.Internal;
ShopperPortalEUController.default.getApplicationReadyData$ServerAction = function (callContext) {
var controller = this.controller;
return controller.callServerAction("GetApplicationReadyData", "screenservices/ShopperPortalEU/ActionGetApplicationReadyData", "fxdn1usw9jmCCTQ20HaXbw", {}, controller.callContext(callContext), OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, false).then(function (outputs) {
var executeServerActionResult = new (controller.constructor.getVariableGroupType("ShopperPortalEU$ActionGetApplicationReadyData"))();
executeServerActionResult.clarityIdOut = OS.DataConversion.ServerDataConverter.from(outputs.ClarityId, OS.DataTypes.DataTypes.Text);
executeServerActionResult.activeOut = OS.DataConversion.ServerDataConverter.from(outputs.Active, OS.DataTypes.DataTypes.Boolean);
executeServerActionResult.isInMaintenanceOut = OS.DataConversion.ServerDataConverter.from(outputs.IsInMaintenance, OS.DataTypes.DataTypes.Boolean);
executeServerActionResult.heapApplicationIdOut = OS.DataConversion.ServerDataConverter.from(outputs.HeapApplicationId, OS.DataTypes.DataTypes.Text);
executeServerActionResult.isHeapActiveOut = OS.DataConversion.ServerDataConverter.from(outputs.IsHeapActive, OS.DataTypes.DataTypes.Boolean);
return executeServerActionResult;
});
};
ShopperPortalEUController.default.constructor.registerVariableGroupType("ShopperPortalEU$ActionGetApplicationReadyData", [{
name: "ClarityId",
attrName: "clarityIdOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}, {
name: "Active",
attrName: "activeOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "IsInMaintenance",
attrName: "isInMaintenanceOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "HeapApplicationId",
attrName: "heapApplicationIdOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}, {
name: "IsHeapActive",
attrName: "isHeapActiveOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Boolean,
defaultValue: function () {
return false;
}
}]);
});
define("ShopperPortalEU.controller", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller$debugger"], function (exports, OutSystems, ShopperPortalEUModel, ShopperPortalEU_Controller_debugger) {
var OS = OutSystems.Internal;
var ShopperPortalEUController = exports;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
this.registerOnApplicationReadyHandler("ShopperPortalEU.controller$OnApplicationReady", "onApplicationReady$Action");
}
Controller.prototype.clientActionProxies = {};
Controller.prototype.roles = {};
Controller.prototype.defaultTimeout = 30;
Controller.prototype.getDefaultTimeout = function () {
return ShopperPortalEUController.default.defaultTimeout;
};
Controller.prototype.getClientActionProxies = function (controller) {
var _this = this;
var thisController = controller;
return Object.keys(this.clientActionProxies).reduce(function (acc, actionName) {
acc[actionName] = function () {
if(thisController.isActive()) {
return _this.clientActionProxies[actionName].apply(thisController, arguments);
}

return Promise.resolve();
};
return acc;
}, {});
};
return Controller;
})(OS.Controller.BaseModuleController);
ShopperPortalEUController.default = new Controller(null, "ShopperPortalEU");
});
define("ShopperPortalEU.controller$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.clientVariables"], function (exports, Debugger, OutSystems, ShopperPortalEUClientVariables) {
var OS = OutSystems.Internal;
var metaInfo = {
"jBuyqOueHkGhvDhEKqImDw": {
getter: function (varBag, idService) {
return varBag.vars.value.cardExpiryDateInLocal;
},
dataType: OS.DataTypes.DataTypes.Date
},
"rv0lNQqK50CNt0oxDYrhSg": {
getter: function (varBag, idService) {
return varBag.vars.value.cardDetailsDataInLocal;
}
},
"BFXnwieHqEG_ebGKDzB25A": {
getter: function (varBag, idService) {
return varBag.outVars.value.isValidOut;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"29bu6kFeIE27FyzviQ9GKQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.errorMessageOut;
},
dataType: OS.DataTypes.DataTypes.Text
},
"AiqsSdbzMk6wvsiOZ18nIw": {
getter: function (varBag, idService) {
return varBag.outVars.value.isExpiryDateErrorOut;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"WbvuQ4yJOkitFhEhfdv_wQ": {
getter: function (varBag, idService) {
return varBag.vars.value.givenNamesInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"SThe0AQW+k26GRIoC4D+pQ": {
getter: function (varBag, idService) {
return varBag.vars.value.surnameInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"UmshV+UPjk2wdIFdgEgzqQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.formattedShopperNameOut;
},
dataType: OS.DataTypes.DataTypes.Text
},
"1mMnmuLGH022UvzHgoCrgg": {
getter: function (varBag, idService) {
return varBag.vars.value.shopperInLocal;
}
},
"yUDNSc7zxEOlHFytoRpWJA": {
getter: function (varBag, idService) {
return varBag.outVars.value.redirectOut;
},
dataType: OS.DataTypes.DataTypes.Integer
},
"ob3qP2fBQE+bQqpD4eXNzA": {
getter: function (varBag, idService) {
return varBag.shopperCheckMandatoryFieldsVar.value;
}
},
"fmjURwsVT0Oq0suwx+xb0Q": {
getter: function (varBag, idService) {
return varBag.scanPassportFromJSONVar.value;
}
},
"YUBcMTCtmkC6rV0yCGYYuQ": {
getter: function (varBag, idService) {
return varBag.vars.value.codeInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"xnzByWCog0Sn3_ENYbeVEA": {
getter: function (varBag, idService) {
return varBag.outVars.value.nameOut;
},
dataType: OS.DataTypes.DataTypes.Text
},
"DkdE+95WKU+1pN_1tdPQdA": {
getter: function (varBag, idService) {
return varBag.getCountryNameJSResult.value;
}
},
"qUFFkOTrPUG2qwXGCP1KCg": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasErrorOut;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"91T3oElzKE2TbfY1L0JDnw": {
getter: function (varBag, idService) {
return varBag.outVars.value.redirectOut;
},
dataType: OS.DataTypes.DataTypes.Integer
},
"NgQWNcNvx02QvZFgWcj0HA": {
getter: function (varBag, idService) {
return varBag.allExceptionsVar.value;
}
},
"Iw_kdFEmdE2eGvrhst86_A": {
getter: function (varBag, idService) {
return varBag.getShopperVar.value;
}
},
"CI3n+9nvGUei5n4WdNvdvg": {
getter: function (varBag, idService) {
return varBag.redirectShopperVar.value;
}
},
"qtTWMYIC6kKqPWk8lUI6fA": {
getter: function (varBag, idService) {
return varBag.outVars.value.resultOut;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"0EpDVsPnEkyTbRHyE+4gfg": {
getter: function (varBag, idService) {
return varBag.outVars.value.successOut;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"2khrqwnaY0yP8EXq2dYawA": {
getter: function (varBag, idService) {
return varBag.outVars.value.errorMessageOut;
},
dataType: OS.DataTypes.DataTypes.Text
},
"Nr9KAJ+FF0SW0F5oNvuj9w": {
getter: function (varBag, idService) {
return varBag.getShopperVar.value;
}
},
"oVgddlz1ykS1ymh716YnBA": {
getter: function (varBag, idService) {
return varBag.vars.value.stringInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"rFczbWwQE0SI+3zrRxavtw": {
getter: function (varBag, idService) {
return varBag.outVars.value.formattedStringOut;
},
dataType: OS.DataTypes.DataTypes.Text
},
"ZcwwK72tAUiRhzvERvV5Jg": {
getter: function (varBag, idService) {
return varBag.vars.value.valueInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"9eBZe+ZY_0aqADGjQHjbVw": {
getter: function (varBag, idService) {
return varBag.vars.value.separatorInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"+8GN6V1VH0ehjNOZ341B8g": {
getter: function (varBag, idService) {
return varBag.outVars.value.listOut;
}
},
"g1AKODxz2E+RH9nE5boGSA": {
getter: function (varBag, idService) {
return varBag.jSONDeserializeTextListVar.value;
}
},
"ljLMf01d+EO05BpP13u2Mw": {
getter: function (varBag, idService) {
return varBag.stringSplitJSResult.value;
}
},
"IAeaR4i20Ey69sU7vHFZ_g": {
getter: function (varBag, idService) {
return varBag.vars.value.detailsVar;
}
},
"tCM40PbG4k2BAychzmkMHQ": {
getter: function (varBag, idService) {
return varBag.vars.value.getShopperResponseInLocal;
}
},
"qz1y8byOBUCOP1lQrhgi4Q": {
getter: function (varBag, idService) {
return varBag.outVars.value.percentageProfileCompleteOut;
},
dataType: OS.DataTypes.DataTypes.Decimal
},
"5dQoqB1WD0eNwd77Yg7Mtg": {
getter: function (varBag, idService) {
return varBag.percentageProfileCalculationVar.value;
}
},
"yQYkFmB0J0e6oWZgMYP2XA": {
getter: function (varBag, idService) {
return varBag.vars.value.maskedCardInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"CT5WJJEes0yXGrBexEsVXw": {
getter: function (varBag, idService) {
return varBag.outVars.value.outputOut;
},
dataType: OS.DataTypes.DataTypes.Text
},
"EI868jq6g0KhGQ5alR9S2A": {
getter: function (varBag, idService) {
return varBag.vars.value.userStringInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"+oSDdhwXiEOkYr3x1TkFLw": {
getter: function (varBag, idService) {
return varBag.identifyJSResult.value;
}
},
"qAu1r1WHd02TQ82MtL5QTw": {
getter: function (varBag, idService) {
return varBag.vars.value.formNumber_AttemptNrVar;
}
},
"FEmOBj0mtkW__cyPcOLKgA": {
getter: function (varBag, idService) {
return varBag.vars.value.anonymousFormsStirngVar;
},
dataType: OS.DataTypes.DataTypes.Text
},
"nRv+yv2lskeT1RzdXvgONA": {
getter: function (varBag, idService) {
return varBag.vars.value.formNumber_AttemptNrStringVar;
},
dataType: OS.DataTypes.DataTypes.Text
},
"KjLCk7IRGUWhGsXYTrgH0A": {
getter: function (varBag, idService) {
return varBag.vars.value.anonymousFormsListInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"aU2EYd2ZX0OpG1j1xMacnA": {
getter: function (varBag, idService) {
return varBag.vars.value.nrOfAttemptsInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"UdjwFa1uBkeB3iaCpCK7jg": {
getter: function (varBag, idService) {
return varBag.vars.value.listOfAnonymousFormsInLocal;
}
},
"isz23JE_xUev0sIG68hL5Q": {
getter: function (varBag, idService) {
return varBag.searchPositionofFormToUpdateVar.value;
}
},
"_IGa+EuAM0S7snurzbu9YA": {
getter: function (varBag, idService) {
return varBag.outVars.value.errorMessageOut;
},
dataType: OS.DataTypes.DataTypes.Text
},
"dwNeuLjAfE+tVFFqyv5wPQ": {
getter: function (varBag, idService) {
return varBag.vars.value.inputInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"ueO5qeBHS069FPmdyQkpFA": {
getter: function (varBag, idService) {
return varBag.outVars.value.outputOut;
},
dataType: OS.DataTypes.DataTypes.Text
},
"9uCWj3HMwkeSgRHTsxvLEA": {
getter: function (varBag, idService) {
return varBag.regexCardHolderNameInputJSResult.value;
}
},
"Wz+uPs+Ex0uAE9X4AOstvw": {
getter: function (varBag, idService) {
return varBag.vars.value.apcuesIdentifyInLocal;
}
},
"oHLvWNVNykebNygQaMD0pQ": {
getter: function (varBag, idService) {
return varBag.identifyJSResult.value;
}
},
"JUIMLy5LjUCICOXjB96_ew": {
getter: function (varBag, idService) {
return varBag.vars.value.passportInLocal;
}
},
"WC3xon+aJ0iCZyO48ZfNCw": {
getter: function (varBag, idService) {
return varBag.outVars.value.formattedPassportOut;
}
},
"WQ4Q0OmJBk+n2G7hXqBtNg": {
getter: function (varBag, idService) {
return varBag.formatPassportDataVar.value;
}
},
"Zn6GsZeMV0KU68Jyoq3RHQ": {
getter: function (varBag, idService) {
return varBag.vars.value.refundSummaryFormRecVar;
}
},
"213U3mKV80iFr2GEGTP+_Q": {
getter: function (varBag, idService) {
return varBag.vars.value.hasMultipleCurrenciesVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"A8lDqKapDEG09O5kQIQb7g": {
getter: function (varBag, idService) {
return varBag.vars.value.formInfoListInLocal;
}
},
"iuV5EVmCzEisI2QjUzML_Q": {
getter: function (varBag, idService) {
return varBag.outVars.value.formsList_ReadyForRefundOut;
}
},
"hfdAVTldcEq80yLryCXY8Q": {
getter: function (varBag, idService) {
return varBag.outVars.value.refundSummaryFormListOut;
}
},
"ZVTDJcYzd0CY8jPKCzFNPQ": {
getter: function (varBag, idService) {
return varBag.listFilterByRA1Var.value;
}
},
"mKFKLDZJFUy6a4HkO47Jrw": {
getter: function (varBag, idService) {
return varBag.listFilterByVA2Var.value;
}
},
"sfUxeyRxRESi+F5AcR192Q": {
getter: function (varBag, idService) {
return varBag.listFilterByVA1Var.value;
}
},
"Ysdx_ZvTFUKqddiwg_LQlA": {
getter: function (varBag, idService) {
return varBag.listFilter_ReadyForRefundVar.value;
}
},
"AB2_6vqchUmdMkdvVnFzNw": {
getter: function (varBag, idService) {
return varBag.outVars.value.errorMessageOut;
},
dataType: OS.DataTypes.DataTypes.Text
},
"auPSgnuOK0GLp_fo0QbJWA": {
getter: function (varBag, idService) {
return varBag.vars.value.formNumber_AttemptNrVar;
},
dataType: OS.DataTypes.DataTypes.Text
},
"yaKPfFMkE0GdeqYhNslq5A": {
getter: function (varBag, idService) {
return varBag.vars.value.anonymousFormNumberInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"lYDkxyT+NUyN0Hw3jS_4Rw": {
getter: function (varBag, idService) {
return varBag.vars.value.nrOfAttemptsInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"fj3GdrLj1EuTOEPg+LUN5g": {
getter: function (varBag, idService) {
return varBag.listFilterVar.value;
}
},
"hkI2oxO+yEmuGgD+tL1IbA": {
getter: function (varBag, idService) {
return varBag.getAnonymousFormsListVar.value;
}
},
"WWdXYyS71EW7HvfDA8WXxQ": {
getter: function (varBag, idService) {
return varBag.vars.value.locationHoursInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"Y1gzDs3lQEKlsR3bkv8IYw": {
getter: function (varBag, idService) {
return varBag.outVars.value.formattedLocationHoursOut;
},
dataType: OS.DataTypes.DataTypes.Text
},
"q8XpTkOQJUGvajVjWsM19w": {
getter: function (varBag, idService) {
return varBag.formatLocationHoursJSResult.value;
}
},
"8lLxc0iH2kie0YIPmRga_w": {
getter: function (varBag, idService) {
return varBag.initJSResult.value;
}
},
"KFKrlxnE+Umxx8AEaPy47A": {
getter: function (varBag, idService) {
return varBag.vars.value.notRedirectInLocal;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"q5bCWZtfrk6e2DRNA9+yyA": {
getter: function (varBag, idService) {
return varBag.outVars.value.isAuthenticatedOut;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"9OL6cohsB0mQnMY0qjLMhw": {
getter: function (varBag, idService) {
return varBag.authenticatedVar.value;
}
},
"16rwkKS3tE+ELQvmPPd4Lg": {
getter: function (varBag, idService) {
return varBag.vars.value.attemptVar;
},
dataType: OS.DataTypes.DataTypes.Integer
},
"vLqUrdqjVECwi_tWmZNoOw": {
getter: function (varBag, idService) {
return varBag.vars.value.usernameInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"7nasn762+UiXxfa1NoTfiw": {
getter: function (varBag, idService) {
return varBag.vars.value.isGenericLoginInLocal;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"kdBiZsjdEUO_heKwPwDrQg": {
getter: function (varBag, idService) {
return varBag.vars.value.captchaTokenInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"j3Luvcs4dEGGp0VadEhXiA": {
getter: function (varBag, idService) {
return varBag.outVars.value.successOut;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"zwGCIKb+pEqK7w6aA2CTsg": {
getter: function (varBag, idService) {
return varBag.outVars.value.errorMessageOut;
},
dataType: OS.DataTypes.DataTypes.Text
},
"7iDpmhVyukWRHxuXtC8ncA": {
getter: function (varBag, idService) {
return varBag.signupShopper2Var.value;
}
},
"DktjcWiSfE2z0MHB0jHitw": {
getter: function (varBag, idService) {
return varBag.vars.value.shopperInLocal;
}
},
"XRwnS6+ocUmlkn6dMmWnvA": {
getter: function (varBag, idService) {
return varBag.getCardsVar.value;
}
},
"tFQtzVvmqkGiaV40Vc8s0w": {
getter: function (varBag, idService) {
return varBag.percentageShopperProfileCompletedVar.value;
}
},
"009plCmdlEuJqd1VeSUi0w": {
getter: function (varBag, idService) {
return varBag.vars.value.dateInLocal;
},
dataType: OS.DataTypes.DataTypes.Date
},
"cGS6HvPNPESoM+8fRweASQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.formattedDateOut;
},
dataType: OS.DataTypes.DataTypes.Text
},
"OMX+tZ58r0+yWYKChy3Kkg": {
getter: function (varBag, idService) {
return varBag.vars.value.counterVar;
},
dataType: OS.DataTypes.DataTypes.Decimal
},
"4O3CdVmdFk6sHgA9anSDMA": {
getter: function (varBag, idService) {
return varBag.vars.value.stepVar;
},
dataType: OS.DataTypes.DataTypes.Decimal
},
"7o1WFBbjHkqYmWfmr0vfNw": {
getter: function (varBag, idService) {
return varBag.vars.value.detailsInLocal;
}
},
"J_lDUt3xUEifhQK2sLHmrw": {
getter: function (varBag, idService) {
return varBag.outVars.value.calculatedPercentageOut;
},
dataType: OS.DataTypes.DataTypes.Decimal
},
"oLxLqnOxnUyBrXONQzw5nQ": {
getter: function (varBag, idService) {
return varBag.vars.value.detailsInLocal;
}
},
"ZFKGRAyaX0KR7LTu8aTNRw": {
getter: function (varBag, idService) {
return varBag.vars.value.initialDetailsInLocal;
}
},
"daLSAl4yO0690MECnbhRMw": {
getter: function (varBag, idService) {
return varBag.outVars.value.isSuccessOut;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"vcKcZNAVOECVfMuKE8TK9Q": {
getter: function (varBag, idService) {
return varBag.outVars.value.errorMessageOut;
},
dataType: OS.DataTypes.DataTypes.Text
},
"qy0C9QCrNUmvZnIJmcKk1A": {
getter: function (varBag, idService) {
return varBag.outVars.value.errorCodeOut;
},
dataType: OS.DataTypes.DataTypes.Text
},
"b5lc0BCm_U6uEyiyS8trOg": {
getter: function (varBag, idService) {
return varBag.allExceptionsVar.value;
}
},
"YWy+A6lF5EC_Uu1Hx6WEVg": {
getter: function (varBag, idService) {
return varBag.updateShopperVar.value;
}
},
"VPbQAIma4Uyew8zLN+8DJw": {
getter: function (varBag, idService) {
return varBag.initialDetailsJSONVar.value;
}
},
"3PIrcXg+MUycR2_V7KPOgA": {
getter: function (varBag, idService) {
return varBag.detailsJSONVar.value;
}
},
"0SkZARK+jEafKBvn+PVoNg": {
getter: function (varBag, idService) {
return varBag.setRequestJSResult.value;
}
},
"4GYNLoWY1EuHSpQFeyVasw": {
getter: function (varBag, idService) {
return varBag.vars.value.heapApplicationIdInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"nPIaC9DajE+y0wTro6snLQ": {
getter: function (varBag, idService) {
return varBag.initHeapJSResult.value;
}
},
"A0KSEfF9RkKDvv9FhnDorQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.passportsOut;
}
},
"R8nb0xX6bkOmpWhrM5hRNw": {
getter: function (varBag, idService) {
return varBag.outVars.value.isSuccessOut;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"XOVu63jWzUC6NPvNsk2ZKg": {
getter: function (varBag, idService) {
return varBag.allExceptionsVar.value;
}
},
"o1b2D3GAzkWFb1m4VGiPjQ": {
getter: function (varBag, idService) {
return varBag.formatPassportsVar.value;
}
},
"BoZEdLpDvkqK95TfOmIjEQ": {
getter: function (varBag, idService) {
return varBag.getShopperVar.value;
}
},
"4JtKALZcJE2bZ6vkYBjlKQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.uRLOut;
},
dataType: OS.DataTypes.DataTypes.Text
},
"fnmz54meOkSWgoAvCSPNOw": {
getter: function (varBag, idService) {
return varBag.getCurrentServerURLJSResult.value;
}
},
"mSsHu6QcVUWKEpq4hpKd4g": {
getter: function (varBag, idService) {
return varBag.vars.value.stringInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"h3H_dxX4tUSyOBqo3YqWCw": {
getter: function (varBag, idService) {
return varBag.outVars.value.isValidOut;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"8jul5Jk_iEiBFgQnB7GGgQ": {
getter: function (varBag, idService) {
return varBag.checkOnlyLettersJSResult.value;
}
},
"mRCGyqeS00OJtmyyuaHunA": {
getter: function (varBag, idService) {
return varBag.vars.value.clarityIdInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"DJuMDcqQP0itEfp9DJm5NQ": {
getter: function (varBag, idService) {
return varBag.consentJSResult.value;
}
},
"tKHZmFQN1ka_hK4GZba+3Q": {
getter: function (varBag, idService) {
return varBag.initJSResult.value;
}
},
"nEuam++XaEW_P2NWSMcBgg": {
getter: function (varBag, idService) {
return varBag.vars.value.keyInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"3e7PeW8SBUCYQaY2EfACKg": {
getter: function (varBag, idService) {
return varBag.vars.value.countryCodeInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"+ucKd+j5A0WaCyrl9+ASOA": {
getter: function (varBag, idService) {
return varBag.outVars.value.textOut;
},
dataType: OS.DataTypes.DataTypes.Text
},
"IqxXDZRZXUGZ_8GG9KdbEg": {
getter: function (varBag, idService) {
return varBag.tCMSVar.value;
}
},
"tu6lFZaNmkGneA4oY2qzQQ": {
getter: function (varBag, idService) {
return varBag.vars.value.stringInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"Wj_CUZaBWUW7QFxZ5jAIrg": {
getter: function (varBag, idService) {
return varBag.outVars.value.formattedStringOut;
},
dataType: OS.DataTypes.DataTypes.Text
},
"oA9R6Q8mnE2dNjmdVL_ZAg": {
getter: function (varBag, idService) {
return varBag.titleCaseJSResult.value;
}
},
"9dggszh0bESpavBjIGJdWQ": {
getter: function (varBag, idService) {
return varBag.vars.value.stringInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"J9oed_N2WESr90su0rQEdA": {
getter: function (varBag, idService) {
return varBag.outVars.value.formattedStringOut;
},
dataType: OS.DataTypes.DataTypes.Text
},
"NE2Av0Yx+0Cq0l2eXP8XTg": {
getter: function (varBag, idService) {
return varBag.titleCaseJSResult.value;
}
},
"HBhZrP7ELECo_nfRz6I1GQ": {
getter: function (varBag, idService) {
return varBag.vars.value.nameInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"zhA1lsK9Pku99aRL5zopmw": {
getter: function (varBag, idService) {
return varBag.clarityEventJSResult.value;
}
},
"D97mwdwl0EmFGutgVFrR1A": {
getter: function (varBag, idService) {
return varBag.vars.value.stringInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"2D5YSfQbrE6iA3toaLnDeg": {
getter: function (varBag, idService) {
return varBag.outVars.value.stringFormattedOut;
},
dataType: OS.DataTypes.DataTypes.Text
},
"YWxUa4TNW06oelS9Iz8oJg": {
getter: function (varBag, idService) {
return varBag.replaceJSResult.value;
}
},
"+4HJG92sIk6BN4GAzmV4YA": {
getter: function (varBag, idService) {
return varBag.vars.value.anonymousFormVar;
}
},
"iiVB2g_JeUuZ65MhROYIEQ": {
getter: function (varBag, idService) {
return varBag.vars.value.formNumber_AttemptNrVar;
},
dataType: OS.DataTypes.DataTypes.Text
},
"ZX2qO4zoWkmrZqa1ic94jw": {
getter: function (varBag, idService) {
return varBag.vars.value.formNumber_AttemptNrListVar;
}
},
"VGAp7eW+Y029lifjq+UsRA": {
getter: function (varBag, idService) {
return varBag.vars.value.anonymousFormsStirngInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"pM6ripbZVEi7wwEENKPugQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.anonymousFormsListOut;
}
},
"GIAMXEoe+0ak4tYzFoqrcg": {
getter: function (varBag, idService) {
return varBag.splitStringVar.value;
}
},
"m6d+Coj3UE2ZHw5c_pt5_g": {
getter: function (varBag, idService) {
return varBag.vars.value.layoutAuthenticationInLocal;
}
},
"U83YDJXxSkCjr3LFrE9KtQ": {
getter: function (varBag, idService) {
return varBag.vars.value.domainInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"tjQvcemKJkyLv5ruF68qdg": {
getter: function (varBag, idService) {
return varBag.vars.value.clientIdInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"xEIHVtjzkk+7SYh_1aJQZw": {
getter: function (varBag, idService) {
return varBag.vars.value.redirectURLInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"QPmXuMBN00mMwSrPQQwPJA": {
getter: function (varBag, idService) {
return varBag.outVars.value.isAuthenticatedOut;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"BgADpoVmMUWYBBDt+NmKYA": {
getter: function (varBag, idService) {
return varBag.initWebAuthVar.value;
}
},
"yfic+BrPJ0GtnDrH3I5z3A": {
getter: function (varBag, idService) {
return varBag.checkAuthenticationVar.value;
}
},
"ik9hy5whgk20FHNMD9pddA": {
getter: function (varBag, idService) {
return varBag.vars.value.formsListInLocal;
}
},
"TN7EgjyvzUitOKRFbi5RZA": {
getter: function (varBag, idService) {
return varBag.outVars.value.formsList_OutputOut;
}
},
"Hzj96OkyzUe7L64rLmeQfg": {
getter: function (varBag, idService) {
return varBag.listFilter_DateVar.value;
}
},
"s25nI6jzEEONajYhmc0NjQ": {
getter: function (varBag, idService) {
return varBag.vars.value.shopperInLocal;
}
},
"UTG4dqOTNkGd7nkUdll1Iw": {
getter: function (varBag, idService) {
return varBag.outVars.value.filledOut;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"yE9AJ0Qc702iTgSjiD8bpg": {
getter: function (varBag, idService) {
return varBag.getApplicationReadyDataVar.value;
}
},
"WeWNGcP_cEmZJEvUQYLshA": {
getter: function (varBag, idService) {
return ShopperPortalEUClientVariables.getShopperGuid();
},
dataType: OS.DataTypes.DataTypes.Text
},
"NrptGog_HkCeF0Bqgm8lXQ": {
getter: function (varBag, idService) {
return ShopperPortalEUClientVariables.getFormNumberVA2();
},
dataType: OS.DataTypes.DataTypes.Text
},
"lV5QJm9v90OePoSHG_SL0w": {
getter: function (varBag, idService) {
return ShopperPortalEUClientVariables.getShopperChecked();
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"TfyNJk3ODUuehyo4GA+Mjg": {
getter: function (varBag, idService) {
return ShopperPortalEUClientVariables.getIsFormRequestRefundTriggered();
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"hhi6LdntvUybd8n+gZkmAg": {
getter: function (varBag, idService) {
return ShopperPortalEUClientVariables.getAnonymousFormList();
},
dataType: OS.DataTypes.DataTypes.Text
},
"Qk11L0cntE65Nhp5PAcxTQ": {
getter: function (varBag, idService) {
return ShopperPortalEUClientVariables.getEmail();
},
dataType: OS.DataTypes.DataTypes.Text
},
"G2RpNGDYF0C8dlTdcCFxHQ": {
getter: function (varBag, idService) {
return ShopperPortalEUClientVariables.getResendCodeSeconds();
},
dataType: OS.DataTypes.DataTypes.Integer
},
"6xaFO3Oo9kW3O7bRjKocgQ": {
getter: function (varBag, idService) {
return ShopperPortalEUClientVariables.getRefundSummaryFormListJSON();
},
dataType: OS.DataTypes.DataTypes.Text
},
"ksv_S76MpUeNNYsMF9rpFg": {
getter: function (varBag, idService) {
return ShopperPortalEUClientVariables.getFromCarouselAddCard();
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"tHoDTZJiGkGCFyWM+2xfPw": {
getter: function (varBag, idService) {
return ShopperPortalEUClientVariables.getShopperCards();
},
dataType: OS.DataTypes.DataTypes.Integer
},
"VcrMXu5S8kCFv3i9BPSklA": {
getter: function (varBag, idService) {
return ShopperPortalEUClientVariables.getShopperName();
},
dataType: OS.DataTypes.DataTypes.Text
},
"C7HGa1MVckS18RUaAi_s6A": {
getter: function (varBag, idService) {
return ShopperPortalEUClientVariables.getErrorMessage();
},
dataType: OS.DataTypes.DataTypes.Text
},
"n_RJb5Od4U2dA5xavwNzAQ": {
getter: function (varBag, idService) {
return ShopperPortalEUClientVariables.getFormInfoListJSON();
},
dataType: OS.DataTypes.DataTypes.Text
},
"hzVdfet3XUOuDl8iwHWZxg": {
getter: function (varBag, idService) {
return ShopperPortalEUClientVariables.getIsInMaintenance();
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"U0ohf3fSHUyImFcPyjqQKA": {
getter: function (varBag, idService) {
return ShopperPortalEUClientVariables.getShopperPassports();
},
dataType: OS.DataTypes.DataTypes.Integer
},
"RBFVhHQIEkyFQFZMiRQIkA": {
getter: function (varBag, idService) {
return ShopperPortalEUClientVariables.getScanPassportRedirect();
},
dataType: OS.DataTypes.DataTypes.Integer
},
"ZCibjagXvECr400wDw7qyA": {
getter: function (varBag, idService) {
return ShopperPortalEUClientVariables.getShopperProfileCompleted();
},
dataType: OS.DataTypes.DataTypes.Decimal
},
"tDCYlOxi1k6g5vi1YH__ig": {
getter: function (varBag, idService) {
return ShopperPortalEUClientVariables.getFormNumberRA1();
},
dataType: OS.DataTypes.DataTypes.Text
},
"f3o_mcoieUySaA5BxIzkOw": {
getter: function (varBag, idService) {
return ShopperPortalEUClientVariables.getLoginType();
},
dataType: OS.DataTypes.DataTypes.Integer
},
"85sDnDPfZEWBgWLzTJjVhw": {
getter: function (varBag, idService) {
return ShopperPortalEUClientVariables.getFormNumberVA1();
},
dataType: OS.DataTypes.DataTypes.Text
},
"l+VCoS+KZkKE6pdmpRfsCA": {
getter: function (varBag, idService) {
return ShopperPortalEUClientVariables.getIsFromFormDetailsOrStepScreen();
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"y4SOxNQdVEmVKWBeomX6Xw": {
getter: function (varBag, idService) {
return ShopperPortalEUClientVariables.getIsProfileDetailsNavigation();
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"7hbp1Ko_ckaKQpK3QaKZZQ": {
getter: function (varBag, idService) {
return ShopperPortalEUClientVariables.getShopperPassportDataTemp();
},
dataType: OS.DataTypes.DataTypes.Text
},
"L_RV8zMIhUiGVDQTum3PlQ": {
getter: function (varBag, idService) {
return ShopperPortalEUClientVariables.getShopperContact();
},
dataType: OS.DataTypes.DataTypes.Text
},
"G49v9YpNDUmSL4OHWyj01g": {
getter: function (varBag, idService) {
return ShopperPortalEUClientVariables.getLoginURL();
},
dataType: OS.DataTypes.DataTypes.Text
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
