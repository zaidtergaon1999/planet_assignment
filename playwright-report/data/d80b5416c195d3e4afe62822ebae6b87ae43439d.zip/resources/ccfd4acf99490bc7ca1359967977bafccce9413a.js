class customMessage {
  constructor() {
    this.class = 'custom-message';
    this.element = document.createElement('div');
    this.classes = {
      types: {
        success: this.class.concat('--success'),
        info: this.class.concat('--info'),
        warning: this.class.concat('--warning'),
        error: this.class.concat('--error'),
        neutral: this.class.concat('--neutral')
      },
      states: {
        customIcon: this.class.concat('--custom-icon')
      }
    };
    this.elements = {
      icon: document.createElement('div'),
      main: {
        element: document.createElement('div'),
        elements: {
          title: document.createElement('div'),
          content: document.createElement('div')
        }
      },
      close: document.createElement('div')
    };
    this.timeout = {
      id: null,
      time: 5000
    };
    this.listeners = {
      hide: this.hide.bind(this),
      _touchStart: this._touchStart.bind(this),
      _touchEnd: this._touchEnd.bind(this)
    };
    this.touch = {
      startX: 0,
      startY: 0,
      endX: 0,
      endY: 0
    };
    this._build();
    this.options = null;
  }
  _touchStart(e) {
    /*Prevents page scroll upon swipe up*/
    if (!this.elements.close.contains(e.target) && e.target.tagName.toLowerCase() !== 'a') {
      e.preventDefault();
    }
    this.touch.startX = e.changedTouches[0].screenX;
    this.touch.startY = e.changedTouches[0].screenY;
  }
  _touchEnd(e) {
    this.touch.endX = e.changedTouches[0].screenX;
    this.touch.endY = e.changedTouches[0].screenY;
    /*Swipe Up*/
    if (this.touch.endY < this.touch.startY) {
      this.hide();
    }
  }
  _create() {
    this.element.classList.add(this.class);
    this.elements.icon.classList.add(this.class.concat('__icon'));
    this.elements.main.element.classList.add(this.class.concat('__main'));
    this.elements.main.elements.title.classList.add(this.class.concat('__title'), 'ph');
    this.elements.main.elements.content.classList.add(this.class.concat('__content'), 'ph');
    this.elements.close.classList.add(this.class.concat('__close'));
    this.element.append(this.elements.icon);
    this.elements.main.element.append(this.elements.main.elements.title);
    this.elements.main.element.append(this.elements.main.elements.content);
    this.element.append(this.elements.main.element);
    let closeIconWrapper = document.createElement('div'),
      closeIcon = document.createElement('span');
    closeIconWrapper.classList.add('custom-icon', 'custom-icon--material');
    closeIcon.classList.add('material-symbols-outlined');
    closeIcon.innerHTML = 'close';
    closeIconWrapper.append(closeIcon);
    this.elements.close.append(closeIconWrapper);
    this.element.append(this.elements.close);
    document.body.prepend(this.element);
  }
  _build() {
    if (window.customMessage === undefined) {
      this._create();
      window.customMessage = this;
      if (window.customMessageWait !== undefined) {
        this.trigger(window.customMessageWait);
        delete window.customMessageWait
      }
    }
  }
  hide() {
    this.element.classList.remove(this.class.concat('--show'));
    this.elements.close.removeEventListener('click', this.listeners.hide);
    this.element.removeEventListener('touchstart', this.listeners._touchStart);
    this.element.removeEventListener('touchend', this.listeners._touchEnd);
    if (this.options.closeClarityEvent) {
      if (window.clarity) {
        window.clarity('event', this.options.closeClarityEvent);
      }
    }
    clearTimeout(this.timeout.id);
  }
  trigger(options) {
    clearTimeout(this.timeout.id);
    this.element.classList.remove(...Object.values(this.classes.types));
    this.element.classList.remove(this.classes.states.customIcon);
    this.elements.icon.innerHTML = '';
    this.element.classList.add(this.classes.types[options.type]);
    if (options.icon.name) {
      this.element.classList.add(this.classes.states.customIcon);
      let i = document.createElement('span');
      if (options.icon.family === 'material') {
        i.classList.add('material-symbols-outlined');
        i.innerHTML = options.icon.name;
        if (options.icon.filled) {
          i.classList.add('custom-icon--filled');
        }
      } else {
        i.classList.add('planet-icon');
        if (options.icon.filled) {
          i.classList.add('planet-icon--'.concat(options.icon.name.concat('-filled')));
        } else {
          i.classList.add('planet-icon--'.concat(options.icon.name));
        }
      }
      this.elements.icon.append(i);
    }
    options.title = options.title.replace(/(?:\r\n|\r|\n)/g, '<br>');
    options.content = options.content.replace(/(?:\r\n|\r|\n)/g, '<br>');
    this.elements.main.elements.title.innerHTML = options.title || null;
    this.elements.main.elements.content.innerHTML = options.content || null;
    if (options.testId) {
      this.elements.main.elements.title.setAttribute('data-testid', options.testId.concat('Title'));
      this.elements.main.elements.content.setAttribute('data-testid', options.testId.concat('Content'));
    } else {
      this.elements.main.elements.title.removeAttribute('data-testid');
      this.elements.main.elements.content.removeAttribute('data-testid');
    }
    this.element.classList.add(this.class.concat('--show'));
    if (options.autoHide && options.type !== 'error') {
      this.timeout.id = setTimeout(this.listeners.hide, this.timeout.time);
    }
    this.elements.close.addEventListener('click', this.listeners.hide);
    this.element.addEventListener('touchstart', this.listeners._touchStart, false);
    this.element.addEventListener('touchend', this.listeners._touchEnd, false);
    this.options = options;
  }
}