define("ShopperPortalEU.Profile.Passports.mvc$model", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Theme.controller", "ShopperPortalEU.Layouts.LayoutDetail.mvc$model", "ShopperPortalEU.LayoutsComponents.Back.mvc$model", "ShopperPortalEU.Common.DataLoading.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomColumns.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCard.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.Flex.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomFlag.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomSeparator.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomIcon.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomBottomBar.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomButton.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomButtonItem.mvc$model", "ShopperPortalEU.controller$FormatEmptyString", "ShopperPortalEU.controller$FormatDate", "ShopperPortalEU.model$PassportList", "ShopperPortalEU_UI_Theme.model$LayoutDetailOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU_UI_Components.model$CustomColumnsOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$CustomCardOptionsRec", "ShopperPortalEU_UI_Components.model$FlexOptionsRec", "ShopperPortalEU_UI_Components.model$CustomFlagOptionsRec", "ShopperPortalEU_UI_Components.model$CustomSeparatorOptionsRec", "ShopperPortalEU_UI_Components.model$CustomSeparatorLabelOptionsRec", "ShopperPortalEU_UI_Components.model$CustomIconOptionsRec", "ShopperPortalEU_UI_Components.model$CustomBottomBarOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconRec", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", "ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger", "ShopperPortalEU.controller$GetPassports", "ShopperPortalEU.controller$DefaultErrorMessage"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ThemeController, ShopperPortalEU_Layouts_LayoutDetail_mvcModel, ShopperPortalEU_LayoutsComponents_Back_mvcModel, ShopperPortalEU_Common_DataLoading_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomColumns_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCard_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomFlag_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomSeparator_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomIcon_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomBottomBar_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvcModel) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("IsDataFetched", "isDataFetchedVar", "IsDataFetched", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("HasFetchError", "hasFetchErrorVar", "HasFetchError", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("Passports", "passportsVar", "Passports", true, false, OS.DataTypes.DataTypes.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEUModel.PassportList());
}, false, ShopperPortalEUModel.PassportList)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Model._hasValidationWidgetsValue = undefined;
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
if((Model._hasValidationWidgetsValue === undefined)) {
Model._hasValidationWidgetsValue = (((((((((((ShopperPortalEU_Layouts_LayoutDetail_mvcModel.hasValidationWidgets || ShopperPortalEU_LayoutsComponents_Back_mvcModel.hasValidationWidgets) || ShopperPortalEU_Common_DataLoading_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomColumns_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCard_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomFlag_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomSeparator_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomIcon_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomBottomBar_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvcModel.hasValidationWidgets);
}

return Model._hasValidationWidgetsValue;
}
});

Model.prototype.setInputs = function (inputs) {
};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "Profile.Passports");
});
define("ShopperPortalEU.Profile.Passports.mvc$view", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Theme.controller", "react", "OutSystems/ReactView/Main", "ShopperPortalEU.Profile.Passports.mvc$model", "ShopperPortalEU.Profile.Passports.mvc$controller", "ShopperPortalEU.clientVariables", "ShopperPortalEU.Layouts.LayoutDetail.mvc$view", "OutSystems/ReactWidgets/Main", "ShopperPortalEU.LayoutsComponents.Back.mvc$view", "ShopperPortalEU.Common.DataLoading.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomColumns.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCard.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.Flex.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomFlag.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomSeparator.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomIcon.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomBottomBar.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomButton.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomButtonItem.mvc$view", "ShopperPortalEU.controller$FormatEmptyString", "ShopperPortalEU.controller$FormatDate", "ShopperPortalEU.model$PassportList", "ShopperPortalEU_UI_Theme.model$LayoutDetailOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU_UI_Components.model$CustomColumnsOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$CustomCardOptionsRec", "ShopperPortalEU_UI_Components.model$FlexOptionsRec", "ShopperPortalEU_UI_Components.model$CustomFlagOptionsRec", "ShopperPortalEU_UI_Components.model$CustomSeparatorOptionsRec", "ShopperPortalEU_UI_Components.model$CustomSeparatorLabelOptionsRec", "ShopperPortalEU_UI_Components.model$CustomIconOptionsRec", "ShopperPortalEU_UI_Components.model$CustomBottomBarOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconRec", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", "ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger", "ShopperPortalEU.controller$GetPassports", "ShopperPortalEU.controller$DefaultErrorMessage"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ThemeController, React, OSView, ShopperPortalEU_Profile_Passports_mvc_model, ShopperPortalEU_Profile_Passports_mvc_controller, ShopperPortalEUClientVariables, ShopperPortalEU_Layouts_LayoutDetail_mvc_view, OSWidgets, ShopperPortalEU_LayoutsComponents_Back_mvc_view, ShopperPortalEU_Common_DataLoading_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomColumns_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCard_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomFlag_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomSeparator_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomIcon_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomBottomBar_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            var thisIsInstanceOfSuper = this instanceof _super;
            if (thisIsInstanceOfSuper == false) {
                return;
            }

            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "Profile.Passports";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css", "css/ShopperPortalEU_UI_Theme.ShopperPortalEUUITheme.css", "css/ShopperPortalEU.ShopperPortalEU.css", "css/ShopperPortalEU_UI_Theme.ShopperPortalEUUITheme.extra.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [ShopperPortalEU_Layouts_LayoutDetail_mvc_view, ShopperPortalEU_LayoutsComponents_Back_mvc_view, ShopperPortalEU_Common_DataLoading_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomColumns_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCard_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomFlag_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomSeparator_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomIcon_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomBottomBar_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return ShopperPortalEU_Profile_Passports_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return ShopperPortalEU_Profile_Passports_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "Shopper Portal EU - Passports";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(ShopperPortalEU_Layouts_LayoutDetail_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
afterAuthentication$Action: function (isAuthenticatedIn) {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Layouts/LayoutDetail AfterAuthentication");
return controller.getData$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "0",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
headerLeft: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_LayoutsComponents_Back_mvc_view, {
inputs: {
ManualRedirect: true
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onClick$Action: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "LayoutsComponents/Back OnClick");
controller.backOnClick$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "1",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}),
headerCenter: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "PassportTitle"
},
value: "Passport",
_idProps: {
service: idService,
uuid: "2"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
headerRight: PlaceholderContent.Empty,
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_Common_DataLoading_mvc_view, {
inputs: {
IsDataFetched: model.variables.isDataFetchedVar,
HasError: model.variables.hasFetchErrorVar
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "3",
alias: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomColumns_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("TBk_ZNSUXEStLYd56PmAew.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomColumnsOptionsRec();
rec.columnsAttr = 1;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space5;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "4",
alias: "4"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.List, {
animateItems: false,
extendedProperties: {
"disable-virtualization": "True",
"TotalPassports": (model.variables.passportsVar.length).toString()
},
gridProperties: {
classes: "OSFillParent"
},
mode: /*Default*/ 0,
source: model.variables.passportsVar,
style: "list list-group",
tag: "div",
_idProps: {
service: idService,
uuid: "5"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new IteratorPlaceholderContent(function (idService, callContext) {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCard_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("3wo124n9RkW306TcsXMv8w.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomCardOptionsRec();
rec.stateAttr = (((model.variables.passportsVar.getCurrent(callContext.iterationContext).expirationDateAttr.equals(OS.BuiltinFunctions.nullDate()) || model.variables.passportsVar.getCurrent(callContext.iterationContext).expirationDateAttr.gte(OS.BuiltinFunctions.currDate()))) ? (OS.BuiltinFunctions.nullTextIdentifier()) : (ShopperPortalEUModel.staticEntities.customCardState.inactive));
return rec;
}();
}, function () {
return model.variables.passportsVar.getCurrent(callContext.iterationContext).expirationDateAttr;
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "6",
alias: "5"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("6Su_j7BfBUG7l+FykCUS+w.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.alignAttr = ShopperPortalEUModel.staticEntities.flexAlign.center;
rec.justifyAttr = ShopperPortalEUModel.staticEntities.flexJustify.spaceBetween;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "7",
alias: "6"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("I3rh9FHIHE2zqSy4IJG84Q.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.alignAttr = ShopperPortalEUModel.staticEntities.flexAlign.center;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
rec.wrapAttr = false;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "8",
alias: "7"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": ("PassportNumber_" + (model.variables.passportsVar.getCurrentRowNumber(callContext.iterationContext)).toString())
},
style: model.getCachedValue(idService.getId("hyS+gJPiEEKOdfgWKCwteQ.Style"), function () {
return ("heading6" + (((model.variables.passportsVar.getCurrent(callContext.iterationContext).expirationDateAttr.equals(OS.BuiltinFunctions.nullDate()) || model.variables.passportsVar.getCurrent(callContext.iterationContext).expirationDateAttr.gte(OS.BuiltinFunctions.currDate()))) ? (" text-primary-black") : (" text-primary-45")));
}, function () {
return model.variables.passportsVar.getCurrent(callContext.iterationContext).expirationDateAttr;
}),
value: model.variables.passportsVar.getCurrent(callContext.iterationContext).numberAttr,
_idProps: {
service: idService,
uuid: "9"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomFlag_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("zbwxPpjGLkmQCl6DSHidUQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomFlagOptionsRec();
rec.testIdAttr = ("CountryFlag_" + model.variables.passportsVar.getCurrent(callContext.iterationContext).countryISOCodeAttr);
rec.flagAttr = model.variables.passportsVar.getCurrent(callContext.iterationContext).countryISOCodeAttr;
rec.isDisabledAttr = (!(model.variables.passportsVar.getCurrent(callContext.iterationContext).expirationDateAttr.equals(OS.BuiltinFunctions.nullDate())) && model.variables.passportsVar.getCurrent(callContext.iterationContext).expirationDateAttr.lt(OS.BuiltinFunctions.currDate()));
return rec;
}();
}, function () {
return model.variables.passportsVar.getCurrent(callContext.iterationContext).countryISOCodeAttr;
}, function () {
return model.variables.passportsVar.getCurrent(callContext.iterationContext).expirationDateAttr;
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "10",
alias: "8"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.passportsVar.getCurrentRowNumber(callContext.iterationContext)), asPrimitiveValue(model.variables.passportsVar.getCurrent(callContext.iterationContext).countryISOCodeAttr), asPrimitiveValue(model.variables.passportsVar.getCurrent(callContext.iterationContext).expirationDateAttr), asPrimitiveValue(model.variables.passportsVar.getCurrent(callContext.iterationContext).numberAttr)]
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.passportsVar.getCurrentRowNumber(callContext.iterationContext)), asPrimitiveValue(model.variables.passportsVar.getCurrent(callContext.iterationContext).countryISOCodeAttr), asPrimitiveValue(model.variables.passportsVar.getCurrent(callContext.iterationContext).expirationDateAttr), asPrimitiveValue(model.variables.passportsVar.getCurrent(callContext.iterationContext).numberAttr)]
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomSeparator_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("mAiv2uQXB0uHtUlQggwzXQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomSeparatorOptionsRec();
rec.marginTopAttr = ShopperPortalEUModel.staticEntities.spacing.space3;
rec.marginBottomAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "11",
alias: "9"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "body-3",
visible: true,
_idProps: {
service: idService,
uuid: "12"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("4Y0PCGiRd02PF2mBMtWCnA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.justifyAttr = ShopperPortalEUModel.staticEntities.flexJustify.spaceBetween;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
rec.wrapAttr = false;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "13",
alias: "10"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "14"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "CountryLabel"
},
value: "Country",
_idProps: {
service: idService,
uuid: "15"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "16"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": ("CountryValue_" + (model.variables.passportsVar.getCurrentRowNumber(callContext.iterationContext)).toString())
},
style: "text-primary-black",
value: model.getCachedValue(idService.getId("0zu26lCr1Eahb8cxJH3eGA.Value"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.formatEmptyString$Action(model.variables.passportsVar.getCurrent(callContext.iterationContext).countryAttr, callContext).formattedStringOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
}, function () {
return model.variables.passportsVar.getCurrent(callContext.iterationContext).countryAttr;
}),
_idProps: {
service: idService,
uuid: "17"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables.passportsVar.getCurrentRowNumber(callContext.iterationContext)), asPrimitiveValue(model.variables.passportsVar.getCurrent(callContext.iterationContext).countryAttr)]
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
ExtendedClass: "margin-top-04",
Options: model.getCachedValue(idService.getId("BEm+hjq8b0qHlLpAVToXKg.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.justifyAttr = ShopperPortalEUModel.staticEntities.flexJustify.spaceBetween;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
rec.wrapAttr = false;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "18",
alias: "11"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "19"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "DateOfExpiryLabel"
},
value: "Date of expiry",
_idProps: {
service: idService,
uuid: "20"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "21"
},
_widgetRecordProvider: widgetsRecordProvider
}, $if((model.variables.passportsVar.getCurrent(callContext.iterationContext).expirationDateAttr.equals(OS.BuiltinFunctions.nullDate()) || model.variables.passportsVar.getCurrent(callContext.iterationContext).expirationDateAttr.gte(OS.BuiltinFunctions.currDate())), false, this, function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": ("DateOfExpiryValue_" + (model.variables.passportsVar.getCurrentRowNumber(callContext.iterationContext)).toString())
},
style: "text-primary-black",
value: model.getCachedValue(idService.getId("8ZWEPJqq_EiAysS6fwBdlg.Value"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.formatDate$Action(model.variables.passportsVar.getCurrent(callContext.iterationContext).expirationDateAttr, callContext).formattedDateOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
}, function () {
return model.variables.passportsVar.getCurrent(callContext.iterationContext).expirationDateAttr;
}),
_idProps: {
service: idService,
uuid: "22"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("HFZOFKpuUUWkYy3AsIwzvg.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.alignAttr = ShopperPortalEUModel.staticEntities.flexAlign.center;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space1;
rec.wrapAttr = false;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "23",
alias: "12"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomIcon_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("KZcYSaUy2k+aLCpLo+casQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomIconOptionsRec();
rec.testIdAttr = "ExpiredDateIcon";
rec.nameAttr = "error";
rec.sizeAttr = ShopperPortalEUModel.staticEntities.customIconSize.extraSmall;
rec.colorAttr = "var(--color-error-10)";
rec.isFilledAttr = true;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "24",
alias: "13"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}), React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": ("ExpiredDateLabel_" + (model.variables.passportsVar.getCurrentRowNumber(callContext.iterationContext)).toString())
},
style: "text-error-10",
value: model.getCachedValue(idService.getId("fB1khogKMEua+2YSYxXGqw.Value"), function () {
return ("Expired on " + OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.formatDate$Action(model.variables.passportsVar.getCurrent(callContext.iterationContext).expirationDateAttr, callContext).formattedDateOut;
}, OS.DataTypes.DataTypes.Text, callContext.id));
}, function () {
return model.variables.passportsVar.getCurrent(callContext.iterationContext).expirationDateAttr;
}),
_idProps: {
service: idService,
uuid: "25"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.passportsVar.getCurrentRowNumber(callContext.iterationContext)), asPrimitiveValue(model.variables.passportsVar.getCurrent(callContext.iterationContext).expirationDateAttr)]
})];
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables.passportsVar.getCurrentRowNumber(callContext.iterationContext)), asPrimitiveValue(model.variables.passportsVar.getCurrent(callContext.iterationContext).expirationDateAttr)]
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables.passportsVar.getCurrentRowNumber(callContext.iterationContext)), asPrimitiveValue(model.variables.passportsVar.getCurrent(callContext.iterationContext).countryAttr), asPrimitiveValue(model.variables.passportsVar.getCurrent(callContext.iterationContext).countryISOCodeAttr), asPrimitiveValue(model.variables.passportsVar.getCurrent(callContext.iterationContext).expirationDateAttr), asPrimitiveValue(model.variables.passportsVar.getCurrent(callContext.iterationContext).numberAttr)]
})];
}, callContext, idService, "1")
},
_dependencies: []
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.passportsVar)]
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomBottomBar_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "26",
alias: "14"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [$if((ShopperPortalEUClientVariables.getShopperPassports() > 3), false, this, function () {
return [];
}, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("1ewfPf2oBkSVbQJGnHC6sA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRec();
rec.testIdAttr = "AddPassportButton";
rec.typeAttr = ShopperPortalEUModel.staticEntities.customButtonType.primary;
rec.isFullWidthAttr = true;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "27",
alias: "15"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
button: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: false,
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Profile/Passports/Button OnClick");
controller.add$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn",
visible: true,
_idProps: {
service: idService,
uuid: "28"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "29",
alias: "16"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Add passport",
_idProps: {
service: idService,
uuid: "30"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
})];
})];
})
},
_dependencies: [asPrimitiveValue(ShopperPortalEUClientVariables.getShopperPassports())]
})];
})
},
_dependencies: [asPrimitiveValue(ShopperPortalEUClientVariables.getShopperPassports()), asPrimitiveValue(model.variables.passportsVar)]
})];
}),
bottom: PlaceholderContent.Empty
},
_dependencies: [asPrimitiveValue(ShopperPortalEUClientVariables.getShopperPassports()), asPrimitiveValue(model.variables.passportsVar), asPrimitiveValue(model.variables.hasFetchErrorVar), asPrimitiveValue(model.variables.isDataFetchedVar)]
}));
        };
        return View;
    })(OSView.BaseView.BaseWebScreen);
	
    return View;
});
define("ShopperPortalEU.Profile.Passports.mvc$controller", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Theme.controller", "ShopperPortalEU.languageResources", "ShopperPortalEU.clientVariables", "ShopperPortalEU.Profile.Passports.mvc$debugger", "ShopperPortalEU.Profile.controller", "ShopperPortalEU.controller$FormatEmptyString", "ShopperPortalEU.controller$FormatDate", "ShopperPortalEU.model$PassportList", "ShopperPortalEU_UI_Theme.model$LayoutDetailOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU_UI_Components.model$CustomColumnsOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$CustomCardOptionsRec", "ShopperPortalEU_UI_Components.model$FlexOptionsRec", "ShopperPortalEU_UI_Components.model$CustomFlagOptionsRec", "ShopperPortalEU_UI_Components.model$CustomSeparatorOptionsRec", "ShopperPortalEU_UI_Components.model$CustomSeparatorLabelOptionsRec", "ShopperPortalEU_UI_Components.model$CustomIconOptionsRec", "ShopperPortalEU_UI_Components.model$CustomBottomBarOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconRec", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", "ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger", "ShopperPortalEU.controller$GetPassports", "ShopperPortalEU.controller$DefaultErrorMessage"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ThemeController, ShopperPortalEULanguageResources, ShopperPortalEUClientVariables, ShopperPortalEU_Profile_Passports_mvc_Debugger, ShopperPortalEU_ProfileController) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = true;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._onInitialize$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnInitialize");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:2_z1BCKPtEqT74wBSykKbA:/NRWebFlows.G6g8LlI0+UqpwXA+JmvtFg/NodesShownInESpaceTree.5Qwk_Cux1EqD9x74kdEnqA/ClientActions.2_z1BCKPtEqT74wBSykKbA:jVpAPtqnlOjqfTLUpQY4Gw", "ShopperPortalEU", "OnInitialize", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:mYhma6w75k6rI_n4XVS5OQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:2aEjXoZDmE6ULVoiglSZHg", callContext.id);
// IsDataFetched = False
model.variables.isDataFetchedVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:2aEjXoZDmE6ULVoiglSZHg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// HasFetchError = False
model.variables.hasFetchErrorVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:2aEjXoZDmE6ULVoiglSZHg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// ScanPassportRedirect = 1
ShopperPortalEUClientVariables.setScanPassportRedirect(1);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:vMZ3gLGv1keI0y46EVufSA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:2_z1BCKPtEqT74wBSykKbA", callContext.id);
}

};
Controller.prototype._add$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Add");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:1cBdWBSko0mJX9SBoXVRbA:/NRWebFlows.G6g8LlI0+UqpwXA+JmvtFg/NodesShownInESpaceTree.5Qwk_Cux1EqD9x74kdEnqA/ClientActions.1cBdWBSko0mJX9SBoXVRbA:3B52f37RkiCpmbReLGKjIw", "ShopperPortalEU", "Add", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Z783juIF2EuRLZAZZ2VHLw", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:4RlYmqIiiU+XpDHHm3YnRw", callContext.id);
// Destination: /ShopperPortalEU/ScanPassport
return OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "ScanPassport", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:1cBdWBSko0mJX9SBoXVRbA", callContext.id);
}

};
Controller.prototype._onDestroy$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnDestroy");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:K5kDaxCJmk+suiUsjeQ4cw:/NRWebFlows.G6g8LlI0+UqpwXA+JmvtFg/NodesShownInESpaceTree.5Qwk_Cux1EqD9x74kdEnqA/ClientActions.K5kDaxCJmk+suiUsjeQ4cw:Yi_IdHKVXdXnI0nSNeRfaQ", "ShopperPortalEU", "OnDestroy", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:XqBSnGo5tUaVwzWBF+xgfA", callContext.id);
// Clean scan passport data
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:SirSkpgq4kuM5mniy0PDYg", callContext.id);
// ShopperPassportDataTemp = ""
ShopperPortalEUClientVariables.setShopperPassportDataTemp("");
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:56wzxBMjMkG+TeDfWkI3XQ", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:K5kDaxCJmk+suiUsjeQ4cw", callContext.id);
}

};
Controller.prototype._backOnClick$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("BackOnClick");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:Wmxgd6iSGEOCjyx2hL96OA:/NRWebFlows.G6g8LlI0+UqpwXA+JmvtFg/NodesShownInESpaceTree.5Qwk_Cux1EqD9x74kdEnqA/ClientActions.Wmxgd6iSGEOCjyx2hL96OA:CZwBt+tf+w8NE15hSLunmw", "ShopperPortalEU", "BackOnClick", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:prCyzRf6zEWdw0TPSbZxnw", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:KIoXIpuq70+nSG_qzdTu6g", callContext.id);
// Destination: /ShopperPortalEU/MyProfile
return OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "MyProfile", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:Wmxgd6iSGEOCjyx2hL96OA", callContext.id);
}

};
Controller.prototype._fetchPassports$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("FetchPassports");
callContext = controller.callContext(callContext);
var allExceptionsVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.ErrorHandlerOutputType());
var getPassportsVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.allExceptionsVar = allExceptionsVar;
varBag.getPassportsVar = getPassportsVar;
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:4d1KtK8QS0SR24LaJn2udA:/NRWebFlows.G6g8LlI0+UqpwXA+JmvtFg/NodesShownInESpaceTree.5Qwk_Cux1EqD9x74kdEnqA/ClientActions.4d1KtK8QS0SR24LaJn2udA:RM7qb3M4CWOUuo_cNN4CAg", "ShopperPortalEU", "FetchPassports", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:+qX1sHi480KuWFAeUt3XOQ", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:bjPNa5ilNkyNZGzQFfVNZg", callContext.id);
// IsDataFetched = False
model.variables.isDataFetchedVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:eMhcrbxAf0O94jHxRRbnsQ", callContext.id);
// Execute Action: GetPassports
model.flush();
return ShopperPortalEUController.default.getPassports$Action(callContext).then(function (value) {
getPassportsVar.value = value;
}).then(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:L_lfTh2S+ECRbcrW9JgWyg", callContext.id);
// Execute Action: ListSort
OS.SystemActions.listSort(getPassportsVar.value.passportsOut, function (p) {
return p.expirationDateAttr;
}, false, callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:1RGBLYvV1UyBPHtqKBBx5A", callContext.id);
// IsDataFetched = True
model.variables.isDataFetchedVar = true;
}).then(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:WsjNW4xfIkmSrwZz8D7jVw", callContext.id) && getPassportsVar.value.isSuccessOut)) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:RPdVjjNRk06vEvN2IgaJMA", callContext.id);
// HasFetchError = False
model.variables.hasFetchErrorVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:em+jXvXn5kqof24NgCUNfw", callContext.id);
// Passports = GetPassports.Passports
model.variables.passportsVar = getPassportsVar.value.passportsOut;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:X6n7m3Cwx0qHzL1X_4LXVQ", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:r60Zu5GX902GQY7iXYA9kA", callContext.id);
// HasFetchError = True
model.variables.hasFetchErrorVar = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:PR3lIXhVSUa3IxgeuiEG_Q", callContext.id);
// Execute Action: ErrorMessage
ShopperPortalEU_UI_ThemeController.default.customMessageTrigger$Action(function () {
var rec = new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customMessageType.error;
rec.titleAttr = "We couldn\'t load the passports";
rec.contentAttr = OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.defaultErrorMessage$Action(callContext).errorMessageOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
rec.testIdAttr = "GetPassportsError";
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:DJp3kHqOvkekPKWOZ4p3gg", callContext.id);
}

});
}).catch(function (ex) {
OS.Logger.trace("Passports.FetchPassports", OS.Exceptions.getMessage(ex), ex.name);
// Handle Error: AllExceptions
if(!(OS.Exceptions.isSystem(ex))) {
OS.Logger.error(null, ex);
allExceptionsVar.value.exceptionMessageAttr = OS.Exceptions.getMessage(ex);
OutSystemsDebugger.handleException(allExceptionsVar.value.exceptionMessageAttr, callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:zbnkWuwO00CPDCih5NMz0g", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:AxANBfFvDUyX8uejxoB0vA", callContext.id);
// HasFetchError = True
model.variables.hasFetchErrorVar = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:arHlrEIMBkuaMYagFpbrmw", callContext.id);
// Execute Action: GenericErrorMessage
ShopperPortalEU_UI_ThemeController.default.customMessageTrigger$Action(function () {
var rec = new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customMessageType.error;
rec.titleAttr = "We couldn\'t load the passports";
rec.contentAttr = OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.defaultErrorMessage$Action(callContext).errorMessageOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
rec.testIdAttr = "GetPassportsGenericError";
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:_LRFDryfuUmqK3IdWoA8Ng", callContext.id);
return OS.Flow.returnAsync();

});
}

throw ex;
}).then(function (res) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:4d1KtK8QS0SR24LaJn2udA", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:4d1KtK8QS0SR24LaJn2udA", callContext.id);
throw ex;

});
};
Controller.prototype._getData$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("GetData");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:bbm79xCXZk6+5bYAR_TQIw:/NRWebFlows.G6g8LlI0+UqpwXA+JmvtFg/NodesShownInESpaceTree.5Qwk_Cux1EqD9x74kdEnqA/ClientActions.bbm79xCXZk6+5bYAR_TQIw:bH+tqCtqVv3XME+ClDxnig", "ShopperPortalEU", "GetData", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:6V+2VkZufU2XAgpPM+Enbg", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:F3bhqTsHuE+a2rMV9+oJJw", callContext.id);
// Execute Action: FetchPassports
return controller._fetchPassports$Action(callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:PXWn+s4iDESe3DirAo5yoQ", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:bbm79xCXZk6+5bYAR_TQIw", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:bbm79xCXZk6+5bYAR_TQIw", callContext.id);
throw ex;

});
};

Controller.prototype.onInitialize$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onInitialize$Action, callContext);

};
Controller.prototype.add$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._add$Action, callContext);

};
Controller.prototype.onDestroy$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onDestroy$Action, callContext);

};
Controller.prototype.backOnClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._backOnClick$Action, callContext);

};
Controller.prototype.fetchPassports$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._fetchPassports$Action, callContext);

};
Controller.prototype.getData$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._getData$Action, callContext);

};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:G6g8LlI0+UqpwXA+JmvtFg:/NRWebFlows.G6g8LlI0+UqpwXA+JmvtFg:yposeKjmRCh6Km0A8t9bYg", "ShopperPortalEU", "Profile", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:5Qwk_Cux1EqD9x74kdEnqA:/NRWebFlows.G6g8LlI0+UqpwXA+JmvtFg/NodesShownInESpaceTree.5Qwk_Cux1EqD9x74kdEnqA:XEKoWRsYjZEuqaKIP5XkGQ", "ShopperPortalEU", "Passports", "NRNodes.WebScreen", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:5Qwk_Cux1EqD9x74kdEnqA", callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:G6g8LlI0+UqpwXA+JmvtFg", callContext.id);
};
Controller.prototype.onInitializeEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Profile/Passports On Initialize");
return controller.onInitialize$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Profile/Passports On Destroy");
return controller.onDestroy$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return ShopperPortalEU_ProfileController.default.handleError(ex, this.callContext());
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return ShopperPortalEUController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, ShopperPortalEULanguageResources);
});

define("ShopperPortalEU.Profile.Passports.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"zbnkWuwO00CPDCih5NMz0g": {
getter: function (varBag, idService) {
return varBag.allExceptionsVar.value;
}
},
"eMhcrbxAf0O94jHxRRbnsQ": {
getter: function (varBag, idService) {
return varBag.getPassportsVar.value;
}
},
"E07mkN4KkkW6LwWjAy9xpg": {
getter: function (varBag, idService) {
return varBag.model.variables.isDataFetchedVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"Fu7UviU+O0+qIFz0r3fHCg": {
getter: function (varBag, idService) {
return varBag.model.variables.hasFetchErrorVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"Aft8Oi7tmUSyEi4tnDmujA": {
getter: function (varBag, idService) {
return varBag.model.variables.passportsVar;
}
},
"w_WHW8c3fU6XOCzXP2XDTQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderLeft"));
})(varBag.model, idService);
}
},
"BccL2YHigkm0ytI49lcbXw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderCenter"));
})(varBag.model, idService);
}
},
"48pMmu_I_UeAZ3LJIujC9A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderRight"));
})(varBag.model, idService);
}
},
"vYoEOS2_zEO20k0AND60Rg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"inOoPMthmUS_989lPuonKw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"4_1g8wW01kWTS4YBaIoSvQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"Q+_b+UuqxUuA0OPVYfYZ2g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"c3an0fKxVEaih4QDsvHWBw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"HLICp7hB8kWBVr_Oysf2KQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"HWdz8RF8bEKdWxXPYlKnHA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"wwc9FwnkEE+e9nhr+W3iIg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"hAg1CZV1L0KODPd6Di36LQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"BGFGDpEpPkymqblEi+NSbQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"K95IaIZSs0WF9Mi3FohwRg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Button"));
})(varBag.model, idService);
}
},
"sAy6KbKnGkiyDdqfyxhI6g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"IoxKB+5CEEe00oZyZO2M7A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Bottom"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
