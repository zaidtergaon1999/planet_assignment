define("reCAPTCHAReact.reCAPTCHAv3.RecaptchaV3.mvc$model", ["OutSystems/ClientRuntime/Main", "reCAPTCHAReact.model", "reCAPTCHAReact.reCAPTCHAPrivate.Recaptcha.mvc$model", "reCAPTCHAReact.model$BooleanRecord"], function (OutSystems, reCAPTCHAReactModel, reCAPTCHAReact_reCAPTCHAPrivate_Recaptcha_mvcModel) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("SiteKey", "siteKeyIn", "SiteKey", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, false), 
this.attr("_siteKeyInDataFetchStatus", "_siteKeyInDataFetchStatus", "_siteKeyInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("RecaptchaTheme", "recaptchaThemeIn", "RecaptchaTheme", true, false, OS.DataTypes.DataTypes.Text, function () {
return reCAPTCHAReactModel.staticEntities.recaptchaTheme.light;
}, false), 
this.attr("_recaptchaThemeInDataFetchStatus", "_recaptchaThemeInDataFetchStatus", "_recaptchaThemeInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("RecaptchaBadge", "recaptchaBadgeIn", "RecaptchaBadge", true, false, OS.DataTypes.DataTypes.Text, function () {
return reCAPTCHAReactModel.staticEntities.recaptchaBadge.inline;
}, false), 
this.attr("_recaptchaBadgeInDataFetchStatus", "_recaptchaBadgeInDataFetchStatus", "_recaptchaBadgeInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("HideBadge", "hideBadgeIn", "HideBadge", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("_hideBadgeInDataFetchStatus", "_hideBadgeInDataFetchStatus", "_hideBadgeInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("OptionalCallbacks", "optionalCallbacksIn", "OptionalCallbacks", true, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new reCAPTCHAReactModel.BooleanRecord());
}, false, reCAPTCHAReactModel.BooleanRecord), 
this.attr("_optionalCallbacksInDataFetchStatus", "_optionalCallbacksInDataFetchStatus", "_optionalCallbacksInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Model._hasValidationWidgetsValue = undefined;
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
if((Model._hasValidationWidgetsValue === undefined)) {
Model._hasValidationWidgetsValue = reCAPTCHAReact_reCAPTCHAPrivate_Recaptcha_mvcModel.hasValidationWidgets;
}

return Model._hasValidationWidgetsValue;
}
});

Model.prototype.setInputs = function (inputs) {
if("SiteKey" in inputs) {
this.variables.siteKeyIn = inputs.SiteKey;
if("_siteKeyInDataFetchStatus" in inputs) {
this.variables._siteKeyInDataFetchStatus = inputs._siteKeyInDataFetchStatus;
}

}

if("RecaptchaTheme" in inputs) {
this.variables.recaptchaThemeIn = inputs.RecaptchaTheme;
if("_recaptchaThemeInDataFetchStatus" in inputs) {
this.variables._recaptchaThemeInDataFetchStatus = inputs._recaptchaThemeInDataFetchStatus;
}

}

if("RecaptchaBadge" in inputs) {
this.variables.recaptchaBadgeIn = inputs.RecaptchaBadge;
if("_recaptchaBadgeInDataFetchStatus" in inputs) {
this.variables._recaptchaBadgeInDataFetchStatus = inputs._recaptchaBadgeInDataFetchStatus;
}

}

if("HideBadge" in inputs) {
this.variables.hideBadgeIn = inputs.HideBadge;
if("_hideBadgeInDataFetchStatus" in inputs) {
this.variables._hideBadgeInDataFetchStatus = inputs._hideBadgeInDataFetchStatus;
}

}

if("OptionalCallbacks" in inputs) {
this.variables.optionalCallbacksIn = inputs.OptionalCallbacks;
if("_optionalCallbacksInDataFetchStatus" in inputs) {
this.variables._optionalCallbacksInDataFetchStatus = inputs._optionalCallbacksInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "reCAPTCHAv3.RecaptchaV3");
});
define("reCAPTCHAReact.reCAPTCHAv3.RecaptchaV3.mvc$view", ["OutSystems/ClientRuntime/Main", "reCAPTCHAReact.model", "reCAPTCHAReact.controller", "react", "OutSystems/ReactView/Main", "reCAPTCHAReact.reCAPTCHAv3.RecaptchaV3.mvc$model", "reCAPTCHAReact.reCAPTCHAv3.RecaptchaV3.mvc$controller", "reCAPTCHAReact.reCAPTCHAPrivate.Recaptcha.mvc$view", "OutSystems/ReactWidgets/Main", "reCAPTCHAReact.model$BooleanRecord"], function (OutSystems, reCAPTCHAReactModel, reCAPTCHAReactController, React, OSView, reCAPTCHAReact_reCAPTCHAv3_RecaptchaV3_mvc_model, reCAPTCHAReact_reCAPTCHAv3_RecaptchaV3_mvc_controller, reCAPTCHAReact_reCAPTCHAPrivate_Recaptcha_mvc_view, OSWidgets) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            var thisIsInstanceOfSuper = this instanceof _super;
            if (thisIsInstanceOfSuper == false) {
                return;
            }

            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "reCAPTCHAv3.RecaptchaV3";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [reCAPTCHAReact_reCAPTCHAPrivate_Recaptcha_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return reCAPTCHAReact_reCAPTCHAv3_RecaptchaV3_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return reCAPTCHAReact_reCAPTCHAv3_RecaptchaV3_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), $if(false, false, this, function () {
return [];
}, function () {
return [React.createElement(reCAPTCHAReact_reCAPTCHAPrivate_Recaptcha_mvc_view, {
inputs: {
RecaptchaTheme: model.variables.recaptchaThemeIn,
_recaptchaThemeInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._recaptchaThemeInDataFetchStatus),
RecaptchaBadge: model.variables.recaptchaBadgeIn,
_recaptchaBadgeInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._recaptchaBadgeInDataFetchStatus),
HideBadge: model.variables.hideBadgeIn,
_hideBadgeInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._hideBadgeInDataFetchStatus),
AddErrorCallback: model.variables.optionalCallbacksIn.addErrorCallbackAttr,
_addErrorCallbackInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._optionalCallbacksInDataFetchStatus),
AddExpiredCallback: false,
Checkbox: false,
SiteKey: model.variables.siteKeyIn,
_siteKeyInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._siteKeyInDataFetchStatus)
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
recaptchaRendered$Action: function (idIn) {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "reCAPTCHAPrivate/Recaptcha RecaptchaRendered");
controller.render$Action(idIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
errorCallback$Action: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "reCAPTCHAPrivate/Recaptcha ErrorCallback");
controller.error$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
dataCallback$Action: function (tokenIn) {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "reCAPTCHAPrivate/Recaptcha DataCallback");
controller.callback$Action(tokenIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "0",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("reCAPTCHAReact.reCAPTCHAv3.RecaptchaV3.mvc$controller", ["OutSystems/ClientRuntime/Main", "reCAPTCHAReact.model", "reCAPTCHAReact.controller", "reCAPTCHAReact.languageResources", "reCAPTCHAReact.reCAPTCHAv3.RecaptchaV3.mvc$debugger", "reCAPTCHAReact.model$BooleanRecord"], function (OutSystems, reCAPTCHAReactModel, reCAPTCHAReactController, reCAPTCHAReactLanguageResources, reCAPTCHAReact_reCAPTCHAv3_RecaptchaV3_mvc_Debugger) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = false;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions

Controller.prototype.callback$Action = function () {
return Promise.resolve();
};
Controller.prototype.render$Action = function () {
return Promise.resolve();
};
Controller.prototype.error$Action = function () {
return Promise.resolve();
};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("o_YczqP5jE+AKx3_6JNghg:AdUvMeqDMEGIjWakCsOfqg:/NRWebFlows.AdUvMeqDMEGIjWakCsOfqg:cIqOY8usvOkCey7BmseGog", "reCAPTCHAReact", "reCAPTCHAv3", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("o_YczqP5jE+AKx3_6JNghg:qP+g5fSMhE65gvZG0cjkvg:/NRWebFlows.AdUvMeqDMEGIjWakCsOfqg/NodesShownInESpaceTree.qP+g5fSMhE65gvZG0cjkvg:fAd4nUJ6xD40ijZlpnxlzA", "reCAPTCHAReact", "RecaptchaV3", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("o_YczqP5jE+AKx3_6JNghg:qP+g5fSMhE65gvZG0cjkvg", callContext.id);
OutSystemsDebugger.pop("o_YczqP5jE+AKx3_6JNghg:AdUvMeqDMEGIjWakCsOfqg", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return reCAPTCHAReactController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, reCAPTCHAReactLanguageResources);
});

define("reCAPTCHAReact.reCAPTCHAv3.RecaptchaV3.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"pGlazZkHX0qYYgpNxho+jA": {
getter: function (varBag, idService) {
return varBag.model.variables.siteKeyIn;
},
dataType: OS.DataTypes.DataTypes.Text
},
"A8JTfX14pUy1VYRqTVSxHQ": {
getter: function (varBag, idService) {
return varBag.model.variables.recaptchaThemeIn;
},
dataType: OS.DataTypes.DataTypes.Text
},
"M7bBQW2Zbk+pCN7Zl2r9zA": {
getter: function (varBag, idService) {
return varBag.model.variables.recaptchaBadgeIn;
},
dataType: OS.DataTypes.DataTypes.Text
},
"E0ii1Ty8YkCXhAvsmqa4hg": {
getter: function (varBag, idService) {
return varBag.model.variables.hideBadgeIn;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"krC2euOUp0CZ1PcaTCqdEw": {
getter: function (varBag, idService) {
return varBag.model.variables.optionalCallbacksIn;
}
},
"Hzqz0+T810qEJ0h_Z4Md5Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Preview"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
