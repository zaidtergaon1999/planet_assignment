class customRadioGroup {
  constructor(id, options, events) {
    this.class = 'custom-radio-group';
    this.element = document.getElementById(id);
    this.radios = this._getRadios();
    this.options = options;
    this.events = events;
    this._build();
  }
  _getRadios() {
    return [...this.element.querySelectorAll('.custom-radio-group-item__input input')];
  }
  _setProps() {
    this.options.testId ? this.element.setAttribute('data-testid', this.options.testId) : this.element.removeAttribute('data-testid');
  }
  change(value) {
    this.events.change(value);
  }
  render() {
    this.radios = this._getRadios();
    for (let radio of this.radios) {
      radio.checked = this.options.value === radio.value;
      radio.checked ? radio.parentElement.parentElement.classList.add('custom-radio-group-item--checked') : radio.parentElement.parentElement.classList.remove('custom-radio-group-item--checked');
    }
  }
  _build() {
    this.element.customRadioGroup = this;
    this._setProps();
  }
  parametersChanged(options) {
    this.options = options;
    this._setProps();
  }
}