class customCheckbox {
  constructor(id, options) {
    this.class = 'custom-checkbox';
    this.element = document.getElementById(id);
    this.elements = {
      checkbox: this.element.firstElementChild.getElementsByClassName('checkbox')[0],
      label: this.element.lastElementChild.getElementsByTagName('label')[0]
    }
    this.stateClasses = {
      notValid: this.class.concat('--not-valid'),
      disabled: this.class.concat('--disabled'),
      checked: this.class.concat('--checked')
    };
    this.options = options;
  }
  checkboxAttributes() {
    if (this.elements.checkbox) {
      this.elements.checkbox.checked ? this.element.classList.add(this.stateClasses.checked) : this.element.classList.remove(this.stateClasses.checked);
      this.elements.checkbox.disabled ? this.element.classList.add(this.stateClasses.disabled) : this.element.classList.remove(this.stateClasses.disabled);
      this.elements.checkbox.classList.contains('not-valid') ? this.element.classList.add(this.stateClasses.notValid) : this.element.classList.remove(this.stateClasses.notValid);
      if (this.options.testId) {
        this.elements.checkbox.setAttribute('data-testid', this.options.testId.concat('Checkbox'));
        if (this.elements.label) {
          this.elements.label.setAttribute('data-testid', this.options.testId.concat('Label'));
        }
      } else {
        this.elements.checkbox.removeAttribute('data-testid');
        if (this.elements.label) {
          this.elements.label.removeAttribute('data-testid');
        }
      }
    }
  }
  render() {
    this.checkboxAttributes();
  }
  parametersChanged(options) {
    this.options = options;
  }
}