define("ShopperPortalEU.InternalComponents.DatatransTokenization_WB.mvc$model", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_UI_Components.controller", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.controller", "ShopperPortalEU_Shopper_IS.controller", "ShopperPortalEU_Forms_IS.controller", "ShopperPortalEU_UI_Components.model$DatatransCardChangeOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_Forms_IS.model$FormInfo_WrapperRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Forms_IS", "ShopperPortalEU.model$FormInfo_WrapperList", "ShopperPortalEU_Shopper_IS.model$DatatransTokenFallbackRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS", "ShopperPortalEU_UI_Components.model$DatatransCardOptionsRec", "ShopperPortalEU_UI_Components.model$CustomInputOptionsRec", "ShopperPortalEU_UI_Components.model$CustomInputIconOptionRec", "ShopperPortalEU_UI_Components.model$CustomInputValidationOptionsRec", "ShopperPortalEU_UI_Components.controller$DatatransCardSubmit", "ShopperPortalEU.controller$FormatCardHolderName", "ShopperPortalEU_UI_Components.controller$DatatransCardExpiryDateFocus", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger", "ShopperPortalEU_Shopper_IS.model$CreateCardRec", "ShopperPortalEU_Shopper_IS.controller$CreateCard", "ShopperPortalEU_Shopper_IS.model$GetCardsResponseRec", "ShopperPortalEU_Forms_IS.controller$FormListRequestRefund", "ShopperPortalEU_Shopper_IS.model$GetShopperResponseRec", "ShopperPortalEU.controller$SetShopperClientVariables", "ShopperPortalEU_Shopper_IS.controller$GetShopper", "ShopperPortalEU_Shopper_IS.model$CreateCardDataRec"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_Forms_ISModel, ShopperPortalEU_Shopper_ISModel, ShopperPortalEU_UI_ComponentsController, ShopperPortalEUController, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ThemeController, ShopperPortalEU_Shopper_ISController, ShopperPortalEU_Forms_ISController) {
var OS = OutSystems.Internal;

var GetDataDataActRec = (function (_super) {
__extends(GetDataDataActRec, _super);
function GetDataDataActRec(defaults) {
_super.apply(this, arguments);
}
GetDataDataActRec.attributesToDeclare = function () {
return [
this.attr("IsProd", "isProdOut", "IsProd", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
GetDataDataActRec.fromStructure = function (str) {
return new GetDataDataActRec(new GetDataDataActRec.RecordClass({
isProdOut: OS.DataTypes.ImmutableBase.getData(str)
}));
};
GetDataDataActRec.init();
return GetDataDataActRec;
})(OS.Model.DataSourceRecord);

var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("DatatransObject", "datatransObjectVar", "DatatransObject", true, false, OS.DataTypes.DataTypes.Object, function () {
return null;
}, false), 
this.attr("Transaction", "transactionVar", "Transaction", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, false), 
this.attr("CardHoldersName", "cardHoldersNameVar", "CardHoldersName", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, false), 
this.attr("IsFromAddCardScreen", "isFromAddCardScreenIn", "IsFromAddCardScreen", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("_isFromAddCardScreenInDataFetchStatus", "_isFromAddCardScreenInDataFetchStatus", "_isFromAddCardScreenInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("IsToSubmitCard", "isToSubmitCardIn", "IsToSubmitCard", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("_isToSubmitCardInDataFetchStatus", "_isToSubmitCardInDataFetchStatus", "_isToSubmitCardInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("IsDefaultCard", "isDefaultCardIn", "IsDefaultCard", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("_isDefaultCardInDataFetchStatus", "_isDefaultCardInDataFetchStatus", "_isDefaultCardInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("MerchantId", "merchantIdIn", "MerchantId", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, false), 
this.attr("_merchantIdInDataFetchStatus", "_merchantIdInDataFetchStatus", "_merchantIdInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("CardDetailsData", "cardDetailsDataIn", "CardDetailsData", true, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.DatatransCardChangeOptionsRec());
}, false, ShopperPortalEU_UI_ComponentsModel.DatatransCardChangeOptionsRec), 
this.attr("_cardDetailsDataInDataFetchStatus", "_cardDetailsDataInDataFetchStatus", "_cardDetailsDataInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("CardErrorMessage", "cardErrorMessageIn", "CardErrorMessage", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, false), 
this.attr("_cardErrorMessageInDataFetchStatus", "_cardErrorMessageInDataFetchStatus", "_cardErrorMessageInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("IsExpiryDateError", "isExpiryDateErrorIn", "IsExpiryDateError", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("_isExpiryDateErrorInDataFetchStatus", "_isExpiryDateErrorInDataFetchStatus", "_isExpiryDateErrorInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("FormsList_ReadyForRefund", "formsList_ReadyForRefundIn", "FormsList_ReadyForRefund", true, false, OS.DataTypes.DataTypes.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEUModel.FormInfo_WrapperList());
}, false, ShopperPortalEUModel.FormInfo_WrapperList), 
this.attr("_formsList_ReadyForRefundInDataFetchStatus", "_formsList_ReadyForRefundInDataFetchStatus", "_formsList_ReadyForRefundInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("TokenFallback", "tokenFallbackIn", "TokenFallback", true, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Shopper_ISModel.DatatransTokenFallbackRec());
}, false, ShopperPortalEU_Shopper_ISModel.DatatransTokenFallbackRec), 
this.attr("_tokenFallbackInDataFetchStatus", "_tokenFallbackInDataFetchStatus", "_tokenFallbackInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("IsToSaveNewCard", "isToSaveNewCardIn", "IsToSaveNewCard", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("_isToSaveNewCardInDataFetchStatus", "_isToSaveNewCardInDataFetchStatus", "_isToSaveNewCardInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("Card", "cardIn", "Card", true, false, OS.DataTypes.DataTypes.Text, function () {
return "0";
}, false), 
this.attr("_cardInDataFetchStatus", "_cardInDataFetchStatus", "_cardInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("IsFromFormDetailsScreen", "isFromFormDetailsScreenIn", "IsFromFormDetailsScreen", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("_isFromFormDetailsScreenInDataFetchStatus", "_isFromFormDetailsScreenInDataFetchStatus", "_isFromFormDetailsScreenInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("GetData", "getDataDataAct", "getDataDataAct", true, true, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new GetDataDataActRec());
}, true, GetDataDataActRec)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {
Input_CardHolderName: OS.Model.ValidationWidgetRecord
};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return true;
}
});

Model.prototype.setInputs = function (inputs) {
if("IsFromAddCardScreen" in inputs) {
this.variables.isFromAddCardScreenIn = inputs.IsFromAddCardScreen;
if("_isFromAddCardScreenInDataFetchStatus" in inputs) {
this.variables._isFromAddCardScreenInDataFetchStatus = inputs._isFromAddCardScreenInDataFetchStatus;
}

}

if("IsToSubmitCard" in inputs) {
this.variables.isToSubmitCardIn = inputs.IsToSubmitCard;
if("_isToSubmitCardInDataFetchStatus" in inputs) {
this.variables._isToSubmitCardInDataFetchStatus = inputs._isToSubmitCardInDataFetchStatus;
}

}

if("IsDefaultCard" in inputs) {
this.variables.isDefaultCardIn = inputs.IsDefaultCard;
if("_isDefaultCardInDataFetchStatus" in inputs) {
this.variables._isDefaultCardInDataFetchStatus = inputs._isDefaultCardInDataFetchStatus;
}

}

if("MerchantId" in inputs) {
this.variables.merchantIdIn = inputs.MerchantId;
if("_merchantIdInDataFetchStatus" in inputs) {
this.variables._merchantIdInDataFetchStatus = inputs._merchantIdInDataFetchStatus;
}

}

if("CardDetailsData" in inputs) {
this.variables.cardDetailsDataIn = inputs.CardDetailsData;
if("_cardDetailsDataInDataFetchStatus" in inputs) {
this.variables._cardDetailsDataInDataFetchStatus = inputs._cardDetailsDataInDataFetchStatus;
}

}

if("CardErrorMessage" in inputs) {
this.variables.cardErrorMessageIn = inputs.CardErrorMessage;
if("_cardErrorMessageInDataFetchStatus" in inputs) {
this.variables._cardErrorMessageInDataFetchStatus = inputs._cardErrorMessageInDataFetchStatus;
}

}

if("IsExpiryDateError" in inputs) {
this.variables.isExpiryDateErrorIn = inputs.IsExpiryDateError;
if("_isExpiryDateErrorInDataFetchStatus" in inputs) {
this.variables._isExpiryDateErrorInDataFetchStatus = inputs._isExpiryDateErrorInDataFetchStatus;
}

}

if("FormsList_ReadyForRefund" in inputs) {
this.variables.formsList_ReadyForRefundIn = inputs.FormsList_ReadyForRefund;
if("_formsList_ReadyForRefundInDataFetchStatus" in inputs) {
this.variables._formsList_ReadyForRefundInDataFetchStatus = inputs._formsList_ReadyForRefundInDataFetchStatus;
}

}

if("TokenFallback" in inputs) {
this.variables.tokenFallbackIn = inputs.TokenFallback;
if("_tokenFallbackInDataFetchStatus" in inputs) {
this.variables._tokenFallbackInDataFetchStatus = inputs._tokenFallbackInDataFetchStatus;
}

}

if("IsToSaveNewCard" in inputs) {
this.variables.isToSaveNewCardIn = inputs.IsToSaveNewCard;
if("_isToSaveNewCardInDataFetchStatus" in inputs) {
this.variables._isToSaveNewCardInDataFetchStatus = inputs._isToSaveNewCardInDataFetchStatus;
}

}

if("Card" in inputs) {
this.variables.cardIn = inputs.Card;
if("_cardInDataFetchStatus" in inputs) {
this.variables._cardInDataFetchStatus = inputs._cardInDataFetchStatus;
}

}

if("IsFromFormDetailsScreen" in inputs) {
this.variables.isFromFormDetailsScreenIn = inputs.IsFromFormDetailsScreen;
if("_isFromFormDetailsScreenInDataFetchStatus" in inputs) {
this.variables._isFromFormDetailsScreenInDataFetchStatus = inputs._isFromFormDetailsScreenInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "InternalComponents.DatatransTokenization_WB");
});
define("ShopperPortalEU.InternalComponents.DatatransTokenization_WB.mvc$view", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_UI_Components.controller", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.controller", "ShopperPortalEU_Shopper_IS.controller", "ShopperPortalEU_Forms_IS.controller", "react", "OutSystems/ReactView/Main", "ShopperPortalEU.InternalComponents.DatatransTokenization_WB.mvc$model", "ShopperPortalEU.InternalComponents.DatatransTokenization_WB.mvc$controller", "ShopperPortalEU.clientVariables", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.DatatransCard.mvc$view", "OutSystems/ReactWidgets/Main", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomInput.mvc$view", "ShopperPortalEU_UI_Components.model$DatatransCardChangeOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_Forms_IS.model$FormInfo_WrapperRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Forms_IS", "ShopperPortalEU.model$FormInfo_WrapperList", "ShopperPortalEU_Shopper_IS.model$DatatransTokenFallbackRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS", "ShopperPortalEU_UI_Components.model$DatatransCardOptionsRec", "ShopperPortalEU_UI_Components.model$CustomInputOptionsRec", "ShopperPortalEU_UI_Components.model$CustomInputIconOptionRec", "ShopperPortalEU_UI_Components.model$CustomInputValidationOptionsRec", "ShopperPortalEU_UI_Components.controller$DatatransCardSubmit", "ShopperPortalEU.controller$FormatCardHolderName", "ShopperPortalEU_UI_Components.controller$DatatransCardExpiryDateFocus", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger", "ShopperPortalEU_Shopper_IS.model$CreateCardRec", "ShopperPortalEU_Shopper_IS.controller$CreateCard", "ShopperPortalEU_Shopper_IS.model$GetCardsResponseRec", "ShopperPortalEU_Forms_IS.controller$FormListRequestRefund", "ShopperPortalEU_Shopper_IS.model$GetShopperResponseRec", "ShopperPortalEU.controller$SetShopperClientVariables", "ShopperPortalEU_Shopper_IS.controller$GetShopper", "ShopperPortalEU_Shopper_IS.model$CreateCardDataRec"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_Forms_ISModel, ShopperPortalEU_Shopper_ISModel, ShopperPortalEU_UI_ComponentsController, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ThemeController, ShopperPortalEU_Shopper_ISController, ShopperPortalEU_Forms_ISController, React, OSView, ShopperPortalEU_InternalComponents_DatatransTokenization_WB_mvc_model, ShopperPortalEU_InternalComponents_DatatransTokenization_WB_mvc_controller, ShopperPortalEUClientVariables, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_DatatransCard_mvc_view, OSWidgets, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomInput_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            var thisIsInstanceOfSuper = this instanceof _super;
            if (thisIsInstanceOfSuper == false) {
                return;
            }

            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "InternalComponents.DatatransTokenization_WB";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_DatatransCard_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomInput_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return ShopperPortalEU_InternalComponents_DatatransTokenization_WB_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return ShopperPortalEU_InternalComponents_DatatransTokenization_WB_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), $if(model.variables.getDataDataAct.isDataFetchedAttr, false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_DatatransCard_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("dR4Cjz7vZ0+pTssJzCAfnw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.DatatransCardOptionsRec();
rec.testIdAttr = "CardInformation";
rec.merchantIdAttr = model.variables.merchantIdIn;
rec.isProdEnvironmentAttr = model.variables.getDataDataAct.isProdOut;
rec.labelAttr = "Card information";
rec.isMandatoryAttr = true;
rec.placeholderAttr = "Debit or credit card number";
rec.includeExpiryDateAttr = true;
rec.expiryDateAttr = model.variables.cardDetailsDataIn.expiryDateAttr;
rec.errorMessageAttr = model.variables.cardErrorMessageIn;
return rec;
}();
}, function () {
return model.variables.merchantIdIn;
}, function () {
return model.variables.getDataDataAct.isProdOut;
}, function () {
return model.variables.cardDetailsDataIn.expiryDateAttr;
}, function () {
return model.variables.cardErrorMessageIn;
}),
_optionsInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._merchantIdInDataFetchStatus, model.variables.getDataDataAct.dataFetchStatusAttr, model.variables._cardDetailsDataInDataFetchStatus, model.variables._cardErrorMessageInDataFetchStatus)
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onSuccess$Action: function (transactionIdIn) {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ShopperPortalEUUIComponents/DatatransCard OnSuccess");
return controller.datatransCardOnSuccess$Action(transactionIdIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
onChange$Action: function (cardInfoIn) {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ShopperPortalEUUIComponents/DatatransCard OnChange");
return controller.datatransCardOnChange$Action(cardInfoIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
onReady$Action: function (objIn) {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ShopperPortalEUUIComponents/DatatransCard OnReady");
controller.datatransCardOnReady$Action(objIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
onError$Action: function (errorMessageIn) {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ShopperPortalEUUIComponents/DatatransCard OnError");
return controller.datatransCardOnError$Action(errorMessageIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "0",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomInput_mvc_view, {
inputs: {
ExtendedClass: "margin-top-04",
Options: model.getCachedValue(idService.getId("Utbg3TGAJU6+pkxiqmt2Lw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomInputOptionsRec();
rec.testIdAttr = "NameOnCardInput";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "1",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
label: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
mandatory: true,
targetWidget: "Input_CardHolderName",
_idProps: {
service: idService,
uuid: "2"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
value: "Name on card",
_idProps: {
service: idService,
uuid: "3"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
}),
input: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Input, {
_validationProps: {
validationService: validationService
},
enabled: true,
gridProperties: {
classes: "OSFillParent"
},
inputType: /*Text*/ 0,
mandatory: true,
maxLength: 50,
onChange: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "InternalComponents/DatatransTokenization_WB/Input_CardHolderName OnChange");
return controller.cardHolderNameOnChange$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
style: "form-control",
variable: model.createVariable(OS.DataTypes.DataTypes.Text, model.variables.cardHoldersNameVar, function (value) {
model.variables.cardHoldersNameVar = value;
}),
_idProps: {
service: idService,
name: "Input_CardHolderName"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
description: PlaceholderContent.Empty
},
_dependencies: [asPrimitiveValue(model.variables.cardHoldersNameVar)]
})];
}, function () {
return [];
}));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("ShopperPortalEU.InternalComponents.DatatransTokenization_WB.mvc$controller", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_UI_Components.controller", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.controller", "ShopperPortalEU_Shopper_IS.controller", "ShopperPortalEU_Forms_IS.controller", "ShopperPortalEU.languageResources", "ShopperPortalEU.clientVariables", "ShopperPortalEU.InternalComponents.DatatransTokenization_WB.mvc$debugger", "ShopperPortalEU_UI_Components.model$DatatransCardChangeOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_Forms_IS.model$FormInfo_WrapperRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Forms_IS", "ShopperPortalEU.model$FormInfo_WrapperList", "ShopperPortalEU_Shopper_IS.model$DatatransTokenFallbackRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS", "ShopperPortalEU_UI_Components.model$DatatransCardOptionsRec", "ShopperPortalEU_UI_Components.model$CustomInputOptionsRec", "ShopperPortalEU_UI_Components.model$CustomInputIconOptionRec", "ShopperPortalEU_UI_Components.model$CustomInputValidationOptionsRec", "ShopperPortalEU_UI_Components.controller$DatatransCardSubmit", "ShopperPortalEU.controller$FormatCardHolderName", "ShopperPortalEU_UI_Components.controller$DatatransCardExpiryDateFocus", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger", "ShopperPortalEU_Shopper_IS.model$CreateCardRec", "ShopperPortalEU_Shopper_IS.controller$CreateCard", "ShopperPortalEU_Shopper_IS.model$GetCardsResponseRec", "ShopperPortalEU_Forms_IS.controller$FormListRequestRefund", "ShopperPortalEU_Shopper_IS.model$GetShopperResponseRec", "ShopperPortalEU.controller$SetShopperClientVariables", "ShopperPortalEU_Shopper_IS.controller$GetShopper", "ShopperPortalEU_Shopper_IS.model$CreateCardDataRec"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_Forms_ISModel, ShopperPortalEU_Shopper_ISModel, ShopperPortalEU_UI_ComponentsController, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ThemeController, ShopperPortalEU_Shopper_ISController, ShopperPortalEU_Forms_ISController, ShopperPortalEULanguageResources, ShopperPortalEUClientVariables, ShopperPortalEU_InternalComponents_DatatransTokenization_WB_mvc_Debugger) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {
getData$DataActRefresh: 0
};
this.dataFetchDependentsGraph = {
getData$DataActRefresh: []
};
this.shouldSendClientVarsToDataSources = true;
}
// Server Actions

// Aggregates and Data Actions
Controller.prototype.getData$DataActRefresh = function (callContext) {
var model = this.model;
var controller = this.controller;
var callContext = controller.callContext(callContext);
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:sQKGHGHGgE6lN4hj_TsUoA:/NRWebFlows.WLZg9jO0M0aiRlyqBkvkgg/NodesShownInESpaceTree.JUNflh5ghUigHFDKthBfoA/DataActions.sQKGHGHGgE6lN4hj_TsUoA:roKjnAhvkF8AIdehxyCfzQ", "ShopperPortalEU", "GetData", "NRFlows.DataScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.setThreadStartName(callContext.id, "InternalComponents/DatatransTokenization_WB/GetData");
return controller.callDataAction("DataActionGetData", "screenservices/ShopperPortalEU/InternalComponents/DatatransTokenization_WB/DataActionGetData", "ZN7OLC3puE3n3lzxtf_iDQ", function (b) {
model.variables.getDataDataAct.dataFetchStatusAttr = b;
}, function (json) {
model.variables.getDataDataAct.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getDataDataAct.constructor));
}, undefined, OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, callContext, ShopperPortalEUClientVariables, false);

}, function () {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:sQKGHGHGgE6lN4hj_TsUoA", callContext.id);
controller.popDebuggerContext(callContext);

});
};

Controller.prototype.dataFetchActionNames = ["getData$DataActRefresh"];
// Client Actions
Controller.prototype._onParametersChanged$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnParametersChanged");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:ZOQNIr5lNEuq+4VnTwn+Mw:/NRWebFlows.WLZg9jO0M0aiRlyqBkvkgg/NodesShownInESpaceTree.JUNflh5ghUigHFDKthBfoA/ClientActions.ZOQNIr5lNEuq+4VnTwn+Mw:pFeH5XGaGwv7vgqD8k_3PA", "ShopperPortalEU", "OnParametersChanged", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:yQLNBCLTxUurzJQY517hLA", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:n9WG9RG5P0GgGU1UY8ExBQ", callContext.id) && model.variables.isToSubmitCardIn)) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:uSya+SP8LEe0RXktX+12pQ", callContext.id);
// Execute Action: DatatransCardSubmit
ShopperPortalEU_UI_ComponentsController.default.datatransCardSubmit$Action(model.variables.datatransObjectVar, callContext);
// Is card from wallet used ?
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:CgozrZ8o8EyZ2s1wI34pyQ", callContext.id) && (OS.BuiltinFunctions.textToInteger(model.variables.cardIn) > 0))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:VXIwvwQnOUq4AUdHR+waAg", callContext.id);
// Execute Action: DatatransCardOnSuccess
return controller._datatransCardOnSuccess$Action("", callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:xAPmI2u5IkOw2oLc5XwQ8Q", callContext.id);
});
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:w2DSIABVXkWNVEXlmBbiqQ", callContext.id);
// Trigger Event: CardSubmitted
return controller.cardSubmitted$Action(callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:xAPmI2u5IkOw2oLc5XwQ8Q", callContext.id);
});
}

});
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:cvVJsO3wKE6KIsKwIPxDCg", callContext.id);
}

});
}).then(function (res) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:ZOQNIr5lNEuq+4VnTwn+Mw", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:ZOQNIr5lNEuq+4VnTwn+Mw", callContext.id);
throw ex;

});
};
Controller.prototype._datatransCardOnChange$Action = function (cardInfoIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("DatatransCardOnChange");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.InternalComponents.DatatransTokenization_WB.DatatransCardOnChange$vars"))());
vars.value.cardInfoInLocal = cardInfoIn.clone();
varBag.callContext = callContext;
varBag.vars = vars;
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:_MpGLrrnrkSmGPlK8CKBNw:/NRWebFlows.WLZg9jO0M0aiRlyqBkvkgg/NodesShownInESpaceTree.JUNflh5ghUigHFDKthBfoA/ClientActions._MpGLrrnrkSmGPlK8CKBNw:Vg1jSPi6xX3KTw2S0967xg", "ShopperPortalEU", "DatatransCardOnChange", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:9aWTN6dZDkuGVQooGiEUzw", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:AE4vZElwOUSdYjeIF47UFg", callContext.id);
// Execute Action: DatatransCardOnChangeCleanErrorMsg
controller._datatransCardOnChangeCleanErrorMsg$Action(callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:PW6xUG985E+KU72wWdI7vg", callContext.id);
// CardDetailsData = CardInfo
model.variables.cardDetailsDataIn = vars.value.cardInfoInLocal;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:COMspN_THUCXbQxGNaTgOA", callContext.id);
// CardDetailsData.CardHolderName = CardHoldersName
model.variables.cardDetailsDataIn.cardHolderNameAttr = model.variables.cardHoldersNameVar;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:rC01TKruSkeEH55yO7dt8g", callContext.id);
// Trigger Event: UpdateParameters
return controller.updateParameters$Action(model.variables.cardDetailsDataIn, model.variables.cardErrorMessageIn, model.variables.isExpiryDateErrorIn, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:S7iKd+N8vUOtyYBEkY90cg", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:_MpGLrrnrkSmGPlK8CKBNw", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:_MpGLrrnrkSmGPlK8CKBNw", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("ShopperPortalEU.InternalComponents.DatatransTokenization_WB.DatatransCardOnChange$vars", [{
name: "CardInfo",
attrName: "cardInfoInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Record,
defaultValue: function () {
return new ShopperPortalEU_UI_ComponentsModel.DatatransCardChangeOptionsRec();
},
complexType: ShopperPortalEU_UI_ComponentsModel.DatatransCardChangeOptionsRec
}]);
Controller.prototype._datatransCardOnError$Action = function (errorMessageIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("DatatransCardOnError");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.InternalComponents.DatatransTokenization_WB.DatatransCardOnError$vars"))());
vars.value.errorMessageInLocal = errorMessageIn;
varBag.callContext = callContext;
varBag.vars = vars;
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:iENIWLH7rk+glGgYskLUSQ:/NRWebFlows.WLZg9jO0M0aiRlyqBkvkgg/NodesShownInESpaceTree.JUNflh5ghUigHFDKthBfoA/ClientActions.iENIWLH7rk+glGgYskLUSQ:ZyjK7oEeIL32v0_izbKCVw", "ShopperPortalEU", "DatatransCardOnError", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:qh3kPkPIDU+NFLvXtFfmfA", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:SH5ew+b3s0md7f6LuMLzAw", callContext.id);
// Trigger Event: ErrorSavingCard
return controller.errorSavingCard$Action(vars.value.errorMessageInLocal, false, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:b6neZo4Qh0Wrgw1_zBnHQQ", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:iENIWLH7rk+glGgYskLUSQ", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:iENIWLH7rk+glGgYskLUSQ", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("ShopperPortalEU.InternalComponents.DatatransTokenization_WB.DatatransCardOnError$vars", [{
name: "ErrorMessage",
attrName: "errorMessageInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
Controller.prototype._cardHolderNameOnChange$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("CardHolderNameOnChange");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.InternalComponents.DatatransTokenization_WB.CardHolderNameOnChange$vars"))());
varBag.callContext = callContext;
varBag.vars = vars;
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:ofyyfxlWf0qzvcKDRRARuQ:/NRWebFlows.WLZg9jO0M0aiRlyqBkvkgg/NodesShownInESpaceTree.JUNflh5ghUigHFDKthBfoA/ClientActions.ofyyfxlWf0qzvcKDRRARuQ:PwUotYP4GLimhKnpEXgpKQ", "ShopperPortalEU", "CardHolderNameOnChange", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Nht9+fk6JEGl3cXrSmyazQ", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
// Set CardHoldersName
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:7cqn1gNL2Equbt55OBx2GQ", callContext.id);
// CardHolderNameTemp = FormatCardHolderName(CardHoldersName)
vars.value.cardHolderNameTempVar = OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.formatCardHolderName$Action(model.variables.cardHoldersNameVar, callContext).outputOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:7cqn1gNL2Equbt55OBx2GQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// CardHoldersName = CardHolderNameTemp
model.variables.cardHoldersNameVar = vars.value.cardHolderNameTempVar;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:2_WzBnNKy02J0e0+cEyJuA", callContext.id);
// CardDetailsData.CardHolderName = CardHoldersName
model.variables.cardDetailsDataIn.cardHolderNameAttr = model.variables.cardHoldersNameVar;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:nWlfI1s5DUKW3rQtB5lACw", callContext.id);
// Trigger Event: UpdateParameters
return controller.updateParameters$Action(model.variables.cardDetailsDataIn, "", false, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:kMvpvxGhIUS1dV4zMFlSlw", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:ofyyfxlWf0qzvcKDRRARuQ", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:ofyyfxlWf0qzvcKDRRARuQ", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("ShopperPortalEU.InternalComponents.DatatransTokenization_WB.CardHolderNameOnChange$vars", [{
name: "CardHolderNameTemp",
attrName: "cardHolderNameTempVar",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
Controller.prototype._datatransCardOnChangeCleanErrorMsg$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("DatatransCardOnChangeCleanErrorMsg");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:chEjkGradk26YtHHp8sy7Q:/NRWebFlows.WLZg9jO0M0aiRlyqBkvkgg/NodesShownInESpaceTree.JUNflh5ghUigHFDKthBfoA/ClientActions.chEjkGradk26YtHHp8sy7Q:dqEUAlc_GRT7vvLJ7r5CWQ", "ShopperPortalEU", "DatatransCardOnChangeCleanErrorMsg", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:rm482hkYKk2HsJFoA2QaDA", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:b8nysP3kxU+MC1oT8dEX0w", callContext.id) && model.variables.isExpiryDateErrorIn)) {
// RemoveExpiryDateError
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:8ZHguu_xTEOCOGDNxtlszA", callContext.id);
// CardDetailsData.ExpiryDate = NullDate
model.variables.cardDetailsDataIn.expiryDateAttr = OS.BuiltinFunctions.nullDate();
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:8ZHguu_xTEOCOGDNxtlszA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// CardErrorMessage = ""
model.variables.cardErrorMessageIn = "";
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:8ZHguu_xTEOCOGDNxtlszA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// IsExpiryDateError = False
model.variables.isExpiryDateErrorIn = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:vqpcvhFV+Uq+UCn548Nuxg", callContext.id);
// Execute Action: DatatransCardExpiryDateFocus
ShopperPortalEU_UI_ComponentsController.default.datatransCardExpiryDateFocus$Action(model.variables.datatransObjectVar, callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:WMc8+oha90i+hV7UNawFWQ", callContext.id);
} else {
// IsCardError ?
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:4BEX9Oruzka13vnUFeTWUw", callContext.id) && ((model.variables.cardErrorMessageIn) !== ("")))) {
// RemoveCardError
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:MzcC0LlLA0akGAbyJ8ykEA", callContext.id);
// CardErrorMessage = ""
model.variables.cardErrorMessageIn = "";
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:MzcC0LlLA0akGAbyJ8ykEA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// CardDetailsData.PaymentMethod = ""
model.variables.cardDetailsDataIn.paymentMethodAttr = "";
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:MzcC0LlLA0akGAbyJ8ykEA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// CardDetailsData.IsValid = False
model.variables.cardDetailsDataIn.isValidAttr = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:WMc8+oha90i+hV7UNawFWQ", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:lCsXTA9SvUKU_jSxOR+gcA", callContext.id);
}

}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:chEjkGradk26YtHHp8sy7Q", callContext.id);
}

};
Controller.prototype._datatransCardOnSuccess$Action = function (transactionIdIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("DatatransCardOnSuccess");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.InternalComponents.DatatransTokenization_WB.DatatransCardOnSuccess$vars"))());
vars.value.transactionIdInLocal = transactionIdIn;
var createCardVar = new OS.DataTypes.VariableHolder();
var formListRequestRefundVar = new OS.DataTypes.VariableHolder();
var getShopperVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.vars = vars;
varBag.createCardVar = createCardVar;
varBag.formListRequestRefundVar = formListRequestRefundVar;
varBag.getShopperVar = getShopperVar;
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:3jAdubesZ0KLMPlznOnwDw:/NRWebFlows.WLZg9jO0M0aiRlyqBkvkgg/NodesShownInESpaceTree.JUNflh5ghUigHFDKthBfoA/ClientActions.3jAdubesZ0KLMPlznOnwDw:4EmyxuV3mXkAOPAWo+3cEA", "ShopperPortalEU", "DatatransCardOnSuccess", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:W4B4dq3YN0C+vg6SKFOa2Q", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
var block2 = false;
return OS.Flow.doWhileAsync(function () {
return false;
}, function () {
block2 = false;
return OS.Flow.doWhileAsync(function () {
return false;
}, function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:zmdLXGwNBEqGVmVrp55Jdw", callContext.id);
// BypassToken = Transaction = TransactionId
vars.value.bypassTokenVar = (model.variables.transactionVar === vars.value.transactionIdInLocal);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:WaK6gXuRkkqaLvrOtCg35w", callContext.id);
// Transaction = TransactionId
model.variables.transactionVar = vars.value.transactionIdInLocal;
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:mLWIS6B2D0+YHacYObvVUg", callContext.id) && model.variables.isFromAddCardScreenIn)) {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:tVVJNgwnV0iMdve7XVNVJg", callContext.id) && !(((vars.value.transactionIdInLocal) !== (""))))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:SdBM1iJIXECRQtUd7nalUA", callContext.id);
return OS.Flow.returnAsync();

}

} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:WH0tcE6dZE2CjlFwVNi7qw", callContext.id);
// Execute Action: FormListRequestRefund
model.flush();
return ShopperPortalEU_Forms_ISController.default.formListRequestRefund$Action(vars.value.transactionIdInLocal, function () {
var rec = new ShopperPortalEU_Shopper_ISModel.GetCardsResponseRec();
rec.maskedCardNumberAttr = model.variables.tokenFallbackIn.maskedCardAttr;
rec.expiryDateAttr = OS.BuiltinFunctions.dateToText(model.variables.cardDetailsDataIn.expiryDateAttr);
rec.expiryDateFormatAttr = model.variables.cardDetailsDataIn.expiryDateAttr;
rec.isDefaultAttr = false;
rec.paymentMethodAttr = model.variables.tokenFallbackIn.paymentMethodAttr;
rec.tokenValueAttr = model.variables.tokenFallbackIn.aliasAttr;
rec.tokenProviderAttr = "Datatrans";
rec.cardHolderNameAttr = model.variables.cardDetailsDataIn.cardHolderNameAttr;
return rec;
}(), model.variables.formsList_ReadyForRefundIn, callContext).then(function (value) {
formListRequestRefundVar.value = value;
}).then(function () {
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:i26NcpbBLkyEPKw7RIfURg", callContext.id) && formListRequestRefundVar.value.successOut)) {
// UseNewCard ?
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:7a16W3L0fkGNZsKm+26e7Q", callContext.id) && (model.variables.cardIn === "0"))) {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Jh0ay0kRdkqSvGRipDPhJw", callContext.id) && model.variables.isToSaveNewCardIn)) {
// TokenFallback & BypassToken
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:w5urBV5wkE+7yy3N9jne+w", callContext.id);
// TokenFallback = FormListRequestRefund.DatatransTokenFallback
model.variables.tokenFallbackIn = formListRequestRefundVar.value.datatransTokenFallbackOut;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:w5urBV5wkE+7yy3N9jne+w", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// BypassToken = True
vars.value.bypassTokenVar = true;
return OS.Flow.breakAsync();
}

}

// < - >
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:1Nydufzbkke7e0LScj4Hgw", callContext.id);
// < - >
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:AqkFByU_0EOBf6OGD_0UQw", callContext.id);
// jump to block2
block2 = true;
return OS.Flow.breakAsync();
} else {
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:n4tkyKHg0EO7+BEnha6cqg", callContext.id) && ((OS.BuiltinFunctions.index(formListRequestRefundVar.value.errorMessageOut, "supported", 0, false, false)) !== (-1)))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:GWXeRYghr0e7OInjPDwNHw", callContext.id);
// Trigger Event: ErrorSavingCard2
return controller.errorSavingCard$Action(formListRequestRefundVar.value.errorMessageOut, false, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:5bomoGZFgE2DsO5sThSxWg", callContext.id);
return OS.Flow.returnAsync();

});
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:90m3JhyiMkSGfQSlLwdsGQ", callContext.id);
// Trigger Event: ErrorRequestingRefund
return controller.errorRequestingRefund$Action(formListRequestRefundVar.value.errorMessageOut, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:5bomoGZFgE2DsO5sThSxWg", callContext.id);
return OS.Flow.returnAsync();

});
}

});
}

});
});
}

});
}).then(function () {
if(block2) {
return OS.Flow.breakAsync();
}

}).then(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:eEM5SlfBI02R3nflMKFs6g", callContext.id);
// Execute Action: CreateCard
model.flush();
return ShopperPortalEU_Shopper_ISController.default.createCard$Action(function () {
var rec = new ShopperPortalEU_Shopper_ISModel.CreateCardRec();
rec.transactionIdAttr = vars.value.transactionIdInLocal;
rec.shopperGuidAttr = ShopperPortalEUClientVariables.getShopperGuid();
rec.cardDataAttr = function () {
var rec = new ShopperPortalEU_Shopper_ISModel.CreateCardDataRec();
rec.expiryDateAttr = OS.BuiltinFunctions.dateToText(model.variables.cardDetailsDataIn.expiryDateAttr);
rec.isDefaultAttr = ((model.variables.isFromAddCardScreenIn) ? (model.variables.isDefaultCardIn) : (false));
rec.cardHolderNameAttr = model.variables.cardHoldersNameVar;
return rec;
}();
return rec;
}(), vars.value.bypassTokenVar, model.variables.tokenFallbackIn, callContext).then(function (value) {
createCardVar.value = value;
});
}).then(function () {
// Success
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:V1t_U0rmP0CO5_aBIXjPcw", callContext.id) && !(createCardVar.value.isSuccessOut))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:tx4WqF_0BUONHifz8qOoFA", callContext.id);
// TokenFallback = CreateCard.DatatransTokenFallback
model.variables.tokenFallbackIn = createCardVar.value.datatransTokenFallbackOut;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:P4zUkPAUK0O8958FXa3y_A", callContext.id);
// Trigger Event: ErrorSavingCard
return controller.errorSavingCard$Action(createCardVar.value.errorMessageOut, createCardVar.value.isGenericErrorOut, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:mR9or323_USjdLC4Cspdqw", callContext.id);
return OS.Flow.returnAsync();

});
}

});
});
}).then(function () {
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:NgaZk6kJzkq1oYm6A4Gy1Q", callContext.id) && !(model.variables.isFromAddCardScreenIn))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:sHsbr76ojEOR8+xXcQfnDw", callContext.id);
// Execute Action: GetShopper
model.flush();
return ShopperPortalEU_Shopper_ISController.default.getShopper$Action(ShopperPortalEUClientVariables.getShopperGuid(), callContext).then(function (value) {
getShopperVar.value = value;
}).then(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:W29XqSmsjEG0dobsPgIu0Q", callContext.id);
// Execute Action: SetShopperClientVariables
model.flush();
return ShopperPortalEUController.default.setShopperClientVariables$Action(getShopperVar.value.shopperOut, callContext);
});
}

});
}).then(function () {
// Not from Refund Details Screen ?
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:J8yPOUksOkKPF3pqpuV8CA", callContext.id) && !(model.variables.isFromFormDetailsScreenIn))) {
// not from MyRefunds card
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:4SEB6SYat0WqTXQVUCmMSg", callContext.id) && (!(ShopperPortalEUClientVariables.getFromCarouselAddCard()) && model.variables.isFromAddCardScreenIn))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:mEJjOgyZC0K1AAkq_Ps1oA", callContext.id);
// Execute Action: SuccessMessage
ShopperPortalEU_UI_ThemeController.default.customMessageTrigger$Action(function () {
var rec = new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customMessageType.success;
rec.titleAttr = "Card added";
rec.testIdAttr = "MyWalletAddCard_Message";
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:mg1xfMS980qwBnwOMSDzJg", callContext.id);
// Destination: /ShopperPortalEU/MyWallet
return OS.Flow.returnAsync(OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "MyWallet", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true));
} else {
// FromCarouselAddCard
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:6JYM8uOD1k2Lg3r1TPxvZw", callContext.id) && ShopperPortalEUClientVariables.getFromCarouselAddCard())) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:hQTkCvYipkucuZ4mwWgmLg", callContext.id);
// Execute Action: MyRefundsAddCardMessage
ShopperPortalEU_UI_ThemeController.default.customMessageTrigger$Action(function () {
var rec = new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customMessageType.success;
rec.titleAttr = "Card added";
rec.contentAttr = "<a href=\'MyWallet\' onclick=\'if (window.clarity) window.clarity(\"SeeMyWallet_link\")\'>See my wallet</a>";
rec.autoHideAttr = false;
rec.testIdAttr = "MyRefundsAddCard_Message";
rec.closeClarityEventAttr = "CloseMessageWithWallet_icon";
return rec;
}(), callContext);
// Reset client variable
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:7_aorkZnqkaCXgsqsfg5mg", callContext.id);
// FromCarouselAddCard = False
ShopperPortalEUClientVariables.setFromCarouselAddCard(false);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:P1WXr7jF9U+9Cz9y3gctHw", callContext.id);
// Destination: /ShopperPortalEU/MyRefunds
return OS.Flow.returnAsync(OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "MyRefunds", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true));
}

}

} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:JJbPIeD2JUq1wdO17iuoOw", callContext.id);
// IsFormRequestRefundTriggered = True
ShopperPortalEUClientVariables.setIsFormRequestRefundTriggered(true);
}

OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:WpBtpnkb70KYKjXtBEUMxg", callContext.id);
// Execute Action: RequestRefundFromDetailsMessage
ShopperPortalEU_UI_ThemeController.default.customMessageTrigger$Action(function () {
var rec = new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customMessageType.success;
rec.titleAttr = "Card added";
rec.contentAttr = "The card may take some time to be added to your Tax Free form.";
rec.autoHideAttr = false;
rec.testIdAttr = "RequestRefundSubmitted_Message";
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:GKo2pf8lIE+x2xgTmpruwA", callContext.id);
// Destination: (PreviousScreen)
return OS.Flow.returnAsync(OS.Navigation.navigateBack(null, callContext, true));
});
}).then(function (res) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:3jAdubesZ0KLMPlznOnwDw", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:3jAdubesZ0KLMPlznOnwDw", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("ShopperPortalEU.InternalComponents.DatatransTokenization_WB.DatatransCardOnSuccess$vars", [{
name: "TransactionId",
attrName: "transactionIdInLocal",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}, {
name: "BypassToken",
attrName: "bypassTokenVar",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Boolean,
defaultValue: function () {
return false;
}
}]);
Controller.prototype._datatransCardOnReady$Action = function (objIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("DatatransCardOnReady");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.InternalComponents.DatatransTokenization_WB.DatatransCardOnReady$vars"))());
vars.value.objInLocal = objIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:4cQavGVVEUqTayhx9PVn4Q:/NRWebFlows.WLZg9jO0M0aiRlyqBkvkgg/NodesShownInESpaceTree.JUNflh5ghUigHFDKthBfoA/ClientActions.4cQavGVVEUqTayhx9PVn4Q:XqOA4Gf8grgvgmDKFG8nOg", "ShopperPortalEU", "DatatransCardOnReady", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:0MuwXd2qS0WA9fd8wLUjpw", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Xs8KMoZfk0ekIWddRBUxTQ", callContext.id);
// DatatransObject = Obj
model.variables.datatransObjectVar = vars.value.objInLocal;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:MgkSgJY+Ik2gcWrZHap8kg", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:4cQavGVVEUqTayhx9PVn4Q", callContext.id);
}

};
Controller.registerVariableGroupType("ShopperPortalEU.InternalComponents.DatatransTokenization_WB.DatatransCardOnReady$vars", [{
name: "Obj",
attrName: "objInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Object,
defaultValue: function () {
return null;
}
}]);

Controller.prototype.onParametersChanged$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onParametersChanged$Action, callContext);

};
Controller.prototype.datatransCardOnChange$Action = function (cardInfoIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._datatransCardOnChange$Action, callContext, cardInfoIn);

};
Controller.prototype.datatransCardOnError$Action = function (errorMessageIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._datatransCardOnError$Action, callContext, errorMessageIn);

};
Controller.prototype.cardHolderNameOnChange$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._cardHolderNameOnChange$Action, callContext);

};
Controller.prototype.datatransCardOnChangeCleanErrorMsg$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._datatransCardOnChangeCleanErrorMsg$Action, callContext);

};
Controller.prototype.datatransCardOnSuccess$Action = function (transactionIdIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._datatransCardOnSuccess$Action, callContext, transactionIdIn);

};
Controller.prototype.datatransCardOnReady$Action = function (objIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._datatransCardOnReady$Action, callContext, objIn);

};
Controller.prototype.cardSubmitted$Action = function () {
return Promise.resolve();
};
Controller.prototype.updateParameters$Action = function () {
return Promise.resolve();
};
Controller.prototype.errorRequestingRefund$Action = function () {
return Promise.resolve();
};
Controller.prototype.errorSavingCard$Action = function () {
return Promise.resolve();
};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:WLZg9jO0M0aiRlyqBkvkgg:/NRWebFlows.WLZg9jO0M0aiRlyqBkvkgg:eI2Gsuu43vLy9LWSnrwTXg", "ShopperPortalEU", "InternalComponents", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:JUNflh5ghUigHFDKthBfoA:/NRWebFlows.WLZg9jO0M0aiRlyqBkvkgg/NodesShownInESpaceTree.JUNflh5ghUigHFDKthBfoA:WKPpe6gRXtQANI_gadiSNA", "ShopperPortalEU", "DatatransTokenization_WB", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:JUNflh5ghUigHFDKthBfoA", callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:WLZg9jO0M0aiRlyqBkvkgg", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "InternalComponents/DatatransTokenization_WB On Parameters Changed");
return controller.onParametersChanged$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return ShopperPortalEUController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, ShopperPortalEULanguageResources);
});

define("ShopperPortalEU.InternalComponents.DatatransTokenization_WB.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"fsAI7Y8Rr0OFxR2osAnSbw": {
getter: function (varBag, idService) {
return varBag.vars.value.cardInfoInLocal;
}
},
"+gWfNPodVkmYOWlsaxsc9w": {
getter: function (varBag, idService) {
return varBag.vars.value.errorMessageInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"hUYmqx33VEafYfSYnBI+UA": {
getter: function (varBag, idService) {
return varBag.vars.value.cardHolderNameTempVar;
},
dataType: OS.DataTypes.DataTypes.Text
},
"8Sk0J9r7JkacqwWNONAo+w": {
getter: function (varBag, idService) {
return varBag.vars.value.bypassTokenVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"pe+lwRcJ1kuw1AuY15guWQ": {
getter: function (varBag, idService) {
return varBag.vars.value.transactionIdInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"eEM5SlfBI02R3nflMKFs6g": {
getter: function (varBag, idService) {
return varBag.createCardVar.value;
}
},
"WH0tcE6dZE2CjlFwVNi7qw": {
getter: function (varBag, idService) {
return varBag.formListRequestRefundVar.value;
}
},
"sHsbr76ojEOR8+xXcQfnDw": {
getter: function (varBag, idService) {
return varBag.getShopperVar.value;
}
},
"1fzdPtlL_kykDsJ1UV+yKQ": {
getter: function (varBag, idService) {
return varBag.vars.value.objInLocal;
},
dataType: OS.DataTypes.DataTypes.Object
},
"dCVcRtWhA0ic4wopONA3mg": {
getter: function (varBag, idService) {
return varBag.model.variables.datatransObjectVar;
},
dataType: OS.DataTypes.DataTypes.Object
},
"PhMmZUqFoUajVz0SAF_4mQ": {
getter: function (varBag, idService) {
return varBag.model.variables.transactionVar;
},
dataType: OS.DataTypes.DataTypes.Text
},
"9dkcj8Tyvk68uSQ7y40kWg": {
getter: function (varBag, idService) {
return varBag.model.variables.cardHoldersNameVar;
},
dataType: OS.DataTypes.DataTypes.Text
},
"BhE0VzuM1EeH4xljYlA0tw": {
getter: function (varBag, idService) {
return varBag.model.variables.isFromAddCardScreenIn;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"BDu9jWm6Lk6rqCTTBvB6XQ": {
getter: function (varBag, idService) {
return varBag.model.variables.isToSubmitCardIn;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"3ZmjST4kXEO0vrCDDmqiow": {
getter: function (varBag, idService) {
return varBag.model.variables.isDefaultCardIn;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"6+UkrxOZSk2isv5zYWGsyg": {
getter: function (varBag, idService) {
return varBag.model.variables.merchantIdIn;
},
dataType: OS.DataTypes.DataTypes.Text
},
"A7JHuuv0j0WM5F2wmyi3jQ": {
getter: function (varBag, idService) {
return varBag.model.variables.cardDetailsDataIn;
}
},
"AyRqpdbJfk2BtGNLdhwi1g": {
getter: function (varBag, idService) {
return varBag.model.variables.cardErrorMessageIn;
},
dataType: OS.DataTypes.DataTypes.Text
},
"+vf5BahackedF2Y4qEisUg": {
getter: function (varBag, idService) {
return varBag.model.variables.isExpiryDateErrorIn;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"MuohCrk3Vk+3mqeq7+KkBA": {
getter: function (varBag, idService) {
return varBag.model.variables.formsList_ReadyForRefundIn;
}
},
"c1Ij2GLFzU2PfW2SD_xTuw": {
getter: function (varBag, idService) {
return varBag.model.variables.tokenFallbackIn;
}
},
"P+uld9OIUkW7EpOHUIuU7A": {
getter: function (varBag, idService) {
return varBag.model.variables.isToSaveNewCardIn;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"y9ul3GVZREW3kp8hF6P+lg": {
getter: function (varBag, idService) {
return varBag.model.variables.cardIn;
},
dataType: OS.DataTypes.DataTypes.Text
},
"c9vhpCSRDkudBTv1PD6sGg": {
getter: function (varBag, idService) {
return varBag.model.variables.isFromFormDetailsScreenIn;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"sQKGHGHGgE6lN4hj_TsUoA": {
getter: function (varBag, idService) {
return varBag.model.variables.getDataDataAct;
}
},
"DNd_k5WCekCuNR1kfSWnVw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Label"));
})(varBag.model, idService);
}
},
"AaHOgyvIhUqDgVHRC3QFEg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input"));
})(varBag.model, idService);
}
},
"qZHzdRurqkO6aY0cmgp_HA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input_CardHolderName"));
})(varBag.model, idService);
}
},
"Pmz0pZeMKkCZkZTiy3rFng": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Description"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
