class customSwitch {
  constructor(id, options) {
    this.class = 'custom-switch';
    this.element = document.getElementById(id);
    this.elements = {
      switch: null,
      label: null
    };
    this.stateClasses = {
      notValid: this.class.concat('--not-valid'),
      disabled: this.class.concat('--disabled'),
      checked: this.class.concat('--checked')
    };
    this.options = options;
  }
  _switchAttributes() {
    if (this.elements.switch) {
      this.elements.switch.checked ? this.element.classList.add(this.stateClasses.checked) : this.element.classList.remove(this.stateClasses.checked);
      this.elements.switch.disabled ? this.element.classList.add(this.stateClasses.disabled) : this.element.classList.remove(this.stateClasses.disabled);
      this.elements.switch.classList.contains('not-valid') ? this.element.classList.add(this.stateClasses.notValid) : this.element.classList.remove(this.stateClasses.notValid);
      if (this.options.testId) {
        this.elements.switch.setAttribute('data-testid', this.options.testId.concat('Switch'));
        if (this.elements.label) {
          this.elements.label.setAttribute('data-testid', this.options.testId.concat('Label'));
        }
      } else {
        this.elements.switch.removeAttribute('data-testid');
        if (this.elements.label) {
          this.elements.label.removeAttribute('data-testid');
        }
      }
    }
  }
  _setElements() {
    this.elements.switch = this.element.firstElementChild.getElementsByClassName('switch')[0];
    this.elements.label = this.element.lastElementChild.getElementsByTagName('label')[0];
  }
  render() {
    this._setElements();
    this._switchAttributes();
  }
  parametersChanged(options) {
    this.options = options;
  }
}