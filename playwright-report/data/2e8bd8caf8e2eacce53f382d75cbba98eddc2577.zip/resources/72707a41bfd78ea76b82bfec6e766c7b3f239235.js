define("ShopperPortalEU_UI_Theme.model$LayoutHeaderOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var LayoutHeaderOptionsRec = (function (_super) {
__extends(LayoutHeaderOptionsRec, _super);
function LayoutHeaderOptionsRec(defaults) {
_super.apply(this, arguments);
}
LayoutHeaderOptionsRec.attributesToDeclare = function () {
return [
this.attr("IsCentered", "isCenteredAttr", "centered", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
LayoutHeaderOptionsRec.fromStructure = function (str) {
return new LayoutHeaderOptionsRec(new LayoutHeaderOptionsRec.RecordClass({
isCenteredAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
LayoutHeaderOptionsRec.init();
return LayoutHeaderOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ThemeModel.LayoutHeaderOptionsRec = LayoutHeaderOptionsRec;

});
define("ShopperPortalEU_UI_Theme.model$LayoutOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$LayoutHeaderOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var LayoutOptionsRec = (function (_super) {
__extends(LayoutOptionsRec, _super);
function LayoutOptionsRec(defaults) {
_super.apply(this, arguments);
}
LayoutOptionsRec.attributesToDeclare = function () {
return [
this.attr("DarkMode", "darkModeAttr", "darkMode", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("Header", "headerAttr", "header", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ThemeModel.LayoutHeaderOptionsRec());
}, true, ShopperPortalEU_UI_ThemeModel.LayoutHeaderOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
LayoutOptionsRec.init();
return LayoutOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ThemeModel.LayoutOptionsRec = LayoutOptionsRec;

});
define("ShopperPortalEU_UI_Theme.model$LayoutOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$LayoutOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var LayoutOptionsRecord = (function (_super) {
__extends(LayoutOptionsRecord, _super);
function LayoutOptionsRecord(defaults) {
_super.apply(this, arguments);
}
LayoutOptionsRecord.attributesToDeclare = function () {
return [
this.attr("LayoutOptions", "layoutOptionsAttr", "LayoutOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ThemeModel.LayoutOptionsRec());
}, true, ShopperPortalEU_UI_ThemeModel.LayoutOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
LayoutOptionsRecord.fromStructure = function (str) {
return new LayoutOptionsRecord(new LayoutOptionsRecord.RecordClass({
layoutOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
LayoutOptionsRecord._isAnonymousRecord = true;
LayoutOptionsRecord.UniqueId = "07362bcd-ed8f-6d3b-4659-f4beee778163";
LayoutOptionsRecord.init();
return LayoutOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ThemeModel.LayoutOptionsRecord = LayoutOptionsRecord;

});
define("ShopperPortalEU_UI_Theme.model$LoginOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var LoginOptionsRec = (function (_super) {
__extends(LoginOptionsRec, _super);
function LoginOptionsRec(defaults) {
_super.apply(this, arguments);
}
LoginOptionsRec.attributesToDeclare = function () {
return [
this.attr("BackgroundURL", "backgroundURLAttr", "backgroundURL", false, false, OS.DataTypes.DataTypes.Text, function () {
return "/ShopperPortalEU_UI_Theme/img/ShopperPortalEU_UI_Theme.login_background.png";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
LoginOptionsRec.fromStructure = function (str) {
return new LoginOptionsRec(new LoginOptionsRec.RecordClass({
backgroundURLAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
LoginOptionsRec.init();
return LoginOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ThemeModel.LoginOptionsRec = LoginOptionsRec;

});
define("ShopperPortalEU_UI_Theme.model$LoginOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$LoginOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var LoginOptionsRecord = (function (_super) {
__extends(LoginOptionsRecord, _super);
function LoginOptionsRecord(defaults) {
_super.apply(this, arguments);
}
LoginOptionsRecord.attributesToDeclare = function () {
return [
this.attr("LoginOptions", "loginOptionsAttr", "LoginOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ThemeModel.LoginOptionsRec());
}, true, ShopperPortalEU_UI_ThemeModel.LoginOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
LoginOptionsRecord.fromStructure = function (str) {
return new LoginOptionsRecord(new LoginOptionsRecord.RecordClass({
loginOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
LoginOptionsRecord._isAnonymousRecord = true;
LoginOptionsRecord.UniqueId = "73bf135b-8221-5e22-5ac6-9f0e87748f9a";
LoginOptionsRecord.init();
return LoginOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ThemeModel.LoginOptionsRecord = LoginOptionsRecord;

});
define("ShopperPortalEU_UI_Theme.model$LoginOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$LoginOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var LoginOptionsRecordList = (function (_super) {
__extends(LoginOptionsRecordList, _super);
function LoginOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
LoginOptionsRecordList.itemType = ShopperPortalEU_UI_ThemeModel.LoginOptionsRecord;
return LoginOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.LoginOptionsRecordList = LoginOptionsRecordList;

});
define("ShopperPortalEU_UI_Theme.model$HeaderActionItemIconOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var HeaderActionItemIconOptionsRec = (function (_super) {
__extends(HeaderActionItemIconOptionsRec, _super);
function HeaderActionItemIconOptionsRec(defaults) {
_super.apply(this, arguments);
}
HeaderActionItemIconOptionsRec.attributesToDeclare = function () {
return [
this.attr("Name", "nameAttr", "name", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("IsFilled", "isFilledAttr", "filled", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
HeaderActionItemIconOptionsRec.init();
return HeaderActionItemIconOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ThemeModel.HeaderActionItemIconOptionsRec = HeaderActionItemIconOptionsRec;

});
define("ShopperPortalEU_UI_Theme.model$HeaderActionItemIconOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$HeaderActionItemIconOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var HeaderActionItemIconOptionsRecord = (function (_super) {
__extends(HeaderActionItemIconOptionsRecord, _super);
function HeaderActionItemIconOptionsRecord(defaults) {
_super.apply(this, arguments);
}
HeaderActionItemIconOptionsRecord.attributesToDeclare = function () {
return [
this.attr("HeaderActionItemIconOptions", "headerActionItemIconOptionsAttr", "HeaderActionItemIconOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ThemeModel.HeaderActionItemIconOptionsRec());
}, true, ShopperPortalEU_UI_ThemeModel.HeaderActionItemIconOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
HeaderActionItemIconOptionsRecord.fromStructure = function (str) {
return new HeaderActionItemIconOptionsRecord(new HeaderActionItemIconOptionsRecord.RecordClass({
headerActionItemIconOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
HeaderActionItemIconOptionsRecord._isAnonymousRecord = true;
HeaderActionItemIconOptionsRecord.UniqueId = "9eef586a-beba-296c-63b9-4c28ac393f32";
HeaderActionItemIconOptionsRecord.init();
return HeaderActionItemIconOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ThemeModel.HeaderActionItemIconOptionsRecord = HeaderActionItemIconOptionsRecord;

});
define("ShopperPortalEU_UI_Theme.model$HeaderActionItemIconOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$HeaderActionItemIconOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var HeaderActionItemIconOptionsRecordList = (function (_super) {
__extends(HeaderActionItemIconOptionsRecordList, _super);
function HeaderActionItemIconOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
HeaderActionItemIconOptionsRecordList.itemType = ShopperPortalEU_UI_ThemeModel.HeaderActionItemIconOptionsRecord;
return HeaderActionItemIconOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.HeaderActionItemIconOptionsRecordList = HeaderActionItemIconOptionsRecordList;

});
define("ShopperPortalEU_UI_Theme.model$CustomMessageTypeRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var CustomMessageTypeRec = (function (_super) {
__extends(CustomMessageTypeRec, _super);
function CustomMessageTypeRec(defaults) {
_super.apply(this, arguments);
}
CustomMessageTypeRec.attributesToDeclare = function () {
return [
this.attr("Class", "classAttr", "Class", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomMessageTypeRec.fromStructure = function (str) {
return new CustomMessageTypeRec(new CustomMessageTypeRec.RecordClass({
classAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomMessageTypeRec.init();
return CustomMessageTypeRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ThemeModel.CustomMessageTypeRec = CustomMessageTypeRec;

});
define("ShopperPortalEU_UI_Theme.model$CustomMessageTypeList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$CustomMessageTypeRec"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var CustomMessageTypeList = (function (_super) {
__extends(CustomMessageTypeList, _super);
function CustomMessageTypeList(defaults) {
_super.apply(this, arguments);
}
CustomMessageTypeList.itemType = ShopperPortalEU_UI_ThemeModel.CustomMessageTypeRec;
return CustomMessageTypeList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.CustomMessageTypeList = CustomMessageTypeList;

});
define("ShopperPortalEU_UI_Theme.model$CustomMessageIconOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var CustomMessageIconOptionsRec = (function (_super) {
__extends(CustomMessageIconOptionsRec, _super);
function CustomMessageIconOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomMessageIconOptionsRec.attributesToDeclare = function () {
return [
this.attr("Name", "nameAttr", "name", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Family", "familyAttr", "family", false, false, OS.DataTypes.DataTypes.Text, function () {
return ShopperPortalEU_UI_ThemeModel.staticEntities.customIconFamily.material;
}, true), 
this.attr("IsFilled", "isFilledAttr", "filled", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomMessageIconOptionsRec.init();
return CustomMessageIconOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ThemeModel.CustomMessageIconOptionsRec = CustomMessageIconOptionsRec;

});
define("ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$CustomMessageIconOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var CustomMessageOptionsRec = (function (_super) {
__extends(CustomMessageOptionsRec, _super);
function CustomMessageOptionsRec(defaults) {
_super.apply(this, arguments);
}
CustomMessageOptionsRec.attributesToDeclare = function () {
return [
this.attr("Type", "typeAttr", "type", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Title", "titleAttr", "title", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Content", "contentAttr", "content", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Icon", "iconAttr", "icon", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ThemeModel.CustomMessageIconOptionsRec());
}, true, ShopperPortalEU_UI_ThemeModel.CustomMessageIconOptionsRec), 
this.attr("AutoHide", "autoHideAttr", "autoHide", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return true;
}, true), 
this.attr("TestId", "testIdAttr", "testId", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("CloseClarityEvent", "closeClarityEventAttr", "closeClarityEvent", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomMessageOptionsRec.init();
return CustomMessageOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec = CustomMessageOptionsRec;

});
define("ShopperPortalEU_UI_Theme.model$CustomMessageOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var CustomMessageOptionsList = (function (_super) {
__extends(CustomMessageOptionsList, _super);
function CustomMessageOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomMessageOptionsList.itemType = ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec;
return CustomMessageOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsList = CustomMessageOptionsList;

});
define("ShopperPortalEU_UI_Theme.model$CustomIconSizeRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.model$CustomIconSizeRec", "ShopperPortalEU_UI_Theme.referencesHealth", "ShopperPortalEU_UI_Theme.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var CustomIconSizeRecord = (function (_super) {
__extends(CustomIconSizeRecord, _super);
function CustomIconSizeRecord(defaults) {
_super.apply(this, arguments);
}
CustomIconSizeRecord.attributesToDeclare = function () {
return [
this.attr("CustomIconSize", "customIconSizeAttr", "CustomIconSize", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomIconSizeRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomIconSizeRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomIconSizeRecord.fromStructure = function (str) {
return new CustomIconSizeRecord(new CustomIconSizeRecord.RecordClass({
customIconSizeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomIconSizeRecord._isAnonymousRecord = true;
CustomIconSizeRecord.UniqueId = "1471df4f-b04a-f4b0-9793-30bd82154efb";
CustomIconSizeRecord.init();
return CustomIconSizeRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ThemeModel.CustomIconSizeRecord = CustomIconSizeRecord;

});
define("ShopperPortalEU_UI_Theme.model$CustomIconSizeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$CustomIconSizeRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var CustomIconSizeRecordList = (function (_super) {
__extends(CustomIconSizeRecordList, _super);
function CustomIconSizeRecordList(defaults) {
_super.apply(this, arguments);
}
CustomIconSizeRecordList.itemType = ShopperPortalEU_UI_ThemeModel.CustomIconSizeRecord;
return CustomIconSizeRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.CustomIconSizeRecordList = CustomIconSizeRecordList;

});
define("ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var HeaderStepsOptionsRec = (function (_super) {
__extends(HeaderStepsOptionsRec, _super);
function HeaderStepsOptionsRec(defaults) {
_super.apply(this, arguments);
}
HeaderStepsOptionsRec.attributesToDeclare = function () {
return [
this.attr("Steps", "stepsAttr", "steps", false, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true), 
this.attr("CurrentStep", "currentStepAttr", "currentStep", false, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
HeaderStepsOptionsRec.init();
return HeaderStepsOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ThemeModel.HeaderStepsOptionsRec = HeaderStepsOptionsRec;

});
define("ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var HeaderStepsOptionsRecord = (function (_super) {
__extends(HeaderStepsOptionsRecord, _super);
function HeaderStepsOptionsRecord(defaults) {
_super.apply(this, arguments);
}
HeaderStepsOptionsRecord.attributesToDeclare = function () {
return [
this.attr("HeaderStepsOptions", "headerStepsOptionsAttr", "HeaderStepsOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ThemeModel.HeaderStepsOptionsRec());
}, true, ShopperPortalEU_UI_ThemeModel.HeaderStepsOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
HeaderStepsOptionsRecord.fromStructure = function (str) {
return new HeaderStepsOptionsRecord(new HeaderStepsOptionsRecord.RecordClass({
headerStepsOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
HeaderStepsOptionsRecord._isAnonymousRecord = true;
HeaderStepsOptionsRecord.UniqueId = "150a9fd7-7cab-7ac0-9581-6aab3545241e";
HeaderStepsOptionsRecord.init();
return HeaderStepsOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ThemeModel.HeaderStepsOptionsRecord = HeaderStepsOptionsRecord;

});
define("ShopperPortalEU_UI_Theme.model$BottomBarOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var BottomBarOptionsRec = (function (_super) {
__extends(BottomBarOptionsRec, _super);
function BottomBarOptionsRec(defaults) {
_super.apply(this, arguments);
}
BottomBarOptionsRec.attributesToDeclare = function () {
return [
this.attr("Active", "activeAttr", "active", false, false, OS.DataTypes.DataTypes.Integer, function () {
return -1;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
BottomBarOptionsRec.fromStructure = function (str) {
return new BottomBarOptionsRec(new BottomBarOptionsRec.RecordClass({
activeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
BottomBarOptionsRec.init();
return BottomBarOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ThemeModel.BottomBarOptionsRec = BottomBarOptionsRec;

});
define("ShopperPortalEU_UI_Theme.model$BottomBarOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$BottomBarOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var BottomBarOptionsRecord = (function (_super) {
__extends(BottomBarOptionsRecord, _super);
function BottomBarOptionsRecord(defaults) {
_super.apply(this, arguments);
}
BottomBarOptionsRecord.attributesToDeclare = function () {
return [
this.attr("BottomBarOptions", "bottomBarOptionsAttr", "BottomBarOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ThemeModel.BottomBarOptionsRec());
}, true, ShopperPortalEU_UI_ThemeModel.BottomBarOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
BottomBarOptionsRecord.fromStructure = function (str) {
return new BottomBarOptionsRecord(new BottomBarOptionsRecord.RecordClass({
bottomBarOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
BottomBarOptionsRecord._isAnonymousRecord = true;
BottomBarOptionsRecord.UniqueId = "15becd11-9084-74a7-71df-8bee809ad738";
BottomBarOptionsRecord.init();
return BottomBarOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ThemeModel.BottomBarOptionsRecord = BottomBarOptionsRecord;

});
define("ShopperPortalEU_UI_Theme.model$MenuItemIconOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var MenuItemIconOptionsRec = (function (_super) {
__extends(MenuItemIconOptionsRec, _super);
function MenuItemIconOptionsRec(defaults) {
_super.apply(this, arguments);
}
MenuItemIconOptionsRec.attributesToDeclare = function () {
return [
this.attr("Name", "nameAttr", "name", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Family", "familyAttr", "family", false, false, OS.DataTypes.DataTypes.Text, function () {
return ShopperPortalEU_UI_ThemeModel.staticEntities.customIconFamily.material;
}, true), 
this.attr("IsFilled", "isFilledAttr", "filled", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("RightAligned", "rightAlignedAttr", "False", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
MenuItemIconOptionsRec.init();
return MenuItemIconOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ThemeModel.MenuItemIconOptionsRec = MenuItemIconOptionsRec;

});
define("ShopperPortalEU_UI_Theme.model$MenuItemIconOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$MenuItemIconOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var MenuItemIconOptionsRecord = (function (_super) {
__extends(MenuItemIconOptionsRecord, _super);
function MenuItemIconOptionsRecord(defaults) {
_super.apply(this, arguments);
}
MenuItemIconOptionsRecord.attributesToDeclare = function () {
return [
this.attr("MenuItemIconOptions", "menuItemIconOptionsAttr", "MenuItemIconOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ThemeModel.MenuItemIconOptionsRec());
}, true, ShopperPortalEU_UI_ThemeModel.MenuItemIconOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
MenuItemIconOptionsRecord.fromStructure = function (str) {
return new MenuItemIconOptionsRecord(new MenuItemIconOptionsRecord.RecordClass({
menuItemIconOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
MenuItemIconOptionsRecord._isAnonymousRecord = true;
MenuItemIconOptionsRecord.UniqueId = "58e2bc41-b1ec-b696-790a-f08f8ffc2182";
MenuItemIconOptionsRecord.init();
return MenuItemIconOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ThemeModel.MenuItemIconOptionsRecord = MenuItemIconOptionsRecord;

});
define("ShopperPortalEU_UI_Theme.model$MenuItemIconOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$MenuItemIconOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var MenuItemIconOptionsRecordList = (function (_super) {
__extends(MenuItemIconOptionsRecordList, _super);
function MenuItemIconOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
MenuItemIconOptionsRecordList.itemType = ShopperPortalEU_UI_ThemeModel.MenuItemIconOptionsRecord;
return MenuItemIconOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.MenuItemIconOptionsRecordList = MenuItemIconOptionsRecordList;

});
define("ShopperPortalEU_UI_Theme.model$CustomIconOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.model$CustomIconOptionsRec", "ShopperPortalEU_UI_Theme.referencesHealth", "ShopperPortalEU_UI_Theme.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var CustomIconOptionsRecord = (function (_super) {
__extends(CustomIconOptionsRecord, _super);
function CustomIconOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomIconOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomIconOptions", "customIconOptionsAttr", "CustomIconOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomIconOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomIconOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomIconOptionsRecord.fromStructure = function (str) {
return new CustomIconOptionsRecord(new CustomIconOptionsRecord.RecordClass({
customIconOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomIconOptionsRecord._isAnonymousRecord = true;
CustomIconOptionsRecord.UniqueId = "ec3a9701-ff9a-7eb1-9cc0-07d487764911";
CustomIconOptionsRecord.init();
return CustomIconOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ThemeModel.CustomIconOptionsRecord = CustomIconOptionsRecord;

});
define("ShopperPortalEU_UI_Theme.model$CustomIconOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$CustomIconOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var CustomIconOptionsRecordList = (function (_super) {
__extends(CustomIconOptionsRecordList, _super);
function CustomIconOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomIconOptionsRecordList.itemType = ShopperPortalEU_UI_ThemeModel.CustomIconOptionsRecord;
return CustomIconOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.CustomIconOptionsRecordList = CustomIconOptionsRecordList;

});
define("ShopperPortalEU_UI_Theme.model$HeaderActionOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var HeaderActionOptionsRec = (function (_super) {
__extends(HeaderActionOptionsRec, _super);
function HeaderActionOptionsRec(defaults) {
_super.apply(this, arguments);
}
HeaderActionOptionsRec.attributesToDeclare = function () {
return [
this.attr("HasAlert", "hasAlertAttr", "hasAlert", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("TestId", "testIdAttr", "testId", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
HeaderActionOptionsRec.init();
return HeaderActionOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ThemeModel.HeaderActionOptionsRec = HeaderActionOptionsRec;

});
define("ShopperPortalEU_UI_Theme.model$HeaderActionOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$HeaderActionOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var HeaderActionOptionsList = (function (_super) {
__extends(HeaderActionOptionsList, _super);
function HeaderActionOptionsList(defaults) {
_super.apply(this, arguments);
}
HeaderActionOptionsList.itemType = ShopperPortalEU_UI_ThemeModel.HeaderActionOptionsRec;
return HeaderActionOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.HeaderActionOptionsList = HeaderActionOptionsList;

});
define("ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var HeaderStepsOptionsList = (function (_super) {
__extends(HeaderStepsOptionsList, _super);
function HeaderStepsOptionsList(defaults) {
_super.apply(this, arguments);
}
HeaderStepsOptionsList.itemType = ShopperPortalEU_UI_ThemeModel.HeaderStepsOptionsRec;
return HeaderStepsOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.HeaderStepsOptionsList = HeaderStepsOptionsList;

});
define("ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var HeaderStepsOptionsRecordList = (function (_super) {
__extends(HeaderStepsOptionsRecordList, _super);
function HeaderStepsOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
HeaderStepsOptionsRecordList.itemType = ShopperPortalEU_UI_ThemeModel.HeaderStepsOptionsRecord;
return HeaderStepsOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.HeaderStepsOptionsRecordList = HeaderStepsOptionsRecordList;

});
define("ShopperPortalEU_UI_Theme.model$LayoutHeaderOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$LayoutHeaderOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var LayoutHeaderOptionsList = (function (_super) {
__extends(LayoutHeaderOptionsList, _super);
function LayoutHeaderOptionsList(defaults) {
_super.apply(this, arguments);
}
LayoutHeaderOptionsList.itemType = ShopperPortalEU_UI_ThemeModel.LayoutHeaderOptionsRec;
return LayoutHeaderOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.LayoutHeaderOptionsList = LayoutHeaderOptionsList;

});
define("ShopperPortalEU_UI_Theme.model$LayoutBlankOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var LayoutBlankOptionsRec = (function (_super) {
__extends(LayoutBlankOptionsRec, _super);
function LayoutBlankOptionsRec(defaults) {
_super.apply(this, arguments);
}
LayoutBlankOptionsRec.attributesToDeclare = function () {
return [
this.attr("NoPadding", "noPaddingAttr", "noPadding", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("DarkMode", "darkModeAttr", "darkMode", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("DarkerBackground", "darkerBackgroundAttr", "darkerBackground", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("FullWidth", "fullWidthAttr", "fullWidth", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
LayoutBlankOptionsRec.init();
return LayoutBlankOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ThemeModel.LayoutBlankOptionsRec = LayoutBlankOptionsRec;

});
define("ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var CustomMessageOptionsRecord = (function (_super) {
__extends(CustomMessageOptionsRecord, _super);
function CustomMessageOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomMessageOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomMessageOptions", "customMessageOptionsAttr", "CustomMessageOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec());
}, true, ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomMessageOptionsRecord.fromStructure = function (str) {
return new CustomMessageOptionsRecord(new CustomMessageOptionsRecord.RecordClass({
customMessageOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomMessageOptionsRecord._isAnonymousRecord = true;
CustomMessageOptionsRecord.UniqueId = "82198c5f-6a28-d6f8-f60f-f53ae31dbc72";
CustomMessageOptionsRecord.init();
return CustomMessageOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRecord = CustomMessageOptionsRecord;

});
define("ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var CustomMessageOptionsRecordList = (function (_super) {
__extends(CustomMessageOptionsRecordList, _super);
function CustomMessageOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomMessageOptionsRecordList.itemType = ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRecord;
return CustomMessageOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRecordList = CustomMessageOptionsRecordList;

});
define("ShopperPortalEU_UI_Theme.model$HeaderActionOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$HeaderActionOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var HeaderActionOptionsRecord = (function (_super) {
__extends(HeaderActionOptionsRecord, _super);
function HeaderActionOptionsRecord(defaults) {
_super.apply(this, arguments);
}
HeaderActionOptionsRecord.attributesToDeclare = function () {
return [
this.attr("HeaderActionOptions", "headerActionOptionsAttr", "HeaderActionOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ThemeModel.HeaderActionOptionsRec());
}, true, ShopperPortalEU_UI_ThemeModel.HeaderActionOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
HeaderActionOptionsRecord.fromStructure = function (str) {
return new HeaderActionOptionsRecord(new HeaderActionOptionsRecord.RecordClass({
headerActionOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
HeaderActionOptionsRecord._isAnonymousRecord = true;
HeaderActionOptionsRecord.UniqueId = "42291f82-e54f-123c-b29c-4e8f8804ecf6";
HeaderActionOptionsRecord.init();
return HeaderActionOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ThemeModel.HeaderActionOptionsRecord = HeaderActionOptionsRecord;

});
define("ShopperPortalEU_UI_Theme.model$ApplicationHeaderOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var ApplicationHeaderOptionsRec = (function (_super) {
__extends(ApplicationHeaderOptionsRec, _super);
function ApplicationHeaderOptionsRec(defaults) {
_super.apply(this, arguments);
}
ApplicationHeaderOptionsRec.attributesToDeclare = function () {
return [
this.attr("ShowLogoOnScroll", "showLogoOnScrollAttr", "showLogoOnScroll", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ApplicationHeaderOptionsRec.fromStructure = function (str) {
return new ApplicationHeaderOptionsRec(new ApplicationHeaderOptionsRec.RecordClass({
showLogoOnScrollAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ApplicationHeaderOptionsRec.init();
return ApplicationHeaderOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ThemeModel.ApplicationHeaderOptionsRec = ApplicationHeaderOptionsRec;

});
define("ShopperPortalEU_UI_Theme.model$ApplicationHeaderOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$ApplicationHeaderOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var ApplicationHeaderOptionsRecord = (function (_super) {
__extends(ApplicationHeaderOptionsRecord, _super);
function ApplicationHeaderOptionsRecord(defaults) {
_super.apply(this, arguments);
}
ApplicationHeaderOptionsRecord.attributesToDeclare = function () {
return [
this.attr("ApplicationHeaderOptions", "applicationHeaderOptionsAttr", "ApplicationHeaderOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ThemeModel.ApplicationHeaderOptionsRec());
}, true, ShopperPortalEU_UI_ThemeModel.ApplicationHeaderOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
ApplicationHeaderOptionsRecord.fromStructure = function (str) {
return new ApplicationHeaderOptionsRecord(new ApplicationHeaderOptionsRecord.RecordClass({
applicationHeaderOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ApplicationHeaderOptionsRecord._isAnonymousRecord = true;
ApplicationHeaderOptionsRecord.UniqueId = "9c3867d1-8601-1237-9093-e41be169d805";
ApplicationHeaderOptionsRecord.init();
return ApplicationHeaderOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ThemeModel.ApplicationHeaderOptionsRecord = ApplicationHeaderOptionsRecord;

});
define("ShopperPortalEU_UI_Theme.model$ApplicationHeaderOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$ApplicationHeaderOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var ApplicationHeaderOptionsRecordList = (function (_super) {
__extends(ApplicationHeaderOptionsRecordList, _super);
function ApplicationHeaderOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
ApplicationHeaderOptionsRecordList.itemType = ShopperPortalEU_UI_ThemeModel.ApplicationHeaderOptionsRecord;
return ApplicationHeaderOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.ApplicationHeaderOptionsRecordList = ApplicationHeaderOptionsRecordList;

});
define("ShopperPortalEU_UI_Theme.model$MenuItemOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$MenuItemIconOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var MenuItemOptionsRec = (function (_super) {
__extends(MenuItemOptionsRec, _super);
function MenuItemOptionsRec(defaults) {
_super.apply(this, arguments);
}
MenuItemOptionsRec.attributesToDeclare = function () {
return [
this.attr("Icon", "iconAttr", "icon", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ThemeModel.MenuItemIconOptionsRec());
}, true, ShopperPortalEU_UI_ThemeModel.MenuItemIconOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
MenuItemOptionsRec.fromStructure = function (str) {
return new MenuItemOptionsRec(new MenuItemOptionsRec.RecordClass({
iconAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
MenuItemOptionsRec.init();
return MenuItemOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ThemeModel.MenuItemOptionsRec = MenuItemOptionsRec;

});
define("ShopperPortalEU_UI_Theme.model$CustomMessageIconOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$CustomMessageIconOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var CustomMessageIconOptionsList = (function (_super) {
__extends(CustomMessageIconOptionsList, _super);
function CustomMessageIconOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomMessageIconOptionsList.itemType = ShopperPortalEU_UI_ThemeModel.CustomMessageIconOptionsRec;
return CustomMessageIconOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.CustomMessageIconOptionsList = CustomMessageIconOptionsList;

});
define("ShopperPortalEU_UI_Theme.model$HeaderActionItemOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$HeaderActionItemIconOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var HeaderActionItemOptionsRec = (function (_super) {
__extends(HeaderActionItemOptionsRec, _super);
function HeaderActionItemOptionsRec(defaults) {
_super.apply(this, arguments);
}
HeaderActionItemOptionsRec.attributesToDeclare = function () {
return [
this.attr("Icon", "iconAttr", "icon", true, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ThemeModel.HeaderActionItemIconOptionsRec());
}, true, ShopperPortalEU_UI_ThemeModel.HeaderActionItemIconOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
HeaderActionItemOptionsRec.fromStructure = function (str) {
return new HeaderActionItemOptionsRec(new HeaderActionItemOptionsRec.RecordClass({
iconAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
HeaderActionItemOptionsRec.init();
return HeaderActionItemOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ThemeModel.HeaderActionItemOptionsRec = HeaderActionItemOptionsRec;

});
define("ShopperPortalEU_UI_Theme.model$HeaderActionItemOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$HeaderActionItemOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var HeaderActionItemOptionsList = (function (_super) {
__extends(HeaderActionItemOptionsList, _super);
function HeaderActionItemOptionsList(defaults) {
_super.apply(this, arguments);
}
HeaderActionItemOptionsList.itemType = ShopperPortalEU_UI_ThemeModel.HeaderActionItemOptionsRec;
return HeaderActionItemOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.HeaderActionItemOptionsList = HeaderActionItemOptionsList;

});
define("ShopperPortalEU_UI_Theme.model$CustomIconFamilyList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.model$CustomIconFamilyRec", "ShopperPortalEU_UI_Theme.referencesHealth", "ShopperPortalEU_UI_Theme.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var CustomIconFamilyList = (function (_super) {
__extends(CustomIconFamilyList, _super);
function CustomIconFamilyList(defaults) {
_super.apply(this, arguments);
}
CustomIconFamilyList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomIconFamilyRec;
return CustomIconFamilyList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.CustomIconFamilyList = CustomIconFamilyList;

});
define("ShopperPortalEU_UI_Theme.model$CustomMessageTypeRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$CustomMessageTypeRec"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var CustomMessageTypeRecord = (function (_super) {
__extends(CustomMessageTypeRecord, _super);
function CustomMessageTypeRecord(defaults) {
_super.apply(this, arguments);
}
CustomMessageTypeRecord.attributesToDeclare = function () {
return [
this.attr("CustomMessageType", "customMessageTypeAttr", "CustomMessageType", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ThemeModel.CustomMessageTypeRec());
}, true, ShopperPortalEU_UI_ThemeModel.CustomMessageTypeRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomMessageTypeRecord.fromStructure = function (str) {
return new CustomMessageTypeRecord(new CustomMessageTypeRecord.RecordClass({
customMessageTypeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomMessageTypeRecord._isAnonymousRecord = true;
CustomMessageTypeRecord.UniqueId = "7e1373d8-7d9c-3134-5433-e8112f618f5c";
CustomMessageTypeRecord.init();
return CustomMessageTypeRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ThemeModel.CustomMessageTypeRecord = CustomMessageTypeRecord;

});
define("ShopperPortalEU_UI_Theme.model$CustomMessageTypeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$CustomMessageTypeRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var CustomMessageTypeRecordList = (function (_super) {
__extends(CustomMessageTypeRecordList, _super);
function CustomMessageTypeRecordList(defaults) {
_super.apply(this, arguments);
}
CustomMessageTypeRecordList.itemType = ShopperPortalEU_UI_ThemeModel.CustomMessageTypeRecord;
return CustomMessageTypeRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.CustomMessageTypeRecordList = CustomMessageTypeRecordList;

});
define("ShopperPortalEU_UI_Theme.model$LayoutDetailOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var LayoutDetailOptionsRec = (function (_super) {
__extends(LayoutDetailOptionsRec, _super);
function LayoutDetailOptionsRec(defaults) {
_super.apply(this, arguments);
}
LayoutDetailOptionsRec.attributesToDeclare = function () {
return [
this.attr("NoPadding", "noPaddingAttr", "noPadding", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("DarkMode", "darkModeAttr", "darkMode", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("DarkerBackground", "darkerBackgroundAttr", "darkerBackground", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("Banner", "bannerAttr", "banner", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("HeaderSteps", "headerStepsAttr", "headerSteps", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ThemeModel.HeaderStepsOptionsRec());
}, true, ShopperPortalEU_UI_ThemeModel.HeaderStepsOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
LayoutDetailOptionsRec.init();
return LayoutDetailOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ThemeModel.LayoutDetailOptionsRec = LayoutDetailOptionsRec;

});
define("ShopperPortalEU_UI_Theme.model$LayoutDetailOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$LayoutDetailOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var LayoutDetailOptionsRecord = (function (_super) {
__extends(LayoutDetailOptionsRecord, _super);
function LayoutDetailOptionsRecord(defaults) {
_super.apply(this, arguments);
}
LayoutDetailOptionsRecord.attributesToDeclare = function () {
return [
this.attr("LayoutDetailOptions", "layoutDetailOptionsAttr", "LayoutDetailOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ThemeModel.LayoutDetailOptionsRec());
}, true, ShopperPortalEU_UI_ThemeModel.LayoutDetailOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
LayoutDetailOptionsRecord.fromStructure = function (str) {
return new LayoutDetailOptionsRecord(new LayoutDetailOptionsRecord.RecordClass({
layoutDetailOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
LayoutDetailOptionsRecord._isAnonymousRecord = true;
LayoutDetailOptionsRecord.UniqueId = "5d61304a-936a-5e78-0235-643de86409f6";
LayoutDetailOptionsRecord.init();
return LayoutDetailOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ThemeModel.LayoutDetailOptionsRecord = LayoutDetailOptionsRecord;

});
define("ShopperPortalEU_UI_Theme.model$MenuElementOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var MenuElementOptionsRec = (function (_super) {
__extends(MenuElementOptionsRec, _super);
function MenuElementOptionsRec(defaults) {
_super.apply(this, arguments);
}
MenuElementOptionsRec.attributesToDeclare = function () {
return [
this.attr("TestId", "testIdAttr", "testId", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
MenuElementOptionsRec.fromStructure = function (str) {
return new MenuElementOptionsRec(new MenuElementOptionsRec.RecordClass({
testIdAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
MenuElementOptionsRec.init();
return MenuElementOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ThemeModel.MenuElementOptionsRec = MenuElementOptionsRec;

});
define("ShopperPortalEU_UI_Theme.model$MenuElementOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$MenuElementOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var MenuElementOptionsRecord = (function (_super) {
__extends(MenuElementOptionsRecord, _super);
function MenuElementOptionsRecord(defaults) {
_super.apply(this, arguments);
}
MenuElementOptionsRecord.attributesToDeclare = function () {
return [
this.attr("MenuElementOptions", "menuElementOptionsAttr", "MenuElementOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ThemeModel.MenuElementOptionsRec());
}, true, ShopperPortalEU_UI_ThemeModel.MenuElementOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
MenuElementOptionsRecord.fromStructure = function (str) {
return new MenuElementOptionsRecord(new MenuElementOptionsRecord.RecordClass({
menuElementOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
MenuElementOptionsRecord._isAnonymousRecord = true;
MenuElementOptionsRecord.UniqueId = "fb7f0b6f-5f77-3c07-a590-0e43896abebf";
MenuElementOptionsRecord.init();
return MenuElementOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ThemeModel.MenuElementOptionsRecord = MenuElementOptionsRecord;

});
define("ShopperPortalEU_UI_Theme.model$MenuElementOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$MenuElementOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var MenuElementOptionsRecordList = (function (_super) {
__extends(MenuElementOptionsRecordList, _super);
function MenuElementOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
MenuElementOptionsRecordList.itemType = ShopperPortalEU_UI_ThemeModel.MenuElementOptionsRecord;
return MenuElementOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.MenuElementOptionsRecordList = MenuElementOptionsRecordList;

});
define("ShopperPortalEU_UI_Theme.model$LoginOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$LoginOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var LoginOptionsList = (function (_super) {
__extends(LoginOptionsList, _super);
function LoginOptionsList(defaults) {
_super.apply(this, arguments);
}
LoginOptionsList.itemType = ShopperPortalEU_UI_ThemeModel.LoginOptionsRec;
return LoginOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.LoginOptionsList = LoginOptionsList;

});
define("ShopperPortalEU_UI_Theme.model$HeaderActionItemOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$HeaderActionItemOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var HeaderActionItemOptionsRecord = (function (_super) {
__extends(HeaderActionItemOptionsRecord, _super);
function HeaderActionItemOptionsRecord(defaults) {
_super.apply(this, arguments);
}
HeaderActionItemOptionsRecord.attributesToDeclare = function () {
return [
this.attr("HeaderActionItemOptions", "headerActionItemOptionsAttr", "HeaderActionItemOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ThemeModel.HeaderActionItemOptionsRec());
}, true, ShopperPortalEU_UI_ThemeModel.HeaderActionItemOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
HeaderActionItemOptionsRecord.fromStructure = function (str) {
return new HeaderActionItemOptionsRecord(new HeaderActionItemOptionsRecord.RecordClass({
headerActionItemOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
HeaderActionItemOptionsRecord._isAnonymousRecord = true;
HeaderActionItemOptionsRecord.UniqueId = "641743b8-afe0-cd38-e466-02710a9bc102";
HeaderActionItemOptionsRecord.init();
return HeaderActionItemOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ThemeModel.HeaderActionItemOptionsRecord = HeaderActionItemOptionsRecord;

});
define("ShopperPortalEU_UI_Theme.model$BottomBarItemOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var BottomBarItemOptionsRec = (function (_super) {
__extends(BottomBarItemOptionsRec, _super);
function BottomBarItemOptionsRec(defaults) {
_super.apply(this, arguments);
}
BottomBarItemOptionsRec.attributesToDeclare = function () {
return [
this.attr("Icon", "iconAttr", "icon", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Family", "familyAttr", "family", false, false, OS.DataTypes.DataTypes.Text, function () {
return ShopperPortalEU_UI_ThemeModel.staticEntities.customIconFamily.material;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
BottomBarItemOptionsRec.init();
return BottomBarItemOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ThemeModel.BottomBarItemOptionsRec = BottomBarItemOptionsRec;

});
define("ShopperPortalEU_UI_Theme.model$BottomBarOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$BottomBarOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var BottomBarOptionsList = (function (_super) {
__extends(BottomBarOptionsList, _super);
function BottomBarOptionsList(defaults) {
_super.apply(this, arguments);
}
BottomBarOptionsList.itemType = ShopperPortalEU_UI_ThemeModel.BottomBarOptionsRec;
return BottomBarOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.BottomBarOptionsList = BottomBarOptionsList;

});
define("ShopperPortalEU_UI_Theme.model$LayoutHeaderOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$LayoutHeaderOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var LayoutHeaderOptionsRecord = (function (_super) {
__extends(LayoutHeaderOptionsRecord, _super);
function LayoutHeaderOptionsRecord(defaults) {
_super.apply(this, arguments);
}
LayoutHeaderOptionsRecord.attributesToDeclare = function () {
return [
this.attr("LayoutHeaderOptions", "layoutHeaderOptionsAttr", "LayoutHeaderOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ThemeModel.LayoutHeaderOptionsRec());
}, true, ShopperPortalEU_UI_ThemeModel.LayoutHeaderOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
LayoutHeaderOptionsRecord.fromStructure = function (str) {
return new LayoutHeaderOptionsRecord(new LayoutHeaderOptionsRecord.RecordClass({
layoutHeaderOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
LayoutHeaderOptionsRecord._isAnonymousRecord = true;
LayoutHeaderOptionsRecord.UniqueId = "7555ea85-7cc5-9f8e-b6b7-2fd90463ce87";
LayoutHeaderOptionsRecord.init();
return LayoutHeaderOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ThemeModel.LayoutHeaderOptionsRecord = LayoutHeaderOptionsRecord;

});
define("ShopperPortalEU_UI_Theme.model$LayoutBlankOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$LayoutBlankOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var LayoutBlankOptionsList = (function (_super) {
__extends(LayoutBlankOptionsList, _super);
function LayoutBlankOptionsList(defaults) {
_super.apply(this, arguments);
}
LayoutBlankOptionsList.itemType = ShopperPortalEU_UI_ThemeModel.LayoutBlankOptionsRec;
return LayoutBlankOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.LayoutBlankOptionsList = LayoutBlankOptionsList;

});
define("ShopperPortalEU_UI_Theme.model$CustomColumnsOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.model$CustomColumnsOptionsRec", "ShopperPortalEU_UI_Theme.referencesHealth", "ShopperPortalEU_UI_Theme.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var CustomColumnsOptionsRecord = (function (_super) {
__extends(CustomColumnsOptionsRecord, _super);
function CustomColumnsOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomColumnsOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomColumnsOptions", "customColumnsOptionsAttr", "CustomColumnsOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomColumnsOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomColumnsOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomColumnsOptionsRecord.fromStructure = function (str) {
return new CustomColumnsOptionsRecord(new CustomColumnsOptionsRecord.RecordClass({
customColumnsOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomColumnsOptionsRecord._isAnonymousRecord = true;
CustomColumnsOptionsRecord.UniqueId = "80510748-bfcb-3f63-e1cf-56d102d07849";
CustomColumnsOptionsRecord.init();
return CustomColumnsOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ThemeModel.CustomColumnsOptionsRecord = CustomColumnsOptionsRecord;

});
define("ShopperPortalEU_UI_Theme.model$MenuOptionsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var MenuOptionsRec = (function (_super) {
__extends(MenuOptionsRec, _super);
function MenuOptionsRec(defaults) {
_super.apply(this, arguments);
}
MenuOptionsRec.attributesToDeclare = function () {
return [
this.attr("ActiveMenu", "activeMenuAttr", "activeMenu", false, false, OS.DataTypes.DataTypes.Integer, function () {
return -1;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
MenuOptionsRec.fromStructure = function (str) {
return new MenuOptionsRec(new MenuOptionsRec.RecordClass({
activeMenuAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
MenuOptionsRec.init();
return MenuOptionsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ThemeModel.MenuOptionsRec = MenuOptionsRec;

});
define("ShopperPortalEU_UI_Theme.model$LayoutBlankOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$LayoutBlankOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var LayoutBlankOptionsRecord = (function (_super) {
__extends(LayoutBlankOptionsRecord, _super);
function LayoutBlankOptionsRecord(defaults) {
_super.apply(this, arguments);
}
LayoutBlankOptionsRecord.attributesToDeclare = function () {
return [
this.attr("LayoutBlankOptions", "layoutBlankOptionsAttr", "LayoutBlankOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ThemeModel.LayoutBlankOptionsRec());
}, true, ShopperPortalEU_UI_ThemeModel.LayoutBlankOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
LayoutBlankOptionsRecord.fromStructure = function (str) {
return new LayoutBlankOptionsRecord(new LayoutBlankOptionsRecord.RecordClass({
layoutBlankOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
LayoutBlankOptionsRecord._isAnonymousRecord = true;
LayoutBlankOptionsRecord.UniqueId = "e3cec805-0d7a-87aa-4836-19b3dbee0ec0";
LayoutBlankOptionsRecord.init();
return LayoutBlankOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ThemeModel.LayoutBlankOptionsRecord = LayoutBlankOptionsRecord;

});
define("ShopperPortalEU_UI_Theme.model$LayoutBlankOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$LayoutBlankOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var LayoutBlankOptionsRecordList = (function (_super) {
__extends(LayoutBlankOptionsRecordList, _super);
function LayoutBlankOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
LayoutBlankOptionsRecordList.itemType = ShopperPortalEU_UI_ThemeModel.LayoutBlankOptionsRecord;
return LayoutBlankOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.LayoutBlankOptionsRecordList = LayoutBlankOptionsRecordList;

});
define("ShopperPortalEU_UI_Theme.model$MenuOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$MenuOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var MenuOptionsRecord = (function (_super) {
__extends(MenuOptionsRecord, _super);
function MenuOptionsRecord(defaults) {
_super.apply(this, arguments);
}
MenuOptionsRecord.attributesToDeclare = function () {
return [
this.attr("MenuOptions", "menuOptionsAttr", "MenuOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ThemeModel.MenuOptionsRec());
}, true, ShopperPortalEU_UI_ThemeModel.MenuOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
MenuOptionsRecord.fromStructure = function (str) {
return new MenuOptionsRecord(new MenuOptionsRecord.RecordClass({
menuOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
MenuOptionsRecord._isAnonymousRecord = true;
MenuOptionsRecord.UniqueId = "9ac651f3-b159-6d35-fe55-fea78c049573";
MenuOptionsRecord.init();
return MenuOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ThemeModel.MenuOptionsRecord = MenuOptionsRecord;

});
define("ShopperPortalEU_UI_Theme.model$BannerTypeRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var BannerTypeRec = (function (_super) {
__extends(BannerTypeRec, _super);
function BannerTypeRec(defaults) {
_super.apply(this, arguments);
}
BannerTypeRec.attributesToDeclare = function () {
return [
this.attr("Class", "classAttr", "Class", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
BannerTypeRec.fromStructure = function (str) {
return new BannerTypeRec(new BannerTypeRec.RecordClass({
classAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
BannerTypeRec.init();
return BannerTypeRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ThemeModel.BannerTypeRec = BannerTypeRec;

});
define("ShopperPortalEU_UI_Theme.model$BannerTypeRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$BannerTypeRec"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var BannerTypeRecord = (function (_super) {
__extends(BannerTypeRecord, _super);
function BannerTypeRecord(defaults) {
_super.apply(this, arguments);
}
BannerTypeRecord.attributesToDeclare = function () {
return [
this.attr("BannerType", "bannerTypeAttr", "BannerType", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ThemeModel.BannerTypeRec());
}, true, ShopperPortalEU_UI_ThemeModel.BannerTypeRec)
].concat(_super.attributesToDeclare.call(this));
};
BannerTypeRecord.fromStructure = function (str) {
return new BannerTypeRecord(new BannerTypeRecord.RecordClass({
bannerTypeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
BannerTypeRecord._isAnonymousRecord = true;
BannerTypeRecord.UniqueId = "9e3dd88d-5f7f-2294-5932-a99d460591e7";
BannerTypeRecord.init();
return BannerTypeRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ThemeModel.BannerTypeRecord = BannerTypeRecord;

});
define("ShopperPortalEU_UI_Theme.model$CustomIconFamilyRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.model$CustomIconFamilyRec", "ShopperPortalEU_UI_Theme.referencesHealth", "ShopperPortalEU_UI_Theme.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var CustomIconFamilyRecord = (function (_super) {
__extends(CustomIconFamilyRecord, _super);
function CustomIconFamilyRecord(defaults) {
_super.apply(this, arguments);
}
CustomIconFamilyRecord.attributesToDeclare = function () {
return [
this.attr("CustomIconFamily", "customIconFamilyAttr", "CustomIconFamily", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomIconFamilyRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomIconFamilyRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomIconFamilyRecord.fromStructure = function (str) {
return new CustomIconFamilyRecord(new CustomIconFamilyRecord.RecordClass({
customIconFamilyAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomIconFamilyRecord._isAnonymousRecord = true;
CustomIconFamilyRecord.UniqueId = "9fc51a4a-fa2f-d647-1909-b8f8c0bf9224";
CustomIconFamilyRecord.init();
return CustomIconFamilyRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ThemeModel.CustomIconFamilyRecord = CustomIconFamilyRecord;

});
define("ShopperPortalEU_UI_Theme.model$MenuOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$MenuOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var MenuOptionsRecordList = (function (_super) {
__extends(MenuOptionsRecordList, _super);
function MenuOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
MenuOptionsRecordList.itemType = ShopperPortalEU_UI_ThemeModel.MenuOptionsRecord;
return MenuOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.MenuOptionsRecordList = MenuOptionsRecordList;

});
define("ShopperPortalEU_UI_Theme.model$MenuItemOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$MenuItemOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var MenuItemOptionsRecord = (function (_super) {
__extends(MenuItemOptionsRecord, _super);
function MenuItemOptionsRecord(defaults) {
_super.apply(this, arguments);
}
MenuItemOptionsRecord.attributesToDeclare = function () {
return [
this.attr("MenuItemOptions", "menuItemOptionsAttr", "MenuItemOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ThemeModel.MenuItemOptionsRec());
}, true, ShopperPortalEU_UI_ThemeModel.MenuItemOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
MenuItemOptionsRecord.fromStructure = function (str) {
return new MenuItemOptionsRecord(new MenuItemOptionsRecord.RecordClass({
menuItemOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
MenuItemOptionsRecord._isAnonymousRecord = true;
MenuItemOptionsRecord.UniqueId = "a3beaa49-0ffd-95c4-b342-a6c98a67cc67";
MenuItemOptionsRecord.init();
return MenuItemOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ThemeModel.MenuItemOptionsRecord = MenuItemOptionsRecord;

});
define("ShopperPortalEU_UI_Theme.model$MenuItemOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$MenuItemOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var MenuItemOptionsList = (function (_super) {
__extends(MenuItemOptionsList, _super);
function MenuItemOptionsList(defaults) {
_super.apply(this, arguments);
}
MenuItemOptionsList.itemType = ShopperPortalEU_UI_ThemeModel.MenuItemOptionsRec;
return MenuItemOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.MenuItemOptionsList = MenuItemOptionsList;

});
define("ShopperPortalEU_UI_Theme.model$CustomMessageIconOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$CustomMessageIconOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var CustomMessageIconOptionsRecord = (function (_super) {
__extends(CustomMessageIconOptionsRecord, _super);
function CustomMessageIconOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomMessageIconOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomMessageIconOptions", "customMessageIconOptionsAttr", "CustomMessageIconOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ThemeModel.CustomMessageIconOptionsRec());
}, true, ShopperPortalEU_UI_ThemeModel.CustomMessageIconOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomMessageIconOptionsRecord.fromStructure = function (str) {
return new CustomMessageIconOptionsRecord(new CustomMessageIconOptionsRecord.RecordClass({
customMessageIconOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomMessageIconOptionsRecord._isAnonymousRecord = true;
CustomMessageIconOptionsRecord.UniqueId = "c3961fb6-59d7-78de-bab0-58a3eec19a04";
CustomMessageIconOptionsRecord.init();
return CustomMessageIconOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ThemeModel.CustomMessageIconOptionsRecord = CustomMessageIconOptionsRecord;

});
define("ShopperPortalEU_UI_Theme.model$CustomMessageIconOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$CustomMessageIconOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var CustomMessageIconOptionsRecordList = (function (_super) {
__extends(CustomMessageIconOptionsRecordList, _super);
function CustomMessageIconOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomMessageIconOptionsRecordList.itemType = ShopperPortalEU_UI_ThemeModel.CustomMessageIconOptionsRecord;
return CustomMessageIconOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.CustomMessageIconOptionsRecordList = CustomMessageIconOptionsRecordList;

});
define("ShopperPortalEU_UI_Theme.model$BottomBarItemOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$BottomBarItemOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var BottomBarItemOptionsRecord = (function (_super) {
__extends(BottomBarItemOptionsRecord, _super);
function BottomBarItemOptionsRecord(defaults) {
_super.apply(this, arguments);
}
BottomBarItemOptionsRecord.attributesToDeclare = function () {
return [
this.attr("BottomBarItemOptions", "bottomBarItemOptionsAttr", "BottomBarItemOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ThemeModel.BottomBarItemOptionsRec());
}, true, ShopperPortalEU_UI_ThemeModel.BottomBarItemOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
BottomBarItemOptionsRecord.fromStructure = function (str) {
return new BottomBarItemOptionsRecord(new BottomBarItemOptionsRecord.RecordClass({
bottomBarItemOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
BottomBarItemOptionsRecord._isAnonymousRecord = true;
BottomBarItemOptionsRecord.UniqueId = "cd13f377-7410-e063-955f-87449f73c9e3";
BottomBarItemOptionsRecord.init();
return BottomBarItemOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ThemeModel.BottomBarItemOptionsRecord = BottomBarItemOptionsRecord;

});
define("ShopperPortalEU_UI_Theme.model$BottomBarItemOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$BottomBarItemOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var BottomBarItemOptionsRecordList = (function (_super) {
__extends(BottomBarItemOptionsRecordList, _super);
function BottomBarItemOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
BottomBarItemOptionsRecordList.itemType = ShopperPortalEU_UI_ThemeModel.BottomBarItemOptionsRecord;
return BottomBarItemOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.BottomBarItemOptionsRecordList = BottomBarItemOptionsRecordList;

});
define("ShopperPortalEU_UI_Theme.model$CustomLoadingOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.model$CustomLoadingOptionsRec", "ShopperPortalEU_UI_Theme.referencesHealth", "ShopperPortalEU_UI_Theme.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var CustomLoadingOptionsList = (function (_super) {
__extends(CustomLoadingOptionsList, _super);
function CustomLoadingOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomLoadingOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomLoadingOptionsRec;
return CustomLoadingOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.CustomLoadingOptionsList = CustomLoadingOptionsList;

});
define("ShopperPortalEU_UI_Theme.model$CustomFormOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.model$CustomFormOptionsRec", "ShopperPortalEU_UI_Theme.referencesHealth", "ShopperPortalEU_UI_Theme.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var CustomFormOptionsRecord = (function (_super) {
__extends(CustomFormOptionsRecord, _super);
function CustomFormOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomFormOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomFormOptions", "customFormOptionsAttr", "CustomFormOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomFormOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomFormOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomFormOptionsRecord.fromStructure = function (str) {
return new CustomFormOptionsRecord(new CustomFormOptionsRecord.RecordClass({
customFormOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomFormOptionsRecord._isAnonymousRecord = true;
CustomFormOptionsRecord.UniqueId = "c9cd1982-bef8-6871-7102-5ab6268c5317";
CustomFormOptionsRecord.init();
return CustomFormOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ThemeModel.CustomFormOptionsRecord = CustomFormOptionsRecord;

});
define("ShopperPortalEU_UI_Theme.model$CustomFormOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$CustomFormOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var CustomFormOptionsRecordList = (function (_super) {
__extends(CustomFormOptionsRecordList, _super);
function CustomFormOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomFormOptionsRecordList.itemType = ShopperPortalEU_UI_ThemeModel.CustomFormOptionsRecord;
return CustomFormOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.CustomFormOptionsRecordList = CustomFormOptionsRecordList;

});
define("ShopperPortalEU_UI_Theme.model$CustomIconFamilyRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$CustomIconFamilyRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var CustomIconFamilyRecordList = (function (_super) {
__extends(CustomIconFamilyRecordList, _super);
function CustomIconFamilyRecordList(defaults) {
_super.apply(this, arguments);
}
CustomIconFamilyRecordList.itemType = ShopperPortalEU_UI_ThemeModel.CustomIconFamilyRecord;
return CustomIconFamilyRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.CustomIconFamilyRecordList = CustomIconFamilyRecordList;

});
define("ShopperPortalEU_UI_Theme.model$CustomLoadingOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.model$CustomLoadingOptionsRec", "ShopperPortalEU_UI_Theme.referencesHealth", "ShopperPortalEU_UI_Theme.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var CustomLoadingOptionsRecord = (function (_super) {
__extends(CustomLoadingOptionsRecord, _super);
function CustomLoadingOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomLoadingOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomLoadingOptions", "customLoadingOptionsAttr", "CustomLoadingOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomLoadingOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomLoadingOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomLoadingOptionsRecord.fromStructure = function (str) {
return new CustomLoadingOptionsRecord(new CustomLoadingOptionsRecord.RecordClass({
customLoadingOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomLoadingOptionsRecord._isAnonymousRecord = true;
CustomLoadingOptionsRecord.UniqueId = "ebc677c9-b8b0-9c98-ea26-376582f23c2a";
CustomLoadingOptionsRecord.init();
return CustomLoadingOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_UI_ThemeModel.CustomLoadingOptionsRecord = CustomLoadingOptionsRecord;

});
define("ShopperPortalEU_UI_Theme.model$CustomLoadingOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$CustomLoadingOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var CustomLoadingOptionsRecordList = (function (_super) {
__extends(CustomLoadingOptionsRecordList, _super);
function CustomLoadingOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomLoadingOptionsRecordList.itemType = ShopperPortalEU_UI_ThemeModel.CustomLoadingOptionsRecord;
return CustomLoadingOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.CustomLoadingOptionsRecordList = CustomLoadingOptionsRecordList;

});
define("ShopperPortalEU_UI_Theme.model$ApplicationHeaderOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$ApplicationHeaderOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var ApplicationHeaderOptionsList = (function (_super) {
__extends(ApplicationHeaderOptionsList, _super);
function ApplicationHeaderOptionsList(defaults) {
_super.apply(this, arguments);
}
ApplicationHeaderOptionsList.itemType = ShopperPortalEU_UI_ThemeModel.ApplicationHeaderOptionsRec;
return ApplicationHeaderOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.ApplicationHeaderOptionsList = ApplicationHeaderOptionsList;

});
define("ShopperPortalEU_UI_Theme.model$LayoutOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$LayoutOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var LayoutOptionsList = (function (_super) {
__extends(LayoutOptionsList, _super);
function LayoutOptionsList(defaults) {
_super.apply(this, arguments);
}
LayoutOptionsList.itemType = ShopperPortalEU_UI_ThemeModel.LayoutOptionsRec;
return LayoutOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.LayoutOptionsList = LayoutOptionsList;

});
define("ShopperPortalEU_UI_Theme.model$CustomColumnsOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.model$CustomColumnsOptionsRec", "ShopperPortalEU_UI_Theme.referencesHealth", "ShopperPortalEU_UI_Theme.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var CustomColumnsOptionsList = (function (_super) {
__extends(CustomColumnsOptionsList, _super);
function CustomColumnsOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomColumnsOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomColumnsOptionsRec;
return CustomColumnsOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.CustomColumnsOptionsList = CustomColumnsOptionsList;

});
define("ShopperPortalEU_UI_Theme.model$LayoutDetailOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$LayoutDetailOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var LayoutDetailOptionsList = (function (_super) {
__extends(LayoutDetailOptionsList, _super);
function LayoutDetailOptionsList(defaults) {
_super.apply(this, arguments);
}
LayoutDetailOptionsList.itemType = ShopperPortalEU_UI_ThemeModel.LayoutDetailOptionsRec;
return LayoutDetailOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.LayoutDetailOptionsList = LayoutDetailOptionsList;

});
define("ShopperPortalEU_UI_Theme.model$LayoutHeaderOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$LayoutHeaderOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var LayoutHeaderOptionsRecordList = (function (_super) {
__extends(LayoutHeaderOptionsRecordList, _super);
function LayoutHeaderOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
LayoutHeaderOptionsRecordList.itemType = ShopperPortalEU_UI_ThemeModel.LayoutHeaderOptionsRecord;
return LayoutHeaderOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.LayoutHeaderOptionsRecordList = LayoutHeaderOptionsRecordList;

});
define("ShopperPortalEU_UI_Theme.model$LayoutDetailOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$LayoutDetailOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var LayoutDetailOptionsRecordList = (function (_super) {
__extends(LayoutDetailOptionsRecordList, _super);
function LayoutDetailOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
LayoutDetailOptionsRecordList.itemType = ShopperPortalEU_UI_ThemeModel.LayoutDetailOptionsRecord;
return LayoutDetailOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.LayoutDetailOptionsRecordList = LayoutDetailOptionsRecordList;

});
define("ShopperPortalEU_UI_Theme.model$CustomIconSizeList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.model$CustomIconSizeRec", "ShopperPortalEU_UI_Theme.referencesHealth", "ShopperPortalEU_UI_Theme.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var CustomIconSizeList = (function (_super) {
__extends(CustomIconSizeList, _super);
function CustomIconSizeList(defaults) {
_super.apply(this, arguments);
}
CustomIconSizeList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomIconSizeRec;
return CustomIconSizeList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.CustomIconSizeList = CustomIconSizeList;

});
define("ShopperPortalEU_UI_Theme.model$BannerTypeList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$BannerTypeRec"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var BannerTypeList = (function (_super) {
__extends(BannerTypeList, _super);
function BannerTypeList(defaults) {
_super.apply(this, arguments);
}
BannerTypeList.itemType = ShopperPortalEU_UI_ThemeModel.BannerTypeRec;
return BannerTypeList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.BannerTypeList = BannerTypeList;

});
define("ShopperPortalEU_UI_Theme.model$MenuItemIconOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$MenuItemIconOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var MenuItemIconOptionsList = (function (_super) {
__extends(MenuItemIconOptionsList, _super);
function MenuItemIconOptionsList(defaults) {
_super.apply(this, arguments);
}
MenuItemIconOptionsList.itemType = ShopperPortalEU_UI_ThemeModel.MenuItemIconOptionsRec;
return MenuItemIconOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.MenuItemIconOptionsList = MenuItemIconOptionsList;

});
define("ShopperPortalEU_UI_Theme.model$BottomBarItemOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$BottomBarItemOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var BottomBarItemOptionsList = (function (_super) {
__extends(BottomBarItemOptionsList, _super);
function BottomBarItemOptionsList(defaults) {
_super.apply(this, arguments);
}
BottomBarItemOptionsList.itemType = ShopperPortalEU_UI_ThemeModel.BottomBarItemOptionsRec;
return BottomBarItemOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.BottomBarItemOptionsList = BottomBarItemOptionsList;

});
define("ShopperPortalEU_UI_Theme.model$CustomColumnsOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$CustomColumnsOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var CustomColumnsOptionsRecordList = (function (_super) {
__extends(CustomColumnsOptionsRecordList, _super);
function CustomColumnsOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomColumnsOptionsRecordList.itemType = ShopperPortalEU_UI_ThemeModel.CustomColumnsOptionsRecord;
return CustomColumnsOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.CustomColumnsOptionsRecordList = CustomColumnsOptionsRecordList;

});
define("ShopperPortalEU_UI_Theme.model$HeaderActionOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$HeaderActionOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var HeaderActionOptionsRecordList = (function (_super) {
__extends(HeaderActionOptionsRecordList, _super);
function HeaderActionOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
HeaderActionOptionsRecordList.itemType = ShopperPortalEU_UI_ThemeModel.HeaderActionOptionsRecord;
return HeaderActionOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.HeaderActionOptionsRecordList = HeaderActionOptionsRecordList;

});
define("ShopperPortalEU_UI_Theme.model$CustomFormOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.model$CustomFormOptionsRec", "ShopperPortalEU_UI_Theme.referencesHealth", "ShopperPortalEU_UI_Theme.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var CustomFormOptionsList = (function (_super) {
__extends(CustomFormOptionsList, _super);
function CustomFormOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomFormOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomFormOptionsRec;
return CustomFormOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.CustomFormOptionsList = CustomFormOptionsList;

});
define("ShopperPortalEU_UI_Theme.model$BannerTypeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$BannerTypeRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var BannerTypeRecordList = (function (_super) {
__extends(BannerTypeRecordList, _super);
function BannerTypeRecordList(defaults) {
_super.apply(this, arguments);
}
BannerTypeRecordList.itemType = ShopperPortalEU_UI_ThemeModel.BannerTypeRecord;
return BannerTypeRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.BannerTypeRecordList = BannerTypeRecordList;

});
define("ShopperPortalEU_UI_Theme.model$HeaderActionItemOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$HeaderActionItemOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var HeaderActionItemOptionsRecordList = (function (_super) {
__extends(HeaderActionItemOptionsRecordList, _super);
function HeaderActionItemOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
HeaderActionItemOptionsRecordList.itemType = ShopperPortalEU_UI_ThemeModel.HeaderActionItemOptionsRecord;
return HeaderActionItemOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.HeaderActionItemOptionsRecordList = HeaderActionItemOptionsRecordList;

});
define("ShopperPortalEU_UI_Theme.model$BottomBarOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$BottomBarOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var BottomBarOptionsRecordList = (function (_super) {
__extends(BottomBarOptionsRecordList, _super);
function BottomBarOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
BottomBarOptionsRecordList.itemType = ShopperPortalEU_UI_ThemeModel.BottomBarOptionsRecord;
return BottomBarOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.BottomBarOptionsRecordList = BottomBarOptionsRecordList;

});
define("ShopperPortalEU_UI_Theme.model$HeaderActionItemIconOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$HeaderActionItemIconOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var HeaderActionItemIconOptionsList = (function (_super) {
__extends(HeaderActionItemIconOptionsList, _super);
function HeaderActionItemIconOptionsList(defaults) {
_super.apply(this, arguments);
}
HeaderActionItemIconOptionsList.itemType = ShopperPortalEU_UI_ThemeModel.HeaderActionItemIconOptionsRec;
return HeaderActionItemIconOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.HeaderActionItemIconOptionsList = HeaderActionItemIconOptionsList;

});
define("ShopperPortalEU_UI_Theme.model$MenuElementOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$MenuElementOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var MenuElementOptionsList = (function (_super) {
__extends(MenuElementOptionsList, _super);
function MenuElementOptionsList(defaults) {
_super.apply(this, arguments);
}
MenuElementOptionsList.itemType = ShopperPortalEU_UI_ThemeModel.MenuElementOptionsRec;
return MenuElementOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.MenuElementOptionsList = MenuElementOptionsList;

});
define("ShopperPortalEU_UI_Theme.model$MenuOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$MenuOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var MenuOptionsList = (function (_super) {
__extends(MenuOptionsList, _super);
function MenuOptionsList(defaults) {
_super.apply(this, arguments);
}
MenuOptionsList.itemType = ShopperPortalEU_UI_ThemeModel.MenuOptionsRec;
return MenuOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.MenuOptionsList = MenuOptionsList;

});
define("ShopperPortalEU_UI_Theme.model$MenuItemOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$MenuItemOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var MenuItemOptionsRecordList = (function (_super) {
__extends(MenuItemOptionsRecordList, _super);
function MenuItemOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
MenuItemOptionsRecordList.itemType = ShopperPortalEU_UI_ThemeModel.MenuItemOptionsRecord;
return MenuItemOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.MenuItemOptionsRecordList = MenuItemOptionsRecordList;

});
define("ShopperPortalEU_UI_Theme.model$LayoutOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.model$LayoutOptionsRecord"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var LayoutOptionsRecordList = (function (_super) {
__extends(LayoutOptionsRecordList, _super);
function LayoutOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
LayoutOptionsRecordList.itemType = ShopperPortalEU_UI_ThemeModel.LayoutOptionsRecord;
return LayoutOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.LayoutOptionsRecordList = LayoutOptionsRecordList;

});
define("ShopperPortalEU_UI_Theme.model$CustomIconOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.model$CustomIconOptionsRec", "ShopperPortalEU_UI_Theme.referencesHealth", "ShopperPortalEU_UI_Theme.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;
var CustomIconOptionsList = (function (_super) {
__extends(CustomIconOptionsList, _super);
function CustomIconOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomIconOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomIconOptionsRec;
return CustomIconOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_UI_ThemeModel.CustomIconOptionsList = CustomIconOptionsList;

});
define("ShopperPortalEU_UI_Theme.model", ["exports", "OutSystems/ClientRuntime/Main"], function (exports, OutSystems) {
var OS = OutSystems.Internal;
var ShopperPortalEU_UI_ThemeModel = exports;
Object.defineProperty(ShopperPortalEU_UI_ThemeModel, "module", {
get: function () {
return OS.ApplicationInfo.getModules()["c65988d6-7505-42fe-87db-3f85bb4d520d"];
}
});

ShopperPortalEU_UI_ThemeModel.staticEntities = {};
ShopperPortalEU_UI_ThemeModel.staticEntities.bannerType = {};
var getBannerTypeRecord = function (record) {
return ShopperPortalEU_UI_ThemeModel.module.staticEntities["463d4b7b-5e44-419e-a346-23e3a2e8ed75"][record];
};
Object.defineProperty(ShopperPortalEU_UI_ThemeModel.staticEntities.bannerType, "travel", {
get: function () {
return getBannerTypeRecord("8bcb6612-ea66-4999-935c-5d0d65ff50c1");
}
});

ShopperPortalEU_UI_ThemeModel.staticEntities.customMessageType = {};
var getCustomMessageTypeRecord = function (record) {
return ShopperPortalEU_UI_ThemeModel.module.staticEntities["4fe6b2fc-c2ed-4e3e-aa6e-3a8e162773aa"][record];
};
Object.defineProperty(ShopperPortalEU_UI_ThemeModel.staticEntities.customMessageType, "warning", {
get: function () {
return getCustomMessageTypeRecord("5f7c1c60-4966-4803-be86-87bc10007a33");
}
});

Object.defineProperty(ShopperPortalEU_UI_ThemeModel.staticEntities.customMessageType, "neutral", {
get: function () {
return getCustomMessageTypeRecord("90939e3e-5b5c-4e5b-a572-9a3f74a90f5d");
}
});

Object.defineProperty(ShopperPortalEU_UI_ThemeModel.staticEntities.customMessageType, "error", {
get: function () {
return getCustomMessageTypeRecord("992b9b75-b842-4a44-aa84-2d93c186f4b0");
}
});

Object.defineProperty(ShopperPortalEU_UI_ThemeModel.staticEntities.customMessageType, "success", {
get: function () {
return getCustomMessageTypeRecord("a901764b-8c93-4ac2-ba90-0c9148b14a61");
}
});

Object.defineProperty(ShopperPortalEU_UI_ThemeModel.staticEntities.customMessageType, "info", {
get: function () {
return getCustomMessageTypeRecord("cddffef1-8412-45e8-944c-4f8916c63e8a");
}
});

ShopperPortalEU_UI_ThemeModel.staticEntities.customIconFamily = {};
var getCustomIconFamilyRecord = function (record) {
return OS.ApplicationInfo.getModules()["e7bb7e26-af64-4f69-9436-0768d54ea01b"].staticEntities["3cac8f18-453c-4266-bac7-1e6a4c9a927d"][record];
};
Object.defineProperty(ShopperPortalEU_UI_ThemeModel.staticEntities.customIconFamily, "material", {
get: function () {
return getCustomIconFamilyRecord("6174a3e0-352f-4bd6-a3d8-02e7c57b11bc");
}
});

Object.defineProperty(ShopperPortalEU_UI_ThemeModel.staticEntities.customIconFamily, "planet", {
get: function () {
return getCustomIconFamilyRecord("df8e6450-0b1f-4ee9-b565-0c9de741e710");
}
});

ShopperPortalEU_UI_ThemeModel.staticEntities.customIconSize = {};
var getCustomIconSizeRecord = function (record) {
return OS.ApplicationInfo.getModules()["e7bb7e26-af64-4f69-9436-0768d54ea01b"].staticEntities["61ccda77-5a92-45e8-9d19-9a6741575ccf"][record];
};
Object.defineProperty(ShopperPortalEU_UI_ThemeModel.staticEntities.customIconSize, "large", {
get: function () {
return getCustomIconSizeRecord("59be3f66-dacf-482a-8f70-2f16fe36af65");
}
});

Object.defineProperty(ShopperPortalEU_UI_ThemeModel.staticEntities.customIconSize, "extraSmall", {
get: function () {
return getCustomIconSizeRecord("6b0d7c1e-80e7-45f4-9532-04cf71317cf9");
}
});

Object.defineProperty(ShopperPortalEU_UI_ThemeModel.staticEntities.customIconSize, "small", {
get: function () {
return getCustomIconSizeRecord("a61035e3-7d0f-416c-9242-af27cde5b6ee");
}
});

Object.defineProperty(ShopperPortalEU_UI_ThemeModel.staticEntities.customIconSize, "base", {
get: function () {
return getCustomIconSizeRecord("de82cee7-2ecd-46fe-a554-5f2b265579c9");
}
});

});
