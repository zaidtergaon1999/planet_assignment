define("ShopperPortalEU_CS.model$URLPathPartRecord", ["exports", "OutSystems/ClientRuntime/Main", "Extension.FrameworkUtils.model", "ShopperPortalEU_CS.model", "Extension.FrameworkUtils.model$URLPathPartRec", "ShopperPortalEU_CS.referencesHealth", "ShopperPortalEU_CS.referencesHealth$FrameworkUtils"], function (exports, OutSystems, Extension_FrameworkUtilsModel, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var URLPathPartRecord = (function (_super) {
__extends(URLPathPartRecord, _super);
function URLPathPartRecord(defaults) {
_super.apply(this, arguments);
}
URLPathPartRecord.attributesToDeclare = function () {
return [
this.attr("URLPathPart", "uRLPathPartAttr", "URLPathPart", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new Extension_FrameworkUtilsModel.URLPathPartRec());
}, true, Extension_FrameworkUtilsModel.URLPathPartRec)
].concat(_super.attributesToDeclare.call(this));
};
URLPathPartRecord.fromStructure = function (str) {
return new URLPathPartRecord(new URLPathPartRecord.RecordClass({
uRLPathPartAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
URLPathPartRecord._isAnonymousRecord = true;
URLPathPartRecord.UniqueId = "67f88e6a-4b80-06dd-213e-85192df1eb31";
URLPathPartRecord.init();
return URLPathPartRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_CSModel.URLPathPartRecord = URLPathPartRecord;

});
define("ShopperPortalEU_CS.model$URLPathPartRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model", "ShopperPortalEU_CS.model$URLPathPartRecord"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var URLPathPartRecordList = (function (_super) {
__extends(URLPathPartRecordList, _super);
function URLPathPartRecordList(defaults) {
_super.apply(this, arguments);
}
URLPathPartRecordList.itemType = ShopperPortalEU_CSModel.URLPathPartRecord;
return URLPathPartRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_CSModel.URLPathPartRecordList = URLPathPartRecordList;

});
define("ShopperPortalEU_CS.model$SPCityRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var SPCityRec = (function (_super) {
__extends(SPCityRec, _super);
function SPCityRec(defaults) {
_super.apply(this, arguments);
}
SPCityRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true), 
this.attr("Name", "nameAttr", "Name", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("SPCountryId", "sPCountryIdAttr", "SPCountryId", false, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
SPCityRec.init();
return SPCityRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_CSModel.SPCityRec = SPCityRec;

});
define("ShopperPortalEU_CS.model$SPCountryRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var SPCountryRec = (function (_super) {
__extends(SPCountryRec, _super);
function SPCountryRec(defaults) {
_super.apply(this, arguments);
}
SPCountryRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true), 
this.attr("Name", "nameAttr", "Name", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Code2", "code2Attr", "Code2", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Code3", "code3Attr", "Code3", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Code3Digits", "code3DigitsAttr", "Code3Digits", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("CodePassport", "codePassportAttr", "CodePassport", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("DefaultLanguage", "defaultLanguageAttr", "DefaultLanguage", false, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true), 
this.attr("CultureCode", "cultureCodeAttr", "CultureCode", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("IsLocationsAndRulesAvailable", "isLocationsAndRulesAvailableAttr", "IsLocationsAndRulesAvailable", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
SPCountryRec.init();
return SPCountryRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_CSModel.SPCountryRec = SPCountryRec;

});
define("ShopperPortalEU_CS.model$SPCitySPCountryRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model", "ShopperPortalEU_CS.model$SPCityRec", "ShopperPortalEU_CS.model$SPCountryRec"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var SPCitySPCountryRecord = (function (_super) {
__extends(SPCitySPCountryRecord, _super);
function SPCitySPCountryRecord(defaults) {
_super.apply(this, arguments);
}
SPCitySPCountryRecord.attributesToDeclare = function () {
return [
this.attr("SPCity", "sPCityAttr", "SPCity", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_CSModel.SPCityRec());
}, true, ShopperPortalEU_CSModel.SPCityRec), 
this.attr("SPCountry", "sPCountryAttr", "SPCountry", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_CSModel.SPCountryRec());
}, true, ShopperPortalEU_CSModel.SPCountryRec)
].concat(_super.attributesToDeclare.call(this));
};
SPCitySPCountryRecord._isAnonymousRecord = true;
SPCitySPCountryRecord.UniqueId = "17dee97d-09e3-897c-9295-ce07df25f74f";
SPCitySPCountryRecord.init();
return SPCitySPCountryRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_CSModel.SPCitySPCountryRecord = SPCitySPCountryRecord;

});
define("ShopperPortalEU_CS.model$SPCity_InfoRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var SPCity_InfoRec = (function (_super) {
__extends(SPCity_InfoRec, _super);
function SPCity_InfoRec(defaults) {
_super.apply(this, arguments);
}
SPCity_InfoRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", false, false, OS.DataTypes.DataTypes.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("Name", "nameAttr", "Name", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
SPCity_InfoRec.init();
return SPCity_InfoRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_CSModel.SPCity_InfoRec = SPCity_InfoRec;

});
define("ShopperPortalEU_CS.model$SPCity_InfoList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model", "ShopperPortalEU_CS.model$SPCity_InfoRec"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var SPCity_InfoList = (function (_super) {
__extends(SPCity_InfoList, _super);
function SPCity_InfoList(defaults) {
_super.apply(this, arguments);
}
SPCity_InfoList.itemType = ShopperPortalEU_CSModel.SPCity_InfoRec;
return SPCity_InfoList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_CSModel.SPCity_InfoList = SPCity_InfoList;

});
define("ShopperPortalEU_CS.model$CardStateTypeList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_CS.model", "ShopperPortalEU_UI_Components.model$CardStateTypeRec", "ShopperPortalEU_CS.referencesHealth", "ShopperPortalEU_CS.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var CardStateTypeList = (function (_super) {
__extends(CardStateTypeList, _super);
function CardStateTypeList(defaults) {
_super.apply(this, arguments);
}
CardStateTypeList.itemType = ShopperPortalEU_UI_ComponentsModel.CardStateTypeRec;
return CardStateTypeList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_CSModel.CardStateTypeList = CardStateTypeList;

});
define("ShopperPortalEU_CS.model$CustomTagStateRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_CS.model", "ShopperPortalEU_UI_Components.model$CustomTagStateRec", "ShopperPortalEU_CS.referencesHealth", "ShopperPortalEU_CS.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var CustomTagStateRecord = (function (_super) {
__extends(CustomTagStateRecord, _super);
function CustomTagStateRecord(defaults) {
_super.apply(this, arguments);
}
CustomTagStateRecord.attributesToDeclare = function () {
return [
this.attr("CustomTagState", "customTagStateAttr", "CustomTagState", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomTagStateRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomTagStateRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomTagStateRecord.fromStructure = function (str) {
return new CustomTagStateRecord(new CustomTagStateRecord.RecordClass({
customTagStateAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomTagStateRecord._isAnonymousRecord = true;
CustomTagStateRecord.UniqueId = "257bb42e-a6a8-1fb0-b051-e88ca4f96cd4";
CustomTagStateRecord.init();
return CustomTagStateRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_CSModel.CustomTagStateRecord = CustomTagStateRecord;

});
define("ShopperPortalEU_CS.model$SPRefundOptionRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var SPRefundOptionRec = (function (_super) {
__extends(SPRefundOptionRec, _super);
function SPRefundOptionRec(defaults) {
_super.apply(this, arguments);
}
SPRefundOptionRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true), 
this.attr("Code", "codeAttr", "Code", true, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true), 
this.attr("Label", "labelAttr", "Label", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", true, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true), 
this.attr("Is_Active", "is_ActiveAttr", "Is_Active", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
SPRefundOptionRec.init();
return SPRefundOptionRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_CSModel.SPRefundOptionRec = SPRefundOptionRec;

});
define("ShopperPortalEU_CS.model$SPRefundOptionList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model", "ShopperPortalEU_CS.model$SPRefundOptionRec"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var SPRefundOptionList = (function (_super) {
__extends(SPRefundOptionList, _super);
function SPRefundOptionList(defaults) {
_super.apply(this, arguments);
}
SPRefundOptionList.itemType = ShopperPortalEU_CSModel.SPRefundOptionRec;
return SPRefundOptionList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_CSModel.SPRefundOptionList = SPRefundOptionList;

});
define("ShopperPortalEU_CS.model$SPRefundMessageRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var SPRefundMessageRec = (function (_super) {
__extends(SPRefundMessageRec, _super);
function SPRefundMessageRec(defaults) {
_super.apply(this, arguments);
}
SPRefundMessageRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true), 
this.attr("Label", "labelAttr", "Label", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", true, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true), 
this.attr("Is_Active", "is_ActiveAttr", "Is_Active", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
SPRefundMessageRec.init();
return SPRefundMessageRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_CSModel.SPRefundMessageRec = SPRefundMessageRec;

});
define("ShopperPortalEU_CS.model$ShopperDocumentTypeRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var ShopperDocumentTypeRec = (function (_super) {
__extends(ShopperDocumentTypeRec, _super);
function ShopperDocumentTypeRec(defaults) {
_super.apply(this, arguments);
}
ShopperDocumentTypeRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true), 
this.attr("ExternalCodePI", "externalCodePIAttr", "ExternalCodePI", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("LabelPI", "labelPIAttr", "LabelPI", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("ExternalCodeDTF", "externalCodeDTFAttr", "ExternalCodeDTF", true, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true), 
this.attr("LabelDTF", "labelDTFAttr", "LabelDTF", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", true, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true), 
this.attr("Is_Active", "is_ActiveAttr", "Is_Active", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ShopperDocumentTypeRec.init();
return ShopperDocumentTypeRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_CSModel.ShopperDocumentTypeRec = ShopperDocumentTypeRec;

});
define("ShopperPortalEU_CS.model$ShopperDocumentTypeRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model", "ShopperPortalEU_CS.model$ShopperDocumentTypeRec"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var ShopperDocumentTypeRecord = (function (_super) {
__extends(ShopperDocumentTypeRecord, _super);
function ShopperDocumentTypeRecord(defaults) {
_super.apply(this, arguments);
}
ShopperDocumentTypeRecord.attributesToDeclare = function () {
return [
this.attr("ShopperDocumentType", "shopperDocumentTypeAttr", "ShopperDocumentType", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_CSModel.ShopperDocumentTypeRec());
}, true, ShopperPortalEU_CSModel.ShopperDocumentTypeRec)
].concat(_super.attributesToDeclare.call(this));
};
ShopperDocumentTypeRecord.fromStructure = function (str) {
return new ShopperDocumentTypeRecord(new ShopperDocumentTypeRecord.RecordClass({
shopperDocumentTypeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ShopperDocumentTypeRecord._isAnonymousRecord = true;
ShopperDocumentTypeRecord.UniqueId = "beb91bc7-59b8-5e31-8df3-c57368e68113";
ShopperDocumentTypeRecord.init();
return ShopperDocumentTypeRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_CSModel.ShopperDocumentTypeRecord = ShopperDocumentTypeRecord;

});
define("ShopperPortalEU_CS.model$ShopperDocumentTypeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model", "ShopperPortalEU_CS.model$ShopperDocumentTypeRecord"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var ShopperDocumentTypeRecordList = (function (_super) {
__extends(ShopperDocumentTypeRecordList, _super);
function ShopperDocumentTypeRecordList(defaults) {
_super.apply(this, arguments);
}
ShopperDocumentTypeRecordList.itemType = ShopperPortalEU_CSModel.ShopperDocumentTypeRecord;
return ShopperDocumentTypeRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_CSModel.ShopperDocumentTypeRecordList = ShopperDocumentTypeRecordList;

});
define("ShopperPortalEU_CS.model$SPCountryRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model", "ShopperPortalEU_CS.model$SPCountryRec"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var SPCountryRecord = (function (_super) {
__extends(SPCountryRecord, _super);
function SPCountryRecord(defaults) {
_super.apply(this, arguments);
}
SPCountryRecord.attributesToDeclare = function () {
return [
this.attr("SPCountry", "sPCountryAttr", "SPCountry", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_CSModel.SPCountryRec());
}, true, ShopperPortalEU_CSModel.SPCountryRec)
].concat(_super.attributesToDeclare.call(this));
};
SPCountryRecord.fromStructure = function (str) {
return new SPCountryRecord(new SPCountryRecord.RecordClass({
sPCountryAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
SPCountryRecord._isAnonymousRecord = true;
SPCountryRecord.UniqueId = "2b0f0777-44ea-775d-7bca-4fae33292c2d";
SPCountryRecord.init();
return SPCountryRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_CSModel.SPCountryRecord = SPCountryRecord;

});
define("ShopperPortalEU_CS.model$SPFormStatusRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var SPFormStatusRec = (function (_super) {
__extends(SPFormStatusRec, _super);
function SPFormStatusRec(defaults) {
_super.apply(this, arguments);
}
SPFormStatusRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Label", "labelAttr", "Label", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", true, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true), 
this.attr("Is_Active", "is_ActiveAttr", "Is_Active", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("TagState", "tagStateAttr", "TagState", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("CardStateTypeId", "cardStateTypeIdAttr", "CardStateTypeId", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("RefundLabel_UIId", "refundLabel_UIIdAttr", "RefundLabel_UIId", false, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true), 
this.attr("RefundMessageId", "refundMessageIdAttr", "RefundMessageId", false, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true), 
this.attr("DisplayBarcode_UI", "displayBarcode_UIAttr", "DisplayBarcode_UI", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("DisplayViewForm_UI", "displayViewForm_UIAttr", "DisplayViewForm_UI", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("DisplayAdditionalInfo_UI", "displayAdditionalInfo_UIAttr", "DisplayAdditionalInfo_UI", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("DisplayRefundPaymentsInfo_UI", "displayRefundPaymentsInfo_UIAttr", "DisplayRefundPaymentsInfo_UI", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("HasRefundStepsPage", "hasRefundStepsPageAttr", "HasRefundStepsPage", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
SPFormStatusRec.init();
return SPFormStatusRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_CSModel.SPFormStatusRec = SPFormStatusRec;

});
define("ShopperPortalEU_CS.model$SPForm_InfoRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var SPForm_InfoRec = (function (_super) {
__extends(SPForm_InfoRec, _super);
function SPForm_InfoRec(defaults) {
_super.apply(this, arguments);
}
SPForm_InfoRec.attributesToDeclare = function () {
return [
this.attr("MerchantName", "merchantNameAttr", "MerchantName", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("FormDateTxt", "formDateTxtAttr", "FormDateTxt", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("IsEstimated", "isEstimatedAttr", "IsEstimated", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("RefundAmountTxt", "refundAmountTxtAttr", "RefundAmountTxt", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("RefundAmountMessage", "refundAmountMessageAttr", "RefundAmountMessage", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("FormStatusLabel", "formStatusLabelAttr", "FormStatusLabel", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("FormTagState", "formTagStateAttr", "FormTagState", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
SPForm_InfoRec.init();
return SPForm_InfoRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_CSModel.SPForm_InfoRec = SPForm_InfoRec;

});
define("ShopperPortalEU_CS.model$SPRefundMessageRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model", "ShopperPortalEU_CS.model$SPRefundMessageRec"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var SPRefundMessageRecord = (function (_super) {
__extends(SPRefundMessageRecord, _super);
function SPRefundMessageRecord(defaults) {
_super.apply(this, arguments);
}
SPRefundMessageRecord.attributesToDeclare = function () {
return [
this.attr("SPRefundMessage", "sPRefundMessageAttr", "SPRefundMessage", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_CSModel.SPRefundMessageRec());
}, true, ShopperPortalEU_CSModel.SPRefundMessageRec)
].concat(_super.attributesToDeclare.call(this));
};
SPRefundMessageRecord.fromStructure = function (str) {
return new SPRefundMessageRecord(new SPRefundMessageRecord.RecordClass({
sPRefundMessageAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
SPRefundMessageRecord._isAnonymousRecord = true;
SPRefundMessageRecord.UniqueId = "c725a529-f4bd-e633-ef32-1f8a50c355a5";
SPRefundMessageRecord.init();
return SPRefundMessageRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_CSModel.SPRefundMessageRecord = SPRefundMessageRecord;

});
define("ShopperPortalEU_CS.model$SPRefundMessageRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model", "ShopperPortalEU_CS.model$SPRefundMessageRecord"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var SPRefundMessageRecordList = (function (_super) {
__extends(SPRefundMessageRecordList, _super);
function SPRefundMessageRecordList(defaults) {
_super.apply(this, arguments);
}
SPRefundMessageRecordList.itemType = ShopperPortalEU_CSModel.SPRefundMessageRecord;
return SPRefundMessageRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_CSModel.SPRefundMessageRecordList = SPRefundMessageRecordList;

});
define("ShopperPortalEU_CS.model$SPFormStatusRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model", "ShopperPortalEU_CS.model$SPFormStatusRec"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var SPFormStatusRecord = (function (_super) {
__extends(SPFormStatusRecord, _super);
function SPFormStatusRecord(defaults) {
_super.apply(this, arguments);
}
SPFormStatusRecord.attributesToDeclare = function () {
return [
this.attr("SPFormStatus", "sPFormStatusAttr", "SPFormStatus", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_CSModel.SPFormStatusRec());
}, true, ShopperPortalEU_CSModel.SPFormStatusRec)
].concat(_super.attributesToDeclare.call(this));
};
SPFormStatusRecord.fromStructure = function (str) {
return new SPFormStatusRecord(new SPFormStatusRecord.RecordClass({
sPFormStatusAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
SPFormStatusRecord._isAnonymousRecord = true;
SPFormStatusRecord.UniqueId = "3e57435d-0124-13a2-dbac-617b836b9cf2";
SPFormStatusRecord.init();
return SPFormStatusRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_CSModel.SPFormStatusRecord = SPFormStatusRecord;

});
define("ShopperPortalEU_CS.model$RefundLabel_UIRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var RefundLabel_UIRec = (function (_super) {
__extends(RefundLabel_UIRec, _super);
function RefundLabel_UIRec(defaults) {
_super.apply(this, arguments);
}
RefundLabel_UIRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true), 
this.attr("Label", "labelAttr", "Label", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", true, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true), 
this.attr("Is_Active", "is_ActiveAttr", "Is_Active", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
RefundLabel_UIRec.init();
return RefundLabel_UIRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_CSModel.RefundLabel_UIRec = RefundLabel_UIRec;

});
define("ShopperPortalEU_CS.model$RefundLabel_UIRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model", "ShopperPortalEU_CS.model$RefundLabel_UIRec"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var RefundLabel_UIRecord = (function (_super) {
__extends(RefundLabel_UIRecord, _super);
function RefundLabel_UIRecord(defaults) {
_super.apply(this, arguments);
}
RefundLabel_UIRecord.attributesToDeclare = function () {
return [
this.attr("RefundLabel_UI", "refundLabel_UIAttr", "RefundLabel_UI", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_CSModel.RefundLabel_UIRec());
}, true, ShopperPortalEU_CSModel.RefundLabel_UIRec)
].concat(_super.attributesToDeclare.call(this));
};
RefundLabel_UIRecord.fromStructure = function (str) {
return new RefundLabel_UIRecord(new RefundLabel_UIRecord.RecordClass({
refundLabel_UIAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
RefundLabel_UIRecord._isAnonymousRecord = true;
RefundLabel_UIRecord.UniqueId = "59c36fdb-dc19-a899-e68a-9ea1e6db4ff6";
RefundLabel_UIRecord.init();
return RefundLabel_UIRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_CSModel.RefundLabel_UIRecord = RefundLabel_UIRecord;

});
define("ShopperPortalEU_CS.model$RefundLabel_UIRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model", "ShopperPortalEU_CS.model$RefundLabel_UIRecord"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var RefundLabel_UIRecordList = (function (_super) {
__extends(RefundLabel_UIRecordList, _super);
function RefundLabel_UIRecordList(defaults) {
_super.apply(this, arguments);
}
RefundLabel_UIRecordList.itemType = ShopperPortalEU_CSModel.RefundLabel_UIRecord;
return RefundLabel_UIRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_CSModel.RefundLabel_UIRecordList = RefundLabel_UIRecordList;

});
define("ShopperPortalEU_CS.model$SPFormStatus_InfoRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var SPFormStatus_InfoRec = (function (_super) {
__extends(SPFormStatus_InfoRec, _super);
function SPFormStatus_InfoRec(defaults) {
_super.apply(this, arguments);
}
SPFormStatus_InfoRec.attributesToDeclare = function () {
return [
this.attr("Label", "labelAttr", "Label", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("RefundLabel_UI", "refundLabel_UIAttr", "RefundLabel_UI", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("TagState", "tagStateAttr", "TagState", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("CardStateTypeId", "cardStateTypeIdAttr", "CardStateTypeId", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("RefundAmountMessage", "refundAmountMessageAttr", "RefundAmountMessage", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("DisplayBarcode_UI", "displayBarcode_UIAttr", "DisplayBarcode_UI", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("DisplayViewForm_UI", "displayViewForm_UIAttr", "DisplayViewForm_UI", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("DisplayAdditionalInfo_UI", "displayAdditionalInfo_UIAttr", "DisplayAdditionalInfo_UI", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("FormStatusId", "formStatusIdAttr", "FormStatusId", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("DisplayRefundPaymentsInfo_UI", "displayRefundPaymentsInfo_UIAttr", "DisplayRefundPaymentsInfo_UI", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("HasRefundStepsPage", "hasRefundStepsPageAttr", "HasRefundStepsPage", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
SPFormStatus_InfoRec.init();
return SPFormStatus_InfoRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_CSModel.SPFormStatus_InfoRec = SPFormStatus_InfoRec;

});
define("ShopperPortalEU_CS.model$SPFormStatus_InfoRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model", "ShopperPortalEU_CS.model$SPFormStatus_InfoRec"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var SPFormStatus_InfoRecord = (function (_super) {
__extends(SPFormStatus_InfoRecord, _super);
function SPFormStatus_InfoRecord(defaults) {
_super.apply(this, arguments);
}
SPFormStatus_InfoRecord.attributesToDeclare = function () {
return [
this.attr("SPFormStatus_Info", "sPFormStatus_InfoAttr", "SPFormStatus_Info", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_CSModel.SPFormStatus_InfoRec());
}, true, ShopperPortalEU_CSModel.SPFormStatus_InfoRec)
].concat(_super.attributesToDeclare.call(this));
};
SPFormStatus_InfoRecord.fromStructure = function (str) {
return new SPFormStatus_InfoRecord(new SPFormStatus_InfoRecord.RecordClass({
sPFormStatus_InfoAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
SPFormStatus_InfoRecord._isAnonymousRecord = true;
SPFormStatus_InfoRecord.UniqueId = "dfff159d-f514-f63c-0717-17ce31743aaf";
SPFormStatus_InfoRecord.init();
return SPFormStatus_InfoRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_CSModel.SPFormStatus_InfoRecord = SPFormStatus_InfoRecord;

});
define("ShopperPortalEU_CS.model$SPFormStatus_InfoRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model", "ShopperPortalEU_CS.model$SPFormStatus_InfoRecord"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var SPFormStatus_InfoRecordList = (function (_super) {
__extends(SPFormStatus_InfoRecordList, _super);
function SPFormStatus_InfoRecordList(defaults) {
_super.apply(this, arguments);
}
SPFormStatus_InfoRecordList.itemType = ShopperPortalEU_CSModel.SPFormStatus_InfoRecord;
return SPFormStatus_InfoRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_CSModel.SPFormStatus_InfoRecordList = SPFormStatus_InfoRecordList;

});
define("ShopperPortalEU_CS.model$SPCountryList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model", "ShopperPortalEU_CS.model$SPCountryRec"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var SPCountryList = (function (_super) {
__extends(SPCountryList, _super);
function SPCountryList(defaults) {
_super.apply(this, arguments);
}
SPCountryList.itemType = ShopperPortalEU_CSModel.SPCountryRec;
return SPCountryList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_CSModel.SPCountryList = SPCountryList;

});
define("ShopperPortalEU_CS.model$URLDetailsRecord", ["exports", "OutSystems/ClientRuntime/Main", "Extension.FrameworkUtils.model", "ShopperPortalEU_CS.model", "Extension.FrameworkUtils.model$URLDetailsRec", "ShopperPortalEU_CS.referencesHealth", "ShopperPortalEU_CS.referencesHealth$FrameworkUtils"], function (exports, OutSystems, Extension_FrameworkUtilsModel, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var URLDetailsRecord = (function (_super) {
__extends(URLDetailsRecord, _super);
function URLDetailsRecord(defaults) {
_super.apply(this, arguments);
}
URLDetailsRecord.attributesToDeclare = function () {
return [
this.attr("URLDetails", "uRLDetailsAttr", "URLDetails", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new Extension_FrameworkUtilsModel.URLDetailsRec());
}, true, Extension_FrameworkUtilsModel.URLDetailsRec)
].concat(_super.attributesToDeclare.call(this));
};
URLDetailsRecord.fromStructure = function (str) {
return new URLDetailsRecord(new URLDetailsRecord.RecordClass({
uRLDetailsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
URLDetailsRecord._isAnonymousRecord = true;
URLDetailsRecord.UniqueId = "4ea76ab8-0da0-b4f0-c924-dda290b405d8";
URLDetailsRecord.init();
return URLDetailsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_CSModel.URLDetailsRecord = URLDetailsRecord;

});
define("ShopperPortalEU_CS.model$SPCityList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model", "ShopperPortalEU_CS.model$SPCityRec"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var SPCityList = (function (_super) {
__extends(SPCityList, _super);
function SPCityList(defaults) {
_super.apply(this, arguments);
}
SPCityList.itemType = ShopperPortalEU_CSModel.SPCityRec;
return SPCityList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_CSModel.SPCityList = SPCityList;

});
define("ShopperPortalEU_CS.model$RefundLabel_UISPRefundMessageSPFormStatusRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model", "ShopperPortalEU_CS.model$RefundLabel_UIRec", "ShopperPortalEU_CS.model$SPRefundMessageRec", "ShopperPortalEU_CS.model$SPFormStatusRec"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var RefundLabel_UISPRefundMessageSPFormStatusRecord = (function (_super) {
__extends(RefundLabel_UISPRefundMessageSPFormStatusRecord, _super);
function RefundLabel_UISPRefundMessageSPFormStatusRecord(defaults) {
_super.apply(this, arguments);
}
RefundLabel_UISPRefundMessageSPFormStatusRecord.attributesToDeclare = function () {
return [
this.attr("RefundLabel_UI", "refundLabel_UIAttr", "RefundLabel_UI", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_CSModel.RefundLabel_UIRec());
}, true, ShopperPortalEU_CSModel.RefundLabel_UIRec), 
this.attr("SPRefundMessage", "sPRefundMessageAttr", "SPRefundMessage", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_CSModel.SPRefundMessageRec());
}, true, ShopperPortalEU_CSModel.SPRefundMessageRec), 
this.attr("SPFormStatus", "sPFormStatusAttr", "SPFormStatus", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_CSModel.SPFormStatusRec());
}, true, ShopperPortalEU_CSModel.SPFormStatusRec)
].concat(_super.attributesToDeclare.call(this));
};
RefundLabel_UISPRefundMessageSPFormStatusRecord._isAnonymousRecord = true;
RefundLabel_UISPRefundMessageSPFormStatusRecord.UniqueId = "61197951-fbc7-ea40-f4cc-41c690fd9dcb";
RefundLabel_UISPRefundMessageSPFormStatusRecord.init();
return RefundLabel_UISPRefundMessageSPFormStatusRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_CSModel.RefundLabel_UISPRefundMessageSPFormStatusRecord = RefundLabel_UISPRefundMessageSPFormStatusRecord;

});
define("ShopperPortalEU_CS.model$SPForm_InfoList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model", "ShopperPortalEU_CS.model$SPForm_InfoRec"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var SPForm_InfoList = (function (_super) {
__extends(SPForm_InfoList, _super);
function SPForm_InfoList(defaults) {
_super.apply(this, arguments);
}
SPForm_InfoList.itemType = ShopperPortalEU_CSModel.SPForm_InfoRec;
return SPForm_InfoList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_CSModel.SPForm_InfoList = SPForm_InfoList;

});
define("ShopperPortalEU_CS.model$CustomTagStateRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model", "ShopperPortalEU_CS.model$CustomTagStateRecord"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var CustomTagStateRecordList = (function (_super) {
__extends(CustomTagStateRecordList, _super);
function CustomTagStateRecordList(defaults) {
_super.apply(this, arguments);
}
CustomTagStateRecordList.itemType = ShopperPortalEU_CSModel.CustomTagStateRecord;
return CustomTagStateRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_CSModel.CustomTagStateRecordList = CustomTagStateRecordList;

});
define("ShopperPortalEU_CS.model$CardStateTypeRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_CS.model", "ShopperPortalEU_UI_Components.model$CardStateTypeRec", "ShopperPortalEU_CS.referencesHealth", "ShopperPortalEU_CS.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var CardStateTypeRecord = (function (_super) {
__extends(CardStateTypeRecord, _super);
function CardStateTypeRecord(defaults) {
_super.apply(this, arguments);
}
CardStateTypeRecord.attributesToDeclare = function () {
return [
this.attr("CardStateType", "cardStateTypeAttr", "CardStateType", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CardStateTypeRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CardStateTypeRec)
].concat(_super.attributesToDeclare.call(this));
};
CardStateTypeRecord.fromStructure = function (str) {
return new CardStateTypeRecord(new CardStateTypeRecord.RecordClass({
cardStateTypeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CardStateTypeRecord._isAnonymousRecord = true;
CardStateTypeRecord.UniqueId = "b7d7feb7-5b30-ca61-c992-48b012ab0684";
CardStateTypeRecord.init();
return CardStateTypeRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_CSModel.CardStateTypeRecord = CardStateTypeRecord;

});
define("ShopperPortalEU_CS.model$CardStateTypeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model", "ShopperPortalEU_CS.model$CardStateTypeRecord"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var CardStateTypeRecordList = (function (_super) {
__extends(CardStateTypeRecordList, _super);
function CardStateTypeRecordList(defaults) {
_super.apply(this, arguments);
}
CardStateTypeRecordList.itemType = ShopperPortalEU_CSModel.CardStateTypeRecord;
return CardStateTypeRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_CSModel.CardStateTypeRecordList = CardStateTypeRecordList;

});
define("ShopperPortalEU_CS.model$SPRefundOptionRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model", "ShopperPortalEU_CS.model$SPRefundOptionRec"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var SPRefundOptionRecord = (function (_super) {
__extends(SPRefundOptionRecord, _super);
function SPRefundOptionRecord(defaults) {
_super.apply(this, arguments);
}
SPRefundOptionRecord.attributesToDeclare = function () {
return [
this.attr("SPRefundOption", "sPRefundOptionAttr", "SPRefundOption", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_CSModel.SPRefundOptionRec());
}, true, ShopperPortalEU_CSModel.SPRefundOptionRec)
].concat(_super.attributesToDeclare.call(this));
};
SPRefundOptionRecord.fromStructure = function (str) {
return new SPRefundOptionRecord(new SPRefundOptionRecord.RecordClass({
sPRefundOptionAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
SPRefundOptionRecord._isAnonymousRecord = true;
SPRefundOptionRecord.UniqueId = "b6b388aa-ad5c-0123-e07b-bd5e93d557d3";
SPRefundOptionRecord.init();
return SPRefundOptionRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_CSModel.SPRefundOptionRecord = SPRefundOptionRecord;

});
define("ShopperPortalEU_CS.model$SPRefundOptionRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model", "ShopperPortalEU_CS.model$SPRefundOptionRecord"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var SPRefundOptionRecordList = (function (_super) {
__extends(SPRefundOptionRecordList, _super);
function SPRefundOptionRecordList(defaults) {
_super.apply(this, arguments);
}
SPRefundOptionRecordList.itemType = ShopperPortalEU_CSModel.SPRefundOptionRecord;
return SPRefundOptionRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_CSModel.SPRefundOptionRecordList = SPRefundOptionRecordList;

});
define("ShopperPortalEU_CS.model$ShopperDocumentTypeList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model", "ShopperPortalEU_CS.model$ShopperDocumentTypeRec"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var ShopperDocumentTypeList = (function (_super) {
__extends(ShopperDocumentTypeList, _super);
function ShopperDocumentTypeList(defaults) {
_super.apply(this, arguments);
}
ShopperDocumentTypeList.itemType = ShopperPortalEU_CSModel.ShopperDocumentTypeRec;
return ShopperDocumentTypeList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_CSModel.ShopperDocumentTypeList = ShopperDocumentTypeList;

});
define("ShopperPortalEU_CS.model$CustomTagStateList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_CS.model", "ShopperPortalEU_UI_Components.model$CustomTagStateRec", "ShopperPortalEU_CS.referencesHealth", "ShopperPortalEU_CS.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var CustomTagStateList = (function (_super) {
__extends(CustomTagStateList, _super);
function CustomTagStateList(defaults) {
_super.apply(this, arguments);
}
CustomTagStateList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomTagStateRec;
return CustomTagStateList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_CSModel.CustomTagStateList = CustomTagStateList;

});
define("ShopperPortalEU_CS.model$SPCurrencyRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var SPCurrencyRec = (function (_super) {
__extends(SPCurrencyRec, _super);
function SPCurrencyRec(defaults) {
_super.apply(this, arguments);
}
SPCurrencyRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true), 
this.attr("Code", "codeAttr", "Code", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Name", "nameAttr", "Name", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Symbol", "symbolAttr", "Symbol", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("IsActive", "isActiveAttr", "IsActive", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("NumericCode", "numericCodeAttr", "NumericCode", false, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true), 
this.attr("DecimalDigits", "decimalDigitsAttr", "DecimalDigits", false, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true), 
this.attr("ExcelFormat", "excelFormatAttr", "ExcelFormat", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
SPCurrencyRec.init();
return SPCurrencyRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_CSModel.SPCurrencyRec = SPCurrencyRec;

});
define("ShopperPortalEU_CS.model$SPCurrencyRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model", "ShopperPortalEU_CS.model$SPCurrencyRec"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var SPCurrencyRecord = (function (_super) {
__extends(SPCurrencyRecord, _super);
function SPCurrencyRecord(defaults) {
_super.apply(this, arguments);
}
SPCurrencyRecord.attributesToDeclare = function () {
return [
this.attr("SPCurrency", "sPCurrencyAttr", "SPCurrency", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_CSModel.SPCurrencyRec());
}, true, ShopperPortalEU_CSModel.SPCurrencyRec)
].concat(_super.attributesToDeclare.call(this));
};
SPCurrencyRecord.fromStructure = function (str) {
return new SPCurrencyRecord(new SPCurrencyRecord.RecordClass({
sPCurrencyAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
SPCurrencyRecord._isAnonymousRecord = true;
SPCurrencyRecord.UniqueId = "79058cb2-5865-4a2c-6a5b-2e3d4f43c888";
SPCurrencyRecord.init();
return SPCurrencyRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_CSModel.SPCurrencyRecord = SPCurrencyRecord;

});
define("ShopperPortalEU_CS.model$SPLanguageRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var SPLanguageRec = (function (_super) {
__extends(SPLanguageRec, _super);
function SPLanguageRec(defaults) {
_super.apply(this, arguments);
}
SPLanguageRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true), 
this.attr("Label", "labelAttr", "Label", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("CurrentLabel", "currentLabelAttr", "CurrentLabel", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Locale", "localeAttr", "Locale", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("VirtualDirectory", "virtualDirectoryAttr", "VirtualDirectory", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("IsActive", "isActiveAttr", "IsActive", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return true;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
SPLanguageRec.init();
return SPLanguageRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_CSModel.SPLanguageRec = SPLanguageRec;

});
define("ShopperPortalEU_CS.model$SPLanguageRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model", "ShopperPortalEU_CS.model$SPLanguageRec"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var SPLanguageRecord = (function (_super) {
__extends(SPLanguageRecord, _super);
function SPLanguageRecord(defaults) {
_super.apply(this, arguments);
}
SPLanguageRecord.attributesToDeclare = function () {
return [
this.attr("SPLanguage", "sPLanguageAttr", "SPLanguage", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_CSModel.SPLanguageRec());
}, true, ShopperPortalEU_CSModel.SPLanguageRec)
].concat(_super.attributesToDeclare.call(this));
};
SPLanguageRecord.fromStructure = function (str) {
return new SPLanguageRecord(new SPLanguageRecord.RecordClass({
sPLanguageAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
SPLanguageRecord._isAnonymousRecord = true;
SPLanguageRecord.UniqueId = "85bde68e-78a9-98b0-ab66-e80ffe32f470";
SPLanguageRecord.init();
return SPLanguageRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_CSModel.SPLanguageRecord = SPLanguageRecord;

});
define("ShopperPortalEU_CS.model$SPLanguageRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model", "ShopperPortalEU_CS.model$SPLanguageRecord"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var SPLanguageRecordList = (function (_super) {
__extends(SPLanguageRecordList, _super);
function SPLanguageRecordList(defaults) {
_super.apply(this, arguments);
}
SPLanguageRecordList.itemType = ShopperPortalEU_CSModel.SPLanguageRecord;
return SPLanguageRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_CSModel.SPLanguageRecordList = SPLanguageRecordList;

});
define("ShopperPortalEU_CS.model$SPCitySPCountryRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model", "ShopperPortalEU_CS.model$SPCitySPCountryRecord"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var SPCitySPCountryRecordList = (function (_super) {
__extends(SPCitySPCountryRecordList, _super);
function SPCitySPCountryRecordList(defaults) {
_super.apply(this, arguments);
}
SPCitySPCountryRecordList.itemType = ShopperPortalEU_CSModel.SPCitySPCountryRecord;
return SPCitySPCountryRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_CSModel.SPCitySPCountryRecordList = SPCitySPCountryRecordList;

});
define("ShopperPortalEU_CS.model$SPFormStatusList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model", "ShopperPortalEU_CS.model$SPFormStatusRec"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var SPFormStatusList = (function (_super) {
__extends(SPFormStatusList, _super);
function SPFormStatusList(defaults) {
_super.apply(this, arguments);
}
SPFormStatusList.itemType = ShopperPortalEU_CSModel.SPFormStatusRec;
return SPFormStatusList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_CSModel.SPFormStatusList = SPFormStatusList;

});
define("ShopperPortalEU_CS.model$RefundLabel_UIList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model", "ShopperPortalEU_CS.model$RefundLabel_UIRec"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var RefundLabel_UIList = (function (_super) {
__extends(RefundLabel_UIList, _super);
function RefundLabel_UIList(defaults) {
_super.apply(this, arguments);
}
RefundLabel_UIList.itemType = ShopperPortalEU_CSModel.RefundLabel_UIRec;
return RefundLabel_UIList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_CSModel.RefundLabel_UIList = RefundLabel_UIList;

});
define("ShopperPortalEU_CS.model$URLPathPartList", ["exports", "OutSystems/ClientRuntime/Main", "Extension.FrameworkUtils.model", "ShopperPortalEU_CS.model", "Extension.FrameworkUtils.model$URLPathPartRec", "ShopperPortalEU_CS.referencesHealth", "ShopperPortalEU_CS.referencesHealth$FrameworkUtils"], function (exports, OutSystems, Extension_FrameworkUtilsModel, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var URLPathPartList = (function (_super) {
__extends(URLPathPartList, _super);
function URLPathPartList(defaults) {
_super.apply(this, arguments);
}
URLPathPartList.itemType = Extension_FrameworkUtilsModel.URLPathPartRec;
return URLPathPartList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_CSModel.URLPathPartList = URLPathPartList;

});
define("ShopperPortalEU_CS.model$SPForm_InfoRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model", "ShopperPortalEU_CS.model$SPForm_InfoRec"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var SPForm_InfoRecord = (function (_super) {
__extends(SPForm_InfoRecord, _super);
function SPForm_InfoRecord(defaults) {
_super.apply(this, arguments);
}
SPForm_InfoRecord.attributesToDeclare = function () {
return [
this.attr("SPForm_Info", "sPForm_InfoAttr", "SPForm_Info", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_CSModel.SPForm_InfoRec());
}, true, ShopperPortalEU_CSModel.SPForm_InfoRec)
].concat(_super.attributesToDeclare.call(this));
};
SPForm_InfoRecord.fromStructure = function (str) {
return new SPForm_InfoRecord(new SPForm_InfoRecord.RecordClass({
sPForm_InfoAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
SPForm_InfoRecord._isAnonymousRecord = true;
SPForm_InfoRecord.UniqueId = "a44a2385-aeb6-51d3-ae3b-1131bc6cf266";
SPForm_InfoRecord.init();
return SPForm_InfoRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_CSModel.SPForm_InfoRecord = SPForm_InfoRecord;

});
define("ShopperPortalEU_CS.model$SPCityRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model", "ShopperPortalEU_CS.model$SPCityRec"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var SPCityRecord = (function (_super) {
__extends(SPCityRecord, _super);
function SPCityRecord(defaults) {
_super.apply(this, arguments);
}
SPCityRecord.attributesToDeclare = function () {
return [
this.attr("SPCity", "sPCityAttr", "SPCity", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_CSModel.SPCityRec());
}, true, ShopperPortalEU_CSModel.SPCityRec)
].concat(_super.attributesToDeclare.call(this));
};
SPCityRecord.fromStructure = function (str) {
return new SPCityRecord(new SPCityRecord.RecordClass({
sPCityAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
SPCityRecord._isAnonymousRecord = true;
SPCityRecord.UniqueId = "adedfcfd-f70c-5bd3-dbd2-024a272490c5";
SPCityRecord.init();
return SPCityRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_CSModel.SPCityRecord = SPCityRecord;

});
define("ShopperPortalEU_CS.model$SPCityRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model", "ShopperPortalEU_CS.model$SPCityRecord"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var SPCityRecordList = (function (_super) {
__extends(SPCityRecordList, _super);
function SPCityRecordList(defaults) {
_super.apply(this, arguments);
}
SPCityRecordList.itemType = ShopperPortalEU_CSModel.SPCityRecord;
return SPCityRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_CSModel.SPCityRecordList = SPCityRecordList;

});
define("ShopperPortalEU_CS.model$SPRefundMessageList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model", "ShopperPortalEU_CS.model$SPRefundMessageRec"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var SPRefundMessageList = (function (_super) {
__extends(SPRefundMessageList, _super);
function SPRefundMessageList(defaults) {
_super.apply(this, arguments);
}
SPRefundMessageList.itemType = ShopperPortalEU_CSModel.SPRefundMessageRec;
return SPRefundMessageList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_CSModel.SPRefundMessageList = SPRefundMessageList;

});
define("ShopperPortalEU_CS.model$SPFormStatusRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model", "ShopperPortalEU_CS.model$SPFormStatusRecord"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var SPFormStatusRecordList = (function (_super) {
__extends(SPFormStatusRecordList, _super);
function SPFormStatusRecordList(defaults) {
_super.apply(this, arguments);
}
SPFormStatusRecordList.itemType = ShopperPortalEU_CSModel.SPFormStatusRecord;
return SPFormStatusRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_CSModel.SPFormStatusRecordList = SPFormStatusRecordList;

});
define("ShopperPortalEU_CS.model$RefundLabel_UISPRefundMessageSPFormStatusRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model", "ShopperPortalEU_CS.model$RefundLabel_UISPRefundMessageSPFormStatusRecord"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var RefundLabel_UISPRefundMessageSPFormStatusRecordList = (function (_super) {
__extends(RefundLabel_UISPRefundMessageSPFormStatusRecordList, _super);
function RefundLabel_UISPRefundMessageSPFormStatusRecordList(defaults) {
_super.apply(this, arguments);
}
RefundLabel_UISPRefundMessageSPFormStatusRecordList.itemType = ShopperPortalEU_CSModel.RefundLabel_UISPRefundMessageSPFormStatusRecord;
return RefundLabel_UISPRefundMessageSPFormStatusRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_CSModel.RefundLabel_UISPRefundMessageSPFormStatusRecordList = RefundLabel_UISPRefundMessageSPFormStatusRecordList;

});
define("ShopperPortalEU_CS.model$SPCountryRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model", "ShopperPortalEU_CS.model$SPCountryRecord"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var SPCountryRecordList = (function (_super) {
__extends(SPCountryRecordList, _super);
function SPCountryRecordList(defaults) {
_super.apply(this, arguments);
}
SPCountryRecordList.itemType = ShopperPortalEU_CSModel.SPCountryRecord;
return SPCountryRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_CSModel.SPCountryRecordList = SPCountryRecordList;

});
define("ShopperPortalEU_CS.model$URLDetailsList", ["exports", "OutSystems/ClientRuntime/Main", "Extension.FrameworkUtils.model", "ShopperPortalEU_CS.model", "Extension.FrameworkUtils.model$URLDetailsRec", "ShopperPortalEU_CS.referencesHealth", "ShopperPortalEU_CS.referencesHealth$FrameworkUtils"], function (exports, OutSystems, Extension_FrameworkUtilsModel, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var URLDetailsList = (function (_super) {
__extends(URLDetailsList, _super);
function URLDetailsList(defaults) {
_super.apply(this, arguments);
}
URLDetailsList.itemType = Extension_FrameworkUtilsModel.URLDetailsRec;
return URLDetailsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_CSModel.URLDetailsList = URLDetailsList;

});
define("ShopperPortalEU_CS.model$SPCurrencyRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model", "ShopperPortalEU_CS.model$SPCurrencyRecord"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var SPCurrencyRecordList = (function (_super) {
__extends(SPCurrencyRecordList, _super);
function SPCurrencyRecordList(defaults) {
_super.apply(this, arguments);
}
SPCurrencyRecordList.itemType = ShopperPortalEU_CSModel.SPCurrencyRecord;
return SPCurrencyRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_CSModel.SPCurrencyRecordList = SPCurrencyRecordList;

});
define("ShopperPortalEU_CS.model$SPLanguageList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model", "ShopperPortalEU_CS.model$SPLanguageRec"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var SPLanguageList = (function (_super) {
__extends(SPLanguageList, _super);
function SPLanguageList(defaults) {
_super.apply(this, arguments);
}
SPLanguageList.itemType = ShopperPortalEU_CSModel.SPLanguageRec;
return SPLanguageList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_CSModel.SPLanguageList = SPLanguageList;

});
define("ShopperPortalEU_CS.model$SPCity_InfoRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model", "ShopperPortalEU_CS.model$SPCity_InfoRec"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var SPCity_InfoRecord = (function (_super) {
__extends(SPCity_InfoRecord, _super);
function SPCity_InfoRecord(defaults) {
_super.apply(this, arguments);
}
SPCity_InfoRecord.attributesToDeclare = function () {
return [
this.attr("SPCity_Info", "sPCity_InfoAttr", "SPCity_Info", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_CSModel.SPCity_InfoRec());
}, true, ShopperPortalEU_CSModel.SPCity_InfoRec)
].concat(_super.attributesToDeclare.call(this));
};
SPCity_InfoRecord.fromStructure = function (str) {
return new SPCity_InfoRecord(new SPCity_InfoRecord.RecordClass({
sPCity_InfoAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
SPCity_InfoRecord._isAnonymousRecord = true;
SPCity_InfoRecord.UniqueId = "f47ab37a-fba0-645e-5cd9-490bcf4be7ee";
SPCity_InfoRecord.init();
return SPCity_InfoRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_CSModel.SPCity_InfoRecord = SPCity_InfoRecord;

});
define("ShopperPortalEU_CS.model$SPCity_InfoRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model", "ShopperPortalEU_CS.model$SPCity_InfoRecord"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var SPCity_InfoRecordList = (function (_super) {
__extends(SPCity_InfoRecordList, _super);
function SPCity_InfoRecordList(defaults) {
_super.apply(this, arguments);
}
SPCity_InfoRecordList.itemType = ShopperPortalEU_CSModel.SPCity_InfoRecord;
return SPCity_InfoRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_CSModel.SPCity_InfoRecordList = SPCity_InfoRecordList;

});
define("ShopperPortalEU_CS.model$SPCurrencyList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model", "ShopperPortalEU_CS.model$SPCurrencyRec"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var SPCurrencyList = (function (_super) {
__extends(SPCurrencyList, _super);
function SPCurrencyList(defaults) {
_super.apply(this, arguments);
}
SPCurrencyList.itemType = ShopperPortalEU_CSModel.SPCurrencyRec;
return SPCurrencyList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_CSModel.SPCurrencyList = SPCurrencyList;

});
define("ShopperPortalEU_CS.model$SPFormStatus_InfoList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model", "ShopperPortalEU_CS.model$SPFormStatus_InfoRec"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var SPFormStatus_InfoList = (function (_super) {
__extends(SPFormStatus_InfoList, _super);
function SPFormStatus_InfoList(defaults) {
_super.apply(this, arguments);
}
SPFormStatus_InfoList.itemType = ShopperPortalEU_CSModel.SPFormStatus_InfoRec;
return SPFormStatus_InfoList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_CSModel.SPFormStatus_InfoList = SPFormStatus_InfoList;

});
define("ShopperPortalEU_CS.model$URLDetailsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model", "ShopperPortalEU_CS.model$URLDetailsRecord"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var URLDetailsRecordList = (function (_super) {
__extends(URLDetailsRecordList, _super);
function URLDetailsRecordList(defaults) {
_super.apply(this, arguments);
}
URLDetailsRecordList.itemType = ShopperPortalEU_CSModel.URLDetailsRecord;
return URLDetailsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_CSModel.URLDetailsRecordList = URLDetailsRecordList;

});
define("ShopperPortalEU_CS.model$SPForm_InfoRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model", "ShopperPortalEU_CS.model$SPForm_InfoRecord"], function (exports, OutSystems, ShopperPortalEU_CSModel) {
var OS = OutSystems.Internal;
var SPForm_InfoRecordList = (function (_super) {
__extends(SPForm_InfoRecordList, _super);
function SPForm_InfoRecordList(defaults) {
_super.apply(this, arguments);
}
SPForm_InfoRecordList.itemType = ShopperPortalEU_CSModel.SPForm_InfoRecord;
return SPForm_InfoRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_CSModel.SPForm_InfoRecordList = SPForm_InfoRecordList;

});
define("ShopperPortalEU_CS.model", ["exports", "OutSystems/ClientRuntime/Main"], function (exports, OutSystems) {
var OS = OutSystems.Internal;
var ShopperPortalEU_CSModel = exports;
Object.defineProperty(ShopperPortalEU_CSModel, "module", {
get: function () {
return OS.ApplicationInfo.getModules()["5f9664ac-af6d-4553-af07-ef3e366dfe88"];
}
});

ShopperPortalEU_CSModel.staticEntities = {};
ShopperPortalEU_CSModel.staticEntities.sPCurrency = {};
var getSPCurrencyRecord = function (record) {
return ShopperPortalEU_CSModel.module.staticEntities["33fed800-4739-4224-8c2d-ec18c8c61efe"][record];
};
Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCurrency, "jPY", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCurrencyRecord("01ffa110-1ec1-4ffe-85e0-66543940374a"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCurrency, "cNY", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCurrencyRecord("0b1fb8a7-57a6-4477-acf4-15a1cbdf38fb"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCurrency, "uSD", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCurrencyRecord("12c82051-a7f4-402d-a8a1-3d2091a9584e"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCurrency, "sGD", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCurrencyRecord("14efcd1d-89a0-4b74-aecc-188ad4d44ff6"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCurrency, "hRK", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCurrencyRecord("1d37cb41-1590-478e-a222-8e8d22ff2aca"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCurrency, "nGN", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCurrencyRecord("23b501df-9a04-47f3-a28d-185ac77a8376"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCurrency, "cAD", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCurrencyRecord("23bb47a3-f127-4e9f-abb5-38a88be7c764"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCurrency, "nOK", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCurrencyRecord("309c5009-6da8-4395-bff2-4caec1a45b07"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCurrency, "iNR", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCurrencyRecord("33a36446-8f9e-4119-b725-f9c0ea86331f"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCurrency, "eGP", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCurrencyRecord("38180ff1-3fca-4f23-8d97-8d321b5b581a"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCurrency, "hKD", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCurrencyRecord("42af0b88-6d60-4c42-8f4c-5a4b783768c9"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCurrency, "sAR", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCurrencyRecord("4b94f300-8cf9-47e6-bc96-b868a8464ab7"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCurrency, "pLN", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCurrencyRecord("5ca0e75c-19cb-4305-9cf0-72604bffeb27"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCurrency, "bND", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCurrencyRecord("5dbd3cd0-8114-4670-8045-e7ef0b73e211"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCurrency, "eUR", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCurrencyRecord("5ffc323c-39cd-4afa-8d9c-fdd3105c12de"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCurrency, "sEK", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCurrencyRecord("695711cd-ade7-4524-a55e-a0658cc67469"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCurrency, "tHB", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCurrencyRecord("77270c1c-7388-460d-aa54-c960569a62e8"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCurrency, "iDR", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCurrencyRecord("7820ba7f-3829-4209-b462-e32ec42ccc22"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCurrency, "nZD", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCurrencyRecord("83782118-131d-43a4-b6d6-75a65f32ee83"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCurrency, "bGN", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCurrencyRecord("87dae782-f63e-42de-bfe8-df9e41dddc95"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCurrency, "gBP", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCurrencyRecord("8c5ffe20-0c68-4bac-b83d-a152bc2a8182"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCurrency, "aED", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCurrencyRecord("8de8afcb-35b2-4379-8f03-ea0e49ff0ec1"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCurrency, "iSK", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCurrencyRecord("95a2543b-08c5-4a43-a716-054e4b5641e0"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCurrency, "cHF", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCurrencyRecord("97f8aa48-947f-4d80-852d-5fc4490b1f55"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCurrency, "hUF", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCurrencyRecord("99afd51b-4a72-47bd-bb64-4c6d9380e4ae"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCurrency, "zAR", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCurrencyRecord("9a29c930-7eea-4f55-b5a0-3c28d93be4a3"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCurrency, "pGK", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCurrencyRecord("9d1eade8-56bb-4006-93e4-43704fa54753"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCurrency, "tRY", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCurrencyRecord("9e3284f1-083a-4865-b3bf-c694e1019060"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCurrency, "pHP", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCurrencyRecord("a9d24cd8-eee6-4a0a-a88d-fde8db555288"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCurrency, "dKK", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCurrencyRecord("aeec3174-9783-41ea-ba6f-d05d14c9e4eb"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCurrency, "lKR", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCurrencyRecord("b51c2a33-16d7-4b63-b815-1fcf20a19017"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCurrency, "rUB", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCurrencyRecord("b5b0b5bb-7f8b-4dcf-89fc-2ba6170b3d94"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCurrency, "bHD", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCurrencyRecord("c7e9717d-0e77-472d-bd61-c6d88dc0f169"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCurrency, "fJD", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCurrencyRecord("d496f2a3-b5e0-415c-8ad0-f1abdc5ce9f3"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCurrency, "kZT", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCurrencyRecord("ea69b9a9-962b-49fb-bf34-7e8f86cf18c0"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCurrency, "kWD", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCurrencyRecord("ef614937-09cf-455c-9677-c2d9c0564b46"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCurrency, "aUD", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCurrencyRecord("f38a374b-a6a2-4753-a542-752f290bd13f"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCurrency, "uAH", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCurrencyRecord("f5f1036e-39be-4e83-ae7e-39034f36c9bb"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCurrency, "tZS", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCurrencyRecord("f6f5070b-f7e3-4efb-8d13-40e51b017bc6"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCurrency, "cZK", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCurrencyRecord("fd4ed103-ca90-4275-a5c1-9d3d55c53662"));
}
});

ShopperPortalEU_CSModel.staticEntities.sPLanguage = {};
var getSPLanguageRecord = function (record) {
return ShopperPortalEU_CSModel.module.staticEntities["469473cb-eb5a-4440-906c-b4954315f40b"][record];
};
Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPLanguage, "korean", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPLanguageRecord("1415f8d8-cacb-4fd2-923d-07659265823d"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPLanguage, "finnish", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPLanguageRecord("2cdc996e-7b25-4e90-8da7-572ad5110813"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPLanguage, "german", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPLanguageRecord("48bcb488-f292-4a7c-a84e-da44c51f8e2e"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPLanguage, "spanish", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPLanguageRecord("4bf049d4-6699-46a9-bab5-8887da300ddf"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPLanguage, "arabic", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPLanguageRecord("5a4d18af-6b6a-408a-a634-69081248491a"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPLanguage, "dutch", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPLanguageRecord("6819e690-5a3f-4331-925a-dd6ebb43d2da"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPLanguage, "japanese", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPLanguageRecord("73575ba8-e217-4c11-ba0f-ce3e6d621160"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPLanguage, "turkish", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPLanguageRecord("7a60276c-5b59-411b-b1c3-0e19cb5f6d15"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPLanguage, "russian", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPLanguageRecord("87e03afa-d263-426b-bac9-d59c8666646f"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPLanguage, "malay", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPLanguageRecord("c4675f8b-1fbe-492e-9f19-d97f4e1907b8"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPLanguage, "urdu", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPLanguageRecord("d0759fe5-576d-4291-a213-46c76453c942"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPLanguage, "icelandic", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPLanguageRecord("d52dbee5-db2c-4e16-82b1-6bef8594c0d1"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPLanguage, "portuguese", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPLanguageRecord("dde330b6-6aa2-4ee8-adfb-bf57eafb3402"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPLanguage, "hindi", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPLanguageRecord("dfbc76c1-33b6-48b7-bf54-0b1ad30632d6"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPLanguage, "faroese", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPLanguageRecord("e3a29f12-b02a-41e6-8555-ca5889b7f185"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPLanguage, "french", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPLanguageRecord("ebae1867-bd13-4ae3-8edc-65f7a783b3a9"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPLanguage, "bengali", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPLanguageRecord("f00db07c-afe4-464a-ad1d-cf1c2755172c"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPLanguage, "danish", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPLanguageRecord("f4c08278-498c-4bf7-8af3-ca8d540d229e"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPLanguage, "english", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPLanguageRecord("f5bd5cf2-e489-4a90-b1bc-015d9c248d78"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPLanguage, "chinese", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPLanguageRecord("f81e251b-df02-484b-9e98-a66e79f2031b"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPLanguage, "swedish", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPLanguageRecord("fa74658f-e1b2-4fdb-b637-0e1eef7ebb38"));
}
});

ShopperPortalEU_CSModel.staticEntities.shopperDocumentType = {};
var getShopperDocumentTypeRecord = function (record) {
return ShopperPortalEU_CSModel.module.staticEntities["4c54e13f-fec6-49fc-aa51-64c3b146c392"][record];
};
Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.shopperDocumentType, "idCard", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getShopperDocumentTypeRecord("123be1b5-2d12-4b6a-b846-133270df6baa"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.shopperDocumentType, "passport", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getShopperDocumentTypeRecord("ec598aa5-51cb-4841-a37b-b9fad6ea0008"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.shopperDocumentType, "residenceCard", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getShopperDocumentTypeRecord("f6cb327e-c2db-4614-bdc8-b819658ff608"));
}
});

ShopperPortalEU_CSModel.staticEntities.refundLabel_UI = {};
var getRefundLabel_UIRecord = function (record) {
return ShopperPortalEU_CSModel.module.staticEntities["5475f53c-b6f3-41f8-afa1-5b4e1c871ff8"][record];
};
Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.refundLabel_UI, "refundAmount", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getRefundLabel_UIRecord("4b7146b0-eb49-459c-b1db-ccdfd7537556"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.refundLabel_UI, "estimatedRefund", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getRefundLabel_UIRecord("d10e9827-5f64-47fd-b6d4-e671322503e3"));
}
});

ShopperPortalEU_CSModel.staticEntities.sPCity = {};
var getSPCityRecord = function (record) {
return ShopperPortalEU_CSModel.module.staticEntities["7cb9a096-8d7a-465a-bef7-5c4d12aceb0a"][record];
};
Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "copenhagen", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("000ae5cf-b525-4e71-9913-54a5bf80d76b"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "wroclaw", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("00262904-b208-43cf-b5c3-58a84ef3411c"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "innsbruck", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("008feb6b-7824-415b-b6b7-cab004fe9034"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "agira", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("035bbb6a-6c2e-410f-aa18-1d7357725a32"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "malaga", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("039295ac-0697-4729-816c-fac7e854fb03"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "orje", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("03ecd49b-f6f4-4ac4-be73-6a27bd143144"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "record1", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("0539c693-bc21-49d8-9f85-b95efbcd4154"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "lasPalmasdeGranCanaria", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("07db9935-6a45-4453-b362-9d1837a0b99d"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "hannover", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("09116472-000f-4495-a150-97a45ed8c071"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "gothenburg", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("09fbcb5b-80c9-4e38-b212-6599d5ebce4b"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "malyi_Bereznyi", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("0c0c1dd7-83fb-47eb-b5b2-68f6dcf7b957"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "hohenems", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("0cd54cfc-a44b-4d65-8b26-d5ea72901b2c"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "noventadiPiave", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("0d62391b-9a23-498f-b8e4-d7a3a30487e6"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "karlovyVary", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("0d890273-f618-495d-b083-f4478aad8205"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "chania", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("0dea917b-7747-43f1-a6e2-172e542989e2"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "metzingen", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("0ea7f33d-defe-4309-91a3-97b6c08e5abd"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "munich", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("0eb2f920-c703-437f-b13d-9ee593f4b4fe"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "morokulien", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("0eb9fa27-8f02-4854-9954-e695ca7230b7"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "gdansk", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("1035f577-dcb5-4ff3-9c50-fbf15824862d"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "parndorf", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("106e7e9b-7de8-43ef-9ed9-988df6db1adc"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "lubeck", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("117e16f2-fdf5-4349-89c8-7ba9f216a357"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "pontaDelgada", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("11a96f5c-236e-4e75-9340-57fc5149b4cf"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "geneva", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("120f62ad-850a-454f-9895-c38d89404990"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "marinadiPietrasanta", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("122c08b8-4bb7-445f-ae2e-1be024b7c572"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "bologna", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("126e3c46-4f6b-4d00-8245-06f1b4a54fa0"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "evora", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("1295a651-1a63-4d96-a167-9024232bb306"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "torshavn", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("13148baa-5194-451e-be37-e6523fe8489d"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "zurich", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("133a5bda-797a-4d7b-83ee-318f5dd5acbf"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "badenBaden", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("13a8a776-b52e-4609-a24b-8afd54f36364"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "krystallopigi", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("14d4b5c6-2355-49ad-a41c-2412fc3dba2b"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "fuerteventura", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("15793704-144b-4118-bad0-8cd2fc463bac"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "portoCervo", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("1750fae0-e592-4e71-8326-67d3207537d0"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "frankfurt", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("176ff7c2-6936-4733-9a19-30f450d6bb01"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "barberinodiMugello", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("17c7eaad-c5b4-41b8-b43e-684a6dd53be5"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "como", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("17d0efab-8f98-47bf-b902-0a45f3f3d57b"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "konstanz", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("181c32ce-26de-403e-a007-525593173731"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "kakavia", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("19631913-b67c-4d5f-8edd-f899cee3bf55"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "albufeira", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("1b6bb6c1-a3ef-45aa-848d-8c5d88400f93"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "beregsurany", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("1bb63daf-0e13-4481-9bff-a5ec21423c88"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "algeciras", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("1c26f678-8b85-45a6-a129-bd2e2108b5d4"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "lustenau", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("1c2e6ec7-8c1a-44ca-b719-113484b411d3"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "cannes", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("1f119735-f518-46b2-ab77-0836f32d6b89"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "andorraEncamp", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("20d76bf4-5d24-4eb8-bb11-68319bfc919f"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "claudio", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("2172c29f-b632-4592-95d2-518d5f6a3c25"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "wiesbaden", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("21cc3111-0f34-4d05-aa04-0f07a2f2b7f2"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "stockholm", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("22d48a3c-caa6-40e7-a28b-bb889190a93d"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "rodovre", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("24a21562-897e-4944-b4c3-8283a050d935"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "portimao", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("24ea25e5-aa13-4e3e-af8a-6015b450b622"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "brussels", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("269965da-cfe8-4717-8f2d-99b692918980"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "terespol", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("26c5eec4-3918-4b91-b50f-de1537d1afae"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "karlslunde", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("26c9eebd-ae67-43ef-b117-091c96457cea"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "varese", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("27a0d303-a7a5-4ae1-957e-fcb40e9faf37"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "uzgorod", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("286ac90f-465b-4be2-b2cc-b8b17bd76680"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "azores", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("28b57e76-5317-4544-82a8-177cf4db3933"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "laPineda", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("2afeb621-15f8-4e82-9639-8698fe998623"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "billund", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("2bbd3b0b-1546-478e-8302-5d951b17d80c"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "grosseto", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("2bfa58d5-62c6-4bf3-9e71-2f31b2216699"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "minsk", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("2bfad700-5367-452a-a0db-4fd1a48d45e0"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "serravalle", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("2c3a59c1-3ef3-410a-bad8-38e9fc2c0daf"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "zahony", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("2ccfc400-66b8-4051-be52-f3e9ad7a7596"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "hrebenne", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("2cec9893-e899-4b9b-91dc-db5f4a4410ad"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "bonn", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("2d5c991d-3784-45af-bdd2-f00d52942e7e"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "ischia", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("2d6c75bb-bec8-4f8e-82c1-187167dae769"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "vagar", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("2d92d133-f410-471f-bdf9-a386562d4ee7"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "girona", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("2ecc2e57-d0ae-4608-b235-2a14afa21807"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "lisbon", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("2edf54a9-b65f-451d-8f38-3e496f7751c2"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "dublin", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("2fd31e3a-1290-4ef3-a7ed-88a31f05e2f0"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "sandefjord", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("31031905-74a6-418c-beee-7bbdd7b826da"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "sorvagur", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("32dc4ca1-f7d7-41d7-b345-e805de4bd831"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "piraeus", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("3454647a-23aa-4a75-aa5e-62044a306f34"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "basel", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("34c91f60-3f57-4bcf-82e3-b34a3fccbfbb"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "feldkirch", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("3519f39f-0a12-4d46-9e8b-975d9be6fc2d"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "runavik", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("36b1f26d-b928-41e4-823a-ad963019d616"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "hirtshals", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("37b96f25-a98f-46e5-9edf-373e8d43dcad"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "sorrento", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("37c85c89-8fee-446e-af72-8c4f2fbe9049"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "faro", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("38d43078-5773-45d1-93a0-d7f701f4ecb1"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "thessaloniki", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("38e08bc1-6ba9-4b97-9931-88d4c568d661"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "kusadasi", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("3947e3b5-3da0-4294-beca-7971be5044c8"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "cork", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("3bdcac0c-f90e-4cbe-b3f7-ce666fafdb9f"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "bodrum", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("3bf83d28-30b9-4f20-89b4-376c5d21d521"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "buharest", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("3c67817b-f0c9-40b0-a987-9824894104f0"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "reyes", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("3d280c4c-482f-418b-8df6-012c58210b73"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "madrid", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("3e93c2e1-41c1-40c1-9410-d667e298b0c4"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "leccioReggello", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("3ee2ca90-bba5-4d83-9226-2deb3be02ee0"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "regensburg", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("3f398667-2a75-4aca-9ae0-93bf071ec6ce"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "figueira", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("40650162-7149-4dfc-b8db-2ca9c2a2ffcb"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "warsaw", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("407c2d0a-d766-4c9a-a36d-5bb7c8ff6845"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "krakow", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("41efb172-5441-4613-a7f9-2095a9ef16e3"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "helsinki", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("44bb8909-8c23-4012-9de3-4d9b03d5980e"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "bolzano", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("44c6d841-807e-4ab9-a0c9-a8e8e9f9cf3d"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "treviso", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("465740db-d2d5-41bf-b985-691624866621"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "badNeustadt", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("484083ad-b2d6-4dc1-a6b6-c8a1180b0e68"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "berlin", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("4a58636d-db20-4722-b387-6e6840affbd1"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "kirkenes", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("4ab14a22-6ccf-444f-8032-b611a3ae09a4"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "klaksvik", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("4adfa919-85f3-4112-9fcd-4b016273c821"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "pisa", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("4dcb190f-a671-41ca-b811-a6bf165a029e"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "tromso", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("4e6a8538-5db5-4c47-a24c-226733d30e38"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "larnaca", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("4e93c73a-de55-4ef8-86e4-f8caba9b8399"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "granCanaria", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("4fb66283-e6c9-47bb-801f-df0ca96f55b5"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "turin", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("5386d70f-fc8c-44d0-ae65-9e34329266ef"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "cascais", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("53cbaeae-b3f1-4b1d-9c14-ad4b24179143"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "aveiro", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("53ef2d3d-7328-4ad1-a945-d616446a45da"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "garmisch", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("5425d502-cc24-4fdc-a6d1-38a2cd431f08"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "ibiza", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("5694ef2f-e9f1-415f-8683-1c7f026495b5"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "bratislava", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("56bf6b19-5eb6-4ced-9165-993e475ac262"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "bremen", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("580aa34c-e89a-40d1-95b6-5fdf5a6ce01a"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "trieste", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("5974eed7-a00e-4124-b9c4-c429a86aba02"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "mader", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("5993f8e2-33aa-4f6c-9f9f-04849deeb524"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "saintJulienenGenevois", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("5b18d5ba-a82a-4c90-88b6-b84a2f58107e"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "crete", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("5baa1b5b-537d-4aa1-bc98-5398113a42a0"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "marbella", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("5bf7c4d1-188d-459a-98ff-b872dc7d9983"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "iJmuiden", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("5dd309e1-9b88-4721-9895-7cce0255b075"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "benidorm", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("5eeb3506-b08b-4cc1-bb99-52aea290976c"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "lyngby", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("5fd07e18-2fd7-4820-b0d9-3e3343635210"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "weil", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("626efda6-69d2-4b5c-beec-336a27e1189e"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "lanzarote", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("6330c5bb-425a-44ec-a7ff-20cc4380e087"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "tarifa", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("63491c81-5518-4ddb-9d62-2e70a58061d2"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "skopje", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("6374105a-68e2-437d-aa57-3b47d8c4beb5"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "sculeni", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("63afa343-681d-4a99-93dc-bbcc3796c00e"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "cologne", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("63f59fa9-9e1a-4f66-9c39-2bfe37d80c26"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "eindhoven", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("645617d1-68dd-40f8-ae34-a41ccb4483d9"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "eidfjord", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("66a02bac-abfd-49ad-9d11-a9b6827ef9b4"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "bergen", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("678d7bd4-0cd3-498a-8436-03587f743a8f"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "alicante", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("68656a43-8482-48ce-8e0d-8b90c43c63c4"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "capri", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("691b0678-6cc4-4b6f-ab0e-87e0f8b7ddff"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "seefeld", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("691b99d2-fb67-4793-a255-64f7ccf9f292"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "velkeKapusany", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("69b9d94c-d6c8-49b5-b866-91b1b2198350"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "odense", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("6a348e8b-1f88-4509-8187-05435aadc90c"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "palermo", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("6d1e87a5-9086-4607-a83d-3255e4dcf806"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "gomel", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("6ea94b32-ac70-4d8e-a4cf-524283c09cdb"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "sanremo", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("6f605b50-07e2-4809-86ec-812df6da3107"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "funchal", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("711235bb-11f1-40cc-a526-d37154dbadc9"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "limassol", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("71d95066-d170-4c36-af9a-c25a600a1949"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "lagos", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("72556ab0-29e0-4ee1-8e88-92ad6ecb797e"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "oslo", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("733e836b-cd91-42c9-8d78-14e0d9591c52"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "evzonoi", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("74be6a25-755a-4ee2-8e08-c7a0a3ec2cfd"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "stMargrethen", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("74f39733-0a83-420e-a0b6-832d47e04c6f"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "heraklion_Crete", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("7626dec0-a695-4b68-aa07-833d7138db4e"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "granada", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("7684ad95-5ab7-4fc2-9b45-02f1b2663292"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "alvor", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("783a3d24-0da9-40bb-844d-060d1e8711b9"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "puertoBanusMalaga", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("79027d7f-54ad-478a-b838-ffe82cebf59d"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "andorra", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("7c7e57f3-19bf-4c50-a1b6-3d13ae473578"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "knock", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("7d197875-3ac4-4c32-9b0d-ef0bcc2722b2"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "halden", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("7d2ff124-5aa4-4e08-9ee3-b8fd44ed0ec9"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "siena", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("7d435592-6cfd-422f-8acd-a5727cc9c45b"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "lloretdeMar", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("7d8ebfcf-6513-471a-9ce2-455116b9541d"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "budapest", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("7e7b6711-60c9-4ca6-85f8-12af6745fe17"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "olbia", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("7f4dace5-5e50-4fda-a220-e82b34b8efed"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "strumica", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("7f7e148f-ed50-4c37-80c0-5483d364f1cf"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "sighetMarmatiei", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("7fd27d6f-0f35-4ff1-a302-b2d1396b5680"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "valencia", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("81dd8ad0-3060-48e7-87d4-3df84e5e961c"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "lyon", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("8388582c-9947-4a8d-8476-b20ed97264fc"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "naples", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("850c0194-e29a-4e4d-85e1-0848e08f3103"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "orly", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("8818166b-cc6b-4b62-9d36-8f377f48e3c9"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "almada", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("89873160-2bea-41b1-a33c-56014610f57b"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "zakynthos", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("8998a016-a975-4d0e-ab57-6f218e7023c4"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "mogilev", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("8a0ad7af-ba20-410c-96ce-4e4b5ef897d8"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "flam", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("8b1fe0d1-3591-4289-9f35-8c964bc07bf8"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "venice", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("8b321793-d88c-4131-bc1a-27b5fcffd724"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "heidelberg", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("8b527ef2-f65d-4b6a-aa2a-85579f8f1d20"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "gandria", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("8c391f57-43d0-4686-b0fc-87e8e9e33e60"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "aarhus", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("8ceb7296-9abc-4bc6-b2f0-234ad2a2f792"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "izmir", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("8d2a92b7-d3ae-4fee-af89-363dba3e8c60"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "noviSad", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("8e7bc79b-e26f-4759-a40c-013bc93bf23e"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "puntaRaisi", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("8e8bde15-d0f3-4580-84ec-1de5fd31f52e"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "tarragona", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("8ec0aff3-5e1d-4df9-82e6-a5082528a74a"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "kipoi", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("8ed19339-cd05-4d79-b4b2-561c4e9f6af1"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "vilamoura", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("8f2f56bb-98a5-4ac0-a82d-61b7a39ebf67"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "dornbirn", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("925b6435-b338-481c-aa3c-af09f670b889"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "warnemunde", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("92b022a1-bd1b-4c4b-9a5f-032efdba63c2"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "stuttgart", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("92c1ba8e-9a8e-41df-96c5-c048b86b898a"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "lugano", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("92fa51f7-c09c-4738-a66c-ba840e62cfb9"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "rhodes", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("93398f0f-8155-419a-992d-043f5cc10491"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "halmeu", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("937a110d-6f13-4405-a330-1678139a659f"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "ponteCremenaga", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("94c92836-3bdb-4614-a919-5dfdd1ddcfb9"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "seville", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("965751b8-367f-452b-94c7-3467d2c79269"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "vigra", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("9750172a-e8ac-4211-8b1d-c0a44e15440f"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "catania", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("97e66c42-4512-4b1e-afdb-1bacf8fdb80b"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "nis", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("986d8f6d-140d-424e-a5fa-18c120fd421b"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "marseille", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("9a220639-c1d2-4d5e-9dc6-8b5792651bb8"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "salzburg", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("9a8dab8b-acd0-4ce2-8af9-a0bc3d16fe95"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "vacallo", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("9bd9bb0f-6e46-4510-a995-e878e0f9ccea"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "paris", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("9d06f186-3269-4903-9ec6-d870c34970ca"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "braga", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("9fc39f80-4f32-484c-99a5-67657d99334a"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "isaccia", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("9fd0f0aa-1285-4753-bb9e-9dd0a272fc6d"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "bielefeld", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("9fd8a94f-995c-4c49-b4d0-bda21c54f28a"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "barcelona", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("a0baaa33-b7a6-4883-bb25-6208d69ff47a"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "brissago", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("a0bfbd1b-93ac-4dbb-b210-9892e0524242"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "monaco", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("a100fa99-86c8-4a80-b81d-aedfd786c3f9"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "cadenazzo", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("a1802eda-9a3f-408c-864b-1438ecf1c13a"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "coimbra", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("a1d1dcf2-9d52-4997-a1b8-5f3a1a8af134"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "piaseczno", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("a379c212-31fb-4eb0-bf82-0d12339a3341"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "dusseldorf", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("a51d2169-06a6-45bb-ae09-b97c2557f0a8"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "amsterdam", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("a62d107e-30e6-42d8-b47a-da1102d1ae99"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "kristiansand", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("a62ed5db-a45b-4e49-98a2-f8fcb530b7c1"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "tiszabecs", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("a9edd3a1-d9ff-4976-a854-2315765a3cf7"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "dresden", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("a9f6f96a-3f17-485e-aead-09d60b592300"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "serravalleScrivia", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("ab3ce646-d19f-4a2f-a666-78b432f195e5"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "slawatycze", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("ab799140-a53f-47a6-b4bf-f3f33865da1f"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "st_Margrethen", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("ac475e21-825d-47ca-8725-2d8cba3a69ca"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "bordeaux", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("ad50fb18-bbd1-4954-a0c8-fe144b7d0e66"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "rimini", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("ad5e16d5-0df0-484f-82c1-77887e48f95b"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "corfu", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("adc33f8d-40a1-4716-b3ec-e50f131a51b8"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "vitebsk", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("adf92b88-62e3-443b-b61e-c33e63b086c5"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "thonex_Vallard", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("b0f1a7aa-89fd-47ed-a9e6-24e1ca3810a0"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "chisinau", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("b160695e-20bb-4902-91c3-1fa35f4e98cb"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "grzechotki", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("b16915e7-4bc2-4f00-9490-4ad2508fb17a"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "caslanoPura", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("b1d9f399-1f42-4949-82df-4f93f942cad6"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "meiningen", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("b233e298-7d5a-4614-be0a-35c617f19ec3"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "grodno", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("b773ff2e-7e07-4942-bd5e-055c423d51ca"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "tenerife", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("b7b5e2c5-d1d8-4c89-9ec8-02af52b343a7"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "wertheim", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("b8f2b56f-0856-406d-94b5-0a470a17368b"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "santorini", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("b919a016-11fc-404d-ad2d-7101e340633a"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "pardubice", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("b93813f2-8a9c-4ee8-b170-16d7f3872257"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "rodovre2", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("ba3adf96-c2c2-4ebb-81d9-4218a3fe73bc"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "verona", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("ba615531-4e50-4774-acf3-34066d61b4d6"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "moura", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("bab7c17f-2f87-427b-bc27-4b7b3a76f122"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "balerna", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("bb87f167-ab6c-4566-9547-da8f69c3f914"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "nice", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("bfb21567-2a76-4c9b-af84-323c95c91d47"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "sanSebastian", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("c4c9a670-c4e5-4a1f-8ad1-7e40961d9036"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "zosin", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("c5dad195-4f5e-41e3-938c-5cd8573a6669"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "reykjavik", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("c730f174-8080-4b76-bc79-67306aeb7bf0"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "ingolstadt", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("c76a461a-a046-47f8-b610-99886a315f10"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "alcochete", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("c786261c-7177-4b3f-862d-13ffbcf17e79"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "araxos", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("c8ebbfff-660d-4f82-a20a-e2edb5d26154"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "athens", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("ca474d78-0c77-42cb-a19d-f1dfdd180ca0"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "vainikkala", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("cb2283d8-c97a-42ac-ba53-be0179192365"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "torremolinos", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("cbb6f292-2509-4595-adba-7e6ba04064ee"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "paphos", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("cc5f2e6a-9c79-47ad-b747-36a1cb0ef9b9"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "elHierro", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("ccee8c7c-d92d-46fb-8d17-fc0553360c36"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "florence", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("cd177ea5-2cbf-4cfc-b15a-ddf76be565b1"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "bergamo", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("cf1c3bcd-2239-4be7-82ac-02720a27748d"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "quarteira", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("d010a75c-0cae-4109-a926-09d4c8fbac7b"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "abanoTerme", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("d2af0069-81d5-484b-adce-93bf11f01ecf"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "medyka", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("d32b3be6-e1f7-4bc5-a8e7-f68564d2296a"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "farranfore", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("d38a9a7d-6fa4-4f5b-ba22-6d66b8064210"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "chiasso", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("d57934c7-269c-40fe-87af-d0505865edba"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "keflavik", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("d65640a1-e8a8-4878-9c54-7bb4196a8abb"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "porto", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("d817f6a9-9bc0-4b04-b4a1-007edb283069"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "istanbul", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("d8265e50-b926-483d-8dc9-07a82e1b9631"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "katowice", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("d9ccb72f-cbb4-40c2-a8f1-a40d55153bfe"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "laPalma", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("d9f7354e-75c5-42cc-a243-a06e3df25a13"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "bromma", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("db0deb29-1dae-4d23-a3f1-a06fbd059e3f"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "mainz", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("dd85e532-a6b3-40ac-aa92-4687c6814a88"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "stavanger", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("dda692cc-e488-4ad5-962f-2733d960fe32"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "dolhobyczow", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("ddc1075d-0e91-4b99-906c-2ad57a677bc2"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "mykonos", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("de0197ab-2e3d-4191-aa13-50badf797246"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "subotica", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("df951375-1a87-4d16-b8cc-bca1685d0608"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "santaCruzdeTenerife", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("e1349ea9-0741-4209-bf22-d21cd4e3048d"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "nuremberg", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("e174cc70-9623-4b95-903a-93a028020e98"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "vienna", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("e3f91bfb-1427-4547-a19b-d1f9762556a8"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "rome", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("e482b200-64e3-4a91-b858-1b64f29c20fc"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "ferno", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("e64ace85-1da1-4ff2-bd9d-4f87c8889223"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "hamburg", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("e8820e21-042c-4dea-b4fd-c6eff790cbd7"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "carnot", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("e88bc843-6a97-4004-906c-a91d2219e59f"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "rosslare", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("e9057322-0b18-4f71-84f5-f90612724c0c"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "malmo", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("efdaa64f-73a3-4147-a907-3f4e27370dcc"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "hochst", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("f05ed59f-e569-486d-8f6f-d88f17dc10ef"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "hohenschwangau", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("f09bfff2-d29f-45ca-b766-bcc088aa05ee"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "taormina", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("f1cc8cb8-7ae4-438d-b3f6-6401ded39728"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "fortedeiMarmi", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("f2173d75-2480-4a7d-8091-07133f48ebf7"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "alanya", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("f325ef9e-4cfa-4540-b5ab-0159629642cc"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "salou", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("f3b59826-300d-41d2-9b16-efb99ea0fbb3"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "haugesund", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("f50ddd2e-ee8b-470e-a001-a30e0a8bc359"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "ayiaNapa", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("f7716687-b9c4-4e59-bb6f-2216ab10d336"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "salamanca", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("f8f433ee-af52-4160-ae0c-68115e3d50b6"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "stabio", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("f97fabda-9648-441a-be8c-1e425ea0751b"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "shannon", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("fa0a14ce-df39-4194-95d6-d325a07e19fd"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "palmadeMallorca", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("fa9d2e33-7bbe-4d05-b20d-790829116bca"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "milan", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("fcf0b8dd-695b-4536-a5c4-e8cd17fd2cda"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "prague", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("fef39bd5-15eb-460b-ab4b-2a851341a0e2"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "gaillard", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("ff003b35-c4fd-42aa-9e32-8ebbdb0ec4bb"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "mendrisio", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("ff59572a-97c5-4c1d-8c5d-6cafd772e849"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCity, "comunaDranceni", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCityRecord("ffb180d1-7ebe-44ff-9237-cd53c5730009"));
}
});

ShopperPortalEU_CSModel.staticEntities.sPRefundOption = {};
var getSPRefundOptionRecord = function (record) {
return ShopperPortalEU_CSModel.module.staticEntities["cbb9e789-b506-4d37-8c2b-ef6f142a76db"][record];
};
Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPRefundOption, "bank", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPRefundOptionRecord("364fdae2-242b-49fe-8d5d-afcf4bb9c71e"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPRefundOption, "localRefund", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPRefundOptionRecord("50987bfc-8959-49d3-8684-3359d8002d04"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPRefundOption, "creditCard", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPRefundOptionRecord("5594fdb3-9bc4-42a4-a076-2ac6b89eff7a"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPRefundOption, "tOPOS", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPRefundOptionRecord("910b8bd9-88db-4311-8269-0a36e090c0cb"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPRefundOption, "cheque", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPRefundOptionRecord("998a51de-445a-4afc-8c7d-0e5baefad96e"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPRefundOption, "cash", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPRefundOptionRecord("ad1ff0db-915d-46c0-92b3-f2b9f1175835"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPRefundOption, "cityCentre", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPRefundOptionRecord("fda240bc-444f-4a00-a631-3fdfb8e781a9"));
}
});

ShopperPortalEU_CSModel.staticEntities.sPCountry = {};
var getSPCountryRecord = function (record) {
return ShopperPortalEU_CSModel.module.staticEntities["dbc21487-ce9d-4f70-87ed-879bc13b370d"][record];
};
Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "swaziland", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("00a2f468-d2b2-4c20-bb58-8569b5e2c4fd"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "venezuela", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("01cc568e-63c4-4027-a3c3-1fe9c8665ebd"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "myanmar", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("023135f2-9bca-4c11-a5ed-61d51133ea86"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "virginIslands_US", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("0467c29e-25cc-447b-a0f8-4d222033653e"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "austria", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("04cac085-0e24-4887-b118-873aebf7297f"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "senegal", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("0752d379-9e74-4080-b062-2d1a8b707d8e"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "anguilla", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("07e11b53-0e70-43e4-82d4-74911f47677e"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "laoPDR", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("07f0423c-1bf3-49a2-a3ae-5b83246f1ac1"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "montserrat", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("08bd28c2-2d3f-4703-925e-73f6fad864a1"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "suriname", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("09339f7b-d44f-4543-96b5-b3f8250a5c3c"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "mali", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("09944877-09cd-454f-89d8-e869d2ac7d93"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "latvia", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("09c751bd-3428-40ca-bab0-c30ab7bbd2fb"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "liechtenstein", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("0d2b85ae-9cb1-4213-9c3a-35c4137ba9e9"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "puertoRico", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("0d821405-9345-45e8-b4c2-a3e303c01ffb"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "rwanda", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("0dd4720d-b3d8-4238-8c38-ca86f53db5b0"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "turksandCaicosIslands", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("0e8e6858-a46f-4efa-8b5e-f54edef4d6bc"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "britishIndianOceanTerritory", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("0eaa9dc1-64a9-4264-b7e4-d0f966166ef3"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "barbados", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("0f50998f-3ffe-475c-932b-e5dcf82d9d7e"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "falklandIslands_Malvinas", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("104e028f-cfba-4d21-acc5-fe2699fd633a"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "jordan", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("108d8cc2-e433-46ae-a491-ffdd72827495"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "switzerland", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("11b852d7-a2f2-49a0-ae30-3ca128e79841"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "afghanistan", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("12cf57f6-165f-4edb-b5b1-1a5d26d7e35e"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "montenegro", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("137445cd-45e9-4595-9a51-947f28a1c654"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "westernSahara", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("13b585e8-cf1f-40ab-98cf-943a6ded56cf"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "dominicanRepublic", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("14b4fe21-202a-434f-9522-514499533130"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "libya", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("150f9fe3-795d-4984-97b2-6b515ae9ffea"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "china", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("1676f479-3255-4091-b157-167c4bfaab10"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "australia", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("19c478b6-cd1d-4ea9-a248-cf548844a68f"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "guam", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("1a323742-c5e2-48af-b1be-1e1958092b8a"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "saintMartin_Frenchpart", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("1ae8dac7-c1b2-4a11-bfb6-06fbf19554e4"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "saintLucia", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("1b878cc0-77e8-4abd-80ac-dd922a9bb7d5"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "dominica", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("1bdd62d7-81c7-41b4-a2cb-9c6f38ed1ad9"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "antiguaandBarbuda", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("1c837466-28d0-4c06-a8b9-2605c1787330"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "americanSamoa", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("1ca37683-1637-4736-bae5-4c3cbd3df99a"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "seychelles", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("1caec13a-5d54-4899-898e-e48bcec07204"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "kosovo", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("1d11afbb-e617-4db3-ab99-c50daa0aee4e"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "northernMarianaIslands", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("1e497b5a-9ae7-4a11-a560-38c0e81c2588"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "mauritania", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("1e6ba8ee-aeff-41c6-9211-0e22141633dd"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "guatemala", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("1e7f6e25-d5f2-41b2-8227-e277f111bca2"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "samoa", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("1e8a02c3-9c7f-413e-8a2d-7057dcdc1c59"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "armenia", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("1ed322f3-de5f-4887-bf1d-fbf9d88d3e92"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "guernsey", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("1f00ca06-7764-4de6-b486-1eaabcdf9db0"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "india", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("24aafe07-5a44-48bb-9b88-496c58826b2c"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "reunion", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("25af1e46-6141-4b10-8d35-7fd480c72630"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "chile", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("25c3baee-3cde-4667-844a-34fa5681dba7"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "somalia", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("26904954-3b8d-4460-a135-9be3898fc035"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "liberia", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("28eca8da-0c36-4911-9072-e66ef21424fa"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "macao", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("2a12a19a-8b3a-411b-ba3f-a56f1b094b03"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "malawi", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("2bd7ac28-b382-4078-b226-6cbadea11081"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "burkinaFaso", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("2bf27032-4255-4a41-a5a5-c9bc73b0c8cb"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "italy", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("2c160943-de41-4637-b78a-32713b11a536"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "belize", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("2c981b0c-537d-4093-98f9-41d8cbf65899"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "turkey", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("2ece920a-0f1b-4763-b640-fa9c9b6a043e"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "indonesia", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("300ac2fa-d0f5-4673-9ad7-e18972c0e139"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "cocos_Keeling_Islands", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("3110a169-830a-407a-bb83-f7c7b0b5d605"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "svalbardandJanMayenIslands", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("31d1b5d1-5f4b-408d-994f-5f674cd4f7ab"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "andorra", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("31f9d9c0-094d-4f89-93bb-412e197bc6e2"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "sanMarino", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("3490d702-9cce-4496-8608-1bad36d9e7c2"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "singapore", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("36065ea1-2812-4b58-9efb-771f25a824ac"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "algeria", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("3672a423-bb6d-4b11-8546-1e6dacf5f6e6"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "benin", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("373d6230-b379-427f-8b47-cb4cd10ec935"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "sweden", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("394e572c-efc5-476a-b1ba-3b12c8b0ce72"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "mayotte", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("399e8740-44f2-4c93-bae0-6959b7dbd5dd"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "brazil", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("3b10a793-01a5-4419-8ef7-12505c635924"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "somaliland", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("3bc55e46-36fd-414b-8b96-8935c43fce1e"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "cameroon", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("3c4d38ae-7e07-4fc0-8cc9-8f34f49abef7"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "equatorialGuinea", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("3cb20e8f-39f2-47de-afcf-594330849af5"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "saintKittsandNevis", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("3cf1787f-4079-4248-bda2-d654f32c1098"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "vanuatu", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("3d81f246-e2ce-4168-8b11-1afdc55219ed"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "haiti", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("3d9c3f80-a1ca-406c-8ab2-c8a1ce626352"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "uganda", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("3e12b32c-186b-4b28-b782-e5abb0f28553"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "mexico", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("3efac3d8-662f-4d91-817a-5e39d9b4e737"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "tajikistan", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("3f89a0c2-2030-4295-9b4a-e3b186d363e7"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "heardIslandandMcdonaldIslands", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("3fb7dd4d-156e-4acd-aab2-366b90785b66"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "kiribati", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("404fe5f4-655a-49a4-8300-db729ef55134"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "papuaNewGuinea", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("408a1f48-e8c6-4b28-bb53-3226396bc35e"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "saintHelena", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("41947e2c-605d-42fc-9fb4-7ae042eb2e6f"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "ecuador", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("41e91c18-c51b-493f-8c73-2ebb825676ad"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "newZealand", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("4255aa18-9ece-480a-ab0a-5da7a616db51"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "wallisandFutunaIslands", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("4312eec6-0ba6-483f-b049-13d925071fe8"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "tonga", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("43c0c1e1-6547-4391-9cab-0a7dae5a6471"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "netherlands", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("45dcdc6c-cc68-49b5-9b1a-e61543e12159"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "zambia", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("45e81034-19cc-4688-a308-c620ee8b1e83"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "syrianArabRepublic_Syria", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("463598d0-a1a1-4239-add4-8ba5bb7075d6"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "honduras", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("48189171-d35a-47a3-a532-f3871076f8ff"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "sierraLeone", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("48196990-3577-4366-af45-fe83f89f2ed4"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "costaRica", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("493f1bec-499b-4b83-8606-1c8eb35d1d2e"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "tokelau", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("494f91b0-d9f1-4904-ad29-04c35e56ecf1"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "mauritius", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("49c605b5-7dd8-45a6-9c81-fbacb118360f"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "sriLanka", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("49f8e5fd-63d2-4187-90f4-61a37a7e27db"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "bruneiDarussalam", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("4a5e8dca-d6b2-4313-9081-002c008b50b2"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "grenada", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("4a90025c-ba91-440e-a052-93640a9450d9"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "romania", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("4e6a9c22-a6b4-4066-97e9-0331eccea0db"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "botswana", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("4f7f74b3-4c10-4d9f-b7ce-41bd548b9169"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "philippines", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("4fb04387-5d2b-407c-b9b9-26f3cd453455"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "morocco", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("505531a6-3c0a-4fa4-aed3-61ba944332d2"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "saintVincentandGrenadines", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("540285de-dfc7-4712-a6e2-86cb78392071"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "croatia", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("544361ca-6b06-4527-9423-31b64eb72933"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "bahamas", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("54ae66e2-f42d-4973-a379-2e6a42c3b3a0"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "isleofMan", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("5602fbc9-89c1-435b-960f-24b5521aca6d"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "bermuda", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("562a73a0-10f7-4ccd-a986-3a8fe48823d4"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "togo", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("5684c51d-6eba-4bee-9dc6-dbf9483eded3"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "congo_Brazzaville", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("57830f74-6972-4adb-98f7-6139ecba802c"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "ukraine", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("58779637-21f5-482a-8504-fee299312b40"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "estonia", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("5887dcb6-534e-421f-92cd-599c8513a07d"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "saoTomeandPrincipe", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("58eda97d-a3d0-4401-aaba-9c16ff44d1d3"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "norway", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("59a53370-745b-421c-98d9-86baeb601d39"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "kyrgyzstan", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("5abb88ee-e9dd-47b6-b85d-ab39253decbd"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "israel", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("5d5284e3-88a0-4ad7-82c8-5814cc920fd0"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "niue", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("5e628d0d-ad41-476a-9964-7a69ce908e17"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "tunisia", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("5ef35160-6024-4434-843c-2d0162239e4d"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "belgium", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("5fb036b1-1db2-49be-a90e-20eab3c2b9a0"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "britishVirginIslands", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("5fe7f1a4-6365-4f16-b701-fdfcaeec2ef8"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "newCaledonia", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("6112d4de-83ac-44ad-a1ce-4f9254c70396"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "canaryIslands", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("6120e770-92f9-45df-9067-ecc797a1a8ae"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "cambodia", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("6128ab30-179c-4b82-ae43-91c7e2497944"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "tuvalu", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("61c6ff67-3b3e-4d16-9efe-9a193f047977"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "thailand", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("6234c443-08fd-41ad-ba58-2efebd52ce56"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "djibouti", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("62389e4d-30f3-415b-9610-d2dcc2ef3848"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "argentina", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("634163ca-e43f-44f7-995a-9a5bfb08c425"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "jamaica", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("64153b80-b5e0-4cd1-b46e-35fe877d6999"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "uruguay", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("67cee8bd-e33b-42f9-bca3-87a4690a3ba3"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "uzbekistan", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("68900ea3-0d76-4230-b04f-cbd600f99741"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "ethiopia", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("692ef2c0-fd01-406e-bc1d-45924e89bc3a"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "sudan", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("69a7f4ad-49c8-4df1-a608-8c55c266e8e3"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "czechRepublic", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("69e22054-0ba6-4cc7-93ac-3f0fee2e86c1"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "norfolkIsland", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("6a444ffa-29f0-4f5c-a2e2-2d53efcbd192"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "greenland", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("6c6b5c92-1e18-4510-b59d-b142fb8adf08"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "pakistan", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("6cfc4c40-d5fe-49f3-b08b-cd26d3b7319d"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "comoros", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("6e1d6b13-b6ca-4961-9d87-e96c919d0603"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "holySee_VaticanCityState", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("6fb1a93e-053d-4281-be75-380c99295b4b"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "pitcairn", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("7089d94c-f1a2-4c7f-815b-a0faf74799cc"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "madagascar", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("756cf722-f42f-4ce0-9bb3-d8e84309a200"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "gabon", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("78483beb-0e29-4fe5-962f-d939334955e6"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "mongolia", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("78902856-a534-4de8-bfeb-b1b569bcbf50"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "lithuania", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("792d769c-37d6-4e49-a747-01cf8709561e"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "tanzania", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("79302f5c-e8ef-4745-8ac0-6d784cfa3922"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "russianFederation", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("7a223268-c0ae-49ec-b4b6-ee8305b083f3"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "marshallIslands", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("7a840d71-d3dd-4ba5-90ed-88d40fe2688d"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "maldives", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("7fec6735-9ecd-449e-b2b3-b78ae789ba67"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "france", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("803bc633-8ca1-451d-90c1-014be09e3992"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "unitedKingdom", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("82424e80-032c-4e2e-a6a7-7137b733f234"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "nigeria", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("837e4cd3-73b7-4ba6-b0e5-3a173aef770b"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "nicaragua", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("8442d65b-72e6-4ff5-9042-8ef80b09b8dd"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "ghana", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("86063891-b57b-4deb-a75a-ae0e77cae5b8"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "hongKong", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("86b69631-1afe-4aac-b6a4-b72a0343c1c9"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "bulgaria", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("89639b59-9222-4bba-a064-d2c86edfe36c"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "kenya", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("8b77f07b-365d-4d50-aecd-a89f34a20fbb"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "bouvetIsland", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("8cdbbc1a-6752-4fcf-b6d1-a6e1e62b750c"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "northKorea", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("8d28d89a-30d4-450b-ba14-12bdc7e8e678"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "azores", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("9044c2cb-1d2a-4d18-874b-12fcc73f9479"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "faroeIslands", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("90e539e1-0af3-49e4-8c81-68b45d4ad8ee"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "moldova", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("90e9004f-7cc6-41de-bb5a-9b2d65bde494"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "netherlandsAntilles", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("917953a4-9e42-4acb-820c-9eb7f9a212bf"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "ireland", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("92475d24-3cb9-45ed-aa2c-93a8334771cc"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "georgia", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("938860a9-c55e-4759-8ab9-20b03ac40ad8"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "guadeloupe", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("9421ba7e-3eee-476a-b81e-e12edcffb767"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "vietnam", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("94411edb-e99f-4c0f-8fce-0a694a2c89c3"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "frenchPolynesia", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("94e31adc-0e4d-4e7c-9675-2adf56fac25e"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "fiji", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("97e4ab05-3169-4aaf-85d6-1eb9a96cd0f5"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "hungary", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("985857d2-1c33-48c1-9650-142d8ca12102"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "angola", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("989fb01d-b1a6-4126-a825-88d597508b1a"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "japan", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("9af80357-2e4c-4b7d-adae-51f7558534fd"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "jersey", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("9c83566a-d2ab-43c5-9b8d-2eef3e4aab01"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "iran", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("9cef2597-c77d-4c50-8a22-f38639d8bd3c"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "unitedStatesofAmerica", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("9d0b38f8-9774-4429-a765-22ecb3f3a2c0"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "burundi", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("9d9430f8-83db-409f-a347-74848151cd6a"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "slovenia", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("9e1df8db-91eb-42c4-9d3c-d1fd31e9e8ec"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "eritrea", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("9e7f4cdc-5a13-4cf5-a698-33d1c4538f71"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "centralAfricanRepublic", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("a0fd9d48-ffda-4dd7-aa5a-d7afa530edb2"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "saintPierreandMiquelon", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("a195423b-d233-4750-b5da-75dd55dc9bed"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "macedonia", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("a1967e0c-2143-45a3-aac0-af50d917c032"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "saudiArabia", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("a21ed24a-b4a7-4b1e-aa2b-1eb96d73a9fc"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "democraticRepublicOfCongo", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("a29257d7-54fe-420b-8aea-f4004de9349f"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "unitedStatesMinorOutlyingIslands", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("a52095d2-3c29-4c74-b97f-26f3a576fb36"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "malta", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("a6cec1ca-5f23-4e7a-9469-c28c3c104bb2"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "christmasIsland", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("a7f36d65-15e4-491b-a077-fd1190d55b75"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "nauru", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("a8eee712-d991-4024-a3c5-2b5ee32fcd89"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "spain", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("a99867ff-e32c-4a22-ad30-72697f59c18c"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "egypt", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("aa5c9c2f-a160-4b6f-95a6-d27f190cf2db"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "iceland", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("ab4ebbd0-06ec-4afc-ab57-ea9bf33d6fed"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "gambia", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("abf4e2d0-45d7-4646-9eff-c52d65498211"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "cuba", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("b4ede63f-5ec4-4c3b-a953-578ec22b5e42"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "kuwait", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("b60fe68a-bb0a-4e05-9451-d037a8c04b77"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "southSudan", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("b6436c16-b55d-4cfc-8a64-9a25d4cab69c"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "lebanon", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("b9832ffe-e3d8-4ce8-9401-77f259072655"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "chad", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("b9ea8d16-75c0-4373-b1da-50e5d99eb1c9"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "bahrain", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("bb29fe83-1ef7-46e6-a981-cf4e80ff3adc"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "kazakhstan", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("bb584f52-216e-41a6-947f-25ce81ea31d1"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "southGeorgiaandtheSouthSandwichIslands", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("bc872b48-ed63-44dc-bc67-3961e3aca984"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "frenchSouthernTerritories", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("bd3c7d39-097a-4d36-a98a-d0fcde13de5b"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "aruba", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("bddb6be9-a86c-4867-9402-03de5ebe75bb"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "colombia", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("be1b1ad7-2110-4949-ad27-5f2f2eb2ccd6"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "southKorea", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("beae0d65-bb52-46fe-97c6-3a317153254d"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "lesotho", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("bf3915ff-2dd6-4d9b-8310-0f520876e067"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "solomonIslands", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("bf41476f-6b21-4cac-86e6-b525baa40c7a"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "timorLeste", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("bf48b5b1-f703-4719-9910-e511ba98ac79"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "federatedStatesOfMicronesia", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("bf7f7560-3440-47c1-9044-211705f0b442"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "peru", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("c1eb2252-9553-4374-a458-9a4f3a05b8bc"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "finland", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("c298ca61-2782-4a11-94f9-7488dd3c7896"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "trinidadandTobago", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("c2c63aab-b3db-4c23-8b0d-0ae7e49ba5d3"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "oman", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("c35869d1-a080-466b-adc8-3dd204ddf796"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "monaco", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("c3dad626-91e5-4d8d-9458-2cf5859c713d"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "southAfrica", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("c58389f0-2c79-4432-9475-64e34bc92013"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "malaysia", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("c5b4c182-ca62-4739-b0bb-c987f4d1a3c8"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "slovakia", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("c5edfd47-7c03-41e7-a990-cae739d2b3ce"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "luxembourg", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("c8978f23-cbc1-4a42-8527-12738418fa16"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "panama", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("ca148ea4-6dbf-4100-ae46-d52b23d98f8b"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "gibraltar", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("cbd7fa6b-19eb-4e31-8b83-095e6af177eb"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "belarus", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("ceedde9c-f87e-4d12-9fe1-357ad3ff9a30"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "albania", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("ceef9f17-761e-47f9-992d-61cee36e8d0e"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "elSalvador", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("cfaa310e-3111-4735-86ee-0f178e8d8738"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "yemen", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("d3ff1141-392d-4c2b-9a14-abc355d07910"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "qatar", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("d6116fae-56d4-4aad-818e-8b24767841c1"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "coted_Ivoire", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("d7b6d524-cf06-438b-a0fa-a4279ebf09db"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "bosniaandHerzegovina", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("dbe7d019-667f-450b-bb43-ac0809af6d5f"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "capeVerde", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("de2b7326-1221-41fc-bfd6-da504250218e"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "cookIslands", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("de603100-3f70-4df2-9f83-af00b14792c1"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "saintBarthelemy", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("dea44f0f-6bd4-4b93-bad5-0316ed27046f"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "guineaBissau", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("dfad6b9e-37c8-446b-91a7-0c12c7978922"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "greece", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("e0230e1a-ad48-4d57-8aa2-be1a5281076c"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "guyana", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("e1113ded-9f28-4f8c-adfa-f3f650fa3287"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "mozambique", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("e20abe3a-f043-417b-b082-f37c8e9d97f4"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "alandIslands", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("e2b2d890-da1b-4f83-8f83-f130f4d80bec"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "cyprus", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("e51b0b7b-7dc1-4629-9fd3-e34e348e1359"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "nepal", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("e545f693-1fa7-4bc2-91d6-0bdebf507955"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "serbia", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("e691eb22-e585-46f4-a423-fdbf44aee804"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "azerbaijan", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("e7d64d7c-2530-4a9d-9143-16859a7c1561"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "namibia", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("e8cadf33-918e-44ce-a9a7-edb632010d69"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "zimbabwe", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("e935aee9-aa72-4b7d-a6d2-26a8cfc5bce8"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "unitedArabEmirates", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("e94eb194-cbf0-49a7-8f9c-1f171fbcba21"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "paraguay", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("edc4257c-0c52-433d-940c-2b8da8e180d2"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "bolivia", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("ee9fdfe6-2970-4bc2-af5c-7d28a3894305"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "caymanIslands", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("eec5a93d-575f-4751-b35f-a864a4be41bd"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "portugal", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("f0111e67-1973-444d-8501-aa6d7a817db4"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "palau", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("f155eabc-1727-40e9-b900-e7601c655f8a"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "martinique", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("f22ec918-69e9-42e8-9a23-10bbd7f6c98a"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "bangladesh", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("f465a47c-71c5-417f-83af-6b26d2fa4b5d"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "poland", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("f4b0dcff-f13b-4e34-b3e8-9e9c5d9df50a"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "germany", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("f57e25d4-26db-41ff-a305-373df80d224b"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "turkmenistan", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("f6470680-2a63-41c7-a00c-99800c1322fd"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "denmark", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("f7636092-640d-49f8-88d6-0c599030ebd8"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "frenchGuiana", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("f7672f22-a297-4ae1-aa2d-78ede3228696"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "antarctica", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("f7b2d905-d7e4-4ed1-b77c-c88fda53240e"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "iraq", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("f85afa3d-44cc-467f-8230-600f729cd2b9"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "taiwan", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("f8c45210-1bf5-4a2b-a4f0-d66d9098b232"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "niger", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("fc7540e0-d2f4-4064-8842-ce6681cff421"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "bhutan", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("fcbb47b8-4f57-47f6-ad5d-696caafa6331"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "canada", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("fda4c7f9-c84c-418a-9d96-dd2e0776469b"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "palestinianTerritory_Occupied", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("ff4ffb25-ee17-43a2-93a0-bb673a71f516"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPCountry, "guinea", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPCountryRecord("ff7ce6ac-502f-4148-8b99-a184b75d9cad"));
}
});

ShopperPortalEU_CSModel.staticEntities.sPRefundMessage = {};
var getSPRefundMessageRecord = function (record) {
return ShopperPortalEU_CSModel.module.staticEntities["e9ed2496-4882-40d4-a42d-21ab14d3d46a"][record];
};
Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPRefundMessage, "feesMayApply", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPRefundMessageRecord("383e5ec2-d314-4653-8e0e-51a1543b15cb"));
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPRefundMessage, "exchangeRateMayApply", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSPRefundMessageRecord("85a12618-464f-453b-8782-80f596fa7885"));
}
});

ShopperPortalEU_CSModel.staticEntities.sPFormStatus = {};
var getSPFormStatusRecord = function (record) {
return ShopperPortalEU_CSModel.module.staticEntities["fbf43fd7-21ba-4911-a301-a6b77599ca4c"][record];
};
Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPFormStatus, "preRefundClaimRejected", {
get: function () {
return getSPFormStatusRecord("027b4946-de19-47fc-8a1c-0ad444d807bf");
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPFormStatus, "preRefundClaimOngoing", {
get: function () {
return getSPFormStatusRecord("04b06f22-59a4-49c0-80b5-23e30caa6e4f");
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPFormStatus, "preCustomsInspectionRequired", {
get: function () {
return getSPFormStatusRecord("14cc82e2-957e-4f8f-a37d-a7900f51e536");
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPFormStatus, "preRefundRevoked_RB8", {
get: function () {
return getSPFormStatusRecord("1f3ba60c-bc66-497f-97cd-efdc574874f5");
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPFormStatus, "postRefundClaimRejected", {
get: function () {
return getSPFormStatusRecord("3366f6fe-154b-4c79-b6b0-8e492d1c0e70");
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPFormStatus, "postRefundOnHold", {
get: function () {
return getSPFormStatusRecord("38c905a5-64ae-428b-9b4b-4d29d8fce714");
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPFormStatus, "postRefundApproved_RA3", {
get: function () {
return getSPFormStatusRecord("3b8ce5ef-4cd9-4fba-8ab1-c51c5cfb3e0f");
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPFormStatus, "preRefundRevoked_RB4", {
get: function () {
return getSPFormStatusRecord("43819221-0247-4c22-9f92-84232e50022c");
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPFormStatus, "postRefundClaimCancelled_VA6", {
get: function () {
return getSPFormStatusRecord("4b5676ae-81ea-475f-9cb0-67d465a79d57");
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPFormStatus, "refundClaimPending", {
get: function () {
return getSPFormStatusRecord("5048c975-e7a0-4391-9238-91f80c4e703a");
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPFormStatus, "preRefundRevoked_RB7", {
get: function () {
return getSPFormStatusRecord("5907711b-d366-40fb-9d98-b8d78104fb2a");
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPFormStatus, "postRefundClaimExpired_VA5", {
get: function () {
return getSPFormStatusRecord("5d1778de-efb7-4b9c-a4a3-9c03f08c7057");
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPFormStatus, "preRefundClaimCompleted_RB3", {
get: function () {
return getSPFormStatusRecord("6cdc4424-31d8-4959-b9c2-15fcc045d0b9");
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPFormStatus, "preRefundClaimCancelled", {
get: function () {
return getSPFormStatusRecord("78ce7dc6-d1e4-4114-bc3a-7c9b671710fa");
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPFormStatus, "preGetCustomsApproval", {
get: function () {
return getSPFormStatusRecord("7e0f7c79-5177-43ce-aa5f-e8fb67db71ba");
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPFormStatus, "postRefundClaimCancelled_RA9", {
get: function () {
return getSPFormStatusRecord("895a5bf8-72f2-45fb-b862-e918b4573e59");
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPFormStatus, "postRefunded_RA7", {
get: function () {
return getSPFormStatusRecord("960ee4c6-05f6-4086-8b6c-4dd7dbfb8a42");
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPFormStatus, "preUpdateRefundDetails", {
get: function () {
return getSPFormStatusRecord("99688444-4770-4b6f-9378-49e36e616939");
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPFormStatus, "postRefundDetailsRequired", {
get: function () {
return getSPFormStatusRecord("ab960dd4-4691-4d84-8d20-c1bd43ce89e6");
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPFormStatus, "postRefundClaimExpired_RA8", {
get: function () {
return getSPFormStatusRecord("b7be8186-c786-43f3-8972-b345ed28b995");
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPFormStatus, "postGetCustomsApproval", {
get: function () {
return getSPFormStatusRecord("bb7d65af-552b-485c-954d-30006dd1fa8c");
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPFormStatus, "postRefundApproved_RA11", {
get: function () {
return getSPFormStatusRecord("cf654140-6869-45df-a236-903380d51c7e");
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPFormStatus, "postRefundInProgress", {
get: function () {
return getSPFormStatusRecord("d50d900f-2dad-4cd2-88fb-20446450a3f3");
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPFormStatus, "postRefunded_RA10", {
get: function () {
return getSPFormStatusRecord("d960ec0f-1506-4c0b-aa07-8c388704e023");
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPFormStatus, "preRefundClaimCompleted_RB6", {
get: function () {
return getSPFormStatusRecord("f2372b04-3269-4df2-8f6f-39e905fa97c6");
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPFormStatus, "postCustomsInspectionRequired", {
get: function () {
return getSPFormStatusRecord("f36f9d17-5cd4-4bab-bc30-240b1e6d3a51");
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.sPFormStatus, "postUpdateRefundDetails", {
get: function () {
return getSPFormStatusRecord("fd776400-6f57-44df-a1bf-ec7084dcd23a");
}
});

ShopperPortalEU_CSModel.staticEntities.customTagState = {};
var getCustomTagStateRecord = function (record) {
return OS.ApplicationInfo.getModules()["e7bb7e26-af64-4f69-9436-0768d54ea01b"].staticEntities["0ecb397c-3ce5-471f-b18f-87158598df3a"][record];
};
Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.customTagState, "error", {
get: function () {
return getCustomTagStateRecord("04940de8-397c-4994-96fc-567cc3bb20b1");
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.customTagState, "new", {
get: function () {
return getCustomTagStateRecord("2155d0da-5bf6-4aa3-93ff-4b1503152d74");
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.customTagState, "success", {
get: function () {
return getCustomTagStateRecord("3ee16a50-b2ad-406b-957c-64848a014a00");
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.customTagState, "neutral", {
get: function () {
return getCustomTagStateRecord("c0f27e66-d8bf-42e4-9a1a-3513dce3a21d");
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.customTagState, "info", {
get: function () {
return getCustomTagStateRecord("c0f66ae5-a24d-4d28-ad01-728a7a41fea0");
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.customTagState, "warning", {
get: function () {
return getCustomTagStateRecord("ccc52884-abd4-414f-bdfb-97412fa5bd64");
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.customTagState, "neutralDark", {
get: function () {
return getCustomTagStateRecord("d89d1c3c-871e-4b16-8580-f20a79b9c223");
}
});

ShopperPortalEU_CSModel.staticEntities.cardStateType = {};
var getCardStateTypeRecord = function (record) {
return OS.ApplicationInfo.getModules()["e7bb7e26-af64-4f69-9436-0768d54ea01b"].staticEntities["cda633b3-44e4-4d03-b041-4ee42266a05a"][record];
};
Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.cardStateType, "warning", {
get: function () {
return getCardStateTypeRecord("2267ce4f-86c5-4534-9a05-9bc4c1a2b8a6");
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.cardStateType, "success", {
get: function () {
return getCardStateTypeRecord("3358c40b-9c87-49f1-8f5a-cd589557c30e");
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.cardStateType, "info", {
get: function () {
return getCardStateTypeRecord("9dce627a-d246-40cc-a52b-296c2b8e66e5");
}
});

Object.defineProperty(ShopperPortalEU_CSModel.staticEntities.cardStateType, "error", {
get: function () {
return getCardStateTypeRecord("cb221e47-9ec7-4a77-af8c-f1208585d4c4");
}
});

});
