define("ShopperPortalEU_UI_Theme.controller$AddFavicon", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.controller", "ShopperPortalEU_UI_Theme.controller$AddFavicon.AddFaviconJS"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ThemeController, ShopperPortalEU_UI_Theme_controller_AddFavicon_AddFaviconJS) {
var OS = OutSystems.Internal;
ShopperPortalEU_UI_ThemeController.default.addFavicon$Action = function (uRLIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Theme.AddFavicon$vars"))());
vars.value.uRLInLocal = uRLIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("1ohZxgV1_kKH2z+Fu01SDQ:s3nf454iq0+DYyxUnn3T7g:/ClientActionFlows.s3nf454iq0+DYyxUnn3T7g:LEgdlK2jQiXxDctZ7XSiMw", "ShopperPortalEU_UI_Theme", "AddFavicon", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:0cux3L0rwE6UWBgbSSfixg", callContext.id);
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:r1ED8qqvGkWb0YnOwdZ0ew", callContext.id);
// Add favicon to your project
controller.safeExecuteJSNode(ShopperPortalEU_UI_Theme_controller_AddFavicon_AddFaviconJS, "AddFavicon", "AddFavicon", {
URL: OS.DataConversion.JSNodeParamConverter.to(vars.value.uRLInLocal, OS.DataTypes.DataTypes.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:xngvSUFdzECjknuidQKLCQ", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("1ohZxgV1_kKH2z+Fu01SDQ:s3nf454iq0+DYyxUnn3T7g", callContext.id);
}

};
var controller = ShopperPortalEU_UI_ThemeController.default;
ShopperPortalEU_UI_ThemeController.default.constructor.registerVariableGroupType("ShopperPortalEU_UI_Theme.AddFavicon$vars", [{
name: "URL",
attrName: "uRLInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEU_UI_ThemeController.default.clientActionProxies.addFavicon$Action = function (uRLIn) {
uRLIn = (uRLIn === undefined) ? "" : uRLIn;
return controller.executeActionInsideJSNode(ShopperPortalEU_UI_ThemeController.default.addFavicon$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(uRLIn, OS.DataTypes.DataTypes.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("ShopperPortalEU_UI_Theme.controller$AddFavicon.AddFaviconJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var link = document.querySelector("link[rel*='icon']") || document.createElement('link');
link.type = 'image/x-icon';
link.rel = 'shortcut icon';
link.href = $parameters.URL;
document.getElementsByTagName('head')[0].appendChild(link);
};
});

define("ShopperPortalEU_UI_Theme.controller$CustomMessageHide", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.controller", "ShopperPortalEU_UI_Theme.controller$CustomMessageHide.HideJS"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ThemeController, ShopperPortalEU_UI_Theme_controller_CustomMessageHide_HideJS) {
var OS = OutSystems.Internal;
ShopperPortalEU_UI_ThemeController.default.customMessageHide$Action = function (noHideIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Theme.CustomMessageHide$vars"))());
vars.value.noHideInLocal = noHideIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("1ohZxgV1_kKH2z+Fu01SDQ:dXcr90swvk2fVxooWhwwtg:/ClientActionFlows.dXcr90swvk2fVxooWhwwtg:lPHCJ4a6oNyti7qZiR1WHw", "ShopperPortalEU_UI_Theme", "CustomMessageHide", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:238dZJLW4kq73xmdfhb9Zg", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:WGBSlwVSeEaQdBxoustHag", callContext.id) && vars.value.noHideInLocal)) {
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:OSj7CF7nck2xpUyXe3mrnA", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:4DYDJ1gUm0KhwTOpgvJQ1g", callContext.id);
// CustomMessage component hide method.
controller.safeExecuteJSNode(ShopperPortalEU_UI_Theme_controller_CustomMessageHide_HideJS, "Hide", "CustomMessageHide", null, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:FDeEhLazBUK079KdEzkfoA", callContext.id);
}

return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("1ohZxgV1_kKH2z+Fu01SDQ:dXcr90swvk2fVxooWhwwtg", callContext.id);
}

};
var controller = ShopperPortalEU_UI_ThemeController.default;
ShopperPortalEU_UI_ThemeController.default.constructor.registerVariableGroupType("ShopperPortalEU_UI_Theme.CustomMessageHide$vars", [{
name: "NoHide",
attrName: "noHideInLocal",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Boolean,
defaultValue: function () {
return false;
}
}]);
ShopperPortalEU_UI_ThemeController.default.clientActionProxies.customMessageHide$Action = function (noHideIn) {
noHideIn = (noHideIn === undefined) ? false : noHideIn;
return controller.executeActionInsideJSNode(ShopperPortalEU_UI_ThemeController.default.customMessageHide$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(noHideIn, OS.DataTypes.DataTypes.Boolean)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("ShopperPortalEU_UI_Theme.controller$CustomMessageHide.HideJS", [], function () {
return function ($actions, $roles, $public) {
if(window.layout && window.layout.customMessage){
    window.layout.customMessage.hide();
}
};
});

define("ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.controller", "ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger.TriggerJS", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ThemeController, ShopperPortalEU_UI_Theme_controller_CustomMessageTrigger_TriggerJS) {
var OS = OutSystems.Internal;
ShopperPortalEU_UI_ThemeController.default.customMessageTrigger$Action = function (optionsIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Theme.CustomMessageTrigger$vars"))());
vars.value.optionsInLocal = optionsIn.clone();
var optionsJSONVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.JSONSerializeOutputType());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.optionsJSONVar = optionsJSONVar;
try {OutSystemsDebugger.push("1ohZxgV1_kKH2z+Fu01SDQ:p7GyJHdMfkuSgB5kcJDYkA:/ClientActionFlows.p7GyJHdMfkuSgB5kcJDYkA:5QR_azuD816gsCDzrvOJGw", "ShopperPortalEU_UI_Theme", "CustomMessageTrigger", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:SgXyefN7zkafCC+h_qkiZw", callContext.id);
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:tsp9IthgU0e_ZrSmtGfzoA", callContext.id);
// JSON Serialize: OptionsJSON
optionsJSONVar.value.jSONOut = OS.JSONUtils.serializeToJSON(vars.value.optionsInLocal, true, false);
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:tHp6QLoLHE2B61m6ngoxqg", callContext.id);
// CustomMessage component trigger method.
controller.safeExecuteJSNode(ShopperPortalEU_UI_Theme_controller_CustomMessageTrigger_TriggerJS, "Trigger", "CustomMessageTrigger", {
Options: OS.DataConversion.JSNodeParamConverter.to(optionsJSONVar.value.jSONOut, OS.DataTypes.DataTypes.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:GdCWKi7G5Ua4dlO8_vAK2A", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("1ohZxgV1_kKH2z+Fu01SDQ:p7GyJHdMfkuSgB5kcJDYkA", callContext.id);
}

};
var controller = ShopperPortalEU_UI_ThemeController.default;
ShopperPortalEU_UI_ThemeController.default.constructor.registerVariableGroupType("ShopperPortalEU_UI_Theme.CustomMessageTrigger$vars", [{
name: "Options",
attrName: "optionsInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Record,
defaultValue: function () {
return new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec();
},
complexType: ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec
}]);
ShopperPortalEU_UI_ThemeController.default.clientActionProxies.customMessageTrigger$Action = function (optionsIn) {
optionsIn = (optionsIn === undefined) ? new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec() : optionsIn;
return controller.executeActionInsideJSNode(ShopperPortalEU_UI_ThemeController.default.customMessageTrigger$Action.bind(controller, optionsIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger.TriggerJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
if(window.layout){
    if (window.layout.customMessage) {
        window.layout.customMessage.trigger(JSON.parse($parameters.Options));
    } else {
        window.layout.customMessageWait = JSON.parse($parameters.Options);
    }
}

};
});

define("ShopperPortalEU_UI_Theme.controller$SetDirection", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.controller", "ShopperPortalEU_UI_Theme.controller$SetDirection.SetDirectionJS"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ThemeController, ShopperPortalEU_UI_Theme_controller_SetDirection_SetDirectionJS) {
var OS = OutSystems.Internal;
ShopperPortalEU_UI_ThemeController.default.setDirection$Action = function (isRTLIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Theme.SetDirection$vars"))());
vars.value.isRTLInLocal = isRTLIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("1ohZxgV1_kKH2z+Fu01SDQ:xY_3QgfOFUCYvMMVa3HVMA:/ClientActionFlows.xY_3QgfOFUCYvMMVa3HVMA:CnhyeRWoXbeOS3EeizO3Pw", "ShopperPortalEU_UI_Theme", "SetDirection", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:GzomN+JZ3EKllBF2W+Z+hw", callContext.id);
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:wB_oGnvrnkGKUgBLAHCpNw", callContext.id);
// Set direction js
controller.safeExecuteJSNode(ShopperPortalEU_UI_Theme_controller_SetDirection_SetDirectionJS, "SetDirection", "SetDirection", {
IsRTL: OS.DataConversion.JSNodeParamConverter.to(vars.value.isRTLInLocal, OS.DataTypes.DataTypes.Boolean)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:J0BNIfgI2E+noFG6TqRXdA", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("1ohZxgV1_kKH2z+Fu01SDQ:xY_3QgfOFUCYvMMVa3HVMA", callContext.id);
}

};
var controller = ShopperPortalEU_UI_ThemeController.default;
ShopperPortalEU_UI_ThemeController.default.constructor.registerVariableGroupType("ShopperPortalEU_UI_Theme.SetDirection$vars", [{
name: "IsRTL",
attrName: "isRTLInLocal",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Boolean,
defaultValue: function () {
return false;
}
}]);
ShopperPortalEU_UI_ThemeController.default.clientActionProxies.setDirection$Action = function (isRTLIn) {
isRTLIn = (isRTLIn === undefined) ? false : isRTLIn;
return controller.executeActionInsideJSNode(ShopperPortalEU_UI_ThemeController.default.setDirection$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(isRTLIn, OS.DataTypes.DataTypes.Boolean)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("ShopperPortalEU_UI_Theme.controller$SetDirection.SetDirectionJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
if($parameters.IsRTL){
    document.body.classList.remove('is-ltr');
    document.body.classList.add('is-rtl');
}else{
    document.body.classList.remove('is-rtl');
    document.body.classList.add('is-ltr');
}
};
});

define("ShopperPortalEU_UI_Theme.controller", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.controller$debugger"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_Theme_Controller_debugger) {
var OS = OutSystems.Internal;
var ShopperPortalEU_UI_ThemeController = exports;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
}
Controller.prototype.clientActionProxies = {};
Controller.prototype.roles = {};
Controller.prototype.defaultTimeout = 10;
Controller.prototype.getDefaultTimeout = function () {
return ShopperPortalEU_UI_ThemeController.default.defaultTimeout;
};
Controller.prototype.getClientActionProxies = function (controller) {
var _this = this;
var thisController = controller;
return Object.keys(this.clientActionProxies).reduce(function (acc, actionName) {
acc[actionName] = function () {
if(thisController.isActive()) {
return _this.clientActionProxies[actionName].apply(thisController, arguments);
}

return Promise.resolve();
};
return acc;
}, {});
};
return Controller;
})(OS.Controller.BaseModuleController);
ShopperPortalEU_UI_ThemeController.default = new Controller(null, "ShopperPortalEU_UI_Theme");
});
define("ShopperPortalEU_UI_Theme.controller$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"jn_4dXU07Ue0qvM_0Xl_NA": {
getter: function (varBag, idService) {
return varBag.vars.value.optionsInLocal;
}
},
"tsp9IthgU0e_ZrSmtGfzoA": {
getter: function (varBag, idService) {
return varBag.optionsJSONVar.value;
}
},
"tHp6QLoLHE2B61m6ngoxqg": {
getter: function (varBag, idService) {
return varBag.triggerJSResult.value;
}
},
"XjqhXLZS6USTe3Qc2GGD6w": {
getter: function (varBag, idService) {
return varBag.vars.value.isRTLInLocal;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"wB_oGnvrnkGKUgBLAHCpNw": {
getter: function (varBag, idService) {
return varBag.setDirectionJSResult.value;
}
},
"eLGqUfzjTUuMYz6okcdoRA": {
getter: function (varBag, idService) {
return varBag.vars.value.uRLInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"r1ED8qqvGkWb0YnOwdZ0ew": {
getter: function (varBag, idService) {
return varBag.addFaviconJSResult.value;
}
},
"XZJ9fV48PkyqbhvPovTwKA": {
getter: function (varBag, idService) {
return varBag.vars.value.noHideInLocal;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"4DYDJ1gUm0KhwTOpgvJQ1g": {
getter: function (varBag, idService) {
return varBag.hideJSResult.value;
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
