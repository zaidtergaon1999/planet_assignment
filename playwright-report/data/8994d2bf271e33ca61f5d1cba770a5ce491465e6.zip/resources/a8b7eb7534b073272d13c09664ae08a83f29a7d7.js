define("ShopperPortalEU_UI_Theme.Private.ApplicationLoadEvents.mvc$model", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model"], function (OutSystems, ShopperPortalEU_UI_ThemeModel) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("Timeout", "timeoutVar", "Timeout", true, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, false), 
this.attr("MinimumDisplayTimeMs", "minimumDisplayTimeMsIn", "MinimumDisplayTimeMs", true, false, OS.DataTypes.DataTypes.Integer, function () {
return 1500;
}, false), 
this.attr("_minimumDisplayTimeMsInDataFetchStatus", "_minimumDisplayTimeMsInDataFetchStatus", "_minimumDisplayTimeMsInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return false;
}
});

Model.prototype.setInputs = function (inputs) {
if("MinimumDisplayTimeMs" in inputs) {
this.variables.minimumDisplayTimeMsIn = inputs.MinimumDisplayTimeMs;
if("_minimumDisplayTimeMsInDataFetchStatus" in inputs) {
this.variables._minimumDisplayTimeMsInDataFetchStatus = inputs._minimumDisplayTimeMsInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "Private.ApplicationLoadEvents");
});
define("ShopperPortalEU_UI_Theme.Private.ApplicationLoadEvents.mvc$view", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.controller", "react", "OutSystems/ReactView/Main", "ShopperPortalEU_UI_Theme.Private.ApplicationLoadEvents.mvc$model", "ShopperPortalEU_UI_Theme.Private.ApplicationLoadEvents.mvc$controller"], function (OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ThemeController, React, OSView, ShopperPortalEU_UI_Theme_Private_ApplicationLoadEvents_mvc_model, ShopperPortalEU_UI_Theme_Private_ApplicationLoadEvents_mvc_controller) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            var thisIsInstanceOfSuper = this instanceof _super;
            if (thisIsInstanceOfSuper == false) {
                return;
            }

            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "Private.ApplicationLoadEvents";
        View.getCssDependencies = function() {
            return [];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return ShopperPortalEU_UI_Theme_Private_ApplicationLoadEvents_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return ShopperPortalEU_UI_Theme_Private_ApplicationLoadEvents_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties());
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("ShopperPortalEU_UI_Theme.Private.ApplicationLoadEvents.mvc$controller", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.controller", "ShopperPortalEU_UI_Theme.languageResources", "ShopperPortalEU_UI_Theme.Private.ApplicationLoadEvents.mvc$debugger", "ShopperPortalEU_UI_Theme.Private.ApplicationLoadEvents.mvc$controller.OnDestroy.clearTimeoutJS", "ShopperPortalEU_UI_Theme.Private.ApplicationLoadEvents.mvc$controller.OnDestroy.DeleteJS", "ShopperPortalEU_UI_Theme.Private.ApplicationLoadEvents.mvc$controller.OnInitialize.RegisterListenersJS"], function (OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ThemeController, ShopperPortalEU_UI_ThemeLanguageResources, ShopperPortalEU_UI_Theme_Private_ApplicationLoadEvents_mvc_Debugger, ShopperPortalEU_UI_Theme_Private_ApplicationLoadEvents_mvc_controller_OnDestroy_clearTimeoutJS, ShopperPortalEU_UI_Theme_Private_ApplicationLoadEvents_mvc_controller_OnDestroy_DeleteJS, ShopperPortalEU_UI_Theme_Private_ApplicationLoadEvents_mvc_controller_OnInitialize_RegisterListenersJS) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {
triggerOnUpgradeProgress$Action: function (completedIn, totalIn) {
completedIn = (completedIn === undefined) ? 0 : completedIn;
totalIn = (totalIn === undefined) ? 0 : totalIn;
return controller.executeActionInsideJSNode(controller._triggerOnUpgradeProgress$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(completedIn, OS.DataTypes.DataTypes.Integer), OS.DataConversion.JSNodeParamConverter.from(totalIn, OS.DataTypes.DataTypes.Integer)), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "TriggerOnUpgradeProgress");
},
triggerOnLoadComplete$Action: function (redirectURLIn) {
redirectURLIn = (redirectURLIn === undefined) ? "" : redirectURLIn;
return controller.executeActionInsideJSNode(controller._triggerOnLoadComplete$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(redirectURLIn, OS.DataTypes.DataTypes.Text)), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "TriggerOnLoadComplete");
}
};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = false;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._onDestroy$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnDestroy");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("1ohZxgV1_kKH2z+Fu01SDQ:892qGq5ZN0OhIH9gFoNSpA:/NRWebFlows.7yoxAlgBGkuVWruL67h_aw/NodesShownInESpaceTree.dsSTNlfm+EWvMZbhliHMGw/ClientActions.892qGq5ZN0OhIH9gFoNSpA:qvnyYcqbDJ+gVKuj0YsZ2g", "ShopperPortalEU_UI_Theme", "OnDestroy", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:jwqtwqUYN0O8HO4Q2v4kSQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:4JE0oF9N5UOy7G8M1pnj0A", callContext.id);
// Remove variable to avoid action calls after block is destroyed
controller.safeExecuteJSNode(ShopperPortalEU_UI_Theme_Private_ApplicationLoadEvents_mvc_controller_OnDestroy_DeleteJS, "Delete", "OnDestroy", null, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:P69QnzulEkuRsdPU1SvTQQ", callContext.id);
// Clears the timeout set on the initialize event.
controller.safeExecuteJSNode(ShopperPortalEU_UI_Theme_Private_ApplicationLoadEvents_mvc_controller_OnDestroy_clearTimeoutJS, "clearTimeout", "OnDestroy", {
Timeout: OS.DataConversion.JSNodeParamConverter.to(model.variables.timeoutVar, OS.DataTypes.DataTypes.Integer)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:L684rVjkqkuW+o05VBmXfw", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("1ohZxgV1_kKH2z+Fu01SDQ:892qGq5ZN0OhIH9gFoNSpA", callContext.id);
}

};
Controller.prototype._triggerOnLoadComplete$Action = function (redirectURLIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("TriggerOnLoadComplete");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Theme.Private.ApplicationLoadEvents.TriggerOnLoadComplete$vars"))());
vars.value.redirectURLInLocal = redirectURLIn;
varBag.callContext = callContext;
varBag.vars = vars;
OutSystemsDebugger.push("1ohZxgV1_kKH2z+Fu01SDQ:BhXmRUzu00+Cwy4NelVMmQ:/NRWebFlows.7yoxAlgBGkuVWruL67h_aw/NodesShownInESpaceTree.dsSTNlfm+EWvMZbhliHMGw/ClientActions.BhXmRUzu00+Cwy4NelVMmQ:QitUrbCzdim26F4f7dHYDA", "ShopperPortalEU_UI_Theme", "TriggerOnLoadComplete", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:Az01Y5+ETEmE3PU903RkuQ", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:6KI4R+LFfUuvFbiN5jdZCg", callContext.id);
// Trigger Event: OnLoadComplete
return controller.onLoadComplete$Action(vars.value.redirectURLInLocal, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:WCeAWrisWU+NAF+mPwZEfg", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("1ohZxgV1_kKH2z+Fu01SDQ:BhXmRUzu00+Cwy4NelVMmQ", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("1ohZxgV1_kKH2z+Fu01SDQ:BhXmRUzu00+Cwy4NelVMmQ", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("ShopperPortalEU_UI_Theme.Private.ApplicationLoadEvents.TriggerOnLoadComplete$vars", [{
name: "RedirectURL",
attrName: "redirectURLInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
Controller.prototype._onInitialize$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnInitialize");
callContext = controller.callContext(callContext);
var registerListenersJSResult = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.registerListenersJSResult = registerListenersJSResult;
try {OutSystemsDebugger.push("1ohZxgV1_kKH2z+Fu01SDQ:HNGlUym9yUCoHMFcDh8FXg:/NRWebFlows.7yoxAlgBGkuVWruL67h_aw/NodesShownInESpaceTree.dsSTNlfm+EWvMZbhliHMGw/ClientActions.HNGlUym9yUCoHMFcDh8FXg:dmcHEzwqfSLi6It5F67z_Q", "ShopperPortalEU_UI_Theme", "OnInitialize", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:PF38tAHJ7kuUcHapvFGreQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:NUfSQGtSl0OiKYUKfgKdTA", callContext.id);
registerListenersJSResult.value = controller.safeExecuteJSNode(ShopperPortalEU_UI_Theme_Private_ApplicationLoadEvents_mvc_controller_OnInitialize_RegisterListenersJS, "RegisterListeners", "OnInitialize", {
MinDisplayTimeMs: OS.DataConversion.JSNodeParamConverter.to(model.variables.minimumDisplayTimeMsIn, OS.DataTypes.DataTypes.Integer),
TimeoutValue: OS.DataConversion.JSNodeParamConverter.to(0, OS.DataTypes.DataTypes.Integer)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Theme.Private.ApplicationLoadEvents.OnInitialize$registerListenersJSResult"))();
jsNodeResult.timeoutValueOut = OS.DataConversion.JSNodeParamConverter.from($parameters.TimeoutValue, OS.DataTypes.DataTypes.Integer);
return jsNodeResult;
}, {
TriggerOnUpgradeProgress: controller.clientActionProxies.triggerOnUpgradeProgress$Action,
TriggerOnLoadComplete: controller.clientActionProxies.triggerOnLoadComplete$Action
}, {});
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:Ls7v33SlfUK5fwfNhZOZ_w", callContext.id);
// Timeout = RegisterListeners.TimeoutValue
model.variables.timeoutVar = registerListenersJSResult.value.timeoutValueOut;
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:5QteHvScKEaRtwZT8_c6tw", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("1ohZxgV1_kKH2z+Fu01SDQ:HNGlUym9yUCoHMFcDh8FXg", callContext.id);
}

};
Controller.registerVariableGroupType("ShopperPortalEU_UI_Theme.Private.ApplicationLoadEvents.OnInitialize$registerListenersJSResult", [{
name: "TimeoutValue",
attrName: "timeoutValueOut",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Integer,
defaultValue: function () {
return 0;
}
}]);
Controller.prototype._triggerOnUpgradeProgress$Action = function (completedIn, totalIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("TriggerOnUpgradeProgress");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Theme.Private.ApplicationLoadEvents.TriggerOnUpgradeProgress$vars"))());
vars.value.completedInLocal = completedIn;
vars.value.totalInLocal = totalIn;
varBag.callContext = callContext;
varBag.vars = vars;
OutSystemsDebugger.push("1ohZxgV1_kKH2z+Fu01SDQ:sS1Sp2YrNEisFLo5Hr3_Ig:/NRWebFlows.7yoxAlgBGkuVWruL67h_aw/NodesShownInESpaceTree.dsSTNlfm+EWvMZbhliHMGw/ClientActions.sS1Sp2YrNEisFLo5Hr3_Ig:Xcz7IddZ+4jwjC0t1OKdtw", "ShopperPortalEU_UI_Theme", "TriggerOnUpgradeProgress", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:WoeQlxUeN0Gq271Ub4NtwA", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:XdsNCsHVj0agrBNFcXSKZw", callContext.id);
// Trigger Event: OnUpgradeProgress
return controller.onUpgradeProgress$Action(vars.value.completedInLocal, vars.value.totalInLocal, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("1ohZxgV1_kKH2z+Fu01SDQ:9YVMejOEmUasrmZkm+czlw", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("1ohZxgV1_kKH2z+Fu01SDQ:sS1Sp2YrNEisFLo5Hr3_Ig", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("1ohZxgV1_kKH2z+Fu01SDQ:sS1Sp2YrNEisFLo5Hr3_Ig", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("ShopperPortalEU_UI_Theme.Private.ApplicationLoadEvents.TriggerOnUpgradeProgress$vars", [{
name: "Completed",
attrName: "completedInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Integer,
defaultValue: function () {
return 0;
}
}, {
name: "Total",
attrName: "totalInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Integer,
defaultValue: function () {
return 0;
}
}]);

Controller.prototype.onDestroy$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onDestroy$Action, callContext);

};
Controller.prototype.triggerOnLoadComplete$Action = function (redirectURLIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._triggerOnLoadComplete$Action, callContext, redirectURLIn);

};
Controller.prototype.onInitialize$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onInitialize$Action, callContext);

};
Controller.prototype.triggerOnUpgradeProgress$Action = function (completedIn, totalIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._triggerOnUpgradeProgress$Action, callContext, completedIn, totalIn);

};
Controller.prototype.onLoadComplete$Action = function () {
return Promise.resolve();
};
Controller.prototype.onUpgradeProgress$Action = function () {
return Promise.resolve();
};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("1ohZxgV1_kKH2z+Fu01SDQ:7yoxAlgBGkuVWruL67h_aw:/NRWebFlows.7yoxAlgBGkuVWruL67h_aw:SIwByfbdqIK4u4eqgw2+Bg", "ShopperPortalEU_UI_Theme", "Private", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("1ohZxgV1_kKH2z+Fu01SDQ:dsSTNlfm+EWvMZbhliHMGw:/NRWebFlows.7yoxAlgBGkuVWruL67h_aw/NodesShownInESpaceTree.dsSTNlfm+EWvMZbhliHMGw:ng_MQ5CU4Ur7D6GET1RFXg", "ShopperPortalEU_UI_Theme", "ApplicationLoadEvents", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("1ohZxgV1_kKH2z+Fu01SDQ:dsSTNlfm+EWvMZbhliHMGw", callContext.id);
OutSystemsDebugger.pop("1ohZxgV1_kKH2z+Fu01SDQ:7yoxAlgBGkuVWruL67h_aw", callContext.id);
};
Controller.prototype.onInitializeEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Private/ApplicationLoadEvents On Initialize");
return controller.onInitialize$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Private/ApplicationLoadEvents On Destroy");
return controller.onDestroy$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return ShopperPortalEU_UI_ThemeController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, ShopperPortalEU_UI_ThemeLanguageResources);
});
define("ShopperPortalEU_UI_Theme.Private.ApplicationLoadEvents.mvc$controller.OnDestroy.clearTimeoutJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
clearTimeout($parameters.Timeout);
};
});
define("ShopperPortalEU_UI_Theme.Private.ApplicationLoadEvents.mvc$controller.OnDestroy.DeleteJS", [], function () {
return function ($actions, $roles, $public) {
delete window.applicationLoadEvents;
};
});
define("ShopperPortalEU_UI_Theme.Private.ApplicationLoadEvents.mvc$controller.OnInitialize.RegisterListenersJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var start = new Date();
//Variable to control if block wasn't destroyed
window.applicationLoadEvents = true;
// Check if the app is currently being upgraded
var isUpgrading = $public.ApplicationLifecycle.isUpgradingVersion();

var progressCallback = function (loaded, total) {
    if (window.applicationLoadEvents) {
        $actions.TriggerOnUpgradeProgress(loaded, total);
    }
};

var finishCallback = function () {
    var elapsedMs = new Date() - start;
    var timeout = Math.max($parameters.MinDisplayTimeMs - elapsedMs, 0);
    $parameters.TimeoutValue = timeout;
    setTimeout(function () {
        if (window.applicationLoadEvents) {
            $actions.TriggerOnLoadComplete(window.location.href);
        }

    }, timeout);
};

// When there is no upgrade, we need to mimic the progress using the MinDisplayTimeMs
if (!isUpgrading) {
    var loaded = 0;
    var interval = Math.ceil($parameters.MinDisplayTimeMs / 10);
    var timerId = setInterval(function () {
        progressCallback(++loaded, 10);
        if (loaded === 10) {
            clearInterval(timerId);
        }
    }, interval);
}
$public.ApplicationLifecycle.listen({
    // When there is no upgrade, we'll provide the feedback
    onUpgradeProgress: isUpgrading ? progressCallback : null,
    onLoadComplete: finishCallback
});
};
});

define("ShopperPortalEU_UI_Theme.Private.ApplicationLoadEvents.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"P69QnzulEkuRsdPU1SvTQQ": {
getter: function (varBag, idService) {
return varBag.clearTimeoutJSResult.value;
}
},
"4JE0oF9N5UOy7G8M1pnj0A": {
getter: function (varBag, idService) {
return varBag.deleteJSResult.value;
}
},
"awwPjD_vHEWEhAwFj6Vw8A": {
getter: function (varBag, idService) {
return varBag.vars.value.redirectURLInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"NUfSQGtSl0OiKYUKfgKdTA": {
getter: function (varBag, idService) {
return varBag.registerListenersJSResult.value;
}
},
"2KGSrtiO+E2PxPHV2kWq8w": {
getter: function (varBag, idService) {
return varBag.vars.value.completedInLocal;
},
dataType: OS.DataTypes.DataTypes.Integer
},
"u37Hh1TKSkO8lpu3QQXY3A": {
getter: function (varBag, idService) {
return varBag.vars.value.totalInLocal;
},
dataType: OS.DataTypes.DataTypes.Integer
},
"gDB97ebmE0CLRsJWFK4WEQ": {
getter: function (varBag, idService) {
return varBag.model.variables.timeoutVar;
},
dataType: OS.DataTypes.DataTypes.Integer
},
"vZ4K7sferEqIIb53c8fT8w": {
getter: function (varBag, idService) {
return varBag.model.variables.minimumDisplayTimeMsIn;
},
dataType: OS.DataTypes.DataTypes.Integer
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
