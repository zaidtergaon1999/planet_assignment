define("ShopperPortalEU.clientVariables", ["OutSystems/ClientRuntime/Main"], function (OutSystems) {
var OS = OutSystems.Internal;
var ClientVariables = (function (_super) {
var clientVarsService;
function ClientVariables() {
clientVarsService = OS.Injector.resolve(OS.ServiceNames.ClientVariablesService);
}
ClientVariables.prototype.getShopperGuid = function () {
return clientVarsService.getVariable("ShopperGuid", "ShopperPortalEU", OS.DataTypes.DataTypes.Text);
};
ClientVariables.prototype.setShopperGuid = function (value) {
return clientVarsService.setVariable("ShopperGuid", "ShopperPortalEU", OS.DataTypes.DataTypes.Text, value);
};
ClientVariables.prototype.getFormNumberVA2 = function () {
return clientVarsService.getVariable("FormNumberVA2", "ShopperPortalEU", OS.DataTypes.DataTypes.Text);
};
ClientVariables.prototype.setFormNumberVA2 = function (value) {
return clientVarsService.setVariable("FormNumberVA2", "ShopperPortalEU", OS.DataTypes.DataTypes.Text, value);
};
ClientVariables.prototype.getShopperChecked = function () {
return clientVarsService.getVariable("ShopperChecked", "ShopperPortalEU", OS.DataTypes.DataTypes.Boolean, false);
};
ClientVariables.prototype.setShopperChecked = function (value) {
return clientVarsService.setVariable("ShopperChecked", "ShopperPortalEU", OS.DataTypes.DataTypes.Boolean, value);
};
ClientVariables.prototype.getIsFormRequestRefundTriggered = function () {
return clientVarsService.getVariable("IsFormRequestRefundTriggered", "ShopperPortalEU", OS.DataTypes.DataTypes.Boolean, false);
};
ClientVariables.prototype.setIsFormRequestRefundTriggered = function (value) {
return clientVarsService.setVariable("IsFormRequestRefundTriggered", "ShopperPortalEU", OS.DataTypes.DataTypes.Boolean, value);
};
ClientVariables.prototype.getAnonymousFormList = function () {
return clientVarsService.getVariable("AnonymousFormList", "ShopperPortalEU", OS.DataTypes.DataTypes.Text);
};
ClientVariables.prototype.setAnonymousFormList = function (value) {
return clientVarsService.setVariable("AnonymousFormList", "ShopperPortalEU", OS.DataTypes.DataTypes.Text, value);
};
ClientVariables.prototype.getEmail = function () {
return clientVarsService.getVariable("Email", "ShopperPortalEU", OS.DataTypes.DataTypes.Text);
};
ClientVariables.prototype.setEmail = function (value) {
return clientVarsService.setVariable("Email", "ShopperPortalEU", OS.DataTypes.DataTypes.Text, value);
};
ClientVariables.prototype.getResendCodeSeconds = function () {
return clientVarsService.getVariable("ResendCodeSeconds", "ShopperPortalEU", OS.DataTypes.DataTypes.Integer, -1);
};
ClientVariables.prototype.setResendCodeSeconds = function (value) {
return clientVarsService.setVariable("ResendCodeSeconds", "ShopperPortalEU", OS.DataTypes.DataTypes.Integer, value);
};
ClientVariables.prototype.getRefundSummaryFormListJSON = function () {
return clientVarsService.getVariable("RefundSummaryFormListJSON", "ShopperPortalEU", OS.DataTypes.DataTypes.Text);
};
ClientVariables.prototype.setRefundSummaryFormListJSON = function (value) {
return clientVarsService.setVariable("RefundSummaryFormListJSON", "ShopperPortalEU", OS.DataTypes.DataTypes.Text, value);
};
ClientVariables.prototype.getFromCarouselAddCard = function () {
return clientVarsService.getVariable("FromCarouselAddCard", "ShopperPortalEU", OS.DataTypes.DataTypes.Boolean, true);
};
ClientVariables.prototype.setFromCarouselAddCard = function (value) {
return clientVarsService.setVariable("FromCarouselAddCard", "ShopperPortalEU", OS.DataTypes.DataTypes.Boolean, value);
};
ClientVariables.prototype.getShopperCards = function () {
return clientVarsService.getVariable("ShopperCards", "ShopperPortalEU", OS.DataTypes.DataTypes.Integer);
};
ClientVariables.prototype.setShopperCards = function (value) {
return clientVarsService.setVariable("ShopperCards", "ShopperPortalEU", OS.DataTypes.DataTypes.Integer, value);
};
ClientVariables.prototype.getShopperName = function () {
return clientVarsService.getVariable("ShopperName", "ShopperPortalEU", OS.DataTypes.DataTypes.Text);
};
ClientVariables.prototype.setShopperName = function (value) {
return clientVarsService.setVariable("ShopperName", "ShopperPortalEU", OS.DataTypes.DataTypes.Text, value);
};
ClientVariables.prototype.getErrorMessage = function () {
return clientVarsService.getVariable("ErrorMessage", "ShopperPortalEU", OS.DataTypes.DataTypes.Text, "Sorry, this page is not available");
};
ClientVariables.prototype.setErrorMessage = function (value) {
return clientVarsService.setVariable("ErrorMessage", "ShopperPortalEU", OS.DataTypes.DataTypes.Text, value);
};
ClientVariables.prototype.getFormInfoListJSON = function () {
return clientVarsService.getVariable("FormInfoListJSON", "ShopperPortalEU", OS.DataTypes.DataTypes.Text);
};
ClientVariables.prototype.setFormInfoListJSON = function (value) {
return clientVarsService.setVariable("FormInfoListJSON", "ShopperPortalEU", OS.DataTypes.DataTypes.Text, value);
};
ClientVariables.prototype.getIsInMaintenance = function () {
return clientVarsService.getVariable("IsInMaintenance", "ShopperPortalEU", OS.DataTypes.DataTypes.Boolean, false);
};
ClientVariables.prototype.setIsInMaintenance = function (value) {
return clientVarsService.setVariable("IsInMaintenance", "ShopperPortalEU", OS.DataTypes.DataTypes.Boolean, value);
};
ClientVariables.prototype.getShopperPassports = function () {
return clientVarsService.getVariable("ShopperPassports", "ShopperPortalEU", OS.DataTypes.DataTypes.Integer);
};
ClientVariables.prototype.setShopperPassports = function (value) {
return clientVarsService.setVariable("ShopperPassports", "ShopperPortalEU", OS.DataTypes.DataTypes.Integer, value);
};
ClientVariables.prototype.getScanPassportRedirect = function () {
return clientVarsService.getVariable("ScanPassportRedirect", "ShopperPortalEU", OS.DataTypes.DataTypes.Integer, 0);
};
ClientVariables.prototype.setScanPassportRedirect = function (value) {
return clientVarsService.setVariable("ScanPassportRedirect", "ShopperPortalEU", OS.DataTypes.DataTypes.Integer, value);
};
ClientVariables.prototype.getShopperProfileCompleted = function () {
return clientVarsService.getVariable("ShopperProfileCompleted", "ShopperPortalEU", OS.DataTypes.DataTypes.Decimal);
};
ClientVariables.prototype.setShopperProfileCompleted = function (value) {
return clientVarsService.setVariable("ShopperProfileCompleted", "ShopperPortalEU", OS.DataTypes.DataTypes.Decimal, value);
};
ClientVariables.prototype.getFormNumberRA1 = function () {
return clientVarsService.getVariable("FormNumberRA1", "ShopperPortalEU", OS.DataTypes.DataTypes.Text);
};
ClientVariables.prototype.setFormNumberRA1 = function (value) {
return clientVarsService.setVariable("FormNumberRA1", "ShopperPortalEU", OS.DataTypes.DataTypes.Text, value);
};
ClientVariables.prototype.getLoginType = function () {
return clientVarsService.getVariable("LoginType", "ShopperPortalEU", OS.DataTypes.DataTypes.Integer);
};
ClientVariables.prototype.setLoginType = function (value) {
return clientVarsService.setVariable("LoginType", "ShopperPortalEU", OS.DataTypes.DataTypes.Integer, value);
};
ClientVariables.prototype.getFormNumberVA1 = function () {
return clientVarsService.getVariable("FormNumberVA1", "ShopperPortalEU", OS.DataTypes.DataTypes.Text);
};
ClientVariables.prototype.setFormNumberVA1 = function (value) {
return clientVarsService.setVariable("FormNumberVA1", "ShopperPortalEU", OS.DataTypes.DataTypes.Text, value);
};
ClientVariables.prototype.getIsFromFormDetailsOrStepScreen = function () {
return clientVarsService.getVariable("IsFromFormDetailsOrStepScreen", "ShopperPortalEU", OS.DataTypes.DataTypes.Boolean);
};
ClientVariables.prototype.setIsFromFormDetailsOrStepScreen = function (value) {
return clientVarsService.setVariable("IsFromFormDetailsOrStepScreen", "ShopperPortalEU", OS.DataTypes.DataTypes.Boolean, value);
};
ClientVariables.prototype.getIsProfileDetailsNavigation = function () {
return clientVarsService.getVariable("IsProfileDetailsNavigation", "ShopperPortalEU", OS.DataTypes.DataTypes.Boolean, false);
};
ClientVariables.prototype.setIsProfileDetailsNavigation = function (value) {
return clientVarsService.setVariable("IsProfileDetailsNavigation", "ShopperPortalEU", OS.DataTypes.DataTypes.Boolean, value);
};
ClientVariables.prototype.getShopperPassportDataTemp = function () {
return clientVarsService.getVariable("ShopperPassportDataTemp", "ShopperPortalEU", OS.DataTypes.DataTypes.Text);
};
ClientVariables.prototype.setShopperPassportDataTemp = function (value) {
return clientVarsService.setVariable("ShopperPassportDataTemp", "ShopperPortalEU", OS.DataTypes.DataTypes.Text, value);
};
ClientVariables.prototype.getShopperContact = function () {
return clientVarsService.getVariable("ShopperContact", "ShopperPortalEU", OS.DataTypes.DataTypes.Text);
};
ClientVariables.prototype.setShopperContact = function (value) {
return clientVarsService.setVariable("ShopperContact", "ShopperPortalEU", OS.DataTypes.DataTypes.Text, value);
};
ClientVariables.prototype.getLoginURL = function () {
return clientVarsService.getVariable("LoginURL", "ShopperPortalEU", OS.DataTypes.DataTypes.Text);
};
ClientVariables.prototype.setLoginURL = function (value) {
return clientVarsService.setVariable("LoginURL", "ShopperPortalEU", OS.DataTypes.DataTypes.Text, value);
};
ClientVariables.prototype.serialize = function () {
return {
ShopperGuid: OS.DataConversion.ServerDataConverter.to(this.getShopperGuid(), OS.DataTypes.DataTypes.Text),
FormNumberVA2: OS.DataConversion.ServerDataConverter.to(this.getFormNumberVA2(), OS.DataTypes.DataTypes.Text),
ShopperChecked: OS.DataConversion.ServerDataConverter.to(this.getShopperChecked(), OS.DataTypes.DataTypes.Boolean),
IsFormRequestRefundTriggered: OS.DataConversion.ServerDataConverter.to(this.getIsFormRequestRefundTriggered(), OS.DataTypes.DataTypes.Boolean),
AnonymousFormList: OS.DataConversion.ServerDataConverter.to(this.getAnonymousFormList(), OS.DataTypes.DataTypes.Text),
Email: OS.DataConversion.ServerDataConverter.to(this.getEmail(), OS.DataTypes.DataTypes.Text),
ResendCodeSeconds: OS.DataConversion.ServerDataConverter.to(this.getResendCodeSeconds(), OS.DataTypes.DataTypes.Integer),
RefundSummaryFormListJSON: OS.DataConversion.ServerDataConverter.to(this.getRefundSummaryFormListJSON(), OS.DataTypes.DataTypes.Text),
FromCarouselAddCard: OS.DataConversion.ServerDataConverter.to(this.getFromCarouselAddCard(), OS.DataTypes.DataTypes.Boolean),
ShopperCards: OS.DataConversion.ServerDataConverter.to(this.getShopperCards(), OS.DataTypes.DataTypes.Integer),
ShopperName: OS.DataConversion.ServerDataConverter.to(this.getShopperName(), OS.DataTypes.DataTypes.Text),
ErrorMessage: OS.DataConversion.ServerDataConverter.to(this.getErrorMessage(), OS.DataTypes.DataTypes.Text),
FormInfoListJSON: OS.DataConversion.ServerDataConverter.to(this.getFormInfoListJSON(), OS.DataTypes.DataTypes.Text),
IsInMaintenance: OS.DataConversion.ServerDataConverter.to(this.getIsInMaintenance(), OS.DataTypes.DataTypes.Boolean),
ShopperPassports: OS.DataConversion.ServerDataConverter.to(this.getShopperPassports(), OS.DataTypes.DataTypes.Integer),
ScanPassportRedirect: OS.DataConversion.ServerDataConverter.to(this.getScanPassportRedirect(), OS.DataTypes.DataTypes.Integer),
ShopperProfileCompleted: OS.DataConversion.ServerDataConverter.to(this.getShopperProfileCompleted(), OS.DataTypes.DataTypes.Decimal),
FormNumberRA1: OS.DataConversion.ServerDataConverter.to(this.getFormNumberRA1(), OS.DataTypes.DataTypes.Text),
LoginType: OS.DataConversion.ServerDataConverter.to(this.getLoginType(), OS.DataTypes.DataTypes.Integer),
FormNumberVA1: OS.DataConversion.ServerDataConverter.to(this.getFormNumberVA1(), OS.DataTypes.DataTypes.Text),
IsFromFormDetailsOrStepScreen: OS.DataConversion.ServerDataConverter.to(this.getIsFromFormDetailsOrStepScreen(), OS.DataTypes.DataTypes.Boolean),
IsProfileDetailsNavigation: OS.DataConversion.ServerDataConverter.to(this.getIsProfileDetailsNavigation(), OS.DataTypes.DataTypes.Boolean),
ShopperPassportDataTemp: OS.DataConversion.ServerDataConverter.to(this.getShopperPassportDataTemp(), OS.DataTypes.DataTypes.Text),
ShopperContact: OS.DataConversion.ServerDataConverter.to(this.getShopperContact(), OS.DataTypes.DataTypes.Text),
LoginURL: OS.DataConversion.ServerDataConverter.to(this.getLoginURL(), OS.DataTypes.DataTypes.Text)
};
};
return ClientVariables;
})();
return new ClientVariables();
});
