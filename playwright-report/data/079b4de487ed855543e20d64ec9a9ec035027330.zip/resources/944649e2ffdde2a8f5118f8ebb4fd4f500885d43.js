define("ShopperPortalEU.LayoutsComponents.ApplicationHeader.mvc$model", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.ShopperPortalEUUIThemeLayoutsComponents.ApplicationHeader.mvc$model", "ShopperPortalEU.model$ApplicationHeaderRec", "ShopperPortalEU_UI_Theme.model$ApplicationHeaderOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_Theme_ShopperPortalEUUIThemeLayoutsComponents_ApplicationHeader_mvcModel) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("Options", "optionsIn", "Options", true, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEUModel.ApplicationHeaderRec());
}, false, ShopperPortalEUModel.ApplicationHeaderRec), 
this.attr("_optionsInDataFetchStatus", "_optionsInDataFetchStatus", "_optionsInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Model._hasValidationWidgetsValue = undefined;
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
if((Model._hasValidationWidgetsValue === undefined)) {
Model._hasValidationWidgetsValue = ShopperPortalEU_UI_Theme_ShopperPortalEUUIThemeLayoutsComponents_ApplicationHeader_mvcModel.hasValidationWidgets;
}

return Model._hasValidationWidgetsValue;
}
});

Model.prototype.setInputs = function (inputs) {
if("Options" in inputs) {
this.variables.optionsIn = inputs.Options;
if("_optionsInDataFetchStatus" in inputs) {
this.variables._optionsInDataFetchStatus = inputs._optionsInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "LayoutsComponents.ApplicationHeader");
});
define("ShopperPortalEU.LayoutsComponents.ApplicationHeader.mvc$view", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Theme.model", "react", "OutSystems/ReactView/Main", "ShopperPortalEU.LayoutsComponents.ApplicationHeader.mvc$model", "ShopperPortalEU.LayoutsComponents.ApplicationHeader.mvc$controller", "ShopperPortalEU.clientVariables", "ShopperPortalEU_UI_Theme.ShopperPortalEUUIThemeLayoutsComponents.ApplicationHeader.mvc$view", "OutSystems/ReactWidgets/Main", "ShopperPortalEU.model$ApplicationHeaderRec", "ShopperPortalEU_UI_Theme.model$ApplicationHeaderOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_UI_ThemeModel, React, OSView, ShopperPortalEU_LayoutsComponents_ApplicationHeader_mvc_model, ShopperPortalEU_LayoutsComponents_ApplicationHeader_mvc_controller, ShopperPortalEUClientVariables, ShopperPortalEU_UI_Theme_ShopperPortalEUUIThemeLayoutsComponents_ApplicationHeader_mvc_view, OSWidgets) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            var thisIsInstanceOfSuper = this instanceof _super;
            if (thisIsInstanceOfSuper == false) {
                return;
            }

            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "LayoutsComponents.ApplicationHeader";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [ShopperPortalEU_UI_Theme_ShopperPortalEUUIThemeLayoutsComponents_ApplicationHeader_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return ShopperPortalEU_LayoutsComponents_ApplicationHeader_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return ShopperPortalEU_LayoutsComponents_ApplicationHeader_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(ShopperPortalEU_UI_Theme_ShopperPortalEUUIThemeLayoutsComponents_ApplicationHeader_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("2kHWlthVpUuLA9IjxpFinA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ThemeModel.ApplicationHeaderOptionsRec();
rec.showLogoOnScrollAttr = (model.variables.optionsIn.scrollTitleAttr === "");
return rec;
}();
}, function () {
return model.variables.optionsIn.scrollTitleAttr;
}),
_optionsInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._optionsInDataFetchStatus)
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onClick$Action: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ShopperPortalEUUIThemeLayoutsComponents/ApplicationHeader OnClick");
controller.onClick$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "0",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
logo: new PlaceholderContent(function () {
return [$if(!(model.variables.optionsIn.isLargerLogoAttr), false, this, function () {
return [React.createElement(OSWidgets.Image, {
image: OS.Navigation.VersionedURL.getVersionedUrl("img/ShopperPortalEU_UI_Resources.planet_logo_white.svg"),
type: /*Static*/ 0,
_idProps: {
service: idService,
uuid: "1"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}, function () {
return [React.createElement(OSWidgets.Image, {
image: OS.Navigation.VersionedURL.getVersionedUrl("img/ShopperPortalEU_UI_Resources.shopperportal_logo_full.svg"),
type: /*Static*/ 0,
_idProps: {
service: idService,
uuid: "2"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})];
}),
title: new PlaceholderContent(function () {
return [$if(!(model.variables.optionsIn.isLargerLogoAttr), false, this, function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "ShopperPortalTitle"
},
value: "Shopper Portal",
_idProps: {
service: idService,
uuid: "3"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}, function () {
return [];
})];
}),
scrollContent: new PlaceholderContent(function () {
return [$if(((model.variables.optionsIn.scrollTitleAttr) !== ("")), false, this, function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "ScreenScrolledTitle"
},
value: model.variables.optionsIn.scrollTitleAttr,
_idProps: {
service: idService,
uuid: "4"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._optionsInDataFetchStatus)
})];
}, function () {
return [];
})];
})
},
_dependencies: [asPrimitiveValue(model.variables._optionsInDataFetchStatus), asPrimitiveValue(model.variables.optionsIn.scrollTitleAttr), asPrimitiveValue(model.variables.optionsIn.isLargerLogoAttr)]
}));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("ShopperPortalEU.LayoutsComponents.ApplicationHeader.mvc$controller", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU.languageResources", "ShopperPortalEU.clientVariables", "ShopperPortalEU.LayoutsComponents.ApplicationHeader.mvc$debugger", "ShopperPortalEU.model$ApplicationHeaderRec", "ShopperPortalEU_UI_Theme.model$ApplicationHeaderOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_UI_ThemeModel, ShopperPortalEULanguageResources, ShopperPortalEUClientVariables, ShopperPortalEU_LayoutsComponents_ApplicationHeader_mvc_Debugger) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = true;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._onClick$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnClick");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:DdFFKGldh0Gt+3mdvMlXrQ:/NRWebFlows.L_YboVe7KUC5K0uH_jh6qw/NodesShownInESpaceTree.0YhgsAJXVUyE4w2PhcKhFA/ClientActions.DdFFKGldh0Gt+3mdvMlXrQ:r5NA_HwLZ41owYQsmkR7Yw", "ShopperPortalEU", "OnClick", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:T_jhkgj5qEmo_1syTI4NXQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:i2fFp0aN8kK+XTRtc3FN1A", callContext.id);
// Destination: /ShopperPortalEU/
return OS.Navigation.navigateTo(OS.Navigation.generateScreenURL(OS.BuiltinFunctions.getOwnerURLPath(), {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:DdFFKGldh0Gt+3mdvMlXrQ", callContext.id);
}

};

Controller.prototype.onClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onClick$Action, callContext);

};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:L_YboVe7KUC5K0uH_jh6qw:/NRWebFlows.L_YboVe7KUC5K0uH_jh6qw:7M96ALC1q_CnwlpVX8Rm0w", "ShopperPortalEU", "LayoutsComponents", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:0YhgsAJXVUyE4w2PhcKhFA:/NRWebFlows.L_YboVe7KUC5K0uH_jh6qw/NodesShownInESpaceTree.0YhgsAJXVUyE4w2PhcKhFA:51LSo5c8m3yhhxQs97BUNQ", "ShopperPortalEU", "ApplicationHeader", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:0YhgsAJXVUyE4w2PhcKhFA", callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:L_YboVe7KUC5K0uH_jh6qw", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return ShopperPortalEUController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, ShopperPortalEULanguageResources);
});

define("ShopperPortalEU.LayoutsComponents.ApplicationHeader.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"0nwI0MPdR0emUll4RVin4g": {
getter: function (varBag, idService) {
return varBag.model.variables.optionsIn;
}
},
"vHqJJdz+vkCdphRUQv0xPQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Logo"));
})(varBag.model, idService);
}
},
"nbt+Bo5Nx0yZepEKPNVMfg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"1BeVh15ldk2xXzYL8yHFBw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("ScrollContent"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
