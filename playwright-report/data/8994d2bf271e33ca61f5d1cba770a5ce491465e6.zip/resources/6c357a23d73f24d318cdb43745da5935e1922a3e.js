define("ShopperPortalEU.Refund.TaxFreeFormDetails.mvc$model", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.controller", "ShopperPortalEU.controller", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.controller", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.controller", "ShopperPortalEU_UI_Components.model$DatePickerValidationOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$CustomDropdownListValidationOptionsRec", "ShopperPortalEU_UI_Components.model$CustomDropdownListValueOptionsRec", "ShopperPortalEU.model$CustomDropdownListValueOptionsList", "ShopperPortalEU_UI_Theme.model$LayoutDetailOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU_UI_Components.model$CustomFormOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentTopOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentBottomOptionsRec", "ShopperPortalEU_UI_Components.model$CustomInputOptionsRec", "ShopperPortalEU_UI_Components.model$CustomInputIconOptionRec", "ShopperPortalEU_UI_Components.model$CustomInputValidationOptionsRec", "ShopperPortalEU_UI_Components.model$CustomValidationMessageOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsIconRec", "ShopperPortalEU_UI_Components.model$DatePickerOptionsRec", "ShopperPortalEU_UI_Components.model$DatePickerLabelOptionsRec", "ShopperPortalEU_UI_Components.model$CustomDropdownListOptionsRec", "ShopperPortalEU_UI_Components.model$CustomDropdownListSearchOptionsRec", "ShopperPortalEU_UI_Components.model$CustomDropdownListSelectedItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomFlagOptionsRec", "ShopperPortalEU_UI_Components.model$CustomDropdownListItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconRec", "ShopperPortalEU_UI_Components.model$BottomDrawerRec", "ShopperPortalEU_UI_Components.model$FlexOptionsRec", "ShopperPortalEU_UI_Components.model$CustomImageOptionsRec", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", "ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger", "ShopperPortalEU.model$PassportList", "ShopperPortalEU.controller$GetPassports", "ShopperPortalEU.controller$DefaultErrorMessage", "ShopperPortalEU.model$AnonymousFormsList", "ShopperPortalEU.controller$GetAnonymousFormsList", "ShopperPortalEU_UI_Components.model$CustomDropdownCustomValueOptionRec", "ShopperPortalEU.controller$ClarityEvent", "ShopperPortalEU.controller$ReplaceAllNonLettersOrNumbers", "ShopperPortalEU_Shopper_IS.model$GetCardsResponseRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS", "ShopperPortalEU.model$GetCardsResponseList", "ShopperPortalEU_Shopper_IS.controller$GetCards", "ShopperPortalEU_Forms_IS.model$AnonymousFormAddRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Forms_IS", "ShopperPortalEU_Forms_IS.controller$LinkAnonymousForm", "ShopperPortalEU.controller$AddAnonymousFormToString", "ShopperPortalEU_Forms_IS.model$FormInfo_WrapperRec", "ShopperPortalEU.model$FormInfo_WrapperList"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ThemeController, ShopperPortalEUController, ShopperPortalEU_Shopper_ISModel, ShopperPortalEU_Shopper_ISController, ShopperPortalEU_Forms_ISModel, ShopperPortalEU_Forms_ISController) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("PurchaseDate", "purchaseDateVar", "PurchaseDate", true, false, OS.DataTypes.DataTypes.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, false), 
this.attr("DateOfPurchaseValidation", "dateOfPurchaseValidationVar", "DateOfPurchaseValidation", true, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.DatePickerValidationOptionsRec());
}, false, ShopperPortalEU_UI_ComponentsModel.DatePickerValidationOptionsRec), 
this.attr("DropdownListValidation", "dropdownListValidationVar", "DropdownListValidation", true, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValidationOptionsRec());
}, false, ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValidationOptionsRec), 
this.attr("IsToOpenDrawer", "isToOpenDrawerVar", "IsToOpenDrawer", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("HasDefaultCard", "hasDefaultCardVar", "HasDefaultCard", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("CC4digits", "cC4digitsVar", "CC4digits", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, false), 
this.attr("IsFormDisqualified", "isFormDisqualifiedVar", "IsFormDisqualified", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("NumberOfAttemps", "numberOfAttempsVar", "NumberOfAttemps", true, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, false), 
this.attr("IsToShowCustomSupportLink", "isToShowCustomSupportLinkVar", "IsToShowCustomSupportLink", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("IsToEnableAddBtn", "isToEnableAddBtnVar", "IsToEnableAddBtn", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return true;
}, false), 
this.attr("IsAdding", "isAddingVar", "IsAdding", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("TFFWithWrongDate", "tFFWithWrongDateVar", "TFFWithWrongDate", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, false), 
this.attr("Passports", "passportsVar", "Passports", true, false, OS.DataTypes.DataTypes.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEUModel.CustomDropdownListValueOptionsList());
}, false, ShopperPortalEUModel.CustomDropdownListValueOptionsList), 
this.attr("PassportSelected", "passportSelectedVar", "PassportSelected", true, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValueOptionsRec());
}, false, ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValueOptionsRec), 
this.attr("IsDataFetched", "isDataFetchedVar", "IsDataFetched", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("IsToShowCustom5007ErrorCodeMessage", "isToShowCustom5007ErrorCodeMessageVar", "IsToShowCustom5007ErrorCodeMessage", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("TaxFreeFormNumber", "taxFreeFormNumberIn", "TaxFreeFormNumber", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, false), 
this.attr("_taxFreeFormNumberInDataFetchStatus", "_taxFreeFormNumberInDataFetchStatus", "_taxFreeFormNumberInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {
TaxFreeForm: OS.Model.ValidationWidgetRecord,
TFF_Number: OS.Model.ValidationWidgetRecord
};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return true;
}
});

Model.prototype.setInputs = function (inputs) {
if("TaxFreeFormNumber" in inputs) {
this.variables.taxFreeFormNumberIn = OS.DataConversion.ServerDataConverter.from(inputs.TaxFreeFormNumber, OS.DataTypes.DataTypes.Text);
}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "Refund.TaxFreeFormDetails");
});
define("ShopperPortalEU.Refund.TaxFreeFormDetails.mvc$view", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.controller", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.controller", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.controller", "react", "OutSystems/ReactView/Main", "ShopperPortalEU.Refund.TaxFreeFormDetails.mvc$model", "ShopperPortalEU.Refund.TaxFreeFormDetails.mvc$controller", "ShopperPortalEU.clientVariables", "ShopperPortalEU.Layouts.LayoutDetail.mvc$view", "OutSystems/ReactWidgets/Main", "ShopperPortalEU.Common.DataLoading.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomForm.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.FullHeightContent.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomInput.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomValidationMessage.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomLink.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomLinkItem.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.DatePicker.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomDropdownList.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomDropdownListSelectedItem.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomFlag.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomDropdownListItem.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomButton.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomButtonItem.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.BottomDrawer.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.Flex.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomImage.mvc$view", "ShopperPortalEU_UI_Components.model$DatePickerValidationOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$CustomDropdownListValidationOptionsRec", "ShopperPortalEU_UI_Components.model$CustomDropdownListValueOptionsRec", "ShopperPortalEU.model$CustomDropdownListValueOptionsList", "ShopperPortalEU_UI_Theme.model$LayoutDetailOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU_UI_Components.model$CustomFormOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentTopOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentBottomOptionsRec", "ShopperPortalEU_UI_Components.model$CustomInputOptionsRec", "ShopperPortalEU_UI_Components.model$CustomInputIconOptionRec", "ShopperPortalEU_UI_Components.model$CustomInputValidationOptionsRec", "ShopperPortalEU_UI_Components.model$CustomValidationMessageOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsIconRec", "ShopperPortalEU_UI_Components.model$DatePickerOptionsRec", "ShopperPortalEU_UI_Components.model$DatePickerLabelOptionsRec", "ShopperPortalEU_UI_Components.model$CustomDropdownListOptionsRec", "ShopperPortalEU_UI_Components.model$CustomDropdownListSearchOptionsRec", "ShopperPortalEU_UI_Components.model$CustomDropdownListSelectedItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomFlagOptionsRec", "ShopperPortalEU_UI_Components.model$CustomDropdownListItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconRec", "ShopperPortalEU_UI_Components.model$BottomDrawerRec", "ShopperPortalEU_UI_Components.model$FlexOptionsRec", "ShopperPortalEU_UI_Components.model$CustomImageOptionsRec", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", "ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger", "ShopperPortalEU.model$PassportList", "ShopperPortalEU.controller$GetPassports", "ShopperPortalEU.controller$DefaultErrorMessage", "ShopperPortalEU.model$AnonymousFormsList", "ShopperPortalEU.controller$GetAnonymousFormsList", "ShopperPortalEU_UI_Components.model$CustomDropdownCustomValueOptionRec", "ShopperPortalEU.controller$ClarityEvent", "ShopperPortalEU.controller$ReplaceAllNonLettersOrNumbers", "ShopperPortalEU_Shopper_IS.model$GetCardsResponseRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS", "ShopperPortalEU.model$GetCardsResponseList", "ShopperPortalEU_Shopper_IS.controller$GetCards", "ShopperPortalEU_Forms_IS.model$AnonymousFormAddRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Forms_IS", "ShopperPortalEU_Forms_IS.controller$LinkAnonymousForm", "ShopperPortalEU.controller$AddAnonymousFormToString", "ShopperPortalEU_Forms_IS.model$FormInfo_WrapperRec", "ShopperPortalEU.model$FormInfo_WrapperList"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ThemeController, ShopperPortalEU_Shopper_ISModel, ShopperPortalEU_Shopper_ISController, ShopperPortalEU_Forms_ISModel, ShopperPortalEU_Forms_ISController, React, OSView, ShopperPortalEU_Refund_TaxFreeFormDetails_mvc_model, ShopperPortalEU_Refund_TaxFreeFormDetails_mvc_controller, ShopperPortalEUClientVariables, ShopperPortalEU_Layouts_LayoutDetail_mvc_view, OSWidgets, ShopperPortalEU_Common_DataLoading_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomForm_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomInput_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomValidationMessage_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLink_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLinkItem_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_DatePicker_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomDropdownList_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomDropdownListSelectedItem_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomFlag_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomDropdownListItem_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_BottomDrawer_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomImage_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            var thisIsInstanceOfSuper = this instanceof _super;
            if (thisIsInstanceOfSuper == false) {
                return;
            }

            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "Refund.TaxFreeFormDetails";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css", "css/ShopperPortalEU_UI_Theme.ShopperPortalEUUITheme.css", "css/ShopperPortalEU.ShopperPortalEU.css", "css/ShopperPortalEU_UI_Theme.ShopperPortalEUUITheme.extra.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [ShopperPortalEU_Layouts_LayoutDetail_mvc_view, ShopperPortalEU_Common_DataLoading_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomForm_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomInput_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomValidationMessage_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLink_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLinkItem_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_DatePicker_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomDropdownList_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomDropdownListSelectedItem_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomFlag_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomDropdownListItem_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_BottomDrawer_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomImage_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return ShopperPortalEU_Refund_TaxFreeFormDetails_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return ShopperPortalEU_Refund_TaxFreeFormDetails_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "Shopper Portal EU - Tax Free form details";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(ShopperPortalEU_Layouts_LayoutDetail_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
afterAuthentication$Action: function (isAuthenticatedIn) {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Layouts/LayoutDetail AfterAuthentication");
return controller.onAfterAuthentication$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "0",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
headerLeft: PlaceholderContent.Empty,
headerCenter: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "Tax Free form details title"
},
value: "Tax Free form details",
_idProps: {
service: idService,
uuid: "1"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
headerRight: PlaceholderContent.Empty,
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_Common_DataLoading_mvc_view, {
inputs: {
IsDataFetched: model.variables.isDataFetchedVar
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "2",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomForm_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("m8dGOIDK0Uqnc+hJxPsW9w.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomFormOptionsRec();
rec.isFullHeightAttr = true;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "3",
alias: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
form: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Form, {
_validationProps: {
validationService: validationService
},
gridProperties: {
classes: "OSFillParent"
},
style: "form",
_idProps: {
service: idService,
name: "TaxFreeForm"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("TaxFreeForm")
},
_idProps: {
service: idService,
uuid: "5",
alias: "4"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
top: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomInput_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("LsXYLqnE8k61pASBxHRPSA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomInputOptionsRec();
rec.testIdAttr = "TaxFreeFormNumber";
rec.iconAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomInputIconOptionRec();
rec.nameAttr = "info";
rec.isClickableAttr = true;
return rec;
}();
rec.iconSecondaryAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomInputIconOptionRec();
rec.nameAttr = "photo_camera";
rec.isClickableAttr = true;
return rec;
}();
rec.validationAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomInputValidationOptionsRec();
return rec;
}();
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onIconClick$Action: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ShopperPortalEUUIComponents/CustomInput OnIconClick");
controller.tFF_NumberInputOnIconClick$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
onSecondaryIconClick$Action: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ShopperPortalEUUIComponents/CustomInput OnSecondaryIconClick");
controller.tFF_NumberInputOnCameraClick$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("TaxFreeForm")
},
_idProps: {
service: idService,
uuid: "6",
alias: "5"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
label: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
mandatory: true,
targetWidget: "TFF_Number",
_idProps: {
service: idService,
uuid: "7"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "Tax Free form number_Label"
},
value: "Tax Free form number",
_idProps: {
service: idService,
uuid: "8"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
}),
input: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Input, {
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("TaxFreeForm")
},
enabled: true,
extendedEvents: {
onBlur: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Refund/TaxFreeFormDetails/TFF_Number onblur");
controller.tFF_NumberOnBlur$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
gridProperties: {
classes: "OSFillParent"
},
inputType: /*Text*/ 0,
mandatory: true,
maxLength: 0,
onChange: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Refund/TaxFreeFormDetails/TFF_Number OnChange");
controller.tFF_NumberOnChange$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "form-control",
variable: model.createVariable(OS.DataTypes.DataTypes.Text, model.variables.taxFreeFormNumberIn, function (value) {
model.variables.taxFreeFormNumberIn = value;
}),
_idProps: {
service: idService,
name: "TFF_Number"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
description: PlaceholderContent.Empty
},
_dependencies: [asPrimitiveValue(model.variables.taxFreeFormNumberIn)]
}), $if(model.variables.isToShowCustom5007ErrorCodeMessageVar, false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomValidationMessage_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("CkwCaJVHtUW8Udovv0M93g.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomValidationMessageOptionsRec();
rec.stateAttr = ShopperPortalEUModel.staticEntities.customValidationMessageState.error;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("TaxFreeForm")
},
_idProps: {
service: idService,
uuid: "10",
alias: "6"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "11"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "DateErrorMessageWithLink507"
},
value: "This form is linked to a passport not saved in your profile. ",
_idProps: {
service: idService,
uuid: "12"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLink_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("QcosEUU440yCFgjH1_T43g.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomLinkOptionsRec();
rec.testIdAttr = "ContactCustomerSupportLink";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("TaxFreeForm")
},
_idProps: {
service: idService,
uuid: "13",
alias: "7"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
link: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Link, {
enabled: true,
transition: OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default),
url: OS.Navigation.generateScreenURL("ShopperPortalEU", "ScanPassport", {}),
visible: true,
_idProps: {
service: idService,
uuid: "14"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLinkItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("TaxFreeForm")
},
_idProps: {
service: idService,
uuid: "15",
alias: "8"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Add passport",
_idProps: {
service: idService,
uuid: "16"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
}), React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "DateErrorMessageWithLink500"
},
value: " to continue.",
_idProps: {
service: idService,
uuid: "17"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
})
},
_dependencies: []
})];
}, function () {
return [];
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_DatePicker_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("zHNvgLxa6UuZxsEVQ9lt5A.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.DatePickerOptionsRec();
rec.testIdAttr = "DateOfPurchase";
rec.dateAttr = model.variables.purchaseDateVar;
rec.isMandatoryAttr = true;
rec.maxDateAttr = OS.BuiltinFunctions.currDate();
rec.validationAttr = model.variables.dateOfPurchaseValidationVar;
return rec;
}();
}, function () {
return model.variables.purchaseDateVar;
}, function () {
return model.variables.dateOfPurchaseValidationVar;
}),
ExtendedClass: "margin-top-04"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onChange$Action: function (currentDateIn) {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ShopperPortalEUUIComponents/DatePicker OnChange");
controller.dateOfPurchaseOnChange$Action(currentDateIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("TaxFreeForm")
},
_idProps: {
service: idService,
uuid: "18",
alias: "9"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
label: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
_idProps: {
service: idService,
uuid: "19"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "Date of purchase_Label"
},
value: "Date of purchase",
_idProps: {
service: idService,
uuid: "20"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
})
},
_dependencies: []
}), $if((model.variables.passportsVar.length > 1), false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomDropdownList_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("PassportDropdown.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomDropdownListOptionsRec();
rec.testIdAttr = "PassportDropdown";
rec.selectedAttr = model.variables.passportSelectedVar.valueAttr;
rec.nullValueAttr = "Select";
rec.labelAttr = "Select passport";
rec.descriptionAttr = "Ensure this is the one you have with you while travelling";
rec.isMandatoryAttr = true;
rec.validationAttr = model.variables.dropdownListValidationVar;
return rec;
}();
}, function () {
return model.variables.passportSelectedVar.valueAttr;
}, function () {
return model.variables.dropdownListValidationVar;
}),
ExtendedClass: "margin-top-04"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onChange$Action: function (currentValueIn) {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ShopperPortalEUUIComponents/CustomDropdownList OnChange");
controller.onChangePassportDropdown$Action(OS.DataConversion.JSConversions.typeConvertRecord(currentValueIn, new ShopperPortalEU_UI_ComponentsModel.CustomDropdownCustomValueOptionRec(), function (source, target) {
target.textAttr = source.textAttr;
target.valueAttr = source.valueAttr;
return target;
}), controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("TaxFreeForm")
},
_idProps: {
service: idService,
name: "PassportDropdown",
alias: "10"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
label: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
_idProps: {
service: idService,
uuid: "22"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
value: "Passport",
_idProps: {
service: idService,
uuid: "23"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
}),
selected: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomDropdownListSelectedItem_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("CustomDropdownListSelectedItem.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomDropdownListSelectedItemOptionsRec();
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("TaxFreeForm")
},
_idProps: {
service: idService,
name: "CustomDropdownListSelectedItem",
alias: "11"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
left: new PlaceholderContent(function () {
return [$if(((model.variables.passportSelectedVar.valueAttr) !== ("")), false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomFlag_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("2Lik580REkSy86ecFQ0mcw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomFlagOptionsRec();
rec.testIdAttr = ("CountryFlag_" + model.variables.passportSelectedVar.valueAttr);
rec.flagAttr = model.variables.passportSelectedVar.valueAttr;
return rec;
}();
}, function () {
return model.variables.passportSelectedVar.valueAttr;
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("TaxFreeForm")
},
_idProps: {
service: idService,
uuid: "25",
alias: "12"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}, function () {
return [];
})];
}),
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": ("passporSelectedt_" + model.variables.passportSelectedVar.textAttr)
},
value: model.getCachedValue(idService.getId("5NYBFDIjo0OkaZa3zULqPg.Value"), function () {
return (((model.variables.passportSelectedVar.textAttr === "")) ? ("Select") : (model.variables.passportSelectedVar.textAttr));
}, function () {
return model.variables.passportSelectedVar.textAttr;
}),
_idProps: {
service: idService,
uuid: "26"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
right: PlaceholderContent.Empty
},
_dependencies: [asPrimitiveValue(model.variables.passportSelectedVar.textAttr), asPrimitiveValue(model.variables.passportSelectedVar.valueAttr)]
})];
}),
list: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.List, {
animateItems: false,
extendedProperties: {
"disable-virtualization": "True"
},
gridProperties: {
classes: "OSFillParent"
},
mode: /*Default*/ 0,
source: model.variables.passportsVar,
style: "list list-group",
tag: "div",
_idProps: {
service: idService,
name: "Lis"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new IteratorPlaceholderContent(function (idService, callContext) {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomDropdownListItem_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("vGVowzoVBUGugF_VZX5eag.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomDropdownListItemOptionsRec();
rec.valueAttr = model.variables.passportsVar.getCurrent(callContext.iterationContext);
return rec;
}();
}, function () {
return model.variables.passportsVar.getCurrent(callContext.iterationContext);
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.ownerService.getId("TaxFreeForm")
},
_idProps: {
service: idService,
uuid: "28",
alias: "13"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
left: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomFlag_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("uIOQEFa_n0yDhZ6wfKGufw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomFlagOptionsRec();
rec.testIdAttr = ("CountryFlag_" + model.variables.passportsVar.getCurrent(callContext.iterationContext).valueAttr);
rec.flagAttr = model.variables.passportsVar.getCurrent(callContext.iterationContext).valueAttr;
return rec;
}();
}, function () {
return model.variables.passportsVar.getCurrent(callContext.iterationContext).valueAttr;
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.ownerService.getId("TaxFreeForm")
},
_idProps: {
service: idService,
uuid: "29",
alias: "14"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}),
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": ("passport_" + (model.variables.passportsVar.getCurrentRowNumber(callContext.iterationContext)).toString())
},
value: model.variables.passportsVar.getCurrent(callContext.iterationContext).textAttr,
_idProps: {
service: idService,
uuid: "30"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
right: PlaceholderContent.Empty,
list: PlaceholderContent.Empty
},
_dependencies: [asPrimitiveValue(model.variables.passportsVar.getCurrentRowNumber(callContext.iterationContext)), asPrimitiveValue(model.variables.passportsVar.getCurrent(callContext.iterationContext).textAttr), asPrimitiveValue(model.variables.passportsVar.getCurrent(callContext.iterationContext).valueAttr)]
})];
}, callContext, idService, "1")
},
_dependencies: []
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.passportsVar), asPrimitiveValue(model.variables.passportSelectedVar.textAttr), asPrimitiveValue(model.variables.passportSelectedVar.valueAttr)]
})];
}, function () {
return [];
}), $if(model.variables.isToShowCustomSupportLinkVar, false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomValidationMessage_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("SrbNkbMgzESRf2KABXI2Qw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomValidationMessageOptionsRec();
rec.stateAttr = ShopperPortalEUModel.staticEntities.customValidationMessageState.error;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("TaxFreeForm")
},
_idProps: {
service: idService,
uuid: "31",
alias: "15"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "32"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "DateErrorMessageWithLink"
},
value: "These details do not match the Tax Free form. No attempts remaining. ",
_idProps: {
service: idService,
uuid: "33"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLink_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("LAEnNjjWdUqbET+oeyIOsA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomLinkOptionsRec();
rec.testIdAttr = "ContactCustomerSupportLink";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("TaxFreeForm")
},
_idProps: {
service: idService,
uuid: "34",
alias: "16"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
link: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Link, {
enabled: true,
transition: OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default),
url: OS.Navigation.generateScreenURL("ShopperPortalEU", "Help", {}),
visible: true,
_idProps: {
service: idService,
uuid: "35"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLinkItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("TaxFreeForm")
},
_idProps: {
service: idService,
uuid: "36",
alias: "17"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Contact Customer Support",
_idProps: {
service: idService,
uuid: "37"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
})];
}, function () {
return [];
})];
}),
bottom: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("esfkOVqgoUSQiXNmvDEpow.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRec();
rec.testIdAttr = "CancelTFFButton";
rec.typeAttr = ShopperPortalEUModel.staticEntities.customButtonType.reverse;
rec.isFullWidthAttr = true;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("TaxFreeForm")
},
_idProps: {
service: idService,
uuid: "38",
alias: "18"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
button: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: false,
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Refund/TaxFreeFormDetails/Button OnClick");
controller.cancel$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn",
visible: true,
_idProps: {
service: idService,
uuid: "39"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("TaxFreeForm")
},
_idProps: {
service: idService,
uuid: "40",
alias: "19"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Cancel",
_idProps: {
service: idService,
uuid: "41"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-top-04",
visible: true,
_idProps: {
service: idService,
uuid: "42"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("TLKElxVyh0CPvnpVW1iYLw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRec();
rec.testIdAttr = "AddTFFButton";
rec.typeAttr = ShopperPortalEUModel.staticEntities.customButtonType.primary;
rec.isLoadingAttr = model.variables.isAddingVar;
rec.isFullWidthAttr = true;
return rec;
}();
}, function () {
return model.variables.isAddingVar;
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("TaxFreeForm")
},
_idProps: {
service: idService,
uuid: "43",
alias: "20"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
button: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: model.variables.isToEnableAddBtnVar,
isDefault: true,
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Refund/TaxFreeFormDetails/Button OnClick");
return controller.addTFF$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
style: "btn",
visible: true,
_idProps: {
service: idService,
uuid: "44"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("TaxFreeForm")
},
_idProps: {
service: idService,
uuid: "45",
alias: "21"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Add ",
_idProps: {
service: idService,
uuid: "46"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables.isToEnableAddBtnVar)]
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables.isToEnableAddBtnVar), asPrimitiveValue(model.variables.isAddingVar), asPrimitiveValue(model.variables.isToShowCustomSupportLinkVar), asPrimitiveValue(model.variables.dropdownListValidationVar), asPrimitiveValue(model.variables.passportSelectedVar.textAttr), asPrimitiveValue(model.variables.passportSelectedVar.valueAttr), asPrimitiveValue(model.variables.passportsVar), asPrimitiveValue(model.variables.dateOfPurchaseValidationVar), asPrimitiveValue(model.variables.purchaseDateVar), asPrimitiveValue(model.variables.isToShowCustom5007ErrorCodeMessageVar), asPrimitiveValue(model.variables.taxFreeFormNumberIn)]
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables.isToEnableAddBtnVar), asPrimitiveValue(model.variables.isAddingVar), asPrimitiveValue(model.variables.isToShowCustomSupportLinkVar), asPrimitiveValue(model.variables.dropdownListValidationVar), asPrimitiveValue(model.variables.passportSelectedVar.textAttr), asPrimitiveValue(model.variables.passportSelectedVar.valueAttr), asPrimitiveValue(model.variables.passportsVar), asPrimitiveValue(model.variables.dateOfPurchaseValidationVar), asPrimitiveValue(model.variables.purchaseDateVar), asPrimitiveValue(model.variables.isToShowCustom5007ErrorCodeMessageVar), asPrimitiveValue(model.variables.taxFreeFormNumberIn)]
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.isToEnableAddBtnVar), asPrimitiveValue(model.variables.isAddingVar), asPrimitiveValue(model.variables.isToShowCustomSupportLinkVar), asPrimitiveValue(model.variables.dropdownListValidationVar), asPrimitiveValue(model.variables.passportSelectedVar.textAttr), asPrimitiveValue(model.variables.passportSelectedVar.valueAttr), asPrimitiveValue(model.variables.passportsVar), asPrimitiveValue(model.variables.dateOfPurchaseValidationVar), asPrimitiveValue(model.variables.purchaseDateVar), asPrimitiveValue(model.variables.isToShowCustom5007ErrorCodeMessageVar), asPrimitiveValue(model.variables.taxFreeFormNumberIn)]
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_BottomDrawer_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("d3f60tBWNUWnyeirMvfAuA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.BottomDrawerRec();
rec.isOpenAttr = model.variables.isToOpenDrawerVar;
return rec;
}();
}, function () {
return model.variables.isToOpenDrawerVar;
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onClose$Action: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ShopperPortalEUUIComponents/BottomDrawer OnClose");
controller.bottomDrawerOnClose$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "47",
alias: "22"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("pq_VUCBIzEeYZ4lM1f7aBQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.alignAttr = ShopperPortalEUModel.staticEntities.flexAlign.center;
rec.directionAttr = ShopperPortalEUModel.staticEntities.flexDirection.column;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space4;
return rec;
}();
}),
ExtendedClass: "text-align-center"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "48",
alias: "23"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomImage_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "49",
alias: "24"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
image: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Image, {
extendedProperties: {
"data-testid": "TFF_Image_Example"
},
type: /*External*/ 1,
url: "/ShopperPortalEU_UI_Resources/img/ShopperPortalEU_UI_Resources.barcode_tff_white.svg",
_idProps: {
service: idService,
uuid: "50"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "51"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "BottomDrawerText"
},
value: "Your tax-free number is located below the barcode on your Tax Free form.",
_idProps: {
service: idService,
uuid: "52"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
})
},
_dependencies: []
})];
})
},
_dependencies: []
})];
}),
bottom: PlaceholderContent.Empty
},
_dependencies: [asPrimitiveValue(model.variables.isToOpenDrawerVar), asPrimitiveValue(model.variables.isToEnableAddBtnVar), asPrimitiveValue(model.variables.isAddingVar), asPrimitiveValue(model.variables.isToShowCustomSupportLinkVar), asPrimitiveValue(model.variables.dropdownListValidationVar), asPrimitiveValue(model.variables.passportSelectedVar.textAttr), asPrimitiveValue(model.variables.passportSelectedVar.valueAttr), asPrimitiveValue(model.variables.passportsVar), asPrimitiveValue(model.variables.dateOfPurchaseValidationVar), asPrimitiveValue(model.variables.purchaseDateVar), asPrimitiveValue(model.variables.isToShowCustom5007ErrorCodeMessageVar), asPrimitiveValue(model.variables.taxFreeFormNumberIn), asPrimitiveValue(model.variables.isDataFetchedVar)]
}), "TaxFreeFormDetails");
        };
        return View;
    })(OSView.BaseView.BaseWebScreen);
	
    return View;
});
define("ShopperPortalEU.Refund.TaxFreeFormDetails.mvc$controller", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.controller", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.controller", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.controller", "ShopperPortalEU.languageResources", "ShopperPortalEU.clientVariables", "ShopperPortalEU.Refund.TaxFreeFormDetails.mvc$debugger", "ShopperPortalEU.Refund.controller", "ShopperPortalEU_UI_Components.model$DatePickerValidationOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$CustomDropdownListValidationOptionsRec", "ShopperPortalEU_UI_Components.model$CustomDropdownListValueOptionsRec", "ShopperPortalEU.model$CustomDropdownListValueOptionsList", "ShopperPortalEU_UI_Theme.model$LayoutDetailOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU_UI_Components.model$CustomFormOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentTopOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentBottomOptionsRec", "ShopperPortalEU_UI_Components.model$CustomInputOptionsRec", "ShopperPortalEU_UI_Components.model$CustomInputIconOptionRec", "ShopperPortalEU_UI_Components.model$CustomInputValidationOptionsRec", "ShopperPortalEU_UI_Components.model$CustomValidationMessageOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsIconRec", "ShopperPortalEU_UI_Components.model$DatePickerOptionsRec", "ShopperPortalEU_UI_Components.model$DatePickerLabelOptionsRec", "ShopperPortalEU_UI_Components.model$CustomDropdownListOptionsRec", "ShopperPortalEU_UI_Components.model$CustomDropdownListSearchOptionsRec", "ShopperPortalEU_UI_Components.model$CustomDropdownListSelectedItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomFlagOptionsRec", "ShopperPortalEU_UI_Components.model$CustomDropdownListItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconRec", "ShopperPortalEU_UI_Components.model$BottomDrawerRec", "ShopperPortalEU_UI_Components.model$FlexOptionsRec", "ShopperPortalEU_UI_Components.model$CustomImageOptionsRec", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", "ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger", "ShopperPortalEU.model$PassportList", "ShopperPortalEU.controller$GetPassports", "ShopperPortalEU.controller$DefaultErrorMessage", "ShopperPortalEU.model$AnonymousFormsList", "ShopperPortalEU.controller$GetAnonymousFormsList", "ShopperPortalEU_UI_Components.model$CustomDropdownCustomValueOptionRec", "ShopperPortalEU.controller$ClarityEvent", "ShopperPortalEU.controller$ReplaceAllNonLettersOrNumbers", "ShopperPortalEU_Shopper_IS.model$GetCardsResponseRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS", "ShopperPortalEU.model$GetCardsResponseList", "ShopperPortalEU_Shopper_IS.controller$GetCards", "ShopperPortalEU_Forms_IS.model$AnonymousFormAddRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Forms_IS", "ShopperPortalEU_Forms_IS.controller$LinkAnonymousForm", "ShopperPortalEU.controller$AddAnonymousFormToString", "ShopperPortalEU_Forms_IS.model$FormInfo_WrapperRec", "ShopperPortalEU.model$FormInfo_WrapperList"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ThemeController, ShopperPortalEU_Shopper_ISModel, ShopperPortalEU_Shopper_ISController, ShopperPortalEU_Forms_ISModel, ShopperPortalEU_Forms_ISController, ShopperPortalEULanguageResources, ShopperPortalEUClientVariables, ShopperPortalEU_Refund_TaxFreeFormDetails_mvc_Debugger, ShopperPortalEU_RefundController) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = true;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._dateOfPurchaseOnChange$Action = function (currentDateIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("DateOfPurchaseOnChange");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.Refund.TaxFreeFormDetails.DateOfPurchaseOnChange$vars"))());
vars.value.currentDateInLocal = currentDateIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:OvsoAYXta02Dz76Upyoasw:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.2hmf5e8CwESiEVNcEOKU+g/ClientActions.OvsoAYXta02Dz76Upyoasw:QO24PM9hzeDBRe1ZyWkg5Q", "ShopperPortalEU", "DateOfPurchaseOnChange", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:y_ZxT1S+SEmRH2d8ZCOTjQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:KqYQzo1KfUimzcYXOnTFAQ", callContext.id);
// PurchaseDate = CurrentDate
model.variables.purchaseDateVar = vars.value.currentDateInLocal;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:KqYQzo1KfUimzcYXOnTFAQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// DateOfPurchaseValidation.State = NullTextIdentifier
model.variables.dateOfPurchaseValidationVar.stateAttr = OS.BuiltinFunctions.nullTextIdentifier();
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:KqYQzo1KfUimzcYXOnTFAQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// DateOfPurchaseValidation.Message = ""
model.variables.dateOfPurchaseValidationVar.messageAttr = "";
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:by9+gYptrk+yfi0XDr4uLQ", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:OvsoAYXta02Dz76Upyoasw", callContext.id);
}

};
Controller.registerVariableGroupType("ShopperPortalEU.Refund.TaxFreeFormDetails.DateOfPurchaseOnChange$vars", [{
name: "CurrentDate",
attrName: "currentDateInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Date,
defaultValue: function () {
return OS.DataTypes.DateTime.defaultValue;
}
}]);
Controller.prototype._cancel$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Cancel");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:nupfBQk2jkCN9YSKSvyhNg:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.2hmf5e8CwESiEVNcEOKU+g/ClientActions.nupfBQk2jkCN9YSKSvyhNg:TonBl8BxbNDOo2hZKGtKRA", "ShopperPortalEU", "Cancel", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:0XsT_loJpkCo1soTTo5_Sw", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:TQY34EhneUS2G6vNiWlJiQ", callContext.id);
// Destination: /ShopperPortalEU/MyRefunds
return OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "MyRefunds", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:nupfBQk2jkCN9YSKSvyhNg", callContext.id);
}

};
Controller.prototype._fetchPassports$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("FetchPassports");
callContext = controller.callContext(callContext);
var allExceptionsVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.ErrorHandlerOutputType());
var listFilterByValidVar = new OS.DataTypes.VariableHolder();
var getPassportsVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.allExceptionsVar = allExceptionsVar;
varBag.listFilterByValidVar = listFilterByValidVar;
varBag.getPassportsVar = getPassportsVar;
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:VvdeDBkZxEKZD0rKIRkVqw:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.2hmf5e8CwESiEVNcEOKU+g/ClientActions.VvdeDBkZxEKZD0rKIRkVqw:S0KY+pgubOZebpvDVptTaQ", "ShopperPortalEU", "FetchPassports", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:4pmLLNlXIkS1+OSTumSPqA", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:WffjP11XcUy8wK4F7EK1RA", callContext.id);
// IsDataFetched = False
model.variables.isDataFetchedVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:jN7ymQnGl0auSKl3JI_LUg", callContext.id);
// Execute Action: GetPassports
model.flush();
return ShopperPortalEUController.default.getPassports$Action(callContext).then(function (value) {
getPassportsVar.value = value;
}).then(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:i01VywJX8kSDnMvfYe6_0A", callContext.id);
// Execute Action: ListSort
OS.SystemActions.listSort(getPassportsVar.value.passportsOut, function (p) {
return p.expirationDateAttr;
}, false, callContext);
}).then(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:jGSjQD3R0ESS2fpIKozD0Q", callContext.id) && getPassportsVar.value.isSuccessOut)) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:dP+sf9TOdEidOA7c2jZk2Q", callContext.id);
// Execute Action: ListFilterByValid
listFilterByValidVar.value = OS.SystemActions.listFilter(getPassportsVar.value.passportsOut, function (p) {
return p.expirationDateAttr.gte(OS.BuiltinFunctions.currDate());
}, callContext);

OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:gZi7elsW+0SzXAXObFZtbg", callContext.id);
// Execute Action: ListAppendAll
OS.SystemActions.listAppendAll(model.variables.passportsVar, OS.DataConversion.JSConversions.typeConvertRecordList(listFilterByValidVar.value.filteredListOut, new ShopperPortalEUModel.CustomDropdownListValueOptionsList(), function (source, target) {
target.textAttr = source.numberAttr;
target.valueAttr = source.countryNumericIsoCodeAttr;
return target;
}), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:v1wsFp2+xEWScF_T45KYTg", callContext.id);
// IsDataFetched = True
model.variables.isDataFetchedVar = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:YrZK2IVSa0WWx9OrWpMLOA", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:DfCpgWelO068RCdPl5j3zw", callContext.id);
// Execute Action: ErrorMessage
ShopperPortalEU_UI_ThemeController.default.customMessageTrigger$Action(function () {
var rec = new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customMessageType.error;
rec.titleAttr = "We couldn\'t load the passports";
rec.contentAttr = OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.defaultErrorMessage$Action(callContext).errorMessageOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
rec.testIdAttr = "GetPassportsError";
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:XwJgjt9CG0eWDGzr1O1RuQ", callContext.id);
}

});
}).catch(function (ex) {
OS.Logger.trace("TaxFreeFormDetails.FetchPassports", OS.Exceptions.getMessage(ex), ex.name);
// Handle Error: AllExceptions
if(!(OS.Exceptions.isSystem(ex))) {
OS.Logger.error(null, ex);
allExceptionsVar.value.exceptionMessageAttr = OS.Exceptions.getMessage(ex);
OutSystemsDebugger.handleException(allExceptionsVar.value.exceptionMessageAttr, callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:u3rxrtLj4EWjy+YV+1BYXg", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:32BzzUwpNE+vMu30Zc_4TQ", callContext.id);
// Execute Action: GenericErrorMessage
ShopperPortalEU_UI_ThemeController.default.customMessageTrigger$Action(function () {
var rec = new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customMessageType.error;
rec.titleAttr = "We couldn\'t load the passports";
rec.contentAttr = OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.defaultErrorMessage$Action(callContext).errorMessageOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
rec.testIdAttr = "GetPassportsGenericError";
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:nDloHV6LaEOPOEbVDfhDCw", callContext.id);
return OS.Flow.returnAsync();

});
}

throw ex;
}).then(function (res) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:VvdeDBkZxEKZD0rKIRkVqw", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:VvdeDBkZxEKZD0rKIRkVqw", callContext.id);
throw ex;

});
};
Controller.prototype._onInitialize$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnInitialize");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:4YTJF8AphEqO64LGQwsvNg:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.2hmf5e8CwESiEVNcEOKU+g/ClientActions.4YTJF8AphEqO64LGQwsvNg:uVw0oov5hCLIZXbFKOCa6A", "ShopperPortalEU", "OnInitialize", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:mAzzPE1qY0uzQ3BYFktrbA", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:9TfC5LbPzUK4zPKqNDGJ9A", callContext.id);
// IsAdding = False
model.variables.isAddingVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:SXPeARv_5E++CrDelSOl8g", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:4YTJF8AphEqO64LGQwsvNg", callContext.id);
}

};
Controller.prototype._tFF_NumberOnBlur$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("TFF_NumberOnBlur");
callContext = controller.callContext(callContext);
var getAnonymousFormsListVar = new OS.DataTypes.VariableHolder();
var listFilterVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.getAnonymousFormsListVar = getAnonymousFormsListVar;
varBag.listFilterVar = listFilterVar;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:7sOuI57YY0Ku9rpB6Q5AWg:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.2hmf5e8CwESiEVNcEOKU+g/ClientActions.7sOuI57YY0Ku9rpB6Q5AWg:pYRLF3hwpg5eWgyQQ+ciZg", "ShopperPortalEU", "TFF_NumberOnBlur", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:khGlhrCosEyR6Cjh8y1QKA", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Fz2mVMNGQEuxR3_NgUazTA", callContext.id) && (ShopperPortalEUClientVariables.getAnonymousFormList() === ""))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:o5VQDuo_4UuxCtUHsAs7PA", callContext.id);
} else {
// TFF changed ?
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Y5LMMUOT30iWfnPLMUjJxw", callContext.id) && ((model.variables.tFFWithWrongDateVar) !== (model.variables.taxFreeFormNumberIn)))) {
// Reset NumberOfAttemps
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Zc7llO8ZR0KJ790XCCNM_Q", callContext.id);
// NumberOfAttemps = 0
model.variables.numberOfAttempsVar = 0;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Zc7llO8ZR0KJ790XCCNM_Q", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// DateOfPurchaseValidation.State = NullTextIdentifier
model.variables.dateOfPurchaseValidationVar.stateAttr = OS.BuiltinFunctions.nullTextIdentifier();
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Zc7llO8ZR0KJ790XCCNM_Q", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// HasDefaultCard = If
model.variables.hasDefaultCardVar = (((model.variables.cC4digitsVar === "")) ? (false) : (true));
}

OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:kr+UpGs0hEGrW6PTzls0aw", callContext.id);
// Execute Action: GetAnonymousFormsList
getAnonymousFormsListVar.value = ShopperPortalEUController.default.getAnonymousFormsList$Action(ShopperPortalEUClientVariables.getAnonymousFormList(), callContext);

OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:V+WCqkaEuUWI4m9Sehtxgg", callContext.id);
// Execute Action: ListFilter
listFilterVar.value = OS.SystemActions.listFilter(getAnonymousFormsListVar.value.anonymousFormsListOut, function (p) {
return (p.formNumberAttr === model.variables.taxFreeFormNumberIn);
}, callContext);

// FoundTFF?
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:r+9IvJsn00am3mfxuReXTg", callContext.id) && !(listFilterVar.value.filteredListOut.isEmpty))) {
// Attempt number < 3
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:GTQgVIfDAEm2zwnIIG7nzA", callContext.id) && (OS.BuiltinFunctions.textToInteger(listFilterVar.value.filteredListOut.getCurrent(callContext.iterationContext).attempNrAttr) <= 2))) {
// UpdateNumberOfAttemps
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:aHMTTnWgCkafG9FCYafgaw", callContext.id);
// NumberOfAttemps = TextToInteger
model.variables.numberOfAttempsVar = OS.BuiltinFunctions.textToInteger(listFilterVar.value.filteredListOut.getCurrent(callContext.iterationContext).attempNrAttr);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:3ABRhHvlF06bHwZtai3nng", callContext.id);
} else {
// Update flags
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:scMvl3cKg0+10uiHqeCLtQ", callContext.id);
// IsToShowCustomSupportLink = True
model.variables.isToShowCustomSupportLinkVar = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:scMvl3cKg0+10uiHqeCLtQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// IsToEnableAddBtn = False
model.variables.isToEnableAddBtnVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:scMvl3cKg0+10uiHqeCLtQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// DateOfPurchaseValidation.Message = ""
model.variables.dateOfPurchaseValidationVar.messageAttr = "";
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:scMvl3cKg0+10uiHqeCLtQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// DateOfPurchaseValidation.State = Error
model.variables.dateOfPurchaseValidationVar.stateAttr = ShopperPortalEUModel.staticEntities.customValidationMessageState.error;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:scMvl3cKg0+10uiHqeCLtQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// HasDefaultCard = False
model.variables.hasDefaultCardVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:3ABRhHvlF06bHwZtai3nng", callContext.id);
}

} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:3ABRhHvlF06bHwZtai3nng", callContext.id);
}

}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:7sOuI57YY0Ku9rpB6Q5AWg", callContext.id);
}

};
Controller.prototype._onChangePassportDropdown$Action = function (valueSelectedIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnChangePassportDropdown");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.Refund.TaxFreeFormDetails.OnChangePassportDropdown$vars"))());
vars.value.valueSelectedInLocal = valueSelectedIn.clone();
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:btdzkMLU_U60YcWGCGsOVw:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.2hmf5e8CwESiEVNcEOKU+g/ClientActions.btdzkMLU_U60YcWGCGsOVw:xDj57iBGRZCSsJAuuwDtCg", "ShopperPortalEU", "OnChangePassportDropdown", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:GiwxlJVwqUK4jUO6ZnUmZw", callContext.id);
// Reset validation values
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:cWcG5l4+bkue85HsXTw0kw", callContext.id);
// PassportSelected = ValueSelected
model.variables.passportSelectedVar = OS.DataConversion.JSConversions.typeConvertRecord(vars.value.valueSelectedInLocal, new ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValueOptionsRec(), function (source, target) {
target.textAttr = source.textAttr;
target.valueAttr = source.valueAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:cWcG5l4+bkue85HsXTw0kw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// DropdownListValidation.State = NullTextIdentifier
model.variables.dropdownListValidationVar.stateAttr = OS.BuiltinFunctions.nullTextIdentifier();
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:cWcG5l4+bkue85HsXTw0kw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// DropdownListValidation.Message = ""
model.variables.dropdownListValidationVar.messageAttr = "";
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:lKsfJIAKxkmW0dbQx8l+kw", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:btdzkMLU_U60YcWGCGsOVw", callContext.id);
}

};
Controller.registerVariableGroupType("ShopperPortalEU.Refund.TaxFreeFormDetails.OnChangePassportDropdown$vars", [{
name: "ValueSelected",
attrName: "valueSelectedInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Record,
defaultValue: function () {
return new ShopperPortalEU_UI_ComponentsModel.CustomDropdownCustomValueOptionRec();
},
complexType: ShopperPortalEU_UI_ComponentsModel.CustomDropdownCustomValueOptionRec
}]);
Controller.prototype._tFF_NumberInputOnCameraClick$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("TFF_NumberInputOnCameraClick");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:z2oDv5R+qU2+JabV9R54Hw:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.2hmf5e8CwESiEVNcEOKU+g/ClientActions.z2oDv5R+qU2+JabV9R54Hw:0EdFxO7pciLj4oNjMrAwfQ", "ShopperPortalEU", "TFF_NumberInputOnCameraClick", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:cWougeVKy06IRflu4c4hmQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:INfV0jb1YUe4BBtW2HBcKA", callContext.id);
// Execute Action: ClarityEvent
ShopperPortalEUController.default.clarityEvent$Action("ScanTFF_btn", callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:GCbE_puifEaqMIwUgwDnLQ", callContext.id);
// Destination: /ShopperPortalEU/AddTaxFreeForm
return OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "AddTaxFreeForm", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:z2oDv5R+qU2+JabV9R54Hw", callContext.id);
}

};
Controller.prototype._tFF_NumberInputOnIconClick$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("TFF_NumberInputOnIconClick");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:_qaMx62EOk2Db383Pu2rmg:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.2hmf5e8CwESiEVNcEOKU+g/ClientActions._qaMx62EOk2Db383Pu2rmg:WYOc2OHQjTYofE3DGF_39g", "ShopperPortalEU", "TFF_NumberInputOnIconClick", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ak6ME0hB7Uyf9BRpm+bueQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:H09fNdrBn0CZ5VMd6H0igQ", callContext.id);
// IsToOpenDrawer = True
model.variables.isToOpenDrawerVar = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:AO5sxI7rQUme4J7JxfQGRA", callContext.id);
// Execute Action: ClarityEvent
ShopperPortalEUController.default.clarityEvent$Action("TFFhelper_btn", callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:PcynjZOEIEGIkDr2G+lpzA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:_qaMx62EOk2Db383Pu2rmg", callContext.id);
}

};
Controller.prototype._tFF_NumberOnChange$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("TFF_NumberOnChange");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:EL_+0tgAGEmVZUazATdpzQ:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.2hmf5e8CwESiEVNcEOKU+g/ClientActions.EL_+0tgAGEmVZUazATdpzQ:B6gvizGuX076e7Dwhtu0bQ", "ShopperPortalEU", "TFF_NumberOnChange", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:f6zqIoIWEEqIu0Job7QckA", callContext.id);
// Format TFFNumber
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:C4v3GeRgh0ScrfXjrduNhg", callContext.id);
// TaxFreeFormNumber = ReplaceAllNonLettersOrNumbers(TaxFreeFormNumber)
model.variables.taxFreeFormNumberIn = OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.replaceAllNonLettersOrNumbers$Action(model.variables.taxFreeFormNumberIn, callContext).stringFormattedOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
// UpdateLocals
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:WLGgkGSca0m_mf5gqKwIaQ", callContext.id);
// IsToShowCustomSupportLink = False
model.variables.isToShowCustomSupportLinkVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:WLGgkGSca0m_mf5gqKwIaQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// IsToEnableAddBtn = True
model.variables.isToEnableAddBtnVar = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:WLGgkGSca0m_mf5gqKwIaQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// IsFormDisqualified = False
model.variables.isFormDisqualifiedVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:WLGgkGSca0m_mf5gqKwIaQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// TFF_Number.Valid = True
model.widgets.get(idService.getId("TFF_Number")).validAttr = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:WLGgkGSca0m_mf5gqKwIaQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// TFF_Number.ValidationMessage = ""
model.widgets.get(idService.getId("TFF_Number")).validationMessageAttr = "";
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:WLGgkGSca0m_mf5gqKwIaQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "6");
// IsToShowCustom5007ErrorCodeMessage = False
model.variables.isToShowCustom5007ErrorCodeMessageVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:YmX5FBuJhEa0lOUy+DeKwQ", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:EL_+0tgAGEmVZUazATdpzQ", callContext.id);
}

};
Controller.prototype._onAfterAuthentication$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnAfterAuthentication");
callContext = controller.callContext(callContext);
var listFilterVar = new OS.DataTypes.VariableHolder();
var getCardsVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.listFilterVar = listFilterVar;
varBag.getCardsVar = getCardsVar;
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:fpx75jK4bEq4yAsbJbtPEQ:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.2hmf5e8CwESiEVNcEOKU+g/ClientActions.fpx75jK4bEq4yAsbJbtPEQ:LPseJRuPyATr_RVsN8PCZg", "ShopperPortalEU", "OnAfterAuthentication", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:7cWwY46dDkuWHxKC5dx19g", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ce5YfSHGLUm79OaEPkbBdA", callContext.id);
// Execute Action: GetCards
model.flush();
return ShopperPortalEU_Shopper_ISController.default.getCards$Action(ShopperPortalEUClientVariables.getShopperGuid(), callContext).then(function (value) {
getCardsVar.value = value;
}).then(function () {
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:1881I_GobU6tNDCypD9SxA", callContext.id) && getCardsVar.value.isSuccessOut)) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:mTUJUNsruU2RVUf8WNYmfg", callContext.id);
// Execute Action: ListFilter
listFilterVar.value = OS.SystemActions.listFilter(getCardsVar.value.cardsOut, function (p) {
return p.isDefaultAttr;
}, callContext);

if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:qbBgo71M7EiXpyhurHlLLA", callContext.id) && listFilterVar.value.filteredListOut.isEmpty)) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:YRpBY3DcoUS9tXLKN403eA", callContext.id);
// HasDefaultCard = False
model.variables.hasDefaultCardVar = false;
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Ccq6JDH2NkCrTrUhzfk5IA", callContext.id);
// HasDefaultCard = True
model.variables.hasDefaultCardVar = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Ccq6JDH2NkCrTrUhzfk5IA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// CC4digits = Substr
model.variables.cC4digitsVar = OS.BuiltinFunctions.substr(listFilterVar.value.filteredListOut.getCurrent(callContext.iterationContext).maskedCardNumberAttr, (OS.BuiltinFunctions.length(listFilterVar.value.filteredListOut.getCurrent(callContext.iterationContext).maskedCardNumberAttr) - 4), 4);
}

OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ZDjxsCGpMEGbVxADTc8AXg", callContext.id);
// Execute Action: FetchPassports
return controller._fetchPassports$Action(callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:gyOg1fbdrECsFRwc68F74A", callContext.id);
});
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:FKvyY6Um1kS_a6BfhMD55Q", callContext.id);
// Execute Action: ErrorMessage2
ShopperPortalEU_UI_ThemeController.default.customMessageTrigger$Action(function () {
var rec = new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customMessageType.error;
rec.titleAttr = getCardsVar.value.errorMessageOut;
rec.contentAttr = OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.defaultErrorMessage$Action(callContext).errorMessageOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
rec.testIdAttr = "Error";
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:y488_RH2jUSND8LA+qKQZw", callContext.id);
}

});
});
}).then(function (res) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:fpx75jK4bEq4yAsbJbtPEQ", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:fpx75jK4bEq4yAsbJbtPEQ", callContext.id);
throw ex;

});
};
Controller.prototype._bottomDrawerOnClose$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("BottomDrawerOnClose");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:GUGm54mGzkmbAGQRZAzB2w:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.2hmf5e8CwESiEVNcEOKU+g/ClientActions.GUGm54mGzkmbAGQRZAzB2w:4WhVX52duSUYYa6jFk75JQ", "ShopperPortalEU", "BottomDrawerOnClose", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:KGpTtQWEdk6g+_nVr1HGDg", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:m2soADyx8EiCIE1eOxdreQ", callContext.id);
// IsToOpenDrawer = False
model.variables.isToOpenDrawerVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:_Qag1540R0+ITzrQO9WUow", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:GUGm54mGzkmbAGQRZAzB2w", callContext.id);
}

};
Controller.prototype._addTFF$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("AddTFF");
callContext = controller.callContext(callContext);
var allExceptionsVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.ErrorHandlerOutputType());
var linkAnonymousFormVar = new OS.DataTypes.VariableHolder();
var check_TFF_In_MyRefundsListVar = new OS.DataTypes.VariableHolder();
var jSONDeserializeFormInfo_WrapperVar = new OS.DataTypes.VariableHolder(new (OS.Controller.BaseController.getJSONDeserializeOutputType(ShopperPortalEUModel.FormInfo_WrapperList))());
varBag.callContext = callContext;
varBag.allExceptionsVar = allExceptionsVar;
varBag.linkAnonymousFormVar = linkAnonymousFormVar;
varBag.check_TFF_In_MyRefundsListVar = check_TFF_In_MyRefundsListVar;
varBag.jSONDeserializeFormInfo_WrapperVar = jSONDeserializeFormInfo_WrapperVar;
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:YEkZ8nK9yEW6L6TOE3EoBg:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.2hmf5e8CwESiEVNcEOKU+g/ClientActions.YEkZ8nK9yEW6L6TOE3EoBg:+3zlk7DhokcCVISWzpjp4Q", "ShopperPortalEU", "AddTFF", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:bg9jSZc0kE2alQGHhyFPFQ", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
do {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:iIJpp2G+h0S4dQWmrZK4sg", callContext.id);
// IsAdding = True
model.variables.isAddingVar = true;
// TFF is empty?
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:uJl7IVLrnkuxvUnj4IF0RA", callContext.id) && (model.variables.taxFreeFormNumberIn === ""))) {
// Validation Message
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:OItZMTak2k6oYeTOw12H+A", callContext.id);
// TFF_Number.Valid = False
model.widgets.get(idService.getId("TFF_Number")).validAttr = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:OItZMTak2k6oYeTOw12H+A", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// TFF_Number.ValidationMessage = "This field is required"
model.widgets.get(idService.getId("TFF_Number")).validationMessageAttr = "This field is required";
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:6V_6txwt9UyVKeR6V8Dk8g", callContext.id);
// TFF_Number.Valid = True
model.widgets.get(idService.getId("TFF_Number")).validAttr = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:6V_6txwt9UyVKeR6V8Dk8g", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// TFF_Number.ValidationMessage = ""
model.widgets.get(idService.getId("TFF_Number")).validationMessageAttr = "";
}

// PurchaseDate is empty?
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:L9zP2W0HE0SrTTRgVQ0XiA", callContext.id) && model.variables.purchaseDateVar.equals(OS.BuiltinFunctions.nullDate()))) {
// Validation Message
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:qnbM3801REmR3Lp6mDvU5Q", callContext.id);
// DateOfPurchaseValidation.State = Error
model.variables.dateOfPurchaseValidationVar.stateAttr = ShopperPortalEUModel.staticEntities.customValidationMessageState.error;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:qnbM3801REmR3Lp6mDvU5Q", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// DateOfPurchaseValidation.Message = "This field is required"
model.variables.dateOfPurchaseValidationVar.messageAttr = "This field is required";
} else {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:J9e0bsAdaUyvfHTSGe22NA", callContext.id) && model.variables.purchaseDateVar.gt(OS.BuiltinFunctions.currDate()))) {
// Validation Message
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:nhZQYz0YY0izthHDqKlvvA", callContext.id);
// DateOfPurchaseValidation.State = Error
model.variables.dateOfPurchaseValidationVar.stateAttr = ShopperPortalEUModel.staticEntities.customValidationMessageState.error;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:nhZQYz0YY0izthHDqKlvvA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// DateOfPurchaseValidation.Message = "Future date not allowed"
model.variables.dateOfPurchaseValidationVar.messageAttr = "Future date not allowed";
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:fdbryMZ9i064kDJK1SChcw", callContext.id);
// DateOfPurchaseValidation.Message = ""
model.variables.dateOfPurchaseValidationVar.messageAttr = "";
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:fdbryMZ9i064kDJK1SChcw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// DateOfPurchaseValidation.State = NullTextIdentifier
model.variables.dateOfPurchaseValidationVar.stateAttr = OS.BuiltinFunctions.nullTextIdentifier();
break;
}

}

// dummy
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:FUoXTXLdEUK8dIcmEyfBSg", callContext.id);
} while(false)
;
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:EAydfs064EOByDl_Ff+4gg", callContext.id) && ((model.variables.passportsVar.length > 1) && (model.variables.passportSelectedVar.textAttr === "")))) {
// Validation Message
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:2N2zYJ2fCkC_skjT_JZ9Qw", callContext.id);
// DropdownListValidation.State = Error
model.variables.dropdownListValidationVar.stateAttr = ShopperPortalEUModel.staticEntities.customValidationMessageState.error;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:2N2zYJ2fCkC_skjT_JZ9Qw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// DropdownListValidation.Message = "This field is required"
model.variables.dropdownListValidationVar.messageAttr = "This field is required";
}

return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:s4tUImRG0U6GXlDClz0iYg", callContext.id) && (model.widgets.get(idService.getId("TFF_Number")).validAttr && !(model.variables.purchaseDateVar.equals(OS.BuiltinFunctions.nullDate()))))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:MifQRJTkmk643jxW1gsxhg", callContext.id);
// JSON Deserialize: JSONDeserializeFormInfo_Wrapper
jSONDeserializeFormInfo_WrapperVar.value.dataOut = OS.JSONUtils.deserializeFromJSON(ShopperPortalEUClientVariables.getFormInfoListJSON(), ShopperPortalEUModel.FormInfo_WrapperList, false);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:SnRzjYKFQECmJch0UlA5qg", callContext.id);
// Execute Action: Check_TFF_In_MyRefundsList
check_TFF_In_MyRefundsListVar.value = OS.SystemActions.listFilter(jSONDeserializeFormInfo_WrapperVar.value.dataOut, function (p) {
return (p.formNumberAttr === model.variables.taxFreeFormNumberIn);
}, callContext);

// Form is not in MyRefundList?
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ZmDMWnHEUE6OGc77Yj9MFg", callContext.id) && check_TFF_In_MyRefundsListVar.value.filteredListOut.isEmpty)) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:dD7RiWX1u0ONQwLssnW8JA", callContext.id);
// Execute Action: LinkAnonymousForm
model.flush();
return ShopperPortalEU_Forms_ISController.default.linkAnonymousForm$Action(function () {
var rec = new ShopperPortalEU_Forms_ISModel.AnonymousFormAddRec();
rec.purchaseDateAttr = OS.BuiltinFunctions.formatDateTime(model.variables.purchaseDateVar, "yyyy-MM-dd");
rec.travelDocumentIdAttr = ((((model.variables.passportSelectedVar.textAttr) !== (""))) ? (model.variables.passportSelectedVar.textAttr) : (model.variables.passportsVar.getCurrent(callContext.iterationContext).textAttr));
rec.passportIssuingCountryAttr = ((((model.variables.passportSelectedVar.valueAttr) !== (""))) ? (model.variables.passportSelectedVar.valueAttr) : (model.variables.passportsVar.getCurrent(callContext.iterationContext).valueAttr));
return rec;
}(), model.variables.taxFreeFormNumberIn, ShopperPortalEUClientVariables.getShopperGuid(), callContext).then(function (value) {
linkAnonymousFormVar.value = value;
}).then(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:GotikTUSD0eIz0uS9wC4ug", callContext.id) && linkAnonymousFormVar.value.successOut)) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:dk1nFq4EmEOeQfKfdNK4zQ", callContext.id);
// Execute Action: SuccessMessage
ShopperPortalEU_UI_ThemeController.default.customMessageTrigger$Action(function () {
var rec = new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customMessageType.success;
rec.titleAttr = "Tax Free form added";
rec.contentAttr = "The form may take some time to be added to your account";
rec.autoHideAttr = false;
rec.testIdAttr = "AddTaxFreeForm_SuccessMessage";
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:qFKOq7DccEGRkoQVKIgelA", callContext.id);
// Execute Action: AddedEvent
ShopperPortalEUController.default.clarityEvent$Action("AddTFFdetails_btn", callContext);
} else {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:cLCNrYz5pEWqHfOvnw1pqg", callContext.id) && linkAnonymousFormVar.value.isErrorProcessedOut)) {
// Is Wrong Form Date?
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:WGifZnBatkyLlFey8ZuOag", callContext.id) && (linkAnonymousFormVar.value.errorCodeOut === "5005"))) {
// UpdateNumberOfAttemps
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:lN7OuuY5vUO_bRKnJZMZoA", callContext.id);
// DateOfPurchaseValidation.State = Error
model.variables.dateOfPurchaseValidationVar.stateAttr = ShopperPortalEUModel.staticEntities.customValidationMessageState.error;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:lN7OuuY5vUO_bRKnJZMZoA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// NumberOfAttemps = NumberOfAttemps + 1
model.variables.numberOfAttempsVar = (model.variables.numberOfAttempsVar + 1);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:lN7OuuY5vUO_bRKnJZMZoA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// TFFWithWrongDate = TaxFreeFormNumber
model.variables.tFFWithWrongDateVar = model.variables.taxFreeFormNumberIn;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:MMc0+c_md0S6zPKr7w4OSA", callContext.id);
// Execute Action: AddAnonymousFormToString
ShopperPortalEUController.default.addAnonymousFormToString$Action(model.variables.taxFreeFormNumberIn, OS.BuiltinFunctions.integerToText(model.variables.numberOfAttempsVar), callContext);
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:3oqCyC_z3ECsvZ+4pRpJqA", callContext.id) && (model.variables.numberOfAttempsVar === 3))) {
// UpdateFlags
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:pAC5r_Q2IUCcQ7rKZweIpQ", callContext.id);
// DateOfPurchaseValidation.Message = ""
model.variables.dateOfPurchaseValidationVar.messageAttr = "";
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:pAC5r_Q2IUCcQ7rKZweIpQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// IsToShowCustomSupportLink = True
model.variables.isToShowCustomSupportLinkVar = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:pAC5r_Q2IUCcQ7rKZweIpQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// IsToEnableAddBtn = False
model.variables.isToEnableAddBtnVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:pAC5r_Q2IUCcQ7rKZweIpQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// HasDefaultCard = False
model.variables.hasDefaultCardVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:6GLTOmxczkq+QiorepsVyw", callContext.id);
// Execute Action: LastAttemptEvent
ShopperPortalEUController.default.clarityEvent$Action("WrongPurchaseDate_failed3rd_time_btn", callContext);
// ClearNumberOfAttemps
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ddgbZdszJ0uMJWr10zaPQg", callContext.id);
// NumberOfAttemps = 0
model.variables.numberOfAttempsVar = 0;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ddgbZdszJ0uMJWr10zaPQg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// IsAdding = False
model.variables.isAddingVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:CkByiLWSNUe42o7EEH5w+w", callContext.id);
return OS.Flow.returnAsync();

} else {
// ValidationMessage
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:tz9HmxYjpUGA1uDkf9NFhA", callContext.id);
// DateOfPurchaseValidation.Message = "These details do not match the Tax Free form. You have " + If + " remaining."
model.variables.dateOfPurchaseValidationVar.messageAttr = (("These details do not match the Tax Free form. You have " + (((model.variables.numberOfAttempsVar === 2)) ? ("1 attempt") : ("2 attempts"))) + " remaining.");
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:tz9HmxYjpUGA1uDkf9NFhA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// IsAdding = False
model.variables.isAddingVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:2vQLwrf4AEOccz25sBDQ8Q", callContext.id);
// Execute Action: AttemptEvent
ShopperPortalEUController.default.clarityEvent$Action((("WrongPurchaseDate_failed" + (((model.variables.numberOfAttempsVar === 2)) ? ("1st") : ("2nd"))) + "_time_btn"), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:EPPWbyIhk0izQUiRvqLK8A", callContext.id);
return OS.Flow.returnAsync();

}

} else {
// Form expired
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:KiDFrpAL0U6j_bzJ4tv5DA", callContext.id) && linkAnonymousFormVar.value.isFormExpiredOut)) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:QdQASwuKt0yizGkbYvW0hg", callContext.id);
// Execute Action: FormExpiredEvent
ShopperPortalEUController.default.clarityEvent$Action("TFFExpired_btn", callContext);
}

// Form voided
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:uWISR+U8HUytoYko306V4A", callContext.id) && linkAnonymousFormVar.value.isFormVoidedOut)) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:M0Lwhf1vHk25NQm5ddO5gA", callContext.id);
// Execute Action: FormVoidedEvent
ShopperPortalEUController.default.clarityEvent$Action("TFFVoided_btn", callContext);
}

// Linked another profile
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:peMnkCP1nUeEYola+kiIBw", callContext.id) && (linkAnonymousFormVar.value.errorCodeOut === "5004"))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:SVj9QaU9o0KTzrZCN9JrSA", callContext.id);
// Execute Action: LinkedAnotherEvent
ShopperPortalEUController.default.clarityEvent$Action("TFFLinkedOtherProfile_btn", callContext);
}

// Form not found
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:+YsWW6qJfEyC34M5Tglhew", callContext.id) && (linkAnonymousFormVar.value.errorCodeOut === "5001"))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:AbVXOgbXW0m0L083_8McsQ", callContext.id);
// Execute Action: FormNotFoundEvent
ShopperPortalEUController.default.clarityEvent$Action("TFFNotFound_btn", callContext);
}

// Not anonymous form
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:hILjQWJzakGjmHvB6aqOSg", callContext.id) && (linkAnonymousFormVar.value.errorCodeOut === "5007"))) {
// set IsToShowCustom5007ErrorCodeMessage
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:odu9feevhkakXFqP+Ev6kA", callContext.id);
// IsToShowCustom5007ErrorCodeMessage = True
model.variables.isToShowCustom5007ErrorCodeMessageVar = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:IFWh_ae6bUCcOOPYx2hiDA", callContext.id);
// Execute Action: NotAnonymousEvent
ShopperPortalEUController.default.clarityEvent$Action("NotAnonymousTFF_btn", callContext);
}

// Validation Message
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:JEbwa+TSK0yi49Ai8jTWOA", callContext.id);
// TFF_Number.Valid = False
model.widgets.get(idService.getId("TFF_Number")).validAttr = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:JEbwa+TSK0yi49Ai8jTWOA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// TFF_Number.ValidationMessage = LinkAnonymousForm.ErrorMessage
model.widgets.get(idService.getId("TFF_Number")).validationMessageAttr = linkAnonymousFormVar.value.errorMessageOut;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:JEbwa+TSK0yi49Ai8jTWOA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// IsAdding = False
model.variables.isAddingVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:rrCxoDsCoE+tiZ+yLqNC8g", callContext.id);
return OS.Flow.returnAsync();

}

} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:r+YcUO+0BkSs7nYJpg4n0g", callContext.id);
// Execute Action: ErrorMessage
ShopperPortalEU_UI_ThemeController.default.customMessageTrigger$Action(function () {
var rec = new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customMessageType.error;
rec.titleAttr = linkAnonymousFormVar.value.errorMessageOut;
rec.contentAttr = OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.defaultErrorMessage$Action(callContext).errorMessageOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
rec.autoHideAttr = false;
rec.testIdAttr = "AddTaxFreeForm_ErrorAPIMessage";
return rec;
}(), callContext);
}

}

OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:BU574hEUg0K4vN9CqPVr8A", callContext.id);
// Destination: /ShopperPortalEU/MyRefunds
return OS.Flow.returnAsync(OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "MyRefunds", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true));
});
} else {
// Validation Message
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:DJiSqwBQjEqY7A5ggYhLhQ", callContext.id);
// TFF_Number.Valid = False
model.widgets.get(idService.getId("TFF_Number")).validAttr = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:DJiSqwBQjEqY7A5ggYhLhQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// TFF_Number.ValidationMessage = "This Tax Free form already exists"
model.widgets.get(idService.getId("TFF_Number")).validationMessageAttr = "This Tax Free form already exists";
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:aQbAhJYva0mL5LFOOv5N2g", callContext.id);
// Execute Action: AlreadyExistsEvent
ShopperPortalEUController.default.clarityEvent$Action("TFFAlreadyExists_btn", callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:GN9MKlVnwU6hDoQxddlA9g", callContext.id);
// IsAdding = False
model.variables.isAddingVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:cs1Of8Q1vkeGBQzOn1Zq2A", callContext.id);
}

});
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:0YgHIOW1I0OSZaYb+++ISQ", callContext.id);
// IsAdding = False
model.variables.isAddingVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:9jngb8S9xEKi8VPFGPHwzA", callContext.id);
}

});
}).catch(function (ex) {
OS.Logger.trace("TaxFreeFormDetails.AddTFF", OS.Exceptions.getMessage(ex), ex.name);
// Handle Error: AllExceptions
if(!(OS.Exceptions.isSystem(ex))) {
OS.Logger.error(null, ex);
allExceptionsVar.value.exceptionMessageAttr = OS.Exceptions.getMessage(ex);
OutSystemsDebugger.handleException(allExceptionsVar.value.exceptionMessageAttr, callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:_tdtsM9y7k++OrxN+HpRjQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:2f+R9G09PEWYagngDj0nvw", callContext.id);
// IsAdding = False
model.variables.isAddingVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:VmZxaaQke0+bMVK4y155yg", callContext.id);
// Execute Action: CustomMessageTrigger
ShopperPortalEU_UI_ThemeController.default.customMessageTrigger$Action(function () {
var rec = new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customMessageType.error;
rec.titleAttr = "Unable to add Tax Free form";
rec.contentAttr = OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.defaultErrorMessage$Action(callContext).errorMessageOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
rec.testIdAttr = "AddTaxFreeForm_ErrorDefaultMessage";
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:30VUksJ6Gkulv_rB26cVlw", callContext.id);
return OS.Flow.returnAsync();

});
}

throw ex;
}).then(function (res) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:YEkZ8nK9yEW6L6TOE3EoBg", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:YEkZ8nK9yEW6L6TOE3EoBg", callContext.id);
throw ex;

});
};

Controller.prototype.dateOfPurchaseOnChange$Action = function (currentDateIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._dateOfPurchaseOnChange$Action, callContext, currentDateIn);

};
Controller.prototype.cancel$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._cancel$Action, callContext);

};
Controller.prototype.fetchPassports$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._fetchPassports$Action, callContext);

};
Controller.prototype.onInitialize$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onInitialize$Action, callContext);

};
Controller.prototype.tFF_NumberOnBlur$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._tFF_NumberOnBlur$Action, callContext);

};
Controller.prototype.onChangePassportDropdown$Action = function (valueSelectedIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onChangePassportDropdown$Action, callContext, valueSelectedIn);

};
Controller.prototype.tFF_NumberInputOnCameraClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._tFF_NumberInputOnCameraClick$Action, callContext);

};
Controller.prototype.tFF_NumberInputOnIconClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._tFF_NumberInputOnIconClick$Action, callContext);

};
Controller.prototype.tFF_NumberOnChange$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._tFF_NumberOnChange$Action, callContext);

};
Controller.prototype.onAfterAuthentication$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onAfterAuthentication$Action, callContext);

};
Controller.prototype.bottomDrawerOnClose$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._bottomDrawerOnClose$Action, callContext);

};
Controller.prototype.addTFF$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._addTFF$Action, callContext);

};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:VcUw8y2coUi7OQ+l92mkmQ:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ:1Ox1BferNhnfzrugqQ41yg", "ShopperPortalEU", "Refund", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:2hmf5e8CwESiEVNcEOKU+g:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.2hmf5e8CwESiEVNcEOKU+g:VPbG++k5VhsfuLtpkV0vAA", "ShopperPortalEU", "TaxFreeFormDetails", "NRNodes.WebScreen", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:2hmf5e8CwESiEVNcEOKU+g", callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:VcUw8y2coUi7OQ+l92mkmQ", callContext.id);
};
Controller.prototype.onInitializeEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Refund/TaxFreeFormDetails On Initialize");
return controller.onInitialize$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return ShopperPortalEU_RefundController.default.handleError(ex, this.callContext());
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return ShopperPortalEUController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, ShopperPortalEULanguageResources);
});

define("ShopperPortalEU.Refund.TaxFreeFormDetails.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"ml76zst0_EiBBvfB36jKcg": {
getter: function (varBag, idService) {
return varBag.vars.value.currentDateInLocal;
},
dataType: OS.DataTypes.DataTypes.Date
},
"u3rxrtLj4EWjy+YV+1BYXg": {
getter: function (varBag, idService) {
return varBag.allExceptionsVar.value;
}
},
"dP+sf9TOdEidOA7c2jZk2Q": {
getter: function (varBag, idService) {
return varBag.listFilterByValidVar.value;
}
},
"jN7ymQnGl0auSKl3JI_LUg": {
getter: function (varBag, idService) {
return varBag.getPassportsVar.value;
}
},
"kr+UpGs0hEGrW6PTzls0aw": {
getter: function (varBag, idService) {
return varBag.getAnonymousFormsListVar.value;
}
},
"V+WCqkaEuUWI4m9Sehtxgg": {
getter: function (varBag, idService) {
return varBag.listFilterVar.value;
}
},
"I567W8BfoUSxaH+ugZzJIA": {
getter: function (varBag, idService) {
return varBag.vars.value.valueSelectedInLocal;
}
},
"mTUJUNsruU2RVUf8WNYmfg": {
getter: function (varBag, idService) {
return varBag.listFilterVar.value;
}
},
"ce5YfSHGLUm79OaEPkbBdA": {
getter: function (varBag, idService) {
return varBag.getCardsVar.value;
}
},
"_tdtsM9y7k++OrxN+HpRjQ": {
getter: function (varBag, idService) {
return varBag.allExceptionsVar.value;
}
},
"dD7RiWX1u0ONQwLssnW8JA": {
getter: function (varBag, idService) {
return varBag.linkAnonymousFormVar.value;
}
},
"SnRzjYKFQECmJch0UlA5qg": {
getter: function (varBag, idService) {
return varBag.check_TFF_In_MyRefundsListVar.value;
}
},
"MifQRJTkmk643jxW1gsxhg": {
getter: function (varBag, idService) {
return varBag.jSONDeserializeFormInfo_WrapperVar.value;
}
},
"msf7y1AaF02FbEbj9PePYg": {
getter: function (varBag, idService) {
return varBag.model.variables.purchaseDateVar;
},
dataType: OS.DataTypes.DataTypes.Date
},
"8vZZHN4pgkiXnFrMnsiBVw": {
getter: function (varBag, idService) {
return varBag.model.variables.dateOfPurchaseValidationVar;
}
},
"XRHrmE+tzUuqEAkwx20IKA": {
getter: function (varBag, idService) {
return varBag.model.variables.dropdownListValidationVar;
}
},
"FC9OSla3R0aLwn6oPZVC6w": {
getter: function (varBag, idService) {
return varBag.model.variables.isToOpenDrawerVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"HhYxGuOyvkKw4aYeqxrcnA": {
getter: function (varBag, idService) {
return varBag.model.variables.hasDefaultCardVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"cMDyM2vGeEuyyI+viTlTow": {
getter: function (varBag, idService) {
return varBag.model.variables.cC4digitsVar;
},
dataType: OS.DataTypes.DataTypes.Text
},
"FxW2LqfbPEWrMNRTUi5WtA": {
getter: function (varBag, idService) {
return varBag.model.variables.isFormDisqualifiedVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"SDbbTsjn4USvJ+NPJwJxoQ": {
getter: function (varBag, idService) {
return varBag.model.variables.numberOfAttempsVar;
},
dataType: OS.DataTypes.DataTypes.Integer
},
"lA6F308sr0exg8+boChrmA": {
getter: function (varBag, idService) {
return varBag.model.variables.isToShowCustomSupportLinkVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"sSW_vXArq06geakphxOj0g": {
getter: function (varBag, idService) {
return varBag.model.variables.isToEnableAddBtnVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"hx8CPZeDW0y7w+5TQVnnLg": {
getter: function (varBag, idService) {
return varBag.model.variables.isAddingVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"e7vbXdluXEqyCDFJRGh3BQ": {
getter: function (varBag, idService) {
return varBag.model.variables.tFFWithWrongDateVar;
},
dataType: OS.DataTypes.DataTypes.Text
},
"nP6FnplY00yYMhAxZch61w": {
getter: function (varBag, idService) {
return varBag.model.variables.passportsVar;
}
},
"By72CqXRJkOFACTwjMCoQA": {
getter: function (varBag, idService) {
return varBag.model.variables.passportSelectedVar;
}
},
"9nKkMo4O3kGfP_trjP9BEQ": {
getter: function (varBag, idService) {
return varBag.model.variables.isDataFetchedVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"iVz0yx1ifkm6VZwyLtGzQA": {
getter: function (varBag, idService) {
return varBag.model.variables.isToShowCustom5007ErrorCodeMessageVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"VeTfC03B2ES9TQwUp3CSQw": {
getter: function (varBag, idService) {
return varBag.model.variables.taxFreeFormNumberIn;
},
dataType: OS.DataTypes.DataTypes.Text
},
"mhUY2BN4UkKgA9RohnKW9A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderLeft"));
})(varBag.model, idService);
}
},
"bAq1sNRReUyCKC_hq9KGXA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderCenter"));
})(varBag.model, idService);
}
},
"ivVLyCs2wkGLLSQ1Hpxwag": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderRight"));
})(varBag.model, idService);
}
},
"mMKkRpQesUCa4ggvD_Prcg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"Kh_m_p6dt0WDvPP1xqT0WQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"eFJKoi00FEONZxajcNtYBg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Form"));
})(varBag.model, idService);
}
},
"_SVLrRngCUKKulo1Xbt0Aw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("TaxFreeForm"));
})(varBag.model, idService);
}
},
"OS00rGqEOEGWQGwIWDJldQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Top"));
})(varBag.model, idService);
}
},
"nt8Nc_cjh06dTJveEFRBGg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Label"));
})(varBag.model, idService);
}
},
"DDtTaiL1Ekqo2M4iEjaxjg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input"));
})(varBag.model, idService);
}
},
"D6Npsb0k0UCeX+y0F7J6vQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("TFF_Number"));
})(varBag.model, idService);
}
},
"OEP0IOx1bUGOsLyekHHBNQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Description"));
})(varBag.model, idService);
}
},
"6T4QZChkvUuOunzyFt4yaA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"cCklev_TcUWe7Z03+oS+Jg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Link"));
})(varBag.model, idService);
}
},
"YKqcLIqm2kabE_MRMYxpIQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"4iZ1_F_pL0iETcAbFfBPEg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Label"));
})(varBag.model, idService);
}
},
"JKkx45TfPEWIljQFvc2gXQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("ShowPassportDropdown"));
})(varBag.model, idService);
}
},
"q5kku5TDHUexL8qPzLsLdg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("PassportDropdown"));
})(varBag.model, idService);
}
},
"GYptJ1nc60qXwXCZWmvTLA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Label"));
})(varBag.model, idService);
}
},
"vWerMHcgsESD789shphM1w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Selected"));
})(varBag.model, idService);
}
},
"y0666liww06vPvIKwJ7oBQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("CustomDropdownListSelectedItem"));
})(varBag.model, idService);
}
},
"vT2UGnjypkqUIVQvHIyKEg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Left"));
})(varBag.model, idService);
}
},
"jLiGwYyCkEyMgDItxE_pZQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("ShowFlag"));
})(varBag.model, idService);
}
},
"o+RPdyHamUGEm6I8ZQqOqA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"td7yqViPOEGxIWy_2sm9qA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Right"));
})(varBag.model, idService);
}
},
"e1UybgDbcUmS2vjTky355g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("List"));
})(varBag.model, idService);
}
},
"b1NfsF_CnkuFafVZZ5k4BA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Lis"));
})(varBag.model, idService);
}
},
"l2RK29rU4kqWFQIdozHu0g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Left"));
})(varBag.model, idService);
}
},
"zyHSjVQ+hUGIqS+P6v+0Mg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"OYESxy1Iske2qX_JllyMMw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Right"));
})(varBag.model, idService);
}
},
"GxXVRr_8CUGLyPXvJzM1ZQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("List"));
})(varBag.model, idService);
}
},
"ObNb8Je0bUGJ7rUL+UaneQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"7WlNH5RDxUWR8iGPt_7l4g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Link"));
})(varBag.model, idService);
}
},
"xFf9LMtVcEiZv2BJbhkBpA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"14_Sc+abXUmhBllgj0PxGQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Bottom"));
})(varBag.model, idService);
}
},
"qrI7XKXQFU2aYz7CEkw+wA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Button"));
})(varBag.model, idService);
}
},
"yg2oHZoKPkKFZ0XihYH93Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"Wz9IMyJz1E+3Q3lmZEVpAQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Button"));
})(varBag.model, idService);
}
},
"jaMfTZmLJEiMpicmCtpVCw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"8tewevHh30myjA9L2A7gAg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"yagRA6xXI0+svirm6HeDAg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"ggfVPuo0d0SdLBMLFPyDlQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Image"));
})(varBag.model, idService);
}
},
"FX_k58L0fEWgYou+Y7R0HA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Bottom"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
