class customDatatransCard {
  constructor(id, options, events) {
    this.class = 'custom-datatrans-card';
    this.element = document.getElementById(id);
    this.elements = {
      label: this.element.firstElementChild.firstElementChild,
      inputPlaceholder: this.element.lastElementChild.firstElementChild.nextElementSibling,
      expiryDate: null
    };
    this.stateClasses = {
      type: this.class.concat('--type')
    };
    this.sFields = null;
    this.listeners = {
      _labelClick: this._labelClick.bind(this),
      _sFieldsReady: this._sFieldsReady.bind(this),
      _sFieldsSuccess: this._sFieldsSuccess.bind(this),
      _sFieldsError: this._sFieldsError.bind(this),
      _sFieldsChange: this._sFieldsChange.bind(this),
      _sFieldsCardInfo: this._sFieldsCardInfo.bind(this)
    };
    this.options = options;
    this.events = events;
    this._build();
  }
  _labelClick(e) {
    this.sFields.focus('cardNumber');
  }
  _sFieldsCardInfo(data) {
    this.events.cardInfo(JSON.stringify(data));
  }
  _sFieldsChange(data) {
    if (this.options.includeExpiryDate && (data.event.type === 'touchstart' || data.event.type === 'focus')) {
      this.events.focus();
      return; // prevent the rest of the logic from running
    }
    this.element.classList.forEach(x => {
      if (x.startsWith(this.stateClasses.type)) {
        this.element.classList.remove(x);
      }
    });
    if (data.fields.cardNumber.paymentMethod !== undefined) {
      this.element.classList.add(this.stateClasses.type.concat('-available'), this.stateClasses.type.concat(`-${data.fields.cardNumber.paymentMethod.toLowerCase()}`));
    } else {
      data.fields.cardNumber.paymentMethod = '';
    }
    this.events.cardNumberChange(JSON.stringify(data.fields.cardNumber));
  }
  _sFieldsError(data) {
    this.events.error(data.error);
  }
  _sFieldsSuccess(data) {
    this.events.success(data.transactionId);
  }
  _sFieldsReady() {
    let paddingRight = this.options.includeExpiryDate ? '66px' : '8px';
    this.sFields.setStyle('cardNumber', `height:40px;border:1px solid #D9D9D9; color:#404040; background-color:#FFFFFF; font-size:16px; transition:all 200ms linear;border-radius:4px; padding:0 ${paddingRight} 0 34px;`);
    this.sFields.setStyle('cardNumber:focus', 'border-color:#7C7CE0');
    this.sFields.setStyle('cardNumber::placeholder', 'color:#D9D9D9');
    if (this.options.placeholder) {
      this.sFields.setPlaceholder('cardNumber', this.options.placeholder);
    }
  }
  _build() {
    this.sFields = new SecureFields();
    let styles = {
      "*": "font-family: TT Commons;",
      "@font-face": {
        "*": {
          fontFamily: "TT Commons",
          fontStyle: "normal",
          fontWeight: 400,
          src: "url('tt-commons-regular.otf') format('opentype')"
        }
      }
    };
    this.sFields.initTokenize(this.options.merchantId, {
      cardNumber: {
        placeholderElementId: this.elements.inputPlaceholder.id,
        inputType: 'tel'
      }
    }, {
      styles: styles
    });
    this.sFields.on('ready', this.listeners._sFieldsReady);
    this.sFields.on('success', this.listeners._sFieldsSuccess);
    this.sFields.on('change', this.listeners._sFieldsChange);
    this.sFields.on('error', this.listeners._sFieldsError);
    this.sFields.on("cardInfo", this.listeners._sFieldsCardInfo);
    if (this.elements.label) {
      this.elements.label.addEventListener('click', this.listeners._labelClick);
    }
    if (this.options.includeExpiryDate) {
      this.elements.expiryDate = this.element.querySelector('.month-year-input__input-wrapper [data-input]');
    }
  }
  expiryDateFocus() {
    if (this.elements.expiryDate) {
      this.elements.expiryDate.focus();
    }
  }
  getCardInfo() {
    this.sFields.getCardInfo();
  }
  submit() {
    this.sFields.submit();
  }
  parametersChanged(options) {
    this.options = options;
    this.options.errorMessage === '' ? this.sFields.setStyle('cardNumber', 'border-color:#D9D9D9') : this.sFields.setStyle('cardNumber', 'border-color:#FF6B6D');
  }
}