class customDropdownList {
  constructor(id, options, events) {
    this.class = 'custom-dropdown-list';
    this.element = document.getElementById(id);
    this.options = options;
    this.events = events;
    this.classes = {
      item: this.class.concat('__item'),
      subItem: this.class.concat('__sub-item')
    }
    this.stateClasses = {
      visible: {
        open: this.class.concat('--open')
      },
      hidden: {
        item: this.classes.item.concat('--hidden'),
        subItem: this.classes.subItem.concat('--hidden'),
      },
      search: {
        visible: this.class.concat('--search'),
        noSearchResults: this.class.concat('--no-search-results')
      },
      selected: {
        item: this.classes.item.concat('--selected'),
        subItem: this.classes.subItem.concat('--selected')
      },
      highlighted: {
        item: this.classes.item.concat('--highlighted'),
        subItem: this.classes.subItem.concat('--highlighted')
      },
      disabled: {
        item: this.classes.item.concat('--disabled'),
        subItem: this.classes.subItem.concat('--disabled')
      },
      groups: this.class.concat('--groups')
    };
    this.elements = {
      label: this.element.firstElementChild,
      content: this.element.firstElementChild.nextElementSibling,
      value: {
        element: this.element.firstElementChild.nextElementSibling.firstElementChild
      },
      dropdown: null,
      list: null,
      search: null,
      overlay: this.element.lastElementChild
    };
    this.items = [];
    this.itemSelected = null;
    this.itemHighlighted = {
      element: null,
      position: {
        item: -1,
        subItem: -1
      }
    };
    this.listeners = {
      _change: this._change.bind(this),
      _hover: this._hover.bind(this),
      _keydown: this._keydown.bind(this),
      _openKeydown: this._openKeydown.bind(this),
      _focus: this._focus.bind(this),
      _blur: this._blur.bind(this),
      _setHeight: this._setHeight.bind(this),
      _overlayClick: this._overlayClick.bind(this),
      _scrollReset: this._scrollReset.bind(this)
    };
    this.open = false;
    this._build();
  }
  _scrollReset() {
    window.scrollTo(0, 0);
    this.elements.overlay.scrollIntoView();
  }
  _setHeight() {
    if (this.elements.dropdown) {
      this.element.style.setProperty('--dropdown-height', this.elements.dropdown.offsetHeight + 'px');
    }
  }
  _getItemPosition(item) {
    let position = {
      item: -1,
      subItem: -1
    };
    if (item) {
      this.items.forEach((a, b) => {
        let itemPos = b;
        if (a.item === item) {
          position.item = b;
          position.subItem = -1;
          return;
        } else {
          a.subItems.forEach((a, b) => {
            if (a === item) {
              position.item = itemPos;
              position.subItem = b;
            }
          });
        }
      });
    }
    return position;
  }
  _scrollIntoView(el) {
    if (el && el.scrollIntoViewIfNeeded) {
      el.scrollIntoViewIfNeeded();
    }
  }
  _getFirstAvailableHighlighted() {
    let first = null;
    if (this.items) {
      let item = this.items.find(i => !i.item.classList.contains(this.stateClasses.disabled.item) && !i.item.classList.contains(this.stateClasses.hidden.item));
      if (item) {
        first = item.item;
      }
    }
    return first;
  }
  _setHighlighted(el) {
    let _getHighlightedClasses = () => {
      return this.itemHighlighted.element.classList.contains(this.classes.item) ? this.stateClasses.highlighted.item : this.stateClasses.highlighted.subItem;
    };
    let _resetHighlighted = () => {
      if (this.itemHighlighted.element) {
        this.itemHighlighted.element.classList.remove(_getHighlightedClasses());
      }
      this.itemHighlighted.element = null;
      this.itemHighlighted.position.item = -1;
      this.itemHighlighted.position.subItem = -1;
    };
    _resetHighlighted();
    if (el) {
      this.itemHighlighted.element = el;
      this.itemHighlighted.element.classList.add(_getHighlightedClasses());
      this.itemHighlighted.position = this._getItemPosition(this.itemHighlighted.element);
    } else {
      this.itemHighlighted.element = this.itemSelected || this._getFirstAvailableHighlighted();
      if (this.itemHighlighted.element) {
        this.itemHighlighted.element.classList.add(_getHighlightedClasses());
        this.itemHighlighted.position = this._getItemPosition(this.itemHighlighted.element);
      } else {
        _resetHighlighted();
      }
    }
    this._scrollIntoView(this.itemHighlighted.element);
  }
  _getSelected() {
    let selected = null;
    for (let i of this.items) {
      if (i.item.dataset.value === this.options.selected) {
        selected = i.item;
        return selected;
      } else {
        for (let s of i.subItems) {
          if (s.dataset.value === this.options.selected) {
            selected = s;
            return selected;
          }
        }
      }
    }
    return selected;
  }
  _getSelectItemsClasses() {
    return this.itemSelected.classList.contains(this.classes.item) ? this.stateClasses.selected.item : this.stateClasses.selected.subItem;
  }
  _resetSelection() {
    if (this.itemSelected) {
      this.itemSelected.classList.remove(this.stateClasses.selected.item);
    }
    this.itemSelected = null;
    this._setHighlighted();
  }
  _updateSelected(el) {
    el !== this.itemSelected ? this._setSelected(el) : this._resetSelection();
  }
  _setSelected(el) {
    if (el) {
      if (this.itemSelected) {
        this.itemSelected.classList.remove(this._getSelectItemsClasses());
      }
      this.itemSelected = el;
      this.itemSelected.classList.add(this._getSelectItemsClasses());
      this._setHighlighted(this.itemSelected);

    } else {
      this._resetSelection();
    }
    this._scrollIntoView(this.itemSelected);
  }
  _getChangeObj() {
    return JSON.stringify({
      text: this.itemSelected ? this.itemSelected.dataset.text : '',
      value: this.itemSelected ? this.itemSelected.dataset.value : this.options.nullValue
    });
  }
  _overlayClick(e) {
    this.events.toggle();
  }
  _change(e) {
    e.stopPropagation();
    this._updateSelected(e.currentTarget);
    this.events.change(this._getChangeObj());
    this.events.toggle();
  }
  _hover(e) {
    e.stopPropagation();
    this._setHighlighted(e.currentTarget);
  }
  _blur(e) {
    document.body.removeEventListener('keydown', this.listeners._openKeydown);
  }
  _focus(e) {
    document.body.addEventListener('keydown', this.listeners._openKeydown);
    document.body.addEventListener('blur', this.listeners._blur);
  }
  _setFocus() {
    this.elements.value.element.focus();
  }
  _goUp() {
    let _getLastAvailableHighlighted = () => {
      let last = null;
      if (this.items) {
        let item = this.items.reverse().find(i => !i.item.classList.contains(this.stateClasses.disabled.item) && !i.item.classList.contains(this.stateClasses.hidden.item));
        this.items.reverse();
        if (item) {
          if (item.subItems.length) {
            let subItem = item.subItems.reverse().find(i => !i.classList.contains(this.stateClasses.disabled.subItem) && !i.classList.contains(this.stateClasses.hidden.subItem));
            item.subItems.reverse();
            last = subItem ? subItem : item.item;
          } else {
            last = item.item;
          }
        }
      }
      return last;
    }
    let _previous = () => {
      let item = this.items[this.itemHighlighted.position.item],
        previous = null;
      //Search next available option on current item
      if (item.subItems.length !== 0 && this.itemHighlighted.position.subItem > -1) {
        if (this.itemHighlighted.position.subItem > 0) {
          previous = item.subItems.reverse().find((el, i, a) => i >= a.length - this.itemHighlighted.position.subItem && !el.classList.contains(this.stateClasses.disabled.subItem) && !el.classList.contains(this.stateClasses.hidden.subItem));
          previous = previous || null;
          item.subItems.reverse();
        } else {
          previous = item.item;
        }
      }
      //Search next available option on previous item
      if (previous === null) {
        let prevItem = this.items.reverse().find((el, i, a) => i >= a.length - this.itemHighlighted.position.item && !el.item.classList.contains(this.stateClasses.disabled.item) && !el.item.classList.contains(this.stateClasses.hidden.item));
        this.items.reverse();
        if (prevItem) {
          if (prevItem.subItems.length === 0) {
            previous = prevItem.item;
          } else {
            let prevSubItem = prevItem.subItems.reverse().find((el, i) => !el.classList.contains(this.stateClasses.disabled.subItem) && !el.classList.contains(this.stateClasses.hidden.subItem));
            prevItem.subItems.reverse();
            previous = prevSubItem;
          }
        } else {
          previous = _getLastAvailableHighlighted();
        }
      }
      return previous;
    };
    this._setHighlighted(_previous());
  }
  _goDown() {
    let _nextSubItem = () => {
      return this.items[this.itemHighlighted.position.item].subItems.length === 0 ? null : this.items[this.itemHighlighted.position.item].subItems.find((el, i) => i > this.itemHighlighted.position.subItem && !el.classList.contains(this.stateClasses.disabled.subItem));
    };
    let _nextItem = () => {
      let item = this.items.find((el, i) => i > this.itemHighlighted.position.item && !el.item.classList.contains(this.stateClasses.disabled.item) && !el.item.classList.contains(this.stateClasses.hidden.item));
      return item ? item.item : null;
    }
    this._setHighlighted(_nextSubItem() || _nextItem() || this._getFirstAvailableHighlighted());
  }
  _keydown(e) {
    switch (e.key) {
      case 'Enter':
        this._updateSelected(this.itemHighlighted.element);
        this.events.change(this._getChangeObj());
        this.events.toggle();
        e.preventDefault();
        e.stopPropagation();
        break;
      case 'ArrowDown':
        this._goDown();
        e.preventDefault();
        e.stopPropagation();
        break;
      case 'ArrowUp':
        this._goUp();
        e.preventDefault();
        e.stopPropagation();
        break;
      case 'Tab':
        this.events.toggle();
        e.stopPropagation();
        break;
      case 'Escape':
        this.events.toggle();
        this._setFocus();
        e.stopPropagation();
        e.preventDefault();
        break;
    }
  }
  _openKeydown(e) {
    if (e.key === 'ArrowDown') {
      this.events.toggle();
      e.stopPropagation();
      e.preventDefault();
      document.body.removeEventListener('keydown', this.listeners._openKeydown);
    }
  }
  _searchFocus() {
    if (this.elements.search) {
      this.elements.search.focus();
    }
  }
  _setItemsListeners() {
    this.items.forEach(i => {
      i.item.removeEventListener('click', this.listeners._change);
      i.item.removeEventListener('mouseover', this.listeners._hover);
      if (!i.item.classList.contains(this.stateClasses.disabled.item)) {
        i.item.addEventListener('click', this.listeners._change);
        i.item.addEventListener('mouseover', this.listeners._hover);
      }
      i.subItems.forEach(s => {
        s.removeEventListener('click', this.listeners._change);
        s.removeEventListener('mouseover', this.listeners._hover);
        s.addEventListener('click', this.listeners._change);
        s.addEventListener('mouseover', this.listeners._hover);
      });
    });
  }
  _hasGroups() {
    return this.items ? this.items.some(x => x.subItems.length > 0) : false;
  }
  _setItems() {
    let groups = this.elements.list.getElementsByClassName(this.classes.item),
      items = [];
    if (groups) {
      items = Array.from(groups).flatMap(i => [{
        item: i,
        subItems: Array.from(i.getElementsByClassName(this.classes.subItem))
      }]);
    }
    this.items = items;
    this._hasGroups() ? this.element.classList.add(this.stateClasses.groups) : this.element.classList.remove(this.stateClasses.groups)
    this._setSelected(this._getSelected());
  }
  _setDropdown() {
    this.elements.dropdown = this.element.getElementsByClassName(this.class.concat('__dropdown'))[0];
    if (this.elements.dropdown) {
      this.elements.list = this.elements.dropdown.lastElementChild.previousElementSibling;
      this.elements.search = this.elements.dropdown.firstElementChild.nextElementSibling.firstElementChild.firstElementChild;
      this._setItems();
      if (this.open) {
        setTimeout(this.listeners._setHeight, 0);
        this._setItemsListeners();
        if (this.items.length >= 12) {
          this.element.classList.add(this.stateClasses.search.visible);
          this.search(this.elements.search.value);
          this._searchFocus();
        } else {
          this.element.classList.remove(this.stateClasses.search.visible);
        }
      }
    } else {
      this.elements.list = null;
      this.elements.search = null;
    }

  }
  _build() {
    this.elements.value.element.addEventListener('focus', this.listeners._focus);
    this.elements.overlay.addEventListener('click', this.listeners._overlayClick);
    if (this.options.testId) {
      this.elements.label.setAttribute('data-testid', this.options.testId.concat('Label'));
      if (this.elements.value.element) {
        this.elements.value.element.setAttribute('data-testid', this.options.testId.concat('Value'));
      }
    }
  }
  dropdownRendered() {
    this._setDropdown();
    this.element.classList.add(this.stateClasses.visible.open);
  }
  search(s) {
    if (!this.options.search.hide) {
      var hideAll = true;
      this.items.forEach(i => {
        if (i.subItems.some(subItem => subItem.dataset.text.toLowerCase().includes(s.toLowerCase()))) {
          i.item.classList.remove(this.stateClasses.hidden.item);
          hideAll = false;
        } else {
          if (i.item.dataset.text.toLowerCase().includes(s.toLowerCase())) {
            i.item.classList.remove(this.stateClasses.hidden.item);
            hideAll = false;
          } else {
            i.item.classList.add(this.stateClasses.hidden.item);
          }
        }
        if (!i.item.classList.contains(this.stateClasses.hidden.item) && !i.item.dataset.text.toLowerCase().includes(s.toLowerCase())) {
          i.subItems.forEach(subItem => {
            if (subItem.dataset.text.toLowerCase().includes(s.toLowerCase())) {
              subItem.classList.remove(this.stateClasses.hidden.subItem);
              hideAll = false;
            } else {
              subItem.classList.add(this.stateClasses.hidden.subItem);
            }
          });
        } else {
          i.subItems.forEach(subItem => subItem.classList.remove(this.stateClasses.hidden.subItem));
        }
      });
      hideAll ? this.element.classList.add(this.stateClasses.search.noSearchResults) : this.element.classList.remove(this.stateClasses.search.noSearchResults);
      this._setHighlighted();
    }
  }
  toggle() {
    this.open = !this.open;
    if (this.open) {
      document.body.addEventListener('keydown', this.listeners._keydown);
      document.body.removeEventListener('keydown', this.listeners._openKeydown);
      setTimeout(this.listeners._scrollReset, 400);
    } else {
      this.element.classList.remove(this.stateClasses.visible.open);
      document.body.removeEventListener('keydown', this.listeners._keydown);
      setTimeout(this.events.close, 200);
    }
    return this.open;
  }
  render() {
    this._setDropdown();
  }
  parametersChanged(options) {
    this.options = options;
  }
}