define("ShopperPortalEU_CS.referencesHealth$FrameworkUtils", [], function () {
// Reference to producer 'FrameworkUtils' is OK.
});
define("ShopperPortalEU_CS.referencesHealth$ShopperPortalEU_UI_Components", [], function () {
// Reference to producer 'ShopperPortalEU_UI_Components' is OK.
});
define("ShopperPortalEU_CS.referencesHealth$Users", [], function () {
// Reference to producer 'Users' is OK.
});
define("ShopperPortalEU_CS.referencesHealth", [], function () {
});
