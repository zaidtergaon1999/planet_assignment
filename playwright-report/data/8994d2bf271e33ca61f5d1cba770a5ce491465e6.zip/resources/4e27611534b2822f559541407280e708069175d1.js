define("ShopperPortalEU.LayoutsComponents.BottomBar.mvc$model", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU_UI_Theme.model", "Auth_Europe.model", "Auth_Europe.controller", "ShopperPortalEU_UI_Theme.ShopperPortalEUUIThemeLayoutsComponents.BottomBar.mvc$model", "ShopperPortalEU_UI_Theme.ShopperPortalEUUIThemeLayoutsComponents.BottomBarItem.mvc$model", "ShopperPortalEU_UI_Theme.model$BottomBarOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$BottomBarItemOptionsRec", "Auth_Europe.model$AccessInfoRec", "ShopperPortalEU.referencesHealth$Auth_Europe", "Auth_Europe.controller$IsAuthenticated"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEU_UI_ThemeModel, Auth_EuropeModel, Auth_EuropeController, ShopperPortalEU_UI_Theme_ShopperPortalEUUIThemeLayoutsComponents_BottomBar_mvcModel, ShopperPortalEU_UI_Theme_ShopperPortalEUUIThemeLayoutsComponents_BottomBarItem_mvcModel) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("ShowBottomBar", "showBottomBarVar", "ShowBottomBar", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("Options", "optionsIn", "Options", true, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ThemeModel.BottomBarOptionsRec());
}, false, ShopperPortalEU_UI_ThemeModel.BottomBarOptionsRec), 
this.attr("_optionsInDataFetchStatus", "_optionsInDataFetchStatus", "_optionsInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Model._hasValidationWidgetsValue = undefined;
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
if((Model._hasValidationWidgetsValue === undefined)) {
Model._hasValidationWidgetsValue = (ShopperPortalEU_UI_Theme_ShopperPortalEUUIThemeLayoutsComponents_BottomBar_mvcModel.hasValidationWidgets || ShopperPortalEU_UI_Theme_ShopperPortalEUUIThemeLayoutsComponents_BottomBarItem_mvcModel.hasValidationWidgets);
}

return Model._hasValidationWidgetsValue;
}
});

Model.prototype.setInputs = function (inputs) {
if("Options" in inputs) {
this.variables.optionsIn = inputs.Options;
if("_optionsInDataFetchStatus" in inputs) {
this.variables._optionsInDataFetchStatus = inputs._optionsInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "LayoutsComponents.BottomBar");
});
define("ShopperPortalEU.LayoutsComponents.BottomBar.mvc$view", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Theme.model", "Auth_Europe.model", "Auth_Europe.controller", "react", "OutSystems/ReactView/Main", "ShopperPortalEU.LayoutsComponents.BottomBar.mvc$model", "ShopperPortalEU.LayoutsComponents.BottomBar.mvc$controller", "ShopperPortalEU.clientVariables", "ShopperPortalEU_UI_Theme.ShopperPortalEUUIThemeLayoutsComponents.BottomBar.mvc$view", "OutSystems/ReactWidgets/Main", "ShopperPortalEU_UI_Theme.ShopperPortalEUUIThemeLayoutsComponents.BottomBarItem.mvc$view", "ShopperPortalEU_UI_Theme.model$BottomBarOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$BottomBarItemOptionsRec", "Auth_Europe.model$AccessInfoRec", "ShopperPortalEU.referencesHealth$Auth_Europe", "Auth_Europe.controller$IsAuthenticated"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_UI_ThemeModel, Auth_EuropeModel, Auth_EuropeController, React, OSView, ShopperPortalEU_LayoutsComponents_BottomBar_mvc_model, ShopperPortalEU_LayoutsComponents_BottomBar_mvc_controller, ShopperPortalEUClientVariables, ShopperPortalEU_UI_Theme_ShopperPortalEUUIThemeLayoutsComponents_BottomBar_mvc_view, OSWidgets, ShopperPortalEU_UI_Theme_ShopperPortalEUUIThemeLayoutsComponents_BottomBarItem_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            var thisIsInstanceOfSuper = this instanceof _super;
            if (thisIsInstanceOfSuper == false) {
                return;
            }

            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "LayoutsComponents.BottomBar";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [ShopperPortalEU_UI_Theme_ShopperPortalEUUIThemeLayoutsComponents_BottomBar_mvc_view, ShopperPortalEU_UI_Theme_ShopperPortalEUUIThemeLayoutsComponents_BottomBarItem_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return ShopperPortalEU_LayoutsComponents_BottomBar_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return ShopperPortalEU_LayoutsComponents_BottomBar_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), $if(model.variables.showBottomBarVar, false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Theme_ShopperPortalEUUIThemeLayoutsComponents_BottomBar_mvc_view, {
inputs: {
Options: model.variables.optionsIn,
_optionsInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._optionsInDataFetchStatus)
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "0",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
items: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Link, {
enabled: true,
extendedProperties: {
"data-testid": "MyRefunds"
},
transition: OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default),
url: OS.Navigation.generateScreenURL("ShopperPortalEU", "MyRefunds", {}),
visible: true,
_idProps: {
service: idService,
uuid: "1"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Theme_ShopperPortalEUUIThemeLayoutsComponents_BottomBarItem_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("6BY03IC16k2U6E4NzeU2mQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ThemeModel.BottomBarItemOptionsRec();
rec.iconAttr = "receipt";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "2",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
title: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "My refunds",
_idProps: {
service: idService,
uuid: "3"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
})), React.createElement(OSWidgets.Link, {
enabled: true,
extendedProperties: {
"data-testid": "Locations"
},
transition: OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default),
url: OS.Navigation.generateScreenURL("ShopperPortalEU", "Locations", {}),
visible: true,
_idProps: {
service: idService,
uuid: "4"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Theme_ShopperPortalEUUIThemeLayoutsComponents_BottomBarItem_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("EekQnDMCs0mp+LnEDHa41g.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ThemeModel.BottomBarItemOptionsRec();
rec.iconAttr = "pin_drop";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "5",
alias: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
title: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Locations",
_idProps: {
service: idService,
uuid: "6"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
})), React.createElement(OSWidgets.Link, {
enabled: true,
extendedProperties: {
"data-testid": "CountryRules"
},
transition: OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default),
url: OS.Navigation.generateScreenURL("ShopperPortalEU", "CountryRules", {}),
visible: true,
_idProps: {
service: idService,
name: "LocalRules"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Theme_ShopperPortalEUUIThemeLayoutsComponents_BottomBarItem_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("iYLRTRnye0qwx2YVNgIGpQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ThemeModel.BottomBarItemOptionsRec();
rec.iconAttr = "local_library";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "8",
alias: "4"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
title: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "CountryRules"
},
value: "Country rules",
_idProps: {
service: idService,
uuid: "9"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
})), React.createElement(OSWidgets.Link, {
enabled: true,
extendedProperties: {
"data-testid": "Help"
},
transition: OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default),
url: OS.Navigation.generateScreenURL("ShopperPortalEU", "Help", {}),
visible: true,
_idProps: {
service: idService,
uuid: "10"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Theme_ShopperPortalEUUIThemeLayoutsComponents_BottomBarItem_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("VVEM0jIjWUSDFeji5mXMGA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ThemeModel.BottomBarItemOptionsRec();
rec.iconAttr = "help";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "11",
alias: "5"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
title: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "Help"
},
value: "Help",
_idProps: {
service: idService,
uuid: "12"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
})];
}, function () {
return [];
}));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("ShopperPortalEU.LayoutsComponents.BottomBar.mvc$controller", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Theme.model", "Auth_Europe.model", "Auth_Europe.controller", "ShopperPortalEU.languageResources", "ShopperPortalEU.clientVariables", "ShopperPortalEU.LayoutsComponents.BottomBar.mvc$debugger", "ShopperPortalEU_UI_Theme.model$BottomBarOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$BottomBarItemOptionsRec", "Auth_Europe.model$AccessInfoRec", "ShopperPortalEU.referencesHealth$Auth_Europe", "Auth_Europe.controller$IsAuthenticated"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_UI_ThemeModel, Auth_EuropeModel, Auth_EuropeController, ShopperPortalEULanguageResources, ShopperPortalEUClientVariables, ShopperPortalEU_LayoutsComponents_BottomBar_mvc_Debugger) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = true;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._onReady$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnReady");
callContext = controller.callContext(callContext);
var isAuthenticatedVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.isAuthenticatedVar = isAuthenticatedVar;
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:lBFgvukLBUOV2fpO6TFgsw:/NRWebFlows.L_YboVe7KUC5K0uH_jh6qw/NodesShownInESpaceTree.rUtENRStOEy9AmCVTWtHTw/ClientActions.lBFgvukLBUOV2fpO6TFgsw:KX8qE_kBcA9idIUZ0S4nFw", "ShopperPortalEU", "OnReady", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:oqsUCWn4tEKdlpVs2ZuVCw", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:7sJSvox6c0KX8LNP8VJTdw", callContext.id);
// Execute Action: IsAuthenticated
model.flush();
return Auth_EuropeController.default.isAuthenticated$Action(callContext).then(function (value) {
isAuthenticatedVar.value = value;
}).then(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ABw8vn_SK0+2TYWDDor51Q", callContext.id);
// Trigger Event: ScreenReady
return controller.screenReady$Action(callContext);
}).then(function () {
// ShowBottomBar
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:khmqYNWFd0CIQfG7BTQhpw", callContext.id);
// ShowBottomBar = If
model.variables.showBottomBarVar = ((isAuthenticatedVar.value.isAuthenticatedOut) ? (true) : (false));
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:nVKzhQd+vkKw67I_dtMcCA", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:lBFgvukLBUOV2fpO6TFgsw", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:lBFgvukLBUOV2fpO6TFgsw", callContext.id);
throw ex;

});
};

Controller.prototype.onReady$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onReady$Action, callContext);

};
Controller.prototype.screenReady$Action = function () {
return Promise.resolve();
};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:L_YboVe7KUC5K0uH_jh6qw:/NRWebFlows.L_YboVe7KUC5K0uH_jh6qw:7M96ALC1q_CnwlpVX8Rm0w", "ShopperPortalEU", "LayoutsComponents", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:rUtENRStOEy9AmCVTWtHTw:/NRWebFlows.L_YboVe7KUC5K0uH_jh6qw/NodesShownInESpaceTree.rUtENRStOEy9AmCVTWtHTw:s8us888TTY3VQelF0ndEzg", "ShopperPortalEU", "BottomBar", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:rUtENRStOEy9AmCVTWtHTw", callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:L_YboVe7KUC5K0uH_jh6qw", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "LayoutsComponents/BottomBar On Ready");
return controller.onReady$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return ShopperPortalEUController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, ShopperPortalEULanguageResources);
});

define("ShopperPortalEU.LayoutsComponents.BottomBar.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"7sJSvox6c0KX8LNP8VJTdw": {
getter: function (varBag, idService) {
return varBag.isAuthenticatedVar.value;
}
},
"2VsjUFodikOB6sP+AlJXpA": {
getter: function (varBag, idService) {
return varBag.model.variables.showBottomBarVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"G2n6G2TNbUqFt6hi3J+0lg": {
getter: function (varBag, idService) {
return varBag.model.variables.optionsIn;
}
},
"I+Ie5yQnAE+cSZ+KE1+8iA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Items"));
})(varBag.model, idService);
}
},
"pga1loDYC0qZP6aMVJUh0g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"0RgvliXZYkaLet5EChUIeQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"Lt2zoKIX8UikWvU+Z04JyA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("LocalRules"));
})(varBag.model, idService);
}
},
"Jzyxplc0kEWGu2UKEqnYMw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"LzJWsANsG02QUeViZKMfpg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
