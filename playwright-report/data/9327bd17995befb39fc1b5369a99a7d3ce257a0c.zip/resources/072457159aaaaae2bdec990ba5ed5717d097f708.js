define("ShopperPortalEU_Shopper_IS.referencesHealth$Auth_Europe", [], function () {
// Reference to producer 'Auth_Europe' is OK.
});
define("ShopperPortalEU_Shopper_IS.referencesHealth$ServiceCenter", [], function () {
// Reference to producer 'ServiceCenter' is OK.
});
define("ShopperPortalEU_Shopper_IS.referencesHealth$Users", [], function () {
// Reference to producer 'Users' is OK.
});
define("ShopperPortalEU_Shopper_IS.referencesHealth", [], function () {
});
