class menu {
  constructor(id, options) {
    this.element = document.getElementById(id);
    this.class = 'menu';
    this.elementsClasses = {
      menuElement: 'menu__element'
    };
    this.stateClasses = {
      menuElementActive: this.elementsClasses.menuElement.concat('--active')
    };
    this.active = null;
    this.options = options;
  }
  _setProps() {
    let items = this.element.getElementsByClassName(this.elementsClasses.menuElement);
    for (let i = 0; i < items.length; i++) {
      let el = items[i].querySelector('a') || items[i].querySelector('button');
      if (el) {
        el.setAttribute('role', 'menuitem');
        if (this.options.activeMenu === -1 && el.href === window.location.href) {
          if (this.active != null) {
            this.active.classList.remove(this.stateClasses.menuElementActive);
          }
          this.active = items[i];
          if (this.active) {
            this.active.classList.add(this.stateClasses.menuElementActive);
          }
        }
      }
    }
    if (this.options.activeMenu > -1) {
      if (this.active != null) {
        this.active.classList.remove(this.stateClasses.menuElementActive);
      }
      this.active = items[this.options.activeMenu];
      if (this.active) {
        this.active.classList.add(this.stateClasses.menuElementActive);
      }
    }
  }
  toggle() {
    document.body.classList.toggle('body--menu-open');
  }
  parametersChanged(options) {
    this.options = options;
  }
  render() {
    this._setProps();
  }
}