class cardExpandable {
  constructor(id, options, events) {
    this.class = 'card-expandable';
    this.stateClasses = {
      expanded: this.class.concat('--expanded')
    };
    this.element = document.getElementById(id);
    this.elements = {
      header: this.element.firstElementChild
    };
    this.listeners = {
      toggle: this.toggle.bind(this)
    };
    this.options = options;
    this.events = events;
    this.expanded = this.options.expanded;
    this._build();
  }
  _build() {
    if (!this.options.expandedDisabled) {
      this.elements.header.addEventListener('click', this.listeners.toggle);
    }
  }
  toggle() {
    this.expanded = this.element.classList.toggle(this.stateClasses.expanded);
    this.events.toggle();
  }
  parametersChanged(options) {
    this.options = options;
    this.expanded = this.options.expanded;
    this.elements.header.removeEventListener('click', this.listeners.toggle);
    if (!this.options.expandedDisabled) {
      this.elements.header.addEventListener('click', this.listeners.toggle);
    }
  }
}