define("ShopperPortalEU.InternalComponents.RefundPaymentDetails_WB.mvc$model", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_API.model", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCard.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomColumns.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.Flex.mvc$model", "ShopperPortalEU.controller$FormatDate", "ShopperPortalEU_API.model$RefundDetails_WrapperRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_API", "ShopperPortalEU_Forms_IS.model$RefundDetailsPaymentDetails_UIRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Forms_IS", "ShopperPortalEU_UI_Components.model$CustomCardOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$CustomColumnsOptionsRec", "ShopperPortalEU_UI_Components.model$FlexOptionsRec"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_APIModel, ShopperPortalEU_Forms_ISModel, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCard_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomColumns_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvcModel) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("RefundDetails", "refundDetailsIn", "RefundDetails", true, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_APIModel.RefundDetails_WrapperRec());
}, false, ShopperPortalEU_APIModel.RefundDetails_WrapperRec), 
this.attr("_refundDetailsInDataFetchStatus", "_refundDetailsInDataFetchStatus", "_refundDetailsInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("RefundDetailsPaymentDetails_UI", "refundDetailsPaymentDetails_UIIn", "RefundDetailsPaymentDetails_UI", true, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Forms_ISModel.RefundDetailsPaymentDetails_UIRec());
}, false, ShopperPortalEU_Forms_ISModel.RefundDetailsPaymentDetails_UIRec), 
this.attr("_refundDetailsPaymentDetails_UIInDataFetchStatus", "_refundDetailsPaymentDetails_UIInDataFetchStatus", "_refundDetailsPaymentDetails_UIInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Model._hasValidationWidgetsValue = undefined;
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
if((Model._hasValidationWidgetsValue === undefined)) {
Model._hasValidationWidgetsValue = ((ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCard_mvcModel.hasValidationWidgets || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomColumns_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvcModel.hasValidationWidgets);
}

return Model._hasValidationWidgetsValue;
}
});

Model.prototype.setInputs = function (inputs) {
if("RefundDetails" in inputs) {
this.variables.refundDetailsIn = inputs.RefundDetails;
if("_refundDetailsInDataFetchStatus" in inputs) {
this.variables._refundDetailsInDataFetchStatus = inputs._refundDetailsInDataFetchStatus;
}

}

if("RefundDetailsPaymentDetails_UI" in inputs) {
this.variables.refundDetailsPaymentDetails_UIIn = inputs.RefundDetailsPaymentDetails_UI;
if("_refundDetailsPaymentDetails_UIInDataFetchStatus" in inputs) {
this.variables._refundDetailsPaymentDetails_UIInDataFetchStatus = inputs._refundDetailsPaymentDetails_UIInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "InternalComponents.RefundPaymentDetails_WB");
});
define("ShopperPortalEU.InternalComponents.RefundPaymentDetails_WB.mvc$view", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_API.model", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_UI_Components.model", "react", "OutSystems/ReactView/Main", "ShopperPortalEU.InternalComponents.RefundPaymentDetails_WB.mvc$model", "ShopperPortalEU.InternalComponents.RefundPaymentDetails_WB.mvc$controller", "ShopperPortalEU.clientVariables", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCard.mvc$view", "OutSystems/ReactWidgets/Main", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomColumns.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.Flex.mvc$view", "ShopperPortalEU.controller$FormatDate", "ShopperPortalEU_API.model$RefundDetails_WrapperRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_API", "ShopperPortalEU_Forms_IS.model$RefundDetailsPaymentDetails_UIRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Forms_IS", "ShopperPortalEU_UI_Components.model$CustomCardOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$CustomColumnsOptionsRec", "ShopperPortalEU_UI_Components.model$FlexOptionsRec"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_APIModel, ShopperPortalEU_Forms_ISModel, ShopperPortalEU_UI_ComponentsModel, React, OSView, ShopperPortalEU_InternalComponents_RefundPaymentDetails_WB_mvc_model, ShopperPortalEU_InternalComponents_RefundPaymentDetails_WB_mvc_controller, ShopperPortalEUClientVariables, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCard_mvc_view, OSWidgets, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomColumns_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            var thisIsInstanceOfSuper = this instanceof _super;
            if (thisIsInstanceOfSuper == false) {
                return;
            }

            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "InternalComponents.RefundPaymentDetails_WB";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCard_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomColumns_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return ShopperPortalEU_InternalComponents_RefundPaymentDetails_WB_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return ShopperPortalEU_InternalComponents_RefundPaymentDetails_WB_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCard_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "0",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomColumns_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("VOBeflegFUW7j1qE+qSDiw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomColumnsOptionsRec();
rec.columnsAttr = 1;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "1",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [$if((((model.variables.refundDetailsPaymentDetails_UIIn.displayPaidOn_UIAttr && !(model.variables.refundDetailsIn.paidOnAttr.equals(OS.BuiltinFunctions.nullDate()))) || (model.variables.refundDetailsPaymentDetails_UIIn.displayLocation_UIAttr && ((model.variables.refundDetailsIn.locationAttr) !== ("")))) || (model.variables.refundDetailsPaymentDetails_UIIn.displayMethod_UIAttr && ((model.variables.refundDetailsIn.paymentTypeAttr) !== ("")))), false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "2"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "heading6 text-primary-grey",
visible: true,
_idProps: {
service: idService,
uuid: "3"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "RefundDetails_RefundPaymentDetails_Title"
},
value: "Refund payment details",
_idProps: {
service: idService,
uuid: "4"
},
_widgetRecordProvider: widgetsRecordProvider
})), $if((model.variables.refundDetailsPaymentDetails_UIIn.displayPaidOn_UIAttr && !(model.variables.refundDetailsIn.paidOnAttr.equals(OS.BuiltinFunctions.nullDate()))), false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
ExtendedClass: "margin-top-02",
Options: model.getCachedValue(idService.getId("q+AjVZzxOUC7TAlWE1UBMA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.justifyAttr = ShopperPortalEUModel.staticEntities.flexJustify.spaceBetween;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
rec.wrapAttr = false;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "5",
alias: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "RefundDetails_RefundPaymentDetails_PaidOn_Label"
},
style: "white-space-no-wrap text-primary-35",
value: "Paid on:",
_idProps: {
service: idService,
uuid: "6"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "text-align-right",
visible: true,
_idProps: {
service: idService,
uuid: "7"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "RefundDetails_RefundPaymentDetails_PaidOn_Label_Value"
},
style: "white-space-no-wrap text-primary-35",
value: model.getCachedValue(idService.getId("FlurtBAjqkyzlNVf0CVb9w.Value"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.formatDate$Action(OS.BuiltinFunctions.dateTimeToDate(model.variables.refundDetailsIn.paidOnAttr), callContext).formattedDateOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
}, function () {
return model.variables.refundDetailsIn.paidOnAttr;
}),
_idProps: {
service: idService,
uuid: "8"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._refundDetailsInDataFetchStatus)
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables._refundDetailsInDataFetchStatus), asPrimitiveValue(model.variables.refundDetailsIn.paidOnAttr)]
})];
}, function () {
return [];
}), $if((model.variables.refundDetailsPaymentDetails_UIIn.displayLocation_UIAttr && ((model.variables.refundDetailsIn.locationAttr) !== (""))), false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("11C5EbRudkelDOg40A_Uww.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.justifyAttr = ShopperPortalEUModel.staticEntities.flexJustify.spaceBetween;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
rec.wrapAttr = false;
return rec;
}();
}),
ExtendedClass: "margin-top-02"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "9",
alias: "4"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "RefundDetails_RefundPaymentDetails_Location_Label"
},
style: "white-space-no-wrap text-primary-35",
value: "Location:",
_idProps: {
service: idService,
uuid: "10"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "text-align-right",
visible: true,
_idProps: {
service: idService,
uuid: "11"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "RefundDetails_RefundPaymentDetails_Location_Value"
},
style: "text-primary-35",
value: model.variables.refundDetailsIn.locationAttr,
_idProps: {
service: idService,
uuid: "12"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._refundDetailsInDataFetchStatus)
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables._refundDetailsInDataFetchStatus), asPrimitiveValue(model.variables.refundDetailsIn.locationAttr)]
})];
}, function () {
return [];
}), $if((model.variables.refundDetailsPaymentDetails_UIIn.displayMethod_UIAttr && ((model.variables.refundDetailsIn.paymentTypeAttr) !== (""))), false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
ExtendedClass: "margin-top-02",
Options: model.getCachedValue(idService.getId("2RqExlIa9EyZK32Zv0Fm1A.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.justifyAttr = ShopperPortalEUModel.staticEntities.flexJustify.spaceBetween;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
rec.wrapAttr = false;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "13",
alias: "5"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "RefundDetails_RefundPaymentDetails_Method_Label"
},
style: "white-space-no-wrap text-primary-35",
value: "Method:",
_idProps: {
service: idService,
uuid: "14"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "text-align-right",
visible: true,
_idProps: {
service: idService,
uuid: "15"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "RefundDetails_RefundPaymentDetails_Method_Value"
},
style: "white-space-no-wrap text-primary-35",
value: model.variables.refundDetailsIn.paymentTypeAttr,
_idProps: {
service: idService,
uuid: "16"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._refundDetailsInDataFetchStatus)
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables._refundDetailsInDataFetchStatus), asPrimitiveValue(model.variables.refundDetailsIn.paymentTypeAttr)]
})];
}, function () {
return [];
}))];
}, function () {
return [];
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("cLC92kwqqkiCAO1XkvYmcw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.justifyAttr = ShopperPortalEUModel.staticEntities.flexJustify.spaceBetween;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
rec.wrapAttr = false;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "17",
alias: "6"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "RefundDetails_RefundPaymentDetails_CardNumberAccount_Label"
},
style: "white-space-no-wrap text-primary-35",
value: model.getCachedValue(idService.getId("KUw2UD_hmEqPEjsI0om_Sg.Value"), function () {
return (((OS.BuiltinFunctions.toLower(model.variables.refundDetailsIn.paymentTypeAttr) === "card")) ? ("Card number:") : ("Account:"));
}, function () {
return model.variables.refundDetailsIn.paymentTypeAttr;
}),
_idProps: {
service: idService,
uuid: "18"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._refundDetailsInDataFetchStatus)
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "text-align-right",
visible: true,
_idProps: {
service: idService,
uuid: "19"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "RefundDetails_RefundPaymentDetails_CardNumberAccount_Value"
},
style: "white-space-no-wrap text-primary-35",
value: model.variables.refundDetailsIn.paymentAccountAttr,
_idProps: {
service: idService,
uuid: "20"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._refundDetailsInDataFetchStatus)
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables._refundDetailsInDataFetchStatus), asPrimitiveValue(model.variables.refundDetailsIn.paymentAccountAttr), asPrimitiveValue(model.variables.refundDetailsIn.paymentTypeAttr)]
}), $if((model.variables.refundDetailsPaymentDetails_UIIn.displayARN_UIAttr && ((model.variables.refundDetailsIn.acquirerRefAttr) !== (""))), false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("e02ym517e0SiRM+00rbq+A.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.justifyAttr = ShopperPortalEUModel.staticEntities.flexJustify.spaceBetween;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
rec.wrapAttr = false;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "21",
alias: "7"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "RefundDetails_RefundPaymentDetails_ARN_Label"
},
style: "white-space-no-wrap text-primary-35",
value: "Acquirer reference (ARN):",
_idProps: {
service: idService,
uuid: "22"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "text-align-right",
visible: true,
_idProps: {
service: idService,
uuid: "23"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "RefundDetails_RefundPaymentDetails_ARN_Value"
},
style: "white-space-no-wrap text-primary-35",
value: model.variables.refundDetailsIn.acquirerRefAttr,
_idProps: {
service: idService,
uuid: "24"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._refundDetailsInDataFetchStatus)
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables._refundDetailsInDataFetchStatus), asPrimitiveValue(model.variables.refundDetailsIn.acquirerRefAttr)]
})];
}, function () {
return [];
})];
})
},
_dependencies: [asPrimitiveValue(model.variables._refundDetailsInDataFetchStatus), asPrimitiveValue(model.variables._refundDetailsPaymentDetails_UIInDataFetchStatus), asPrimitiveValue(model.variables.refundDetailsIn.acquirerRefAttr), asPrimitiveValue(model.variables.refundDetailsIn.paymentAccountAttr), asPrimitiveValue(model.variables.refundDetailsIn.paymentTypeAttr), asPrimitiveValue(model.variables.refundDetailsIn.locationAttr), asPrimitiveValue(model.variables.refundDetailsIn.paidOnAttr), asPrimitiveValue(model.variables.refundDetailsPaymentDetails_UIIn.displayARN_UIAttr), asPrimitiveValue(model.variables.refundDetailsPaymentDetails_UIIn.displayMethod_UIAttr), asPrimitiveValue(model.variables.refundDetailsPaymentDetails_UIIn.displayLocation_UIAttr), asPrimitiveValue(model.variables.refundDetailsPaymentDetails_UIIn.displayPaidOn_UIAttr)]
})];
})
},
_dependencies: [asPrimitiveValue(model.variables._refundDetailsInDataFetchStatus), asPrimitiveValue(model.variables._refundDetailsPaymentDetails_UIInDataFetchStatus), asPrimitiveValue(model.variables.refundDetailsIn.acquirerRefAttr), asPrimitiveValue(model.variables.refundDetailsIn.paymentAccountAttr), asPrimitiveValue(model.variables.refundDetailsIn.paymentTypeAttr), asPrimitiveValue(model.variables.refundDetailsIn.locationAttr), asPrimitiveValue(model.variables.refundDetailsIn.paidOnAttr), asPrimitiveValue(model.variables.refundDetailsPaymentDetails_UIIn.displayARN_UIAttr), asPrimitiveValue(model.variables.refundDetailsPaymentDetails_UIIn.displayMethod_UIAttr), asPrimitiveValue(model.variables.refundDetailsPaymentDetails_UIIn.displayLocation_UIAttr), asPrimitiveValue(model.variables.refundDetailsPaymentDetails_UIIn.displayPaidOn_UIAttr)]
}));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("ShopperPortalEU.InternalComponents.RefundPaymentDetails_WB.mvc$controller", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_API.model", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.languageResources", "ShopperPortalEU.clientVariables", "ShopperPortalEU.InternalComponents.RefundPaymentDetails_WB.mvc$debugger", "ShopperPortalEU.controller$FormatDate", "ShopperPortalEU_API.model$RefundDetails_WrapperRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_API", "ShopperPortalEU_Forms_IS.model$RefundDetailsPaymentDetails_UIRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Forms_IS", "ShopperPortalEU_UI_Components.model$CustomCardOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$CustomColumnsOptionsRec", "ShopperPortalEU_UI_Components.model$FlexOptionsRec"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_APIModel, ShopperPortalEU_Forms_ISModel, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEULanguageResources, ShopperPortalEUClientVariables, ShopperPortalEU_InternalComponents_RefundPaymentDetails_WB_mvc_Debugger) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = true;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions


// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:WLZg9jO0M0aiRlyqBkvkgg:/NRWebFlows.WLZg9jO0M0aiRlyqBkvkgg:eI2Gsuu43vLy9LWSnrwTXg", "ShopperPortalEU", "InternalComponents", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:3Ol2ehJR7Eijz33rXEF9HQ:/NRWebFlows.WLZg9jO0M0aiRlyqBkvkgg/NodesShownInESpaceTree.3Ol2ehJR7Eijz33rXEF9HQ:eoKzd2el+c8hAFSIMCnQOg", "ShopperPortalEU", "RefundPaymentDetails_WB", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:3Ol2ehJR7Eijz33rXEF9HQ", callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:WLZg9jO0M0aiRlyqBkvkgg", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return ShopperPortalEUController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, ShopperPortalEULanguageResources);
});

define("ShopperPortalEU.InternalComponents.RefundPaymentDetails_WB.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"XNI+V9w89U2+KniKeCXMiw": {
getter: function (varBag, idService) {
return varBag.model.variables.refundDetailsIn;
}
},
"qq8AHI1JuEeD+KvP+_s5Kw": {
getter: function (varBag, idService) {
return varBag.model.variables.refundDetailsPaymentDetails_UIIn;
}
},
"M9sRPisxc0a+30d6bly4uw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"A8zRLQpZvUqqOvdEz6JlPg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"vzfIe9fCxkmvrQ38ydmYJQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"b3Zj2Jk2u0qp9ovdAl_GPQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"BpOyeMy6iUKb5ZhlKD0xeA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"uuKamSfsZk++nPyuHX3TRA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"wFCmw7SDSkm51ku4BBIwwQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("ARN"));
})(varBag.model, idService);
}
},
"23scYCMpYUuy59O2_6KcLw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
