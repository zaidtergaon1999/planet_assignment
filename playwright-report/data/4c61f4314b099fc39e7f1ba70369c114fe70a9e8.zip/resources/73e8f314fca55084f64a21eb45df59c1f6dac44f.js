class creditCard {
  constructor(id, options, events) {
    this.class = 'credit-card';
    this.element = document.getElementById(id);
    this.stateClasses = {
      flipped: this.class.concat('--flipped'),
      swipping: this.class.concat('--swipping'),
      swipped: this.class.concat('--swipped')
    };
    this.listeners = {
      _click: this._click.bind(this),
      _touchStart: this._touchStart.bind(this),
      _touchMove: this._touchMove.bind(this),
      _touchEnd: this._touchEnd.bind(this)
    };
    this.swipe = {
      translate: 0
    };
    this.touches = {
      x: 0,
      y: 0,
      xF: 0,
      yF: 0
    };
    this.direction = '';
    this.options = options;
    this.events = events;
    this._build();
  }
  _updateSwipe() {
    this.element.classList.add(this.stateClasses.swipping);
    this.element.style.setProperty('--translate', this.swipe + 'px');
  }
  _swipeEnd() {
    if (this.direction === 'left' || this.direction === 'right') {
      if (this.swipe > 0) {
        this.swipe = 0;
        this.element.classList.remove(this.stateClasses.swipped);
      } else {
        this.swipe = -100;
        this.element.classList.add(this.stateClasses.swipped);
      }
      this._updateSwipe();
      this.element.classList.remove(this.stateClasses.swipping);
      this.direction = '';
    }
  }
  _swipeLeft() {
    this.swipe = this.touches.xF - this.touches.x;
    this._updateSwipe();
  }
  _swipeRight() {
    this.swipe = Math.abs(this.touches.xF - this.touches.x);
    this._updateSwipe();
  }
  _getDirection() {
    let dX = this.touches.xF - this.touches.x,
      dY = this.touches.yF - this.touches.y;
    if (dX === 0 && dY === 0) return 'touch';
    if (Math.abs(dX) > Math.abs(dY)) {
      return dX > 0 ? 'right' : 'left';
    } else {
      return dY > 0 ? 'down' : 'up';
    }
  }
  _touchStart(e) {
    if (!this.element.classList.contains(this.stateClasses.flipped)) {
      this.touches.x = e.changedTouches[0].screenX;
      this.touches.y = e.changedTouches[0].screenY;
    }
  }
  _touchMove(e) {
    if (!this.element.classList.contains(this.stateClasses.flipped)) {
      this.touches.xF = e.changedTouches[0].screenX;
      this.touches.yF = e.changedTouches[0].screenY;
      this.direction = this._getDirection();
      if (this.direction === 'left') {
        this._swipeLeft();
      } else {
        if (this.direction === 'right') {
          this._swipeRight();
        }
      }
    }
  }
  _touchEnd(e) {
    if (!this.element.classList.contains(this.stateClasses.flipped)) {
      this._swipeEnd();
    }
  }
  _click(e) {
    if (!this.options.empty) {
      let target = e.target;
      if (target.closest('button') === null && target.closest('a') === null && target.closest('.custom-switch') === null) {
        let cards = [...document.getElementsByClassName(this.class)];
        cards.forEach(x => {
          if (x !== this.element) {
            x.classList.remove(this.stateClasses.flipped);
          }
        });
        this.element.classList.toggle(this.stateClasses.flipped);
        if (this.options.swipe.swipeToDelete) {
          this.swipe = 0;
          this._updateSwipe();
          this.element.classList.remove(this.stateClasses.swipping);
          this.element.classList.remove(this.stateClasses.swipped);
        }
      }
    } else {
      this.events.emptyClick();
    }
  }
  _build() {
    this.element.addEventListener('click', this.listeners._click);
    if (this.options.swipe.swipeToDelete) {
      this.element.addEventListener('touchstart', this.listeners._touchStart);
      this.element.addEventListener('touchmove', this.listeners._touchMove);
      this.element.addEventListener('touchend', this.listeners._touchEnd);
    }
  }
}