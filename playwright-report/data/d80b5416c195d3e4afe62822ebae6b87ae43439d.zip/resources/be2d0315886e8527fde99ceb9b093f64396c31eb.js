define("ShopperPortalEU_UI_Components.controller$Base64ToBlobUrl", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.controller", "ShopperPortalEU_UI_Components.controller$Base64ToBlobUrl.Base64ToUrlJS"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ComponentsController, ShopperPortalEU_UI_Components_controller_Base64ToBlobUrl_Base64ToUrlJS) {
var OS = OutSystems.Internal;
ShopperPortalEU_UI_ComponentsController.default.base64ToBlobUrl$Action = function (base64In, contentTypeIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.Base64ToBlobUrl$vars"))());
vars.value.base64InLocal = base64In;
vars.value.contentTypeInLocal = contentTypeIn;
var base64ToUrlJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.Base64ToBlobUrl$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.base64ToUrlJSResult = base64ToUrlJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:fnTSPZhj0k+MnmqXXqnNSw:/ClientActionFlows.fnTSPZhj0k+MnmqXXqnNSw:XNYU+tcOinaTfOt6yOYzKA", "ShopperPortalEU_UI_Components", "Base64ToBlobUrl", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:cDbtSusGK0ipCi04Lf9Vzw", callContext.id);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:nPEa0MRPcEOpNrAPWS4Pow", callContext.id);
// Base64 = Replace
vars.value.base64InLocal = OS.BuiltinFunctions.replace(vars.value.base64InLocal, "data:application/pdf;base64,", "");
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:U9EtbP5t00GCB_IGd7PhMA", callContext.id);
base64ToUrlJSResult.value = controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_controller_Base64ToBlobUrl_Base64ToUrlJS, "Base64ToUrl", "Base64ToBlobUrl", {
ContentType: OS.DataConversion.JSNodeParamConverter.to(vars.value.contentTypeInLocal, OS.DataTypes.DataTypes.Text),
Base64String: OS.DataConversion.JSNodeParamConverter.to(vars.value.base64InLocal, OS.DataTypes.DataTypes.Text),
BlobUrl: OS.DataConversion.JSNodeParamConverter.to("", OS.DataTypes.DataTypes.Text)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.Base64ToBlobUrl$base64ToUrlJSResult"))();
jsNodeResult.blobUrlOut = OS.DataConversion.JSNodeParamConverter.from($parameters.BlobUrl, OS.DataTypes.DataTypes.Text);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:8rC58h2llUu5jT5nUxLRSQ", callContext.id);
// URL = Base64ToUrl.BlobUrl
outVars.value.uRLOut = base64ToUrlJSResult.value.blobUrlOut;
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:AV3CLVKapk6CRGO0pMq3yw", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:fnTSPZhj0k+MnmqXXqnNSw", callContext.id);
}

};
var controller = ShopperPortalEU_UI_ComponentsController.default;
ShopperPortalEU_UI_ComponentsController.default.constructor.registerVariableGroupType("ShopperPortalEU_UI_Components.Base64ToBlobUrl$vars", [{
name: "Base64",
attrName: "base64InLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}, {
name: "ContentType",
attrName: "contentTypeInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEU_UI_ComponentsController.default.constructor.registerVariableGroupType("ShopperPortalEU_UI_Components.Base64ToBlobUrl$base64ToUrlJSResult", [{
name: "BlobUrl",
attrName: "blobUrlOut",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEU_UI_ComponentsController.default.constructor.registerVariableGroupType("ShopperPortalEU_UI_Components.Base64ToBlobUrl$outVars", [{
name: "URL",
attrName: "uRLOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEU_UI_ComponentsController.default.clientActionProxies.base64ToBlobUrl$Action = function (base64In, contentTypeIn) {
base64In = (base64In === undefined) ? "" : base64In;
contentTypeIn = (contentTypeIn === undefined) ? "" : contentTypeIn;
return controller.executeActionInsideJSNode(ShopperPortalEU_UI_ComponentsController.default.base64ToBlobUrl$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(base64In, OS.DataTypes.DataTypes.Text), OS.DataConversion.JSNodeParamConverter.from(contentTypeIn, OS.DataTypes.DataTypes.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
URL: OS.DataConversion.JSNodeParamConverter.to(actionResults.uRLOut, OS.DataTypes.DataTypes.Text)
};
});
};
});
define("ShopperPortalEU_UI_Components.controller$Base64ToBlobUrl.Base64ToUrlJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
function b64toBlob(b64Data, contentType, sliceSize) {

  var byteCharacters = atob(b64Data);
  var byteArrays = [];

  for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
    var slice = byteCharacters.slice(offset, offset + sliceSize);

    var byteNumbers = new Array(slice.length);
    for (var i = 0; i < slice.length; i++) {
      byteNumbers[i] = slice.charCodeAt(i);
    }

    byteArrays.push(new Uint8Array(byteNumbers));
  }

  return new Blob(byteArrays, { type: contentType });
}


$parameters.BlobUrl = URL.createObjectURL(
    b64toBlob($parameters.Base64String, $parameters.ContentType, 512)
);

};
});

define("ShopperPortalEU_UI_Components.controller$CodeInputSetFocus", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.controller", "ShopperPortalEU_UI_Components.controller$CodeInputSetFocus.FocusJS"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ComponentsController, ShopperPortalEU_UI_Components_controller_CodeInputSetFocus_FocusJS) {
var OS = OutSystems.Internal;
ShopperPortalEU_UI_ComponentsController.default.codeInputSetFocus$Action = function (objIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.CodeInputSetFocus$vars"))());
vars.value.objInLocal = objIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:c8UuuitMRkOJU7rKqtrrDA:/ClientActionFlows.c8UuuitMRkOJU7rKqtrrDA:Agta9Dx1xtY4pdiz4F2Wbg", "ShopperPortalEU_UI_Components", "CodeInputSetFocus", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:CltdsX8nIUmrhZxdHHWGWw", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:c_cRv3HW3k6bsp1B+_axrw", callContext.id) && ((vars.value.objInLocal) !== (OS.BuiltinFunctions.nullObject())))) {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:_i_uk8CtekKoVQ5fG9PS6A", callContext.id);
// Focus method
controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_controller_CodeInputSetFocus_FocusJS, "Focus", "CodeInputSetFocus", {
Obj: OS.DataConversion.JSNodeParamConverter.to(vars.value.objInLocal, OS.DataTypes.DataTypes.Object)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:GPO5P2078kGTU1uiaodbqw", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:GPO5P2078kGTU1uiaodbqw", callContext.id);
}

return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:c8UuuitMRkOJU7rKqtrrDA", callContext.id);
}

};
var controller = ShopperPortalEU_UI_ComponentsController.default;
ShopperPortalEU_UI_ComponentsController.default.constructor.registerVariableGroupType("ShopperPortalEU_UI_Components.CodeInputSetFocus$vars", [{
name: "Obj",
attrName: "objInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Object,
defaultValue: function () {
return null;
}
}]);
ShopperPortalEU_UI_ComponentsController.default.clientActionProxies.codeInputSetFocus$Action = function (objIn) {
objIn = (objIn === undefined) ? null : objIn;
return controller.executeActionInsideJSNode(ShopperPortalEU_UI_ComponentsController.default.codeInputSetFocus$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(objIn, OS.DataTypes.DataTypes.Object)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("ShopperPortalEU_UI_Components.controller$CodeInputSetFocus.FocusJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.Obj.focus();
};
});

define("ShopperPortalEU_UI_Components.controller$DatatransCardExpiryDateFocus", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.controller", "ShopperPortalEU_UI_Components.controller$DatatransCardExpiryDateFocus.ExpiryDateFocusJS"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ComponentsController, ShopperPortalEU_UI_Components_controller_DatatransCardExpiryDateFocus_ExpiryDateFocusJS) {
var OS = OutSystems.Internal;
ShopperPortalEU_UI_ComponentsController.default.datatransCardExpiryDateFocus$Action = function (objIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.DatatransCardExpiryDateFocus$vars"))());
vars.value.objInLocal = objIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:bUk6xBNwg0Sd3XDdAWr58A:/ClientActionFlows.bUk6xBNwg0Sd3XDdAWr58A:adwh8UOFI2+aHWZqsPcX3A", "ShopperPortalEU_UI_Components", "DatatransCardExpiryDateFocus", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:Pf69hwKLbkiyXidRiVq6zQ", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:0oGrSWJB0ES70K_qykvn4w", callContext.id) && (vars.value.objInLocal === OS.BuiltinFunctions.nullObject()))) {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:aEoSY4u79kuEvPoxD+rMww", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:pkMd62vtXEyz+Uoel0MREQ", callContext.id);
// expiryDateFocus method.
controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_controller_DatatransCardExpiryDateFocus_ExpiryDateFocusJS, "ExpiryDateFocus", "DatatransCardExpiryDateFocus", {
Obj: OS.DataConversion.JSNodeParamConverter.to(vars.value.objInLocal, OS.DataTypes.DataTypes.Object)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:IYxmJcu5gEGCTiFINh9Oog", callContext.id);
}

return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:bUk6xBNwg0Sd3XDdAWr58A", callContext.id);
}

};
var controller = ShopperPortalEU_UI_ComponentsController.default;
ShopperPortalEU_UI_ComponentsController.default.constructor.registerVariableGroupType("ShopperPortalEU_UI_Components.DatatransCardExpiryDateFocus$vars", [{
name: "Obj",
attrName: "objInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Object,
defaultValue: function () {
return null;
}
}]);
ShopperPortalEU_UI_ComponentsController.default.clientActionProxies.datatransCardExpiryDateFocus$Action = function (objIn) {
objIn = (objIn === undefined) ? null : objIn;
return controller.executeActionInsideJSNode(ShopperPortalEU_UI_ComponentsController.default.datatransCardExpiryDateFocus$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(objIn, OS.DataTypes.DataTypes.Object)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("ShopperPortalEU_UI_Components.controller$DatatransCardExpiryDateFocus.ExpiryDateFocusJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.Obj.expiryDateFocus();
};
});

define("ShopperPortalEU_UI_Components.controller$DatatransCardGetCardInfo", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.controller", "ShopperPortalEU_UI_Components.controller$DatatransCardGetCardInfo.GetCardInfoJS"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ComponentsController, ShopperPortalEU_UI_Components_controller_DatatransCardGetCardInfo_GetCardInfoJS) {
var OS = OutSystems.Internal;
ShopperPortalEU_UI_ComponentsController.default.datatransCardGetCardInfo$Action = function (objIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.DatatransCardGetCardInfo$vars"))());
vars.value.objInLocal = objIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:X7HxMHJnAkORYHhkHggfgw:/ClientActionFlows.X7HxMHJnAkORYHhkHggfgw:LaaZlbsp2O6VLmURTgo8UQ", "ShopperPortalEU_UI_Components", "DatatransCardGetCardInfo", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:TGeyxcI9hUeKpHpU546xXQ", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:86K1W8lAlUSobnD9DVZ60w", callContext.id) && (vars.value.objInLocal === OS.BuiltinFunctions.nullObject()))) {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:G_w5N3Gdpk6j7_0I13M2vA", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:mlSZv_0CXESzExVWbXjKUA", callContext.id);
// GetCard info method
controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_controller_DatatransCardGetCardInfo_GetCardInfoJS, "GetCardInfo", "DatatransCardGetCardInfo", {
Obj: OS.DataConversion.JSNodeParamConverter.to(vars.value.objInLocal, OS.DataTypes.DataTypes.Object)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:on97XDLD6UiBhdcHCEHuEg", callContext.id);
}

return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:X7HxMHJnAkORYHhkHggfgw", callContext.id);
}

};
var controller = ShopperPortalEU_UI_ComponentsController.default;
ShopperPortalEU_UI_ComponentsController.default.constructor.registerVariableGroupType("ShopperPortalEU_UI_Components.DatatransCardGetCardInfo$vars", [{
name: "Obj",
attrName: "objInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Object,
defaultValue: function () {
return null;
}
}]);
ShopperPortalEU_UI_ComponentsController.default.clientActionProxies.datatransCardGetCardInfo$Action = function (objIn) {
objIn = (objIn === undefined) ? null : objIn;
return controller.executeActionInsideJSNode(ShopperPortalEU_UI_ComponentsController.default.datatransCardGetCardInfo$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(objIn, OS.DataTypes.DataTypes.Object)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("ShopperPortalEU_UI_Components.controller$DatatransCardGetCardInfo.GetCardInfoJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.Obj.getCardInfo();
};
});

define("ShopperPortalEU_UI_Components.controller$DatatransCardSubmit", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.controller", "ShopperPortalEU_UI_Components.controller$DatatransCardSubmit.SubmitJS"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ComponentsController, ShopperPortalEU_UI_Components_controller_DatatransCardSubmit_SubmitJS) {
var OS = OutSystems.Internal;
ShopperPortalEU_UI_ComponentsController.default.datatransCardSubmit$Action = function (objIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.DatatransCardSubmit$vars"))());
vars.value.objInLocal = objIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:Ao3z4fDU5UOtkN8VQYgGqA:/ClientActionFlows.Ao3z4fDU5UOtkN8VQYgGqA:5wkt4fl0m_sB0ZzZU4nvtA", "ShopperPortalEU_UI_Components", "DatatransCardSubmit", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:Kn3OhDkQgUy3ybZBSiLrOg", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:y00bQxp_YEWiS8Afr4RoaA", callContext.id) && (vars.value.objInLocal === OS.BuiltinFunctions.nullObject()))) {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:JvFlS58jdkGnSuHMO066BA", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:Bn9Rr_VSc0K_d_cN7b613g", callContext.id);
// Submit method.
controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_controller_DatatransCardSubmit_SubmitJS, "Submit", "DatatransCardSubmit", {
Obj: OS.DataConversion.JSNodeParamConverter.to(vars.value.objInLocal, OS.DataTypes.DataTypes.Object)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:0Prdx97sx0u5LQwJyjWsiQ", callContext.id);
}

return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:Ao3z4fDU5UOtkN8VQYgGqA", callContext.id);
}

};
var controller = ShopperPortalEU_UI_ComponentsController.default;
ShopperPortalEU_UI_ComponentsController.default.constructor.registerVariableGroupType("ShopperPortalEU_UI_Components.DatatransCardSubmit$vars", [{
name: "Obj",
attrName: "objInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Object,
defaultValue: function () {
return null;
}
}]);
ShopperPortalEU_UI_ComponentsController.default.clientActionProxies.datatransCardSubmit$Action = function (objIn) {
objIn = (objIn === undefined) ? null : objIn;
return controller.executeActionInsideJSNode(ShopperPortalEU_UI_ComponentsController.default.datatransCardSubmit$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(objIn, OS.DataTypes.DataTypes.Object)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("ShopperPortalEU_UI_Components.controller$DatatransCardSubmit.SubmitJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.Obj.submit();
};
});

define("ShopperPortalEU_UI_Components.controller$GetOS", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.controller", "ShopperPortalEU_UI_Components.controller$GetOS.GetOSJS", "ShopperPortalEU_UI_Components.model$GetOSRec", "ShopperPortalEU_UI_Components.controller$GetOSFallback"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ComponentsController, ShopperPortalEU_UI_Components_controller_GetOS_GetOSJS) {
var OS = OutSystems.Internal;
ShopperPortalEU_UI_ComponentsController.default.getOS$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var getOSJSResult = new OS.DataTypes.VariableHolder();
var getOSDeserializeVar = new OS.DataTypes.VariableHolder(new (OS.Controller.BaseController.getJSONDeserializeOutputType(ShopperPortalEU_UI_ComponentsModel.GetOSRec))());
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.GetOS$outVars"))());
varBag.callContext = callContext;
varBag.getOSJSResult = getOSJSResult;
varBag.getOSDeserializeVar = getOSDeserializeVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:SEnFPiouSEKXSikTvrk7qw:/ClientActionFlows.SEnFPiouSEKXSikTvrk7qw:Dz+vhpwFpt3W+xoDiRsHsw", "ShopperPortalEU_UI_Components", "GetOS", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:SsjpcT_qfUCiaShftRThqA", callContext.id);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:1Bd4azlsS0W9+ib7cymnjw", callContext.id);
// GetOS information method
getOSJSResult.value = controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_controller_GetOS_GetOSJS, "GetOS", "GetOS", {
OS: OS.DataConversion.JSNodeParamConverter.to("", OS.DataTypes.DataTypes.Text)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.GetOS$getOSJSResult"))();
jsNodeResult.oSOut = OS.DataConversion.JSNodeParamConverter.from($parameters.OS, OS.DataTypes.DataTypes.Text);
return jsNodeResult;
}, {}, {});
if((OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:IWIEyE_di060arj_JxTJnA", callContext.id) && (getOSJSResult.value.oSOut === ""))) {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:rjiTKmxOokOdyfpolHEd1Q", callContext.id);
// OS = GetOSFallback()
outVars.value.oSOut = OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEU_UI_ComponentsController.default.getOSFallback$Action(callContext).oSOut;
}, OS.DataTypes.DataTypes.Record, callContext.id);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:x9qW+WP0Nke2CAePUbeDeA", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:bkWQG9dKbke5Lgr2GtOCjg", callContext.id);
// JSON Deserialize: GetOSDeserialize
getOSDeserializeVar.value.dataOut = OS.JSONUtils.deserializeFromJSON(getOSJSResult.value.oSOut, ShopperPortalEU_UI_ComponentsModel.GetOSRec, false);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:ujRJ52zYpkmqZSrZScjrzg", callContext.id);
// OS = GetOSDeserialize.Data
outVars.value.oSOut = getOSDeserializeVar.value.dataOut;
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:p1HVSnu3oEme+NWK6GAQtw", callContext.id);
}

return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:SEnFPiouSEKXSikTvrk7qw", callContext.id);
}

};
var controller = ShopperPortalEU_UI_ComponentsController.default;
ShopperPortalEU_UI_ComponentsController.default.constructor.registerVariableGroupType("ShopperPortalEU_UI_Components.GetOS$getOSJSResult", [{
name: "OS",
attrName: "oSOut",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEU_UI_ComponentsController.default.constructor.registerVariableGroupType("ShopperPortalEU_UI_Components.GetOS$outVars", [{
name: "OS",
attrName: "oSOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Record,
defaultValue: function () {
return new ShopperPortalEU_UI_ComponentsModel.GetOSRec();
},
complexType: ShopperPortalEU_UI_ComponentsModel.GetOSRec
}]);
ShopperPortalEU_UI_ComponentsController.default.clientActionProxies.getOS$Action = function () {
return controller.executeActionInsideJSNode(ShopperPortalEU_UI_ComponentsController.default.getOS$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
OS: actionResults.oSOut
};
});
};
});
define("ShopperPortalEU_UI_Components.controller$GetOS.GetOSJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
if (window.layout && window.layout.browserReport !== undefined) {
    $parameters.OS = JSON.stringify(window.layout.browserReport);
}
};
});

define("ShopperPortalEU_UI_Components.controller$GetOSFallback", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.controller", "ShopperPortalEU_UI_Components.controller$GetOSFallback.supportsMultiTouchJS", "ShopperPortalEU_UI_Components.model$GetOSRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ComponentsController, ShopperPortalEU_UI_Components_controller_GetOSFallback_supportsMultiTouchJS) {
var OS = OutSystems.Internal;
ShopperPortalEU_UI_ComponentsController.default.getOSFallback$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.GetOSFallback$vars"))());
var supportsMultiTouchJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.GetOSFallback$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.supportsMultiTouchJSResult = supportsMultiTouchJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:_UxbeoJw80Wq7Xi_Jfdjqw:/ClientActionFlows._UxbeoJw80Wq7Xi_Jfdjqw:2g9fk4sV8jr39aypsi7b4Q", "ShopperPortalEU_UI_Components", "GetOSFallback", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:y1G_JeqVl0OB94hAn1jNtg", callContext.id);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:MQjRgnzZY0uMuM2DFaZVNA", callContext.id);
// UserAgent = ToLower
vars.value.userAgentVar = OS.BuiltinFunctions.toLower(OS.BuiltinFunctions.getUserAgent());
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:7i5y9o9bB0i1eGdHJvb4Ww", callContext.id);
// Check if browser supports multi-touch.
supportsMultiTouchJSResult.value = controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_controller_GetOSFallback_supportsMultiTouchJS, "supportsMultiTouch", "GetOSFallback", {
HasMaxTouchPoints: OS.DataConversion.JSNodeParamConverter.to(false, OS.DataTypes.DataTypes.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.GetOSFallback$supportsMultiTouchJSResult"))();
jsNodeResult.hasMaxTouchPointsOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasMaxTouchPoints, OS.DataTypes.DataTypes.Boolean);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:YzQ5_annh0SkaZTK8HGehQ", callContext.id);
// MultiTouch = supportsMultiTouch.HasMaxTouchPoints
vars.value.multiTouchVar = supportsMultiTouchJSResult.value.hasMaxTouchPointsOut;
// Detect Device
if((OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:TuUWOkQMN0Kt+F23whRQrA", callContext.id) && (((OS.BuiltinFunctions.index(vars.value.userAgentVar, "ipad", 0, false, false) > -1) || (OS.BuiltinFunctions.index(vars.value.userAgentVar, "iphone", 0, false, false) > -1)) || ((OS.BuiltinFunctions.index(vars.value.userAgentVar, "mac", 0, false, false) > -1) && vars.value.multiTouchVar)))) {
// Ios
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:Xh3WAtdFrk6zgmooTXO5EA", callContext.id);
// OS.OS.Name = "ios"
outVars.value.oSOut.oSAttr.nameAttr = "ios";
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:XaLjKIVNikmGIDdNzyJlAQ", callContext.id);
} else {
if((OS.BuiltinFunctions.index(vars.value.userAgentVar, "android", 0, false, false) > -1)) {
// Android
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:sioLQsaocEOs9RXxfhMvow", callContext.id);
// OS.OS.Name = "android"
outVars.value.oSOut.oSAttr.nameAttr = "android";
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:XaLjKIVNikmGIDdNzyJlAQ", callContext.id);
} else {
if((OS.BuiltinFunctions.index(vars.value.userAgentVar, "windows", 0, false, false) > -1)) {
// Windows
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:2i8z1AfGbkesICeJQHDz2Q", callContext.id);
// OS.OS.Name = "windows"
outVars.value.oSOut.oSAttr.nameAttr = "windows";
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:XaLjKIVNikmGIDdNzyJlAQ", callContext.id);
} else {
if(((OS.BuiltinFunctions.index(vars.value.userAgentVar, "mac", 0, false, false) > -1) && !(vars.value.multiTouchVar))) {
// Macos
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:Xxy+1TjNq0mCVW4yZ4D9ow", callContext.id);
// OS.OS.Name = "macos"
outVars.value.oSOut.oSAttr.nameAttr = "macos";
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:XaLjKIVNikmGIDdNzyJlAQ", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:XaLjKIVNikmGIDdNzyJlAQ", callContext.id);
}

}

}

}

return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:_UxbeoJw80Wq7Xi_Jfdjqw", callContext.id);
}

};
var controller = ShopperPortalEU_UI_ComponentsController.default;
ShopperPortalEU_UI_ComponentsController.default.constructor.registerVariableGroupType("ShopperPortalEU_UI_Components.GetOSFallback$vars", [{
name: "UserAgent",
attrName: "userAgentVar",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}, {
name: "MultiTouch",
attrName: "multiTouchVar",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Boolean,
defaultValue: function () {
return false;
}
}]);
ShopperPortalEU_UI_ComponentsController.default.constructor.registerVariableGroupType("ShopperPortalEU_UI_Components.GetOSFallback$supportsMultiTouchJSResult", [{
name: "HasMaxTouchPoints",
attrName: "hasMaxTouchPointsOut",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Boolean,
defaultValue: function () {
return false;
}
}]);
ShopperPortalEU_UI_ComponentsController.default.constructor.registerVariableGroupType("ShopperPortalEU_UI_Components.GetOSFallback$outVars", [{
name: "OS",
attrName: "oSOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Record,
defaultValue: function () {
return new ShopperPortalEU_UI_ComponentsModel.GetOSRec();
},
complexType: ShopperPortalEU_UI_ComponentsModel.GetOSRec
}]);
ShopperPortalEU_UI_ComponentsController.default.clientActionProxies.getOSFallback$Action = function () {
return controller.executeActionInsideJSNode(ShopperPortalEU_UI_ComponentsController.default.getOSFallback$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
OS: actionResults.oSOut
};
});
};
});
define("ShopperPortalEU_UI_Components.controller$GetOSFallback.supportsMultiTouchJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasMaxTouchPoints = navigator.maxTouchPoints > 1
};
});

define("ShopperPortalEU_UI_Components.controller$GetScreenNavigationType", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.controller", "ShopperPortalEU_UI_Components.controller$GetScreenNavigationType.GetNavigationTypeJS"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ComponentsController, ShopperPortalEU_UI_Components_controller_GetScreenNavigationType_GetNavigationTypeJS) {
var OS = OutSystems.Internal;
ShopperPortalEU_UI_ComponentsController.default.getScreenNavigationType$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var getNavigationTypeJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.GetScreenNavigationType$outVars"))());
varBag.callContext = callContext;
varBag.getNavigationTypeJSResult = getNavigationTypeJSResult;
varBag.outVars = outVars;
OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:8NfYDOrNPE6meAGK6VTqmQ:/ClientActionFlows.8NfYDOrNPE6meAGK6VTqmQ:O3Mr1KHD+lvWVhYm2NWTGA", "ShopperPortalEU_UI_Components", "GetScreenNavigationType", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:zPmIs1RE0UGRPdwVLnuBtQ", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:BbIIpjqpN0Giw2dY2blVog", callContext.id);
// Method to return current screen navigation type
return controller.safeExecuteAsyncJSNode(ShopperPortalEU_UI_Components_controller_GetScreenNavigationType_GetNavigationTypeJS, "GetNavigationType", "GetScreenNavigationType", {
Type: OS.DataConversion.JSNodeParamConverter.to("", OS.DataTypes.DataTypes.Text)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.GetScreenNavigationType$getNavigationTypeJSResult"))();
jsNodeResult.typeOut = OS.DataConversion.JSNodeParamConverter.from($parameters.Type, OS.DataTypes.DataTypes.Text);
return jsNodeResult;
}, {}, {}).then(function (results) {
getNavigationTypeJSResult.value = results;
}).then(function () {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:Snt7x6Va1ECSKIFwaZaJ7Q", callContext.id);
// Type = GetNavigationType.Type
outVars.value.typeOut = getNavigationTypeJSResult.value.typeOut;
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:9on85zqH_0+MWCLFcFv6IA", callContext.id);
});
}).then(function () {
return outVars.value;
}).then(function (res) {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:8NfYDOrNPE6meAGK6VTqmQ", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:8NfYDOrNPE6meAGK6VTqmQ", callContext.id);
throw ex;

});
};
var controller = ShopperPortalEU_UI_ComponentsController.default;
ShopperPortalEU_UI_ComponentsController.default.constructor.registerVariableGroupType("ShopperPortalEU_UI_Components.GetScreenNavigationType$getNavigationTypeJSResult", [{
name: "Type",
attrName: "typeOut",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEU_UI_ComponentsController.default.constructor.registerVariableGroupType("ShopperPortalEU_UI_Components.GetScreenNavigationType$outVars", [{
name: "Type",
attrName: "typeOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEU_UI_ComponentsController.default.clientActionProxies.getScreenNavigationType$Action = function () {
return controller.executeActionInsideJSNode(ShopperPortalEU_UI_ComponentsController.default.getScreenNavigationType$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Type: OS.DataConversion.JSNodeParamConverter.to(actionResults.typeOut, OS.DataTypes.DataTypes.Text)
};
});
};
});
define("ShopperPortalEU_UI_Components.controller$GetScreenNavigationType.GetNavigationTypeJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
return new Promise(function ($resolve, $reject) {
if (PerformanceObserver) {
    let observer = new PerformanceObserver((list) => {
        list.getEntries().forEach((entry) => {
            $parameters.Type = entry.type;
            $resolve();
        });
    });
    observer.observe({
        type: "navigation",
        buffered: true
    });
} else {
    //DEPRECATED method (only for devices that don't support PerfomanceObserver)
    if (performance && performance.navigation) {
        switch (performance.navigation.type) {
            case performance.navigation.TYPE_RELOAD:
                $parameters.Type = 'reload';
                break;
            case performance.navigation.TYPE_BACK_FORWARD:
                $parameters.Type = 'back_forward';
                break;
            case performance.navigation.TYPE_NAVIGATE:
                $parameters.Type = 'navigate';
                break;
        }
    }
}

});
};
});

define("ShopperPortalEU_UI_Components.controller$GetScreenOrientation", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.controller", "ShopperPortalEU_UI_Components.controller$GetScreenOrientation.GetScreenOrientationJS"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ComponentsController, ShopperPortalEU_UI_Components_controller_GetScreenOrientation_GetScreenOrientationJS) {
var OS = OutSystems.Internal;
ShopperPortalEU_UI_ComponentsController.default.getScreenOrientation$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var getScreenOrientationJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.GetScreenOrientation$outVars"))());
varBag.callContext = callContext;
varBag.getScreenOrientationJSResult = getScreenOrientationJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:HAGfh66Q3kWcEBQuvI4DYQ:/ClientActionFlows.HAGfh66Q3kWcEBQuvI4DYQ:k5Qp97m58lGhfymELffOFA", "ShopperPortalEU_UI_Components", "GetScreenOrientation", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:yiin7fd45E+9IqsTHP86DA", callContext.id);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:FbobanTpFUCmyboDZc9P_A", callContext.id);
// Method to detect current screen orientation ('portrait','landscape')
getScreenOrientationJSResult.value = controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_controller_GetScreenOrientation_GetScreenOrientationJS, "GetScreenOrientation", "GetScreenOrientation", {
Orientation: OS.DataConversion.JSNodeParamConverter.to("", OS.DataTypes.DataTypes.Text)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.GetScreenOrientation$getScreenOrientationJSResult"))();
jsNodeResult.orientationOut = OS.DataConversion.JSNodeParamConverter.from($parameters.Orientation, OS.DataTypes.DataTypes.Text);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:bHe7mjdHKkabNxGSz8qc3g", callContext.id);
// Orientation = GetScreenOrientation.Orientation
outVars.value.orientationOut = getScreenOrientationJSResult.value.orientationOut;
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:VvA5JhExRU2v9QKZFnZeeA", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:HAGfh66Q3kWcEBQuvI4DYQ", callContext.id);
}

};
var controller = ShopperPortalEU_UI_ComponentsController.default;
ShopperPortalEU_UI_ComponentsController.default.constructor.registerVariableGroupType("ShopperPortalEU_UI_Components.GetScreenOrientation$getScreenOrientationJSResult", [{
name: "Orientation",
attrName: "orientationOut",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEU_UI_ComponentsController.default.constructor.registerVariableGroupType("ShopperPortalEU_UI_Components.GetScreenOrientation$outVars", [{
name: "Orientation",
attrName: "orientationOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEU_UI_ComponentsController.default.clientActionProxies.getScreenOrientation$Action = function () {
return controller.executeActionInsideJSNode(ShopperPortalEU_UI_ComponentsController.default.getScreenOrientation$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Orientation: OS.DataConversion.JSNodeParamConverter.to(actionResults.orientationOut, OS.DataTypes.DataTypes.Text)
};
});
};
});
define("ShopperPortalEU_UI_Components.controller$GetScreenOrientation.GetScreenOrientationJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
if (screen.orientation) {
    $parameters.Orientation = screen.orientation.type.includes('landscape') ? 'landscape' : 'portrait';
} else {
    $parameters.Orientation = document.body.classList.contains('landscape') ? 'landscape' : 'portrait';
}
};
});

define("ShopperPortalEU_UI_Components.controller$OpenPDF", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.controller", "ShopperPortalEU_UI_Components.controller$OpenPDF.OpenPDFJS", "ShopperPortalEU_UI_Components.controller$Base64ToBlobUrl", "ShopperPortalEU_UI_Components.model$OpenPDFOptionsRec"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ComponentsController, ShopperPortalEU_UI_Components_controller_OpenPDF_OpenPDFJS) {
var OS = OutSystems.Internal;
ShopperPortalEU_UI_ComponentsController.default.openPDF$Action = function (optionsIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.OpenPDF$vars"))());
vars.value.optionsInLocal = optionsIn.clone();
var base64ToBlobUrlVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.vars = vars;
varBag.base64ToBlobUrlVar = base64ToBlobUrlVar;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:15E_p7AD00OeF8cpKaef+g:/ClientActionFlows.15E_p7AD00OeF8cpKaef+g:KM6aGoP_a7WHYM+IPa3OVg", "ShopperPortalEU_UI_Components", "OpenPDF", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:8AOZE_u6p0uLcVsd6cGHKg", callContext.id);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:l0r4EK+a70GfqBsNNgz37A", callContext.id);
// Execute Action: Base64ToBlobUrl
base64ToBlobUrlVar.value = ShopperPortalEU_UI_ComponentsController.default.base64ToBlobUrl$Action(vars.value.optionsInLocal.pDFAttr, "application/pdf", callContext);

OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:sxM6dEiyKUaf7QvW9v1R8w", callContext.id);
// Open pdf file in a new browser tab.
controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_controller_OpenPDF_OpenPDFJS, "OpenPDF", "OpenPDF", {
PDF: OS.DataConversion.JSNodeParamConverter.to(base64ToBlobUrlVar.value.uRLOut, OS.DataTypes.DataTypes.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:GMKPeFRh706LsHKFNDE1oA", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:15E_p7AD00OeF8cpKaef+g", callContext.id);
}

};
var controller = ShopperPortalEU_UI_ComponentsController.default;
ShopperPortalEU_UI_ComponentsController.default.constructor.registerVariableGroupType("ShopperPortalEU_UI_Components.OpenPDF$vars", [{
name: "Options",
attrName: "optionsInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Record,
defaultValue: function () {
return new ShopperPortalEU_UI_ComponentsModel.OpenPDFOptionsRec();
},
complexType: ShopperPortalEU_UI_ComponentsModel.OpenPDFOptionsRec
}]);
ShopperPortalEU_UI_ComponentsController.default.clientActionProxies.openPDF$Action = function (optionsIn) {
optionsIn = (optionsIn === undefined) ? new ShopperPortalEU_UI_ComponentsModel.OpenPDFOptionsRec() : optionsIn;
return controller.executeActionInsideJSNode(ShopperPortalEU_UI_ComponentsController.default.openPDF$Action.bind(controller, optionsIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("ShopperPortalEU_UI_Components.controller$OpenPDF.OpenPDFJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
window.location.href = $parameters.PDF;
//window.open($parameters.PDF,'_blank');
};
});

define("ShopperPortalEU_UI_Components.controller$ResetFocus", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.controller", "ShopperPortalEU_UI_Components.controller$ResetFocus.ResetJS"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ComponentsController, ShopperPortalEU_UI_Components_controller_ResetFocus_ResetJS) {
var OS = OutSystems.Internal;
ShopperPortalEU_UI_ComponentsController.default.resetFocus$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:MFhgUEikaEKZpV2nkGE08A:/ClientActionFlows.MFhgUEikaEKZpV2nkGE08A:IYv+pUi3loAMSkisTPbq4w", "ShopperPortalEU_UI_Components", "ResetFocus", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:G6tHef3Lmk+bPenIBx9zkw", callContext.id);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:TZ2S9ZSSxEOTIHA+4Wpmqg", callContext.id);
controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_controller_ResetFocus_ResetJS, "Reset", "ResetFocus", null, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:i5cM7B7HHE69xiLdtPwncw", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:MFhgUEikaEKZpV2nkGE08A", callContext.id);
}

};
var controller = ShopperPortalEU_UI_ComponentsController.default;
ShopperPortalEU_UI_ComponentsController.default.clientActionProxies.resetFocus$Action = function () {
return controller.executeActionInsideJSNode(ShopperPortalEU_UI_ComponentsController.default.resetFocus$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("ShopperPortalEU_UI_Components.controller$ResetFocus.ResetJS", [], function () {
return function ($actions, $roles, $public) {
document.activeElement.blur();
};
});

define("ShopperPortalEU_UI_Components.controller$ScreenOrientationLock", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.controller", "ShopperPortalEU_UI_Components.controller$ScreenOrientationLock.LockOrientationJS"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ComponentsController, ShopperPortalEU_UI_Components_controller_ScreenOrientationLock_LockOrientationJS) {
var OS = OutSystems.Internal;
ShopperPortalEU_UI_ComponentsController.default.screenOrientationLock$Action = function (orientationIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.ScreenOrientationLock$vars"))());
vars.value.orientationInLocal = orientationIn;
var lockOrientationJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.ScreenOrientationLock$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.lockOrientationJSResult = lockOrientationJSResult;
varBag.outVars = outVars;
OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:0uYEDseHrEe95N1DkiSyqQ:/ClientActionFlows.0uYEDseHrEe95N1DkiSyqQ:jXvIJhLmhAeoIbsnSh8UTQ", "ShopperPortalEU_UI_Components", "ScreenOrientationLock", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:nGK7WeqFQkKq+NP9timznw", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:qxAWfLe9nECk9H1RI0z46g", callContext.id);
// Lock orientation method
return controller.safeExecuteAsyncJSNode(ShopperPortalEU_UI_Components_controller_ScreenOrientationLock_LockOrientationJS, "LockOrientation", "ScreenOrientationLock", {
Orientation: OS.DataConversion.JSNodeParamConverter.to(vars.value.orientationInLocal, OS.DataTypes.DataTypes.Text),
Success: OS.DataConversion.JSNodeParamConverter.to(false, OS.DataTypes.DataTypes.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.ScreenOrientationLock$lockOrientationJSResult"))();
jsNodeResult.successOut = OS.DataConversion.JSNodeParamConverter.from($parameters.Success, OS.DataTypes.DataTypes.Boolean);
return jsNodeResult;
}, {}, {}).then(function (results) {
lockOrientationJSResult.value = results;
}).then(function () {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:nQ4zkyExj06MfQJ8qn60rg", callContext.id);
// IsSuccess = LockOrientation.Success
outVars.value.isSuccessOut = lockOrientationJSResult.value.successOut;
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:CFIDL8OPDU2Svvua+BOCDA", callContext.id);
});
}).then(function () {
return outVars.value;
}).then(function (res) {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:0uYEDseHrEe95N1DkiSyqQ", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:0uYEDseHrEe95N1DkiSyqQ", callContext.id);
throw ex;

});
};
var controller = ShopperPortalEU_UI_ComponentsController.default;
ShopperPortalEU_UI_ComponentsController.default.constructor.registerVariableGroupType("ShopperPortalEU_UI_Components.ScreenOrientationLock$vars", [{
name: "Orientation",
attrName: "orientationInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
ShopperPortalEU_UI_ComponentsController.default.constructor.registerVariableGroupType("ShopperPortalEU_UI_Components.ScreenOrientationLock$lockOrientationJSResult", [{
name: "Success",
attrName: "successOut",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Boolean,
defaultValue: function () {
return false;
}
}]);
ShopperPortalEU_UI_ComponentsController.default.constructor.registerVariableGroupType("ShopperPortalEU_UI_Components.ScreenOrientationLock$outVars", [{
name: "IsSuccess",
attrName: "isSuccessOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Boolean,
defaultValue: function () {
return false;
}
}]);
ShopperPortalEU_UI_ComponentsController.default.clientActionProxies.screenOrientationLock$Action = function (orientationIn) {
orientationIn = (orientationIn === undefined) ? "" : orientationIn;
return controller.executeActionInsideJSNode(ShopperPortalEU_UI_ComponentsController.default.screenOrientationLock$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(orientationIn, OS.DataTypes.DataTypes.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
IsSuccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.isSuccessOut, OS.DataTypes.DataTypes.Boolean)
};
});
};
});
define("ShopperPortalEU_UI_Components.controller$ScreenOrientationLock.LockOrientationJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
return new Promise(function ($resolve, $reject) {
if (screen.orientation && screen.orientation.lock) {
    screen.orientation.lock($parameters.Orientation).then(() => {
        $parameters.Success = true;
        $resolve();
    }).catch((error) => {
        $parameters.Success = false;
        $resolve();
    });
}
});
};
});

define("ShopperPortalEU_UI_Components.controller$ScrollToFirstInvalidField", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.controller", "ShopperPortalEU_UI_Components.controller$ScrollToFirstInvalidField.ScrollJS"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ComponentsController, ShopperPortalEU_UI_Components_controller_ScrollToFirstInvalidField_ScrollJS) {
var OS = OutSystems.Internal;
ShopperPortalEU_UI_ComponentsController.default.scrollToFirstInvalidField$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:YH2KzPghSUyT+v4lxysbww:/ClientActionFlows.YH2KzPghSUyT+v4lxysbww:X6FRwQ99BekNtVdxapCBrg", "ShopperPortalEU_UI_Components", "ScrollToFirstInvalidField", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:8EU28Xd7mUamxnPbho3qKQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:tnLafnH3z0CQ9XqzN0o7Yg", callContext.id);
// Scroll method
controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_controller_ScrollToFirstInvalidField_ScrollJS, "Scroll", "ScrollToFirstInvalidField", null, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:roa53jIBwUCNR2jEGBVvIA", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:YH2KzPghSUyT+v4lxysbww", callContext.id);
}

};
var controller = ShopperPortalEU_UI_ComponentsController.default;
ShopperPortalEU_UI_ComponentsController.default.clientActionProxies.scrollToFirstInvalidField$Action = function () {
return controller.executeActionInsideJSNode(ShopperPortalEU_UI_ComponentsController.default.scrollToFirstInvalidField$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("ShopperPortalEU_UI_Components.controller$ScrollToFirstInvalidField.ScrollJS", [], function () {
return function ($actions, $roles, $public) {
setTimeout(function() {
    let el = document.getElementsByClassName('not-valid')[0];
    if (el) {
        let pos = el.getBoundingClientRect();
        if (window.layout.element) {
            window.layout.element.scrollTo({
                top: pos.top + window.layout.element.scrollTop - 80,
                behavior: "smooth",
            });
        }

    }
}, 0)
};
});

define("ShopperPortalEU_UI_Components.controller", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.controller$debugger"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_Components_Controller_debugger) {
var OS = OutSystems.Internal;
var ShopperPortalEU_UI_ComponentsController = exports;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
}
Controller.prototype.clientActionProxies = {};
Controller.prototype.roles = {};
Controller.prototype.defaultTimeout = 10;
Controller.prototype.getDefaultTimeout = function () {
return ShopperPortalEU_UI_ComponentsController.default.defaultTimeout;
};
Controller.prototype.getClientActionProxies = function (controller) {
var _this = this;
var thisController = controller;
return Object.keys(this.clientActionProxies).reduce(function (acc, actionName) {
acc[actionName] = function () {
if(thisController.isActive()) {
return _this.clientActionProxies[actionName].apply(thisController, arguments);
}

return Promise.resolve();
};
return acc;
}, {});
};
return Controller;
})(OS.Controller.BaseModuleController);
ShopperPortalEU_UI_ComponentsController.default = new Controller(null, "ShopperPortalEU_UI_Components");
});
define("ShopperPortalEU_UI_Components.controller$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"G2fgZdf0pUS9wrzyVd4qGg": {
getter: function (varBag, idService) {
return varBag.outVars.value.typeOut;
},
dataType: OS.DataTypes.DataTypes.Text
},
"BbIIpjqpN0Giw2dY2blVog": {
getter: function (varBag, idService) {
return varBag.getNavigationTypeJSResult.value;
}
},
"kkeLmOjTG0CPicjfZwMppQ": {
getter: function (varBag, idService) {
return varBag.vars.value.orientationInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"o_koTvWn2k+rWndGZNJehA": {
getter: function (varBag, idService) {
return varBag.outVars.value.isSuccessOut;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"qxAWfLe9nECk9H1RI0z46g": {
getter: function (varBag, idService) {
return varBag.lockOrientationJSResult.value;
}
},
"54E212+gaUOnlj0tARO8GQ": {
getter: function (varBag, idService) {
return varBag.vars.value.objInLocal;
},
dataType: OS.DataTypes.DataTypes.Object
},
"mlSZv_0CXESzExVWbXjKUA": {
getter: function (varBag, idService) {
return varBag.getCardInfoJSResult.value;
}
},
"v0AyYie1+0KJtp4ufKw0Eg": {
getter: function (varBag, idService) {
return varBag.vars.value.base64InLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"5N+eeIggXU2rN9wdXZwcaQ": {
getter: function (varBag, idService) {
return varBag.vars.value.contentTypeInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"zbylECErvkGHYjx9fWo1bA": {
getter: function (varBag, idService) {
return varBag.outVars.value.uRLOut;
},
dataType: OS.DataTypes.DataTypes.Text
},
"U9EtbP5t00GCB_IGd7PhMA": {
getter: function (varBag, idService) {
return varBag.base64ToUrlJSResult.value;
}
},
"8rh6t8Qtmk2GcL_ALSb76g": {
getter: function (varBag, idService) {
return varBag.outVars.value.oSOut;
}
},
"bkWQG9dKbke5Lgr2GtOCjg": {
getter: function (varBag, idService) {
return varBag.getOSDeserializeVar.value;
}
},
"1Bd4azlsS0W9+ib7cymnjw": {
getter: function (varBag, idService) {
return varBag.getOSJSResult.value;
}
},
"TZ2S9ZSSxEOTIHA+4Wpmqg": {
getter: function (varBag, idService) {
return varBag.resetJSResult.value;
}
},
"jwj5ixr7GEuwJ7osLW7_xQ": {
getter: function (varBag, idService) {
return varBag.vars.value.userAgentVar;
},
dataType: OS.DataTypes.DataTypes.Text
},
"HJZrHC+iXE+lSba3x+QovA": {
getter: function (varBag, idService) {
return varBag.vars.value.multiTouchVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"twntd_JWMk+xDaWpnODJiA": {
getter: function (varBag, idService) {
return varBag.outVars.value.oSOut;
}
},
"7i5y9o9bB0i1eGdHJvb4Ww": {
getter: function (varBag, idService) {
return varBag.supportsMultiTouchJSResult.value;
}
},
"6GWBJvsgkUaJ44F1w6tygg": {
getter: function (varBag, idService) {
return varBag.outVars.value.orientationOut;
},
dataType: OS.DataTypes.DataTypes.Text
},
"FbobanTpFUCmyboDZc9P_A": {
getter: function (varBag, idService) {
return varBag.getScreenOrientationJSResult.value;
}
},
"4kryXngHcESBvG5q8oE4TA": {
getter: function (varBag, idService) {
return varBag.vars.value.optionsInLocal;
}
},
"l0r4EK+a70GfqBsNNgz37A": {
getter: function (varBag, idService) {
return varBag.base64ToBlobUrlVar.value;
}
},
"sxM6dEiyKUaf7QvW9v1R8w": {
getter: function (varBag, idService) {
return varBag.openPDFJSResult.value;
}
},
"jIA6Msu_xUykS3oUb+fiGg": {
getter: function (varBag, idService) {
return varBag.vars.value.objInLocal;
},
dataType: OS.DataTypes.DataTypes.Object
},
"_i_uk8CtekKoVQ5fG9PS6A": {
getter: function (varBag, idService) {
return varBag.focusJSResult.value;
}
},
"HnL7lgTcXkmMkTOEfFPoBQ": {
getter: function (varBag, idService) {
return varBag.vars.value.objInLocal;
},
dataType: OS.DataTypes.DataTypes.Object
},
"pkMd62vtXEyz+Uoel0MREQ": {
getter: function (varBag, idService) {
return varBag.expiryDateFocusJSResult.value;
}
},
"tnLafnH3z0CQ9XqzN0o7Yg": {
getter: function (varBag, idService) {
return varBag.scrollJSResult.value;
}
},
"l_lrWFcGDkmiO9jOZVplOA": {
getter: function (varBag, idService) {
return varBag.vars.value.objInLocal;
},
dataType: OS.DataTypes.DataTypes.Object
},
"Bn9Rr_VSc0K_d_cN7b613g": {
getter: function (varBag, idService) {
return varBag.submitJSResult.value;
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
