var Callback = (function() {
    var privateCallbacks = [];
    return {
        register: function(func) {
            privateCallbacks.push(func);
        },
        getFirst: function() {
            return privateCallbacks.shift();
            //delete privateCallbacks[index];//.splice(index, 1);
        },
        list: function() {
            return privateCallbacks;
        },
        count: function(){
            return privateCallbacks.length;
        }
    };
})();

function onLoadCallback(){
    var count = Callback.count();
    var callbackAction;
    for(var i = 0; i < count; i++){
        callbackAction = Callback.getFirst();
        if(callbackAction && typeof callbackAction === 'function'){
            callbackAction();
        }
    }
}
