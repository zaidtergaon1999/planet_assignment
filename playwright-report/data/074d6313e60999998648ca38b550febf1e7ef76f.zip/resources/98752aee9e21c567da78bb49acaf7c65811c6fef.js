define("ShopperPortalEU.Refund.RefundDetails.mvc$model", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_API.model", "ShopperPortalEU_Forms_IS.controller", "ShopperPortalEU_UI_Theme.controller", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Components.controller", "ShopperPortalEU.Layouts.LayoutDetail.mvc$model", "ShopperPortalEU.LayoutsComponents.Back.mvc$model", "ShopperPortalEU.Common.DataLoading.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.FullHeightContent.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.Padding.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CardState.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.Flex.mvc$model", "ShopperPortalEU.InternalComponents.RefundDetails_Text_WB.mvc$model", "ShopperPortalEU.InternalComponents.RefundPaymentDetails_WB.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomButton.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomButtonItem.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomList.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomListItem.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CircleIcon.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomPopup.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomPopupLayout.mvc$model", "ShopperPortalEU_Forms_IS.model$FormInfo_WrapperRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Forms_IS", "ShopperPortalEU_UI_Theme.model$LayoutDetailOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU_UI_Components.model$FullHeightContentOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$FullHeightContentTopOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentBottomOptionsRec", "ShopperPortalEU_UI_Components.model$PaddingRec", "ShopperPortalEU_UI_Components.model$PaddingSideOptionsRec", "ShopperPortalEU_UI_Components.model$CardStateOptionsRec", "ShopperPortalEU_UI_Components.model$FlexOptionsRec", "ShopperPortalEU_API.model$RefundDetails_WrapperRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_API", "ShopperPortalEU_Forms_IS.model$RefundDetailsPaymentDetails_UIRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconRec", "ShopperPortalEU_UI_Components.model$CustomListOptionsRec", "ShopperPortalEU_UI_Components.model$CustomListItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomListItemClickableOptionsRec", "ShopperPortalEU_UI_Components.model$CircleIconOptionsRec", "ShopperPortalEU_UI_Components.model$CircleIconIconOptionsRec", "ShopperPortalEU_UI_Components.model$CustomPopupLayoutOptionsRec", "ShopperPortalEU_UI_Components.model$CustomPopupLayoutHeaderImageOptionsRec", "ShopperPortalEU_Forms_IS.controller$GetForm", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", "ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger", "ShopperPortalEU.controller$DefaultErrorMessage", "ShopperPortalEU_UI_Components.model$OpenPDFOptionsRec", "ShopperPortalEU_UI_Components.controller$OpenPDF", "ShopperPortalEU_UI_Components.controller$ResetFocus", "ShopperPortalEU_Forms_IS.controller$GetPDFByFormNumber", "ShopperPortalEU.controller$ClarityEvent", "ShopperPortalEU_API.model$Location_WrapperRec"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEU_Forms_ISModel, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_APIModel, ShopperPortalEU_Forms_ISController, ShopperPortalEU_UI_ThemeController, ShopperPortalEUController, ShopperPortalEU_UI_ComponentsController, ShopperPortalEU_Layouts_LayoutDetail_mvcModel, ShopperPortalEU_LayoutsComponents_Back_mvcModel, ShopperPortalEU_Common_DataLoading_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Padding_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CardState_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvcModel, ShopperPortalEU_InternalComponents_RefundDetails_Text_WB_mvcModel, ShopperPortalEU_InternalComponents_RefundPaymentDetails_WB_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomList_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomListItem_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CircleIcon_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomPopup_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomPopupLayout_mvcModel) {
var OS = OutSystems.Internal;

var GetCountryLocationDataActRec = (function (_super) {
__extends(GetCountryLocationDataActRec, _super);
function GetCountryLocationDataActRec(defaults) {
_super.apply(this, arguments);
}
GetCountryLocationDataActRec.attributesToDeclare = function () {
return [
this.attr("Location", "locationOut", "Location", true, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_APIModel.Location_WrapperRec());
}, true, ShopperPortalEU_APIModel.Location_WrapperRec), 
this.attr("IP", "iPOut", "IP", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
GetCountryLocationDataActRec.init();
return GetCountryLocationDataActRec;
})(OS.Model.DataSourceRecord);

var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("FormRec", "formRecVar", "FormRec", true, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Forms_ISModel.FormInfo_WrapperRec());
}, false, ShopperPortalEU_Forms_ISModel.FormInfo_WrapperRec), 
this.attr("ShowPopup", "showPopupVar", "ShowPopup", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("DisplayAddCardForRefundBtn", "displayAddCardForRefundBtnVar", "DisplayAddCardForRefundBtn", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("IsDataFetched", "isDataFetchedVar", "IsDataFetched", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("FormNumberIn", "formNumberInIn", "FormNumberIn", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, false), 
this.attr("_formNumberInInDataFetchStatus", "_formNumberInInDataFetchStatus", "_formNumberInInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("GetCountryLocation", "getCountryLocationDataAct", "getCountryLocationDataAct", true, true, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new GetCountryLocationDataActRec());
}, true, GetCountryLocationDataActRec)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Model._hasValidationWidgetsValue = undefined;
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
if((Model._hasValidationWidgetsValue === undefined)) {
Model._hasValidationWidgetsValue = (((((((((((((((ShopperPortalEU_Layouts_LayoutDetail_mvcModel.hasValidationWidgets || ShopperPortalEU_LayoutsComponents_Back_mvcModel.hasValidationWidgets) || ShopperPortalEU_Common_DataLoading_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Padding_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CardState_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvcModel.hasValidationWidgets) || ShopperPortalEU_InternalComponents_RefundDetails_Text_WB_mvcModel.hasValidationWidgets) || ShopperPortalEU_InternalComponents_RefundPaymentDetails_WB_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomList_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomListItem_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CircleIcon_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomPopup_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomPopupLayout_mvcModel.hasValidationWidgets);
}

return Model._hasValidationWidgetsValue;
}
});

Model.prototype.setInputs = function (inputs) {
if("FormNumberIn" in inputs) {
this.variables.formNumberInIn = OS.DataConversion.ServerDataConverter.from(inputs.FormNumberIn, OS.DataTypes.DataTypes.Text);
}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "Refund.RefundDetails");
});
define("ShopperPortalEU.Refund.RefundDetails.mvc$view", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_API.model", "ShopperPortalEU_Forms_IS.controller", "ShopperPortalEU_UI_Theme.controller", "ShopperPortalEU_UI_Components.controller", "react", "OutSystems/ReactView/Main", "ShopperPortalEU.Refund.RefundDetails.mvc$model", "ShopperPortalEU.Refund.RefundDetails.mvc$controller", "ShopperPortalEU.clientVariables", "ShopperPortalEU.Layouts.LayoutDetail.mvc$view", "OutSystems/ReactWidgets/Main", "ShopperPortalEU.LayoutsComponents.Back.mvc$view", "ShopperPortalEU.Common.DataLoading.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.FullHeightContent.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.Padding.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CardState.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.Flex.mvc$view", "ShopperPortalEU.InternalComponents.RefundDetails_Text_WB.mvc$view", "ShopperPortalEU.InternalComponents.RefundPaymentDetails_WB.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomButton.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomButtonItem.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomList.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomListItem.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CircleIcon.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomPopup.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomPopupLayout.mvc$view", "ShopperPortalEU_Forms_IS.model$FormInfo_WrapperRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Forms_IS", "ShopperPortalEU_UI_Theme.model$LayoutDetailOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU_UI_Components.model$FullHeightContentOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$FullHeightContentTopOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentBottomOptionsRec", "ShopperPortalEU_UI_Components.model$PaddingRec", "ShopperPortalEU_UI_Components.model$PaddingSideOptionsRec", "ShopperPortalEU_UI_Components.model$CardStateOptionsRec", "ShopperPortalEU_UI_Components.model$FlexOptionsRec", "ShopperPortalEU_API.model$RefundDetails_WrapperRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_API", "ShopperPortalEU_Forms_IS.model$RefundDetailsPaymentDetails_UIRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconRec", "ShopperPortalEU_UI_Components.model$CustomListOptionsRec", "ShopperPortalEU_UI_Components.model$CustomListItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomListItemClickableOptionsRec", "ShopperPortalEU_UI_Components.model$CircleIconOptionsRec", "ShopperPortalEU_UI_Components.model$CircleIconIconOptionsRec", "ShopperPortalEU_UI_Components.model$CustomPopupLayoutOptionsRec", "ShopperPortalEU_UI_Components.model$CustomPopupLayoutHeaderImageOptionsRec", "ShopperPortalEU_Forms_IS.controller$GetForm", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", "ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger", "ShopperPortalEU.controller$DefaultErrorMessage", "ShopperPortalEU_UI_Components.model$OpenPDFOptionsRec", "ShopperPortalEU_UI_Components.controller$OpenPDF", "ShopperPortalEU_UI_Components.controller$ResetFocus", "ShopperPortalEU_Forms_IS.controller$GetPDFByFormNumber", "ShopperPortalEU.controller$ClarityEvent", "ShopperPortalEU_API.model$Location_WrapperRec"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_Forms_ISModel, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_APIModel, ShopperPortalEU_Forms_ISController, ShopperPortalEU_UI_ThemeController, ShopperPortalEU_UI_ComponentsController, React, OSView, ShopperPortalEU_Refund_RefundDetails_mvc_model, ShopperPortalEU_Refund_RefundDetails_mvc_controller, ShopperPortalEUClientVariables, ShopperPortalEU_Layouts_LayoutDetail_mvc_view, OSWidgets, ShopperPortalEU_LayoutsComponents_Back_mvc_view, ShopperPortalEU_Common_DataLoading_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Padding_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CardState_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, ShopperPortalEU_InternalComponents_RefundDetails_Text_WB_mvc_view, ShopperPortalEU_InternalComponents_RefundPaymentDetails_WB_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomList_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomListItem_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CircleIcon_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomPopup_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomPopupLayout_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            var thisIsInstanceOfSuper = this instanceof _super;
            if (thisIsInstanceOfSuper == false) {
                return;
            }

            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "Refund.RefundDetails";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css", "css/ShopperPortalEU_UI_Theme.ShopperPortalEUUITheme.css", "css/ShopperPortalEU.ShopperPortalEU.css", "css/ShopperPortalEU_UI_Theme.ShopperPortalEUUITheme.extra.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [ShopperPortalEU_Layouts_LayoutDetail_mvc_view, ShopperPortalEU_LayoutsComponents_Back_mvc_view, ShopperPortalEU_Common_DataLoading_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Padding_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CardState_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, ShopperPortalEU_InternalComponents_RefundDetails_Text_WB_mvc_view, ShopperPortalEU_InternalComponents_RefundPaymentDetails_WB_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomList_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomListItem_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CircleIcon_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomPopup_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomPopupLayout_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return ShopperPortalEU_Refund_RefundDetails_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return ShopperPortalEU_Refund_RefundDetails_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "Shopper Portal EU - Refund Details";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(ShopperPortalEU_Layouts_LayoutDetail_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("P9HTgSbqOEuri6yggLk_0g.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ThemeModel.LayoutDetailOptionsRec();
rec.noPaddingAttr = true;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "0",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
headerLeft: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_LayoutsComponents_Back_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "1",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}),
headerCenter: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "RefundDetails_RefundDetails"
},
value: "Refund details",
_idProps: {
service: idService,
uuid: "2"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
headerRight: PlaceholderContent.Empty,
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_Common_DataLoading_mvc_view, {
inputs: {
IsDataFetched: model.variables.isDataFetchedVar
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "3",
alias: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("9UJtEj95q0Cbl8adkthKug.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FullHeightContentOptionsRec();
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space4;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "4",
alias: "4"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
top: new PlaceholderContent(function () {
return [$if((((model.variables.formRecVar.formNumberAttr) !== ("")) && ((model.variables.formRecVar.formNumberAttr) !== (" "))), false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "5"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Padding_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("_PYdd9D52UW9cSqkG7Wf5Q.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.PaddingRec();
rec.rightAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.PaddingSideOptionsRec();
rec.layoutAttr = true;
return rec;
}();
rec.leftAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.PaddingSideOptionsRec();
rec.layoutAttr = true;
return rec;
}();
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "6",
alias: "5"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CardState_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("b1UnD_ExR0Sl3caSwhxBhQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CardStateOptionsRec();
rec.typeAttr = model.variables.formRecVar.formDetailsAttr.cardStateTypeIdAttr;
rec.clickableAttr = model.variables.formRecVar.uIConfigurationAttr.hasRefundStepsPageAttr;
rec.testIdAttr = "RefundDetails_Card";
return rec;
}();
}, function () {
return model.variables.formRecVar.formDetailsAttr.cardStateTypeIdAttr;
}, function () {
return model.variables.formRecVar.uIConfigurationAttr.hasRefundStepsPageAttr;
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onClick$Action: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ShopperPortalEUUIComponents/CardState OnClick");
controller.cardClick$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "7",
alias: "6"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "RefundDetails_Merchant"
},
style: "heading6 text-primary-black",
value: model.variables.formRecVar.merchantNameAttr,
_idProps: {
service: idService,
uuid: "8"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-top-02",
visible: true,
_idProps: {
service: idService,
uuid: "9"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "RefundDetails_FormNumber"
},
style: "body-4",
value: ("ID: " + model.variables.formRecVar.formNumberFormattedAttr),
_idProps: {
service: idService,
uuid: "10"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("CPIh05lt5ki4f4X2py+8cQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.justifyAttr = ShopperPortalEUModel.staticEntities.flexJustify.spaceBetween;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
rec.wrapAttr = false;
return rec;
}();
}),
ExtendedClass: "margin-top-02"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "11",
alias: "7"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "RefundDetails_EstimatedRefund"
},
style: "white-space-no-wrap text-primary-35",
value: model.variables.formRecVar.refundLabel_UIAttr,
_idProps: {
service: idService,
uuid: "12"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "text-align-right",
visible: true,
_idProps: {
service: idService,
uuid: "13"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "RefundDetails_RefundAmount"
},
style: "heading6 text-primary-black white-space-no-wrap",
value: model.variables.formRecVar.refundAmountTxtAttr,
_idProps: {
service: idService,
uuid: "14"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "15"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "RefundDetails_FeeRefundLabel"
},
style: "white-space-no-wrap body-4 text-primary-35",
value: model.variables.formRecVar.refundAmountMessageAttr,
_idProps: {
service: idService,
uuid: "16"
},
_widgetRecordProvider: widgetsRecordProvider
})))];
})
},
_dependencies: [asPrimitiveValue(model.variables.formRecVar.refundAmountMessageAttr), asPrimitiveValue(model.variables.formRecVar.refundAmountTxtAttr), asPrimitiveValue(model.variables.formRecVar.refundLabel_UIAttr)]
})];
}),
stateContent: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_InternalComponents_RefundDetails_Text_WB_mvc_view, {
inputs: {
Country: model.variables.getCountryLocationDataAct.locationOut.countryAttr,
_countryInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getCountryLocationDataAct.dataFetchStatusAttr),
FormStatusId: model.variables.formRecVar.formDetailsAttr.formStatusIdAttr,
CC4Digits: model.getCachedValue(idService.getId("KZVyDtQv8k2_t0YLGmmm3A.CC4Digits"), function () {
return OS.BuiltinFunctions.substr(model.variables.formRecVar.refundDetailsAttr.paymentAccountAttr, (OS.BuiltinFunctions.length(model.variables.formRecVar.refundDetailsAttr.paymentAccountAttr) - 4), 4);
}, function () {
return model.variables.formRecVar.refundDetailsAttr.paymentAccountAttr;
}),
FormStatusLabel: model.variables.formRecVar.formStatusLabelAttr
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "17",
alias: "8"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.getCountryLocationDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.getCountryLocationDataAct.locationOut.countryAttr), asPrimitiveValue(model.variables.formRecVar.formStatusLabelAttr), asPrimitiveValue(model.variables.formRecVar.refundDetailsAttr.paymentAccountAttr), asPrimitiveValue(model.variables.formRecVar.formDetailsAttr.formStatusIdAttr), asPrimitiveValue(model.variables.formRecVar.refundAmountMessageAttr), asPrimitiveValue(model.variables.formRecVar.refundAmountTxtAttr), asPrimitiveValue(model.variables.formRecVar.refundLabel_UIAttr), asPrimitiveValue(model.variables.formRecVar.formNumberFormattedAttr), asPrimitiveValue(model.variables.formRecVar.merchantNameAttr)]
}), $if(model.variables.formRecVar.uIConfigurationAttr.displayRefundPaymentsDetails_UIAttr, false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-top-06",
visible: true,
_idProps: {
service: idService,
uuid: "18"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_InternalComponents_RefundPaymentDetails_WB_mvc_view, {
inputs: {
RefundDetails: model.getCachedValue(idService.getId("X3TDTG9n7UCabMoMpd2Q4g.RefundDetails"), function () {
return OS.DataConversion.JSConversions.typeConvertRecord(model.variables.formRecVar.refundDetailsAttr, new ShopperPortalEU_APIModel.RefundDetails_WrapperRec(), function (source, target) {
target.paymentTypeAttr = source.paymentTypeAttr;
target.paymentAccountAttr = source.paymentAccountAttr;
target.paidOnAttr = source.paidOnAttr;
target.acquirerRefAttr = source.acquirerRefAttr;
target.locationAttr = source.locationAttr;
return target;
});
}, function () {
return model.variables.formRecVar.refundDetailsAttr;
}),
RefundDetailsPaymentDetails_UI: model.variables.formRecVar.uIConfigurationAttr.refundDetailsPaymentDetails_UIAttr
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "19",
alias: "9"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}))];
}, function () {
return [];
}), $if(model.variables.formRecVar.uIConfigurationAttr.displayRefundPaymentsInfo_WheresMyRefundAttr, false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-top-05",
visible: true,
_idProps: {
service: idService,
uuid: "20"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("rvj0rMe0R0a_mXwUp5ts9Q.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRec();
rec.testIdAttr = "RefundDetails_WhereIsMyRefund_Button";
rec.typeAttr = ShopperPortalEUModel.staticEntities.customButtonType.linkPrimary;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "21",
alias: "10"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
button: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: false,
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Refund/RefundDetails/Button OnClick");
controller.togglePopup$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn",
visible: true,
_idProps: {
service: idService,
uuid: "22"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("xLtup66aTUW37V_TqlRkww.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonItemOptionsRec();
rec.iconAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsIconRec();
rec.nameAttr = "help";
return rec;
}();
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "23",
alias: "11"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "RefundDetails_WhereIsMyRefund_Button_Label"
},
value: "Where\'s my refund?",
_idProps: {
service: idService,
uuid: "24"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
}))];
}, function () {
return [];
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.getCountryLocationDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.getCountryLocationDataAct.locationOut.countryAttr), asPrimitiveValue(model.variables.formRecVar.formStatusLabelAttr), asPrimitiveValue(model.variables.formRecVar.refundDetailsAttr), asPrimitiveValue(model.variables.formRecVar.refundAmountMessageAttr), asPrimitiveValue(model.variables.formRecVar.refundAmountTxtAttr), asPrimitiveValue(model.variables.formRecVar.refundLabel_UIAttr), asPrimitiveValue(model.variables.formRecVar.formNumberFormattedAttr), asPrimitiveValue(model.variables.formRecVar.merchantNameAttr), asPrimitiveValue(model.variables.formRecVar.uIConfigurationAttr.displayRefundPaymentsInfo_WheresMyRefundAttr), asPrimitiveValue(model.variables.formRecVar.uIConfigurationAttr.refundDetailsPaymentDetails_UIAttr), asPrimitiveValue(model.variables.formRecVar.uIConfigurationAttr.displayRefundPaymentsDetails_UIAttr), asPrimitiveValue(model.variables.formRecVar.uIConfigurationAttr.hasRefundStepsPageAttr), asPrimitiveValue(model.variables.formRecVar.formDetailsAttr.formStatusIdAttr), asPrimitiveValue(model.variables.formRecVar.formDetailsAttr.cardStateTypeIdAttr)]
}), $if((model.variables.formRecVar.uIConfigurationAttr.displayBarcode_UIAttr || model.variables.formRecVar.uIConfigurationAttr.displayViewForm_UIAttr), false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-top-06",
visible: true,
_idProps: {
service: idService,
uuid: "25"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Padding_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("3II7LpSlHU6TCNUS0kK49g.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.PaddingRec();
rec.rightAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.PaddingSideOptionsRec();
rec.layoutAttr = true;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space4;
return rec;
}();
rec.leftAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.PaddingSideOptionsRec();
rec.layoutAttr = true;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space4;
return rec;
}();
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "26",
alias: "12"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "RefundDetails_TaxRefundFormDetails"
},
style: "heading6",
value: "Tax Free form details",
_idProps: {
service: idService,
uuid: "27"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomList_mvc_view, {
inputs: {
ExtendedClass: "margin-top-02",
Options: model.getCachedValue(idService.getId("WNclYSpW4EaEmLeycJkdRw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomListOptionsRec();
rec.horizontalPaddingAttr = ShopperPortalEUModel.staticEntities.spacing.space4;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "28",
alias: "13"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
list: new PlaceholderContent(function () {
return [$if(model.variables.formRecVar.uIConfigurationAttr.displayBarcode_UIAttr, false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomListItem_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("CustomListItem_ViewBarcode.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomListItemOptionsRec();
rec.testIdAttr = "ViewBarcode_Link";
rec.clickableAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomListItemClickableOptionsRec();
rec.clickableAttr = true;
return rec;
}();
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onClick$Action: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ShopperPortalEUUIComponents/CustomListItem OnClick");
controller.customListItem_ViewBarcodeOnClick$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
name: "CustomListItem_ViewBarcode",
alias: "14"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
left: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CircleIcon_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("8mZK7IrYPUm0auA3dVISPg.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CircleIconOptionsRec();
rec.iconAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CircleIconIconOptionsRec();
rec.nameAttr = "barcode_scanner";
return rec;
}();
rec.softRadiusAttr = true;
rec.testIdAttr = "viewBarcodeIcon";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "30",
alias: "15"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}),
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "RefundDetails_ViewBarcode"
},
value: "View barcode",
_idProps: {
service: idService,
uuid: "31"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
})];
}, function () {
return [];
}), $if(model.variables.formRecVar.uIConfigurationAttr.displayViewForm_UIAttr, false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomListItem_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("CustomListItem_ViewForm.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomListItemOptionsRec();
rec.testIdAttr = "ViewForm_Link";
rec.clickableAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomListItemClickableOptionsRec();
rec.clickableAttr = true;
rec.iconAttr = "open_in_new";
return rec;
}();
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onClick$Action: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ShopperPortalEUUIComponents/CustomListItem OnClick");
return controller.formPdfClick$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
name: "CustomListItem_ViewForm",
alias: "16"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
left: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CircleIcon_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("qVfFhlf+sk6uvCL826Ab7Q.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CircleIconOptionsRec();
rec.iconAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CircleIconIconOptionsRec();
rec.nameAttr = "draft";
return rec;
}();
rec.softRadiusAttr = true;
rec.testIdAttr = "viewFromIcon";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "33",
alias: "17"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}),
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "RefundDetails_ViewForm"
},
value: "View form",
_idProps: {
service: idService,
uuid: "34"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
})];
}, function () {
return [];
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.formRecVar.uIConfigurationAttr.displayViewForm_UIAttr), asPrimitiveValue(model.variables.formRecVar.uIConfigurationAttr.displayBarcode_UIAttr)]
}))];
}, function () {
return [];
}))];
}, function () {
return [];
})];
}),
bottom: new PlaceholderContent(function () {
return [$if(model.variables.displayAddCardForRefundBtnVar, false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Padding_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("qWeFFA1eckWUnOS2TlD6FQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.PaddingRec();
rec.rightAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.PaddingSideOptionsRec();
rec.layoutAttr = true;
return rec;
}();
rec.leftAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.PaddingSideOptionsRec();
rec.layoutAttr = true;
return rec;
}();
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "35",
alias: "18"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("HwlttFfoLEqZ3SXU+b2Muw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRec();
rec.testIdAttr = "AddCardButtonFromRefundDetails";
rec.typeAttr = ShopperPortalEUModel.staticEntities.customButtonType.secondary;
rec.isFullWidthAttr = true;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "36",
alias: "19"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
button: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: false,
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Refund/RefundDetails/Button OnClick");
controller.addCardForRefundOnClick$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn",
visible: true,
_idProps: {
service: idService,
uuid: "37"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "38",
alias: "20"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Add card for refund",
_idProps: {
service: idService,
uuid: "39"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
})];
})
},
_dependencies: []
})];
}, function () {
return [];
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.displayAddCardForRefundBtnVar), asPrimitiveValue(model.variables.getCountryLocationDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.getCountryLocationDataAct.locationOut.countryAttr), asPrimitiveValue(model.variables.formRecVar.formStatusLabelAttr), asPrimitiveValue(model.variables.formRecVar.refundDetailsAttr), asPrimitiveValue(model.variables.formRecVar.refundAmountMessageAttr), asPrimitiveValue(model.variables.formRecVar.refundAmountTxtAttr), asPrimitiveValue(model.variables.formRecVar.refundLabel_UIAttr), asPrimitiveValue(model.variables.formRecVar.formNumberFormattedAttr), asPrimitiveValue(model.variables.formRecVar.merchantNameAttr), asPrimitiveValue(model.variables.formRecVar.uIConfigurationAttr.displayViewForm_UIAttr), asPrimitiveValue(model.variables.formRecVar.uIConfigurationAttr.displayBarcode_UIAttr), asPrimitiveValue(model.variables.formRecVar.uIConfigurationAttr.displayRefundPaymentsInfo_WheresMyRefundAttr), asPrimitiveValue(model.variables.formRecVar.uIConfigurationAttr.refundDetailsPaymentDetails_UIAttr), asPrimitiveValue(model.variables.formRecVar.uIConfigurationAttr.displayRefundPaymentsDetails_UIAttr), asPrimitiveValue(model.variables.formRecVar.uIConfigurationAttr.hasRefundStepsPageAttr), asPrimitiveValue(model.variables.formRecVar.formDetailsAttr.formStatusIdAttr), asPrimitiveValue(model.variables.formRecVar.formDetailsAttr.cardStateTypeIdAttr), asPrimitiveValue(model.variables.formRecVar.formNumberAttr)]
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.displayAddCardForRefundBtnVar), asPrimitiveValue(model.variables.getCountryLocationDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.getCountryLocationDataAct.locationOut.countryAttr), asPrimitiveValue(model.variables.formRecVar.formStatusLabelAttr), asPrimitiveValue(model.variables.formRecVar.refundDetailsAttr), asPrimitiveValue(model.variables.formRecVar.refundAmountMessageAttr), asPrimitiveValue(model.variables.formRecVar.refundAmountTxtAttr), asPrimitiveValue(model.variables.formRecVar.refundLabel_UIAttr), asPrimitiveValue(model.variables.formRecVar.formNumberFormattedAttr), asPrimitiveValue(model.variables.formRecVar.merchantNameAttr), asPrimitiveValue(model.variables.formRecVar.uIConfigurationAttr.displayViewForm_UIAttr), asPrimitiveValue(model.variables.formRecVar.uIConfigurationAttr.displayBarcode_UIAttr), asPrimitiveValue(model.variables.formRecVar.uIConfigurationAttr.displayRefundPaymentsInfo_WheresMyRefundAttr), asPrimitiveValue(model.variables.formRecVar.uIConfigurationAttr.refundDetailsPaymentDetails_UIAttr), asPrimitiveValue(model.variables.formRecVar.uIConfigurationAttr.displayRefundPaymentsDetails_UIAttr), asPrimitiveValue(model.variables.formRecVar.uIConfigurationAttr.hasRefundStepsPageAttr), asPrimitiveValue(model.variables.formRecVar.formDetailsAttr.formStatusIdAttr), asPrimitiveValue(model.variables.formRecVar.formDetailsAttr.cardStateTypeIdAttr), asPrimitiveValue(model.variables.formRecVar.formNumberAttr)]
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomPopup_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "40",
alias: "21"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
popup: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Popup, {
showPopup: model.variables.showPopupVar,
style: "popup-dialog",
_idProps: {
service: idService,
uuid: "41"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomPopupLayout_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onOverlayClick$Action: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ShopperPortalEUUIComponents/CustomPopupLayout OnOverlayClick");
controller.togglePopup$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "42",
alias: "22"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
title: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "RefundDetails_WhereIsMyRefund_PopUp_Title"
},
value: "Where\'s my refund?",
_idProps: {
service: idService,
uuid: "43"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "RefundDetails_WhereIsMyRefund_PopUp_Text"
},
value: (("If you still have not received your refund, please contact your bank and provide the Acquirer reference (ARN) " + model.variables.formRecVar.refundDetailsAttr.acquirerRefAttr) + " for a further check."),
_idProps: {
service: idService,
uuid: "44"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
actions: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("Fd_xLzmHLU6i59E4_0yeLg.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.justifyAttr = ShopperPortalEUModel.staticEntities.flexJustify.center;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.none;
rec.wrapAttr = false;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "45",
alias: "23"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("sV0XEVK4xE+HjgzgmlMrmQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customButtonType.primary;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "46",
alias: "24"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
button: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: false,
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Refund/RefundDetails/Button OnClick");
controller.togglePopup$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn",
visible: true,
_idProps: {
service: idService,
uuid: "47"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "48",
alias: "25"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Close",
_idProps: {
service: idService,
uuid: "49"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
})];
})
},
_dependencies: []
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.formRecVar.refundDetailsAttr.acquirerRefAttr)]
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables.formRecVar.refundDetailsAttr.acquirerRefAttr), asPrimitiveValue(model.variables.showPopupVar)]
})];
}),
bottom: PlaceholderContent.Empty
},
_dependencies: [asPrimitiveValue(model.variables.showPopupVar), asPrimitiveValue(model.variables.displayAddCardForRefundBtnVar), asPrimitiveValue(model.variables.getCountryLocationDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.getCountryLocationDataAct.locationOut.countryAttr), asPrimitiveValue(model.variables.formRecVar.formStatusLabelAttr), asPrimitiveValue(model.variables.formRecVar.refundDetailsAttr), asPrimitiveValue(model.variables.formRecVar.refundAmountMessageAttr), asPrimitiveValue(model.variables.formRecVar.refundAmountTxtAttr), asPrimitiveValue(model.variables.formRecVar.refundLabel_UIAttr), asPrimitiveValue(model.variables.formRecVar.formNumberFormattedAttr), asPrimitiveValue(model.variables.formRecVar.merchantNameAttr), asPrimitiveValue(model.variables.formRecVar.uIConfigurationAttr.displayViewForm_UIAttr), asPrimitiveValue(model.variables.formRecVar.uIConfigurationAttr.displayBarcode_UIAttr), asPrimitiveValue(model.variables.formRecVar.uIConfigurationAttr.displayRefundPaymentsInfo_WheresMyRefundAttr), asPrimitiveValue(model.variables.formRecVar.uIConfigurationAttr.refundDetailsPaymentDetails_UIAttr), asPrimitiveValue(model.variables.formRecVar.uIConfigurationAttr.displayRefundPaymentsDetails_UIAttr), asPrimitiveValue(model.variables.formRecVar.uIConfigurationAttr.hasRefundStepsPageAttr), asPrimitiveValue(model.variables.formRecVar.formDetailsAttr.formStatusIdAttr), asPrimitiveValue(model.variables.formRecVar.formDetailsAttr.cardStateTypeIdAttr), asPrimitiveValue(model.variables.formRecVar.formNumberAttr), asPrimitiveValue(model.variables.isDataFetchedVar)]
}));
        };
        return View;
    })(OSView.BaseView.BaseWebScreen);
	
    return View;
});
define("ShopperPortalEU.Refund.RefundDetails.mvc$controller", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_API.model", "ShopperPortalEU_Forms_IS.controller", "ShopperPortalEU_UI_Theme.controller", "ShopperPortalEU_UI_Components.controller", "ShopperPortalEU.languageResources", "ShopperPortalEU.clientVariables", "ShopperPortalEU.Refund.RefundDetails.mvc$debugger", "ShopperPortalEU.Refund.controller", "ShopperPortalEU_Forms_IS.model$FormInfo_WrapperRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Forms_IS", "ShopperPortalEU_UI_Theme.model$LayoutDetailOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU_UI_Components.model$FullHeightContentOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$FullHeightContentTopOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentBottomOptionsRec", "ShopperPortalEU_UI_Components.model$PaddingRec", "ShopperPortalEU_UI_Components.model$PaddingSideOptionsRec", "ShopperPortalEU_UI_Components.model$CardStateOptionsRec", "ShopperPortalEU_UI_Components.model$FlexOptionsRec", "ShopperPortalEU_API.model$RefundDetails_WrapperRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_API", "ShopperPortalEU_Forms_IS.model$RefundDetailsPaymentDetails_UIRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconRec", "ShopperPortalEU_UI_Components.model$CustomListOptionsRec", "ShopperPortalEU_UI_Components.model$CustomListItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomListItemClickableOptionsRec", "ShopperPortalEU_UI_Components.model$CircleIconOptionsRec", "ShopperPortalEU_UI_Components.model$CircleIconIconOptionsRec", "ShopperPortalEU_UI_Components.model$CustomPopupLayoutOptionsRec", "ShopperPortalEU_UI_Components.model$CustomPopupLayoutHeaderImageOptionsRec", "ShopperPortalEU_Forms_IS.controller$GetForm", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", "ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger", "ShopperPortalEU.controller$DefaultErrorMessage", "ShopperPortalEU_UI_Components.model$OpenPDFOptionsRec", "ShopperPortalEU_UI_Components.controller$OpenPDF", "ShopperPortalEU_UI_Components.controller$ResetFocus", "ShopperPortalEU_Forms_IS.controller$GetPDFByFormNumber", "ShopperPortalEU.controller$ClarityEvent", "ShopperPortalEU_API.model$Location_WrapperRec"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_Forms_ISModel, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_APIModel, ShopperPortalEU_Forms_ISController, ShopperPortalEU_UI_ThemeController, ShopperPortalEU_UI_ComponentsController, ShopperPortalEULanguageResources, ShopperPortalEUClientVariables, ShopperPortalEU_Refund_RefundDetails_mvc_Debugger, ShopperPortalEU_RefundController) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {
getCountryLocation$DataActRefresh: 0
};
this.dataFetchDependentsGraph = {
getCountryLocation$DataActRefresh: []
};
this.shouldSendClientVarsToDataSources = true;
}
// Server Actions

// Aggregates and Data Actions
Controller.prototype.getCountryLocation$DataActRefresh = function (callContext) {
var model = this.model;
var controller = this.controller;
var callContext = controller.callContext(callContext);
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:FcEhyECP+kmcVIIBkwzTTg:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.05pm1Xjpy0ye5EaE3tg36Q/DataActions.FcEhyECP+kmcVIIBkwzTTg:vG8BD_CSxsP9mmQf7zI5sg", "ShopperPortalEU", "GetCountryLocation", "NRFlows.DataScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.setThreadStartName(callContext.id, "Refund/RefundDetails/GetCountryLocation");
return controller.callDataAction("DataActionGetCountryLocation", "screenservices/ShopperPortalEU/Refund/RefundDetails/DataActionGetCountryLocation", "+igZtEmyCNRPE4CD4Z09iw", function (b) {
model.variables.getCountryLocationDataAct.dataFetchStatusAttr = b;
}, function (json) {
model.variables.getCountryLocationDataAct.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getCountryLocationDataAct.constructor));
}, undefined, OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, callContext, ShopperPortalEUClientVariables, false);

}, function () {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:FcEhyECP+kmcVIIBkwzTTg", callContext.id);
controller.popDebuggerContext(callContext);

});
};

Controller.prototype.dataFetchActionNames = ["getCountryLocation$DataActRefresh"];
// Client Actions
Controller.prototype._togglePopup$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("TogglePopup");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:6xtYCv8oE0CBkG3Ez2znMw:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.05pm1Xjpy0ye5EaE3tg36Q/ClientActions.6xtYCv8oE0CBkG3Ez2znMw:R56n6QuGSnGEN9JyfMc1Fw", "ShopperPortalEU", "TogglePopup", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:6hOUpdFkjE+DX8V1M9lpzA", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:aFFSM1ja+kmIVOXTO1QfZw", callContext.id);
// ShowPopup = notShowPopup
model.variables.showPopupVar = !(model.variables.showPopupVar);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:FmQLKYf400WlQ5pH927Hyg", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:6xtYCv8oE0CBkG3Ez2znMw", callContext.id);
}

};
Controller.prototype._onReady$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnReady");
callContext = controller.callContext(callContext);
var getFormVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.getFormVar = getFormVar;
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:O4BwCqyCzU+tIuLON3r19g:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.05pm1Xjpy0ye5EaE3tg36Q/ClientActions.O4BwCqyCzU+tIuLON3r19g:fMLrKh8_on1N0n+42kQeoA", "ShopperPortalEU", "OnReady", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:jePerJPN30u_b4tQB+wbrw", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:q_cYP0eQJUehiS9Tf4fxVg", callContext.id);
// Execute Action: GetForm
model.flush();
return ShopperPortalEU_Forms_ISController.default.getForm$Action(model.variables.formNumberInIn, callContext).then(function (value) {
getFormVar.value = value;
}).then(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:fHzYVUopkUqci5IKqW5rXw", callContext.id) && !(getFormVar.value.successOut))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:0X4iBXQKiUaML2+sRV0RYw", callContext.id);
// FormRec.FormNumber = " "
model.variables.formRecVar.formNumberAttr = " ";
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:b9Ta+YDM9EehWBXQpWKKxg", callContext.id);
// Execute Action: CustomMessageTrigger
ShopperPortalEU_UI_ThemeController.default.customMessageTrigger$Action(function () {
var rec = new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customMessageType.error;
rec.titleAttr = "We couldn\'t load the form";
rec.contentAttr = OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.defaultErrorMessage$Action(callContext).errorMessageOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
rec.testIdAttr = "Error";
return rec;
}(), callContext);
}

// Set vars
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:9pcvDtJDQ0yHk3r2VzA5lg", callContext.id);
// FormRec = GetForm.FormInfo
model.variables.formRecVar = getFormVar.value.formInfoOut;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:9pcvDtJDQ0yHk3r2VzA5lg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// FormNumberRA1 = If
ShopperPortalEUClientVariables.setFormNumberRA1((((getFormVar.value.formInfoOut.formDetailsAttr.formStatusIdAttr === ShopperPortalEUModel.staticEntities.sPFormStatus.postRefundDetailsRequired)) ? (getFormVar.value.formInfoOut.formNumberAttr) : (ShopperPortalEUClientVariables.getFormNumberRA1())));
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:9pcvDtJDQ0yHk3r2VzA5lg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// FormNumberVA1 = If
ShopperPortalEUClientVariables.setFormNumberVA1((((getFormVar.value.formInfoOut.formDetailsAttr.formStatusIdAttr === ShopperPortalEUModel.staticEntities.sPFormStatus.postGetCustomsApproval)) ? (getFormVar.value.formInfoOut.formNumberAttr) : (ShopperPortalEUClientVariables.getFormNumberVA1())));
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:9pcvDtJDQ0yHk3r2VzA5lg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// FormNumberVA2 = If
ShopperPortalEUClientVariables.setFormNumberVA2((((getFormVar.value.formInfoOut.formDetailsAttr.formStatusIdAttr === ShopperPortalEUModel.staticEntities.sPFormStatus.postCustomsInspectionRequired)) ? (getFormVar.value.formInfoOut.formNumberAttr) : (ShopperPortalEUClientVariables.getFormNumberVA2())));
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:9pcvDtJDQ0yHk3r2VzA5lg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// DisplayAddCardForRefundBtn = GetForm.FormInfo.IsReadyForRefund and notIsFormRequestRefundTriggered and FormRec.FormDetails.FormStatusId <> PostRefundDetailsRequired
model.variables.displayAddCardForRefundBtnVar = ((getFormVar.value.formInfoOut.isReadyForRefundAttr && !(ShopperPortalEUClientVariables.getIsFormRequestRefundTriggered())) && ((model.variables.formRecVar.formDetailsAttr.formStatusIdAttr) !== (ShopperPortalEUModel.staticEntities.sPFormStatus.postRefundDetailsRequired)));
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:9pcvDtJDQ0yHk3r2VzA5lg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "6");
// IsFromFormDetailsOrStepScreen = False
ShopperPortalEUClientVariables.setIsFromFormDetailsOrStepScreen(false);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:9pcvDtJDQ0yHk3r2VzA5lg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "7");
// IsDataFetched = True
model.variables.isDataFetchedVar = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ufkhChwAd0+21YUmLPXZLA", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:O4BwCqyCzU+tIuLON3r19g", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:O4BwCqyCzU+tIuLON3r19g", callContext.id);
throw ex;

});
};
Controller.prototype._cardClick$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("CardClick");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:gt+iSudM_kygBElZgcuy8w:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.05pm1Xjpy0ye5EaE3tg36Q/ClientActions.gt+iSudM_kygBElZgcuy8w:jaBtvf1Fp7uzV7K3K_iz6Q", "ShopperPortalEU", "CardClick", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:j6vTPrAyfEeI1T5MOoiXVw", callContext.id);
// HasRefundStepsPage
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:qOGwvIOB4EquXpCOBpMYGA", callContext.id) && model.variables.formRecVar.uIConfigurationAttr.hasRefundStepsPageAttr)) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:T8Rn0tUjq0yzRwonPN8m0w", callContext.id);
// Destination: /ShopperPortalEU/RefundSteps
return OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "RefundSteps", {
FormStatusLabel: OS.DataConversion.ServerDataConverter.asString(model.variables.formRecVar.formStatusLabelAttr, OS.DataTypes.DataTypes.Text),
FormStatusId: OS.DataConversion.ServerDataConverter.asString(model.variables.formRecVar.formDetailsAttr.formStatusIdAttr, OS.DataTypes.DataTypes.Text)
}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true);
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:L+BDqAgMV0u8lRAzTE2_nQ", callContext.id);
}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:gt+iSudM_kygBElZgcuy8w", callContext.id);
}

};
Controller.prototype._formPdfClick$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("FormPdfClick");
callContext = controller.callContext(callContext);
var allExceptionsVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.ErrorHandlerOutputType());
var getPDFByFormNumberVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.allExceptionsVar = allExceptionsVar;
varBag.getPDFByFormNumberVar = getPDFByFormNumberVar;
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:kfC8hSvgAkqBV18xDWtezg:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.05pm1Xjpy0ye5EaE3tg36Q/ClientActions.kfC8hSvgAkqBV18xDWtezg:2TfV87at2VOPwQ+y6vejNQ", "ShopperPortalEU", "FormPdfClick", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:zKaPGxQVwE+Dyu+MbdTN+w", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:IPHt_QotIkOobBDaa0iJRg", callContext.id);
// Execute Action: GetPDFByFormNumber
model.flush();
return ShopperPortalEU_Forms_ISController.default.getPDFByFormNumber$Action(model.variables.formRecVar.formNumberAttr, callContext).then(function (value) {
getPDFByFormNumberVar.value = value;
}).then(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:10iURWVxj0aAd0zrzyoCbw", callContext.id);
// Execute Action: OpenPDF
ShopperPortalEU_UI_ComponentsController.default.openPDF$Action(function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.OpenPDFOptionsRec();
rec.pDFAttr = getPDFByFormNumberVar.value.pDFOut;
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:rzn4ymWFRUaKHJz4g3Jn3g", callContext.id);
// Execute Action: ResetFocus
ShopperPortalEU_UI_ComponentsController.default.resetFocus$Action(callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:VZDk3Pk4mUmUPDCP3ZXB5g", callContext.id);
});
}).catch(function (ex) {
OS.Logger.trace("RefundDetails.FormPdfClick", OS.Exceptions.getMessage(ex), ex.name);
// Handle Error: AllExceptions
if(!(OS.Exceptions.isSystem(ex))) {
OS.Logger.error(null, ex);
allExceptionsVar.value.exceptionMessageAttr = OS.Exceptions.getMessage(ex);
OutSystemsDebugger.handleException(allExceptionsVar.value.exceptionMessageAttr, callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:BscCG6SOxkCo602dSnXVvQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:O_WjbiByBkKIIvXvmFzmaA", callContext.id);
// Execute Action: CustomMessageTrigger
ShopperPortalEU_UI_ThemeController.default.customMessageTrigger$Action(function () {
var rec = new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customMessageType.error;
rec.titleAttr = "We couldn\'t load the PDF";
rec.testIdAttr = "FailedToRetrievePDF_Message";
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:7ppHEGBr+0mkvf9pXQkrdQ", callContext.id);
return OS.Flow.returnAsync();

});
}

throw ex;
}).then(function (res) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:kfC8hSvgAkqBV18xDWtezg", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:kfC8hSvgAkqBV18xDWtezg", callContext.id);
throw ex;

});
};
Controller.prototype._onInitialize$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnInitialize");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:JThTlheVsEaaoOCosqUdpw:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.05pm1Xjpy0ye5EaE3tg36Q/ClientActions.JThTlheVsEaaoOCosqUdpw:UZoImTQLX9goivVcRFSm1g", "ShopperPortalEU", "OnInitialize", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:6twpZDCTfE2jAO7Fkko6eg", callContext.id);
// Set IsFromFormDetailsScreen
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:S2y_nAqbtkyxCQuutTKEIw", callContext.id);
// IsFromFormDetailsOrStepScreen = False
ShopperPortalEUClientVariables.setIsFromFormDetailsOrStepScreen(false);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:S2y_nAqbtkyxCQuutTKEIw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// IsDataFetched = False
model.variables.isDataFetchedVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:UJVyXMPgnE+K1nV1yYLFRQ", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:JThTlheVsEaaoOCosqUdpw", callContext.id);
}

};
Controller.prototype._addCardForRefundOnClick$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("AddCardForRefundOnClick");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:lY5v3TjXPEWAK4n7JqUv5g:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.05pm1Xjpy0ye5EaE3tg36Q/ClientActions.lY5v3TjXPEWAK4n7JqUv5g:FG5GwxpLstLj+9V+sEIziA", "ShopperPortalEU", "AddCardForRefundOnClick", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Cz9gWNvU9k+m2sPArATZ_w", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:bLlpuvHqHE+LjABKBysFcA", callContext.id);
// IsFromFormDetailsOrStepScreen = True
ShopperPortalEUClientVariables.setIsFromFormDetailsOrStepScreen(true);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:VmmVSxjIkUO1Ns5QD69quQ", callContext.id);
// Execute Action: ClarityEvent
ShopperPortalEUController.default.clarityEvent$Action("AddCardForRefund_btn", callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:2c88Sx+460OernoRwywlmw", callContext.id);
// Destination: /ShopperPortalEU/RequestRefund
return OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "RequestRefund", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:lY5v3TjXPEWAK4n7JqUv5g", callContext.id);
}

};
Controller.prototype._customListItem_ViewBarcodeOnClick$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("CustomListItem_ViewBarcodeOnClick");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:cPpf+bG1H0uynUKqvpG2Mg:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.05pm1Xjpy0ye5EaE3tg36Q/ClientActions.cPpf+bG1H0uynUKqvpG2Mg:8UAVaoPxoZiBZRq4F2TFoQ", "ShopperPortalEU", "CustomListItem_ViewBarcodeOnClick", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:CMLiSJz2KEK96_YB3HC0GQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:H0mZzYUtXUGM_ayobhyShg", callContext.id);
// Destination: /ShopperPortalEU/RefundDetails_Barcode
return OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "RefundDetails_Barcode", {
FormNumber: OS.DataConversion.ServerDataConverter.asString(model.variables.formRecVar.formNumberAttr, OS.DataTypes.DataTypes.Text)
}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:cPpf+bG1H0uynUKqvpG2Mg", callContext.id);
}

};

Controller.prototype.togglePopup$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._togglePopup$Action, callContext);

};
Controller.prototype.onReady$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onReady$Action, callContext);

};
Controller.prototype.cardClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._cardClick$Action, callContext);

};
Controller.prototype.formPdfClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._formPdfClick$Action, callContext);

};
Controller.prototype.onInitialize$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onInitialize$Action, callContext);

};
Controller.prototype.addCardForRefundOnClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._addCardForRefundOnClick$Action, callContext);

};
Controller.prototype.customListItem_ViewBarcodeOnClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._customListItem_ViewBarcodeOnClick$Action, callContext);

};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:VcUw8y2coUi7OQ+l92mkmQ:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ:1Ox1BferNhnfzrugqQ41yg", "ShopperPortalEU", "Refund", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:05pm1Xjpy0ye5EaE3tg36Q:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.05pm1Xjpy0ye5EaE3tg36Q:mMb1mPCfWWZPTCyjBGnLBw", "ShopperPortalEU", "RefundDetails", "NRNodes.WebScreen", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:05pm1Xjpy0ye5EaE3tg36Q", callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:VcUw8y2coUi7OQ+l92mkmQ", callContext.id);
};
Controller.prototype.onInitializeEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Refund/RefundDetails On Initialize");
return controller.onInitialize$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onReadyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Refund/RefundDetails On Ready");
return controller.onReady$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return ShopperPortalEU_RefundController.default.handleError(ex, this.callContext());
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return ShopperPortalEUController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, ShopperPortalEULanguageResources);
});

define("ShopperPortalEU.Refund.RefundDetails.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"q_cYP0eQJUehiS9Tf4fxVg": {
getter: function (varBag, idService) {
return varBag.getFormVar.value;
}
},
"BscCG6SOxkCo602dSnXVvQ": {
getter: function (varBag, idService) {
return varBag.allExceptionsVar.value;
}
},
"IPHt_QotIkOobBDaa0iJRg": {
getter: function (varBag, idService) {
return varBag.getPDFByFormNumberVar.value;
}
},
"R66th5fiT0ihOIqpD1nwfQ": {
getter: function (varBag, idService) {
return varBag.model.variables.formRecVar;
}
},
"axjsgvup_kqyBeCgAgXDIQ": {
getter: function (varBag, idService) {
return varBag.model.variables.showPopupVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"zseQFsBRk0S0TY1Z4TM_aA": {
getter: function (varBag, idService) {
return varBag.model.variables.displayAddCardForRefundBtnVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"bBgTclvqZUSpXpBm_n6WfQ": {
getter: function (varBag, idService) {
return varBag.model.variables.isDataFetchedVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"HF6V7cZIx0qknYzKR2wduQ": {
getter: function (varBag, idService) {
return varBag.model.variables.formNumberInIn;
},
dataType: OS.DataTypes.DataTypes.Text
},
"FcEhyECP+kmcVIIBkwzTTg": {
getter: function (varBag, idService) {
return varBag.model.variables.getCountryLocationDataAct;
}
},
"kX+TLlUgn0SdqMm2d5NLqA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderLeft"));
})(varBag.model, idService);
}
},
"AHATIctk202PQk1QXyEXNg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderCenter"));
})(varBag.model, idService);
}
},
"wiw3d8GfC0imfPNKU9kpIw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderRight"));
})(varBag.model, idService);
}
},
"9Zs1M4h9okCJbksWysi69A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"vlg+5D8tH0qUaP0wgXNaZQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"wLrUirQb0UWLaF8tWo3Igg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Top"));
})(varBag.model, idService);
}
},
"3_Eg8TleYE2A6cdFxWzCcw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("ShowContent"));
})(varBag.model, idService);
}
},
"_ZLuBQq7OEmb_KkfRhLFXg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"5rNounUQXUCI1NzA6e06Tw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"zQbFr2LLW0q8Gqq_qEWntA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"AJYbeuPvmEiYU5fU9Uk7ZQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("StateContent"));
})(varBag.model, idService);
}
},
"sUtHNxGScUmrRdzc6_ITzQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Button"));
})(varBag.model, idService);
}
},
"lhCMEunc1kiKVmhVyisGdQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"o6YgQ5bo_E6du9hz1zf9TA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("If_DisplayFormDetails"));
})(varBag.model, idService);
}
},
"yPPpMKFWH0er7DusyA_UbQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"N73e5EnNm06R5CIQyBpJEw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("List"));
})(varBag.model, idService);
}
},
"LA666oip3EWwKdCg0S9j4Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("CustomListItem_ViewBarcode"));
})(varBag.model, idService);
}
},
"IZQXnrZ8YUiZ4bmgkcdD2Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Left"));
})(varBag.model, idService);
}
},
"VWIZOTvtX0W3VSionc23zg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"I3nRqSfOdE+2mZOU18Kc7Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("CustomListItem_ViewForm"));
})(varBag.model, idService);
}
},
"9omsSmA6j0GbWcTTe9EPbw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Left"));
})(varBag.model, idService);
}
},
"yyaWUbXZgkqDvFV3ND1Urg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"uHMtA40PiU+nI21u4d2nzg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Bottom"));
})(varBag.model, idService);
}
},
"gvqn1Hhlkk+dowGnpfyy5Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"HRP3fsA5aUmFlKtLt9KXmg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Button"));
})(varBag.model, idService);
}
},
"3vUIWTCB_UeHyh4YeS9X9w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"IDcu6OnfJUelGOaC285tLQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Popup"));
})(varBag.model, idService);
}
},
"a8agAtF3GkqM97eZmOP1OA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"_uMIHEvYJUqwGLLu5zslnw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"C+nF+mSjSEuaJKoW0YksEQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Actions"));
})(varBag.model, idService);
}
},
"__rf+ELwR0e4gMoLMSy5dg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"kNCZHS6UOEeFORMhpJfUHQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Button"));
})(varBag.model, idService);
}
},
"HXRw7opRfkycbFS0wwaTuw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"O8_fGawYhUiuPVwdBH7VzA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Bottom"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
