define("ShopperPortalEU.Support.Help.mvc$model", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.Layouts.Layout.mvc$model", "ShopperPortalEU.LayoutsComponents.Menu.mvc$model", "ShopperPortalEU.LayoutsComponents.ApplicationHeader.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomColumns.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCard.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.Flex.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CircleIcon.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.FlexItem.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomSeparator.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomLink.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomLinkItem.mvc$model", "ShopperPortalEU.controller$TRuleWrapper", "ShopperPortalEU_UI_Theme.model$LayoutOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$LayoutHeaderOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU.model$ApplicationHeaderRec", "ShopperPortalEU_UI_Components.model$CustomColumnsOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$CustomCardOptionsRec", "ShopperPortalEU_UI_Components.model$FlexOptionsRec", "ShopperPortalEU_UI_Components.model$CircleIconOptionsRec", "ShopperPortalEU_UI_Components.model$CircleIconIconOptionsRec", "ShopperPortalEU_UI_Components.model$FlexItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomSeparatorOptionsRec", "ShopperPortalEU_UI_Components.model$CustomSeparatorLabelOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsIconRec", "ShopperPortalEU.controller$CheckAuthentication"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_Layouts_Layout_mvcModel, ShopperPortalEU_LayoutsComponents_Menu_mvcModel, ShopperPortalEU_LayoutsComponents_ApplicationHeader_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomColumns_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCard_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CircleIcon_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FlexItem_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomSeparator_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLink_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLinkItem_mvcModel) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("Authenticated", "authenticatedVar", "Authenticated", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.fromStructure = function (str) {
return new VariablesRecord(new VariablesRecord.RecordClass({
authenticatedVar: OS.DataTypes.ImmutableBase.getData(str)
}));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Model._hasValidationWidgetsValue = undefined;
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
if((Model._hasValidationWidgetsValue === undefined)) {
Model._hasValidationWidgetsValue = ((((((((((ShopperPortalEU_Layouts_Layout_mvcModel.hasValidationWidgets || ShopperPortalEU_LayoutsComponents_Menu_mvcModel.hasValidationWidgets) || ShopperPortalEU_LayoutsComponents_ApplicationHeader_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomColumns_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCard_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CircleIcon_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FlexItem_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomSeparator_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLink_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLinkItem_mvcModel.hasValidationWidgets);
}

return Model._hasValidationWidgetsValue;
}
});

Model.prototype.setInputs = function (inputs) {
};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "Support.Help");
});
define("ShopperPortalEU.Support.Help.mvc$view", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.model", "react", "OutSystems/ReactView/Main", "ShopperPortalEU.Support.Help.mvc$model", "ShopperPortalEU.Support.Help.mvc$controller", "ShopperPortalEU.clientVariables", "ShopperPortalEU.Layouts.Layout.mvc$view", "OutSystems/ReactWidgets/Main", "ShopperPortalEU.LayoutsComponents.Menu.mvc$view", "ShopperPortalEU.LayoutsComponents.ApplicationHeader.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomColumns.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCard.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.Flex.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CircleIcon.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.FlexItem.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomSeparator.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomLink.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomLinkItem.mvc$view", "ShopperPortalEU.controller$TRuleWrapper", "ShopperPortalEU_UI_Theme.model$LayoutOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$LayoutHeaderOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU.model$ApplicationHeaderRec", "ShopperPortalEU_UI_Components.model$CustomColumnsOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$CustomCardOptionsRec", "ShopperPortalEU_UI_Components.model$FlexOptionsRec", "ShopperPortalEU_UI_Components.model$CircleIconOptionsRec", "ShopperPortalEU_UI_Components.model$CircleIconIconOptionsRec", "ShopperPortalEU_UI_Components.model$FlexItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomSeparatorOptionsRec", "ShopperPortalEU_UI_Components.model$CustomSeparatorLabelOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsIconRec", "ShopperPortalEU.controller$CheckAuthentication"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ComponentsModel, React, OSView, ShopperPortalEU_Support_Help_mvc_model, ShopperPortalEU_Support_Help_mvc_controller, ShopperPortalEUClientVariables, ShopperPortalEU_Layouts_Layout_mvc_view, OSWidgets, ShopperPortalEU_LayoutsComponents_Menu_mvc_view, ShopperPortalEU_LayoutsComponents_ApplicationHeader_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomColumns_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCard_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CircleIcon_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FlexItem_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomSeparator_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLink_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLinkItem_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            var thisIsInstanceOfSuper = this instanceof _super;
            if (thisIsInstanceOfSuper == false) {
                return;
            }

            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "Support.Help";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css", "css/ShopperPortalEU_UI_Theme.ShopperPortalEUUITheme.css", "css/ShopperPortalEU.ShopperPortalEU.css", "css/ShopperPortalEU_UI_Theme.ShopperPortalEUUITheme.extra.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [ShopperPortalEU_Layouts_Layout_mvc_view, ShopperPortalEU_LayoutsComponents_Menu_mvc_view, ShopperPortalEU_LayoutsComponents_ApplicationHeader_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomColumns_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCard_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CircleIcon_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FlexItem_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomSeparator_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLink_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLinkItem_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return ShopperPortalEU_Support_Help_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return ShopperPortalEU_Support_Help_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "Shopper Portal EU - Help";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(ShopperPortalEU_Layouts_Layout_mvc_view, {
inputs: {
Auth: model.getCachedValue(idService.getId("Z93vn+3b8Ei6l7K2gv3RCQ.Auth"), function () {
return function () {
var rec = new ShopperPortalEUModel.LayoutAuthenticationRec();
rec.isToUseAuthAttr = false;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
afterAuthentication$Action: function (isAuthenticatedIn) {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Layouts/Layout AfterAuthentication");
return controller.layoutAfterAuthentication$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "0",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
headerLeft: new PlaceholderContent(function () {
return [$if(model.variables.authenticatedVar, false, this, function () {
return [React.createElement(ShopperPortalEU_LayoutsComponents_Menu_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "1",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}, function () {
return [];
})];
}),
headerCenter: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_LayoutsComponents_ApplicationHeader_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("65gWwU+UFkaVZuhvzdLgTA.Options"), function () {
return function () {
var rec = new ShopperPortalEUModel.ApplicationHeaderRec();
rec.scrollTitleAttr = "Help";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "2",
alias: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}),
headerRight: PlaceholderContent.Empty,
headerBottom: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "heading6 text-align-center",
visible: true,
_idProps: {
service: idService,
uuid: "3"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "HelpScreen"
},
value: "Help",
_idProps: {
service: idService,
uuid: "4"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
}),
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomColumns_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("A8P1CNWdd0mnzdZ1W5RO+Q.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomColumnsOptionsRec();
rec.columnsAttr = 1;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "5",
alias: "4"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCard_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "6",
alias: "5"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("yAFpIXiRL06dEn+oqy4AwA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.wrapAttr = false;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "7",
alias: "6"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CircleIcon_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("Is3T1xIx4kmYI_S0reBntg.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CircleIconOptionsRec();
rec.iconAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CircleIconIconOptionsRec();
rec.nameAttr = "send";
rec.familyAttr = ShopperPortalEUModel.staticEntities.customIconFamily.planet;
return rec;
}();
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "8",
alias: "7"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FlexItem_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("xskD05SA7kCkFUZPgTkgbQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexItemOptionsRec();
rec.flexAttr = "1";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "9",
alias: "8"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "HelpRequest"
},
style: "heading5 text-primary-35",
value: "Help request",
_idProps: {
service: idService,
uuid: "10"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomSeparator_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("8qgbj1mN3USYOsI6cZ6EHw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomSeparatorOptionsRec();
rec.marginTopAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
rec.marginBottomAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "11",
alias: "9"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLink_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("ONChCNJLu0CDcImilmMkOw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomLinkOptionsRec();
rec.testIdAttr = "PlanetSupportLink";
return rec;
}();
}),
ExtendedClass: "body-3"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "12",
alias: "10"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
link: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Link, {
enabled: true,
extendedProperties: {
target: "_blank"
},
transition: OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default),
url: OS.Navigation.generateScreenURL(OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("support_website", "", callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id), {}),
visible: true,
_idProps: {
service: idService,
uuid: "13"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLinkItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "14",
alias: "11"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Send us your contact details",
_idProps: {
service: idService,
uuid: "15"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-top-02 body-4",
visible: true,
_idProps: {
service: idService,
uuid: "16"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "WellGetBackToYouShortly"
},
value: "We\'ll get back to you shortly",
_idProps: {
service: idService,
uuid: "17"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
})
},
_dependencies: []
})];
})
},
_dependencies: []
})];
})
},
_dependencies: []
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCard_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "18",
alias: "12"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("uTssPvJzg0yc1C1hykPPow.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.wrapAttr = false;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "19",
alias: "13"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CircleIcon_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("Xxj8L3cXh0mPsIim0zYWnw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CircleIconOptionsRec();
rec.iconAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CircleIconIconOptionsRec();
rec.nameAttr = "call";
return rec;
}();
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "20",
alias: "14"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FlexItem_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("IuiaTxz9W0KpAPHpPwo6dQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexItemOptionsRec();
rec.flexAttr = "1";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "21",
alias: "15"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "Phone"
},
style: "heading5 text-primary-35",
value: "Phone",
_idProps: {
service: idService,
uuid: "22"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomSeparator_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("yCag_mmpr0CjUOzwH8_Nrw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomSeparatorOptionsRec();
rec.marginTopAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
rec.marginBottomAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "23",
alias: "16"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLink_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("Eu2lqx+f7kC+kqN+Kc55UA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomLinkOptionsRec();
rec.testIdAttr = "phoneNumberLink";
return rec;
}();
}),
ExtendedClass: "body-3"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "24",
alias: "17"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
link: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Link, {
enabled: true,
transition: OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default),
url: OS.Navigation.generateScreenURL("tel:+48223075222", {}),
visible: true,
_idProps: {
service: idService,
uuid: "25"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLinkItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "26",
alias: "18"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: model.getCachedValue(idService.getId("mAgM_esdNkWRg5YlrUGWQQ.Value"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("support_phone", "", callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
}),
_idProps: {
service: idService,
uuid: "27"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-top-02 body-3",
visible: true,
_idProps: {
service: idService,
uuid: "28"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "support_phone_hours_week"
},
value: model.getCachedValue(idService.getId("vT9LAyfyrUK4BZlmF7ahAg.Value"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("support_phone_hours_week", "", callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
}),
_idProps: {
service: idService,
uuid: "29"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "30"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "support_phone_hours_weekend"
},
value: model.getCachedValue(idService.getId("s12kak+0w0axkJzLgRH7Qw.Value"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("support_phone_hours_weekend", "", callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
}),
_idProps: {
service: idService,
uuid: "31"
},
_widgetRecordProvider: widgetsRecordProvider
})))];
})
},
_dependencies: []
})];
})
},
_dependencies: []
})];
})
},
_dependencies: []
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCard_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "32",
alias: "19"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("uPObqgCdBEu_tp9UHaN20g.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.wrapAttr = false;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "33",
alias: "20"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CircleIcon_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("OIsUVxAyJ0ixK6enJ7Vp_w.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CircleIconOptionsRec();
rec.iconAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CircleIconIconOptionsRec();
rec.nameAttr = "mail";
return rec;
}();
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "34",
alias: "21"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FlexItem_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("LV7lmeFNv0qLlki0YCjyRQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexItemOptionsRec();
rec.flexAttr = "1";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "35",
alias: "22"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "Address"
},
style: "heading5 text-primary-35",
value: "Address",
_idProps: {
service: idService,
uuid: "36"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomSeparator_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("dj9G_oPPz0e1sr6Wo2aO5A.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomSeparatorOptionsRec();
rec.marginTopAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
rec.marginBottomAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "37",
alias: "23"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "subhead-2",
visible: true,
_idProps: {
service: idService,
uuid: "38"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "support_address_center"
},
style: "text-primary-35",
value: model.getCachedValue(idService.getId("6n84JnxkmE+t85AMf0N29g.Value"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("support_address_center", "", callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
}),
_idProps: {
service: idService,
uuid: "39"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-top-02 body-3",
visible: true,
_idProps: {
service: idService,
uuid: "40"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "support_address_line1"
},
value: model.getCachedValue(idService.getId("xISmz6ZLS02lcXL0g0fC8Q.Value"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("support_address_line1", "", callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
}),
_idProps: {
service: idService,
uuid: "41"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "42"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "support_address_line2"
},
value: model.getCachedValue(idService.getId("vsAchtWy0kGGglMdXbIXzw.Value"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("support_address_line2", "", callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
}),
_idProps: {
service: idService,
uuid: "43"
},
_widgetRecordProvider: widgetsRecordProvider
}))), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-top-02 body-4",
visible: true,
_idProps: {
service: idService,
uuid: "44"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "YouCanMailYourValidatedPlanetTaxFreeFormToThisAddress"
},
value: "You can mail your validated Planet Tax Free form to this address",
_idProps: {
service: idService,
uuid: "45"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
})
},
_dependencies: []
})];
})
},
_dependencies: []
})];
})
},
_dependencies: []
})];
})
},
_dependencies: []
})];
}),
bottom: PlaceholderContent.Empty
},
_dependencies: [asPrimitiveValue(model.variables.authenticatedVar)]
}));
        };
        return View;
    })(OSView.BaseView.BaseWebScreen);
	
    return View;
});
define("ShopperPortalEU.Support.Help.mvc$controller", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.languageResources", "ShopperPortalEU.clientVariables", "ShopperPortalEU.Support.Help.mvc$debugger", "ShopperPortalEU.Support.controller", "ShopperPortalEU.controller$TRuleWrapper", "ShopperPortalEU_UI_Theme.model$LayoutOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$LayoutHeaderOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU.model$ApplicationHeaderRec", "ShopperPortalEU_UI_Components.model$CustomColumnsOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$CustomCardOptionsRec", "ShopperPortalEU_UI_Components.model$FlexOptionsRec", "ShopperPortalEU_UI_Components.model$CircleIconOptionsRec", "ShopperPortalEU_UI_Components.model$CircleIconIconOptionsRec", "ShopperPortalEU_UI_Components.model$FlexItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomSeparatorOptionsRec", "ShopperPortalEU_UI_Components.model$CustomSeparatorLabelOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsIconRec", "ShopperPortalEU.controller$CheckAuthentication"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEULanguageResources, ShopperPortalEUClientVariables, ShopperPortalEU_Support_Help_mvc_Debugger, ShopperPortalEU_SupportController) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = true;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._layoutAfterAuthentication$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("LayoutAfterAuthentication");
callContext = controller.callContext(callContext);
var checkAuthenticationVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.checkAuthenticationVar = checkAuthenticationVar;
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:oINTCjZ3K0KVlsNQZgtgnw:/NRWebFlows._1zAHv5LwEGws6WRTm11hA/NodesShownInESpaceTree.AtGggq82qUKnEiiKvsg7AA/ClientActions.oINTCjZ3K0KVlsNQZgtgnw:ALgTZxFQOmUGyoTYXNEblg", "ShopperPortalEU", "LayoutAfterAuthentication", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:VjZIQJlI90KlmmEHwcp+Sw", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:txTIEoIsbU27_jn01NUvYw", callContext.id);
// Execute Action: CheckAuthentication
model.flush();
return ShopperPortalEUController.default.checkAuthentication$Action(true, callContext).then(function (value) {
checkAuthenticationVar.value = value;
}).then(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:j62AcAYK_EO7ZGovkSjZ4Q", callContext.id);
// Authenticated = CheckAuthentication.IsAuthenticated
model.variables.authenticatedVar = checkAuthenticationVar.value.isAuthenticatedOut;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:N83m9inw+0WlLVz82md1iQ", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:oINTCjZ3K0KVlsNQZgtgnw", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:oINTCjZ3K0KVlsNQZgtgnw", callContext.id);
throw ex;

});
};

Controller.prototype.layoutAfterAuthentication$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._layoutAfterAuthentication$Action, callContext);

};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:_1zAHv5LwEGws6WRTm11hA:/NRWebFlows._1zAHv5LwEGws6WRTm11hA:mL1lLGIiQoiQpGIO1O5tXg", "ShopperPortalEU", "Support", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:AtGggq82qUKnEiiKvsg7AA:/NRWebFlows._1zAHv5LwEGws6WRTm11hA/NodesShownInESpaceTree.AtGggq82qUKnEiiKvsg7AA:jUeOFpJVX74r9nWvyyie3A", "ShopperPortalEU", "Help", "NRNodes.WebScreen", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:AtGggq82qUKnEiiKvsg7AA", callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:_1zAHv5LwEGws6WRTm11hA", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return ShopperPortalEU_SupportController.default.handleError(ex, this.callContext());
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return ShopperPortalEUController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, ShopperPortalEULanguageResources);
});

define("ShopperPortalEU.Support.Help.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"txTIEoIsbU27_jn01NUvYw": {
getter: function (varBag, idService) {
return varBag.checkAuthenticationVar.value;
}
},
"LyUEZnZ4ukWem1oFcDUAxw": {
getter: function (varBag, idService) {
return varBag.model.variables.authenticatedVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"E87f7xbBG0y1lKjva8txPw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderLeft"));
})(varBag.model, idService);
}
},
"j+pPQfJeFUemRG3emlhHjg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderCenter"));
})(varBag.model, idService);
}
},
"z0aUMgZzxEeTogVkojgCwQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderRight"));
})(varBag.model, idService);
}
},
"r8iQftqrIUayzPvaU3pBVg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderBottom"));
})(varBag.model, idService);
}
},
"59Qly5JJeU6MB8B+BbEbPQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"BrRnGpTP1Eu0lG2RPvYyAQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"DVzynBiho06NrbwOI5Cjmg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"nn15C7soh0K2lnhu_nn60Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"T7CNCGCDPUqomtNkzOIJ9g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"1evdsqmoR0eszGe1nvPDGg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Link"));
})(varBag.model, idService);
}
},
"LgaLpacHf0qnvo8a20AUQA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"ujBHHUv+hUa42pM13ZUdGw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"0HNiOXmRG0CCO3ESIkeJiw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"LJVNfNSuP06KXZZBakuVPg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"rZO5MGfZpkmgpH3DJFw4Hg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Link"));
})(varBag.model, idService);
}
},
"__Ms5ugJlEqhwrlHAiz5uw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"0+j0q37Bt0ShxVl4p6YR6w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"uAe50tJi8US4YziDkBGx6A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"HS07JqnU9UuSiOeYbXxItw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"zVtber6h7ES2b90f3+y96g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Bottom"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
