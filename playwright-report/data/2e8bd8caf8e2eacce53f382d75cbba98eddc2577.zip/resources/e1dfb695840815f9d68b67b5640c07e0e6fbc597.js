define("reCAPTCHAReact.reCAPTCHAPrivate.GoogleJS.mvc$model", ["OutSystems/ClientRuntime/Main", "reCAPTCHAReact.model"], function (OutSystems, reCAPTCHAReactModel) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return false;
}
});

Model.prototype.setInputs = function (inputs) {
};
return Model;
})(OS.Model.VariablelessViewModel);
return new OS.Model.ModelFactory(Model, "reCAPTCHAPrivate.GoogleJS");
});
define("reCAPTCHAReact.reCAPTCHAPrivate.GoogleJS.mvc$view", ["OutSystems/ClientRuntime/Main", "reCAPTCHAReact.model", "reCAPTCHAReact.controller", "react", "OutSystems/ReactView/Main", "reCAPTCHAReact.reCAPTCHAPrivate.GoogleJS.mvc$model", "reCAPTCHAReact.reCAPTCHAPrivate.GoogleJS.mvc$controller"], function (OutSystems, reCAPTCHAReactModel, reCAPTCHAReactController, React, OSView, reCAPTCHAReact_reCAPTCHAPrivate_GoogleJS_mvc_model, reCAPTCHAReact_reCAPTCHAPrivate_GoogleJS_mvc_controller) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            var thisIsInstanceOfSuper = this instanceof _super;
            if (thisIsInstanceOfSuper == false) {
                return;
            }

            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "reCAPTCHAPrivate.GoogleJS";
        View.getCssDependencies = function() {
            return [];
        };
        View.getJsDependencies = function() {
            return ["scripts/reCAPTCHAReact.CallbackHandler.js"];
        };
        View.getBlocks = function() {
            return [];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return reCAPTCHAReact_reCAPTCHAPrivate_GoogleJS_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return reCAPTCHAReact_reCAPTCHAPrivate_GoogleJS_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), $if(false, false, this, function () {
return [];
}, function () {
return [];
}));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("reCAPTCHAReact.reCAPTCHAPrivate.GoogleJS.mvc$controller", ["OutSystems/ClientRuntime/Main", "reCAPTCHAReact.model", "reCAPTCHAReact.controller", "reCAPTCHAReact.languageResources", "reCAPTCHAReact.reCAPTCHAPrivate.GoogleJS.mvc$debugger", "reCAPTCHAReact.reCAPTCHAPrivate.GoogleJS.mvc$controller.OnRender.InitJS"], function (OutSystems, reCAPTCHAReactModel, reCAPTCHAReactController, reCAPTCHAReactLanguageResources, reCAPTCHAReact_reCAPTCHAPrivate_GoogleJS_mvc_Debugger, reCAPTCHAReact_reCAPTCHAPrivate_GoogleJS_mvc_controller_OnRender_InitJS) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {
triggerOnLoad$Action: function () {
return controller.executeActionInsideJSNode(controller._triggerOnLoad$Action.bind(controller), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "TriggerOnLoad");
}
};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = false;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._triggerOnLoad$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("TriggerOnLoad");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
OutSystemsDebugger.push("o_YczqP5jE+AKx3_6JNghg:0iZgAuy7VkWH398Ye031RA:/NRWebFlows.4iJa9bpDZ0anc6ITcMzLEQ/NodesShownInESpaceTree.0ofm+YHVX0qI6Ih_gupEDA/ClientActions.0iZgAuy7VkWH398Ye031RA:aBJ1OuHBDQwYpN6ioN8oUw", "reCAPTCHAReact", "TriggerOnLoad", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("o_YczqP5jE+AKx3_6JNghg:s094b39QR0GuZJXxHL_Hmw", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("o_YczqP5jE+AKx3_6JNghg:TIRybY+fgUK_Lvubbj8TLA", callContext.id);
// Trigger Event: OnLoad
return controller.onLoad$Action(callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("o_YczqP5jE+AKx3_6JNghg:6i_RRTmSeEqnY8tT24p5pw", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("o_YczqP5jE+AKx3_6JNghg:0iZgAuy7VkWH398Ye031RA", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("o_YczqP5jE+AKx3_6JNghg:0iZgAuy7VkWH398Ye031RA", callContext.id);
throw ex;

});
};
Controller.prototype._onRender$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnRender");
callContext = controller.callContext(callContext);
var initJSResult = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.initJSResult = initJSResult;
OutSystemsDebugger.push("o_YczqP5jE+AKx3_6JNghg:ZFrG8zSMUEWtDwENgJ6EKg:/NRWebFlows.4iJa9bpDZ0anc6ITcMzLEQ/NodesShownInESpaceTree.0ofm+YHVX0qI6Ih_gupEDA/ClientActions.ZFrG8zSMUEWtDwENgJ6EKg:vY+yOs5pMdgIW9_jQyI38A", "reCAPTCHAReact", "OnRender", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("o_YczqP5jE+AKx3_6JNghg:1GRm_Vuo_0yecjfs1FW_qA", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("o_YczqP5jE+AKx3_6JNghg:aKsWvfiU+EOWFmMpStVhSg", callContext.id);
initJSResult.value = controller.safeExecuteJSNode(reCAPTCHAReact_reCAPTCHAPrivate_GoogleJS_mvc_controller_OnRender_InitJS, "Init", "OnRender", {
IsLoaded: OS.DataConversion.JSNodeParamConverter.to(false, OS.DataTypes.DataTypes.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("reCAPTCHAReact.reCAPTCHAPrivate.GoogleJS.OnRender$initJSResult"))();
jsNodeResult.isLoadedOut = OS.DataConversion.JSNodeParamConverter.from($parameters.IsLoaded, OS.DataTypes.DataTypes.Boolean);
return jsNodeResult;
}, {
TriggerOnLoad: controller.clientActionProxies.triggerOnLoad$Action
}, {});
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("o_YczqP5jE+AKx3_6JNghg:dK4OYv0bMU+Ez4GllEXBWA", callContext.id) && initJSResult.value.isLoadedOut)) {
OutSystemsDebugger.handleBreakpoint("o_YczqP5jE+AKx3_6JNghg:Nt5Tj_nEPUycUbkbevdMcw", callContext.id);
// Trigger Event: OnLoad
return controller.onLoad$Action(callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("o_YczqP5jE+AKx3_6JNghg:+h2xNqmE60Ci3t8yr0BRHw", callContext.id);
});
} else {
OutSystemsDebugger.handleBreakpoint("o_YczqP5jE+AKx3_6JNghg:2briOXWSuUeAFkLP+NATxg", callContext.id);
// Execute Action: RequireScript
model.flush();
return OS.SystemActions.requireScript("https://www.google.com/recaptcha/api.js?onload=onLoadCallback&render=explicit", callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("o_YczqP5jE+AKx3_6JNghg:o0dXjgJnx0C56QLOEMw11g", callContext.id);
});
}

});
}).then(function (res) {
OutSystemsDebugger.pop("o_YczqP5jE+AKx3_6JNghg:ZFrG8zSMUEWtDwENgJ6EKg", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("o_YczqP5jE+AKx3_6JNghg:ZFrG8zSMUEWtDwENgJ6EKg", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("reCAPTCHAReact.reCAPTCHAPrivate.GoogleJS.OnRender$initJSResult", [{
name: "IsLoaded",
attrName: "isLoadedOut",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Boolean,
defaultValue: function () {
return false;
}
}]);

Controller.prototype.triggerOnLoad$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._triggerOnLoad$Action, callContext);

};
Controller.prototype.onRender$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onRender$Action, callContext);

};
Controller.prototype.onLoad$Action = function () {
return Promise.resolve();
};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("o_YczqP5jE+AKx3_6JNghg:4iJa9bpDZ0anc6ITcMzLEQ:/NRWebFlows.4iJa9bpDZ0anc6ITcMzLEQ:jL9CWKo0vzi2ozx67CiyHw", "reCAPTCHAReact", "reCAPTCHAPrivate", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("o_YczqP5jE+AKx3_6JNghg:0ofm+YHVX0qI6Ih_gupEDA:/NRWebFlows.4iJa9bpDZ0anc6ITcMzLEQ/NodesShownInESpaceTree.0ofm+YHVX0qI6Ih_gupEDA:D2xg1V+coiepIqicG4Tc0w", "reCAPTCHAReact", "GoogleJS", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("o_YczqP5jE+AKx3_6JNghg:0ofm+YHVX0qI6Ih_gupEDA", callContext.id);
OutSystemsDebugger.pop("o_YczqP5jE+AKx3_6JNghg:4iJa9bpDZ0anc6ITcMzLEQ", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "reCAPTCHAPrivate/GoogleJS On Render");
return controller.onRender$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return reCAPTCHAReactController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, reCAPTCHAReactLanguageResources);
});
define("reCAPTCHAReact.reCAPTCHAPrivate.GoogleJS.mvc$controller.OnRender.InitJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.IsLoaded = typeof grecaptcha !== 'undefined';

if(!$parameters.IsLoaded){
    Callback.register($actions.TriggerOnLoad);
}

};
});

define("reCAPTCHAReact.reCAPTCHAPrivate.GoogleJS.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"aKsWvfiU+EOWFmMpStVhSg": {
getter: function (varBag, idService) {
return varBag.initJSResult.value;
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
