define("ShopperPortalEU_DataSync.Sync.DataSyncCore.mvc$model", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU_DataSync.model", "ShopperPortalEU_DataSync.controller", "ShopperPortalEU_DataSync.controller$SyncCMSBackofficeTranslations"], function (OutSystems, ShopperPortalEU_DataSyncModel, ShopperPortalEU_DataSyncController) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return false;
}
});

Model.prototype.setInputs = function (inputs) {
};
return Model;
})(OS.Model.VariablelessViewModel);
return new OS.Model.ModelFactory(Model, "Sync.DataSyncCore");
});
define("ShopperPortalEU_DataSync.Sync.DataSyncCore.mvc$view", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU_DataSync.model", "ShopperPortalEU_DataSync.controller", "react", "OutSystems/ReactView/Main", "ShopperPortalEU_DataSync.Sync.DataSyncCore.mvc$model", "ShopperPortalEU_DataSync.Sync.DataSyncCore.mvc$controller", "ShopperPortalEU_DataSync.controller$SyncCMSBackofficeTranslations"], function (OutSystems, ShopperPortalEU_DataSyncModel, ShopperPortalEU_DataSyncController, React, OSView, ShopperPortalEU_DataSync_Sync_DataSyncCore_mvc_model, ShopperPortalEU_DataSync_Sync_DataSyncCore_mvc_controller) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            var thisIsInstanceOfSuper = this instanceof _super;
            if (thisIsInstanceOfSuper == false) {
                return;
            }

            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "Sync.DataSyncCore";
        View.getCssDependencies = function() {
            return [];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return ShopperPortalEU_DataSync_Sync_DataSyncCore_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return ShopperPortalEU_DataSync_Sync_DataSyncCore_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties());
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("ShopperPortalEU_DataSync.Sync.DataSyncCore.mvc$controller", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU_DataSync.model", "ShopperPortalEU_DataSync.controller", "ShopperPortalEU_DataSync.languageResources", "ShopperPortalEU_DataSync.Sync.DataSyncCore.mvc$debugger", "ShopperPortalEU_DataSync.controller$SyncCMSBackofficeTranslations"], function (OutSystems, ShopperPortalEU_DataSyncModel, ShopperPortalEU_DataSyncController, ShopperPortalEU_DataSyncLanguageResources, ShopperPortalEU_DataSync_Sync_DataSyncCore_mvc_Debugger) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = false;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._onReady$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnReady");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
OutSystemsDebugger.push("BzPXzb2R8k2PLMHT7WmUdg:RbUy5ihtwE+TcJl8PL1e2g:/NRWebFlows.IBL2xZW2aUWHuUqXvsJMiA/NodesShownInESpaceTree.BXU9SvpM5kqVSnKjMAu0sQ/ClientActions.RbUy5ihtwE+TcJl8PL1e2g:2wVPyADtiKKYKfnwGOlCnA", "ShopperPortalEU_DataSync", "OnReady", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:I9puixrpGUCy7ZF6VaHSxw", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:ZAnaRYZE7Uubc0zz3NQfgg", callContext.id);
// Execute Action: SyncCMSBackofficeTranslations
model.flush();
return ShopperPortalEU_DataSyncController.default.syncCMSBackofficeTranslations$Action(callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("BzPXzb2R8k2PLMHT7WmUdg:ULnDsdx2N0G125AXH5sX3A", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("BzPXzb2R8k2PLMHT7WmUdg:RbUy5ihtwE+TcJl8PL1e2g", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("BzPXzb2R8k2PLMHT7WmUdg:RbUy5ihtwE+TcJl8PL1e2g", callContext.id);
throw ex;

});
};

Controller.prototype.onReady$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onReady$Action, callContext);

};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("BzPXzb2R8k2PLMHT7WmUdg:IBL2xZW2aUWHuUqXvsJMiA:/NRWebFlows.IBL2xZW2aUWHuUqXvsJMiA:pDy76WHsr74vPUIfujnLkQ", "ShopperPortalEU_DataSync", "Sync", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("BzPXzb2R8k2PLMHT7WmUdg:BXU9SvpM5kqVSnKjMAu0sQ:/NRWebFlows.IBL2xZW2aUWHuUqXvsJMiA/NodesShownInESpaceTree.BXU9SvpM5kqVSnKjMAu0sQ:VsUXMBUr5ewC8CGK0_4oKg", "ShopperPortalEU_DataSync", "DataSyncCore", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("BzPXzb2R8k2PLMHT7WmUdg:BXU9SvpM5kqVSnKjMAu0sQ", callContext.id);
OutSystemsDebugger.pop("BzPXzb2R8k2PLMHT7WmUdg:IBL2xZW2aUWHuUqXvsJMiA", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Sync/DataSyncCore On Ready");
return controller.onReady$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return ShopperPortalEU_DataSyncController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, ShopperPortalEU_DataSyncLanguageResources);
});

define("ShopperPortalEU_DataSync.Sync.DataSyncCore.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
