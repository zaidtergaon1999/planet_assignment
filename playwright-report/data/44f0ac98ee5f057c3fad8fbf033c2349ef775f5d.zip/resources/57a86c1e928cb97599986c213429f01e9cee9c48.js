define("ShopperPortalEU_Shopper_IS.model$RequestSignupRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var RequestSignupRec = (function (_super) {
__extends(RequestSignupRec, _super);
function RequestSignupRec(defaults) {
_super.apply(this, arguments);
}
RequestSignupRec.attributesToDeclare = function () {
return [
this.attr("email", "emailAttr", "email", false, false, OS.DataTypes.DataTypes.Email, function () {
return "";
}, true), 
this.attr("mobileNumber", "mobileNumberAttr", "mobileNumber", false, false, OS.DataTypes.DataTypes.PhoneNumber, function () {
return "";
}, true), 
this.attr("captchaToken", "captchaTokenAttr", "captchaToken", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
RequestSignupRec.init();
return RequestSignupRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Shopper_ISModel.RequestSignupRec = RequestSignupRec;

});
define("ShopperPortalEU_Shopper_IS.model$RequestSignupRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.model$RequestSignupRec"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var RequestSignupRecord = (function (_super) {
__extends(RequestSignupRecord, _super);
function RequestSignupRecord(defaults) {
_super.apply(this, arguments);
}
RequestSignupRecord.attributesToDeclare = function () {
return [
this.attr("RequestSignup", "requestSignupAttr", "RequestSignup", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Shopper_ISModel.RequestSignupRec());
}, true, ShopperPortalEU_Shopper_ISModel.RequestSignupRec)
].concat(_super.attributesToDeclare.call(this));
};
RequestSignupRecord.fromStructure = function (str) {
return new RequestSignupRecord(new RequestSignupRecord.RecordClass({
requestSignupAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
RequestSignupRecord._isAnonymousRecord = true;
RequestSignupRecord.UniqueId = "83f56b77-5132-0d20-627c-a04668a237b5";
RequestSignupRecord.init();
return RequestSignupRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Shopper_ISModel.RequestSignupRecord = RequestSignupRecord;

});
define("ShopperPortalEU_Shopper_IS.model$RequestSignupRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.model$RequestSignupRecord"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var RequestSignupRecordList = (function (_super) {
__extends(RequestSignupRecordList, _super);
function RequestSignupRecordList(defaults) {
_super.apply(this, arguments);
}
RequestSignupRecordList.itemType = ShopperPortalEU_Shopper_ISModel.RequestSignupRecord;
return RequestSignupRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Shopper_ISModel.RequestSignupRecordList = RequestSignupRecordList;

});
define("ShopperPortalEU_Shopper_IS.model$CreateCardDataRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var CreateCardDataRec = (function (_super) {
__extends(CreateCardDataRec, _super);
function CreateCardDataRec(defaults) {
_super.apply(this, arguments);
}
CreateCardDataRec.attributesToDeclare = function () {
return [
this.attr("ExpiryDate", "expiryDateAttr", "expiryDate", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("IsDefault", "isDefaultAttr", "isDefault", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("CardHolderName", "cardHolderNameAttr", "cardHolderName", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CreateCardDataRec.init();
return CreateCardDataRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Shopper_ISModel.CreateCardDataRec = CreateCardDataRec;

});
define("ShopperPortalEU_Shopper_IS.model$CreateCardDataList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.model$CreateCardDataRec"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var CreateCardDataList = (function (_super) {
__extends(CreateCardDataList, _super);
function CreateCardDataList(defaults) {
_super.apply(this, arguments);
}
CreateCardDataList.itemType = ShopperPortalEU_Shopper_ISModel.CreateCardDataRec;
return CreateCardDataList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Shopper_ISModel.CreateCardDataList = CreateCardDataList;

});
define("ShopperPortalEU_Shopper_IS.model$UpdateCardDataRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var UpdateCardDataRec = (function (_super) {
__extends(UpdateCardDataRec, _super);
function UpdateCardDataRec(defaults) {
_super.apply(this, arguments);
}
UpdateCardDataRec.attributesToDeclare = function () {
return [
this.attr("TokenValue", "tokenValueAttr", "tokenValue", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("TokenProvider", "tokenProviderAttr", "tokenProvider", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("IsDefault", "isDefaultAttr", "isDefault", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
UpdateCardDataRec.init();
return UpdateCardDataRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Shopper_ISModel.UpdateCardDataRec = UpdateCardDataRec;

});
define("ShopperPortalEU_Shopper_IS.model$UpdateCardDataList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.model$UpdateCardDataRec"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var UpdateCardDataList = (function (_super) {
__extends(UpdateCardDataList, _super);
function UpdateCardDataList(defaults) {
_super.apply(this, arguments);
}
UpdateCardDataList.itemType = ShopperPortalEU_Shopper_ISModel.UpdateCardDataRec;
return UpdateCardDataList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Shopper_ISModel.UpdateCardDataList = UpdateCardDataList;

});
define("ShopperPortalEU_Shopper_IS.model$UpdateCardRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.model$UpdateCardDataRec"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var UpdateCardRec = (function (_super) {
__extends(UpdateCardRec, _super);
function UpdateCardRec(defaults) {
_super.apply(this, arguments);
}
UpdateCardRec.attributesToDeclare = function () {
return [
this.attr("ShopperGuid", "shopperGuidAttr", "shopperGuid", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("UpdateCardData", "updateCardDataAttr", "UpdateCardData", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Shopper_ISModel.UpdateCardDataRec());
}, true, ShopperPortalEU_Shopper_ISModel.UpdateCardDataRec)
].concat(_super.attributesToDeclare.call(this));
};
UpdateCardRec.init();
return UpdateCardRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Shopper_ISModel.UpdateCardRec = UpdateCardRec;

});
define("ShopperPortalEU_Shopper_IS.model$UpdateCardList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.model$UpdateCardRec"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var UpdateCardList = (function (_super) {
__extends(UpdateCardList, _super);
function UpdateCardList(defaults) {
_super.apply(this, arguments);
}
UpdateCardList.itemType = ShopperPortalEU_Shopper_ISModel.UpdateCardRec;
return UpdateCardList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Shopper_ISModel.UpdateCardList = UpdateCardList;

});
define("ShopperPortalEU_Shopper_IS.model$GetShopperTravelDocumentsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var GetShopperTravelDocumentsRec = (function (_super) {
__extends(GetShopperTravelDocumentsRec, _super);
function GetShopperTravelDocumentsRec(defaults) {
_super.apply(this, arguments);
}
GetShopperTravelDocumentsRec.attributesToDeclare = function () {
return [
this.attr("Type", "typeAttr", "type", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Number", "numberAttr", "number", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("IssuedByIso", "issuedByIsoAttr", "issuedByIso", false, false, OS.DataTypes.DataTypes.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("ExpirationDate", "expirationDateAttr", "expirationDate", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
GetShopperTravelDocumentsRec.init();
return GetShopperTravelDocumentsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Shopper_ISModel.GetShopperTravelDocumentsRec = GetShopperTravelDocumentsRec;

});
define("ShopperPortalEU_Shopper_IS.model$GetShopperTravelDocumentsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.model$GetShopperTravelDocumentsRec"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var GetShopperTravelDocumentsList = (function (_super) {
__extends(GetShopperTravelDocumentsList, _super);
function GetShopperTravelDocumentsList(defaults) {
_super.apply(this, arguments);
}
GetShopperTravelDocumentsList.itemType = ShopperPortalEU_Shopper_ISModel.GetShopperTravelDocumentsRec;
return GetShopperTravelDocumentsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Shopper_ISModel.GetShopperTravelDocumentsList = GetShopperTravelDocumentsList;

});
define("ShopperPortalEU_Shopper_IS.model$GetShopperResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.model$GetShopperTravelDocumentsList"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var GetShopperResponseRec = (function (_super) {
__extends(GetShopperResponseRec, _super);
function GetShopperResponseRec(defaults) {
_super.apply(this, arguments);
}
GetShopperResponseRec.attributesToDeclare = function () {
return [
this.attr("ShopperGuid", "shopperGuidAttr", "shopperGuid", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Title", "titleAttr", "title", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("FirstName", "firstNameAttr", "firstName", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("LastName", "lastNameAttr", "lastName", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("AddressLineOne", "addressLineOneAttr", "addressLineOne", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("AddressLineTwo", "addressLineTwoAttr", "addressLineTwo", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Region", "regionAttr", "region", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("City", "cityAttr", "city", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("PostCode", "postCodeAttr", "postCode", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Email", "emailAttr", "email", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("MobileNumber", "mobileNumberAttr", "mobileNumber", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("DateOfBirth", "dateOfBirthAttr", "dateOfBirth", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("TaxIdentifierNumber", "taxIdentifierNumberAttr", "taxIdentifierNumber", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("CountryOfResidenceIso", "countryOfResidenceIsoAttr", "countryOfResidenceIso", false, false, OS.DataTypes.DataTypes.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("CountryOfResidenceTerritoryCode", "countryOfResidenceTerritoryCodeAttr", "countryOfResidenceTerritoryCode", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("NationalityIso", "nationalityIsoAttr", "nationalityIso", false, false, OS.DataTypes.DataTypes.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("EulaAcceptanceDate", "eulaAcceptanceDateAttr", "eulaAcceptanceDate", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("EulaAcceptanceVersion", "eulaAcceptanceVersionAttr", "eulaAcceptanceVersion", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("EulaAccepted", "eulaAcceptedAttr", "eulaAccepted", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("TravelDocuments", "travelDocumentsAttr", "travelDocuments", false, false, OS.DataTypes.DataTypes.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Shopper_ISModel.GetShopperTravelDocumentsList());
}, true, ShopperPortalEU_Shopper_ISModel.GetShopperTravelDocumentsList)
].concat(_super.attributesToDeclare.call(this));
};
GetShopperResponseRec.init();
return GetShopperResponseRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Shopper_ISModel.GetShopperResponseRec = GetShopperResponseRec;

});
define("ShopperPortalEU_Shopper_IS.model$GetShopperResponseList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.model$GetShopperResponseRec"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var GetShopperResponseList = (function (_super) {
__extends(GetShopperResponseList, _super);
function GetShopperResponseList(defaults) {
_super.apply(this, arguments);
}
GetShopperResponseList.itemType = ShopperPortalEU_Shopper_ISModel.GetShopperResponseRec;
return GetShopperResponseList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Shopper_ISModel.GetShopperResponseList = GetShopperResponseList;

});
define("ShopperPortalEU_Shopper_IS.model$GetDatatransTokenCardInfoRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var GetDatatransTokenCardInfoRec = (function (_super) {
__extends(GetDatatransTokenCardInfoRec, _super);
function GetDatatransTokenCardInfoRec(defaults) {
_super.apply(this, arguments);
}
GetDatatransTokenCardInfoRec.attributesToDeclare = function () {
return [
this.attr("Brand", "brandAttr", "brand", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Type", "typeAttr", "type", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Usage", "usageAttr", "usage", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Country", "countryAttr", "country", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Issuer", "issuerAttr", "issuer", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
GetDatatransTokenCardInfoRec.init();
return GetDatatransTokenCardInfoRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Shopper_ISModel.GetDatatransTokenCardInfoRec = GetDatatransTokenCardInfoRec;

});
define("ShopperPortalEU_Shopper_IS.model$GetDatatransTokenRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.model$GetDatatransTokenCardInfoRec"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var GetDatatransTokenRec = (function (_super) {
__extends(GetDatatransTokenRec, _super);
function GetDatatransTokenRec(defaults) {
_super.apply(this, arguments);
}
GetDatatransTokenRec.attributesToDeclare = function () {
return [
this.attr("PaymentMethod", "paymentMethodAttr", "paymentMethod", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Alias", "aliasAttr", "alias", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Fingerprint", "fingerprintAttr", "fingerprint", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("MaskedCard", "maskedCardAttr", "maskedCard", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("CardInfo", "cardInfoAttr", "cardInfo", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Shopper_ISModel.GetDatatransTokenCardInfoRec());
}, true, ShopperPortalEU_Shopper_ISModel.GetDatatransTokenCardInfoRec)
].concat(_super.attributesToDeclare.call(this));
};
GetDatatransTokenRec.init();
return GetDatatransTokenRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Shopper_ISModel.GetDatatransTokenRec = GetDatatransTokenRec;

});
define("ShopperPortalEU_Shopper_IS.model$GetDatatransTokenList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.model$GetDatatransTokenRec"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var GetDatatransTokenList = (function (_super) {
__extends(GetDatatransTokenList, _super);
function GetDatatransTokenList(defaults) {
_super.apply(this, arguments);
}
GetDatatransTokenList.itemType = ShopperPortalEU_Shopper_ISModel.GetDatatransTokenRec;
return GetDatatransTokenList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Shopper_ISModel.GetDatatransTokenList = GetDatatransTokenList;

});
define("ShopperPortalEU_Shopper_IS.model$CreateCardRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.model$CreateCardDataRec"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var CreateCardRec = (function (_super) {
__extends(CreateCardRec, _super);
function CreateCardRec(defaults) {
_super.apply(this, arguments);
}
CreateCardRec.attributesToDeclare = function () {
return [
this.attr("TransactionId", "transactionIdAttr", "TransactionId", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("ShopperGuid", "shopperGuidAttr", "shopperGuid", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("CardData", "cardDataAttr", "card", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Shopper_ISModel.CreateCardDataRec());
}, true, ShopperPortalEU_Shopper_ISModel.CreateCardDataRec)
].concat(_super.attributesToDeclare.call(this));
};
CreateCardRec.init();
return CreateCardRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Shopper_ISModel.CreateCardRec = CreateCardRec;

});
define("ShopperPortalEU_Shopper_IS.model$CreateCardRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.model$CreateCardRec"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var CreateCardRecord = (function (_super) {
__extends(CreateCardRecord, _super);
function CreateCardRecord(defaults) {
_super.apply(this, arguments);
}
CreateCardRecord.attributesToDeclare = function () {
return [
this.attr("CreateCard", "createCardAttr", "CreateCard", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Shopper_ISModel.CreateCardRec());
}, true, ShopperPortalEU_Shopper_ISModel.CreateCardRec)
].concat(_super.attributesToDeclare.call(this));
};
CreateCardRecord.fromStructure = function (str) {
return new CreateCardRecord(new CreateCardRecord.RecordClass({
createCardAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CreateCardRecord._isAnonymousRecord = true;
CreateCardRecord.UniqueId = "2aa63039-c51f-079c-c2a5-f20293781d0c";
CreateCardRecord.init();
return CreateCardRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Shopper_ISModel.CreateCardRecord = CreateCardRecord;

});
define("ShopperPortalEU_Shopper_IS.model$DeleteCardBodyRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var DeleteCardBodyRec = (function (_super) {
__extends(DeleteCardBodyRec, _super);
function DeleteCardBodyRec(defaults) {
_super.apply(this, arguments);
}
DeleteCardBodyRec.attributesToDeclare = function () {
return [
this.attr("tokenValue", "tokenValueAttr", "tokenValue", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("tokenProvider", "tokenProviderAttr", "tokenProvider", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
DeleteCardBodyRec.init();
return DeleteCardBodyRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Shopper_ISModel.DeleteCardBodyRec = DeleteCardBodyRec;

});
define("ShopperPortalEU_Shopper_IS.model$DeleteCardRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.model$DeleteCardBodyRec"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var DeleteCardRec = (function (_super) {
__extends(DeleteCardRec, _super);
function DeleteCardRec(defaults) {
_super.apply(this, arguments);
}
DeleteCardRec.attributesToDeclare = function () {
return [
this.attr("ShopperGuid", "shopperGuidAttr", "shopperGuid", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("DeleteCardBody", "deleteCardBodyAttr", "DeleteCardBody", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Shopper_ISModel.DeleteCardBodyRec());
}, true, ShopperPortalEU_Shopper_ISModel.DeleteCardBodyRec)
].concat(_super.attributesToDeclare.call(this));
};
DeleteCardRec.init();
return DeleteCardRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Shopper_ISModel.DeleteCardRec = DeleteCardRec;

});
define("ShopperPortalEU_Shopper_IS.model$DeleteCardRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.model$DeleteCardRec"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var DeleteCardRecord = (function (_super) {
__extends(DeleteCardRecord, _super);
function DeleteCardRecord(defaults) {
_super.apply(this, arguments);
}
DeleteCardRecord.attributesToDeclare = function () {
return [
this.attr("DeleteCard", "deleteCardAttr", "DeleteCard", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Shopper_ISModel.DeleteCardRec());
}, true, ShopperPortalEU_Shopper_ISModel.DeleteCardRec)
].concat(_super.attributesToDeclare.call(this));
};
DeleteCardRecord.fromStructure = function (str) {
return new DeleteCardRecord(new DeleteCardRecord.RecordClass({
deleteCardAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
DeleteCardRecord._isAnonymousRecord = true;
DeleteCardRecord.UniqueId = "2acdfd0f-8e9a-b3a5-161b-827328775995";
DeleteCardRecord.init();
return DeleteCardRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Shopper_ISModel.DeleteCardRecord = DeleteCardRecord;

});
define("ShopperPortalEU_Shopper_IS.model$PostCardBodyRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var PostCardBodyRec = (function (_super) {
__extends(PostCardBodyRec, _super);
function PostCardBodyRec(defaults) {
_super.apply(this, arguments);
}
PostCardBodyRec.attributesToDeclare = function () {
return [
this.attr("MaskedCardNumber", "maskedCardNumberAttr", "maskedCardNumber", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("ExpiryDate", "expiryDateAttr", "expiryDate", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("IsDefault", "isDefaultAttr", "isDefault", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("PaymentMethod", "paymentMethodAttr", "paymentMethod", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("TokenValue", "tokenValueAttr", "tokenValue", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("TokenProvider", "tokenProviderAttr", "tokenProvider", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("CardHolderName", "cardHolderNameAttr", "cardHolderName", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PostCardBodyRec.init();
return PostCardBodyRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Shopper_ISModel.PostCardBodyRec = PostCardBodyRec;

});
define("ShopperPortalEU_Shopper_IS.model$PostCardBodyList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.model$PostCardBodyRec"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var PostCardBodyList = (function (_super) {
__extends(PostCardBodyList, _super);
function PostCardBodyList(defaults) {
_super.apply(this, arguments);
}
PostCardBodyList.itemType = ShopperPortalEU_Shopper_ISModel.PostCardBodyRec;
return PostCardBodyList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Shopper_ISModel.PostCardBodyList = PostCardBodyList;

});
define("ShopperPortalEU_Shopper_IS.model$GetCardsResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var GetCardsResponseRec = (function (_super) {
__extends(GetCardsResponseRec, _super);
function GetCardsResponseRec(defaults) {
_super.apply(this, arguments);
}
GetCardsResponseRec.attributesToDeclare = function () {
return [
this.attr("MaskedCardNumber", "maskedCardNumberAttr", "maskedCardNumber", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("ExpiryDate", "expiryDateAttr", "expiryDate", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("ExpiryDateFormat", "expiryDateFormatAttr", "expiryDateFormat", false, false, OS.DataTypes.DataTypes.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("IsDefault", "isDefaultAttr", "isDefault", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("PaymentMethod", "paymentMethodAttr", "paymentMethod", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("TokenValue", "tokenValueAttr", "tokenValue", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("TokenProvider", "tokenProviderAttr", "tokenProvider", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("CardHolderName", "cardHolderNameAttr", "cardHolderName", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
GetCardsResponseRec.init();
return GetCardsResponseRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Shopper_ISModel.GetCardsResponseRec = GetCardsResponseRec;

});
define("ShopperPortalEU_Shopper_IS.model$GetShopperResponseRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.model$GetShopperResponseRec"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var GetShopperResponseRecord = (function (_super) {
__extends(GetShopperResponseRecord, _super);
function GetShopperResponseRecord(defaults) {
_super.apply(this, arguments);
}
GetShopperResponseRecord.attributesToDeclare = function () {
return [
this.attr("GetShopperResponse", "getShopperResponseAttr", "GetShopperResponse", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Shopper_ISModel.GetShopperResponseRec());
}, true, ShopperPortalEU_Shopper_ISModel.GetShopperResponseRec)
].concat(_super.attributesToDeclare.call(this));
};
GetShopperResponseRecord.fromStructure = function (str) {
return new GetShopperResponseRecord(new GetShopperResponseRecord.RecordClass({
getShopperResponseAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
GetShopperResponseRecord._isAnonymousRecord = true;
GetShopperResponseRecord.UniqueId = "d97a7288-58bb-d5f9-7397-3049472192c4";
GetShopperResponseRecord.init();
return GetShopperResponseRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Shopper_ISModel.GetShopperResponseRecord = GetShopperResponseRecord;

});
define("ShopperPortalEU_Shopper_IS.model$GetShopperResponseRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.model$GetShopperResponseRecord"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var GetShopperResponseRecordList = (function (_super) {
__extends(GetShopperResponseRecordList, _super);
function GetShopperResponseRecordList(defaults) {
_super.apply(this, arguments);
}
GetShopperResponseRecordList.itemType = ShopperPortalEU_Shopper_ISModel.GetShopperResponseRecord;
return GetShopperResponseRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Shopper_ISModel.GetShopperResponseRecordList = GetShopperResponseRecordList;

});
define("ShopperPortalEU_Shopper_IS.model$PostCardBodyRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.model$PostCardBodyRec"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var PostCardBodyRecord = (function (_super) {
__extends(PostCardBodyRecord, _super);
function PostCardBodyRecord(defaults) {
_super.apply(this, arguments);
}
PostCardBodyRecord.attributesToDeclare = function () {
return [
this.attr("PostCardBody", "postCardBodyAttr", "PostCardBody", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Shopper_ISModel.PostCardBodyRec());
}, true, ShopperPortalEU_Shopper_ISModel.PostCardBodyRec)
].concat(_super.attributesToDeclare.call(this));
};
PostCardBodyRecord.fromStructure = function (str) {
return new PostCardBodyRecord(new PostCardBodyRecord.RecordClass({
postCardBodyAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
PostCardBodyRecord._isAnonymousRecord = true;
PostCardBodyRecord.UniqueId = "67b0ea2d-07ac-59e6-171c-98c9e7122ee1";
PostCardBodyRecord.init();
return PostCardBodyRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Shopper_ISModel.PostCardBodyRecord = PostCardBodyRecord;

});
define("ShopperPortalEU_Shopper_IS.model$PostCardBodyRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.model$PostCardBodyRecord"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var PostCardBodyRecordList = (function (_super) {
__extends(PostCardBodyRecordList, _super);
function PostCardBodyRecordList(defaults) {
_super.apply(this, arguments);
}
PostCardBodyRecordList.itemType = ShopperPortalEU_Shopper_ISModel.PostCardBodyRecord;
return PostCardBodyRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Shopper_ISModel.PostCardBodyRecordList = PostCardBodyRecordList;

});
define("ShopperPortalEU_Shopper_IS.model$UpdateCardRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.model$UpdateCardRec"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var UpdateCardRecord = (function (_super) {
__extends(UpdateCardRecord, _super);
function UpdateCardRecord(defaults) {
_super.apply(this, arguments);
}
UpdateCardRecord.attributesToDeclare = function () {
return [
this.attr("UpdateCard", "updateCardAttr", "UpdateCard", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Shopper_ISModel.UpdateCardRec());
}, true, ShopperPortalEU_Shopper_ISModel.UpdateCardRec)
].concat(_super.attributesToDeclare.call(this));
};
UpdateCardRecord.fromStructure = function (str) {
return new UpdateCardRecord(new UpdateCardRecord.RecordClass({
updateCardAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
UpdateCardRecord._isAnonymousRecord = true;
UpdateCardRecord.UniqueId = "92948489-f574-cf5e-cee2-940c8bf3009f";
UpdateCardRecord.init();
return UpdateCardRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Shopper_ISModel.UpdateCardRecord = UpdateCardRecord;

});
define("ShopperPortalEU_Shopper_IS.model$UpdateCardRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.model$UpdateCardRecord"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var UpdateCardRecordList = (function (_super) {
__extends(UpdateCardRecordList, _super);
function UpdateCardRecordList(defaults) {
_super.apply(this, arguments);
}
UpdateCardRecordList.itemType = ShopperPortalEU_Shopper_ISModel.UpdateCardRecord;
return UpdateCardRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Shopper_ISModel.UpdateCardRecordList = UpdateCardRecordList;

});
define("ShopperPortalEU_Shopper_IS.model$CreateCardDataRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.model$CreateCardDataRec"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var CreateCardDataRecord = (function (_super) {
__extends(CreateCardDataRecord, _super);
function CreateCardDataRecord(defaults) {
_super.apply(this, arguments);
}
CreateCardDataRecord.attributesToDeclare = function () {
return [
this.attr("CreateCardData", "createCardDataAttr", "CreateCardData", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Shopper_ISModel.CreateCardDataRec());
}, true, ShopperPortalEU_Shopper_ISModel.CreateCardDataRec)
].concat(_super.attributesToDeclare.call(this));
};
CreateCardDataRecord.fromStructure = function (str) {
return new CreateCardDataRecord(new CreateCardDataRecord.RecordClass({
createCardDataAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CreateCardDataRecord._isAnonymousRecord = true;
CreateCardDataRecord.UniqueId = "51a8e68a-2f02-433f-3762-3dcf86152272";
CreateCardDataRecord.init();
return CreateCardDataRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Shopper_ISModel.CreateCardDataRecord = CreateCardDataRecord;

});
define("ShopperPortalEU_Shopper_IS.model$CreateCardDataRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.model$CreateCardDataRecord"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var CreateCardDataRecordList = (function (_super) {
__extends(CreateCardDataRecordList, _super);
function CreateCardDataRecordList(defaults) {
_super.apply(this, arguments);
}
CreateCardDataRecordList.itemType = ShopperPortalEU_Shopper_ISModel.CreateCardDataRecord;
return CreateCardDataRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Shopper_ISModel.CreateCardDataRecordList = CreateCardDataRecordList;

});
define("ShopperPortalEU_Shopper_IS.model$GetShopperTravelDocumentsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.model$GetShopperTravelDocumentsRec"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var GetShopperTravelDocumentsRecord = (function (_super) {
__extends(GetShopperTravelDocumentsRecord, _super);
function GetShopperTravelDocumentsRecord(defaults) {
_super.apply(this, arguments);
}
GetShopperTravelDocumentsRecord.attributesToDeclare = function () {
return [
this.attr("GetShopperTravelDocuments", "getShopperTravelDocumentsAttr", "GetShopperTravelDocuments", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Shopper_ISModel.GetShopperTravelDocumentsRec());
}, true, ShopperPortalEU_Shopper_ISModel.GetShopperTravelDocumentsRec)
].concat(_super.attributesToDeclare.call(this));
};
GetShopperTravelDocumentsRecord.fromStructure = function (str) {
return new GetShopperTravelDocumentsRecord(new GetShopperTravelDocumentsRecord.RecordClass({
getShopperTravelDocumentsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
GetShopperTravelDocumentsRecord._isAnonymousRecord = true;
GetShopperTravelDocumentsRecord.UniqueId = "647d66f0-d221-16fd-af5c-cef5e4e38375";
GetShopperTravelDocumentsRecord.init();
return GetShopperTravelDocumentsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Shopper_ISModel.GetShopperTravelDocumentsRecord = GetShopperTravelDocumentsRecord;

});
define("ShopperPortalEU_Shopper_IS.model$GetShopperTravelDocumentsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.model$GetShopperTravelDocumentsRecord"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var GetShopperTravelDocumentsRecordList = (function (_super) {
__extends(GetShopperTravelDocumentsRecordList, _super);
function GetShopperTravelDocumentsRecordList(defaults) {
_super.apply(this, arguments);
}
GetShopperTravelDocumentsRecordList.itemType = ShopperPortalEU_Shopper_ISModel.GetShopperTravelDocumentsRecord;
return GetShopperTravelDocumentsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Shopper_ISModel.GetShopperTravelDocumentsRecordList = GetShopperTravelDocumentsRecordList;

});
define("ShopperPortalEU_Shopper_IS.model$CreateCardList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.model$CreateCardRec"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var CreateCardList = (function (_super) {
__extends(CreateCardList, _super);
function CreateCardList(defaults) {
_super.apply(this, arguments);
}
CreateCardList.itemType = ShopperPortalEU_Shopper_ISModel.CreateCardRec;
return CreateCardList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Shopper_ISModel.CreateCardList = CreateCardList;

});
define("ShopperPortalEU_Shopper_IS.model$GetDatatransTokenRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.model$GetDatatransTokenRec"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var GetDatatransTokenRecord = (function (_super) {
__extends(GetDatatransTokenRecord, _super);
function GetDatatransTokenRecord(defaults) {
_super.apply(this, arguments);
}
GetDatatransTokenRecord.attributesToDeclare = function () {
return [
this.attr("GetDatatransToken", "getDatatransTokenAttr", "GetDatatransToken", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Shopper_ISModel.GetDatatransTokenRec());
}, true, ShopperPortalEU_Shopper_ISModel.GetDatatransTokenRec)
].concat(_super.attributesToDeclare.call(this));
};
GetDatatransTokenRecord.fromStructure = function (str) {
return new GetDatatransTokenRecord(new GetDatatransTokenRecord.RecordClass({
getDatatransTokenAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
GetDatatransTokenRecord._isAnonymousRecord = true;
GetDatatransTokenRecord.UniqueId = "61431d1a-1b91-0d4c-17d7-f3caeed93cda";
GetDatatransTokenRecord.init();
return GetDatatransTokenRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Shopper_ISModel.GetDatatransTokenRecord = GetDatatransTokenRecord;

});
define("ShopperPortalEU_Shopper_IS.model$DatatransTokenFallbackRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var DatatransTokenFallbackRec = (function (_super) {
__extends(DatatransTokenFallbackRec, _super);
function DatatransTokenFallbackRec(defaults) {
_super.apply(this, arguments);
}
DatatransTokenFallbackRec.attributesToDeclare = function () {
return [
this.attr("Alias", "aliasAttr", "fingerprint", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("MaskedCard", "maskedCardAttr", "maskedCard", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("PaymentMethod", "paymentMethodAttr", "paymentMethod", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
DatatransTokenFallbackRec.init();
return DatatransTokenFallbackRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Shopper_ISModel.DatatransTokenFallbackRec = DatatransTokenFallbackRec;

});
define("ShopperPortalEU_Shopper_IS.model$DatatransTokenFallbackList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.model$DatatransTokenFallbackRec"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var DatatransTokenFallbackList = (function (_super) {
__extends(DatatransTokenFallbackList, _super);
function DatatransTokenFallbackList(defaults) {
_super.apply(this, arguments);
}
DatatransTokenFallbackList.itemType = ShopperPortalEU_Shopper_ISModel.DatatransTokenFallbackRec;
return DatatransTokenFallbackList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Shopper_ISModel.DatatransTokenFallbackList = DatatransTokenFallbackList;

});
define("ShopperPortalEU_Shopper_IS.model$DeleteCardList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.model$DeleteCardRec"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var DeleteCardList = (function (_super) {
__extends(DeleteCardList, _super);
function DeleteCardList(defaults) {
_super.apply(this, arguments);
}
DeleteCardList.itemType = ShopperPortalEU_Shopper_ISModel.DeleteCardRec;
return DeleteCardList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Shopper_ISModel.DeleteCardList = DeleteCardList;

});
define("ShopperPortalEU_Shopper_IS.model$DatatransTokenFallbackRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.model$DatatransTokenFallbackRec"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var DatatransTokenFallbackRecord = (function (_super) {
__extends(DatatransTokenFallbackRecord, _super);
function DatatransTokenFallbackRecord(defaults) {
_super.apply(this, arguments);
}
DatatransTokenFallbackRecord.attributesToDeclare = function () {
return [
this.attr("DatatransTokenFallback", "datatransTokenFallbackAttr", "DatatransTokenFallback", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Shopper_ISModel.DatatransTokenFallbackRec());
}, true, ShopperPortalEU_Shopper_ISModel.DatatransTokenFallbackRec)
].concat(_super.attributesToDeclare.call(this));
};
DatatransTokenFallbackRecord.fromStructure = function (str) {
return new DatatransTokenFallbackRecord(new DatatransTokenFallbackRecord.RecordClass({
datatransTokenFallbackAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
DatatransTokenFallbackRecord._isAnonymousRecord = true;
DatatransTokenFallbackRecord.UniqueId = "a00329e6-e7a4-5fa0-fa18-442f4b66f64e";
DatatransTokenFallbackRecord.init();
return DatatransTokenFallbackRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Shopper_ISModel.DatatransTokenFallbackRecord = DatatransTokenFallbackRecord;

});
define("ShopperPortalEU_Shopper_IS.model$DatatransTokenFallbackRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.model$DatatransTokenFallbackRecord"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var DatatransTokenFallbackRecordList = (function (_super) {
__extends(DatatransTokenFallbackRecordList, _super);
function DatatransTokenFallbackRecordList(defaults) {
_super.apply(this, arguments);
}
DatatransTokenFallbackRecordList.itemType = ShopperPortalEU_Shopper_ISModel.DatatransTokenFallbackRecord;
return DatatransTokenFallbackRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Shopper_ISModel.DatatransTokenFallbackRecordList = DatatransTokenFallbackRecordList;

});
define("ShopperPortalEU_Shopper_IS.model$DeleteCardBodyRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.model$DeleteCardBodyRec"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var DeleteCardBodyRecord = (function (_super) {
__extends(DeleteCardBodyRecord, _super);
function DeleteCardBodyRecord(defaults) {
_super.apply(this, arguments);
}
DeleteCardBodyRecord.attributesToDeclare = function () {
return [
this.attr("DeleteCardBody", "deleteCardBodyAttr", "DeleteCardBody", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Shopper_ISModel.DeleteCardBodyRec());
}, true, ShopperPortalEU_Shopper_ISModel.DeleteCardBodyRec)
].concat(_super.attributesToDeclare.call(this));
};
DeleteCardBodyRecord.fromStructure = function (str) {
return new DeleteCardBodyRecord(new DeleteCardBodyRecord.RecordClass({
deleteCardBodyAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
DeleteCardBodyRecord._isAnonymousRecord = true;
DeleteCardBodyRecord.UniqueId = "b237ea99-f2e2-374b-5e07-724bfc5e422c";
DeleteCardBodyRecord.init();
return DeleteCardBodyRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Shopper_ISModel.DeleteCardBodyRecord = DeleteCardBodyRecord;

});
define("ShopperPortalEU_Shopper_IS.model$DeleteCardBodyRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.model$DeleteCardBodyRecord"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var DeleteCardBodyRecordList = (function (_super) {
__extends(DeleteCardBodyRecordList, _super);
function DeleteCardBodyRecordList(defaults) {
_super.apply(this, arguments);
}
DeleteCardBodyRecordList.itemType = ShopperPortalEU_Shopper_ISModel.DeleteCardBodyRecord;
return DeleteCardBodyRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Shopper_ISModel.DeleteCardBodyRecordList = DeleteCardBodyRecordList;

});
define("ShopperPortalEU_Shopper_IS.model$UpdateCardDataRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.model$UpdateCardDataRec"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var UpdateCardDataRecord = (function (_super) {
__extends(UpdateCardDataRecord, _super);
function UpdateCardDataRecord(defaults) {
_super.apply(this, arguments);
}
UpdateCardDataRecord.attributesToDeclare = function () {
return [
this.attr("UpdateCardData", "updateCardDataAttr", "UpdateCardData", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Shopper_ISModel.UpdateCardDataRec());
}, true, ShopperPortalEU_Shopper_ISModel.UpdateCardDataRec)
].concat(_super.attributesToDeclare.call(this));
};
UpdateCardDataRecord.fromStructure = function (str) {
return new UpdateCardDataRecord(new UpdateCardDataRecord.RecordClass({
updateCardDataAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
UpdateCardDataRecord._isAnonymousRecord = true;
UpdateCardDataRecord.UniqueId = "74e578f3-3808-27d7-bafc-9a0ba367ac89";
UpdateCardDataRecord.init();
return UpdateCardDataRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Shopper_ISModel.UpdateCardDataRecord = UpdateCardDataRecord;

});
define("ShopperPortalEU_Shopper_IS.model$PostCardRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.model$PostCardBodyRec"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var PostCardRec = (function (_super) {
__extends(PostCardRec, _super);
function PostCardRec(defaults) {
_super.apply(this, arguments);
}
PostCardRec.attributesToDeclare = function () {
return [
this.attr("ShopperGuid", "shopperGuidAttr", "shopperGuid", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Body", "bodyAttr", "body", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Shopper_ISModel.PostCardBodyRec());
}, true, ShopperPortalEU_Shopper_ISModel.PostCardBodyRec)
].concat(_super.attributesToDeclare.call(this));
};
PostCardRec.init();
return PostCardRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Shopper_ISModel.PostCardRec = PostCardRec;

});
define("ShopperPortalEU_Shopper_IS.model$PostCardRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.model$PostCardRec"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var PostCardRecord = (function (_super) {
__extends(PostCardRecord, _super);
function PostCardRecord(defaults) {
_super.apply(this, arguments);
}
PostCardRecord.attributesToDeclare = function () {
return [
this.attr("PostCard", "postCardAttr", "PostCard", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Shopper_ISModel.PostCardRec());
}, true, ShopperPortalEU_Shopper_ISModel.PostCardRec)
].concat(_super.attributesToDeclare.call(this));
};
PostCardRecord.fromStructure = function (str) {
return new PostCardRecord(new PostCardRecord.RecordClass({
postCardAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
PostCardRecord._isAnonymousRecord = true;
PostCardRecord.UniqueId = "7959c5cc-fc10-e596-c944-37402454df6d";
PostCardRecord.init();
return PostCardRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Shopper_ISModel.PostCardRecord = PostCardRecord;

});
define("ShopperPortalEU_Shopper_IS.model$PostCardRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.model$PostCardRecord"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var PostCardRecordList = (function (_super) {
__extends(PostCardRecordList, _super);
function PostCardRecordList(defaults) {
_super.apply(this, arguments);
}
PostCardRecordList.itemType = ShopperPortalEU_Shopper_ISModel.PostCardRecord;
return PostCardRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Shopper_ISModel.PostCardRecordList = PostCardRecordList;

});
define("ShopperPortalEU_Shopper_IS.model$PostCardList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.model$PostCardRec"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var PostCardList = (function (_super) {
__extends(PostCardList, _super);
function PostCardList(defaults) {
_super.apply(this, arguments);
}
PostCardList.itemType = ShopperPortalEU_Shopper_ISModel.PostCardRec;
return PostCardList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Shopper_ISModel.PostCardList = PostCardList;

});
define("ShopperPortalEU_Shopper_IS.model$GetDatatransTokenCardInfoRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.model$GetDatatransTokenCardInfoRec"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var GetDatatransTokenCardInfoRecord = (function (_super) {
__extends(GetDatatransTokenCardInfoRecord, _super);
function GetDatatransTokenCardInfoRecord(defaults) {
_super.apply(this, arguments);
}
GetDatatransTokenCardInfoRecord.attributesToDeclare = function () {
return [
this.attr("GetDatatransTokenCardInfo", "getDatatransTokenCardInfoAttr", "GetDatatransTokenCardInfo", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Shopper_ISModel.GetDatatransTokenCardInfoRec());
}, true, ShopperPortalEU_Shopper_ISModel.GetDatatransTokenCardInfoRec)
].concat(_super.attributesToDeclare.call(this));
};
GetDatatransTokenCardInfoRecord.fromStructure = function (str) {
return new GetDatatransTokenCardInfoRecord(new GetDatatransTokenCardInfoRecord.RecordClass({
getDatatransTokenCardInfoAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
GetDatatransTokenCardInfoRecord._isAnonymousRecord = true;
GetDatatransTokenCardInfoRecord.UniqueId = "7e906083-c54b-20be-4a27-590863369fb5";
GetDatatransTokenCardInfoRecord.init();
return GetDatatransTokenCardInfoRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Shopper_ISModel.GetDatatransTokenCardInfoRecord = GetDatatransTokenCardInfoRecord;

});
define("ShopperPortalEU_Shopper_IS.model$GetCardsResponseRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.model$GetCardsResponseRec"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var GetCardsResponseRecord = (function (_super) {
__extends(GetCardsResponseRecord, _super);
function GetCardsResponseRecord(defaults) {
_super.apply(this, arguments);
}
GetCardsResponseRecord.attributesToDeclare = function () {
return [
this.attr("GetCardsResponse", "getCardsResponseAttr", "GetCardsResponse", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Shopper_ISModel.GetCardsResponseRec());
}, true, ShopperPortalEU_Shopper_ISModel.GetCardsResponseRec)
].concat(_super.attributesToDeclare.call(this));
};
GetCardsResponseRecord.fromStructure = function (str) {
return new GetCardsResponseRecord(new GetCardsResponseRecord.RecordClass({
getCardsResponseAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
GetCardsResponseRecord._isAnonymousRecord = true;
GetCardsResponseRecord.UniqueId = "c5ad02da-ae50-7a50-e338-796338df6661";
GetCardsResponseRecord.init();
return GetCardsResponseRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Shopper_ISModel.GetCardsResponseRecord = GetCardsResponseRecord;

});
define("ShopperPortalEU_Shopper_IS.model$GetCardsResponseRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.model$GetCardsResponseRecord"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var GetCardsResponseRecordList = (function (_super) {
__extends(GetCardsResponseRecordList, _super);
function GetCardsResponseRecordList(defaults) {
_super.apply(this, arguments);
}
GetCardsResponseRecordList.itemType = ShopperPortalEU_Shopper_ISModel.GetCardsResponseRecord;
return GetCardsResponseRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Shopper_ISModel.GetCardsResponseRecordList = GetCardsResponseRecordList;

});
define("ShopperPortalEU_Shopper_IS.model$CreateCardRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.model$CreateCardRecord"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var CreateCardRecordList = (function (_super) {
__extends(CreateCardRecordList, _super);
function CreateCardRecordList(defaults) {
_super.apply(this, arguments);
}
CreateCardRecordList.itemType = ShopperPortalEU_Shopper_ISModel.CreateCardRecord;
return CreateCardRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Shopper_ISModel.CreateCardRecordList = CreateCardRecordList;

});
define("ShopperPortalEU_Shopper_IS.model$GetCardsResponseList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.model$GetCardsResponseRec"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var GetCardsResponseList = (function (_super) {
__extends(GetCardsResponseList, _super);
function GetCardsResponseList(defaults) {
_super.apply(this, arguments);
}
GetCardsResponseList.itemType = ShopperPortalEU_Shopper_ISModel.GetCardsResponseRec;
return GetCardsResponseList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Shopper_ISModel.GetCardsResponseList = GetCardsResponseList;

});
define("ShopperPortalEU_Shopper_IS.model$GetDatatransTokenRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.model$GetDatatransTokenRecord"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var GetDatatransTokenRecordList = (function (_super) {
__extends(GetDatatransTokenRecordList, _super);
function GetDatatransTokenRecordList(defaults) {
_super.apply(this, arguments);
}
GetDatatransTokenRecordList.itemType = ShopperPortalEU_Shopper_ISModel.GetDatatransTokenRecord;
return GetDatatransTokenRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Shopper_ISModel.GetDatatransTokenRecordList = GetDatatransTokenRecordList;

});
define("ShopperPortalEU_Shopper_IS.model$GetDatatransTokenCardInfoRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.model$GetDatatransTokenCardInfoRecord"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var GetDatatransTokenCardInfoRecordList = (function (_super) {
__extends(GetDatatransTokenCardInfoRecordList, _super);
function GetDatatransTokenCardInfoRecordList(defaults) {
_super.apply(this, arguments);
}
GetDatatransTokenCardInfoRecordList.itemType = ShopperPortalEU_Shopper_ISModel.GetDatatransTokenCardInfoRecord;
return GetDatatransTokenCardInfoRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Shopper_ISModel.GetDatatransTokenCardInfoRecordList = GetDatatransTokenCardInfoRecordList;

});
define("ShopperPortalEU_Shopper_IS.model$GetDatatransTokenCardInfoList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.model$GetDatatransTokenCardInfoRec"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var GetDatatransTokenCardInfoList = (function (_super) {
__extends(GetDatatransTokenCardInfoList, _super);
function GetDatatransTokenCardInfoList(defaults) {
_super.apply(this, arguments);
}
GetDatatransTokenCardInfoList.itemType = ShopperPortalEU_Shopper_ISModel.GetDatatransTokenCardInfoRec;
return GetDatatransTokenCardInfoList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Shopper_ISModel.GetDatatransTokenCardInfoList = GetDatatransTokenCardInfoList;

});
define("ShopperPortalEU_Shopper_IS.model$RequestSignupList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.model$RequestSignupRec"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var RequestSignupList = (function (_super) {
__extends(RequestSignupList, _super);
function RequestSignupList(defaults) {
_super.apply(this, arguments);
}
RequestSignupList.itemType = ShopperPortalEU_Shopper_ISModel.RequestSignupRec;
return RequestSignupList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Shopper_ISModel.RequestSignupList = RequestSignupList;

});
define("ShopperPortalEU_Shopper_IS.model$UpdateCardDataRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.model$UpdateCardDataRecord"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var UpdateCardDataRecordList = (function (_super) {
__extends(UpdateCardDataRecordList, _super);
function UpdateCardDataRecordList(defaults) {
_super.apply(this, arguments);
}
UpdateCardDataRecordList.itemType = ShopperPortalEU_Shopper_ISModel.UpdateCardDataRecord;
return UpdateCardDataRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Shopper_ISModel.UpdateCardDataRecordList = UpdateCardDataRecordList;

});
define("ShopperPortalEU_Shopper_IS.model$DeleteCardBodyList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.model$DeleteCardBodyRec"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var DeleteCardBodyList = (function (_super) {
__extends(DeleteCardBodyList, _super);
function DeleteCardBodyList(defaults) {
_super.apply(this, arguments);
}
DeleteCardBodyList.itemType = ShopperPortalEU_Shopper_ISModel.DeleteCardBodyRec;
return DeleteCardBodyList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Shopper_ISModel.DeleteCardBodyList = DeleteCardBodyList;

});
define("ShopperPortalEU_Shopper_IS.model$DeleteCardRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.model$DeleteCardRecord"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel) {
var OS = OutSystems.Internal;
var DeleteCardRecordList = (function (_super) {
__extends(DeleteCardRecordList, _super);
function DeleteCardRecordList(defaults) {
_super.apply(this, arguments);
}
DeleteCardRecordList.itemType = ShopperPortalEU_Shopper_ISModel.DeleteCardRecord;
return DeleteCardRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Shopper_ISModel.DeleteCardRecordList = DeleteCardRecordList;

});
define("ShopperPortalEU_Shopper_IS.model", ["exports", "OutSystems/ClientRuntime/Main"], function (exports, OutSystems) {
var OS = OutSystems.Internal;
var ShopperPortalEU_Shopper_ISModel = exports;
Object.defineProperty(ShopperPortalEU_Shopper_ISModel, "module", {
get: function () {
return OS.ApplicationInfo.getModules()["dae28401-1bb1-44d6-afe7-42ff2db37f08"];
}
});

ShopperPortalEU_Shopper_ISModel.staticEntities = {};
});
