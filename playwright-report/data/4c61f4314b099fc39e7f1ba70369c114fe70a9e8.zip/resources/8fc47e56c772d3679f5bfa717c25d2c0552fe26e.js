define("Auth_Europe.model$", ["exports", "OutSystems/ClientRuntime/Main", "Auth_Europe.model"], function (exports, OutSystems, Auth_EuropeModel) {
var OS = OutSystems.Internal;
var TextList = (function (_super) {
__extends(TextList, _super);
function TextList(defaults) {
_super.apply(this, arguments);
}
TextList.itemType = OS.DataTypes.DataTypes.Text;
return TextList;
})(OS.DataTypes.GenericRecordList);
Auth_EuropeModel.TextList = TextList;

});
define("Auth_Europe.model$AccessInfoRec", ["exports", "OutSystems/ClientRuntime/Main", "Auth_Europe.model"], function (exports, OutSystems, Auth_EuropeModel) {
var OS = OutSystems.Internal;
var AccessInfoRec = (function (_super) {
__extends(AccessInfoRec, _super);
function AccessInfoRec(defaults) {
_super.apply(this, arguments);
}
AccessInfoRec.attributesToDeclare = function () {
return [
this.attr("ShopperGuid", "shopperGuidAttr", "shopper_guid", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("PreferredLanguage", "preferredLanguageAttr", "preferred_language", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("UserType", "userTypeAttr", "user_type", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Roles", "rolesAttr", "roles", false, false, OS.DataTypes.DataTypes.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new OS.DataTypes.TextList());
}, true, OS.DataTypes.TextList)
].concat(_super.attributesToDeclare.call(this));
};
AccessInfoRec.init();
return AccessInfoRec;
})(OS.DataTypes.GenericRecord);
Auth_EuropeModel.AccessInfoRec = AccessInfoRec;

});
define("Auth_Europe.model$AccessInfoRecord", ["exports", "OutSystems/ClientRuntime/Main", "Auth_Europe.model", "Auth_Europe.model$AccessInfoRec"], function (exports, OutSystems, Auth_EuropeModel) {
var OS = OutSystems.Internal;
var AccessInfoRecord = (function (_super) {
__extends(AccessInfoRecord, _super);
function AccessInfoRecord(defaults) {
_super.apply(this, arguments);
}
AccessInfoRecord.attributesToDeclare = function () {
return [
this.attr("AccessInfo", "accessInfoAttr", "AccessInfo", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new Auth_EuropeModel.AccessInfoRec());
}, true, Auth_EuropeModel.AccessInfoRec)
].concat(_super.attributesToDeclare.call(this));
};
AccessInfoRecord.fromStructure = function (str) {
return new AccessInfoRecord(new AccessInfoRecord.RecordClass({
accessInfoAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
AccessInfoRecord._isAnonymousRecord = true;
AccessInfoRecord.UniqueId = "9683fe1d-cb74-0ed6-b719-506d17b99a3f";
AccessInfoRecord.init();
return AccessInfoRecord;
})(OS.DataTypes.GenericRecord);
Auth_EuropeModel.AccessInfoRecord = AccessInfoRecord;

});
define("Auth_Europe.model$AccessInfoRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Auth_Europe.model", "Auth_Europe.model$AccessInfoRecord"], function (exports, OutSystems, Auth_EuropeModel) {
var OS = OutSystems.Internal;
var AccessInfoRecordList = (function (_super) {
__extends(AccessInfoRecordList, _super);
function AccessInfoRecordList(defaults) {
_super.apply(this, arguments);
}
AccessInfoRecordList.itemType = Auth_EuropeModel.AccessInfoRecord;
return AccessInfoRecordList;
})(OS.DataTypes.GenericRecordList);
Auth_EuropeModel.AccessInfoRecordList = AccessInfoRecordList;

});
define("Auth_Europe.model$AccessInfoList", ["exports", "OutSystems/ClientRuntime/Main", "Auth_Europe.model", "Auth_Europe.model$AccessInfoRec"], function (exports, OutSystems, Auth_EuropeModel) {
var OS = OutSystems.Internal;
var AccessInfoList = (function (_super) {
__extends(AccessInfoList, _super);
function AccessInfoList(defaults) {
_super.apply(this, arguments);
}
AccessInfoList.itemType = Auth_EuropeModel.AccessInfoRec;
return AccessInfoList;
})(OS.DataTypes.GenericRecordList);
Auth_EuropeModel.AccessInfoList = AccessInfoList;

});
define("Auth_Europe.model", ["exports", "OutSystems/ClientRuntime/Main"], function (exports, OutSystems) {
var OS = OutSystems.Internal;
var Auth_EuropeModel = exports;
Object.defineProperty(Auth_EuropeModel, "module", {
get: function () {
return OS.ApplicationInfo.getModules()["b2bd97e1-68ea-44fe-9e4b-23b8ba4dc689"];
}
});

Auth_EuropeModel.staticEntities = {};
});
