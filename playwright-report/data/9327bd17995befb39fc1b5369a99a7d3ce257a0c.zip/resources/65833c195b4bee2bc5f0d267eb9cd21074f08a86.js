define("ShopperPortalEU.CreditCard.controller", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU.Common.controller", "ShopperPortalEU.clientVariables", "ShopperPortalEU.CreditCard.controller$debugger"], function (exports, OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_CommonController, ShopperPortalEUClientVariables, ShopperPortalEU_CreditCard_Controller_debugger) {
var OS = OutSystems.Internal;
var ShopperPortalEU_CreditCardController = exports;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
}
Controller.prototype.getDefaultTimeout = function () {
return ShopperPortalEUController.default.defaultTimeout;
};
Controller.prototype.handleError = function (ex, callContext) {
var varBag = {};
var controller = this.controller;
OS.Logger.trace("CreditCard", OS.Exceptions.getMessage(ex), ex.name);
return ShopperPortalEU_CommonController.default.handleError(ex, callContext);


};
return Controller;
})(OS.Controller.BaseController);
ShopperPortalEU_CreditCardController.default = new Controller();
});

define("ShopperPortalEU.CreditCard.controller$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
});
