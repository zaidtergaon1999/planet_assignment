class scanBarcode {
  constructor(id, properties, events) {
    this.class = 'scan-barcode';
    this.element = document.getElementById(id);
    this.properties = properties;
    this.events = events;
    this.listeners = {
      _load: this._load.bind(this),
      _result: this._result.bind(this),
      _error: this._error.bind(this)
    };
    this.anylineObj = null;
    this._build();
  }
  _load() {
    this.events.load();
  }
  _error(data) {
    this.events.error(JSON.stringify(data));
  }
  _result(data) {
    var dataObj = data.result.barcodeResult.barcodes[0];
    this.events.result(JSON.stringify(dataObj));
  }
  _setData() {
    let data = {
      preset: 'legacy_barcode',
      viewConfig: {
        cutouts: [{
          cutoutConfig: {
            strokeWidth: 4,
            cornerRadius: 8,
            strokeColor: 'FFFFFF',
            feedbackStrokeColor: 'FFFFFF'
          },
          scanFeedback: {
            style: 'contour_point',
            strokeColor: 'FFFFFF',
            fillColor: 'FFFFFF',
            strokeWidth: 1,
            cornerRadius: 8,
            vibrateOnResult: true
          },
        }],
      },
      license: this.properties.license,
      element: this.element,
      mirrorOnDesktop: false,
      loadingScreen: '<div data-container="" class="custom-loading"><div data-container="" class="custom-loading__content"><div data-container="" class="custom-loading__loading"><div data-container="" class="custom-loading__loading-item"><div data-container="" class="custom-loading__loading-item-bubble"></div></div><div data-container="" class="custom-loading__loading-item"><div data-container="" class="custom-loading__loading-item-bubble"></div></div><div data-container="" class="custom-loading__loading-item"><div data-container="" class="custom-loading__loading-item-bubble"></div></div><div data-container="" class="custom-loading__loading-item"><div data-container="" class="custom-loading__loading-item-bubble"></div></div><div data-container="" class="custom-loading__loading-item"><div data-container="" class="custom-loading__loading-item-bubble"></div></div><div data-container="" class="custom-loading__loading-item"><div data-container="" class="custom-loading__loading-item-bubble"></div></div><div data-container="" class="custom-loading__loading-item"><div data-container="" class="custom-loading__loading-item-bubble"></div></div><div data-container="" class="custom-loading__loading-item"><div data-container="" class="custom-loading__loading-item-bubble"></div></div></div></div></div>'
    };
    return data;
  }
  _build() {
    this.anylineObj = anylinejs.init(this._setData());
    this.anylineObj.onLoad = this.listeners._load;
    this.anylineObj.onResult = this.listeners._result;
    this.anylineObj.onError = this.listeners._error;
    this.anylineObj.startScanning().catch((data) => { });
  }
  destroy() {
    if (this.anylineObj && this.anylineObj.state === "scanning") {
      this.anylineObj.stopScanning();
    }
  }
}