class customRadioGroupItem {
  constructor(id, options) {
    this.class = 'custom-radio-group-item';
    this.element = document.getElementById(id);
    this.elements = {
      radioGroup: this.element.closest('.custom-radio-group'),
      radio: {
        element: this.element.firstElementChild,
        input: document.createElement('input')
      }
    };
    this.stateClasses = {
      previousSeparator: this.class.concat('--previous-separated')
    }
    this.options = options;
    this.listeners = {
      _change: this._change.bind(this)
    };
    this._build();
  }
  _setProps() {
    if (this.elements.radio.input) {
      this.options.testId ? this.elements.radio.input.setAttribute('data-testid', this.options.testId) : this.elements.radio.input.removeAttribute('data-testid');
    }
  }
  _change() {
    if (this.elements.radio.input.checked) {
      this.elements.radioGroup.customRadioGroup.events.change(this.options.value);
    }
  }
  _create() {
    let id = this.element.id.concat('-radio-button');
    this.elements.radio.input.setAttribute('type', 'radio');
    this.elements.radio.input.setAttribute('value', this.options.value);
    this.elements.radio.input.setAttribute('id', id);
    this.elements.radio.element.append(this.elements.radio.input);
    this.elements.radio.input.addEventListener('change', this.listeners._change);
  }
  _build() {
    this._create();
    this._setProps();
  }
  render() {
    this.elements.radio.input.setAttribute('name', this.elements.radioGroup.id);
    if (this.options.separated) {
      let previous = this.element.parentElement.previousSibling;
      if (previous && previous.firstElementChild) {
        previous.firstElementChild.classList.add(this.stateClasses.previousSeparator);
      }
    }
  }
  parametersChanged(options) {
    this.options = options;
    this.elements.radio.input.setAttribute('value', this.options.value);
    this._setProps();
  }
}