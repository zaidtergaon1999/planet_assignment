define("ShopperPortalEU.Common.controller", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.controller", "ShopperPortalEU.clientVariables", "ShopperPortalEU.Common.controller$debugger", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger"], function (exports, OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ThemeController, ShopperPortalEUClientVariables, ShopperPortalEU_Common_Controller_debugger) {
var OS = OutSystems.Internal;
var ShopperPortalEU_CommonController = exports;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
}
Controller.prototype.getDefaultTimeout = function () {
return ShopperPortalEUController.default.defaultTimeout;
};
Controller.prototype.handleError = function (ex, callContext) {
var varBag = {};
var controller = this.controller;
var allExceptionsVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.ErrorHandlerOutputType());
var securityExceptionVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.ErrorHandlerOutputType());
var communicationExceptionVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.ErrorHandlerOutputType());
var notAuthenticatedVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.ErrorHandlerOutputType());
var maintenanceVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.ErrorHandlerOutputType());
varBag.allExceptionsVar = allExceptionsVar;
varBag.securityExceptionVar = securityExceptionVar;
varBag.communicationExceptionVar = communicationExceptionVar;
varBag.notAuthenticatedVar = notAuthenticatedVar;
varBag.maintenanceVar = maintenanceVar;
OS.Logger.trace("Common.OnException", OS.Exceptions.getMessage(ex), ex.name);
if(OS.ErrorHandling.ignoreError(ex, callContext)) {
return OS.ErrorHandling.IGNORED_ERROR_RESULT;
}

try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:B4kRGvrnOEmQonA8ir4Pyg.#FlowExceptionHandler:/NRWebFlows.B4kRGvrnOEmQonA8ir4Pyg/FlowExceptionHandler:Hle_WzOtnJnq3dcVGSg16g", "ShopperPortalEU", "OnException", "NRFlows.FlowExceptionHandlingFlow", callContext.id, varBag);
OS.Logger.trace("Common.OnException", OS.Exceptions.getMessage(ex), ex.name);
// Handle Error: SecurityException
if(OS.Exceptions.isInstanceOf(ex, OS.Exceptions.Exceptions.SecurityException)) {
securityExceptionVar.value.exceptionMessageAttr = OS.Exceptions.getMessage(ex);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:EKsoYfUET0SHcIwe_9lUPA", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:jfzf_bzlMUebqIP1PBZh_w", callContext.id) && ((OS.BuiltinFunctions.getUserId()) !== (OS.BuiltinFunctions.nullIdentifier())))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:VY_pZrphX0CJP63e_M4JHQ", callContext.id);
// Destination: /ShopperPortalEU/Error
return OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "Error", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true);
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:+JwCP4TqBkKlREF5Y_hpug", callContext.id);
// Destination: /ShopperPortalEU/VerifyIdentity
return OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "VerifyIdentity", {
LT: OS.DataConversion.ServerDataConverter.asString((((OS.BuiltinFunctions.substr(OS.BuiltinFunctions.getBookmarkableURL(), (OS.BuiltinFunctions.length(OS.BuiltinFunctions.getBookmarkableURL()) - 1), 1) === "1")) ? (1) : ((((OS.BuiltinFunctions.substr(OS.BuiltinFunctions.getBookmarkableURL(), (OS.BuiltinFunctions.length(OS.BuiltinFunctions.getBookmarkableURL()) - 1), 1) === "2")) ? (2) : (OS.BuiltinFunctions.nullIdentifier())))), OS.DataTypes.DataTypes.Integer)
}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true);
}

}

// Handle Error: CommunicationException
if(OS.Exceptions.isInstanceOf(ex, OS.Exceptions.Exceptions.CommunicationException)) {
OS.Logger.error(null, ex);
communicationExceptionVar.value.exceptionMessageAttr = OS.Exceptions.getMessage(ex);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:UEw6n9qWe06ZuSWntFQS4w", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:os0fT4IwoEWfatrybSq_ug", callContext.id);
// Execute Action: CommunicationsMessage
ShopperPortalEU_UI_ThemeController.default.customMessageTrigger$Action(function () {
var rec = new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customMessageType.error;
rec.titleAttr = communicationExceptionVar.value.exceptionMessageAttr;
rec.testIdAttr = "App_CommunicationExceptionMessage";
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:4qeSJUNPsU2eKIm6gj0sdw", callContext.id);
return ;

}

// Handle Error: NotAuthenticated
if(OS.Exceptions.isInstanceOf(ex, OS.Exceptions.Exceptions.UserException, "ShopperPortalEU.NotAuthenticated")) {
OS.Logger.error(null, ex);
notAuthenticatedVar.value.exceptionMessageAttr = OS.Exceptions.getMessage(ex);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:beqcrMEOfkW+7IhLuKbosw", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:6SJmE7eKg0Kc_9czEeM1RQ", callContext.id);
// ErrorMessage = "Sorry, you don't have permissions to see this page."
ShopperPortalEUClientVariables.setErrorMessage("Sorry, you don\'t have permissions to see this page.");
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:scX6I0ArdUiF3l9G5D7V+A", callContext.id);
// Destination: /ShopperPortalEU/Error
return OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "Error", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true);
}

// Handle Error: Maintenance
if(OS.Exceptions.isInstanceOf(ex, OS.Exceptions.Exceptions.UserException, "ShopperPortalEU.Maintenance")) {
OS.Logger.error(null, ex);
maintenanceVar.value.exceptionMessageAttr = OS.Exceptions.getMessage(ex);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:AqSs30GvK0CnS8pZE5zZYA", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:mWxCRcFIDkeAEb1pnU5pvg", callContext.id);
// Destination: /ShopperPortalEU/Maintenance
return OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "Maintenance", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true);
}

// Handle Error: AllExceptions
if(!(OS.Exceptions.isSystem(ex))) {
OS.Logger.error(null, ex);
allExceptionsVar.value.exceptionMessageAttr = OS.Exceptions.getMessage(ex);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:YJDpIiqj+kystnvSyst84Q", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:6syJqQDSpkSnXnVwMUwJ8A", callContext.id);
// Execute Action: AllExceptionsMessage
ShopperPortalEU_UI_ThemeController.default.customMessageTrigger$Action(function () {
var rec = new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customMessageType.error;
rec.titleAttr = allExceptionsVar.value.exceptionMessageAttr;
rec.testIdAttr = "App_AllExceptionsMessage";
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:lR4WVBAPvki5mxBvHbkoEg", callContext.id);
return ;

}

throw ex;
} catch (unhandledEx) {
OS.Logger.trace("Common.OnException", OS.Exceptions.getMessage(ex), ex.name);
if(!(OS.ErrorHandling.ignoreError(unhandledEx, callContext))) {
OS.ErrorHandling.handleError(unhandledEx, callContext);
OutSystemsDebugger.handleException(unhandledEx, callContext.id);
return OS.ErrorHandling.UNHANDLED_ERROR_RESULT;

}

OutSystemsDebugger.handleException(unhandledEx, callContext.id);
return OS.ErrorHandling.IGNORED_ERROR_RESULT;

} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:B4kRGvrnOEmQonA8ir4Pyg.#FlowExceptionHandler", callContext.id);
}



};
return Controller;
})(OS.Controller.BaseController);
ShopperPortalEU_CommonController.default = new Controller();
});

define("ShopperPortalEU.Common.controller$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"YJDpIiqj+kystnvSyst84Q": {
getter: function (varBag, idService) {
return varBag.allExceptionsVar.value;
}
},
"EKsoYfUET0SHcIwe_9lUPA": {
getter: function (varBag, idService) {
return varBag.securityExceptionVar.value;
}
},
"UEw6n9qWe06ZuSWntFQS4w": {
getter: function (varBag, idService) {
return varBag.communicationExceptionVar.value;
}
},
"beqcrMEOfkW+7IhLuKbosw": {
getter: function (varBag, idService) {
return varBag.notAuthenticatedVar.value;
}
},
"AqSs30GvK0CnS8pZE5zZYA": {
getter: function (varBag, idService) {
return varBag.maintenanceVar.value;
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
