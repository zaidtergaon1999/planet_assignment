define("ShopperPortalEU.Layouts.Layout.mvc$model", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.controller", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Theme.ShopperPortalEUUIThemeLayouts.Layout.mvc$model", "ShopperPortalEU_DataSync.Sync.DataSyncCore.mvc$model", "ShopperPortalEU_UI_Theme.model$LayoutOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU_UI_Theme.model$LayoutHeaderOptionsRec", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", "ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger", "ShopperPortalEU.controller$LayoutCheckAuthentication", "ShopperPortalEU.controller$CheckRedirectShopper", "ShopperPortalEU.controller$GenericErrorMessage"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ThemeController, ShopperPortalEUController, ShopperPortalEU_UI_Theme_ShopperPortalEUUIThemeLayouts_Layout_mvcModel, ShopperPortalEU_DataSync_Sync_DataSyncCore_mvcModel) {
var OS = OutSystems.Internal;

var GetWebAuthSitePropertiesDataActRec = (function (_super) {
__extends(GetWebAuthSitePropertiesDataActRec, _super);
function GetWebAuthSitePropertiesDataActRec(defaults) {
_super.apply(this, arguments);
}
GetWebAuthSitePropertiesDataActRec.attributesToDeclare = function () {
return [
this.attr("Domain", "domainOut", "Domain", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("ClientId", "clientIdOut", "ClientId", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("RedirectURL", "redirectURLOut", "RedirectURL", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
GetWebAuthSitePropertiesDataActRec.init();
return GetWebAuthSitePropertiesDataActRec;
})(OS.Model.DataSourceRecord);

var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("Options", "optionsIn", "Options", true, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ThemeModel.LayoutOptionsRec());
}, false, ShopperPortalEU_UI_ThemeModel.LayoutOptionsRec), 
this.attr("_optionsInDataFetchStatus", "_optionsInDataFetchStatus", "_optionsInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("Auth", "authIn", "Auth", true, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEUModel.LayoutAuthenticationRec());
}, false, ShopperPortalEUModel.LayoutAuthenticationRec), 
this.attr("_authInDataFetchStatus", "_authInDataFetchStatus", "_authInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("GetWebAuthSiteProperties", "getWebAuthSitePropertiesDataAct", "getWebAuthSitePropertiesDataAct", true, true, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new GetWebAuthSitePropertiesDataActRec());
}, true, GetWebAuthSitePropertiesDataActRec)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Model._hasValidationWidgetsValue = undefined;
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
if((Model._hasValidationWidgetsValue === undefined)) {
Model._hasValidationWidgetsValue = (ShopperPortalEU_UI_Theme_ShopperPortalEUUIThemeLayouts_Layout_mvcModel.hasValidationWidgets || ShopperPortalEU_DataSync_Sync_DataSyncCore_mvcModel.hasValidationWidgets);
}

return Model._hasValidationWidgetsValue;
}
});

Model.prototype.setInputs = function (inputs) {
if("Options" in inputs) {
this.variables.optionsIn = inputs.Options;
if("_optionsInDataFetchStatus" in inputs) {
this.variables._optionsInDataFetchStatus = inputs._optionsInDataFetchStatus;
}

}

if("Auth" in inputs) {
this.variables.authIn = inputs.Auth;
if("_authInDataFetchStatus" in inputs) {
this.variables._authInDataFetchStatus = inputs._authInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "Layouts.Layout");
});
define("ShopperPortalEU.Layouts.Layout.mvc$view", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.controller", "react", "OutSystems/ReactView/Main", "ShopperPortalEU.Layouts.Layout.mvc$model", "ShopperPortalEU.Layouts.Layout.mvc$controller", "ShopperPortalEU.clientVariables", "ShopperPortalEU_UI_Theme.ShopperPortalEUUIThemeLayouts.Layout.mvc$view", "OutSystems/ReactWidgets/Main", "ShopperPortalEU_DataSync.Sync.DataSyncCore.mvc$view", "ShopperPortalEU_UI_Theme.model$LayoutOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU_UI_Theme.model$LayoutHeaderOptionsRec", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", "ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger", "ShopperPortalEU.controller$LayoutCheckAuthentication", "ShopperPortalEU.controller$CheckRedirectShopper", "ShopperPortalEU.controller$GenericErrorMessage"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ThemeController, React, OSView, ShopperPortalEU_Layouts_Layout_mvc_model, ShopperPortalEU_Layouts_Layout_mvc_controller, ShopperPortalEUClientVariables, ShopperPortalEU_UI_Theme_ShopperPortalEUUIThemeLayouts_Layout_mvc_view, OSWidgets, ShopperPortalEU_DataSync_Sync_DataSyncCore_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            var thisIsInstanceOfSuper = this instanceof _super;
            if (thisIsInstanceOfSuper == false) {
                return;
            }

            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "Layouts.Layout";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [ShopperPortalEU_UI_Theme_ShopperPortalEUUIThemeLayouts_Layout_mvc_view, ShopperPortalEU_DataSync_Sync_DataSyncCore_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return ShopperPortalEU_Layouts_Layout_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return ShopperPortalEU_Layouts_Layout_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(ShopperPortalEU_UI_Theme_ShopperPortalEUUIThemeLayouts_Layout_mvc_view, {
inputs: {
Options: model.variables.optionsIn,
_optionsInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._optionsInDataFetchStatus)
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onOrientationChange$Action: function (currentOrientationIn) {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ShopperPortalEUUIThemeLayouts/Layout OnOrientationChange");
controller.onOrientationChange$Action(currentOrientationIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "0",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
headerLeft: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Placeholder, {
align: /*Default*/ 0,
content: _this.props.placeholders.headerLeft,
style: "ph",
_idProps: {
service: idService,
name: "HeaderLeft"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
headerCenter: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Placeholder, {
align: /*Default*/ 0,
content: _this.props.placeholders.headerCenter,
style: "ph",
_idProps: {
service: idService,
name: "HeaderCenter"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
headerRight: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Placeholder, {
align: /*Default*/ 0,
content: _this.props.placeholders.headerRight,
style: "ph",
_idProps: {
service: idService,
name: "HeaderRight"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
headerBottom: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Placeholder, {
align: /*Default*/ 0,
content: _this.props.placeholders.headerBottom,
style: "ph",
_idProps: {
service: idService,
name: "HeaderBottom"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Placeholder, {
align: /*Default*/ 0,
content: _this.props.placeholders.content,
style: "ph",
_idProps: {
service: idService,
name: "Content"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
bottom: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Placeholder, {
align: /*Default*/ 0,
content: _this.props.placeholders.bottom,
style: "ph",
_idProps: {
service: idService,
name: "Bottom"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
}
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "hide-on-service-studio",
visible: true,
_idProps: {
service: idService,
name: "Sync"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_DataSync_Sync_DataSyncCore_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "8",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("ShopperPortalEU.Layouts.Layout.mvc$controller", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Theme.controller", "ShopperPortalEU.languageResources", "ShopperPortalEU.clientVariables", "ShopperPortalEU.Layouts.Layout.mvc$debugger", "ShopperPortalEU_UI_Theme.model$LayoutOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU_UI_Theme.model$LayoutHeaderOptionsRec", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", "ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger", "ShopperPortalEU.controller$LayoutCheckAuthentication", "ShopperPortalEU.controller$CheckRedirectShopper", "ShopperPortalEU.controller$GenericErrorMessage"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ThemeController, ShopperPortalEULanguageResources, ShopperPortalEUClientVariables, ShopperPortalEU_Layouts_Layout_mvc_Debugger) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {
getWebAuthSiteProperties$DataActRefresh: 0
};
this.dataFetchDependentsGraph = {
getWebAuthSiteProperties$DataActRefresh: []
};
this.shouldSendClientVarsToDataSources = true;
}
// Server Actions

// Aggregates and Data Actions
Controller.prototype.getWebAuthSiteProperties$DataActRefresh = function (callContext) {
var model = this.model;
var controller = this.controller;
var callContext = controller.callContext(callContext);
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:ZquXnGBfukedwE2ESlF4zg:/NRWebFlows.9dW_P1aGJE6tp_XCzsZj4Q/NodesShownInESpaceTree.mcbBxbrn0kuJl15MIzJlhQ/DataActions.ZquXnGBfukedwE2ESlF4zg:uYPj7ZC7r4NmytnT1ip_JA", "ShopperPortalEU", "GetWebAuthSiteProperties", "NRFlows.DataScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.setThreadStartName(callContext.id, "Layouts/Layout/GetWebAuthSiteProperties");
return controller.callDataAction("DataActionGetWebAuthSiteProperties", "screenservices/ShopperPortalEU/Layouts/Layout/DataActionGetWebAuthSiteProperties", "f21k_TZBWF5uqE6tQ+6e2A", function (b) {
model.variables.getWebAuthSitePropertiesDataAct.dataFetchStatusAttr = b;
}, function (json) {
model.variables.getWebAuthSitePropertiesDataAct.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getWebAuthSitePropertiesDataAct.constructor));
}, undefined, OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, callContext, ShopperPortalEUClientVariables, false).then(function () {
OutSystemsDebugger.setThreadStartName(callContext.id, "Layouts/Layout/GetWebAuthSiteProperties On After Fetch");
return controller._getWebAuthSitePropertiesOnAfterFetch$Action(controller.callContext(callContext));

});

}, function () {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:ZquXnGBfukedwE2ESlF4zg", callContext.id);
controller.popDebuggerContext(callContext);

});
};

Controller.prototype.dataFetchActionNames = ["getWebAuthSiteProperties$DataActRefresh"];
// Client Actions
Controller.prototype._onInitialize$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnInitialize");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:yrLrf3S7u06ll2g1ISOY8w:/NRWebFlows.9dW_P1aGJE6tp_XCzsZj4Q/NodesShownInESpaceTree.mcbBxbrn0kuJl15MIzJlhQ/ClientActions.yrLrf3S7u06ll2g1ISOY8w:SJ2xK22jv+41F6kqCwb6Pg", "ShopperPortalEU", "OnInitialize", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:nUUOTeN_QUW3b6eqrAJhAw", callContext.id);
// In maintenance
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:QuLtAWsGVk6Z6j8en7v9Vw", callContext.id) && (ShopperPortalEUClientVariables.getIsInMaintenance() && !(model.variables.authIn.notCheckMaintenanceAttr)))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:+7FVEE41ZkavIeF96bO14Q", callContext.id);
// Raise Error: Maintenance
throw new OS.Exceptions.Exceptions.UserException("ShopperPortalEU.Maintenance", "Application in maintenance");
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:LNkLliE1x0yTwUnTxCc4wg", callContext.id);
}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:yrLrf3S7u06ll2g1ISOY8w", callContext.id);
}

};
Controller.prototype._getWebAuthSitePropertiesOnAfterFetch$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("GetWebAuthSitePropertiesOnAfterFetch");
callContext = controller.callContext(callContext);
var allExceptionsVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.ErrorHandlerOutputType());
var layoutCheckAuthenticationVar = new OS.DataTypes.VariableHolder();
var checkRedirectShopperVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.allExceptionsVar = allExceptionsVar;
varBag.layoutCheckAuthenticationVar = layoutCheckAuthenticationVar;
varBag.checkRedirectShopperVar = checkRedirectShopperVar;
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:kO+0nIqfykyaCnetQSY6YQ:/NRWebFlows.9dW_P1aGJE6tp_XCzsZj4Q/NodesShownInESpaceTree.mcbBxbrn0kuJl15MIzJlhQ/ClientActions.kO+0nIqfykyaCnetQSY6YQ:LrIbswdKfFGi1464YiqMkA", "ShopperPortalEU", "GetWebAuthSitePropertiesOnAfterFetch", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:pV3bswvjZUOaANrME81nAw", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:giHc2Wh6WkOwNLKRUT_4Aw", callContext.id);
// Execute Action: LayoutCheckAuthentication
model.flush();
return ShopperPortalEUController.default.layoutCheckAuthentication$Action(model.variables.authIn, model.variables.getWebAuthSitePropertiesDataAct.domainOut, model.variables.getWebAuthSitePropertiesDataAct.clientIdOut, model.variables.getWebAuthSitePropertiesDataAct.redirectURLOut, callContext).then(function (value) {
layoutCheckAuthenticationVar.value = value;
}).then(function () {
// Check shopper
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:8Gr5GO3rvEeOMSybGPifSg", callContext.id) && ((!(ShopperPortalEUClientVariables.getShopperChecked()) && model.variables.authIn.isToUseAuthAttr) && !(model.variables.authIn.notAutomaticallyRedirectAttr)))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:j3S5+Q0Dyk+8GLT8xRyeBA", callContext.id);
// Execute Action: CheckRedirectShopper
model.flush();
return ShopperPortalEUController.default.checkRedirectShopper$Action(callContext).then(function (value) {
checkRedirectShopperVar.value = value;
}).then(function () {
// Success
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:NyJch5D8Ekqrd64pVCfw9A", callContext.id) && !(checkRedirectShopperVar.value.hasErrorOut))) {
// Redirect
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:z9LZnJiumUaFHK_vcbkJjQ", callContext.id) && (checkRedirectShopperVar.value.redirectOut === 1))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:srW_lxjdi0WedMcB8DP5Bg", callContext.id);
// Destination: /ShopperPortalEU/TermsService
return OS.Flow.returnAsync(OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "TermsService", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true));
} else {
return OS.Flow.executeSequence(function () {
if((checkRedirectShopperVar.value.redirectOut === 2)) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:XGqFOXU73UGvokRIfj_eMA", callContext.id);
// Destination: /ShopperPortalEU/PassportDetails
return OS.Flow.returnAsync(OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "PassportDetails", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true));
} else {
return OS.Flow.executeSequence(function () {
if((checkRedirectShopperVar.value.redirectOut === 3)) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Krc4fGGZSEWnyr7fV99S3w", callContext.id);
// Destination: /ShopperPortalEU/ConfirmPassport
return OS.Flow.returnAsync(OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "ConfirmPassport", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true));
} else {
return OS.Flow.executeSequence(function () {
if((checkRedirectShopperVar.value.redirectOut === 4)) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:iV4ROtv4TU+AKnXGNODlcw", callContext.id);
// Destination: /ShopperPortalEU/CompleteDetails
return OS.Flow.returnAsync(OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "CompleteDetails", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true));
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:mfzGKbaUwEeCg7GuCU2y7A", callContext.id);
// Trigger Event: Authentication2
return controller.afterAuthentication$Action(layoutCheckAuthenticationVar.value.isAuthenticatedOut, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:EMD+JcYoWE2FIbj0jS63Zg", callContext.id);
});
}

});
}

});
}

});
}

});
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:TJ5Ih6kQwEuuTutlU5mlXg", callContext.id);
// Destination: /ShopperPortalEU/Error
return OS.Flow.returnAsync(OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "Error", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true));
}

});
});
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:1IxVnPaaR0yK91a5Bp6uQg", callContext.id);
// Trigger Event: Authentication
return controller.afterAuthentication$Action(layoutCheckAuthenticationVar.value.isAuthenticatedOut, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:x9veDGnTmEWFRLQNDng8Bw", callContext.id);
});
}

});
});
}).catch(function (ex) {
OS.Logger.trace("Layout.GetWebAuthSitePropertiesOnAfterFetch", OS.Exceptions.getMessage(ex), ex.name);
// Handle Error: AllExceptions
if(!(OS.Exceptions.isSystem(ex))) {
OS.Logger.error(null, ex);
allExceptionsVar.value.exceptionMessageAttr = OS.Exceptions.getMessage(ex);
OutSystemsDebugger.handleException(allExceptionsVar.value.exceptionMessageAttr, callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:dq39w9_rjUauFviYqDHXyQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:O9N_xLvuoE2gVJhaB7LE6A", callContext.id);
// Execute Action: AllExceptionsMessage
ShopperPortalEU_UI_ThemeController.default.customMessageTrigger$Action(function () {
var rec = new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customMessageType.error;
rec.titleAttr = "Sorry, we are experiencing technical difficulties";
rec.contentAttr = OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.genericErrorMessage$Action(callContext).errorMessageOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:NBUjOYEzpkmKSy_nw9xyrw", callContext.id);
return OS.Flow.returnAsync();

});
}

throw ex;
}).then(function (res) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:kO+0nIqfykyaCnetQSY6YQ", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:kO+0nIqfykyaCnetQSY6YQ", callContext.id);
throw ex;

});
};

Controller.prototype.onInitialize$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onInitialize$Action, callContext);

};
Controller.prototype.getWebAuthSitePropertiesOnAfterFetch$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._getWebAuthSitePropertiesOnAfterFetch$Action, callContext);

};
Controller.prototype.afterAuthentication$Action = function () {
return Promise.resolve();
};
Controller.prototype.onOrientationChange$Action = function () {
return Promise.resolve();
};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:9dW_P1aGJE6tp_XCzsZj4Q:/NRWebFlows.9dW_P1aGJE6tp_XCzsZj4Q:nNMjO4GL+VwElV3Ipnmv5w", "ShopperPortalEU", "Layouts", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:mcbBxbrn0kuJl15MIzJlhQ:/NRWebFlows.9dW_P1aGJE6tp_XCzsZj4Q/NodesShownInESpaceTree.mcbBxbrn0kuJl15MIzJlhQ:cbb630gvATwvel2T2A0aEQ", "ShopperPortalEU", "Layout", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:mcbBxbrn0kuJl15MIzJlhQ", callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:9dW_P1aGJE6tp_XCzsZj4Q", callContext.id);
};
Controller.prototype.onInitializeEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Layouts/Layout On Initialize");
return controller.onInitialize$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return ShopperPortalEUController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, ShopperPortalEULanguageResources);
});

define("ShopperPortalEU.Layouts.Layout.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"dq39w9_rjUauFviYqDHXyQ": {
getter: function (varBag, idService) {
return varBag.allExceptionsVar.value;
}
},
"giHc2Wh6WkOwNLKRUT_4Aw": {
getter: function (varBag, idService) {
return varBag.layoutCheckAuthenticationVar.value;
}
},
"j3S5+Q0Dyk+8GLT8xRyeBA": {
getter: function (varBag, idService) {
return varBag.checkRedirectShopperVar.value;
}
},
"TobI1ul6AUW5lBnQuFCkhA": {
getter: function (varBag, idService) {
return varBag.model.variables.optionsIn;
}
},
"xoELG51DEkOFg6SnWjhBfQ": {
getter: function (varBag, idService) {
return varBag.model.variables.authIn;
}
},
"ZquXnGBfukedwE2ESlF4zg": {
getter: function (varBag, idService) {
return varBag.model.variables.getWebAuthSitePropertiesDataAct;
}
},
"hduIq+kmI0iAtUOfbnOISA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderLeft"));
})(varBag.model, idService);
}
},
"znjtcdRfwkuRpZaJfdcVqA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderLeft"));
})(varBag.model, idService);
}
},
"QIC41RZT8EqND++MvVygcQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderCenter"));
})(varBag.model, idService);
}
},
"2frUpH6nyE+gIz9yGIREEg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderCenter"));
})(varBag.model, idService);
}
},
"ZUSe5sgqX0m8BJmu4TOTFQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderRight"));
})(varBag.model, idService);
}
},
"vaheWsrzX0uHFVpCRUo1aA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderRight"));
})(varBag.model, idService);
}
},
"PbdesGOMDU2hHOGXwQik7g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderBottom"));
})(varBag.model, idService);
}
},
"f6xFz6j2dUuDysR9vXfQ7w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderBottom"));
})(varBag.model, idService);
}
},
"wqNcnx2qYUuefUqPqU8dBA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"9PmvGEihG0qfMralpXyCdw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"mBY1WtlpPUaffAaBaPlInw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Bottom"));
})(varBag.model, idService);
}
},
"jZ00KZ1PzUC1TxY+Mv6ccw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Bottom"));
})(varBag.model, idService);
}
},
"WlN5jyfg80KUdNz5feYueA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Sync"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
