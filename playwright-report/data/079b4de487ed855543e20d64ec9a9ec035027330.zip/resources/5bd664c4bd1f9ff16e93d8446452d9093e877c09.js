define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.PhoneNumberInput.mvc$model", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$PhoneNumberInputCountryOptionsList", "ShopperPortalEU_UI_Components.model$PhoneNumberInputChangeOptionsRec", "ShopperPortalEU_UI_Components.model$PhoneNumberInputOptionsRec", "ShopperPortalEU_UI_Components.model$CustomFlagOptionsRec", "ShopperPortalEU_UI_Components.model$CustomIconOptionsRec"], function (OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("Obj", "objVar", "Obj", true, false, OS.DataTypes.DataTypes.Object, function () {
return null;
}, false), 
this.attr("Countries", "countriesVar", "Countries", true, false, OS.DataTypes.DataTypes.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputCountryOptionsList());
}, false, ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputCountryOptionsList), 
this.attr("PhoneNumber", "phoneNumberVar", "PhoneNumber", true, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputChangeOptionsRec());
}, false, ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputChangeOptionsRec), 
this.attr("SearchVar", "searchVarVar", "SearchVar", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, false), 
this.attr("IsVisible", "isVisibleVar", "IsVisible", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("Options", "optionsIn", "Options", true, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputOptionsRec());
}, false, ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputOptionsRec), 
this.attr("_optionsInDataFetchStatus", "_optionsInDataFetchStatus", "_optionsInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("ExtendedClass", "extendedClassIn", "ExtendedClass", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, false), 
this.attr("_extendedClassInDataFetchStatus", "_extendedClassInDataFetchStatus", "_extendedClassInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {
Input_MobileNumber: OS.Model.ValidationWidgetRecord,
Input_Search: OS.Model.ValidationWidgetRecord
};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return true;
}
});

Model.prototype.setInputs = function (inputs) {
if("Options" in inputs) {
this.variables.optionsIn = inputs.Options;
if("_optionsInDataFetchStatus" in inputs) {
this.variables._optionsInDataFetchStatus = inputs._optionsInDataFetchStatus;
}

}

if("ExtendedClass" in inputs) {
this.variables.extendedClassIn = inputs.ExtendedClass;
if("_extendedClassInDataFetchStatus" in inputs) {
this.variables._extendedClassInDataFetchStatus = inputs._extendedClassInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "ShopperPortalEUUIComponents.PhoneNumberInput");
});
define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.PhoneNumberInput.mvc$view", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.controller", "react", "OutSystems/ReactView/Main", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.PhoneNumberInput.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.PhoneNumberInput.mvc$controller", "OutSystems/ReactWidgets/Main", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomFlag.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomIcon.mvc$view", "ShopperPortalEU_UI_Components.model$PhoneNumberInputCountryOptionsList", "ShopperPortalEU_UI_Components.model$PhoneNumberInputChangeOptionsRec", "ShopperPortalEU_UI_Components.model$PhoneNumberInputOptionsRec", "ShopperPortalEU_UI_Components.model$CustomFlagOptionsRec", "ShopperPortalEU_UI_Components.model$CustomIconOptionsRec"], function (OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ComponentsController, React, OSView, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_PhoneNumberInput_mvc_model, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_PhoneNumberInput_mvc_controller, OSWidgets, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomFlag_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomIcon_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            var thisIsInstanceOfSuper = this instanceof _super;
            if (thisIsInstanceOfSuper == false) {
                return;
            }

            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "ShopperPortalEUUIComponents.PhoneNumberInput";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css"];
        };
        View.getJsDependencies = function() {
            return ["scripts/ShopperPortalEU_UI_Components.libphonenumbermobile.js", "scripts/ShopperPortalEU_UI_Components.phoneNumberInput.js"];
        };
        View.getBlocks = function() {
            return [ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomFlag_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomIcon_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_PhoneNumberInput_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_PhoneNumberInput_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: model.getCachedValue(idService.getId("Element.Style"), function () {
return (((("phone-number-input" + ((!(model.variables.optionsIn.isDisabledAttr)) ? ("") : (" phone-number-input--disabled"))) + ((!(model.variables.optionsIn.isReadOnlyAttr)) ? ("") : (" phone-number-input--read-only"))) + (((model.variables.optionsIn.validationAttr.stateAttr === OS.BuiltinFunctions.nullTextIdentifier())) ? ("") : ((" phone-number-input--" + model.variables.optionsIn.validationAttr.stateAttr)))) + (((model.variables.extendedClassIn === "")) ? ("") : ((" " + model.variables.extendedClassIn))));
}, function () {
return model.variables.optionsIn.isDisabledAttr;
}, function () {
return model.variables.optionsIn.isReadOnlyAttr;
}, function () {
return model.variables.optionsIn.validationAttr.stateAttr;
}, function () {
return model.variables.extendedClassIn;
}),
visible: true,
_idProps: {
service: idService,
name: "Element"
},
_widgetRecordProvider: widgetsRecordProvider,
style_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._optionsInDataFetchStatus, model.variables._extendedClassInDataFetchStatus)
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "phone-number-input__label ph",
visible: true,
_idProps: {
service: idService,
uuid: "1"
},
_widgetRecordProvider: widgetsRecordProvider
}, $if(((model.variables.optionsIn.labelAttr) !== ("")), false, this, function () {
return [React.createElement(OSWidgets.Label, {
extendedProperties: {
"data-testid": model.getCachedValue(idService.getId("CtOuSeloG0qy+t2+Lfwmcg.data-testid"), function () {
return ((((model.variables.optionsIn.testIdAttr) !== (""))) ? ((model.variables.optionsIn.testIdAttr + "Label")) : (""));
}, function () {
return model.variables.optionsIn.testIdAttr;
})
},
gridProperties: {
classes: "OSFillParent"
},
mandatory: model.variables.optionsIn.isMandatoryAttr,
targetWidget: "Input_MobileNumber",
_idProps: {
service: idService,
uuid: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
mandatory_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._optionsInDataFetchStatus)
}, React.createElement(OSWidgets.Expression, {
value: model.variables.optionsIn.labelAttr,
_idProps: {
service: idService,
uuid: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._optionsInDataFetchStatus)
}))];
}, function () {
return [];
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "phone-number-input__input-wrapper",
visible: true,
_idProps: {
service: idService,
uuid: "4"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: false,
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ShopperPortalEUUIComponents/PhoneNumberInput/Button OnClick");
controller.toggle$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "phone-number-input__flag",
visible: true,
_idProps: {
service: idService,
uuid: "5"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomFlag_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("HefTSWFa00SgtvEu1NpXUA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomFlagOptionsRec();
rec.flagAttr = model.variables.phoneNumberVar.countryAttr.codeAttr;
return rec;
}();
}, function () {
return model.variables.phoneNumberVar.countryAttr.codeAttr;
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "6",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})), React.createElement(OSWidgets.Input, {
_validationProps: {
validationService: validationService
},
enabled: !(model.variables.optionsIn.isDisabledAttr),
extendedProperties: {
"data-testid": model.getCachedValue(idService.getId("Input_MobileNumber.data-testid"), function () {
return ((((model.variables.optionsIn.testIdAttr) !== (""))) ? ((model.variables.optionsIn.testIdAttr + "Input")) : (""));
}, function () {
return model.variables.optionsIn.testIdAttr;
})
},
gridProperties: {
classes: "OSFillParent"
},
inputType: /*Phone*/ 6,
mandatory: model.variables.optionsIn.isMandatoryAttr,
maxLength: 0,
prompt: "+353 999 999 999",
style: "form-control",
variable: model.createVariable(OS.DataTypes.DataTypes.PhoneNumber, model.variables.phoneNumberVar.formattedPhoneNumberAttr, function (value) {
model.variables.phoneNumberVar.formattedPhoneNumberAttr = value;
}),
_idProps: {
service: idService,
name: "Input_MobileNumber"
},
_widgetRecordProvider: widgetsRecordProvider,
enabled_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._optionsInDataFetchStatus),
mandatory_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._optionsInDataFetchStatus)
}), $if((model.variables.optionsIn.validationAttr.messageAttr === ""), false, this, function () {
return [];
}, function () {
return [React.createElement(OSWidgets.Expression, {
style: "validation-message",
value: model.variables.optionsIn.validationAttr.messageAttr,
_idProps: {
service: idService,
uuid: "8"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._optionsInDataFetchStatus)
})];
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "phone-number-input__dropdown",
visible: model.variables.isVisibleVar,
_idProps: {
service: idService,
uuid: "9"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "phone-number-input__dropdown-header",
visible: true,
_idProps: {
service: idService,
uuid: "10"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "phone-number-input__dropdown-header-title",
visible: true,
_idProps: {
service: idService,
uuid: "11"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": model.getCachedValue(idService.getId("SE6hvc9LPEuit9R9GaiHOQ.data-testid"), function () {
return ((((model.variables.optionsIn.testIdAttr) !== (""))) ? ((model.variables.optionsIn.testIdAttr + "OpenedLabel")) : (""));
}, function () {
return model.variables.optionsIn.testIdAttr;
})
},
value: model.variables.optionsIn.dropdownLabelAttr,
_idProps: {
service: idService,
uuid: "12"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._optionsInDataFetchStatus)
})), React.createElement(OSWidgets.Button, {
enabled: true,
extendedProperties: {
"data-testid": model.getCachedValue(idService.getId("TzkuC+wrCUuAHDjoYJL5DA.data-testid"), function () {
return ((((model.variables.optionsIn.testIdAttr) !== (""))) ? ((model.variables.optionsIn.testIdAttr + "Close")) : (""));
}, function () {
return model.variables.optionsIn.testIdAttr;
})
},
isDefault: false,
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ShopperPortalEUUIComponents/PhoneNumberInput/Button OnClick");
controller.toggle$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "phone-number-input__dropdown-close",
visible: true,
_idProps: {
service: idService,
uuid: "13"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomIcon_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("J32INX5NYUeFEQTozpurJw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomIconOptionsRec();
rec.nameAttr = "close";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "14",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}))), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "phone-number-input__dropdown-search",
visible: true,
_idProps: {
service: idService,
uuid: "15"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Input, {
_validationProps: {
validationService: validationService
},
enabled: true,
extendedEvents: {
"componentDidMount": function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ShopperPortalEUUIComponents/PhoneNumberInput/Input_Search componentDidMount");
controller.dropdownRendered$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
extendedProperties: {
spellCheck: "false",
"data-testid": model.getCachedValue(idService.getId("Input_Search.data-testid"), function () {
return (((model.variables.optionsIn.testIdAttr === "")) ? ("") : ((model.variables.optionsIn.testIdAttr + "SearchInput")));
}, function () {
return model.variables.optionsIn.testIdAttr;
})
},
gridProperties: {
classes: "OSFillParent"
},
inputType: /*Search*/ 8,
mandatory: false,
maxLength: 50,
onChange: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ShopperPortalEUUIComponents/PhoneNumberInput/Input_Search OnChange");
controller.search$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
prompt: model.variables.optionsIn.searchAttr.placeholderAttr,
style: "form-control",
variable: model.createVariable(OS.DataTypes.DataTypes.Text, model.variables.searchVarVar, function (value) {
model.variables.searchVarVar = value;
}),
_idProps: {
service: idService,
name: "Input_Search"
},
_widgetRecordProvider: widgetsRecordProvider,
prompt_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._optionsInDataFetchStatus)
})), React.createElement(OSWidgets.List, {
animateItems: false,
extendedProperties: {
"disable-virtualization": "True"
},
gridProperties: {
classes: "OSFillParent"
},
mode: /*Custom*/ 1,
source: model.variables.countriesVar,
style: "phone-number-input__dropdown-list",
tag: "ul",
_idProps: {
service: idService,
uuid: "17"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new IteratorPlaceholderContent(function (idService, callContext) {
return [React.createElement(OSWidgets.AdvancedHtml, {
extendedProperties: {
className: "phone-number-input__dropdown-item",
"data-code": model.variables.countriesVar.getCurrent(callContext.iterationContext).codeAttr,
"data-dial-code": model.variables.countriesVar.getCurrent(callContext.iterationContext).dialCodeAttr,
"data-name": model.variables.countriesVar.getCurrent(callContext.iterationContext).nameAttr
},
tag: "li",
_idProps: {
service: idService,
uuid: "18"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.countriesVar.getCurrent(callContext.iterationContext).dialCodeAttr), asPrimitiveValue(model.variables.countriesVar.getCurrent(callContext.iterationContext).nameAttr), asPrimitiveValue(model.variables.countriesVar.getCurrent(callContext.iterationContext).codeAttr)]
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "phone-number-input__dropdown-item-flag",
visible: true,
_idProps: {
service: idService,
uuid: "19"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomFlag_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("Sh9dXut67EeepO8KBOI4cg.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomFlagOptionsRec();
rec.flagAttr = model.variables.countriesVar.getCurrent(callContext.iterationContext).codeAttr;
return rec;
}();
}, function () {
return model.variables.countriesVar.getCurrent(callContext.iterationContext).codeAttr;
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "20",
alias: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "phone-number-input__dropdown-item-name",
visible: true,
_idProps: {
service: idService,
uuid: "21"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
value: model.variables.countriesVar.getCurrent(callContext.iterationContext).nameAttr,
_idProps: {
service: idService,
uuid: "22"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "phone-number-input__dropdown-item-ext",
visible: true,
_idProps: {
service: idService,
uuid: "23"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
value: ("+" + model.variables.countriesVar.getCurrent(callContext.iterationContext).dialCodeAttr),
_idProps: {
service: idService,
uuid: "24"
},
_widgetRecordProvider: widgetsRecordProvider
})))];
}, callContext, idService, "1")
},
_dependencies: []
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "phone-number-input__dropdown-empty-message",
visible: true,
_idProps: {
service: idService,
uuid: "25"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "phone-number-input__dropdown-empty-message-title",
visible: true,
_idProps: {
service: idService,
uuid: "26"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": model.getCachedValue(idService.getId("f1fPJXmnnEGW95UunDlCSw.data-testid"), function () {
return (((model.variables.optionsIn.testIdAttr === "")) ? ("") : ((model.variables.optionsIn.testIdAttr + "EmptyMessageTitle")));
}, function () {
return model.variables.optionsIn.testIdAttr;
})
},
value: model.variables.optionsIn.searchAttr.emptyMessageAttr,
_idProps: {
service: idService,
uuid: "27"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._optionsInDataFetchStatus)
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "phone-number-input__dropdown-empty-message-description",
visible: true,
_idProps: {
service: idService,
uuid: "28"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": model.getCachedValue(idService.getId("elTkj7jFdEutjwxnqu_6Tg.data-testid"), function () {
return (((model.variables.optionsIn.testIdAttr === "")) ? ("") : ((model.variables.optionsIn.testIdAttr + "EmptyMessageDescription")));
}, function () {
return model.variables.optionsIn.testIdAttr;
})
},
value: model.variables.optionsIn.searchAttr.emptyDescriptionAttr,
_idProps: {
service: idService,
uuid: "29"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._optionsInDataFetchStatus)
}))))), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "phone-number-input__overlay",
visible: true,
_idProps: {
service: idService,
uuid: "30"
},
_widgetRecordProvider: widgetsRecordProvider
})));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.PhoneNumberInput.mvc$controller", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.controller", "ShopperPortalEU_UI_Components.languageResources", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.PhoneNumberInput.mvc$debugger", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.PhoneNumberInput.mvc$controller.Search.SearchJS", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.PhoneNumberInput.mvc$controller.OnDestroy.DestroyJS", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.PhoneNumberInput.mvc$controller.Toggle.ToggleJS", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.PhoneNumberInput.mvc$controller.OnReady.InitializeJS", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.PhoneNumberInput.mvc$controller.DropdownRendered.DropdownRenderedJS", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.PhoneNumberInput.mvc$controller.OnParametersChanged.ParametersChangedJS", "ShopperPortalEU_UI_Components.model$PhoneNumberInputCountryOptionsList", "ShopperPortalEU_UI_Components.model$PhoneNumberInputChangeOptionsRec", "ShopperPortalEU_UI_Components.model$PhoneNumberInputOptionsRec", "ShopperPortalEU_UI_Components.model$CustomFlagOptionsRec", "ShopperPortalEU_UI_Components.model$CustomIconOptionsRec"], function (OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ComponentsController, ShopperPortalEU_UI_ComponentsLanguageResources, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_PhoneNumberInput_mvc_Debugger, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_PhoneNumberInput_mvc_controller_Search_SearchJS, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_PhoneNumberInput_mvc_controller_OnDestroy_DestroyJS, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_PhoneNumberInput_mvc_controller_Toggle_ToggleJS, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_PhoneNumberInput_mvc_controller_OnReady_InitializeJS, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_PhoneNumberInput_mvc_controller_DropdownRendered_DropdownRenderedJS, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_PhoneNumberInput_mvc_controller_OnParametersChanged_ParametersChangedJS) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {
setCountries$Action: function (countriesListIn) {
countriesListIn = (countriesListIn === undefined) ? "" : countriesListIn;
return controller.executeActionInsideJSNode(controller._setCountries$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(countriesListIn, OS.DataTypes.DataTypes.Text)), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "SetCountries");
},
setValue$Action: function (dataIn) {
dataIn = (dataIn === undefined) ? "" : dataIn;
return controller.executeActionInsideJSNode(controller._setValue$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(dataIn, OS.DataTypes.DataTypes.Text)), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "SetValue");
},
open$Action: function () {
return controller.executeActionInsideJSNode(controller._open$Action.bind(controller), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "Open");
},
close$Action: function () {
return controller.executeActionInsideJSNode(controller._close$Action.bind(controller), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "Close");
}
};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = false;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._search$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Search");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:eslBDkQhEkusKuqt0Fsmyw:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.beu+s6c8pE69t2Th59VNnA/ClientActions.eslBDkQhEkusKuqt0Fsmyw:1LOxACtsxrg40Tman7pANQ", "ShopperPortalEU_UI_Components", "Search", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:B+f+RksLiEuMg+ZUVuYrRA", callContext.id);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:CIjj6u4gkUCCGMc+hDkO2w", callContext.id);
// Search method.
controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_PhoneNumberInput_mvc_controller_Search_SearchJS, "Search", "Search", {
Obj: OS.DataConversion.JSNodeParamConverter.to(model.variables.objVar, OS.DataTypes.DataTypes.Object),
SearchVar: OS.DataConversion.JSNodeParamConverter.to(model.variables.searchVarVar, OS.DataTypes.DataTypes.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:wSASoqbA8UmSLRifJ5NyRw", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:eslBDkQhEkusKuqt0Fsmyw", callContext.id);
}

};
Controller.prototype._setCountries$Action = function (countriesListIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("SetCountries");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.PhoneNumberInput.SetCountries$vars"))());
vars.value.countriesListInLocal = countriesListIn;
var countriesListFromJSONVar = new OS.DataTypes.VariableHolder(new (OS.Controller.BaseController.getJSONDeserializeOutputType(ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputCountryOptionsList))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.countriesListFromJSONVar = countriesListFromJSONVar;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:iIhMKk_fWUeV1bH_hO84vg:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.beu+s6c8pE69t2Th59VNnA/ClientActions.iIhMKk_fWUeV1bH_hO84vg:ElfFQntBMGmmBCD6QjU1iA", "ShopperPortalEU_UI_Components", "SetCountries", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:rpcyFo+850KoxQ836I8VnA", callContext.id);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:clHTnxCv4keewLL42_Y4OA", callContext.id);
// JSON Deserialize: CountriesListFromJSON
countriesListFromJSONVar.value.dataOut = OS.JSONUtils.deserializeFromJSON(vars.value.countriesListInLocal, ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputCountryOptionsList, false);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:lzf_hBJS3kGHgE7MtIVgkg", callContext.id);
// Countries = CountriesListFromJSON.Data
model.variables.countriesVar = countriesListFromJSONVar.value.dataOut;
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:pyWMRsggrUKngIlnm3WZFg", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:iIhMKk_fWUeV1bH_hO84vg", callContext.id);
}

};
Controller.registerVariableGroupType("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.PhoneNumberInput.SetCountries$vars", [{
name: "CountriesList",
attrName: "countriesListInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
Controller.prototype._close$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Close");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:OibaL6faA02koyjVsydEgQ:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.beu+s6c8pE69t2Th59VNnA/ClientActions.OibaL6faA02koyjVsydEgQ:Tc2m0KhHdTOpYuyhxU7lzw", "ShopperPortalEU_UI_Components", "Close", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:O1g+mB4vFEedKWvRO5rZmw", callContext.id);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:Edd2CdnTE0SBaIK6A0KK_A", callContext.id);
// IsVisible = False
model.variables.isVisibleVar = false;
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:vuInjG3IE02pXNIQMhA8hA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:OibaL6faA02koyjVsydEgQ", callContext.id);
}

};
Controller.prototype._onDestroy$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnDestroy");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:jz+7ZmGQEUWKtff+OMcO+w:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.beu+s6c8pE69t2Th59VNnA/ClientActions.jz+7ZmGQEUWKtff+OMcO+w:CYxMbcmdqKQi6qquxLwigA", "ShopperPortalEU_UI_Components", "OnDestroy", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:1pHNjOFm9EmvypKy_ldmWw", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:68F8cswCLkGUgSmhm4cWug", callContext.id) && ((model.variables.objVar) !== (OS.BuiltinFunctions.nullObject())))) {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:lKiZFPwN7UavYhJtlBeX8g", callContext.id);
// Destroy method.
controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_PhoneNumberInput_mvc_controller_OnDestroy_DestroyJS, "Destroy", "OnDestroy", {
Obj: OS.DataConversion.JSNodeParamConverter.to(model.variables.objVar, OS.DataTypes.DataTypes.Object)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:xEJ_RgRl3USxN9akunhy2w", callContext.id);
// Obj = NullObject
model.variables.objVar = OS.BuiltinFunctions.nullObject();
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:yINMZ7uUa0eCdfOJ62bThw", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:dTSTxprZPUacN3ICIcDijA", callContext.id);
}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:jz+7ZmGQEUWKtff+OMcO+w", callContext.id);
}

};
Controller.prototype._open$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Open");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:2E44fDoWIkaSPu8OqjADeg:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.beu+s6c8pE69t2Th59VNnA/ClientActions.2E44fDoWIkaSPu8OqjADeg:qBWq+_Uuzq11pU6lfaMVyw", "ShopperPortalEU_UI_Components", "Open", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:9WiWuicKx0OvjkVv+IW3vQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:r2TDjXcxIEuUGpOqkzXOSQ", callContext.id);
// IsVisible = True
model.variables.isVisibleVar = true;
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:zOltYStWnUeMaJpRbc8Pxg", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:2E44fDoWIkaSPu8OqjADeg", callContext.id);
}

};
Controller.prototype._toggle$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Toggle");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:0Le8t6NexU2B_X4WobRZow:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.beu+s6c8pE69t2Th59VNnA/ClientActions.0Le8t6NexU2B_X4WobRZow:+K1Lf4iTQdKgvmcoPmT_wg", "ShopperPortalEU_UI_Components", "Toggle", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:41DIU35OkkKALl3bmjfqjA", callContext.id);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:skPRqa6uS0Cd3uanR69flw", callContext.id);
// Toggle method.
controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_PhoneNumberInput_mvc_controller_Toggle_ToggleJS, "Toggle", "Toggle", {
Obj: OS.DataConversion.JSNodeParamConverter.to(model.variables.objVar, OS.DataTypes.DataTypes.Object)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:+yqAcAyJb0i0KqKg0R727A", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:0Le8t6NexU2B_X4WobRZow", callContext.id);
}

};
Controller.prototype._onReady$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnReady");
callContext = controller.callContext(callContext);
var initializeJSResult = new OS.DataTypes.VariableHolder();
var optionsJSONVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.JSONSerializeOutputType());
varBag.callContext = callContext;
varBag.initializeJSResult = initializeJSResult;
varBag.optionsJSONVar = optionsJSONVar;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:5DTFu0JdjkOO5WrmQo+2BQ:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.beu+s6c8pE69t2Th59VNnA/ClientActions.5DTFu0JdjkOO5WrmQo+2BQ:yKKw2rQxuxi+59AvHtryGg", "ShopperPortalEU_UI_Components", "OnReady", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:qZ2aeyLuq0S3RSlnmAG+aA", callContext.id);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:CNBjAXEdhkKFYk2u6FTz2A", callContext.id);
// JSON Serialize: OptionsJSON
optionsJSONVar.value.jSONOut = OS.JSONUtils.serializeToJSON(model.variables.optionsIn, true, false);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:uF__4ebzxk6lAxTQi6qJzQ", callContext.id);
// Initialize component.
initializeJSResult.value = controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_PhoneNumberInput_mvc_controller_OnReady_InitializeJS, "Initialize", "OnReady", {
Options: OS.DataConversion.JSNodeParamConverter.to(optionsJSONVar.value.jSONOut, OS.DataTypes.DataTypes.Text),
ElementId: OS.DataConversion.JSNodeParamConverter.to(idService.getId("Element"), OS.DataTypes.DataTypes.Text),
Obj: OS.DataConversion.JSNodeParamConverter.to(null, OS.DataTypes.DataTypes.Object)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.PhoneNumberInput.OnReady$initializeJSResult"))();
jsNodeResult.objOut = OS.DataConversion.JSNodeParamConverter.from($parameters.Obj, OS.DataTypes.DataTypes.Object);
return jsNodeResult;
}, {
SetCountries: controller.clientActionProxies.setCountries$Action,
SetValue: controller.clientActionProxies.setValue$Action,
Open: controller.clientActionProxies.open$Action,
Close: controller.clientActionProxies.close$Action
}, {});
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:wubkOwEKIE+DbTvSAzXpfQ", callContext.id);
// Obj = Initialize.Obj
model.variables.objVar = initializeJSResult.value.objOut;
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:ctQnP+F++kSPyceui2BoKQ", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:5DTFu0JdjkOO5WrmQo+2BQ", callContext.id);
}

};
Controller.registerVariableGroupType("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.PhoneNumberInput.OnReady$initializeJSResult", [{
name: "Obj",
attrName: "objOut",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Object,
defaultValue: function () {
return null;
}
}]);
Controller.prototype._dropdownRendered$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("DropdownRendered");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:w4a80zQSD0mp12Lm6latCA:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.beu+s6c8pE69t2Th59VNnA/ClientActions.w4a80zQSD0mp12Lm6latCA:_7aN+K0+jvklKAd35eysvg", "ShopperPortalEU_UI_Components", "DropdownRendered", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:LtPOMA0dGk+31wsCs_tCHw", callContext.id);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:32rALVHywESzN8hk7RewWQ", callContext.id);
// DropdownRendered method.
controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_PhoneNumberInput_mvc_controller_DropdownRendered_DropdownRenderedJS, "DropdownRendered", "DropdownRendered", {
Obj: OS.DataConversion.JSNodeParamConverter.to(model.variables.objVar, OS.DataTypes.DataTypes.Object)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:wsV7xArrmUGkBzjGrTMi7w", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:w4a80zQSD0mp12Lm6latCA", callContext.id);
}

};
Controller.prototype._setValue$Action = function (dataIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("SetValue");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.PhoneNumberInput.SetValue$vars"))());
vars.value.dataInLocal = dataIn;
var dataToStructureVar = new OS.DataTypes.VariableHolder(new (OS.Controller.BaseController.getJSONDeserializeOutputType(ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputChangeOptionsRec))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.dataToStructureVar = dataToStructureVar;
OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:kQDF4WmSjkigCxZPUeXT+g:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.beu+s6c8pE69t2Th59VNnA/ClientActions.kQDF4WmSjkigCxZPUeXT+g:eqiaXQPFNp+n9vIVBNbWPA", "ShopperPortalEU_UI_Components", "SetValue", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:teUCz8eZFk+98A3Piizm6g", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:CSr1IxYq_0u9s1s4ycAMGw", callContext.id);
// JSON Deserialize: DataToStructure
dataToStructureVar.value.dataOut = OS.JSONUtils.deserializeFromJSON(vars.value.dataInLocal, ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputChangeOptionsRec, false);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:rnM0wu5fyEmBCojtQTfhSA", callContext.id);
// PhoneNumber = DataToStructure.Data
model.variables.phoneNumberVar = dataToStructureVar.value.dataOut;
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:DYnGdsTs2USxiz8bWMTfgw", callContext.id);
// Trigger Event: OnChange
return controller.onChange$Action(model.variables.phoneNumberVar, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:z2xIkIDg70e8SJXxI3xG5Q", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:kQDF4WmSjkigCxZPUeXT+g", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:kQDF4WmSjkigCxZPUeXT+g", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.PhoneNumberInput.SetValue$vars", [{
name: "Data",
attrName: "dataInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
Controller.prototype._onParametersChanged$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnParametersChanged");
callContext = controller.callContext(callContext);
var optionsJSONVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.JSONSerializeOutputType());
varBag.callContext = callContext;
varBag.optionsJSONVar = optionsJSONVar;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:cMn05GWY8UeCydGUhdvXHw:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.beu+s6c8pE69t2Th59VNnA/ClientActions.cMn05GWY8UeCydGUhdvXHw:orkNM7P3ekApMHG4XNn39A", "ShopperPortalEU_UI_Components", "OnParametersChanged", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:paYzp42WCkuQGbNy7uqn4w", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:kXcylWQRZkqqwoG4PGcDcQ", callContext.id) && ((model.variables.objVar) !== (OS.BuiltinFunctions.nullObject())))) {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:PvMzdubO9k+yu0RmoF4tLA", callContext.id);
// JSON Serialize: OptionsJSON
optionsJSONVar.value.jSONOut = OS.JSONUtils.serializeToJSON(model.variables.optionsIn, true, false);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:DH0pF5ZtOk6JWeE_s6UYig", callContext.id);
// Parameters change method.
controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_PhoneNumberInput_mvc_controller_OnParametersChanged_ParametersChangedJS, "ParametersChanged", "OnParametersChanged", {
Obj: OS.DataConversion.JSNodeParamConverter.to(model.variables.objVar, OS.DataTypes.DataTypes.Object),
Options: OS.DataConversion.JSNodeParamConverter.to(optionsJSONVar.value.jSONOut, OS.DataTypes.DataTypes.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:pw7VjlvdAUit3TDQjEZLSQ", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:AH4IKysrjE+m60+7yC39eg", callContext.id);
}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:cMn05GWY8UeCydGUhdvXHw", callContext.id);
}

};

Controller.prototype.search$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._search$Action, callContext);

};
Controller.prototype.setCountries$Action = function (countriesListIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._setCountries$Action, callContext, countriesListIn);

};
Controller.prototype.close$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._close$Action, callContext);

};
Controller.prototype.onDestroy$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onDestroy$Action, callContext);

};
Controller.prototype.open$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._open$Action, callContext);

};
Controller.prototype.toggle$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._toggle$Action, callContext);

};
Controller.prototype.onReady$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onReady$Action, callContext);

};
Controller.prototype.dropdownRendered$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._dropdownRendered$Action, callContext);

};
Controller.prototype.setValue$Action = function (dataIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._setValue$Action, callContext, dataIn);

};
Controller.prototype.onParametersChanged$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onParametersChanged$Action, callContext);

};
Controller.prototype.onChange$Action = function () {
return Promise.resolve();
};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:7hC2bHqrKEmxvEuPSzIN0Q:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q:g5BtT+X6uN+vFl8t9PMqCQ", "ShopperPortalEU_UI_Components", "ShopperPortalEUUIComponents", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:beu+s6c8pE69t2Th59VNnA:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.beu+s6c8pE69t2Th59VNnA:16H1dDA26JRrR3m53e6L3Q", "ShopperPortalEU_UI_Components", "PhoneNumberInput", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:beu+s6c8pE69t2Th59VNnA", callContext.id);
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:7hC2bHqrKEmxvEuPSzIN0Q", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "ShopperPortalEUUIComponents/PhoneNumberInput On Ready");
return controller.onReady$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "ShopperPortalEUUIComponents/PhoneNumberInput On Destroy");
return controller.onDestroy$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onParametersChangedEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "ShopperPortalEUUIComponents/PhoneNumberInput On Parameters Changed");
return controller.onParametersChanged$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return ShopperPortalEU_UI_ComponentsController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, ShopperPortalEU_UI_ComponentsLanguageResources);
});
define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.PhoneNumberInput.mvc$controller.Search.SearchJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.Obj.search($parameters.SearchVar);
};
});
define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.PhoneNumberInput.mvc$controller.OnDestroy.DestroyJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.Obj.destroy();
};
});
define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.PhoneNumberInput.mvc$controller.Toggle.ToggleJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.Obj.toggle();
};
});
define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.PhoneNumberInput.mvc$controller.OnReady.InitializeJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.Obj = new phoneNumberInput($parameters.ElementId,JSON.parse($parameters.Options),{
    setCountries:$actions.SetCountries,
    setValue:$actions.SetValue,
    open:$actions.Open,
    close:$actions.Close
});
};
});
define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.PhoneNumberInput.mvc$controller.DropdownRendered.DropdownRenderedJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.Obj.dropdownRendered();
};
});
define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.PhoneNumberInput.mvc$controller.OnParametersChanged.ParametersChangedJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.Obj.parametersChanged(JSON.parse($parameters.Options));
};
});

define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.PhoneNumberInput.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"CIjj6u4gkUCCGMc+hDkO2w": {
getter: function (varBag, idService) {
return varBag.searchJSResult.value;
}
},
"nOgyKVWSAEGpmB6ODOF41g": {
getter: function (varBag, idService) {
return varBag.vars.value.countriesListInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"clHTnxCv4keewLL42_Y4OA": {
getter: function (varBag, idService) {
return varBag.countriesListFromJSONVar.value;
}
},
"lKiZFPwN7UavYhJtlBeX8g": {
getter: function (varBag, idService) {
return varBag.destroyJSResult.value;
}
},
"skPRqa6uS0Cd3uanR69flw": {
getter: function (varBag, idService) {
return varBag.toggleJSResult.value;
}
},
"CNBjAXEdhkKFYk2u6FTz2A": {
getter: function (varBag, idService) {
return varBag.optionsJSONVar.value;
}
},
"uF__4ebzxk6lAxTQi6qJzQ": {
getter: function (varBag, idService) {
return varBag.initializeJSResult.value;
}
},
"32rALVHywESzN8hk7RewWQ": {
getter: function (varBag, idService) {
return varBag.dropdownRenderedJSResult.value;
}
},
"QMM2lSTSCkStHx0O1rZPhQ": {
getter: function (varBag, idService) {
return varBag.vars.value.dataInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"CSr1IxYq_0u9s1s4ycAMGw": {
getter: function (varBag, idService) {
return varBag.dataToStructureVar.value;
}
},
"PvMzdubO9k+yu0RmoF4tLA": {
getter: function (varBag, idService) {
return varBag.optionsJSONVar.value;
}
},
"DH0pF5ZtOk6JWeE_s6UYig": {
getter: function (varBag, idService) {
return varBag.parametersChangedJSResult.value;
}
},
"KV6mz0wuuk+nPhCxh_J+qQ": {
getter: function (varBag, idService) {
return varBag.model.variables.objVar;
},
dataType: OS.DataTypes.DataTypes.Object
},
"srwC4Tusu0SlABQHltmVag": {
getter: function (varBag, idService) {
return varBag.model.variables.countriesVar;
}
},
"4ZbnqpN+aE6t3idc+1WR6A": {
getter: function (varBag, idService) {
return varBag.model.variables.phoneNumberVar;
}
},
"PD2PhqkgwE6srz6zH56tMQ": {
getter: function (varBag, idService) {
return varBag.model.variables.searchVarVar;
},
dataType: OS.DataTypes.DataTypes.Text
},
"hosd5bTdp0GFsFKAa6QmEg": {
getter: function (varBag, idService) {
return varBag.model.variables.isVisibleVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"EiqWW6gq40C0vu3MPntIdw": {
getter: function (varBag, idService) {
return varBag.model.variables.optionsIn;
}
},
"4+3riQ3jHEuNsyE928mIrQ": {
getter: function (varBag, idService) {
return varBag.model.variables.extendedClassIn;
},
dataType: OS.DataTypes.DataTypes.Text
},
"wFWrU1+U10qlVmsFCaAbQw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Element"));
})(varBag.model, idService);
}
},
"h7f299RXHUmMmgMUBmkqjg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input_MobileNumber"));
})(varBag.model, idService);
}
},
"toEELZuwFUCc_OKYnB3oPg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input_Search"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
