define("ShopperPortalEU_Forms_IS.model$RefundDetails_WrapperRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var RefundDetails_WrapperRec = (function (_super) {
__extends(RefundDetails_WrapperRec, _super);
function RefundDetails_WrapperRec(defaults) {
_super.apply(this, arguments);
}
RefundDetails_WrapperRec.attributesToDeclare = function () {
return [
this.attr("CurrencyIso", "currencyIsoAttr", "CurrencyIso", false, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true), 
this.attr("PaymentType", "paymentTypeAttr", "PaymentType", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("PaymentAccount", "paymentAccountAttr", "PaymentAccount", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("PaidOn", "paidOnAttr", "PaidOn", false, false, OS.DataTypes.DataTypes.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("AcquirerRef", "acquirerRefAttr", "AcquirerRef", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Location", "locationAttr", "Location", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
RefundDetails_WrapperRec.init();
return RefundDetails_WrapperRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Forms_ISModel.RefundDetails_WrapperRec = RefundDetails_WrapperRec;

});
define("ShopperPortalEU_Forms_IS.model$RefundDetails_WrapperRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$RefundDetails_WrapperRec"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var RefundDetails_WrapperRecord = (function (_super) {
__extends(RefundDetails_WrapperRecord, _super);
function RefundDetails_WrapperRecord(defaults) {
_super.apply(this, arguments);
}
RefundDetails_WrapperRecord.attributesToDeclare = function () {
return [
this.attr("RefundDetails_Wrapper", "refundDetails_WrapperAttr", "RefundDetails_Wrapper", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Forms_ISModel.RefundDetails_WrapperRec());
}, true, ShopperPortalEU_Forms_ISModel.RefundDetails_WrapperRec)
].concat(_super.attributesToDeclare.call(this));
};
RefundDetails_WrapperRecord.fromStructure = function (str) {
return new RefundDetails_WrapperRecord(new RefundDetails_WrapperRecord.RecordClass({
refundDetails_WrapperAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
RefundDetails_WrapperRecord._isAnonymousRecord = true;
RefundDetails_WrapperRecord.UniqueId = "be72198d-7a64-8e63-e860-8ca3ce8a9205";
RefundDetails_WrapperRecord.init();
return RefundDetails_WrapperRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Forms_ISModel.RefundDetails_WrapperRecord = RefundDetails_WrapperRecord;

});
define("ShopperPortalEU_Forms_IS.model$RefundDetails_WrapperRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$RefundDetails_WrapperRecord"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var RefundDetails_WrapperRecordList = (function (_super) {
__extends(RefundDetails_WrapperRecordList, _super);
function RefundDetails_WrapperRecordList(defaults) {
_super.apply(this, arguments);
}
RefundDetails_WrapperRecordList.itemType = ShopperPortalEU_Forms_ISModel.RefundDetails_WrapperRecord;
return RefundDetails_WrapperRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Forms_ISModel.RefundDetails_WrapperRecordList = RefundDetails_WrapperRecordList;

});
define("ShopperPortalEU_Forms_IS.model$FormRefundDetailsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var FormRefundDetailsRec = (function (_super) {
__extends(FormRefundDetailsRec, _super);
function FormRefundDetailsRec(defaults) {
_super.apply(this, arguments);
}
FormRefundDetailsRec.attributesToDeclare = function () {
return [
this.attr("ActualRefundAmount", "actualRefundAmountAttr", "actualRefundAmount", false, false, OS.DataTypes.DataTypes.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("CurrencyCode", "currencyCodeAttr", "currencyCode", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("CurrencyIso", "currencyIsoAttr", "currencyIso", false, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true), 
this.attr("PaidOn", "paidOnAttr", "paidOn", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("PaymentType", "paymentTypeAttr", "paymentType", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("PaymentAccount", "paymentAccountAttr", "paymentAccount", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("AcquirerReference", "acquirerReferenceAttr", "acquirerReference", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("RefundLocation", "refundLocationAttr", "refundLocation", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
FormRefundDetailsRec.init();
return FormRefundDetailsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Forms_ISModel.FormRefundDetailsRec = FormRefundDetailsRec;

});
define("ShopperPortalEU_Forms_IS.model$FormsRequestRefundDetailsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var FormsRequestRefundDetailsRec = (function (_super) {
__extends(FormsRequestRefundDetailsRec, _super);
function FormsRequestRefundDetailsRec(defaults) {
_super.apply(this, arguments);
}
FormsRequestRefundDetailsRec.attributesToDeclare = function () {
return [
this.attr("RefundMethod", "refundMethodAttr", "refundMethod", false, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true), 
this.attr("RefundType", "refundTypeAttr", "refundType", false, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true), 
this.attr("CreditCardNumberMasked", "creditCardNumberMaskedAttr", "creditCardNumberMasked", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
FormsRequestRefundDetailsRec.init();
return FormsRequestRefundDetailsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Forms_ISModel.FormsRequestRefundDetailsRec = FormsRequestRefundDetailsRec;

});
define("ShopperPortalEU_Forms_IS.model$FormsListDetailRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$FormRefundDetailsRec", "ShopperPortalEU_Forms_IS.model$FormsRequestRefundDetailsRec"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var FormsListDetailRec = (function (_super) {
__extends(FormsListDetailRec, _super);
function FormsListDetailRec(defaults) {
_super.apply(this, arguments);
}
FormsListDetailRec.attributesToDeclare = function () {
return [
this.attr("MerchantName", "merchantNameAttr", "merchantName", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("FormNumber", "formNumberAttr", "formNumber", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("FormIssuedDateTime", "formIssuedDateTimeAttr", "formIssuedDateTime", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("EstimatedRefundAmount", "estimatedRefundAmountAttr", "estimatedRefundAmount", false, false, OS.DataTypes.DataTypes.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("CurrencyIso", "currencyIsoAttr", "currencyIso", false, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true), 
this.attr("RefundStatus", "refundStatusAttr", "refundStatus", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("CombinedFormStatus", "combinedFormStatusAttr", "combinedFormStatus", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("RefundFlow", "refundFlowAttr", "refundFlow", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("RefundDetails", "refundDetailsAttr", "RefundDetails", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Forms_ISModel.FormRefundDetailsRec());
}, true, ShopperPortalEU_Forms_ISModel.FormRefundDetailsRec), 
this.attr("FormsRequestRefundDetails", "formsRequestRefundDetailsAttr", "requestRefundDetails", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Forms_ISModel.FormsRequestRefundDetailsRec());
}, true, ShopperPortalEU_Forms_ISModel.FormsRequestRefundDetailsRec)
].concat(_super.attributesToDeclare.call(this));
};
FormsListDetailRec.init();
return FormsListDetailRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Forms_ISModel.FormsListDetailRec = FormsListDetailRec;

});
define("ShopperPortalEU_Forms_IS.model$FormsListDetailList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$FormsListDetailRec"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var FormsListDetailList = (function (_super) {
__extends(FormsListDetailList, _super);
function FormsListDetailList(defaults) {
_super.apply(this, arguments);
}
FormsListDetailList.itemType = ShopperPortalEU_Forms_ISModel.FormsListDetailRec;
return FormsListDetailList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Forms_ISModel.FormsListDetailList = FormsListDetailList;

});
define("ShopperPortalEU_Forms_IS.model$AnonymousFormAddRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var AnonymousFormAddRec = (function (_super) {
__extends(AnonymousFormAddRec, _super);
function AnonymousFormAddRec(defaults) {
_super.apply(this, arguments);
}
AnonymousFormAddRec.attributesToDeclare = function () {
return [
this.attr("PurchaseDate", "purchaseDateAttr", "purchaseDate", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("TravelDocumentId", "travelDocumentIdAttr", "travelDocumentId", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("PassportIssuingCountry", "passportIssuingCountryAttr", "passportIssuingCountry", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
AnonymousFormAddRec.init();
return AnonymousFormAddRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Forms_ISModel.AnonymousFormAddRec = AnonymousFormAddRec;

});
define("ShopperPortalEU_Forms_IS.model$AnonymousFormAddList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$AnonymousFormAddRec"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var AnonymousFormAddList = (function (_super) {
__extends(AnonymousFormAddList, _super);
function AnonymousFormAddList(defaults) {
_super.apply(this, arguments);
}
AnonymousFormAddList.itemType = ShopperPortalEU_Forms_ISModel.AnonymousFormAddRec;
return AnonymousFormAddList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Forms_ISModel.AnonymousFormAddList = AnonymousFormAddList;

});
define("ShopperPortalEU_Forms_IS.model$RefundDetailsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var RefundDetailsRec = (function (_super) {
__extends(RefundDetailsRec, _super);
function RefundDetailsRec(defaults) {
_super.apply(this, arguments);
}
RefundDetailsRec.attributesToDeclare = function () {
return [
this.attr("ActualRefundAmount", "actualRefundAmountAttr", "ActualRefundAmount", false, false, OS.DataTypes.DataTypes.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("CurrencyCode", "currencyCodeAttr", "currencyCode", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("CurrencyIso", "currencyIsoAttr", "CurrencyIso", false, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true), 
this.attr("PaidOn", "paidOnAttr", "PaidOn", false, false, OS.DataTypes.DataTypes.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("PaymentType", "paymentTypeAttr", "PaymentType", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("PaymentAccount", "paymentAccountAttr", "PaymentAccount", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("AcquirerReference", "acquirerReferenceAttr", "AcquirerReference", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("RefundLocation", "refundLocationAttr", "RefundLocation", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
RefundDetailsRec.init();
return RefundDetailsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Forms_ISModel.RefundDetailsRec = RefundDetailsRec;

});
define("ShopperPortalEU_Forms_IS.model$FormRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$RefundDetailsRec"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var FormRec = (function (_super) {
__extends(FormRec, _super);
function FormRec(defaults) {
_super.apply(this, arguments);
}
FormRec.attributesToDeclare = function () {
return [
this.attr("MerchantName", "merchantNameAttr", "MerchantName", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("FormNumber", "formNumberAttr", "FormNumber", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("FormIssuedDateTime", "formIssuedDateTimeAttr", "FormIssuedDateTime", false, false, OS.DataTypes.DataTypes.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("RefundAmount", "refundAmountAttr", "refundAmount", false, false, OS.DataTypes.DataTypes.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("CombinedFormStatus", "combinedFormStatusAttr", "CombinedFormStatus", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("RefundFlow", "refundFlowAttr", "RefundFlow", false, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true), 
this.attr("RefundDetails", "refundDetailsAttr", "RefundDetails", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Forms_ISModel.RefundDetailsRec());
}, true, ShopperPortalEU_Forms_ISModel.RefundDetailsRec)
].concat(_super.attributesToDeclare.call(this));
};
FormRec.init();
return FormRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Forms_ISModel.FormRec = FormRec;

});
define("ShopperPortalEU_Forms_IS.model$MerchantLocationRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var MerchantLocationRec = (function (_super) {
__extends(MerchantLocationRec, _super);
function MerchantLocationRec(defaults) {
_super.apply(this, arguments);
}
MerchantLocationRec.attributesToDeclare = function () {
return [
this.attr("MerchantName", "merchantNameAttr", "merchantName", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("MerchantCity", "merchantCityAttr", "merchantCity", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("MerchantCountry", "merchantCountryAttr", "merchantCountry", false, false, OS.DataTypes.DataTypes.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("HeadOfficeName", "headOfficeNameAttr", "headOfficeName", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
MerchantLocationRec.init();
return MerchantLocationRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Forms_ISModel.MerchantLocationRec = MerchantLocationRec;

});
define("ShopperPortalEU_Forms_IS.model$MerchantLocationList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$MerchantLocationRec"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var MerchantLocationList = (function (_super) {
__extends(MerchantLocationList, _super);
function MerchantLocationList(defaults) {
_super.apply(this, arguments);
}
MerchantLocationList.itemType = ShopperPortalEU_Forms_ISModel.MerchantLocationRec;
return MerchantLocationList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Forms_ISModel.MerchantLocationList = MerchantLocationList;

});
define("ShopperPortalEU_Forms_IS.model$FormShopperDetailRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var FormShopperDetailRec = (function (_super) {
__extends(FormShopperDetailRec, _super);
function FormShopperDetailRec(defaults) {
_super.apply(this, arguments);
}
FormShopperDetailRec.attributesToDeclare = function () {
return [
this.attr("Title", "titleAttr", "title", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("FirstName", "firstNameAttr", "firstName", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("LastName", "lastNameAttr", "lastName", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("AddressLineOne", "addressLineOneAttr", "addressLineOne", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("AddressLineTwo", "addressLineTwoAttr", "addressLineTwo", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Region", "regionAttr", "region", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("City", "cityAttr", "city", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("PostCode", "postCodeAttr", "postCode", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Email", "emailAttr", "email", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("MobileNumber", "mobileNumberAttr", "mobileNumber", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("DateOfBirth", "dateOfBirthAttr", "dateOfBirth", false, false, OS.DataTypes.DataTypes.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("TaxIdentifierNumber", "taxIdentifierNumberAttr", "taxIdentifierNumber", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("CountryOfResidenceIso", "countryOfResidenceIsoAttr", "countryOfResidenceIso", false, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true), 
this.attr("CountryOfResidenceTerritoryCode", "countryOfResidenceTerritoryCodeAttr", "countryOfResidenceTerritoryCode", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("NationalityIso", "nationalityIsoAttr", "nationalityIso", false, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true), 
this.attr("TravelDocumentType", "travelDocumentTypeAttr", "travelDocumentType", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("TravelDocumentNumber", "travelDocumentNumberAttr", "travelDocumentNumber", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("TravelDocumentIssuedByIso", "travelDocumentIssuedByIsoAttr", "TravelDocumentIssuedByIso", false, false, OS.DataTypes.DataTypes.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("TravelDocumentExpirationDate", "travelDocumentExpirationDateAttr", "travelDocumentExpirationDate", false, false, OS.DataTypes.DataTypes.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
FormShopperDetailRec.init();
return FormShopperDetailRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Forms_ISModel.FormShopperDetailRec = FormShopperDetailRec;

});
define("ShopperPortalEU_Forms_IS.model$FormsRequestRefundDetailsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$FormsRequestRefundDetailsRec"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var FormsRequestRefundDetailsList = (function (_super) {
__extends(FormsRequestRefundDetailsList, _super);
function FormsRequestRefundDetailsList(defaults) {
_super.apply(this, arguments);
}
FormsRequestRefundDetailsList.itemType = ShopperPortalEU_Forms_ISModel.FormsRequestRefundDetailsRec;
return FormsRequestRefundDetailsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Forms_ISModel.FormsRequestRefundDetailsList = FormsRequestRefundDetailsList;

});
define("ShopperPortalEU_Forms_IS.model$CardStateTypeList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_UI_Components.model$CardStateTypeRec", "ShopperPortalEU_Forms_IS.referencesHealth", "ShopperPortalEU_Forms_IS.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var CardStateTypeList = (function (_super) {
__extends(CardStateTypeList, _super);
function CardStateTypeList(defaults) {
_super.apply(this, arguments);
}
CardStateTypeList.itemType = ShopperPortalEU_UI_ComponentsModel.CardStateTypeRec;
return CardStateTypeList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Forms_ISModel.CardStateTypeList = CardStateTypeList;

});
define("ShopperPortalEU_Forms_IS.model$RefundDetailsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$RefundDetailsRec"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var RefundDetailsRecord = (function (_super) {
__extends(RefundDetailsRecord, _super);
function RefundDetailsRecord(defaults) {
_super.apply(this, arguments);
}
RefundDetailsRecord.attributesToDeclare = function () {
return [
this.attr("RefundDetails", "refundDetailsAttr", "RefundDetails", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Forms_ISModel.RefundDetailsRec());
}, true, ShopperPortalEU_Forms_ISModel.RefundDetailsRec)
].concat(_super.attributesToDeclare.call(this));
};
RefundDetailsRecord.fromStructure = function (str) {
return new RefundDetailsRecord(new RefundDetailsRecord.RecordClass({
refundDetailsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
RefundDetailsRecord._isAnonymousRecord = true;
RefundDetailsRecord.UniqueId = "256dce3f-a690-af57-fc1e-9f628b95fabb";
RefundDetailsRecord.init();
return RefundDetailsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Forms_ISModel.RefundDetailsRecord = RefundDetailsRecord;

});
define("ShopperPortalEU_Forms_IS.model$CustomTagStateRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_UI_Components.model$CustomTagStateRec", "ShopperPortalEU_Forms_IS.referencesHealth", "ShopperPortalEU_Forms_IS.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var CustomTagStateRecord = (function (_super) {
__extends(CustomTagStateRecord, _super);
function CustomTagStateRecord(defaults) {
_super.apply(this, arguments);
}
CustomTagStateRecord.attributesToDeclare = function () {
return [
this.attr("CustomTagState", "customTagStateAttr", "CustomTagState", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomTagStateRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomTagStateRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomTagStateRecord.fromStructure = function (str) {
return new CustomTagStateRecord(new CustomTagStateRecord.RecordClass({
customTagStateAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomTagStateRecord._isAnonymousRecord = true;
CustomTagStateRecord.UniqueId = "257bb42e-a6a8-1fb0-b051-e88ca4f96cd4";
CustomTagStateRecord.init();
return CustomTagStateRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Forms_ISModel.CustomTagStateRecord = CustomTagStateRecord;

});
define("ShopperPortalEU_Forms_IS.model$FormListRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$FormsListDetailList"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var FormListRec = (function (_super) {
__extends(FormListRec, _super);
function FormListRec(defaults) {
_super.apply(this, arguments);
}
FormListRec.attributesToDeclare = function () {
return [
this.attr("FormListDetail", "formListDetailAttr", "formsDetail", false, false, OS.DataTypes.DataTypes.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Forms_ISModel.FormsListDetailList());
}, true, ShopperPortalEU_Forms_ISModel.FormsListDetailList)
].concat(_super.attributesToDeclare.call(this));
};
FormListRec.fromStructure = function (str) {
return new FormListRec(new FormListRec.RecordClass({
formListDetailAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
FormListRec.init();
return FormListRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Forms_ISModel.FormListRec = FormListRec;

});
define("ShopperPortalEU_Forms_IS.model$FormListRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$FormListRec"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var FormListRecord = (function (_super) {
__extends(FormListRecord, _super);
function FormListRecord(defaults) {
_super.apply(this, arguments);
}
FormListRecord.attributesToDeclare = function () {
return [
this.attr("FormList", "formListAttr", "FormList", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Forms_ISModel.FormListRec());
}, true, ShopperPortalEU_Forms_ISModel.FormListRec)
].concat(_super.attributesToDeclare.call(this));
};
FormListRecord.fromStructure = function (str) {
return new FormListRecord(new FormListRecord.RecordClass({
formListAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
FormListRecord._isAnonymousRecord = true;
FormListRecord.UniqueId = "27eaa5c3-2954-924e-6c3f-63b4bc6772ca";
FormListRecord.init();
return FormListRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Forms_ISModel.FormListRecord = FormListRecord;

});
define("ShopperPortalEU_Forms_IS.model$RefundDetailsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$RefundDetailsRecord"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var RefundDetailsRecordList = (function (_super) {
__extends(RefundDetailsRecordList, _super);
function RefundDetailsRecordList(defaults) {
_super.apply(this, arguments);
}
RefundDetailsRecordList.itemType = ShopperPortalEU_Forms_ISModel.RefundDetailsRecord;
return RefundDetailsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Forms_ISModel.RefundDetailsRecordList = RefundDetailsRecordList;

});
define("ShopperPortalEU_Forms_IS.model$FormRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$FormRec"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var FormRecord = (function (_super) {
__extends(FormRecord, _super);
function FormRecord(defaults) {
_super.apply(this, arguments);
}
FormRecord.attributesToDeclare = function () {
return [
this.attr("Form", "formAttr", "Form", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Forms_ISModel.FormRec());
}, true, ShopperPortalEU_Forms_ISModel.FormRec)
].concat(_super.attributesToDeclare.call(this));
};
FormRecord.fromStructure = function (str) {
return new FormRecord(new FormRecord.RecordClass({
formAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
FormRecord._isAnonymousRecord = true;
FormRecord.UniqueId = "3362dc43-097f-8e04-5e2d-f3adb4a082ec";
FormRecord.init();
return FormRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Forms_ISModel.FormRecord = FormRecord;

});
define("ShopperPortalEU_Forms_IS.model$RefundDetailsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$RefundDetailsRec"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var RefundDetailsList = (function (_super) {
__extends(RefundDetailsList, _super);
function RefundDetailsList(defaults) {
_super.apply(this, arguments);
}
RefundDetailsList.itemType = ShopperPortalEU_Forms_ISModel.RefundDetailsRec;
return RefundDetailsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Forms_ISModel.RefundDetailsList = RefundDetailsList;

});
define("ShopperPortalEU_Forms_IS.model$FormRequestRefundDetailsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var FormRequestRefundDetailsRec = (function (_super) {
__extends(FormRequestRefundDetailsRec, _super);
function FormRequestRefundDetailsRec(defaults) {
_super.apply(this, arguments);
}
FormRequestRefundDetailsRec.attributesToDeclare = function () {
return [
this.attr("RefundMethod", "refundMethodAttr", "refundMethod", false, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true), 
this.attr("RefundType", "refundTypeAttr", "refundType", false, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true), 
this.attr("CreditCardNumberMasked", "creditCardNumberMaskedAttr", "creditCardNumberMasked", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
FormRequestRefundDetailsRec.init();
return FormRequestRefundDetailsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Forms_ISModel.FormRequestRefundDetailsRec = FormRequestRefundDetailsRec;

});
define("ShopperPortalEU_Forms_IS.model$FormRequestRefundRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var FormRequestRefundRec = (function (_super) {
__extends(FormRequestRefundRec, _super);
function FormRequestRefundRec(defaults) {
_super.apply(this, arguments);
}
FormRequestRefundRec.attributesToDeclare = function () {
return [
this.attr("FormNumber", "formNumberAttr", "formNumber", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("MaskedCardNumber", "maskedCardNumberAttr", "maskedCardNumber", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("ExpiryDate", "expiryDateAttr", "expiryDate", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("TokenValue", "tokenValueAttr", "tokenValue", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("CardTokenProvider", "cardTokenProviderAttr", "cardTokenProvider", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("PaymentMethod", "paymentMethodAttr", "paymentMethod", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
FormRequestRefundRec.init();
return FormRequestRefundRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Forms_ISModel.FormRequestRefundRec = FormRequestRefundRec;

});
define("ShopperPortalEU_Forms_IS.model$FormRequestRefundRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$FormRequestRefundRec"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var FormRequestRefundRecord = (function (_super) {
__extends(FormRequestRefundRecord, _super);
function FormRequestRefundRecord(defaults) {
_super.apply(this, arguments);
}
FormRequestRefundRecord.attributesToDeclare = function () {
return [
this.attr("FormRequestRefund", "formRequestRefundAttr", "FormRequestRefund", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Forms_ISModel.FormRequestRefundRec());
}, true, ShopperPortalEU_Forms_ISModel.FormRequestRefundRec)
].concat(_super.attributesToDeclare.call(this));
};
FormRequestRefundRecord.fromStructure = function (str) {
return new FormRequestRefundRecord(new FormRequestRefundRecord.RecordClass({
formRequestRefundAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
FormRequestRefundRecord._isAnonymousRecord = true;
FormRequestRefundRecord.UniqueId = "3bb10a93-aef9-ea4d-eb8b-4476b1818f86";
FormRequestRefundRecord.init();
return FormRequestRefundRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Forms_ISModel.FormRequestRefundRecord = FormRequestRefundRecord;

});
define("ShopperPortalEU_Forms_IS.model$SPFormStatusRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_CS.model$SPFormStatusRec", "ShopperPortalEU_Forms_IS.referencesHealth", "ShopperPortalEU_Forms_IS.referencesHealth$ShopperPortalEU_CS"], function (exports, OutSystems, ShopperPortalEU_CSModel, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var SPFormStatusRecord = (function (_super) {
__extends(SPFormStatusRecord, _super);
function SPFormStatusRecord(defaults) {
_super.apply(this, arguments);
}
SPFormStatusRecord.attributesToDeclare = function () {
return [
this.attr("SPFormStatus", "sPFormStatusAttr", "SPFormStatus", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_CSModel.SPFormStatusRec());
}, true, ShopperPortalEU_CSModel.SPFormStatusRec)
].concat(_super.attributesToDeclare.call(this));
};
SPFormStatusRecord.fromStructure = function (str) {
return new SPFormStatusRecord(new SPFormStatusRecord.RecordClass({
sPFormStatusAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
SPFormStatusRecord._isAnonymousRecord = true;
SPFormStatusRecord.UniqueId = "3e57435d-0124-13a2-dbac-617b836b9cf2";
SPFormStatusRecord.init();
return SPFormStatusRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Forms_ISModel.SPFormStatusRecord = SPFormStatusRecord;

});
define("ShopperPortalEU_Forms_IS.model$FormDetails_WrapperRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var FormDetails_WrapperRec = (function (_super) {
__extends(FormDetails_WrapperRec, _super);
function FormDetails_WrapperRec(defaults) {
_super.apply(this, arguments);
}
FormDetails_WrapperRec.attributesToDeclare = function () {
return [
this.attr("Barcode", "barcodeAttr", "Barcode", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Pdf", "pdfAttr", "Pdf", false, false, OS.DataTypes.DataTypes.BinaryData, function () {
return OS.DataTypes.BinaryData.defaultValue;
}, true), 
this.attr("CardStateTypeId", "cardStateTypeIdAttr", "CardStateTypeId", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("FormStatusId", "formStatusIdAttr", "FormStatusId", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
FormDetails_WrapperRec.init();
return FormDetails_WrapperRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Forms_ISModel.FormDetails_WrapperRec = FormDetails_WrapperRec;

});
define("ShopperPortalEU_Forms_IS.model$SPFormStatus_InfoRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_CS.model$SPFormStatus_InfoRec", "ShopperPortalEU_Forms_IS.referencesHealth", "ShopperPortalEU_Forms_IS.referencesHealth$ShopperPortalEU_CS"], function (exports, OutSystems, ShopperPortalEU_CSModel, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var SPFormStatus_InfoRecord = (function (_super) {
__extends(SPFormStatus_InfoRecord, _super);
function SPFormStatus_InfoRecord(defaults) {
_super.apply(this, arguments);
}
SPFormStatus_InfoRecord.attributesToDeclare = function () {
return [
this.attr("SPFormStatus_Info", "sPFormStatus_InfoAttr", "SPFormStatus_Info", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_CSModel.SPFormStatus_InfoRec());
}, true, ShopperPortalEU_CSModel.SPFormStatus_InfoRec)
].concat(_super.attributesToDeclare.call(this));
};
SPFormStatus_InfoRecord.fromStructure = function (str) {
return new SPFormStatus_InfoRecord(new SPFormStatus_InfoRecord.RecordClass({
sPFormStatus_InfoAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
SPFormStatus_InfoRecord._isAnonymousRecord = true;
SPFormStatus_InfoRecord.UniqueId = "dfff159d-f514-f63c-0717-17ce31743aaf";
SPFormStatus_InfoRecord.init();
return SPFormStatus_InfoRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Forms_ISModel.SPFormStatus_InfoRecord = SPFormStatus_InfoRecord;

});
define("ShopperPortalEU_Forms_IS.model$SPFormStatus_InfoRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$SPFormStatus_InfoRecord"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var SPFormStatus_InfoRecordList = (function (_super) {
__extends(SPFormStatus_InfoRecordList, _super);
function SPFormStatus_InfoRecordList(defaults) {
_super.apply(this, arguments);
}
SPFormStatus_InfoRecordList.itemType = ShopperPortalEU_Forms_ISModel.SPFormStatus_InfoRecord;
return SPFormStatus_InfoRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Forms_ISModel.SPFormStatus_InfoRecordList = SPFormStatus_InfoRecordList;

});
define("ShopperPortalEU_Forms_IS.model$FormDetails_WrapperRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$FormDetails_WrapperRec"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var FormDetails_WrapperRecord = (function (_super) {
__extends(FormDetails_WrapperRecord, _super);
function FormDetails_WrapperRecord(defaults) {
_super.apply(this, arguments);
}
FormDetails_WrapperRecord.attributesToDeclare = function () {
return [
this.attr("FormDetails_Wrapper", "formDetails_WrapperAttr", "FormDetails_Wrapper", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Forms_ISModel.FormDetails_WrapperRec());
}, true, ShopperPortalEU_Forms_ISModel.FormDetails_WrapperRec)
].concat(_super.attributesToDeclare.call(this));
};
FormDetails_WrapperRecord.fromStructure = function (str) {
return new FormDetails_WrapperRecord(new FormDetails_WrapperRecord.RecordClass({
formDetails_WrapperAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
FormDetails_WrapperRecord._isAnonymousRecord = true;
FormDetails_WrapperRecord.UniqueId = "629612d4-b284-bccc-5aeb-98c37fa5fdfd";
FormDetails_WrapperRecord.init();
return FormDetails_WrapperRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Forms_ISModel.FormDetails_WrapperRecord = FormDetails_WrapperRecord;

});
define("ShopperPortalEU_Forms_IS.model$FormDetails_WrapperRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$FormDetails_WrapperRecord"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var FormDetails_WrapperRecordList = (function (_super) {
__extends(FormDetails_WrapperRecordList, _super);
function FormDetails_WrapperRecordList(defaults) {
_super.apply(this, arguments);
}
FormDetails_WrapperRecordList.itemType = ShopperPortalEU_Forms_ISModel.FormDetails_WrapperRecord;
return FormDetails_WrapperRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Forms_ISModel.FormDetails_WrapperRecordList = FormDetails_WrapperRecordList;

});
define("ShopperPortalEU_Forms_IS.model$FormRequestRefundDetailsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$FormRequestRefundDetailsRec"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var FormRequestRefundDetailsRecord = (function (_super) {
__extends(FormRequestRefundDetailsRecord, _super);
function FormRequestRefundDetailsRecord(defaults) {
_super.apply(this, arguments);
}
FormRequestRefundDetailsRecord.attributesToDeclare = function () {
return [
this.attr("FormRequestRefundDetails", "formRequestRefundDetailsAttr", "FormRequestRefundDetails", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Forms_ISModel.FormRequestRefundDetailsRec());
}, true, ShopperPortalEU_Forms_ISModel.FormRequestRefundDetailsRec)
].concat(_super.attributesToDeclare.call(this));
};
FormRequestRefundDetailsRecord.fromStructure = function (str) {
return new FormRequestRefundDetailsRecord(new FormRequestRefundDetailsRecord.RecordClass({
formRequestRefundDetailsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
FormRequestRefundDetailsRecord._isAnonymousRecord = true;
FormRequestRefundDetailsRecord.UniqueId = "89c8bd2c-e456-bf44-10d4-a0d18e1ef2b7";
FormRequestRefundDetailsRecord.init();
return FormRequestRefundDetailsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Forms_ISModel.FormRequestRefundDetailsRecord = FormRequestRefundDetailsRecord;

});
define("ShopperPortalEU_Forms_IS.model$FormRequestRefundDetailsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$FormRequestRefundDetailsRecord"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var FormRequestRefundDetailsRecordList = (function (_super) {
__extends(FormRequestRefundDetailsRecordList, _super);
function FormRequestRefundDetailsRecordList(defaults) {
_super.apply(this, arguments);
}
FormRequestRefundDetailsRecordList.itemType = ShopperPortalEU_Forms_ISModel.FormRequestRefundDetailsRecord;
return FormRequestRefundDetailsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Forms_ISModel.FormRequestRefundDetailsRecordList = FormRequestRefundDetailsRecordList;

});
define("ShopperPortalEU_Forms_IS.model$RefundDetailsPaymentDetails_UIRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var RefundDetailsPaymentDetails_UIRec = (function (_super) {
__extends(RefundDetailsPaymentDetails_UIRec, _super);
function RefundDetailsPaymentDetails_UIRec(defaults) {
_super.apply(this, arguments);
}
RefundDetailsPaymentDetails_UIRec.attributesToDeclare = function () {
return [
this.attr("DisplayPaidOn_UI", "displayPaidOn_UIAttr", "DisplayPaidOn_UI", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("DisplayLocation_UI", "displayLocation_UIAttr", "DisplayLocation_UI", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("DisplayMethod_UI", "displayMethod_UIAttr", "DisplayMethod_UI", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("DisplayARN_UI", "displayARN_UIAttr", "DisplayARN_UI", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
RefundDetailsPaymentDetails_UIRec.init();
return RefundDetailsPaymentDetails_UIRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Forms_ISModel.RefundDetailsPaymentDetails_UIRec = RefundDetailsPaymentDetails_UIRec;

});
define("ShopperPortalEU_Forms_IS.model$UIConfigurationRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$RefundDetailsPaymentDetails_UIRec"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var UIConfigurationRec = (function (_super) {
__extends(UIConfigurationRec, _super);
function UIConfigurationRec(defaults) {
_super.apply(this, arguments);
}
UIConfigurationRec.attributesToDeclare = function () {
return [
this.attr("DisplayBarcode_UI", "displayBarcode_UIAttr", "DisplayBarcode_UI", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("DisplayViewForm_UI", "displayViewForm_UIAttr", "DisplayViewForm_UI", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("DisplayAdditionalInfo_UI", "displayAdditionalInfo_UIAttr", "DisplayAdditionalInfo_UI", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("DisplayRefundPaymentsDetails_UI", "displayRefundPaymentsDetails_UIAttr", "DisplayRefundPaymentsDetails_UI", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("DisplayRefundPaymentsInfo_WheresMyRefund", "displayRefundPaymentsInfo_WheresMyRefundAttr", "DisplayRefundPaymentsInfo_WheresMyRefund", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("HasRefundStepsPage", "hasRefundStepsPageAttr", "HasRefundStepsPage", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("RefundDetailsPaymentDetails_UI", "refundDetailsPaymentDetails_UIAttr", "RefundDetailsPaymentDetails_UI", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Forms_ISModel.RefundDetailsPaymentDetails_UIRec());
}, true, ShopperPortalEU_Forms_ISModel.RefundDetailsPaymentDetails_UIRec)
].concat(_super.attributesToDeclare.call(this));
};
UIConfigurationRec.init();
return UIConfigurationRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Forms_ISModel.UIConfigurationRec = UIConfigurationRec;

});
define("ShopperPortalEU_Forms_IS.model$UIConfigurationRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$UIConfigurationRec"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var UIConfigurationRecord = (function (_super) {
__extends(UIConfigurationRecord, _super);
function UIConfigurationRecord(defaults) {
_super.apply(this, arguments);
}
UIConfigurationRecord.attributesToDeclare = function () {
return [
this.attr("UIConfiguration", "uIConfigurationAttr", "UIConfiguration", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Forms_ISModel.UIConfigurationRec());
}, true, ShopperPortalEU_Forms_ISModel.UIConfigurationRec)
].concat(_super.attributesToDeclare.call(this));
};
UIConfigurationRecord.fromStructure = function (str) {
return new UIConfigurationRecord(new UIConfigurationRecord.RecordClass({
uIConfigurationAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
UIConfigurationRecord._isAnonymousRecord = true;
UIConfigurationRecord.UniqueId = "5a0d29a6-e534-3bb6-6dde-bbbccf1b042c";
UIConfigurationRecord.init();
return UIConfigurationRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Forms_ISModel.UIConfigurationRecord = UIConfigurationRecord;

});
define("ShopperPortalEU_Forms_IS.model$FormInfo_WrapperRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$RefundDetails_WrapperRec", "ShopperPortalEU_Forms_IS.model$FormDetails_WrapperRec", "ShopperPortalEU_Forms_IS.model$UIConfigurationRec"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var FormInfo_WrapperRec = (function (_super) {
__extends(FormInfo_WrapperRec, _super);
function FormInfo_WrapperRec(defaults) {
_super.apply(this, arguments);
}
FormInfo_WrapperRec.attributesToDeclare = function () {
return [
this.attr("FormNumber", "formNumberAttr", "FormNumber", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("FormNumberFormatted", "formNumberFormattedAttr", "FormNumberFormatted", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("MerchantName", "merchantNameAttr", "MerchantName", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("FormDateTxt", "formDateTxtAttr", "FormDateTxt", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("RefundLabel_UI", "refundLabel_UIAttr", "RefundLabel_UI", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("RefundAmountTxt", "refundAmountTxtAttr", "RefundAmountTxt", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("RefundAmount", "refundAmountAttr", "RefundAmount", false, false, OS.DataTypes.DataTypes.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("RefundAmountCurrency", "refundAmountCurrencyAttr", "RefundAmountCurrency", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("RefundAmountMessage", "refundAmountMessageAttr", "RefundAmountMessage", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("RefundStatus", "refundStatusAttr", "refundStatus", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("FormStatusLabel", "formStatusLabelAttr", "FormStatusLabel", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("FormTagState", "formTagStateAttr", "FormTagState", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("IsActive", "isActiveAttr", "IsActive", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("IsClosed", "isClosedAttr", "IsClosed", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("IsReadyForRefund", "isReadyForRefundAttr", "IsReadyForRefund", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("RefundDetails", "refundDetailsAttr", "RefundDetails", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Forms_ISModel.RefundDetails_WrapperRec());
}, true, ShopperPortalEU_Forms_ISModel.RefundDetails_WrapperRec), 
this.attr("FormDetails", "formDetailsAttr", "FormDetails", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Forms_ISModel.FormDetails_WrapperRec());
}, true, ShopperPortalEU_Forms_ISModel.FormDetails_WrapperRec), 
this.attr("UIConfiguration", "uIConfigurationAttr", "UIConfiguration", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Forms_ISModel.UIConfigurationRec());
}, true, ShopperPortalEU_Forms_ISModel.UIConfigurationRec)
].concat(_super.attributesToDeclare.call(this));
};
FormInfo_WrapperRec.init();
return FormInfo_WrapperRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Forms_ISModel.FormInfo_WrapperRec = FormInfo_WrapperRec;

});
define("ShopperPortalEU_Forms_IS.model$RefundDetailsPaymentDetails_UIList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$RefundDetailsPaymentDetails_UIRec"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var RefundDetailsPaymentDetails_UIList = (function (_super) {
__extends(RefundDetailsPaymentDetails_UIList, _super);
function RefundDetailsPaymentDetails_UIList(defaults) {
_super.apply(this, arguments);
}
RefundDetailsPaymentDetails_UIList.itemType = ShopperPortalEU_Forms_ISModel.RefundDetailsPaymentDetails_UIRec;
return RefundDetailsPaymentDetails_UIList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Forms_ISModel.RefundDetailsPaymentDetails_UIList = RefundDetailsPaymentDetails_UIList;

});
define("ShopperPortalEU_Forms_IS.model$DatatransTokenFallbackList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Shopper_IS.model$DatatransTokenFallbackRec", "ShopperPortalEU_Forms_IS.referencesHealth", "ShopperPortalEU_Forms_IS.referencesHealth$ShopperPortalEU_Shopper_IS"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var DatatransTokenFallbackList = (function (_super) {
__extends(DatatransTokenFallbackList, _super);
function DatatransTokenFallbackList(defaults) {
_super.apply(this, arguments);
}
DatatransTokenFallbackList.itemType = ShopperPortalEU_Shopper_ISModel.DatatransTokenFallbackRec;
return DatatransTokenFallbackList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Forms_ISModel.DatatransTokenFallbackList = DatatransTokenFallbackList;

});
define("ShopperPortalEU_Forms_IS.model$FormDetailsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$FormShopperDetailRec", "ShopperPortalEU_Forms_IS.model$MerchantLocationRec", "ShopperPortalEU_Forms_IS.model$FormRefundDetailsRec", "ShopperPortalEU_Forms_IS.model$FormRequestRefundDetailsRec"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var FormDetailsRec = (function (_super) {
__extends(FormDetailsRec, _super);
function FormDetailsRec(defaults) {
_super.apply(this, arguments);
}
FormDetailsRec.attributesToDeclare = function () {
return [
this.attr("FormNumber", "formNumberAttr", "formNumber", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("FormIssuedDateTime", "formIssuedDateTimeAttr", "formIssuedDateTime", false, false, OS.DataTypes.DataTypes.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("EstimatedRefundAmount", "estimatedRefundAmountAttr", "estimatedRefundAmount", false, false, OS.DataTypes.DataTypes.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("VatAmount", "vatAmountAttr", "vatAmount", false, false, OS.DataTypes.DataTypes.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("TotalAmount", "totalAmountAttr", "totalAmount", false, false, OS.DataTypes.DataTypes.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("CurrencyIso", "currencyIsoAttr", "currencyIso", false, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true), 
this.attr("CombinedFormStatus", "combinedFormStatusAttr", "combinedFormStatus", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("RefundStatus", "refundStatusAttr", "refundStatus", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("RefundFlow", "refundFlowAttr", "refundFlow", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("FormShopperDetails", "formShopperDetailsAttr", "formShopperDetails", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Forms_ISModel.FormShopperDetailRec());
}, true, ShopperPortalEU_Forms_ISModel.FormShopperDetailRec), 
this.attr("MerchantLocation", "merchantLocationAttr", "merchantLocation", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Forms_ISModel.MerchantLocationRec());
}, true, ShopperPortalEU_Forms_ISModel.MerchantLocationRec), 
this.attr("FormRefundDetails", "formRefundDetailsAttr", "formRefundDetails", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Forms_ISModel.FormRefundDetailsRec());
}, true, ShopperPortalEU_Forms_ISModel.FormRefundDetailsRec), 
this.attr("FormRequestRefundDetails", "formRequestRefundDetailsAttr", "formRequestRefundDetails", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Forms_ISModel.FormRequestRefundDetailsRec());
}, true, ShopperPortalEU_Forms_ISModel.FormRequestRefundDetailsRec)
].concat(_super.attributesToDeclare.call(this));
};
FormDetailsRec.init();
return FormDetailsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Forms_ISModel.FormDetailsRec = FormDetailsRec;

});
define("ShopperPortalEU_Forms_IS.model$FormDetailsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$FormDetailsRec"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var FormDetailsList = (function (_super) {
__extends(FormDetailsList, _super);
function FormDetailsList(defaults) {
_super.apply(this, arguments);
}
FormDetailsList.itemType = ShopperPortalEU_Forms_ISModel.FormDetailsRec;
return FormDetailsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Forms_ISModel.FormDetailsList = FormDetailsList;

});
define("ShopperPortalEU_Forms_IS.model$FormsRequestRefundDetailsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$FormsRequestRefundDetailsRec"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var FormsRequestRefundDetailsRecord = (function (_super) {
__extends(FormsRequestRefundDetailsRecord, _super);
function FormsRequestRefundDetailsRecord(defaults) {
_super.apply(this, arguments);
}
FormsRequestRefundDetailsRecord.attributesToDeclare = function () {
return [
this.attr("FormsRequestRefundDetails", "formsRequestRefundDetailsAttr", "FormsRequestRefundDetails", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Forms_ISModel.FormsRequestRefundDetailsRec());
}, true, ShopperPortalEU_Forms_ISModel.FormsRequestRefundDetailsRec)
].concat(_super.attributesToDeclare.call(this));
};
FormsRequestRefundDetailsRecord.fromStructure = function (str) {
return new FormsRequestRefundDetailsRecord(new FormsRequestRefundDetailsRecord.RecordClass({
formsRequestRefundDetailsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
FormsRequestRefundDetailsRecord._isAnonymousRecord = true;
FormsRequestRefundDetailsRecord.UniqueId = "6757920f-537a-fdd8-e323-005cbd525e0d";
FormsRequestRefundDetailsRecord.init();
return FormsRequestRefundDetailsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Forms_ISModel.FormsRequestRefundDetailsRecord = FormsRequestRefundDetailsRecord;

});
define("ShopperPortalEU_Forms_IS.model$DatatransTokenFallbackRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Shopper_IS.model$DatatransTokenFallbackRec", "ShopperPortalEU_Forms_IS.referencesHealth", "ShopperPortalEU_Forms_IS.referencesHealth$ShopperPortalEU_Shopper_IS"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var DatatransTokenFallbackRecord = (function (_super) {
__extends(DatatransTokenFallbackRecord, _super);
function DatatransTokenFallbackRecord(defaults) {
_super.apply(this, arguments);
}
DatatransTokenFallbackRecord.attributesToDeclare = function () {
return [
this.attr("DatatransTokenFallback", "datatransTokenFallbackAttr", "DatatransTokenFallback", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Shopper_ISModel.DatatransTokenFallbackRec());
}, true, ShopperPortalEU_Shopper_ISModel.DatatransTokenFallbackRec)
].concat(_super.attributesToDeclare.call(this));
};
DatatransTokenFallbackRecord.fromStructure = function (str) {
return new DatatransTokenFallbackRecord(new DatatransTokenFallbackRecord.RecordClass({
datatransTokenFallbackAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
DatatransTokenFallbackRecord._isAnonymousRecord = true;
DatatransTokenFallbackRecord.UniqueId = "a00329e6-e7a4-5fa0-fa18-442f4b66f64e";
DatatransTokenFallbackRecord.init();
return DatatransTokenFallbackRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Forms_ISModel.DatatransTokenFallbackRecord = DatatransTokenFallbackRecord;

});
define("ShopperPortalEU_Forms_IS.model$DatatransTokenFallbackRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$DatatransTokenFallbackRecord"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var DatatransTokenFallbackRecordList = (function (_super) {
__extends(DatatransTokenFallbackRecordList, _super);
function DatatransTokenFallbackRecordList(defaults) {
_super.apply(this, arguments);
}
DatatransTokenFallbackRecordList.itemType = ShopperPortalEU_Forms_ISModel.DatatransTokenFallbackRecord;
return DatatransTokenFallbackRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Forms_ISModel.DatatransTokenFallbackRecordList = DatatransTokenFallbackRecordList;

});
define("ShopperPortalEU_Forms_IS.model$CustomTagStateRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$CustomTagStateRecord"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var CustomTagStateRecordList = (function (_super) {
__extends(CustomTagStateRecordList, _super);
function CustomTagStateRecordList(defaults) {
_super.apply(this, arguments);
}
CustomTagStateRecordList.itemType = ShopperPortalEU_Forms_ISModel.CustomTagStateRecord;
return CustomTagStateRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Forms_ISModel.CustomTagStateRecordList = CustomTagStateRecordList;

});
define("ShopperPortalEU_Forms_IS.model$CardStateTypeRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_UI_Components.model$CardStateTypeRec", "ShopperPortalEU_Forms_IS.referencesHealth", "ShopperPortalEU_Forms_IS.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var CardStateTypeRecord = (function (_super) {
__extends(CardStateTypeRecord, _super);
function CardStateTypeRecord(defaults) {
_super.apply(this, arguments);
}
CardStateTypeRecord.attributesToDeclare = function () {
return [
this.attr("CardStateType", "cardStateTypeAttr", "CardStateType", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CardStateTypeRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CardStateTypeRec)
].concat(_super.attributesToDeclare.call(this));
};
CardStateTypeRecord.fromStructure = function (str) {
return new CardStateTypeRecord(new CardStateTypeRecord.RecordClass({
cardStateTypeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CardStateTypeRecord._isAnonymousRecord = true;
CardStateTypeRecord.UniqueId = "b7d7feb7-5b30-ca61-c992-48b012ab0684";
CardStateTypeRecord.init();
return CardStateTypeRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Forms_ISModel.CardStateTypeRecord = CardStateTypeRecord;

});
define("ShopperPortalEU_Forms_IS.model$CardStateTypeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$CardStateTypeRecord"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var CardStateTypeRecordList = (function (_super) {
__extends(CardStateTypeRecordList, _super);
function CardStateTypeRecordList(defaults) {
_super.apply(this, arguments);
}
CardStateTypeRecordList.itemType = ShopperPortalEU_Forms_ISModel.CardStateTypeRecord;
return CardStateTypeRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Forms_ISModel.CardStateTypeRecordList = CardStateTypeRecordList;

});
define("ShopperPortalEU_Forms_IS.model$FormRefundDetailsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$FormRefundDetailsRec"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var FormRefundDetailsRecord = (function (_super) {
__extends(FormRefundDetailsRecord, _super);
function FormRefundDetailsRecord(defaults) {
_super.apply(this, arguments);
}
FormRefundDetailsRecord.attributesToDeclare = function () {
return [
this.attr("FormRefundDetails", "formRefundDetailsAttr", "FormRefundDetails", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Forms_ISModel.FormRefundDetailsRec());
}, true, ShopperPortalEU_Forms_ISModel.FormRefundDetailsRec)
].concat(_super.attributesToDeclare.call(this));
};
FormRefundDetailsRecord.fromStructure = function (str) {
return new FormRefundDetailsRecord(new FormRefundDetailsRecord.RecordClass({
formRefundDetailsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
FormRefundDetailsRecord._isAnonymousRecord = true;
FormRefundDetailsRecord.UniqueId = "b7331959-8bfa-c150-6fc5-39df4065973f";
FormRefundDetailsRecord.init();
return FormRefundDetailsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Forms_ISModel.FormRefundDetailsRecord = FormRefundDetailsRecord;

});
define("ShopperPortalEU_Forms_IS.model$FormRefundDetailsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$FormRefundDetailsRecord"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var FormRefundDetailsRecordList = (function (_super) {
__extends(FormRefundDetailsRecordList, _super);
function FormRefundDetailsRecordList(defaults) {
_super.apply(this, arguments);
}
FormRefundDetailsRecordList.itemType = ShopperPortalEU_Forms_ISModel.FormRefundDetailsRecord;
return FormRefundDetailsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Forms_ISModel.FormRefundDetailsRecordList = FormRefundDetailsRecordList;

});
define("ShopperPortalEU_Forms_IS.model$FormInfo_WrapperList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$FormInfo_WrapperRec"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var FormInfo_WrapperList = (function (_super) {
__extends(FormInfo_WrapperList, _super);
function FormInfo_WrapperList(defaults) {
_super.apply(this, arguments);
}
FormInfo_WrapperList.itemType = ShopperPortalEU_Forms_ISModel.FormInfo_WrapperRec;
return FormInfo_WrapperList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Forms_ISModel.FormInfo_WrapperList = FormInfo_WrapperList;

});
define("ShopperPortalEU_Forms_IS.model$FormListRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$FormListRecord"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var FormListRecordList = (function (_super) {
__extends(FormListRecordList, _super);
function FormListRecordList(defaults) {
_super.apply(this, arguments);
}
FormListRecordList.itemType = ShopperPortalEU_Forms_ISModel.FormListRecord;
return FormListRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Forms_ISModel.FormListRecordList = FormListRecordList;

});
define("ShopperPortalEU_Forms_IS.model$UIConfigurationList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$UIConfigurationRec"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var UIConfigurationList = (function (_super) {
__extends(UIConfigurationList, _super);
function UIConfigurationList(defaults) {
_super.apply(this, arguments);
}
UIConfigurationList.itemType = ShopperPortalEU_Forms_ISModel.UIConfigurationRec;
return UIConfigurationList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Forms_ISModel.UIConfigurationList = UIConfigurationList;

});
define("ShopperPortalEU_Forms_IS.model$CustomTagStateList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_UI_Components.model$CustomTagStateRec", "ShopperPortalEU_Forms_IS.referencesHealth", "ShopperPortalEU_Forms_IS.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var CustomTagStateList = (function (_super) {
__extends(CustomTagStateList, _super);
function CustomTagStateList(defaults) {
_super.apply(this, arguments);
}
CustomTagStateList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomTagStateRec;
return CustomTagStateList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Forms_ISModel.CustomTagStateList = CustomTagStateList;

});
define("ShopperPortalEU_Forms_IS.model$FormShopperDetailList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$FormShopperDetailRec"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var FormShopperDetailList = (function (_super) {
__extends(FormShopperDetailList, _super);
function FormShopperDetailList(defaults) {
_super.apply(this, arguments);
}
FormShopperDetailList.itemType = ShopperPortalEU_Forms_ISModel.FormShopperDetailRec;
return FormShopperDetailList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Forms_ISModel.FormShopperDetailList = FormShopperDetailList;

});
define("ShopperPortalEU_Forms_IS.model$FormRequestRefundDetailsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$FormRequestRefundDetailsRec"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var FormRequestRefundDetailsList = (function (_super) {
__extends(FormRequestRefundDetailsList, _super);
function FormRequestRefundDetailsList(defaults) {
_super.apply(this, arguments);
}
FormRequestRefundDetailsList.itemType = ShopperPortalEU_Forms_ISModel.FormRequestRefundDetailsRec;
return FormRequestRefundDetailsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Forms_ISModel.FormRequestRefundDetailsList = FormRequestRefundDetailsList;

});
define("ShopperPortalEU_Forms_IS.model$GetCardsResponseRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Shopper_IS.model$GetCardsResponseRec", "ShopperPortalEU_Forms_IS.referencesHealth", "ShopperPortalEU_Forms_IS.referencesHealth$ShopperPortalEU_Shopper_IS"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var GetCardsResponseRecord = (function (_super) {
__extends(GetCardsResponseRecord, _super);
function GetCardsResponseRecord(defaults) {
_super.apply(this, arguments);
}
GetCardsResponseRecord.attributesToDeclare = function () {
return [
this.attr("GetCardsResponse", "getCardsResponseAttr", "GetCardsResponse", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Shopper_ISModel.GetCardsResponseRec());
}, true, ShopperPortalEU_Shopper_ISModel.GetCardsResponseRec)
].concat(_super.attributesToDeclare.call(this));
};
GetCardsResponseRecord.fromStructure = function (str) {
return new GetCardsResponseRecord(new GetCardsResponseRecord.RecordClass({
getCardsResponseAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
GetCardsResponseRecord._isAnonymousRecord = true;
GetCardsResponseRecord.UniqueId = "c5ad02da-ae50-7a50-e338-796338df6661";
GetCardsResponseRecord.init();
return GetCardsResponseRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Forms_ISModel.GetCardsResponseRecord = GetCardsResponseRecord;

});
define("ShopperPortalEU_Forms_IS.model$GetCardsResponseRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$GetCardsResponseRecord"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var GetCardsResponseRecordList = (function (_super) {
__extends(GetCardsResponseRecordList, _super);
function GetCardsResponseRecordList(defaults) {
_super.apply(this, arguments);
}
GetCardsResponseRecordList.itemType = ShopperPortalEU_Forms_ISModel.GetCardsResponseRecord;
return GetCardsResponseRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Forms_ISModel.GetCardsResponseRecordList = GetCardsResponseRecordList;

});
define("ShopperPortalEU_Forms_IS.model$FormsRequestRefundDetailsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$FormsRequestRefundDetailsRecord"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var FormsRequestRefundDetailsRecordList = (function (_super) {
__extends(FormsRequestRefundDetailsRecordList, _super);
function FormsRequestRefundDetailsRecordList(defaults) {
_super.apply(this, arguments);
}
FormsRequestRefundDetailsRecordList.itemType = ShopperPortalEU_Forms_ISModel.FormsRequestRefundDetailsRecord;
return FormsRequestRefundDetailsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Forms_ISModel.FormsRequestRefundDetailsRecordList = FormsRequestRefundDetailsRecordList;

});
define("ShopperPortalEU_Forms_IS.model$GetCardsResponseList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Shopper_IS.model$GetCardsResponseRec", "ShopperPortalEU_Forms_IS.referencesHealth", "ShopperPortalEU_Forms_IS.referencesHealth$ShopperPortalEU_Shopper_IS"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var GetCardsResponseList = (function (_super) {
__extends(GetCardsResponseList, _super);
function GetCardsResponseList(defaults) {
_super.apply(this, arguments);
}
GetCardsResponseList.itemType = ShopperPortalEU_Shopper_ISModel.GetCardsResponseRec;
return GetCardsResponseList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Forms_ISModel.GetCardsResponseList = GetCardsResponseList;

});
define("ShopperPortalEU_Forms_IS.model$AnonymousFormAddRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$AnonymousFormAddRec"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var AnonymousFormAddRecord = (function (_super) {
__extends(AnonymousFormAddRecord, _super);
function AnonymousFormAddRecord(defaults) {
_super.apply(this, arguments);
}
AnonymousFormAddRecord.attributesToDeclare = function () {
return [
this.attr("AnonymousFormAdd", "anonymousFormAddAttr", "AnonymousFormAdd", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Forms_ISModel.AnonymousFormAddRec());
}, true, ShopperPortalEU_Forms_ISModel.AnonymousFormAddRec)
].concat(_super.attributesToDeclare.call(this));
};
AnonymousFormAddRecord.fromStructure = function (str) {
return new AnonymousFormAddRecord(new AnonymousFormAddRecord.RecordClass({
anonymousFormAddAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
AnonymousFormAddRecord._isAnonymousRecord = true;
AnonymousFormAddRecord.UniqueId = "d4e5474c-164d-48e5-8804-bce0ae9093e0";
AnonymousFormAddRecord.init();
return AnonymousFormAddRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Forms_ISModel.AnonymousFormAddRecord = AnonymousFormAddRecord;

});
define("ShopperPortalEU_Forms_IS.model$AnonymousFormAddRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$AnonymousFormAddRecord"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var AnonymousFormAddRecordList = (function (_super) {
__extends(AnonymousFormAddRecordList, _super);
function AnonymousFormAddRecordList(defaults) {
_super.apply(this, arguments);
}
AnonymousFormAddRecordList.itemType = ShopperPortalEU_Forms_ISModel.AnonymousFormAddRecord;
return AnonymousFormAddRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Forms_ISModel.AnonymousFormAddRecordList = AnonymousFormAddRecordList;

});
define("ShopperPortalEU_Forms_IS.model$FormDetailsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$FormDetailsRec"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var FormDetailsRecord = (function (_super) {
__extends(FormDetailsRecord, _super);
function FormDetailsRecord(defaults) {
_super.apply(this, arguments);
}
FormDetailsRecord.attributesToDeclare = function () {
return [
this.attr("FormDetails", "formDetailsAttr", "FormDetails", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Forms_ISModel.FormDetailsRec());
}, true, ShopperPortalEU_Forms_ISModel.FormDetailsRec)
].concat(_super.attributesToDeclare.call(this));
};
FormDetailsRecord.fromStructure = function (str) {
return new FormDetailsRecord(new FormDetailsRecord.RecordClass({
formDetailsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
FormDetailsRecord._isAnonymousRecord = true;
FormDetailsRecord.UniqueId = "90edff5b-3ab5-83d9-7869-c3252f6f4b02";
FormDetailsRecord.init();
return FormDetailsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Forms_ISModel.FormDetailsRecord = FormDetailsRecord;

});
define("ShopperPortalEU_Forms_IS.model$FormList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$FormRec"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var FormList = (function (_super) {
__extends(FormList, _super);
function FormList(defaults) {
_super.apply(this, arguments);
}
FormList.itemType = ShopperPortalEU_Forms_ISModel.FormRec;
return FormList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Forms_ISModel.FormList = FormList;

});
define("ShopperPortalEU_Forms_IS.model$FormRequestRefundList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$FormRequestRefundRec"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var FormRequestRefundList = (function (_super) {
__extends(FormRequestRefundList, _super);
function FormRequestRefundList(defaults) {
_super.apply(this, arguments);
}
FormRequestRefundList.itemType = ShopperPortalEU_Forms_ISModel.FormRequestRefundRec;
return FormRequestRefundList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Forms_ISModel.FormRequestRefundList = FormRequestRefundList;

});
define("ShopperPortalEU_Forms_IS.model$FormShopperDetailRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$FormShopperDetailRec"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var FormShopperDetailRecord = (function (_super) {
__extends(FormShopperDetailRecord, _super);
function FormShopperDetailRecord(defaults) {
_super.apply(this, arguments);
}
FormShopperDetailRecord.attributesToDeclare = function () {
return [
this.attr("FormShopperDetail", "formShopperDetailAttr", "FormShopperDetail", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Forms_ISModel.FormShopperDetailRec());
}, true, ShopperPortalEU_Forms_ISModel.FormShopperDetailRec)
].concat(_super.attributesToDeclare.call(this));
};
FormShopperDetailRecord.fromStructure = function (str) {
return new FormShopperDetailRecord(new FormShopperDetailRecord.RecordClass({
formShopperDetailAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
FormShopperDetailRecord._isAnonymousRecord = true;
FormShopperDetailRecord.UniqueId = "eb6cd8f0-ea7d-368c-ef3b-f94e7754a561";
FormShopperDetailRecord.init();
return FormShopperDetailRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Forms_ISModel.FormShopperDetailRecord = FormShopperDetailRecord;

});
define("ShopperPortalEU_Forms_IS.model$FormShopperDetailRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$FormShopperDetailRecord"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var FormShopperDetailRecordList = (function (_super) {
__extends(FormShopperDetailRecordList, _super);
function FormShopperDetailRecordList(defaults) {
_super.apply(this, arguments);
}
FormShopperDetailRecordList.itemType = ShopperPortalEU_Forms_ISModel.FormShopperDetailRecord;
return FormShopperDetailRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Forms_ISModel.FormShopperDetailRecordList = FormShopperDetailRecordList;

});
define("ShopperPortalEU_Forms_IS.model$SPFormStatusList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_CS.model$SPFormStatusRec", "ShopperPortalEU_Forms_IS.referencesHealth", "ShopperPortalEU_Forms_IS.referencesHealth$ShopperPortalEU_CS"], function (exports, OutSystems, ShopperPortalEU_CSModel, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var SPFormStatusList = (function (_super) {
__extends(SPFormStatusList, _super);
function SPFormStatusList(defaults) {
_super.apply(this, arguments);
}
SPFormStatusList.itemType = ShopperPortalEU_CSModel.SPFormStatusRec;
return SPFormStatusList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Forms_ISModel.SPFormStatusList = SPFormStatusList;

});
define("ShopperPortalEU_Forms_IS.model$MerchantLocationRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$MerchantLocationRec"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var MerchantLocationRecord = (function (_super) {
__extends(MerchantLocationRecord, _super);
function MerchantLocationRecord(defaults) {
_super.apply(this, arguments);
}
MerchantLocationRecord.attributesToDeclare = function () {
return [
this.attr("MerchantLocation", "merchantLocationAttr", "MerchantLocation", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Forms_ISModel.MerchantLocationRec());
}, true, ShopperPortalEU_Forms_ISModel.MerchantLocationRec)
].concat(_super.attributesToDeclare.call(this));
};
MerchantLocationRecord.fromStructure = function (str) {
return new MerchantLocationRecord(new MerchantLocationRecord.RecordClass({
merchantLocationAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
MerchantLocationRecord._isAnonymousRecord = true;
MerchantLocationRecord.UniqueId = "f3f74cd1-e4f5-5931-c327-89be9c089260";
MerchantLocationRecord.init();
return MerchantLocationRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Forms_ISModel.MerchantLocationRecord = MerchantLocationRecord;

});
define("ShopperPortalEU_Forms_IS.model$MerchantLocationRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$MerchantLocationRecord"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var MerchantLocationRecordList = (function (_super) {
__extends(MerchantLocationRecordList, _super);
function MerchantLocationRecordList(defaults) {
_super.apply(this, arguments);
}
MerchantLocationRecordList.itemType = ShopperPortalEU_Forms_ISModel.MerchantLocationRecord;
return MerchantLocationRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Forms_ISModel.MerchantLocationRecordList = MerchantLocationRecordList;

});
define("ShopperPortalEU_Forms_IS.model$UIConfigurationRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$UIConfigurationRecord"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var UIConfigurationRecordList = (function (_super) {
__extends(UIConfigurationRecordList, _super);
function UIConfigurationRecordList(defaults) {
_super.apply(this, arguments);
}
UIConfigurationRecordList.itemType = ShopperPortalEU_Forms_ISModel.UIConfigurationRecord;
return UIConfigurationRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Forms_ISModel.UIConfigurationRecordList = UIConfigurationRecordList;

});
define("ShopperPortalEU_Forms_IS.model$FormRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$FormRecord"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var FormRecordList = (function (_super) {
__extends(FormRecordList, _super);
function FormRecordList(defaults) {
_super.apply(this, arguments);
}
FormRecordList.itemType = ShopperPortalEU_Forms_ISModel.FormRecord;
return FormRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Forms_ISModel.FormRecordList = FormRecordList;

});
define("ShopperPortalEU_Forms_IS.model$SPFormStatusRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$SPFormStatusRecord"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var SPFormStatusRecordList = (function (_super) {
__extends(SPFormStatusRecordList, _super);
function SPFormStatusRecordList(defaults) {
_super.apply(this, arguments);
}
SPFormStatusRecordList.itemType = ShopperPortalEU_Forms_ISModel.SPFormStatusRecord;
return SPFormStatusRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Forms_ISModel.SPFormStatusRecordList = SPFormStatusRecordList;

});
define("ShopperPortalEU_Forms_IS.model$RefundDetails_WrapperList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$RefundDetails_WrapperRec"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var RefundDetails_WrapperList = (function (_super) {
__extends(RefundDetails_WrapperList, _super);
function RefundDetails_WrapperList(defaults) {
_super.apply(this, arguments);
}
RefundDetails_WrapperList.itemType = ShopperPortalEU_Forms_ISModel.RefundDetails_WrapperRec;
return RefundDetails_WrapperList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Forms_ISModel.RefundDetails_WrapperList = RefundDetails_WrapperList;

});
define("ShopperPortalEU_Forms_IS.model$FormsListDetailRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$FormsListDetailRec"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var FormsListDetailRecord = (function (_super) {
__extends(FormsListDetailRecord, _super);
function FormsListDetailRecord(defaults) {
_super.apply(this, arguments);
}
FormsListDetailRecord.attributesToDeclare = function () {
return [
this.attr("FormsListDetail", "formsListDetailAttr", "FormsListDetail", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Forms_ISModel.FormsListDetailRec());
}, true, ShopperPortalEU_Forms_ISModel.FormsListDetailRec)
].concat(_super.attributesToDeclare.call(this));
};
FormsListDetailRecord.fromStructure = function (str) {
return new FormsListDetailRecord(new FormsListDetailRecord.RecordClass({
formsListDetailAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
FormsListDetailRecord._isAnonymousRecord = true;
FormsListDetailRecord.UniqueId = "efbc76f2-977a-1c3f-bd12-a37604149959";
FormsListDetailRecord.init();
return FormsListDetailRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Forms_ISModel.FormsListDetailRecord = FormsListDetailRecord;

});
define("ShopperPortalEU_Forms_IS.model$FormsListDetailRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$FormsListDetailRecord"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var FormsListDetailRecordList = (function (_super) {
__extends(FormsListDetailRecordList, _super);
function FormsListDetailRecordList(defaults) {
_super.apply(this, arguments);
}
FormsListDetailRecordList.itemType = ShopperPortalEU_Forms_ISModel.FormsListDetailRecord;
return FormsListDetailRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Forms_ISModel.FormsListDetailRecordList = FormsListDetailRecordList;

});
define("ShopperPortalEU_Forms_IS.model$FormDetailsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$FormDetailsRecord"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var FormDetailsRecordList = (function (_super) {
__extends(FormDetailsRecordList, _super);
function FormDetailsRecordList(defaults) {
_super.apply(this, arguments);
}
FormDetailsRecordList.itemType = ShopperPortalEU_Forms_ISModel.FormDetailsRecord;
return FormDetailsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Forms_ISModel.FormDetailsRecordList = FormDetailsRecordList;

});
define("ShopperPortalEU_Forms_IS.model$FormRefundDetailsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$FormRefundDetailsRec"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var FormRefundDetailsList = (function (_super) {
__extends(FormRefundDetailsList, _super);
function FormRefundDetailsList(defaults) {
_super.apply(this, arguments);
}
FormRefundDetailsList.itemType = ShopperPortalEU_Forms_ISModel.FormRefundDetailsRec;
return FormRefundDetailsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Forms_ISModel.FormRefundDetailsList = FormRefundDetailsList;

});
define("ShopperPortalEU_Forms_IS.model$FormInfo_WrapperRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$FormInfo_WrapperRec"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var FormInfo_WrapperRecord = (function (_super) {
__extends(FormInfo_WrapperRecord, _super);
function FormInfo_WrapperRecord(defaults) {
_super.apply(this, arguments);
}
FormInfo_WrapperRecord.attributesToDeclare = function () {
return [
this.attr("FormInfo_Wrapper", "formInfo_WrapperAttr", "FormInfo_Wrapper", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Forms_ISModel.FormInfo_WrapperRec());
}, true, ShopperPortalEU_Forms_ISModel.FormInfo_WrapperRec)
].concat(_super.attributesToDeclare.call(this));
};
FormInfo_WrapperRecord.fromStructure = function (str) {
return new FormInfo_WrapperRecord(new FormInfo_WrapperRecord.RecordClass({
formInfo_WrapperAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
FormInfo_WrapperRecord._isAnonymousRecord = true;
FormInfo_WrapperRecord.UniqueId = "f047d9e7-03f8-1ce5-e685-3c380a706f58";
FormInfo_WrapperRecord.init();
return FormInfo_WrapperRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Forms_ISModel.FormInfo_WrapperRecord = FormInfo_WrapperRecord;

});
define("ShopperPortalEU_Forms_IS.model$FormInfo_WrapperRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$FormInfo_WrapperRecord"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var FormInfo_WrapperRecordList = (function (_super) {
__extends(FormInfo_WrapperRecordList, _super);
function FormInfo_WrapperRecordList(defaults) {
_super.apply(this, arguments);
}
FormInfo_WrapperRecordList.itemType = ShopperPortalEU_Forms_ISModel.FormInfo_WrapperRecord;
return FormInfo_WrapperRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Forms_ISModel.FormInfo_WrapperRecordList = FormInfo_WrapperRecordList;

});
define("ShopperPortalEU_Forms_IS.model$FormListList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$FormListRec"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var FormListList = (function (_super) {
__extends(FormListList, _super);
function FormListList(defaults) {
_super.apply(this, arguments);
}
FormListList.itemType = ShopperPortalEU_Forms_ISModel.FormListRec;
return FormListList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Forms_ISModel.FormListList = FormListList;

});
define("ShopperPortalEU_Forms_IS.model$RefundDetailsPaymentDetails_UIRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$RefundDetailsPaymentDetails_UIRec"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var RefundDetailsPaymentDetails_UIRecord = (function (_super) {
__extends(RefundDetailsPaymentDetails_UIRecord, _super);
function RefundDetailsPaymentDetails_UIRecord(defaults) {
_super.apply(this, arguments);
}
RefundDetailsPaymentDetails_UIRecord.attributesToDeclare = function () {
return [
this.attr("RefundDetailsPaymentDetails_UI", "refundDetailsPaymentDetails_UIAttr", "RefundDetailsPaymentDetails_UI", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Forms_ISModel.RefundDetailsPaymentDetails_UIRec());
}, true, ShopperPortalEU_Forms_ISModel.RefundDetailsPaymentDetails_UIRec)
].concat(_super.attributesToDeclare.call(this));
};
RefundDetailsPaymentDetails_UIRecord.fromStructure = function (str) {
return new RefundDetailsPaymentDetails_UIRecord(new RefundDetailsPaymentDetails_UIRecord.RecordClass({
refundDetailsPaymentDetails_UIAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
RefundDetailsPaymentDetails_UIRecord._isAnonymousRecord = true;
RefundDetailsPaymentDetails_UIRecord.UniqueId = "ffc630bc-e3cb-eed0-2402-e2bc158867d9";
RefundDetailsPaymentDetails_UIRecord.init();
return RefundDetailsPaymentDetails_UIRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEU_Forms_ISModel.RefundDetailsPaymentDetails_UIRecord = RefundDetailsPaymentDetails_UIRecord;

});
define("ShopperPortalEU_Forms_IS.model$RefundDetailsPaymentDetails_UIRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$RefundDetailsPaymentDetails_UIRecord"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var RefundDetailsPaymentDetails_UIRecordList = (function (_super) {
__extends(RefundDetailsPaymentDetails_UIRecordList, _super);
function RefundDetailsPaymentDetails_UIRecordList(defaults) {
_super.apply(this, arguments);
}
RefundDetailsPaymentDetails_UIRecordList.itemType = ShopperPortalEU_Forms_ISModel.RefundDetailsPaymentDetails_UIRecord;
return RefundDetailsPaymentDetails_UIRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Forms_ISModel.RefundDetailsPaymentDetails_UIRecordList = RefundDetailsPaymentDetails_UIRecordList;

});
define("ShopperPortalEU_Forms_IS.model$FormRequestRefundRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$FormRequestRefundRecord"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var FormRequestRefundRecordList = (function (_super) {
__extends(FormRequestRefundRecordList, _super);
function FormRequestRefundRecordList(defaults) {
_super.apply(this, arguments);
}
FormRequestRefundRecordList.itemType = ShopperPortalEU_Forms_ISModel.FormRequestRefundRecord;
return FormRequestRefundRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Forms_ISModel.FormRequestRefundRecordList = FormRequestRefundRecordList;

});
define("ShopperPortalEU_Forms_IS.model$FormDetails_WrapperList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Forms_IS.model$FormDetails_WrapperRec"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var FormDetails_WrapperList = (function (_super) {
__extends(FormDetails_WrapperList, _super);
function FormDetails_WrapperList(defaults) {
_super.apply(this, arguments);
}
FormDetails_WrapperList.itemType = ShopperPortalEU_Forms_ISModel.FormDetails_WrapperRec;
return FormDetails_WrapperList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Forms_ISModel.FormDetails_WrapperList = FormDetails_WrapperList;

});
define("ShopperPortalEU_Forms_IS.model$SPFormStatus_InfoList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_CS.model$SPFormStatus_InfoRec", "ShopperPortalEU_Forms_IS.referencesHealth", "ShopperPortalEU_Forms_IS.referencesHealth$ShopperPortalEU_CS"], function (exports, OutSystems, ShopperPortalEU_CSModel, ShopperPortalEU_Forms_ISModel) {
var OS = OutSystems.Internal;
var SPFormStatus_InfoList = (function (_super) {
__extends(SPFormStatus_InfoList, _super);
function SPFormStatus_InfoList(defaults) {
_super.apply(this, arguments);
}
SPFormStatus_InfoList.itemType = ShopperPortalEU_CSModel.SPFormStatus_InfoRec;
return SPFormStatus_InfoList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEU_Forms_ISModel.SPFormStatus_InfoList = SPFormStatus_InfoList;

});
define("ShopperPortalEU_Forms_IS.model", ["exports", "OutSystems/ClientRuntime/Main"], function (exports, OutSystems) {
var OS = OutSystems.Internal;
var ShopperPortalEU_Forms_ISModel = exports;
Object.defineProperty(ShopperPortalEU_Forms_ISModel, "module", {
get: function () {
return OS.ApplicationInfo.getModules()["187c31b8-189b-42f2-a6a2-4c2fde2a8684"];
}
});

ShopperPortalEU_Forms_ISModel.staticEntities = {};
ShopperPortalEU_Forms_ISModel.staticEntities.sPFormStatus = {};
var getSPFormStatusRecord = function (record) {
return OS.ApplicationInfo.getModules()["5f9664ac-af6d-4553-af07-ef3e366dfe88"].staticEntities["fbf43fd7-21ba-4911-a301-a6b77599ca4c"][record];
};
Object.defineProperty(ShopperPortalEU_Forms_ISModel.staticEntities.sPFormStatus, "preRefundClaimRejected", {
get: function () {
return getSPFormStatusRecord("027b4946-de19-47fc-8a1c-0ad444d807bf");
}
});

Object.defineProperty(ShopperPortalEU_Forms_ISModel.staticEntities.sPFormStatus, "preRefundClaimOngoing", {
get: function () {
return getSPFormStatusRecord("04b06f22-59a4-49c0-80b5-23e30caa6e4f");
}
});

Object.defineProperty(ShopperPortalEU_Forms_ISModel.staticEntities.sPFormStatus, "preCustomsInspectionRequired", {
get: function () {
return getSPFormStatusRecord("14cc82e2-957e-4f8f-a37d-a7900f51e536");
}
});

Object.defineProperty(ShopperPortalEU_Forms_ISModel.staticEntities.sPFormStatus, "preRefundRevoked_RB8", {
get: function () {
return getSPFormStatusRecord("1f3ba60c-bc66-497f-97cd-efdc574874f5");
}
});

Object.defineProperty(ShopperPortalEU_Forms_ISModel.staticEntities.sPFormStatus, "postRefundClaimRejected", {
get: function () {
return getSPFormStatusRecord("3366f6fe-154b-4c79-b6b0-8e492d1c0e70");
}
});

Object.defineProperty(ShopperPortalEU_Forms_ISModel.staticEntities.sPFormStatus, "postRefundOnHold", {
get: function () {
return getSPFormStatusRecord("38c905a5-64ae-428b-9b4b-4d29d8fce714");
}
});

Object.defineProperty(ShopperPortalEU_Forms_ISModel.staticEntities.sPFormStatus, "postRefundApproved_RA3", {
get: function () {
return getSPFormStatusRecord("3b8ce5ef-4cd9-4fba-8ab1-c51c5cfb3e0f");
}
});

Object.defineProperty(ShopperPortalEU_Forms_ISModel.staticEntities.sPFormStatus, "preRefundRevoked_RB4", {
get: function () {
return getSPFormStatusRecord("43819221-0247-4c22-9f92-84232e50022c");
}
});

Object.defineProperty(ShopperPortalEU_Forms_ISModel.staticEntities.sPFormStatus, "postRefundClaimCancelled_VA6", {
get: function () {
return getSPFormStatusRecord("4b5676ae-81ea-475f-9cb0-67d465a79d57");
}
});

Object.defineProperty(ShopperPortalEU_Forms_ISModel.staticEntities.sPFormStatus, "refundClaimPending", {
get: function () {
return getSPFormStatusRecord("5048c975-e7a0-4391-9238-91f80c4e703a");
}
});

Object.defineProperty(ShopperPortalEU_Forms_ISModel.staticEntities.sPFormStatus, "preRefundRevoked_RB7", {
get: function () {
return getSPFormStatusRecord("5907711b-d366-40fb-9d98-b8d78104fb2a");
}
});

Object.defineProperty(ShopperPortalEU_Forms_ISModel.staticEntities.sPFormStatus, "postRefundClaimExpired_VA5", {
get: function () {
return getSPFormStatusRecord("5d1778de-efb7-4b9c-a4a3-9c03f08c7057");
}
});

Object.defineProperty(ShopperPortalEU_Forms_ISModel.staticEntities.sPFormStatus, "preRefundClaimCompleted_RB3", {
get: function () {
return getSPFormStatusRecord("6cdc4424-31d8-4959-b9c2-15fcc045d0b9");
}
});

Object.defineProperty(ShopperPortalEU_Forms_ISModel.staticEntities.sPFormStatus, "preRefundClaimCancelled", {
get: function () {
return getSPFormStatusRecord("78ce7dc6-d1e4-4114-bc3a-7c9b671710fa");
}
});

Object.defineProperty(ShopperPortalEU_Forms_ISModel.staticEntities.sPFormStatus, "preGetCustomsApproval", {
get: function () {
return getSPFormStatusRecord("7e0f7c79-5177-43ce-aa5f-e8fb67db71ba");
}
});

Object.defineProperty(ShopperPortalEU_Forms_ISModel.staticEntities.sPFormStatus, "postRefundClaimCancelled_RA9", {
get: function () {
return getSPFormStatusRecord("895a5bf8-72f2-45fb-b862-e918b4573e59");
}
});

Object.defineProperty(ShopperPortalEU_Forms_ISModel.staticEntities.sPFormStatus, "postRefunded_RA7", {
get: function () {
return getSPFormStatusRecord("960ee4c6-05f6-4086-8b6c-4dd7dbfb8a42");
}
});

Object.defineProperty(ShopperPortalEU_Forms_ISModel.staticEntities.sPFormStatus, "preUpdateRefundDetails", {
get: function () {
return getSPFormStatusRecord("99688444-4770-4b6f-9378-49e36e616939");
}
});

Object.defineProperty(ShopperPortalEU_Forms_ISModel.staticEntities.sPFormStatus, "postRefundDetailsRequired", {
get: function () {
return getSPFormStatusRecord("ab960dd4-4691-4d84-8d20-c1bd43ce89e6");
}
});

Object.defineProperty(ShopperPortalEU_Forms_ISModel.staticEntities.sPFormStatus, "postRefundClaimExpired_RA8", {
get: function () {
return getSPFormStatusRecord("b7be8186-c786-43f3-8972-b345ed28b995");
}
});

Object.defineProperty(ShopperPortalEU_Forms_ISModel.staticEntities.sPFormStatus, "postGetCustomsApproval", {
get: function () {
return getSPFormStatusRecord("bb7d65af-552b-485c-954d-30006dd1fa8c");
}
});

Object.defineProperty(ShopperPortalEU_Forms_ISModel.staticEntities.sPFormStatus, "postRefundApproved_RA11", {
get: function () {
return getSPFormStatusRecord("cf654140-6869-45df-a236-903380d51c7e");
}
});

Object.defineProperty(ShopperPortalEU_Forms_ISModel.staticEntities.sPFormStatus, "postRefundInProgress", {
get: function () {
return getSPFormStatusRecord("d50d900f-2dad-4cd2-88fb-20446450a3f3");
}
});

Object.defineProperty(ShopperPortalEU_Forms_ISModel.staticEntities.sPFormStatus, "postRefunded_RA10", {
get: function () {
return getSPFormStatusRecord("d960ec0f-1506-4c0b-aa07-8c388704e023");
}
});

Object.defineProperty(ShopperPortalEU_Forms_ISModel.staticEntities.sPFormStatus, "preRefundClaimCompleted_RB6", {
get: function () {
return getSPFormStatusRecord("f2372b04-3269-4df2-8f6f-39e905fa97c6");
}
});

Object.defineProperty(ShopperPortalEU_Forms_ISModel.staticEntities.sPFormStatus, "postCustomsInspectionRequired", {
get: function () {
return getSPFormStatusRecord("f36f9d17-5cd4-4bab-bc30-240b1e6d3a51");
}
});

Object.defineProperty(ShopperPortalEU_Forms_ISModel.staticEntities.sPFormStatus, "postUpdateRefundDetails", {
get: function () {
return getSPFormStatusRecord("fd776400-6f57-44df-a1bf-ec7084dcd23a");
}
});

ShopperPortalEU_Forms_ISModel.staticEntities.customTagState = {};
var getCustomTagStateRecord = function (record) {
return OS.ApplicationInfo.getModules()["e7bb7e26-af64-4f69-9436-0768d54ea01b"].staticEntities["0ecb397c-3ce5-471f-b18f-87158598df3a"][record];
};
Object.defineProperty(ShopperPortalEU_Forms_ISModel.staticEntities.customTagState, "error", {
get: function () {
return getCustomTagStateRecord("04940de8-397c-4994-96fc-567cc3bb20b1");
}
});

Object.defineProperty(ShopperPortalEU_Forms_ISModel.staticEntities.customTagState, "new", {
get: function () {
return getCustomTagStateRecord("2155d0da-5bf6-4aa3-93ff-4b1503152d74");
}
});

Object.defineProperty(ShopperPortalEU_Forms_ISModel.staticEntities.customTagState, "success", {
get: function () {
return getCustomTagStateRecord("3ee16a50-b2ad-406b-957c-64848a014a00");
}
});

Object.defineProperty(ShopperPortalEU_Forms_ISModel.staticEntities.customTagState, "neutral", {
get: function () {
return getCustomTagStateRecord("c0f27e66-d8bf-42e4-9a1a-3513dce3a21d");
}
});

Object.defineProperty(ShopperPortalEU_Forms_ISModel.staticEntities.customTagState, "info", {
get: function () {
return getCustomTagStateRecord("c0f66ae5-a24d-4d28-ad01-728a7a41fea0");
}
});

Object.defineProperty(ShopperPortalEU_Forms_ISModel.staticEntities.customTagState, "warning", {
get: function () {
return getCustomTagStateRecord("ccc52884-abd4-414f-bdfb-97412fa5bd64");
}
});

Object.defineProperty(ShopperPortalEU_Forms_ISModel.staticEntities.customTagState, "neutralDark", {
get: function () {
return getCustomTagStateRecord("d89d1c3c-871e-4b16-8580-f20a79b9c223");
}
});

ShopperPortalEU_Forms_ISModel.staticEntities.cardStateType = {};
var getCardStateTypeRecord = function (record) {
return OS.ApplicationInfo.getModules()["e7bb7e26-af64-4f69-9436-0768d54ea01b"].staticEntities["cda633b3-44e4-4d03-b041-4ee42266a05a"][record];
};
Object.defineProperty(ShopperPortalEU_Forms_ISModel.staticEntities.cardStateType, "warning", {
get: function () {
return getCardStateTypeRecord("2267ce4f-86c5-4534-9a05-9bc4c1a2b8a6");
}
});

Object.defineProperty(ShopperPortalEU_Forms_ISModel.staticEntities.cardStateType, "success", {
get: function () {
return getCardStateTypeRecord("3358c40b-9c87-49f1-8f5a-cd589557c30e");
}
});

Object.defineProperty(ShopperPortalEU_Forms_ISModel.staticEntities.cardStateType, "info", {
get: function () {
return getCardStateTypeRecord("9dce627a-d246-40cc-a52b-296c2b8e66e5");
}
});

Object.defineProperty(ShopperPortalEU_Forms_ISModel.staticEntities.cardStateType, "error", {
get: function () {
return getCardStateTypeRecord("cb221e47-9ec7-4a77-af8c-f1208585d4c4");
}
});

});
