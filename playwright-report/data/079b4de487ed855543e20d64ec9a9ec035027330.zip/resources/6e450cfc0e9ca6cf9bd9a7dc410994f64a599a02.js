define("ShopperPortalEU.Profile.CompleteDetails.mvc$model", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.controller", "ShopperPortalEU_UI_Theme.controller", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.controller", "ShopperPortalEU.controller$FormatEmptyString", "ShopperPortalEU.controller$FormatDate", "ShopperPortalEU.controller$GetCountryName", "ShopperPortalEU.model$CompleteDetailsRec", "ShopperPortalEU_UI_Components.model$DatePickerValidationOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$CustomDropdownListValidationOptionsRec", "ShopperPortalEU_UI_Theme.model$LayoutDetailOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU_UI_Components.model$CustomFormOptionsRec", "ShopperPortalEU_UI_Components.model$CustomColumnsOptionsRec", "ShopperPortalEU_UI_Components.model$CustomInputOptionsRec", "ShopperPortalEU_UI_Components.model$CustomInputIconOptionRec", "ShopperPortalEU_UI_Components.model$CustomInputValidationOptionsRec", "ShopperPortalEU_UI_Components.model$DatePickerOptionsRec", "ShopperPortalEU_UI_Components.model$DatePickerLabelOptionsRec", "ShopperPortalEU.model$CountriesWithFlagsDropdownListList", "ShopperPortalEU_UI_Components.model$LabelValueOptionsRec", "ShopperPortalEU_UI_Components.model$PhoneNumberInputOptionsRec", "ShopperPortalEU_UI_Components.model$PhoneNumberInputSearchOptionsRec", "ShopperPortalEU_UI_Components.model$CustomBottomBarOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconRec", "ShopperPortalEU_UI_Components.model$PhoneNumberInputChangeOptionsRec", "ShopperPortalEU.controller$PercentageProfileCalculation", "ShopperPortalEU.controller$ShopperCreateOrUpdateDetails", "ShopperPortalEU_UI_Components.controller$ScrollToFirstInvalidField", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", "ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger", "ShopperPortalEU.controller$ClarityEvent", "ShopperPortalEU.controller$FormatTitleCase", "ShopperPortalEU.controller$DefaultErrorMessage", "ShopperPortalEU.controller$CheckOnlyLetters", "ShopperPortalEU.controller$FormatShopperName", "ShopperPortalEU_UI_Components.model$CustomDropdownListValueOptionsRec", "ShopperPortalEU_Shopper_IS.model$GetShopperResponseRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS", "ShopperPortalEU_Shopper_IS.controller$GetShopper", "ShopperPortalEU.controller$ShopperCheckMandatoryFields", "ShopperPortalEU.model$ScanPassportRec", "ShopperPortalEU.model$ApcuesIdentifyRec", "ShopperPortalEU.controller$ApcuesIdentify", "ShopperPortalEU.controller$HeapIdentify"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ComponentsController, ShopperPortalEU_UI_ThemeController, ShopperPortalEU_Shopper_ISModel, ShopperPortalEU_Shopper_ISController) {
var OS = OutSystems.Internal;

var GetCountriesDataActRec = (function (_super) {
__extends(GetCountriesDataActRec, _super);
function GetCountriesDataActRec(defaults) {
_super.apply(this, arguments);
}
GetCountriesDataActRec.attributesToDeclare = function () {
return [
this.attr("Countries", "countriesOut", "Countries", true, false, OS.DataTypes.DataTypes.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEUModel.CountriesWithFlagsDropdownListList());
}, true, ShopperPortalEUModel.CountriesWithFlagsDropdownListList)
].concat(_super.attributesToDeclare.call(this));
};
GetCountriesDataActRec.fromStructure = function (str) {
return new GetCountriesDataActRec(new GetCountriesDataActRec.RecordClass({
countriesOut: OS.DataTypes.ImmutableBase.getData(str)
}));
};
GetCountriesDataActRec.init();
return GetCountriesDataActRec;
})(OS.Model.DataSourceRecord);

var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("Details", "detailsVar", "Details", true, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEUModel.CompleteDetailsRec());
}, false, ShopperPortalEUModel.CompleteDetailsRec), 
this.attr("InitialDetails", "initialDetailsVar", "InitialDetails", true, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEUModel.CompleteDetailsRec());
}, false, ShopperPortalEUModel.CompleteDetailsRec), 
this.attr("DateOfBirthValidation", "dateOfBirthValidationVar", "DateOfBirthValidation", true, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.DatePickerValidationOptionsRec());
}, false, ShopperPortalEU_UI_ComponentsModel.DatePickerValidationOptionsRec), 
this.attr("CountryOrRegionValidation", "countryOrRegionValidationVar", "CountryOrRegionValidation", true, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValidationOptionsRec());
}, false, ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValidationOptionsRec), 
this.attr("ShowEditableWidgets", "showEditableWidgetsVar", "ShowEditableWidgets", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("IsEntryFlow", "isEntryFlowVar", "IsEntryFlow", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("GetCountries", "getCountriesDataAct", "getCountriesDataAct", true, true, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new GetCountriesDataActRec());
}, true, GetCountriesDataActRec)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {
DetailsForm: OS.Model.ValidationWidgetRecord,
Input_GivenNames: OS.Model.ValidationWidgetRecord,
Input_Surname: OS.Model.ValidationWidgetRecord,
Input_AddressLine1: OS.Model.ValidationWidgetRecord,
Input_AddressLine2: OS.Model.ValidationWidgetRecord,
Input_Postcode: OS.Model.ValidationWidgetRecord,
Input_City: OS.Model.ValidationWidgetRecord,
Input_State: OS.Model.ValidationWidgetRecord,
Input_Email: OS.Model.ValidationWidgetRecord
};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return true;
}
});

Model.prototype.setInputs = function (inputs) {
};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "Profile.CompleteDetails");
});
define("ShopperPortalEU.Profile.CompleteDetails.mvc$view", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.controller", "ShopperPortalEU_UI_Theme.controller", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.controller", "react", "OutSystems/ReactView/Main", "ShopperPortalEU.Profile.CompleteDetails.mvc$model", "ShopperPortalEU.Profile.CompleteDetails.mvc$controller", "ShopperPortalEU.clientVariables", "ShopperPortalEU.Layouts.LayoutDetail.mvc$view", "OutSystems/ReactWidgets/Main", "ShopperPortalEU.LayoutsComponents.Back.mvc$view", "ShopperPortalEU.Common.DataLoading.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomForm.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomColumns.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomInput.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.DatePicker.mvc$view", "ShopperPortalEU.Common.CountryDropdown.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.LabelValue.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.PhoneNumberInput.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomBottomBar.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomButton.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomButtonItem.mvc$view", "ShopperPortalEU.controller$FormatEmptyString", "ShopperPortalEU.controller$FormatDate", "ShopperPortalEU.controller$GetCountryName", "ShopperPortalEU.model$CompleteDetailsRec", "ShopperPortalEU_UI_Components.model$DatePickerValidationOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$CustomDropdownListValidationOptionsRec", "ShopperPortalEU_UI_Theme.model$LayoutDetailOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU_UI_Components.model$CustomFormOptionsRec", "ShopperPortalEU_UI_Components.model$CustomColumnsOptionsRec", "ShopperPortalEU_UI_Components.model$CustomInputOptionsRec", "ShopperPortalEU_UI_Components.model$CustomInputIconOptionRec", "ShopperPortalEU_UI_Components.model$CustomInputValidationOptionsRec", "ShopperPortalEU_UI_Components.model$DatePickerOptionsRec", "ShopperPortalEU_UI_Components.model$DatePickerLabelOptionsRec", "ShopperPortalEU.model$CountriesWithFlagsDropdownListList", "ShopperPortalEU_UI_Components.model$LabelValueOptionsRec", "ShopperPortalEU_UI_Components.model$PhoneNumberInputOptionsRec", "ShopperPortalEU_UI_Components.model$PhoneNumberInputSearchOptionsRec", "ShopperPortalEU_UI_Components.model$CustomBottomBarOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconRec", "ShopperPortalEU_UI_Components.model$PhoneNumberInputChangeOptionsRec", "ShopperPortalEU.controller$PercentageProfileCalculation", "ShopperPortalEU.controller$ShopperCreateOrUpdateDetails", "ShopperPortalEU_UI_Components.controller$ScrollToFirstInvalidField", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", "ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger", "ShopperPortalEU.controller$ClarityEvent", "ShopperPortalEU.controller$FormatTitleCase", "ShopperPortalEU.controller$DefaultErrorMessage", "ShopperPortalEU.controller$CheckOnlyLetters", "ShopperPortalEU.controller$FormatShopperName", "ShopperPortalEU_UI_Components.model$CustomDropdownListValueOptionsRec", "ShopperPortalEU_Shopper_IS.model$GetShopperResponseRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS", "ShopperPortalEU_Shopper_IS.controller$GetShopper", "ShopperPortalEU.controller$ShopperCheckMandatoryFields", "ShopperPortalEU.model$ScanPassportRec", "ShopperPortalEU.model$ApcuesIdentifyRec", "ShopperPortalEU.controller$ApcuesIdentify", "ShopperPortalEU.controller$HeapIdentify"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ComponentsController, ShopperPortalEU_UI_ThemeController, ShopperPortalEU_Shopper_ISModel, ShopperPortalEU_Shopper_ISController, React, OSView, ShopperPortalEU_Profile_CompleteDetails_mvc_model, ShopperPortalEU_Profile_CompleteDetails_mvc_controller, ShopperPortalEUClientVariables, ShopperPortalEU_Layouts_LayoutDetail_mvc_view, OSWidgets, ShopperPortalEU_LayoutsComponents_Back_mvc_view, ShopperPortalEU_Common_DataLoading_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomForm_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomColumns_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomInput_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_DatePicker_mvc_view, ShopperPortalEU_Common_CountryDropdown_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_LabelValue_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_PhoneNumberInput_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomBottomBar_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            var thisIsInstanceOfSuper = this instanceof _super;
            if (thisIsInstanceOfSuper == false) {
                return;
            }

            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "Profile.CompleteDetails";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css", "css/ShopperPortalEU_UI_Theme.ShopperPortalEUUITheme.css", "css/ShopperPortalEU.ShopperPortalEU.css", "css/ShopperPortalEU_UI_Theme.ShopperPortalEUUITheme.extra.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [ShopperPortalEU_Layouts_LayoutDetail_mvc_view, ShopperPortalEU_LayoutsComponents_Back_mvc_view, ShopperPortalEU_Common_DataLoading_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomForm_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomColumns_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomInput_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_DatePicker_mvc_view, ShopperPortalEU_Common_CountryDropdown_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_LabelValue_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_PhoneNumberInput_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomBottomBar_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return ShopperPortalEU_Profile_CompleteDetails_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return ShopperPortalEU_Profile_CompleteDetails_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "Shopper Portal EU - Complete details";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(ShopperPortalEU_Layouts_LayoutDetail_mvc_view, {
inputs: {
Auth: model.getCachedValue(idService.getId("UP67yu0OLEOdo7I1YzetvA.Auth"), function () {
return function () {
var rec = new ShopperPortalEUModel.LayoutAuthenticationRec();
return rec;
}();
}),
Options: model.getCachedValue(idService.getId("UP67yu0OLEOdo7I1YzetvA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ThemeModel.LayoutDetailOptionsRec();
rec.headerStepsAttr = function () {
var rec = new ShopperPortalEU_UI_ThemeModel.HeaderStepsOptionsRec();
rec.stepsAttr = ((model.variables.isEntryFlowVar) ? (4) : (0));
rec.currentStepAttr = ((model.variables.isEntryFlowVar) ? (4) : (0));
return rec;
}();
return rec;
}();
}, function () {
return model.variables.isEntryFlowVar;
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
afterAuthentication$Action: function (isAuthenticatedIn) {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Layouts/LayoutDetail AfterAuthentication");
return controller.onReady$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "0",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
headerLeft: new PlaceholderContent(function () {
return [$if(model.variables.detailsVar.isDataFetchedAttr, false, this, function () {
return [$if(!(model.variables.isEntryFlowVar), false, this, function () {
return [React.createElement(ShopperPortalEU_LayoutsComponents_Back_mvc_view, {
inputs: {
ManualRedirect: true
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onClick$Action: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "LayoutsComponents/Back OnClick");
return controller.onBackClick$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "1",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}, function () {
return [];
})];
}, function () {
return [];
})];
}),
headerCenter: new PlaceholderContent(function () {
return [$if(ShopperPortalEUClientVariables.getIsProfileDetailsNavigation(), false, this, function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "ProfileDetailsTitle"
},
value: "Profile details",
_idProps: {
service: idService,
uuid: "2"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}, function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "CompleteDetailsTitle"
},
value: "Complete details",
_idProps: {
service: idService,
uuid: "3"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})];
}),
headerRight: PlaceholderContent.Empty,
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_Common_DataLoading_mvc_view, {
inputs: {
IsDataFetched: model.variables.detailsVar.isDataFetchedAttr,
HasError: !(model.variables.detailsVar.isSuccessAttr)
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "4",
alias: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [$if((model.variables.showEditableWidgetsVar && ShopperPortalEUClientVariables.getIsProfileDetailsNavigation()), false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "text-primary-black body-1 margin-bottom-06",
visible: true,
_idProps: {
service: idService,
uuid: "5"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "ProfileDetailsDescription",
style: "font-size: 16px;"
},
value: "You can update your information anytime, and it will not affect your ongoing tax-free process.",
_idProps: {
service: idService,
uuid: "6"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
}, function () {
return [];
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomForm_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "7",
alias: "4"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
form: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Form, {
_validationProps: {
validationService: validationService
},
gridProperties: {
classes: "OSFillParent"
},
style: "form",
_idProps: {
service: idService,
name: "DetailsForm"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "9"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "subhead-1 text-primary-35",
visible: true,
_idProps: {
service: idService,
uuid: "10"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "PersonalDetailsHeading"
},
value: "Personal details",
_idProps: {
service: idService,
uuid: "11"
},
_widgetRecordProvider: widgetsRecordProvider
})), $if(!(ShopperPortalEUClientVariables.getIsProfileDetailsNavigation()), false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "text-primary-black body-4 margin-top-01",
visible: true,
_idProps: {
service: idService,
uuid: "12"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "PersonalDetailsDescription"
},
value: "Please enter your personal details as shown on your passport.",
_idProps: {
service: idService,
uuid: "13"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
}, function () {
return [];
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomColumns_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("fxmPSJvvY0SzMHQScIzG5Q.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomColumnsOptionsRec();
rec.columnsAttr = 1;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space4;
return rec;
}();
}),
ExtendedClass: "margin-top-04"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("DetailsForm")
},
_idProps: {
service: idService,
uuid: "14",
alias: "5"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [$if(model.variables.showEditableWidgetsVar, false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomInput_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("yX7k9Kcr4kiRnXVsW8e55g.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomInputOptionsRec();
rec.testIdAttr = "GivenNames";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("DetailsForm")
},
_idProps: {
service: idService,
uuid: "15",
alias: "6"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
label: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
mandatory: true,
targetWidget: "Input_GivenNames",
_idProps: {
service: idService,
uuid: "16"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
value: "Given names",
_idProps: {
service: idService,
uuid: "17"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
}),
input: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Input, {
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("DetailsForm")
},
enabled: true,
gridProperties: {
classes: "OSFillParent"
},
inputType: /*Text*/ 0,
mandatory: true,
maxLength: 0,
onChange: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Profile/CompleteDetails/Input_GivenNames OnChange");
controller.givenNamesOnChange$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "form-control",
variable: model.createVariable(OS.DataTypes.DataTypes.Text, model.variables.detailsVar.personalDetailsAttr.givenNamesAttr, function (value) {
model.variables.detailsVar.personalDetailsAttr.givenNamesAttr = value;
}),
_idProps: {
service: idService,
name: "Input_GivenNames"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
description: PlaceholderContent.Empty
},
_dependencies: [asPrimitiveValue(model.variables.detailsVar.personalDetailsAttr.givenNamesAttr)]
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomInput_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("9Fc7xAIRbE+zSDOo3InDIQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomInputOptionsRec();
rec.testIdAttr = "Surname";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("DetailsForm")
},
_idProps: {
service: idService,
uuid: "19",
alias: "7"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
label: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
mandatory: true,
targetWidget: "Input_Surname",
_idProps: {
service: idService,
uuid: "20"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
value: "Surname",
_idProps: {
service: idService,
uuid: "21"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
}),
input: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Input, {
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("DetailsForm")
},
enabled: true,
gridProperties: {
classes: "OSFillParent"
},
inputType: /*Text*/ 0,
mandatory: true,
maxLength: 0,
onChange: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Profile/CompleteDetails/Input_Surname OnChange");
controller.surnameOnChange$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "form-control",
variable: model.createVariable(OS.DataTypes.DataTypes.Text, model.variables.detailsVar.personalDetailsAttr.surnameAttr, function (value) {
model.variables.detailsVar.personalDetailsAttr.surnameAttr = value;
}),
_idProps: {
service: idService,
name: "Input_Surname"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
description: PlaceholderContent.Empty
},
_dependencies: [asPrimitiveValue(model.variables.detailsVar.personalDetailsAttr.surnameAttr)]
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_DatePicker_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("Y2SPSv1dE0CjkOwYPCBIJA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.DatePickerOptionsRec();
rec.dateAttr = model.variables.detailsVar.personalDetailsAttr.birthDateAttr;
rec.isMandatoryAttr = true;
rec.maxDateAttr = OS.BuiltinFunctions.currDate();
rec.testIdAttr = "DateOfBirth";
rec.validationAttr = model.variables.dateOfBirthValidationVar;
return rec;
}();
}, function () {
return model.variables.detailsVar.personalDetailsAttr.birthDateAttr;
}, function () {
return model.variables.dateOfBirthValidationVar;
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onChange$Action: function (currentDateIn) {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ShopperPortalEUUIComponents/DatePicker OnChange");
controller.birthDateOnChange$Action(currentDateIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("DetailsForm")
},
_idProps: {
service: idService,
uuid: "23",
alias: "8"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
label: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
_idProps: {
service: idService,
uuid: "24"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
value: "Date of birth",
_idProps: {
service: idService,
uuid: "25"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
})
},
_dependencies: []
}), React.createElement(ShopperPortalEU_Common_CountryDropdown_mvc_view, {
inputs: {
List: model.variables.getCountriesDataAct.countriesOut,
_listInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getCountriesDataAct.dataFetchStatusAttr),
OpenedLabel: "Select nationality",
NullValue: "0",
TestId: "Nationality",
HasNullValue: true,
NativeLabel: "Nationality",
Selected: model.variables.detailsVar.personalDetailsAttr.nationalityAttr
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onChange$Action: function (currentCountryIn) {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common/CountryDropdown OnChange");
controller.nationalityOnChange$Action(currentCountryIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("DetailsForm")
},
_idProps: {
service: idService,
uuid: "26",
alias: "9"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
label: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Nationality",
_idProps: {
service: idService,
uuid: "27"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
})];
}, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_LabelValue_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("GivenNames.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.LabelValueOptionsRec();
rec.testIdAttr = "GivenNamesReadOnly";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("DetailsForm")
},
_idProps: {
service: idService,
name: "GivenNames",
alias: "10"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
label: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Given names",
_idProps: {
service: idService,
uuid: "29"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
value: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: model.getCachedValue(idService.getId("iTnwxCcCTE2RAEsSKXBAbQ.Value"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.formatEmptyString$Action(model.variables.detailsVar.personalDetailsAttr.givenNamesAttr, callContext).formattedStringOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
}, function () {
return model.variables.detailsVar.personalDetailsAttr.givenNamesAttr;
}),
_idProps: {
service: idService,
uuid: "30"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.detailsVar.personalDetailsAttr.givenNamesAttr)]
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_LabelValue_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("Surname.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.LabelValueOptionsRec();
rec.testIdAttr = "SurnameReadOnly";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("DetailsForm")
},
_idProps: {
service: idService,
name: "Surname",
alias: "11"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
label: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Surname",
_idProps: {
service: idService,
uuid: "32"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
value: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: model.getCachedValue(idService.getId("FrfNpLcVv0eUEuOG4gCs8Q.Value"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.formatEmptyString$Action(model.variables.detailsVar.personalDetailsAttr.surnameAttr, callContext).formattedStringOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
}, function () {
return model.variables.detailsVar.personalDetailsAttr.surnameAttr;
}),
_idProps: {
service: idService,
uuid: "33"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.detailsVar.personalDetailsAttr.surnameAttr)]
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_LabelValue_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("DateOfBirth.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.LabelValueOptionsRec();
rec.testIdAttr = "DateOfBirthReadOnly";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("DetailsForm")
},
_idProps: {
service: idService,
name: "DateOfBirth",
alias: "12"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
label: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Date of birth",
_idProps: {
service: idService,
uuid: "35"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
value: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: model.getCachedValue(idService.getId("PJW85IK9c029yArTpICrvw.Value"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.formatDate$Action(model.variables.detailsVar.personalDetailsAttr.birthDateAttr, callContext).formattedDateOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
}, function () {
return model.variables.detailsVar.personalDetailsAttr.birthDateAttr;
}),
_idProps: {
service: idService,
uuid: "36"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.detailsVar.personalDetailsAttr.birthDateAttr)]
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_LabelValue_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("Nationality2.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.LabelValueOptionsRec();
rec.testIdAttr = "NationalityReadOnly";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("DetailsForm")
},
_idProps: {
service: idService,
name: "Nationality2",
alias: "13"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
label: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Nationality",
_idProps: {
service: idService,
uuid: "38"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
value: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: model.getCachedValue(idService.getId("T1aoHYClpkOL4zU3EANIRQ.Value"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.formatEmptyString$Action(OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.getCountryName$Action(model.variables.detailsVar.personalDetailsAttr.nationalityAttr, callContext).nameOut;
}, OS.DataTypes.DataTypes.Text, callContext.id), callContext).formattedStringOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
}, function () {
return model.variables.detailsVar.personalDetailsAttr.nationalityAttr;
}),
_idProps: {
service: idService,
uuid: "39"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.detailsVar.personalDetailsAttr.nationalityAttr)]
})];
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.getCountriesDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.getCountriesDataAct.countriesOut), asPrimitiveValue(model.variables.dateOfBirthValidationVar), asPrimitiveValue(model.variables.detailsVar.personalDetailsAttr.nationalityAttr), asPrimitiveValue(model.variables.detailsVar.personalDetailsAttr.birthDateAttr), asPrimitiveValue(model.variables.detailsVar.personalDetailsAttr.surnameAttr), asPrimitiveValue(model.variables.detailsVar.personalDetailsAttr.givenNamesAttr), asPrimitiveValue(model.variables.showEditableWidgetsVar)]
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-top-05",
visible: true,
_idProps: {
service: idService,
uuid: "40"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "PermanentAddressHeading"
},
style: "subhead-1 text-primary-35",
value: "Permanent address of residence",
_idProps: {
service: idService,
uuid: "41"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomColumns_mvc_view, {
inputs: {
ExtendedClass: "margin-top-04",
Options: model.getCachedValue(idService.getId("gdHcADXNSk6nsrzrNftf_w.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomColumnsOptionsRec();
rec.columnsAttr = 1;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space4;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("DetailsForm")
},
_idProps: {
service: idService,
uuid: "42",
alias: "14"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [$if(model.variables.showEditableWidgetsVar, false, this, function () {
return [React.createElement(ShopperPortalEU_Common_CountryDropdown_mvc_view, {
inputs: {
HasNullValue: true,
OpenedLabel: "Select country or region",
Validation: model.variables.countryOrRegionValidationVar,
TestId: "CountryOrRegion",
NativeLabel: "Country or region",
IsMandatory: true,
Selected: model.variables.detailsVar.addressAttr.countryAttr,
NullValue: "0",
List: model.variables.getCountriesDataAct.countriesOut,
_listInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getCountriesDataAct.dataFetchStatusAttr)
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onChange$Action: function (currentCountryIn) {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common/CountryDropdown OnChange");
controller.countryOnChange$Action(currentCountryIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("DetailsForm")
},
_idProps: {
service: idService,
uuid: "43",
alias: "15"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
label: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Country or region",
_idProps: {
service: idService,
uuid: "44"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomInput_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("4W1_PbFfQ0m44n85IdsgTA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomInputOptionsRec();
rec.testIdAttr = "AddressLine1";
rec.hasMaxLengthCounterAttr = true;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("DetailsForm")
},
_idProps: {
service: idService,
uuid: "45",
alias: "16"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
label: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
mandatory: false,
targetWidget: "Input_AddressLine1",
_idProps: {
service: idService,
uuid: "46"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
value: "Address line 1",
_idProps: {
service: idService,
uuid: "47"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
}),
input: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Input, {
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("DetailsForm")
},
enabled: true,
gridProperties: {
classes: "OSFillParent"
},
inputType: /*Text*/ 0,
mandatory: false,
maxLength: 100,
prompt: "Street number, street name",
style: "form-control",
variable: model.createVariable(OS.DataTypes.DataTypes.Text, model.variables.detailsVar.addressAttr.addressLine1Attr, function (value) {
model.variables.detailsVar.addressAttr.addressLine1Attr = value;
}),
_idProps: {
service: idService,
name: "Input_AddressLine1"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
description: PlaceholderContent.Empty
},
_dependencies: [asPrimitiveValue(model.variables.detailsVar.addressAttr.addressLine1Attr)]
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomInput_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("Htki2GOvakqTaAGQKqtbkQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomInputOptionsRec();
rec.testIdAttr = "AddressLine2";
rec.hasMaxLengthCounterAttr = true;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("DetailsForm")
},
_idProps: {
service: idService,
uuid: "49",
alias: "17"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
label: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
mandatory: false,
targetWidget: "Input_AddressLine2",
_idProps: {
service: idService,
uuid: "50"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
value: "Address line 2",
_idProps: {
service: idService,
uuid: "51"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
}),
input: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Input, {
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("DetailsForm")
},
enabled: true,
gridProperties: {
classes: "OSFillParent"
},
inputType: /*Text*/ 0,
mandatory: false,
maxLength: 100,
prompt: "Apartment number, suite number, etc.",
style: "form-control",
variable: model.createVariable(OS.DataTypes.DataTypes.Text, model.variables.detailsVar.addressAttr.addressLine2Attr, function (value) {
model.variables.detailsVar.addressAttr.addressLine2Attr = value;
}),
_idProps: {
service: idService,
name: "Input_AddressLine2"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
description: PlaceholderContent.Empty
},
_dependencies: [asPrimitiveValue(model.variables.detailsVar.addressAttr.addressLine2Attr)]
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomColumns_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("kmFmEMXQiUuZUl0UhBjJMA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomColumnsOptionsRec();
rec.columnsAttr = 2;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space5;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("DetailsForm")
},
_idProps: {
service: idService,
uuid: "53",
alias: "18"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomInput_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("zh+NwrB0sUSEV1dFCbeT2w.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomInputOptionsRec();
rec.testIdAttr = "Postcode";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("DetailsForm")
},
_idProps: {
service: idService,
uuid: "54",
alias: "19"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
label: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
mandatory: false,
targetWidget: "Input_Postcode",
_idProps: {
service: idService,
uuid: "55"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
value: "Postcode",
_idProps: {
service: idService,
uuid: "56"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
}),
input: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Input, {
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("DetailsForm")
},
enabled: true,
gridProperties: {
classes: "OSFillParent"
},
inputType: /*Text*/ 0,
mandatory: false,
maxLength: 0,
style: "form-control",
variable: model.createVariable(OS.DataTypes.DataTypes.Text, model.variables.detailsVar.addressAttr.postcodeAttr, function (value) {
model.variables.detailsVar.addressAttr.postcodeAttr = value;
}),
_idProps: {
service: idService,
name: "Input_Postcode"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
description: PlaceholderContent.Empty
},
_dependencies: [asPrimitiveValue(model.variables.detailsVar.addressAttr.postcodeAttr)]
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomInput_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("T9qkx_IWVEuTyxbQdbStTg.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomInputOptionsRec();
rec.testIdAttr = "City";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("DetailsForm")
},
_idProps: {
service: idService,
uuid: "58",
alias: "20"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
label: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
mandatory: false,
targetWidget: "Input_City",
_idProps: {
service: idService,
uuid: "59"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
value: "City",
_idProps: {
service: idService,
uuid: "60"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
}),
input: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Input, {
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("DetailsForm")
},
enabled: true,
gridProperties: {
classes: "OSFillParent"
},
inputType: /*Text*/ 0,
mandatory: false,
maxLength: 0,
style: "form-control",
variable: model.createVariable(OS.DataTypes.DataTypes.Text, model.variables.detailsVar.addressAttr.cityAttr, function (value) {
model.variables.detailsVar.addressAttr.cityAttr = value;
}),
_idProps: {
service: idService,
name: "Input_City"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
description: PlaceholderContent.Empty
},
_dependencies: [asPrimitiveValue(model.variables.detailsVar.addressAttr.cityAttr)]
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.detailsVar.addressAttr.cityAttr), asPrimitiveValue(model.variables.detailsVar.addressAttr.postcodeAttr)]
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomInput_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("mBe2WOmRpkiVUHkLv1uYbg.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomInputOptionsRec();
rec.testIdAttr = "StateOrProvince";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("DetailsForm")
},
_idProps: {
service: idService,
uuid: "62",
alias: "21"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
label: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
mandatory: false,
targetWidget: "Input_State",
_idProps: {
service: idService,
uuid: "63"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
value: "State or province",
_idProps: {
service: idService,
uuid: "64"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
}),
input: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Input, {
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("DetailsForm")
},
enabled: true,
gridProperties: {
classes: "OSFillParent"
},
inputType: /*Text*/ 0,
mandatory: false,
maxLength: 0,
style: "form-control",
variable: model.createVariable(OS.DataTypes.DataTypes.Text, model.variables.detailsVar.addressAttr.stateAttr, function (value) {
model.variables.detailsVar.addressAttr.stateAttr = value;
}),
_idProps: {
service: idService,
name: "Input_State"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
description: PlaceholderContent.Empty
},
_dependencies: [asPrimitiveValue(model.variables.detailsVar.addressAttr.stateAttr)]
})];
}, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_LabelValue_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("AddressCountry2.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.LabelValueOptionsRec();
rec.testIdAttr = "GivenNamesReadOnly";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("DetailsForm")
},
_idProps: {
service: idService,
name: "AddressCountry2",
alias: "22"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
label: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Country or region",
_idProps: {
service: idService,
uuid: "67"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
value: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: model.getCachedValue(idService.getId("tY3pci3mYkmcc2Lw0zUjdg.Value"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.formatEmptyString$Action(OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.getCountryName$Action(model.variables.detailsVar.addressAttr.countryAttr, callContext).nameOut;
}, OS.DataTypes.DataTypes.Text, callContext.id), callContext).formattedStringOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
}, function () {
return model.variables.detailsVar.addressAttr.countryAttr;
}),
_idProps: {
service: idService,
uuid: "68"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.detailsVar.addressAttr.countryAttr)]
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_LabelValue_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("Address1.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.LabelValueOptionsRec();
rec.testIdAttr = "Address1ReadOnly";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("DetailsForm")
},
_idProps: {
service: idService,
name: "Address1",
alias: "23"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
label: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Address line 1",
_idProps: {
service: idService,
uuid: "70"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
value: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: model.getCachedValue(idService.getId("_3SE0PYrZkeQXQhilrXQwA.Value"), function () {
return ((((model.variables.detailsVar.addressAttr.addressLine1Attr) !== (""))) ? (model.variables.detailsVar.addressAttr.addressLine1Attr) : ("—"));
}, function () {
return model.variables.detailsVar.addressAttr.addressLine1Attr;
}),
_idProps: {
service: idService,
uuid: "71"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.detailsVar.addressAttr.addressLine1Attr)]
}), $if(((model.variables.detailsVar.addressAttr.addressLine2Attr) !== ("")), false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_LabelValue_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("Address2.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.LabelValueOptionsRec();
rec.testIdAttr = "Address2ReadOnly";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("DetailsForm")
},
_idProps: {
service: idService,
name: "Address2",
alias: "24"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
label: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Address line 2",
_idProps: {
service: idService,
uuid: "73"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
value: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: model.variables.detailsVar.addressAttr.addressLine2Attr,
_idProps: {
service: idService,
uuid: "74"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.detailsVar.addressAttr.addressLine2Attr)]
})];
}, function () {
return [];
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomColumns_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("b72gr8hxVE+LEBcfc3I7QQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomColumnsOptionsRec();
rec.columnsAttr = 2;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space5;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("DetailsForm")
},
_idProps: {
service: idService,
uuid: "75",
alias: "25"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_LabelValue_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("Postcode.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.LabelValueOptionsRec();
rec.testIdAttr = "PostCodeReadOnly";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("DetailsForm")
},
_idProps: {
service: idService,
name: "Postcode",
alias: "26"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
label: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Postcode",
_idProps: {
service: idService,
uuid: "77"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
value: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: model.getCachedValue(idService.getId("gQ5_VytiJkqNEfJQS4uDFw.Value"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.formatEmptyString$Action(model.variables.detailsVar.addressAttr.postcodeAttr, callContext).formattedStringOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
}, function () {
return model.variables.detailsVar.addressAttr.postcodeAttr;
}),
_idProps: {
service: idService,
uuid: "78"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.detailsVar.addressAttr.postcodeAttr)]
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_LabelValue_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("City.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.LabelValueOptionsRec();
rec.testIdAttr = "CityReadOnly";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("DetailsForm")
},
_idProps: {
service: idService,
name: "City",
alias: "27"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
label: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "City",
_idProps: {
service: idService,
uuid: "80"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
value: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: model.getCachedValue(idService.getId("izcuOp_WC06F1zyVJ49ygg.Value"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.formatEmptyString$Action(model.variables.detailsVar.addressAttr.cityAttr, callContext).formattedStringOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
}, function () {
return model.variables.detailsVar.addressAttr.cityAttr;
}),
_idProps: {
service: idService,
uuid: "81"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.detailsVar.addressAttr.cityAttr)]
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.detailsVar.addressAttr.cityAttr), asPrimitiveValue(model.variables.detailsVar.addressAttr.postcodeAttr)]
})];
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.getCountriesDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.getCountriesDataAct.countriesOut), asPrimitiveValue(model.variables.detailsVar.addressAttr.stateAttr), asPrimitiveValue(model.variables.detailsVar.addressAttr.cityAttr), asPrimitiveValue(model.variables.detailsVar.addressAttr.postcodeAttr), asPrimitiveValue(model.variables.detailsVar.addressAttr.addressLine2Attr), asPrimitiveValue(model.variables.detailsVar.addressAttr.addressLine1Attr), asPrimitiveValue(model.variables.detailsVar.addressAttr.countryAttr), asPrimitiveValue(model.variables.countryOrRegionValidationVar), asPrimitiveValue(model.variables.showEditableWidgetsVar)]
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-top-07",
visible: true,
_idProps: {
service: idService,
uuid: "82"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "subhead-1 text-primary-35",
visible: true,
_idProps: {
service: idService,
uuid: "83"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "ContactDetailsHeading"
},
value: "Contact details",
_idProps: {
service: idService,
uuid: "84"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomColumns_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("yn6NXoBZTUKwHD3aNkdIOQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomColumnsOptionsRec();
rec.columnsAttr = 1;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space4;
return rec;
}();
}),
ExtendedClass: "margin-top-04"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("DetailsForm")
},
_idProps: {
service: idService,
uuid: "85",
alias: "28"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomInput_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("1cCnkE5Ez0GXZtyUfFexTg.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomInputOptionsRec();
rec.testIdAttr = "Email";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("DetailsForm")
},
_idProps: {
service: idService,
uuid: "86",
alias: "29"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
label: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
mandatory: false,
targetWidget: "Input_Email",
_idProps: {
service: idService,
uuid: "87"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
value: "Email",
_idProps: {
service: idService,
uuid: "88"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
}),
input: new PlaceholderContent(function () {
return [$if((((model.variables.initialDetailsVar.contactAttr.emailAttr) !== ("")) || !(model.variables.showEditableWidgetsVar)), false, this, function () {
return [React.createElement(OSWidgets.Expression, {
value: model.getCachedValue(idService.getId("Email.Value"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.formatEmptyString$Action(model.variables.detailsVar.contactAttr.emailAttr, callContext).formattedStringOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
}, function () {
return model.variables.detailsVar.contactAttr.emailAttr;
}),
_idProps: {
service: idService,
name: "Email"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}, function () {
return [React.createElement(OSWidgets.Input, {
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("DetailsForm")
},
enabled: true,
gridProperties: {
classes: "OSFillParent"
},
inputType: /*Email*/ 7,
mandatory: false,
maxLength: 0,
style: "form-control",
variable: model.createVariable(OS.DataTypes.DataTypes.Email, model.variables.detailsVar.contactAttr.emailAttr, function (value) {
model.variables.detailsVar.contactAttr.emailAttr = value;
}),
_idProps: {
service: idService,
name: "Input_Email"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})];
}),
description: PlaceholderContent.Empty
},
_dependencies: [asPrimitiveValue(model.variables.detailsVar.contactAttr.emailAttr), asPrimitiveValue(model.variables.showEditableWidgetsVar), asPrimitiveValue(model.variables.initialDetailsVar.contactAttr.emailAttr)]
}), $if((((model.variables.initialDetailsVar.contactAttr.mobileNumberAttr) !== ("")) || !(model.variables.showEditableWidgetsVar)), false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_LabelValue_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("MobileNumber2.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.LabelValueOptionsRec();
rec.testIdAttr = "MobileNumberReadOnly";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("DetailsForm")
},
_idProps: {
service: idService,
name: "MobileNumber2",
alias: "30"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
label: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Mobile number",
_idProps: {
service: idService,
uuid: "92"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
value: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: model.getCachedValue(idService.getId("MobileNumber.Value"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.formatEmptyString$Action(model.variables.detailsVar.contactAttr.mobileNumberAttr, callContext).formattedStringOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
}, function () {
return model.variables.detailsVar.contactAttr.mobileNumberAttr;
}),
_idProps: {
service: idService,
name: "MobileNumber"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.detailsVar.contactAttr.mobileNumberAttr)]
})];
}, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_PhoneNumberInput_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("2w_vvlY1AkSv738NjYoKug.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputOptionsRec();
rec.testIdAttr = "MobileNumber";
rec.phoneNumberAttr = model.variables.detailsVar.contactAttr.mobileNumberAttr;
rec.labelAttr = "Mobile number";
rec.isReadOnlyAttr = (((model.variables.initialDetailsVar.contactAttr.mobileNumberAttr) !== ("")) || !(model.variables.showEditableWidgetsVar));
return rec;
}();
}, function () {
return model.variables.detailsVar.contactAttr.mobileNumberAttr;
}, function () {
return model.variables.initialDetailsVar.contactAttr.mobileNumberAttr;
}, function () {
return model.variables.showEditableWidgetsVar;
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onChange$Action: function (dataIn) {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ShopperPortalEUUIComponents/PhoneNumberInput OnChange");
controller.mobileNumberOnChange$Action(dataIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("DetailsForm")
},
_idProps: {
service: idService,
uuid: "94",
alias: "31"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.detailsVar.contactAttr.mobileNumberAttr), asPrimitiveValue(model.variables.detailsVar.contactAttr.emailAttr), asPrimitiveValue(model.variables.showEditableWidgetsVar), asPrimitiveValue(model.variables.initialDetailsVar.contactAttr.mobileNumberAttr), asPrimitiveValue(model.variables.initialDetailsVar.contactAttr.emailAttr)]
})), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomBottomBar_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("DetailsForm")
},
_idProps: {
service: idService,
uuid: "95",
alias: "32"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [$if(model.variables.showEditableWidgetsVar, false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("8soIBgGcik+Jc+Cm9Iecrg.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRec();
rec.testIdAttr = "SaveButton";
rec.typeAttr = ShopperPortalEUModel.staticEntities.customButtonType.primary;
rec.isLoadingAttr = model.variables.detailsVar.isSavingAttr;
rec.isFullWidthAttr = true;
return rec;
}();
}, function () {
return model.variables.detailsVar.isSavingAttr;
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("DetailsForm")
},
_idProps: {
service: idService,
uuid: "96",
alias: "33"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
button: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: true,
onClick: function () {
_this.validateWidget(idService.getId("DetailsForm"));
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Profile/CompleteDetails/Button OnClick");
return controller.save$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});

;
},
style: "btn",
visible: true,
_idProps: {
service: idService,
uuid: "97"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("DetailsForm")
},
_idProps: {
service: idService,
uuid: "98",
alias: "34"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Save",
_idProps: {
service: idService,
uuid: "99"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
})];
}, function () {
return [$if(ShopperPortalEUClientVariables.getIsProfileDetailsNavigation(), false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("bCCFEpYQZUiW8BZRsAHS0w.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRec();
rec.testIdAttr = "EditButton";
rec.typeAttr = ShopperPortalEUModel.staticEntities.customButtonType.primary;
rec.isFullWidthAttr = true;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("DetailsForm")
},
_idProps: {
service: idService,
uuid: "100",
alias: "35"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
button: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: false,
onClick: function () {
_this.validateWidget(idService.getId("DetailsForm"));
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Profile/CompleteDetails/Button OnClick");
controller.onEdit$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});


;
},
style: "btn",
visible: true,
_idProps: {
service: idService,
uuid: "101"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("DetailsForm")
},
_idProps: {
service: idService,
uuid: "102",
alias: "36"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Edit",
_idProps: {
service: idService,
uuid: "103"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
})];
}, function () {
return [];
})];
})];
})
},
_dependencies: [asPrimitiveValue(ShopperPortalEUClientVariables.getIsProfileDetailsNavigation()), asPrimitiveValue(model.variables.detailsVar.isSavingAttr), asPrimitiveValue(model.variables.showEditableWidgetsVar)]
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables.initialDetailsVar.contactAttr.mobileNumberAttr), asPrimitiveValue(model.variables.initialDetailsVar.contactAttr.emailAttr), asPrimitiveValue(model.variables.countryOrRegionValidationVar), asPrimitiveValue(model.variables.getCountriesDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.getCountriesDataAct.countriesOut), asPrimitiveValue(model.variables.dateOfBirthValidationVar), asPrimitiveValue(model.variables.detailsVar.isSavingAttr), asPrimitiveValue(model.variables.detailsVar.contactAttr.mobileNumberAttr), asPrimitiveValue(model.variables.detailsVar.contactAttr.emailAttr), asPrimitiveValue(model.variables.detailsVar.addressAttr.stateAttr), asPrimitiveValue(model.variables.detailsVar.addressAttr.cityAttr), asPrimitiveValue(model.variables.detailsVar.addressAttr.postcodeAttr), asPrimitiveValue(model.variables.detailsVar.addressAttr.addressLine2Attr), asPrimitiveValue(model.variables.detailsVar.addressAttr.addressLine1Attr), asPrimitiveValue(model.variables.detailsVar.addressAttr.countryAttr), asPrimitiveValue(model.variables.detailsVar.personalDetailsAttr.nationalityAttr), asPrimitiveValue(model.variables.detailsVar.personalDetailsAttr.birthDateAttr), asPrimitiveValue(model.variables.detailsVar.personalDetailsAttr.surnameAttr), asPrimitiveValue(model.variables.detailsVar.personalDetailsAttr.givenNamesAttr), asPrimitiveValue(model.variables.showEditableWidgetsVar), asPrimitiveValue(ShopperPortalEUClientVariables.getIsProfileDetailsNavigation())]
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.initialDetailsVar.contactAttr.mobileNumberAttr), asPrimitiveValue(model.variables.initialDetailsVar.contactAttr.emailAttr), asPrimitiveValue(model.variables.countryOrRegionValidationVar), asPrimitiveValue(model.variables.getCountriesDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.getCountriesDataAct.countriesOut), asPrimitiveValue(model.variables.dateOfBirthValidationVar), asPrimitiveValue(model.variables.detailsVar.isSavingAttr), asPrimitiveValue(model.variables.detailsVar.contactAttr.mobileNumberAttr), asPrimitiveValue(model.variables.detailsVar.contactAttr.emailAttr), asPrimitiveValue(model.variables.detailsVar.addressAttr.stateAttr), asPrimitiveValue(model.variables.detailsVar.addressAttr.cityAttr), asPrimitiveValue(model.variables.detailsVar.addressAttr.postcodeAttr), asPrimitiveValue(model.variables.detailsVar.addressAttr.addressLine2Attr), asPrimitiveValue(model.variables.detailsVar.addressAttr.addressLine1Attr), asPrimitiveValue(model.variables.detailsVar.addressAttr.countryAttr), asPrimitiveValue(model.variables.detailsVar.personalDetailsAttr.nationalityAttr), asPrimitiveValue(model.variables.detailsVar.personalDetailsAttr.birthDateAttr), asPrimitiveValue(model.variables.detailsVar.personalDetailsAttr.surnameAttr), asPrimitiveValue(model.variables.detailsVar.personalDetailsAttr.givenNamesAttr), asPrimitiveValue(ShopperPortalEUClientVariables.getIsProfileDetailsNavigation()), asPrimitiveValue(model.variables.showEditableWidgetsVar)]
})];
}),
bottom: PlaceholderContent.Empty
},
_dependencies: [asPrimitiveValue(model.variables.initialDetailsVar.contactAttr.mobileNumberAttr), asPrimitiveValue(model.variables.initialDetailsVar.contactAttr.emailAttr), asPrimitiveValue(model.variables.countryOrRegionValidationVar), asPrimitiveValue(model.variables.getCountriesDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.getCountriesDataAct.countriesOut), asPrimitiveValue(model.variables.dateOfBirthValidationVar), asPrimitiveValue(model.variables.showEditableWidgetsVar), asPrimitiveValue(ShopperPortalEUClientVariables.getIsProfileDetailsNavigation()), asPrimitiveValue(model.variables.isEntryFlowVar), asPrimitiveValue(model.variables.detailsVar.isSavingAttr), asPrimitiveValue(model.variables.detailsVar.contactAttr.mobileNumberAttr), asPrimitiveValue(model.variables.detailsVar.contactAttr.emailAttr), asPrimitiveValue(model.variables.detailsVar.addressAttr.stateAttr), asPrimitiveValue(model.variables.detailsVar.addressAttr.cityAttr), asPrimitiveValue(model.variables.detailsVar.addressAttr.postcodeAttr), asPrimitiveValue(model.variables.detailsVar.addressAttr.addressLine2Attr), asPrimitiveValue(model.variables.detailsVar.addressAttr.addressLine1Attr), asPrimitiveValue(model.variables.detailsVar.addressAttr.countryAttr), asPrimitiveValue(model.variables.detailsVar.personalDetailsAttr.nationalityAttr), asPrimitiveValue(model.variables.detailsVar.personalDetailsAttr.birthDateAttr), asPrimitiveValue(model.variables.detailsVar.personalDetailsAttr.surnameAttr), asPrimitiveValue(model.variables.detailsVar.personalDetailsAttr.givenNamesAttr), asPrimitiveValue(model.variables.detailsVar.isSuccessAttr), asPrimitiveValue(model.variables.detailsVar.isDataFetchedAttr)]
}));
        };
        return View;
    })(OSView.BaseView.BaseWebScreen);
	
    return View;
});
define("ShopperPortalEU.Profile.CompleteDetails.mvc$controller", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.controller", "ShopperPortalEU_UI_Theme.controller", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_Shopper_IS.controller", "ShopperPortalEU.languageResources", "ShopperPortalEU.clientVariables", "ShopperPortalEU.Profile.CompleteDetails.mvc$debugger", "ShopperPortalEU.Profile.controller", "ShopperPortalEU.controller$FormatEmptyString", "ShopperPortalEU.controller$FormatDate", "ShopperPortalEU.controller$GetCountryName", "ShopperPortalEU.model$CompleteDetailsRec", "ShopperPortalEU_UI_Components.model$DatePickerValidationOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$CustomDropdownListValidationOptionsRec", "ShopperPortalEU_UI_Theme.model$LayoutDetailOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU_UI_Components.model$CustomFormOptionsRec", "ShopperPortalEU_UI_Components.model$CustomColumnsOptionsRec", "ShopperPortalEU_UI_Components.model$CustomInputOptionsRec", "ShopperPortalEU_UI_Components.model$CustomInputIconOptionRec", "ShopperPortalEU_UI_Components.model$CustomInputValidationOptionsRec", "ShopperPortalEU_UI_Components.model$DatePickerOptionsRec", "ShopperPortalEU_UI_Components.model$DatePickerLabelOptionsRec", "ShopperPortalEU.model$CountriesWithFlagsDropdownListList", "ShopperPortalEU_UI_Components.model$LabelValueOptionsRec", "ShopperPortalEU_UI_Components.model$PhoneNumberInputOptionsRec", "ShopperPortalEU_UI_Components.model$PhoneNumberInputSearchOptionsRec", "ShopperPortalEU_UI_Components.model$CustomBottomBarOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconRec", "ShopperPortalEU_UI_Components.model$PhoneNumberInputChangeOptionsRec", "ShopperPortalEU.controller$PercentageProfileCalculation", "ShopperPortalEU.controller$ShopperCreateOrUpdateDetails", "ShopperPortalEU_UI_Components.controller$ScrollToFirstInvalidField", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", "ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger", "ShopperPortalEU.controller$ClarityEvent", "ShopperPortalEU.controller$FormatTitleCase", "ShopperPortalEU.controller$DefaultErrorMessage", "ShopperPortalEU.controller$CheckOnlyLetters", "ShopperPortalEU.controller$FormatShopperName", "ShopperPortalEU_UI_Components.model$CustomDropdownListValueOptionsRec", "ShopperPortalEU_Shopper_IS.model$GetShopperResponseRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS", "ShopperPortalEU_Shopper_IS.controller$GetShopper", "ShopperPortalEU.controller$ShopperCheckMandatoryFields", "ShopperPortalEU.model$ScanPassportRec", "ShopperPortalEU.model$ApcuesIdentifyRec", "ShopperPortalEU.controller$ApcuesIdentify", "ShopperPortalEU.controller$HeapIdentify"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ComponentsController, ShopperPortalEU_UI_ThemeController, ShopperPortalEU_Shopper_ISModel, ShopperPortalEU_Shopper_ISController, ShopperPortalEULanguageResources, ShopperPortalEUClientVariables, ShopperPortalEU_Profile_CompleteDetails_mvc_Debugger, ShopperPortalEU_ProfileController) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {
getCountries$DataActRefresh: 0
};
this.dataFetchDependentsGraph = {
getCountries$DataActRefresh: []
};
this.shouldSendClientVarsToDataSources = true;
}
// Server Actions

// Aggregates and Data Actions
Controller.prototype.getCountries$DataActRefresh = function (callContext) {
var model = this.model;
var controller = this.controller;
var callContext = controller.callContext(callContext);
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:Ci_n0dUeiUGG5hpVh4jkWw:/NRWebFlows.G6g8LlI0+UqpwXA+JmvtFg/NodesShownInESpaceTree.rWRZhI99HUesTaH+0J0+RQ/DataActions.Ci_n0dUeiUGG5hpVh4jkWw:9KpPB2PK+w+kBRe5tvUeqQ", "ShopperPortalEU", "GetCountries", "NRFlows.DataScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.setThreadStartName(callContext.id, "Profile/CompleteDetails/GetCountries");
return controller.callDataAction("DataActionGetCountries", "screenservices/ShopperPortalEU/Profile/CompleteDetails/DataActionGetCountries", "lI6MlJj7XlNy9+blzqKzeA", function (b) {
model.variables.getCountriesDataAct.dataFetchStatusAttr = b;
}, function (json) {
model.variables.getCountriesDataAct.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getCountriesDataAct.constructor));
}, undefined, OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, callContext, ShopperPortalEUClientVariables, false);

}, function () {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:Ci_n0dUeiUGG5hpVh4jkWw", callContext.id);
controller.popDebuggerContext(callContext);

});
};

Controller.prototype.dataFetchActionNames = ["getCountries$DataActRefresh"];
// Client Actions
Controller.prototype._birthDateOnChange$Action = function (currentDateIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("BirthDateOnChange");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.Profile.CompleteDetails.BirthDateOnChange$vars"))());
vars.value.currentDateInLocal = currentDateIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:jGsHDM+O9kyLKAywENPqlQ:/NRWebFlows.G6g8LlI0+UqpwXA+JmvtFg/NodesShownInESpaceTree.rWRZhI99HUesTaH+0J0+RQ/ClientActions.jGsHDM+O9kyLKAywENPqlQ:UjNn4FMDzcQm2EG_HYA+qA", "ShopperPortalEU", "BirthDateOnChange", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:BkN6Jky__UiXomFeMbMDDA", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:x9bXikCJGECgHojUwDrYaA", callContext.id);
// Details.PersonalDetails.BirthDate = CurrentDate
model.variables.detailsVar.personalDetailsAttr.birthDateAttr = vars.value.currentDateInLocal;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:x9bXikCJGECgHojUwDrYaA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// DateOfBirthValidation.State = NullTextIdentifier
model.variables.dateOfBirthValidationVar.stateAttr = OS.BuiltinFunctions.nullTextIdentifier();
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:x9bXikCJGECgHojUwDrYaA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// DateOfBirthValidation.Message = ""
model.variables.dateOfBirthValidationVar.messageAttr = "";
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ba6wOsJVnEqerHmo8bTRfg", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:jGsHDM+O9kyLKAywENPqlQ", callContext.id);
}

};
Controller.registerVariableGroupType("ShopperPortalEU.Profile.CompleteDetails.BirthDateOnChange$vars", [{
name: "CurrentDate",
attrName: "currentDateInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Date,
defaultValue: function () {
return OS.DataTypes.DateTime.defaultValue;
}
}]);
Controller.prototype._mobileNumberOnChange$Action = function (dataIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("MobileNumberOnChange");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.Profile.CompleteDetails.MobileNumberOnChange$vars"))());
vars.value.dataInLocal = dataIn.clone();
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:FfSiIm+090iDyB1W8tsj_A:/NRWebFlows.G6g8LlI0+UqpwXA+JmvtFg/NodesShownInESpaceTree.rWRZhI99HUesTaH+0J0+RQ/ClientActions.FfSiIm+090iDyB1W8tsj_A:NXHkV9sZa0YRUbrfITeU9Q", "ShopperPortalEU", "MobileNumberOnChange", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:iH51ZTe980yeoREH0VOqRQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:f16xxlhJZEeB5CEcDifyQA", callContext.id);
// Details.Contact.MobileNumber = Data.PhoneNumber
model.variables.detailsVar.contactAttr.mobileNumberAttr = vars.value.dataInLocal.phoneNumberAttr;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:8xB1tgnHJE+EgHzav8PBKg", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:FfSiIm+090iDyB1W8tsj_A", callContext.id);
}

};
Controller.registerVariableGroupType("ShopperPortalEU.Profile.CompleteDetails.MobileNumberOnChange$vars", [{
name: "Data",
attrName: "dataInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Record,
defaultValue: function () {
return new ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputChangeOptionsRec();
},
complexType: ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputChangeOptionsRec
}]);
Controller.prototype._save$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Save");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.Profile.CompleteDetails.Save$vars"))());
var allExceptionsVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.ErrorHandlerOutputType());
var percentageProfileCalculationVar = new OS.DataTypes.VariableHolder();
var shopperUpdateDetailsVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.vars = vars;
varBag.allExceptionsVar = allExceptionsVar;
varBag.percentageProfileCalculationVar = percentageProfileCalculationVar;
varBag.shopperUpdateDetailsVar = shopperUpdateDetailsVar;
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:jqR5JegRqkqYEe_ZE2zbOA:/NRWebFlows.G6g8LlI0+UqpwXA+JmvtFg/NodesShownInESpaceTree.rWRZhI99HUesTaH+0J0+RQ/ClientActions.jqR5JegRqkqYEe_ZE2zbOA:oYyJTCkjqKNOKdn_nE11eg", "ShopperPortalEU", "Save", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:lDcEekDKckSkvK+5DcLnXg", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:VqSXTdbVIEKNPUpAnBpA7A", callContext.id);
// IsValid = True
vars.value.isValidVar = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:VqSXTdbVIEKNPUpAnBpA7A", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Details.PersonalDetails.Passport = Trim
model.variables.detailsVar.personalDetailsAttr.passportAttr = OS.BuiltinFunctions.trim(model.variables.detailsVar.personalDetailsAttr.passportAttr);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:VqSXTdbVIEKNPUpAnBpA7A", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// Details.PersonalDetails.GivenNames = Trim
model.variables.detailsVar.personalDetailsAttr.givenNamesAttr = OS.BuiltinFunctions.trim(model.variables.detailsVar.personalDetailsAttr.givenNamesAttr);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:VqSXTdbVIEKNPUpAnBpA7A", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// Details.PersonalDetails.Surname = Trim
model.variables.detailsVar.personalDetailsAttr.surnameAttr = OS.BuiltinFunctions.trim(model.variables.detailsVar.personalDetailsAttr.surnameAttr);
// Has given names
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:DO5a4AqD7kib658uQmAlsg", callContext.id) && ((model.variables.detailsVar.personalDetailsAttr.givenNamesAttr) !== ("")))) {
// Invalid given names
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:kCka_AQqoEa16atKogqJ0Q", callContext.id) && !(OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.checkOnlyLetters$Action(model.variables.detailsVar.personalDetailsAttr.givenNamesAttr, callContext).isValidOut;
}, OS.DataTypes.DataTypes.Boolean, callContext.id)))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:dwRQO9+kP0qclWtgMeY3PQ", callContext.id);
// Input_GivenNames.Valid = False
model.widgets.get(idService.getId("Input_GivenNames")).validAttr = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:dwRQO9+kP0qclWtgMeY3PQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Input_GivenNames.ValidationMessage = "Use only letters"
model.widgets.get(idService.getId("Input_GivenNames")).validationMessageAttr = "Use only letters";
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:dwRQO9+kP0qclWtgMeY3PQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// IsValid = False
vars.value.isValidVar = false;
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:3qEP_qz_4kWw_XOKNXSzDg", callContext.id);
// Input_GivenNames.Valid = True
model.widgets.get(idService.getId("Input_GivenNames")).validAttr = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:3qEP_qz_4kWw_XOKNXSzDg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Input_GivenNames.ValidationMessage = ""
model.widgets.get(idService.getId("Input_GivenNames")).validationMessageAttr = "";
}

}

// Has surname
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:isvaWU_pfEKg9GOFdhl4Aw", callContext.id) && ((model.variables.detailsVar.personalDetailsAttr.surnameAttr) !== ("")))) {
// Invalid surname
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:WthLkn7n6k+Weqjo42oa_A", callContext.id) && !(OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.checkOnlyLetters$Action(model.variables.detailsVar.personalDetailsAttr.surnameAttr, callContext).isValidOut;
}, OS.DataTypes.DataTypes.Boolean, callContext.id)))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:oafFApz400SqFUZbjhOarA", callContext.id);
// Input_Surname.Valid = False
model.widgets.get(idService.getId("Input_Surname")).validAttr = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:oafFApz400SqFUZbjhOarA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Input_Surname.ValidationMessage = "Use only letters"
model.widgets.get(idService.getId("Input_Surname")).validationMessageAttr = "Use only letters";
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:oafFApz400SqFUZbjhOarA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// IsValid = False
vars.value.isValidVar = false;
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:VnN5nb+ZYUu9Y0eNGNT_0A", callContext.id);
// Input_Surname.Valid = True
model.widgets.get(idService.getId("Input_Surname")).validAttr = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:VnN5nb+ZYUu9Y0eNGNT_0A", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Input_Surname.ValidationMessage = ""
model.widgets.get(idService.getId("Input_Surname")).validationMessageAttr = "";
}

}

// Is Diff Null?
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:gCclw8YySkq5twYg4iH6gQ", callContext.id) && !(model.variables.detailsVar.personalDetailsAttr.birthDateAttr.equals(OS.BuiltinFunctions.nullDate())))) {
// Invalid BirthDate
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:z7Iy4Ar1J0ev+6_vJCyWWg", callContext.id) && model.variables.detailsVar.personalDetailsAttr.birthDateAttr.gt(OS.BuiltinFunctions.dateTimeToDate(OS.BuiltinFunctions.addYears(OS.BuiltinFunctions.currDate(), -16))))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:pIZOuFXAMEGxa+5xNa3Z4w", callContext.id);
// DateOfBirthValidation.State = Error
model.variables.dateOfBirthValidationVar.stateAttr = ShopperPortalEUModel.staticEntities.customValidationMessageState.error;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:pIZOuFXAMEGxa+5xNa3Z4w", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// DateOfBirthValidation.Message = "You must be 16 or older to use the Shopper Portal"
model.variables.dateOfBirthValidationVar.messageAttr = "You must be 16 or older to use the Shopper Portal";
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:pIZOuFXAMEGxa+5xNa3Z4w", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// IsValid = False
vars.value.isValidVar = false;
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:zdeoU7Yuk0GmyGD5vMqKMA", callContext.id);
// DateOfBirthValidation.State = NullTextIdentifier
model.variables.dateOfBirthValidationVar.stateAttr = OS.BuiltinFunctions.nullTextIdentifier();
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:zdeoU7Yuk0GmyGD5vMqKMA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// DateOfBirthValidation.Message = ""
model.variables.dateOfBirthValidationVar.messageAttr = "";
}

} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:3v77hNs4mEWNpI4OgnUTCA", callContext.id);
// DateOfBirthValidation.State = Error
model.variables.dateOfBirthValidationVar.stateAttr = ShopperPortalEUModel.staticEntities.customValidationMessageState.error;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:3v77hNs4mEWNpI4OgnUTCA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// DateOfBirthValidation.Message = "This field is required"
model.variables.dateOfBirthValidationVar.messageAttr = "This field is required";
}

// Invalid Country or region
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:FPb3vxpE_0+evoaZrPr3wA", callContext.id) && ((model.variables.detailsVar.addressAttr.countryAttr === "") || (model.variables.detailsVar.addressAttr.countryAttr === "0")))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:gsyu9F7SWUacR+4USufp9Q", callContext.id);
// CountryOrRegionValidation.State = Error
model.variables.countryOrRegionValidationVar.stateAttr = ShopperPortalEUModel.staticEntities.customValidationMessageState.error;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:gsyu9F7SWUacR+4USufp9Q", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// CountryOrRegionValidation.Message = "This field is required"
model.variables.countryOrRegionValidationVar.messageAttr = "This field is required";
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:gsyu9F7SWUacR+4USufp9Q", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// IsValid = False
vars.value.isValidVar = false;
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:tNS9_3UpxEul8CNz5jVkLw", callContext.id);
// CountryOrRegionValidation.State = NullTextIdentifier
model.variables.countryOrRegionValidationVar.stateAttr = OS.BuiltinFunctions.nullTextIdentifier();
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:tNS9_3UpxEul8CNz5jVkLw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// CountryOrRegionValidation.Message = ""
model.variables.countryOrRegionValidationVar.messageAttr = "";
}

// Not valid
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:0zL9ZAkdO0GIh7CYEpJR8w", callContext.id) && (!(vars.value.isValidVar) || !(model.widgets.get(idService.getId("DetailsForm")).validAttr)))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:uh9Tdmhbp0+3Z4WypzD2+w", callContext.id);
// Execute Action: ScrollToFirstInvalidField
ShopperPortalEU_UI_ComponentsController.default.scrollToFirstInvalidField$Action(callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:eLyVyWtMNUOopRpUbl5SiA", callContext.id);
} else {
// Format names
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ktlINFXKuEeoMvijHXQymw", callContext.id);
// Details.PersonalDetails.GivenNames = FormatTitleCase(Details.PersonalDetails.GivenNames)
model.variables.detailsVar.personalDetailsAttr.givenNamesAttr = OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.formatTitleCase$Action(model.variables.detailsVar.personalDetailsAttr.givenNamesAttr, callContext).formattedStringOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ktlINFXKuEeoMvijHXQymw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Details.PersonalDetails.Surname = FormatTitleCase(Details.PersonalDetails.Surname)
model.variables.detailsVar.personalDetailsAttr.surnameAttr = OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.formatTitleCase$Action(model.variables.detailsVar.personalDetailsAttr.surnameAttr, callContext).formattedStringOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:fD+PJJBS+EKus_6iiEYV6w", callContext.id);
// Details.IsSaving = True
model.variables.detailsVar.isSavingAttr = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:RK1TP0nf5U6zj5YymOHS_Q", callContext.id);
// Execute Action: ShopperUpdateDetails
model.flush();
return ShopperPortalEUController.default.shopperCreateOrUpdateDetails$Action(model.variables.detailsVar, model.variables.initialDetailsVar, callContext).then(function (value) {
shopperUpdateDetailsVar.value = value;
}).then(function () {
// Success
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:H_OmOUOZfk2U+H0sik8tdA", callContext.id) && shopperUpdateDetailsVar.value.isSuccessOut)) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:XZkgSZLPdUW8ewxz5IBOPw", callContext.id);
// Details.IsSaving = False
model.variables.detailsVar.isSavingAttr = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:jQAk4Poxx0Gbe7ID7VQzww", callContext.id);
// Execute Action: SuccessMessage
ShopperPortalEU_UI_ThemeController.default.customMessageTrigger$Action(function () {
var rec = new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customMessageType.success;
rec.titleAttr = "Profile details saved";
rec.testIdAttr = "CompleteDetailsSuccess";
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ShpVOeLr3kuWa4JMdud5Xg", callContext.id);
// Execute Action: PercentageProfileCalculation
percentageProfileCalculationVar.value = ShopperPortalEUController.default.percentageProfileCalculation$Action(model.variables.detailsVar, callContext);

// UpdatePercentage
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:JtPl1QUvvUyLJCuYnIdUTQ", callContext.id);
// ShopperProfileCompleted = Round
ShopperPortalEUClientVariables.setShopperProfileCompleted(OS.BuiltinFunctions.round(percentageProfileCalculationVar.value.calculatedPercentageOut, 0));
// Set client variables
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:TfKM2SZfcESna0Fr3CLNbw", callContext.id);
// ShopperName = FormatShopperName(Details.PersonalDetails.GivenNames, Details.PersonalDetails.Surname)
ShopperPortalEUClientVariables.setShopperName(OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.formatShopperName$Action(model.variables.detailsVar.personalDetailsAttr.givenNamesAttr, model.variables.detailsVar.personalDetailsAttr.surnameAttr, callContext).formattedShopperNameOut;
}, OS.DataTypes.DataTypes.Text, callContext.id));
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:TfKM2SZfcESna0Fr3CLNbw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// ShopperContact = If
ShopperPortalEUClientVariables.setShopperContact(((((model.variables.detailsVar.contactAttr.emailAttr) !== (""))) ? (model.variables.detailsVar.contactAttr.emailAttr) : (model.variables.detailsVar.contactAttr.mobileNumberAttr)));
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:TfKM2SZfcESna0Fr3CLNbw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// ShopperPassports = If
ShopperPortalEUClientVariables.setShopperPassports((((ShopperPortalEUClientVariables.getShopperPassports() > 0)) ? (ShopperPortalEUClientVariables.getShopperPassports()) : ((((model.variables.detailsVar.personalDetailsAttr.passportAttr === "")) ? (ShopperPortalEUClientVariables.getShopperPassports()) : (1)))));
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:TfKM2SZfcESna0Fr3CLNbw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// ShopperPassportDataTemp = ""
ShopperPortalEUClientVariables.setShopperPassportDataTemp("");
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:VLwIz1wQK02freHZbkr8RQ", callContext.id);
// Execute Action: ClarityEvent
ShopperPortalEUController.default.clarityEvent$Action("savedetails_btn", callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Y56hKcHHSUWgPDZlCpc8mg", callContext.id);
// Destination: /ShopperPortalEU/MyRefunds
return OS.Flow.returnAsync(OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "MyRefunds", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true));
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Aqobaxl7M0KJoOVTag5IrQ", callContext.id);
// Details.IsSaving = False
model.variables.detailsVar.isSavingAttr = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:VJDg1Oz5A0m6ftZfHIfIMg", callContext.id);
// Execute Action: ErrorMessage
ShopperPortalEU_UI_ThemeController.default.customMessageTrigger$Action(function () {
var rec = new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customMessageType.error;
rec.titleAttr = shopperUpdateDetailsVar.value.errorMessageOut;
rec.contentAttr = OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.defaultErrorMessage$Action(callContext).errorMessageOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
rec.testIdAttr = "CompleteDetailsError";
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:9lo8GjY51EOagFOhN3D1Pg", callContext.id);
}

});
}

});
}).catch(function (ex) {
OS.Logger.trace("CompleteDetails.Save", OS.Exceptions.getMessage(ex), ex.name);
// Handle Error: AllExceptions
if(!(OS.Exceptions.isSystem(ex))) {
OS.Logger.error(null, ex);
allExceptionsVar.value.exceptionMessageAttr = OS.Exceptions.getMessage(ex);
OutSystemsDebugger.handleException(allExceptionsVar.value.exceptionMessageAttr, callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:1zH0rtRIzkyC5UGLBsK3vQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:K9bfWgxKRka6CFF_u5BaBw", callContext.id);
// Details.IsSaving = False
model.variables.detailsVar.isSavingAttr = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:mIwUjbt9fUqsYBPPsot6+g", callContext.id);
// Execute Action: GenericErrorMessage
ShopperPortalEU_UI_ThemeController.default.customMessageTrigger$Action(function () {
var rec = new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customMessageType.error;
rec.titleAttr = "Failed to save details";
rec.contentAttr = OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.defaultErrorMessage$Action(callContext).errorMessageOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
rec.testIdAttr = "CompleteDetailsError";
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:3pi1q1kjtkuw8eYaRDFpyA", callContext.id);
return OS.Flow.returnAsync();

});
}

throw ex;
}).then(function (res) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:jqR5JegRqkqYEe_ZE2zbOA", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:jqR5JegRqkqYEe_ZE2zbOA", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("ShopperPortalEU.Profile.CompleteDetails.Save$vars", [{
name: "IsValid",
attrName: "isValidVar",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Boolean,
defaultValue: function () {
return false;
}
}]);
Controller.prototype._onReady$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnReady");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:WE9Hbs_DSUiqYrPcWCysqQ:/NRWebFlows.G6g8LlI0+UqpwXA+JmvtFg/NodesShownInESpaceTree.rWRZhI99HUesTaH+0J0+RQ/ClientActions.WE9Hbs_DSUiqYrPcWCysqQ:DqkOOMpWyxBM2b0myau90w", "ShopperPortalEU", "OnReady", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:sVw3rgdbcECHDlfWVJRXJQ", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:SSfnEf6xc021SZli+M5OnA", callContext.id);
// Execute Action: FetchShopper
return controller._fetchShopper$Action(callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:TmiYnHKuMUWW50eCwoYt2Q", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:WE9Hbs_DSUiqYrPcWCysqQ", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:WE9Hbs_DSUiqYrPcWCysqQ", callContext.id);
throw ex;

});
};
Controller.prototype._countryOnChange$Action = function (currentCountryIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("CountryOnChange");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.Profile.CompleteDetails.CountryOnChange$vars"))());
vars.value.currentCountryInLocal = currentCountryIn.clone();
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:1c4new4rQUi3bK2QlvznGw:/NRWebFlows.G6g8LlI0+UqpwXA+JmvtFg/NodesShownInESpaceTree.rWRZhI99HUesTaH+0J0+RQ/ClientActions.1c4new4rQUi3bK2QlvznGw:VWQepLsU34BstK4B0FUvQQ", "ShopperPortalEU", "CountryOnChange", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:kQroZpfZ5U6tvYrqnTODLQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:TpdEregvU0+uB8rftTwfOg", callContext.id);
// Details.Address.Country = CurrentCountry.Value
model.variables.detailsVar.addressAttr.countryAttr = vars.value.currentCountryInLocal.valueAttr;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:TpdEregvU0+uB8rftTwfOg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// CountryOrRegionValidation.State = NullTextIdentifier
model.variables.countryOrRegionValidationVar.stateAttr = OS.BuiltinFunctions.nullTextIdentifier();
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:TpdEregvU0+uB8rftTwfOg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// CountryOrRegionValidation.Message = ""
model.variables.countryOrRegionValidationVar.messageAttr = "";
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:DG9JBHwE7Uq7ZD4e2dzuBQ", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:1c4new4rQUi3bK2QlvznGw", callContext.id);
}

};
Controller.registerVariableGroupType("ShopperPortalEU.Profile.CompleteDetails.CountryOnChange$vars", [{
name: "CurrentCountry",
attrName: "currentCountryInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Record,
defaultValue: function () {
return new ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValueOptionsRec();
},
complexType: ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValueOptionsRec
}]);
Controller.prototype._fetchShopper$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("FetchShopper");
callContext = controller.callContext(callContext);
var getShopperVar = new OS.DataTypes.VariableHolder();
var scanPassportFromJSONVar = new OS.DataTypes.VariableHolder(new (OS.Controller.BaseController.getJSONDeserializeOutputType(ShopperPortalEUModel.ScanPassportRec))());
varBag.callContext = callContext;
varBag.getShopperVar = getShopperVar;
varBag.scanPassportFromJSONVar = scanPassportFromJSONVar;
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:YnjYg6+cMEaEhVN3wG+fDg:/NRWebFlows.G6g8LlI0+UqpwXA+JmvtFg/NodesShownInESpaceTree.rWRZhI99HUesTaH+0J0+RQ/ClientActions.YnjYg6+cMEaEhVN3wG+fDg:UtWx0vqlVYHEWjO8eyvngw", "ShopperPortalEU", "FetchShopper", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:62axVAgCh0eus_1IUZPxtQ", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Kn5SEBLDHkq+19rsCq2uaA", callContext.id);
// Details.IsDataFetched = False
model.variables.detailsVar.isDataFetchedAttr = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:qOcPsYOTYk+7wE4hiFXfbA", callContext.id);
// Execute Action: GetShopper
model.flush();
return ShopperPortalEU_Shopper_ISController.default.getShopper$Action(ShopperPortalEUClientVariables.getShopperGuid(), callContext).then(function (value) {
getShopperVar.value = value;
}).then(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:5kkN76ySgkaSnfcUc6V0mQ", callContext.id) && getShopperVar.value.isSuccessOut)) {
// Set Details
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:gP_RKrYx9k24ihNsEq63OA", callContext.id);
// Details.PersonalDetails.Passport = If
model.variables.detailsVar.personalDetailsAttr.passportAttr = (((getShopperVar.value.shopperOut.travelDocumentsAttr.length > 1)) ? (getShopperVar.value.shopperOut.travelDocumentsAttr.getItem((getShopperVar.value.shopperOut.travelDocumentsAttr.length - 1)).numberAttr) : (getShopperVar.value.shopperOut.travelDocumentsAttr.getCurrent(callContext.iterationContext).numberAttr));
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:gP_RKrYx9k24ihNsEq63OA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Details.PersonalDetails.PassportExpiryDate = If
model.variables.detailsVar.personalDetailsAttr.passportExpiryDateAttr = (((getShopperVar.value.shopperOut.travelDocumentsAttr.length > 1)) ? (OS.BuiltinFunctions.textToDate(getShopperVar.value.shopperOut.travelDocumentsAttr.getItem((getShopperVar.value.shopperOut.travelDocumentsAttr.length - 1)).expirationDateAttr)) : (OS.BuiltinFunctions.textToDate(getShopperVar.value.shopperOut.travelDocumentsAttr.getCurrent(callContext.iterationContext).expirationDateAttr)));
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:gP_RKrYx9k24ihNsEq63OA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// Details.PersonalDetails.PassportCountry = If
model.variables.detailsVar.personalDetailsAttr.passportCountryAttr = OS.BuiltinFunctions.longIntegerToText((((getShopperVar.value.shopperOut.travelDocumentsAttr.length > 1)) ? (getShopperVar.value.shopperOut.travelDocumentsAttr.getItem((getShopperVar.value.shopperOut.travelDocumentsAttr.length - 1)).issuedByIsoAttr) : (getShopperVar.value.shopperOut.travelDocumentsAttr.getCurrent(callContext.iterationContext).issuedByIsoAttr)));
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:gP_RKrYx9k24ihNsEq63OA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// Details.PersonalDetails.GivenNames = GetShopper.Shopper.FirstName
model.variables.detailsVar.personalDetailsAttr.givenNamesAttr = getShopperVar.value.shopperOut.firstNameAttr;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:gP_RKrYx9k24ihNsEq63OA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// Details.PersonalDetails.Surname = GetShopper.Shopper.LastName
model.variables.detailsVar.personalDetailsAttr.surnameAttr = getShopperVar.value.shopperOut.lastNameAttr;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:gP_RKrYx9k24ihNsEq63OA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "6");
// Details.PersonalDetails.BirthDate = If
model.variables.detailsVar.personalDetailsAttr.birthDateAttr = ((((getShopperVar.value.shopperOut.dateOfBirthAttr === "") || (getShopperVar.value.shopperOut.dateOfBirthAttr === "0001-01-01"))) ? (OS.BuiltinFunctions.nullDate()) : (OS.BuiltinFunctions.textToDate(getShopperVar.value.shopperOut.dateOfBirthAttr)));
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:gP_RKrYx9k24ihNsEq63OA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "7");
// Details.PersonalDetails.Nationality = GetShopper.Shopper.NationalityIso
model.variables.detailsVar.personalDetailsAttr.nationalityAttr = OS.BuiltinFunctions.longIntegerToText(getShopperVar.value.shopperOut.nationalityIsoAttr);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:gP_RKrYx9k24ihNsEq63OA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "8");
// Details.Address.Country = GetShopper.Shopper.CountryOfResidenceIso
model.variables.detailsVar.addressAttr.countryAttr = OS.BuiltinFunctions.longIntegerToText(getShopperVar.value.shopperOut.countryOfResidenceIsoAttr);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:gP_RKrYx9k24ihNsEq63OA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "9");
// Details.Address.AddressLine1 = GetShopper.Shopper.AddressLineOne
model.variables.detailsVar.addressAttr.addressLine1Attr = getShopperVar.value.shopperOut.addressLineOneAttr;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:gP_RKrYx9k24ihNsEq63OA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "10");
// Details.Address.AddressLine2 = GetShopper.Shopper.AddressLineTwo
model.variables.detailsVar.addressAttr.addressLine2Attr = getShopperVar.value.shopperOut.addressLineTwoAttr;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:gP_RKrYx9k24ihNsEq63OA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "11");
// Details.Address.Postcode = GetShopper.Shopper.PostCode
model.variables.detailsVar.addressAttr.postcodeAttr = getShopperVar.value.shopperOut.postCodeAttr;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:gP_RKrYx9k24ihNsEq63OA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "12");
// Details.Address.City = GetShopper.Shopper.City
model.variables.detailsVar.addressAttr.cityAttr = getShopperVar.value.shopperOut.cityAttr;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:gP_RKrYx9k24ihNsEq63OA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "13");
// Details.Address.State = GetShopper.Shopper.Region
model.variables.detailsVar.addressAttr.stateAttr = getShopperVar.value.shopperOut.regionAttr;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:gP_RKrYx9k24ihNsEq63OA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "14");
// Details.Contact.Email = GetShopper.Shopper.Email
model.variables.detailsVar.contactAttr.emailAttr = getShopperVar.value.shopperOut.emailAttr;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:gP_RKrYx9k24ihNsEq63OA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "15");
// Details.Contact.MobileNumber = GetShopper.Shopper.MobileNumber
model.variables.detailsVar.contactAttr.mobileNumberAttr = getShopperVar.value.shopperOut.mobileNumberAttr;
// Set initial values
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:qjUN8wh8IkWdYIOeKQevcA", callContext.id);
// InitialDetails = Details
model.variables.initialDetailsVar = model.variables.detailsVar;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:QO7o8mpTE0CJpiWXEbYq4g", callContext.id);
// JSON Deserialize: ScanPassportFromJSON
scanPassportFromJSONVar.value.dataOut = OS.JSONUtils.deserializeFromJSON(ShopperPortalEUClientVariables.getShopperPassportDataTemp(), ShopperPortalEUModel.ScanPassportRec, false);
// SetScanPassportDetails
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:tdhkUqhevkmjdoJYaAPGeA", callContext.id);
// Details.PersonalDetails.Passport = If
model.variables.detailsVar.personalDetailsAttr.passportAttr = ((((scanPassportFromJSONVar.value.dataOut.personalNumberAttr) !== (""))) ? (scanPassportFromJSONVar.value.dataOut.documentNumberAttr) : (model.variables.detailsVar.personalDetailsAttr.passportAttr));
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:tdhkUqhevkmjdoJYaAPGeA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Details.PersonalDetails.PassportExpiryDate = If
model.variables.detailsVar.personalDetailsAttr.passportExpiryDateAttr = OS.BuiltinFunctions.dateTimeToDate(((!(scanPassportFromJSONVar.value.dataOut.dateOfExpiryAttr.equals(OS.BuiltinFunctions.nullDate()))) ? (scanPassportFromJSONVar.value.dataOut.dateOfExpiryAttr) : (model.variables.detailsVar.personalDetailsAttr.passportExpiryDateAttr)));
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:tdhkUqhevkmjdoJYaAPGeA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// Details.PersonalDetails.PassportCountry = If
model.variables.detailsVar.personalDetailsAttr.passportCountryAttr = ((((scanPassportFromJSONVar.value.dataOut.issuingCountryCodeAttr) !== (""))) ? (scanPassportFromJSONVar.value.dataOut.issuingCountryCodeAttr) : (model.variables.detailsVar.personalDetailsAttr.passportCountryAttr));
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:tdhkUqhevkmjdoJYaAPGeA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// Details.PersonalDetails.GivenNames = If
model.variables.detailsVar.personalDetailsAttr.givenNamesAttr = ((((scanPassportFromJSONVar.value.dataOut.givenNamesAttr) !== (""))) ? (scanPassportFromJSONVar.value.dataOut.givenNamesAttr) : (model.variables.detailsVar.personalDetailsAttr.givenNamesAttr));
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:tdhkUqhevkmjdoJYaAPGeA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// Details.PersonalDetails.Surname = If
model.variables.detailsVar.personalDetailsAttr.surnameAttr = ((((scanPassportFromJSONVar.value.dataOut.surnameAttr) !== (""))) ? (scanPassportFromJSONVar.value.dataOut.surnameAttr) : (model.variables.detailsVar.personalDetailsAttr.surnameAttr));
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:tdhkUqhevkmjdoJYaAPGeA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "6");
// Details.PersonalDetails.BirthDate = If
model.variables.detailsVar.personalDetailsAttr.birthDateAttr = OS.BuiltinFunctions.dateTimeToDate(((!(scanPassportFromJSONVar.value.dataOut.dateOfBirthAttr.equals(OS.BuiltinFunctions.nullDate()))) ? (scanPassportFromJSONVar.value.dataOut.dateOfBirthAttr) : (model.variables.detailsVar.personalDetailsAttr.birthDateAttr)));
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:tdhkUqhevkmjdoJYaAPGeA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "7");
// Details.PersonalDetails.Nationality = If
model.variables.detailsVar.personalDetailsAttr.nationalityAttr = ((((scanPassportFromJSONVar.value.dataOut.nationalityCountryCodeAttr) !== (""))) ? (scanPassportFromJSONVar.value.dataOut.nationalityCountryCodeAttr) : (model.variables.detailsVar.personalDetailsAttr.nationalityAttr));
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:XHg0Ciav4EyhnWlf4fSR2g", callContext.id);
// Details.IsDataFetched = True
model.variables.detailsVar.isDataFetchedAttr = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:XHg0Ciav4EyhnWlf4fSR2g", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Details.IsSuccess = True
model.variables.detailsVar.isSuccessAttr = true;
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:bHVWFuAycU6OSlmA9SophQ", callContext.id) && ShopperPortalEUClientVariables.getIsProfileDetailsNavigation())) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:cp8G+X8d0kanJqxtnrjF_g", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:aGROk29iC0SRUnKzBNyu1g", callContext.id);
// IsEntryFlow = notShopperCheckMandatoryFields(GetShopper.Shopper)
model.variables.isEntryFlowVar = !(OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.shopperCheckMandatoryFields$Action(getShopperVar.value.shopperOut, callContext).filledOut;
}, OS.DataTypes.DataTypes.Boolean, callContext.id));
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:2FVg9lDKuUaEX5EckvLUkw", callContext.id);
}

} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:rn6MGJLH8EW+RsilITMASg", callContext.id);
// Details.IsSuccess = False
model.variables.detailsVar.isSuccessAttr = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:rn6MGJLH8EW+RsilITMASg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Details.IsDataFetched = True
model.variables.detailsVar.isDataFetchedAttr = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Y7vfRjL5RUuqnHslzQytGw", callContext.id);
// Execute Action: CustomMessageTrigger
ShopperPortalEU_UI_ThemeController.default.customMessageTrigger$Action(function () {
var rec = new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customMessageType.error;
rec.titleAttr = "We couldn\'t load the shopper data";
rec.contentAttr = OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.defaultErrorMessage$Action(callContext).errorMessageOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
rec.testIdAttr = "ErrorFetchingShopperData";
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:lpPH24P78UOo03BFpJ8uRg", callContext.id);
}

});
}).then(function (res) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:YnjYg6+cMEaEhVN3wG+fDg", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:YnjYg6+cMEaEhVN3wG+fDg", callContext.id);
throw ex;

});
};
Controller.prototype._onBackClick$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnBackClick");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:7FwOizmysEWGNYq4OUbAjg:/NRWebFlows.G6g8LlI0+UqpwXA+JmvtFg/NodesShownInESpaceTree.rWRZhI99HUesTaH+0J0+RQ/ClientActions.7FwOizmysEWGNYq4OUbAjg:92v7Lk2TjtVUK4cGhpqwcw", "ShopperPortalEU", "OnBackClick", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:RYw5AMxN_kqHhc5BczaY0A", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
// Profile navigation
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:AEbP86EEqUGpU_eV4ddK+A", callContext.id) && ShopperPortalEUClientVariables.getIsProfileDetailsNavigation())) {
// Edit mode
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:PbWBmZjuvkqiK1PjwNR5lw", callContext.id) && model.variables.showEditableWidgetsVar)) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:d+it4_fhuUS4K80IzYaM6Q", callContext.id);
// Execute Action: FetchShopper
return controller._fetchShopper$Action(callContext).then(function () {
// Reset flags
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:y2oeYRIO9ka_zYuxHCkjOw", callContext.id);
// ShowEditableWidgets = notShowEditableWidgets
model.variables.showEditableWidgetsVar = !(model.variables.showEditableWidgetsVar);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:RkFQBCHJTkOEJ5m6yn6euQ", callContext.id);
});
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:mibgZmkNZUu1RSF2ay7f4w", callContext.id);
// Destination: /ShopperPortalEU/MyProfile
return OS.Flow.returnAsync(OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "MyProfile", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true));
}

});
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:zOK9BoUUe0C+gCIFwZD3PQ", callContext.id);
// Destination: (PreviousScreen)
return OS.Flow.returnAsync(OS.Navigation.navigateBack(null, callContext, true));
}

});
}).then(function (res) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:7FwOizmysEWGNYq4OUbAjg", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:7FwOizmysEWGNYq4OUbAjg", callContext.id);
throw ex;

});
};
Controller.prototype._onEdit$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnEdit");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:epDXoT5j2kKpEjn3xepN4Q:/NRWebFlows.G6g8LlI0+UqpwXA+JmvtFg/NodesShownInESpaceTree.rWRZhI99HUesTaH+0J0+RQ/ClientActions.epDXoT5j2kKpEjn3xepN4Q:63uWJcBxFHOJGIHRSKCuhA", "ShopperPortalEU", "OnEdit", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:9JmUL3o6iEKmN+BXkblR4w", callContext.id);
// Reset flags
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:xHVkPEL+kEGGb6xoLQNtAA", callContext.id);
// ShowEditableWidgets = notShowEditableWidgets
model.variables.showEditableWidgetsVar = !(model.variables.showEditableWidgetsVar);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:gg_cPy0_kEKwVRUQlVYmrg", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:epDXoT5j2kKpEjn3xepN4Q", callContext.id);
}

};
Controller.prototype._givenNamesOnChange$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("GivenNamesOnChange");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:h3iiszjXZ06ciASfBHQh8A:/NRWebFlows.G6g8LlI0+UqpwXA+JmvtFg/NodesShownInESpaceTree.rWRZhI99HUesTaH+0J0+RQ/ClientActions.h3iiszjXZ06ciASfBHQh8A:Zsxncn28X5LgzH3V4FtPQw", "ShopperPortalEU", "GivenNamesOnChange", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:0rSNpJ7O_ketXGNqRAbbqQ", callContext.id);
// Set Valid = True
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Xw08j801b0WJMcFmzJanwA", callContext.id);
// Input_GivenNames.Valid = True
model.widgets.get(idService.getId("Input_GivenNames")).validAttr = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Xw08j801b0WJMcFmzJanwA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Input_GivenNames.ValidationMessage = ""
model.widgets.get(idService.getId("Input_GivenNames")).validationMessageAttr = "";
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:GEF8o_syl0SnYqznb56Rfw", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:h3iiszjXZ06ciASfBHQh8A", callContext.id);
}

};
Controller.prototype._onInitialize$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnInitialize");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:FX80xte2tk2QLq7T4MXq0A:/NRWebFlows.G6g8LlI0+UqpwXA+JmvtFg/NodesShownInESpaceTree.rWRZhI99HUesTaH+0J0+RQ/ClientActions.FX80xte2tk2QLq7T4MXq0A:xQkwxwiHKS4p8b8+xf5TqQ", "ShopperPortalEU", "OnInitialize", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:yEB0Vo1pf0mG+q1_goyemQ", callContext.id);
// init vars
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:8sz2A91IPU+NBTZmDQfwOw", callContext.id);
// Details.IsDataFetched = False
model.variables.detailsVar.isDataFetchedAttr = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:8sz2A91IPU+NBTZmDQfwOw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Details.IsSuccess = False
model.variables.detailsVar.isSuccessAttr = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:8sz2A91IPU+NBTZmDQfwOw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// Details.IsSaving = False
model.variables.detailsVar.isSavingAttr = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:8sz2A91IPU+NBTZmDQfwOw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// ShowEditableWidgets = notIsProfileDetailsNavigation
model.variables.showEditableWidgetsVar = !(ShopperPortalEUClientVariables.getIsProfileDetailsNavigation());
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:8sz2A91IPU+NBTZmDQfwOw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// IsEntryFlow = False
model.variables.isEntryFlowVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:2j1qwirzvUC+lBjaH2e_Zg", callContext.id);
// Execute Action: HeapIdentify
ShopperPortalEUController.default.heapIdentify$Action(ShopperPortalEUClientVariables.getEmail(), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:L4rpb7Y8rku4AIHwVIRwJA", callContext.id);
// Execute Action: ApcuesIdentify
ShopperPortalEUController.default.apcuesIdentify$Action(function () {
var rec = new ShopperPortalEUModel.ApcuesIdentifyRec();
rec.guidAttr = ShopperPortalEUClientVariables.getShopperGuid();
rec.nameAttr = ShopperPortalEUClientVariables.getShopperName();
rec.emailAttr = ShopperPortalEUClientVariables.getEmail();
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:gCAwvgPbx0Sgwyf1UqqYiA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:FX80xte2tk2QLq7T4MXq0A", callContext.id);
}

};
Controller.prototype._surnameOnChange$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("SurnameOnChange");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:Bpl_1DChHEeVMR1O4uZwfQ:/NRWebFlows.G6g8LlI0+UqpwXA+JmvtFg/NodesShownInESpaceTree.rWRZhI99HUesTaH+0J0+RQ/ClientActions.Bpl_1DChHEeVMR1O4uZwfQ:l4ljsQvfpEUnTaI1o9IUdQ", "ShopperPortalEU", "SurnameOnChange", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:vt0nzuOh_0WHigzxGdnEuQ", callContext.id);
// Set Valid = True
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:9XaxA4klmU2IyKIZzbPcMQ", callContext.id);
// Input_Surname.Valid = True
model.widgets.get(idService.getId("Input_Surname")).validAttr = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:9XaxA4klmU2IyKIZzbPcMQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Input_Surname.ValidationMessage = ""
model.widgets.get(idService.getId("Input_Surname")).validationMessageAttr = "";
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:IIkaUdvF00aI+W1LV1ghsw", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:Bpl_1DChHEeVMR1O4uZwfQ", callContext.id);
}

};
Controller.prototype._nationalityOnChange$Action = function (currentDataIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("NationalityOnChange");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.Profile.CompleteDetails.NationalityOnChange$vars"))());
vars.value.currentDataInLocal = currentDataIn.clone();
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:vxpB43BHnECMu7AyjN8tiA:/NRWebFlows.G6g8LlI0+UqpwXA+JmvtFg/NodesShownInESpaceTree.rWRZhI99HUesTaH+0J0+RQ/ClientActions.vxpB43BHnECMu7AyjN8tiA:5etKVSdhk2XL1tqJbCTaKA", "ShopperPortalEU", "NationalityOnChange", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:SNtFl0JCFkOjvIO3XXNPzQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:sFfbmWL8M0arv3bahxV4NA", callContext.id);
// Details.PersonalDetails.Nationality = CurrentData.Value
model.variables.detailsVar.personalDetailsAttr.nationalityAttr = vars.value.currentDataInLocal.valueAttr;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:VXaxmoarJU+31VZzhzYtkQ", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:vxpB43BHnECMu7AyjN8tiA", callContext.id);
}

};
Controller.registerVariableGroupType("ShopperPortalEU.Profile.CompleteDetails.NationalityOnChange$vars", [{
name: "CurrentData",
attrName: "currentDataInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Record,
defaultValue: function () {
return new ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValueOptionsRec();
},
complexType: ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValueOptionsRec
}]);

Controller.prototype.birthDateOnChange$Action = function (currentDateIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._birthDateOnChange$Action, callContext, currentDateIn);

};
Controller.prototype.mobileNumberOnChange$Action = function (dataIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._mobileNumberOnChange$Action, callContext, dataIn);

};
Controller.prototype.save$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._save$Action, callContext);

};
Controller.prototype.onReady$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onReady$Action, callContext);

};
Controller.prototype.countryOnChange$Action = function (currentCountryIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._countryOnChange$Action, callContext, currentCountryIn);

};
Controller.prototype.fetchShopper$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._fetchShopper$Action, callContext);

};
Controller.prototype.onBackClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onBackClick$Action, callContext);

};
Controller.prototype.onEdit$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onEdit$Action, callContext);

};
Controller.prototype.givenNamesOnChange$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._givenNamesOnChange$Action, callContext);

};
Controller.prototype.onInitialize$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onInitialize$Action, callContext);

};
Controller.prototype.surnameOnChange$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._surnameOnChange$Action, callContext);

};
Controller.prototype.nationalityOnChange$Action = function (currentDataIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._nationalityOnChange$Action, callContext, currentDataIn);

};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:G6g8LlI0+UqpwXA+JmvtFg:/NRWebFlows.G6g8LlI0+UqpwXA+JmvtFg:yposeKjmRCh6Km0A8t9bYg", "ShopperPortalEU", "Profile", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:rWRZhI99HUesTaH+0J0+RQ:/NRWebFlows.G6g8LlI0+UqpwXA+JmvtFg/NodesShownInESpaceTree.rWRZhI99HUesTaH+0J0+RQ:kYH8OwLcvzeFUKEIuNm0kg", "ShopperPortalEU", "CompleteDetails", "NRNodes.WebScreen", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:rWRZhI99HUesTaH+0J0+RQ", callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:G6g8LlI0+UqpwXA+JmvtFg", callContext.id);
};
Controller.prototype.onInitializeEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Profile/CompleteDetails On Initialize");
return controller.onInitialize$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return ShopperPortalEU_ProfileController.default.handleError(ex, this.callContext());
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return ShopperPortalEUController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, ShopperPortalEULanguageResources);
});

define("ShopperPortalEU.Profile.CompleteDetails.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"kaRS4aA2AkWTTMK8O3I5XA": {
getter: function (varBag, idService) {
return varBag.vars.value.currentDateInLocal;
},
dataType: OS.DataTypes.DataTypes.Date
},
"B9maFwnIX0ag_qndo_RTEA": {
getter: function (varBag, idService) {
return varBag.vars.value.dataInLocal;
}
},
"yyahhI5sgUamfW2Q+w3Ang": {
getter: function (varBag, idService) {
return varBag.vars.value.isValidVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"1zH0rtRIzkyC5UGLBsK3vQ": {
getter: function (varBag, idService) {
return varBag.allExceptionsVar.value;
}
},
"ShpVOeLr3kuWa4JMdud5Xg": {
getter: function (varBag, idService) {
return varBag.percentageProfileCalculationVar.value;
}
},
"RK1TP0nf5U6zj5YymOHS_Q": {
getter: function (varBag, idService) {
return varBag.shopperUpdateDetailsVar.value;
}
},
"qIVl5NzjokO6H3A0SVS2yg": {
getter: function (varBag, idService) {
return varBag.vars.value.currentCountryInLocal;
}
},
"qOcPsYOTYk+7wE4hiFXfbA": {
getter: function (varBag, idService) {
return varBag.getShopperVar.value;
}
},
"QO7o8mpTE0CJpiWXEbYq4g": {
getter: function (varBag, idService) {
return varBag.scanPassportFromJSONVar.value;
}
},
"MFPb21ngEk2Ix7g6jMELnQ": {
getter: function (varBag, idService) {
return varBag.vars.value.currentDataInLocal;
}
},
"46DYUHf8ok+HBFAgnc1_Fg": {
getter: function (varBag, idService) {
return varBag.model.variables.detailsVar;
}
},
"e1ZXx_7ji0uNyz0drljSRw": {
getter: function (varBag, idService) {
return varBag.model.variables.initialDetailsVar;
}
},
"JnFWe6fqzUaDrBm_+tyeaw": {
getter: function (varBag, idService) {
return varBag.model.variables.dateOfBirthValidationVar;
}
},
"Zo_7n9MuqUi1GphK5vPh9w": {
getter: function (varBag, idService) {
return varBag.model.variables.countryOrRegionValidationVar;
}
},
"1Af71boq+UamrbH9kCEE8g": {
getter: function (varBag, idService) {
return varBag.model.variables.showEditableWidgetsVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"8LR_n6sZP02opZRsh8asgA": {
getter: function (varBag, idService) {
return varBag.model.variables.isEntryFlowVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"Ci_n0dUeiUGG5hpVh4jkWw": {
getter: function (varBag, idService) {
return varBag.model.variables.getCountriesDataAct;
}
},
"u5IYOh3DX0yXip59+PmMXw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderLeft"));
})(varBag.model, idService);
}
},
"IEMxJ0ZXM0ik3FISwfMK8A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderCenter"));
})(varBag.model, idService);
}
},
"jIbmLCj8BE+fPCW_Q1kWTQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("IsProfileDetailsNavigation"));
})(varBag.model, idService);
}
},
"cCbLHiNdjEGbaZrpzr0U2w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderRight"));
})(varBag.model, idService);
}
},
"R2PVqTY5PkiYeoS+e3llIw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"q+rZ3R8Hz0yYGsa0OL3dEw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"Mt+WfbmY_UOmXAGwsDKZEw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Form"));
})(varBag.model, idService);
}
},
"2XqbKN97okeZc+yH8tmlSw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("DetailsForm"));
})(varBag.model, idService);
}
},
"z_7fnEA2p0usa5tEEqqGNA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("IsCompleteDetailsMode3"));
})(varBag.model, idService);
}
},
"hXH3qNdHmkGfQvo0MIgkwg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"bEGdiTVGL0iwzHX9mDtYuw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Show_EditableWidgets2"));
})(varBag.model, idService);
}
},
"hFntVnnik0OhKqDbJ5pstQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Label"));
})(varBag.model, idService);
}
},
"OSIPFnY_BE2Wzld+6eGVcg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input"));
})(varBag.model, idService);
}
},
"_uNazxzFa0SL_iL6fiuBZA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input_GivenNames"));
})(varBag.model, idService);
}
},
"_RckjnwStEKtfr5kL5ygHw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Description"));
})(varBag.model, idService);
}
},
"62nIeH5gckWqCQ7mecHnQw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Label"));
})(varBag.model, idService);
}
},
"4BlxUO0O9U+tw52uco+CWA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input"));
})(varBag.model, idService);
}
},
"vGt_aYmA50+9IS9_Iucf+A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input_Surname"));
})(varBag.model, idService);
}
},
"_5aBuwSCTEKowq1SgIcAEg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Description"));
})(varBag.model, idService);
}
},
"6SNJx3JOF0a++zPGstQpvw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Label"));
})(varBag.model, idService);
}
},
"68v67JA+OEakGcPvrq53gA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Label"));
})(varBag.model, idService);
}
},
"xvdnH4V7aEaLmp6uVLBKRw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("GivenNames"));
})(varBag.model, idService);
}
},
"kXgctvBp7Ee4UInX24iTnQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Label"));
})(varBag.model, idService);
}
},
"prv6PspwCUml9+xaExb8HA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Value"));
})(varBag.model, idService);
}
},
"R0c2EAx9A06Te2JmG3WtvQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Surname"));
})(varBag.model, idService);
}
},
"u9HWBHYiQk6SDiNzCp66hg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Label"));
})(varBag.model, idService);
}
},
"43o7f0lFlkOi_qsWZZJGGQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Value"));
})(varBag.model, idService);
}
},
"oCtaoUSWPEm3flXbLNziiQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("DateOfBirth"));
})(varBag.model, idService);
}
},
"tiBaVDh+okqZePMsQ+rPpA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Label"));
})(varBag.model, idService);
}
},
"Y6viTSdheEK8rH2gNAlj1g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Value"));
})(varBag.model, idService);
}
},
"g9MVp6wyPkikjT+5z27nyw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Nationality2"));
})(varBag.model, idService);
}
},
"Z3Bnd3jS+U6k5OU6BN3iDw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Label"));
})(varBag.model, idService);
}
},
"mjEZETSmLkKLQcQeUARMww": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Value"));
})(varBag.model, idService);
}
},
"0I9m1NO1uEahTjI_BXm30Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"tUtBXoAhZkiFVO3TLK7__w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Show_EditableWidgets"));
})(varBag.model, idService);
}
},
"zU8GtO1EKEClm9Xm7F3nTQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Label"));
})(varBag.model, idService);
}
},
"6jgi7xEJC0G7yQPQPFAncQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Label"));
})(varBag.model, idService);
}
},
"uLV25jY73UKWcMnq5j3txg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input"));
})(varBag.model, idService);
}
},
"ngeI8HX1lEOeZeHSf+vyOg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input_AddressLine1"));
})(varBag.model, idService);
}
},
"JeKMoLhU0UKn1CGdi_3owA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Description"));
})(varBag.model, idService);
}
},
"BgeAR5ZMv0OzRXimzaR+BA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Label"));
})(varBag.model, idService);
}
},
"v1SZYYnbqkC0mhlMR9nrzA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input"));
})(varBag.model, idService);
}
},
"W7iooGrdVUmxAqCKp0K1Iw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input_AddressLine2"));
})(varBag.model, idService);
}
},
"WSHKnkozOUu8lMwTV4ZuSA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Description"));
})(varBag.model, idService);
}
},
"VDRYCwKpWUyj9E7V63TctQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"n9+HgZf110GRSiOoAvg3Ng": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Label"));
})(varBag.model, idService);
}
},
"4sx1J15RMEWjt4q2G9At4w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input"));
})(varBag.model, idService);
}
},
"o7n+q6_6HEO0AuJb4WJV5g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input_Postcode"));
})(varBag.model, idService);
}
},
"MDRtcPJNpkSiB4dkjz8C7g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Description"));
})(varBag.model, idService);
}
},
"Zq5O1_IN6UO06T7I_NYEig": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Label"));
})(varBag.model, idService);
}
},
"dfxfVDzDqkmu3e8a_3H1Uw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input"));
})(varBag.model, idService);
}
},
"e97O_6Sxrk+JYpff0oq8LQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input_City"));
})(varBag.model, idService);
}
},
"A3mKdBgQ4U6kRlzRhzUTkQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Description"));
})(varBag.model, idService);
}
},
"lay74yBtKkea6OUKJYYxzQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Label"));
})(varBag.model, idService);
}
},
"hUn8l1PqeUeaZNwWtjz7XQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input"));
})(varBag.model, idService);
}
},
"AIphg0qUKk+pE8f6PoxspQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input_State"));
})(varBag.model, idService);
}
},
"XTBhFfWI5kGNvg+bJOLAeA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Description"));
})(varBag.model, idService);
}
},
"rfGWt+h2W02E73WMR6T9Gw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("AddressCountry2"));
})(varBag.model, idService);
}
},
"QTsYIaN930i8e_DJns8zAw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Label"));
})(varBag.model, idService);
}
},
"yd9+z86qn0Kx4U9TXyhDPQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Value"));
})(varBag.model, idService);
}
},
"RFUM3tnrl0mmyd8U6ZmIUQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Address1"));
})(varBag.model, idService);
}
},
"ZmhaMTlTbkCDZKB0OA4kzg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Label"));
})(varBag.model, idService);
}
},
"jN2Uceyh2U6BfgYxTumcOw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Value"));
})(varBag.model, idService);
}
},
"A6nDBMckmEmudBlYlcQonw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Show_Address2"));
})(varBag.model, idService);
}
},
"lv7Zac0KvkCCRCi78tjNNg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Address2"));
})(varBag.model, idService);
}
},
"vx+GTXy930u3ubvCm6ppZA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Label"));
})(varBag.model, idService);
}
},
"HEG4zE_xv0muIanR8lMQpQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Value"));
})(varBag.model, idService);
}
},
"S8GoSudUnESesyE1lqT1Rg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"eROItY52EEyJm+nTzFMpoA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Postcode"));
})(varBag.model, idService);
}
},
"P2QMe0pfGkayCupTgFxHtQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Label"));
})(varBag.model, idService);
}
},
"MG58y8Bmg0mPArVoaucnJg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Value"));
})(varBag.model, idService);
}
},
"5l7AbOMnz0WpNQwobfTz8w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("City"));
})(varBag.model, idService);
}
},
"1FBt54huS0SlAtI6_LPL7A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Label"));
})(varBag.model, idService);
}
},
"P_EhaFSVKUiRYSq3yM6icA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Value"));
})(varBag.model, idService);
}
},
"28fri3FYmE2jCOORfkMq2g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"A9jj4krMXEu6vUqa8Vjg_g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Label"));
})(varBag.model, idService);
}
},
"v_ZHvf_6skqvJVRCTimObw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input"));
})(varBag.model, idService);
}
},
"g4rXkLoYYU+OBH5eLhPlrg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("EmaiFilled"));
})(varBag.model, idService);
}
},
"lAqF_WHpWE+JNCq49SPosg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Email"));
})(varBag.model, idService);
}
},
"vCnRuLUzrU21A3X3paQkjg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input_Email"));
})(varBag.model, idService);
}
},
"4j6PxCU2Y0SMcarng049oA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Description"));
})(varBag.model, idService);
}
},
"X_gMyxSVKU6yDQdzpIXBkA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("MobileFilled"));
})(varBag.model, idService);
}
},
"aJ1tEMUIMkeU7YkBLsBxZA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("MobileNumber2"));
})(varBag.model, idService);
}
},
"jr3I2NUfvEy3dfzhWjHYPA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Label"));
})(varBag.model, idService);
}
},
"UyPSLKTQckGbfuyB0nTBpg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Value"));
})(varBag.model, idService);
}
},
"64i5_LuOLkSvuAsrS+Ssdw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("MobileNumber"));
})(varBag.model, idService);
}
},
"5xy3vZ67FEWQQvDzs+lwew": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"bPZVylyl50CuycU3ItfOFw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("ShowSave"));
})(varBag.model, idService);
}
},
"XlqgL7QQWUy5so+8dfoE8Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Button"));
})(varBag.model, idService);
}
},
"yKD3v+Gf1U+nbTpQcpuMlQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"gR57jKn4D0qDWeoALiEHuw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("ShowEdit"));
})(varBag.model, idService);
}
},
"EAtUT4fhiEmXCYAyBZyZng": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Button"));
})(varBag.model, idService);
}
},
"oMTkoztX4EuTr_5dG5A5tw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"i2aQEEvKvUGHGX0MFmYFaQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Bottom"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
