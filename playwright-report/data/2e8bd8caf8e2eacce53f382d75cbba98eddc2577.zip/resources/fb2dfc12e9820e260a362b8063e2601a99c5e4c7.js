define("Custom404Plugin.controller$NotFoundOnDestroy", ["exports", "OutSystems/ClientRuntime/Main", "Custom404Plugin.model", "Custom404Plugin.controller", "Custom404Plugin.controller$NotFoundOnDestroy.BreakOutOfIFrameJS"], function (exports, OutSystems, Custom404PluginModel, Custom404PluginController, Custom404Plugin_controller_NotFoundOnDestroy_BreakOutOfIFrameJS) {
var OS = OutSystems.Internal;
Custom404PluginController.default.notFoundOnDestroy$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("ygBN765a8k6PM17If1bXiQ:TvOw2hjegUmh55XjmYHFqw:/ClientActionFlows.TvOw2hjegUmh55XjmYHFqw:r3Kqr9nqDMulKoEuWMqCzg", "Custom404Plugin", "NotFoundOnDestroy", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ygBN765a8k6PM17If1bXiQ:q2ONPaWEn0KYMYujhWMzzg", callContext.id);
OutSystemsDebugger.handleBreakpoint("ygBN765a8k6PM17If1bXiQ:LphM03rBn0KeegsvpFcaCA", callContext.id);
controller.safeExecuteJSNode(Custom404Plugin_controller_NotFoundOnDestroy_BreakOutOfIFrameJS, "BreakOutOfIFrame", "NotFoundOnDestroy", null, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("ygBN765a8k6PM17If1bXiQ:FH3A8NJ4JUSkoFmr7+GkdA", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ygBN765a8k6PM17If1bXiQ:TvOw2hjegUmh55XjmYHFqw", callContext.id);
}

};
var controller = Custom404PluginController.default;
Custom404PluginController.default.clientActionProxies.notFoundOnDestroy$Action = function () {
return controller.executeActionInsideJSNode(Custom404PluginController.default.notFoundOnDestroy$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("Custom404Plugin.controller$NotFoundOnDestroy.BreakOutOfIFrameJS", [], function () {
return function ($actions, $roles, $public) {
window.top.location = window.location;
};
});

define("Custom404Plugin.controller", ["exports", "OutSystems/ClientRuntime/Main", "Custom404Plugin.model", "Custom404Plugin.controller$debugger"], function (exports, OutSystems, Custom404PluginModel, Custom404Plugin_Controller_debugger) {
var OS = OutSystems.Internal;
var Custom404PluginController = exports;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
}
Controller.prototype.clientActionProxies = {};
Controller.prototype.roles = {};
Controller.prototype.defaultTimeout = 10;
Controller.prototype.getDefaultTimeout = function () {
return Custom404PluginController.default.defaultTimeout;
};
Controller.prototype.getClientActionProxies = function (controller) {
var _this = this;
var thisController = controller;
return Object.keys(this.clientActionProxies).reduce(function (acc, actionName) {
acc[actionName] = function () {
if(thisController.isActive()) {
return _this.clientActionProxies[actionName].apply(thisController, arguments);
}

return Promise.resolve();
};
return acc;
}, {});
};
return Controller;
})(OS.Controller.BaseModuleController);
Custom404PluginController.default = new Controller(null, "Custom404Plugin");
});
define("Custom404Plugin.controller$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"LphM03rBn0KeegsvpFcaCA": {
getter: function (varBag, idService) {
return varBag.breakOutOfIFrameJSResult.value;
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
