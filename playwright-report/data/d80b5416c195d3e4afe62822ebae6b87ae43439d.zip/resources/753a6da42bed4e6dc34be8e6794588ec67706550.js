define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.DatatransCard.mvc$model", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.MonthYearInput.mvc$model", "ShopperPortalEU_UI_Components.model$DatatransCardChangeOptionsRec", "ShopperPortalEU_UI_Components.model$DatatransCardOptionsRec", "ShopperPortalEU_UI_Components.model$MonthYearInputOptionsRec", "ShopperPortalEU_UI_Components.model$MonthYearInputValidationOptionsRec", "ShopperPortalEU_UI_Components.model$DatatransCardGetCardInfoOptionsRec", "ShopperPortalEU_UI_Components.model$MonthYearInputChangeOptionsRec"], function (OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_MonthYearInput_mvcModel) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("Obj", "objVar", "Obj", true, false, OS.DataTypes.DataTypes.Object, function () {
return null;
}, false), 
this.attr("Card", "cardVar", "Card", true, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.DatatransCardChangeOptionsRec());
}, false, ShopperPortalEU_UI_ComponentsModel.DatatransCardChangeOptionsRec), 
this.attr("Options", "optionsIn", "Options", true, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.DatatransCardOptionsRec());
}, false, ShopperPortalEU_UI_ComponentsModel.DatatransCardOptionsRec), 
this.attr("_optionsInDataFetchStatus", "_optionsInDataFetchStatus", "_optionsInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Model._hasValidationWidgetsValue = undefined;
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
if((Model._hasValidationWidgetsValue === undefined)) {
Model._hasValidationWidgetsValue = ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_MonthYearInput_mvcModel.hasValidationWidgets;
}

return Model._hasValidationWidgetsValue;
}
});

Model.prototype.setInputs = function (inputs) {
if("Options" in inputs) {
this.variables.optionsIn = inputs.Options;
if("_optionsInDataFetchStatus" in inputs) {
this.variables._optionsInDataFetchStatus = inputs._optionsInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "ShopperPortalEUUIComponents.DatatransCard");
});
define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.DatatransCard.mvc$view", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.controller", "react", "OutSystems/ReactView/Main", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.DatatransCard.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.DatatransCard.mvc$controller", "OutSystems/ReactWidgets/Main", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.MonthYearInput.mvc$view", "ShopperPortalEU_UI_Components.model$DatatransCardChangeOptionsRec", "ShopperPortalEU_UI_Components.model$DatatransCardOptionsRec", "ShopperPortalEU_UI_Components.model$MonthYearInputOptionsRec", "ShopperPortalEU_UI_Components.model$MonthYearInputValidationOptionsRec", "ShopperPortalEU_UI_Components.model$DatatransCardGetCardInfoOptionsRec", "ShopperPortalEU_UI_Components.model$MonthYearInputChangeOptionsRec"], function (OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ComponentsController, React, OSView, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_DatatransCard_mvc_model, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_DatatransCard_mvc_controller, OSWidgets, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_MonthYearInput_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            var thisIsInstanceOfSuper = this instanceof _super;
            if (thisIsInstanceOfSuper == false) {
                return;
            }

            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "ShopperPortalEUUIComponents.DatatransCard";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css"];
        };
        View.getJsDependencies = function() {
            return ["scripts/ShopperPortalEU_UI_Components.datatransCard.js"];
        };
        View.getBlocks = function() {
            return [ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_MonthYearInput_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_DatatransCard_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_DatatransCard_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "custom-datatrans-card",
visible: true,
_idProps: {
service: idService,
name: "Element"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "custom-datatrans-card__label",
visible: true,
_idProps: {
service: idService,
uuid: "1"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
extendedProperties: {
"data-testid": model.getCachedValue(idService.getId("uZKmaA9oIECqMA5jHVX4BQ.data-testid"), function () {
return ((((model.variables.optionsIn.testIdAttr) !== (""))) ? ((model.variables.optionsIn.testIdAttr + "Label")) : (""));
}, function () {
return model.variables.optionsIn.testIdAttr;
})
},
gridProperties: {
classes: "OSFillParent"
},
style: model.getCachedValue(idService.getId("uZKmaA9oIECqMA5jHVX4BQ.Style"), function () {
return ((!(model.variables.optionsIn.isMandatoryAttr)) ? ("") : ("mandatory"));
}, function () {
return model.variables.optionsIn.isMandatoryAttr;
}),
_idProps: {
service: idService,
uuid: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
style_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._optionsInDataFetchStatus)
}, React.createElement(OSWidgets.Expression, {
value: model.variables.optionsIn.labelAttr,
_idProps: {
service: idService,
uuid: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._optionsInDataFetchStatus)
}))), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "custom-datatrans-card__input-wrapper",
visible: true,
_idProps: {
service: idService,
uuid: "4"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "custom-datatrans-card__input-image",
visible: true,
_idProps: {
service: idService,
uuid: "5"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "custom-datatrans-card__input",
visible: true,
_idProps: {
service: idService,
name: "Input"
},
_widgetRecordProvider: widgetsRecordProvider
}, $if(false, false, this, function () {
return [];
}, function () {
return [];
})), $if(!(model.variables.optionsIn.includeExpiryDateAttr), false, this, function () {
return [];
}, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_MonthYearInput_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("wcxBHVExVEyilV8fDHLfJw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.MonthYearInputOptionsRec();
rec.dateAttr = model.variables.optionsIn.expiryDateAttr;
rec.useMaskAttr = true;
rec.isCCTypeAttr = true;
rec.testIdAttr = ((((model.variables.optionsIn.testIdAttr) !== (""))) ? ((model.variables.optionsIn.testIdAttr + "MonthYear")) : (""));
return rec;
}();
}, function () {
return model.variables.optionsIn.expiryDateAttr;
}, function () {
return model.variables.optionsIn.testIdAttr;
}),
_optionsInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._optionsInDataFetchStatus)
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onChange$Action: function (currentDateInfoIn) {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ShopperPortalEUUIComponents/MonthYearInput OnChange");
return controller.expiryOnChange$Action(currentDateInfoIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
onFocus$Action: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ShopperPortalEUUIComponents/MonthYearInput OnFocus");
return controller.focus$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "7",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
label: PlaceholderContent.Empty
},
_dependencies: []
})];
}), $if((model.variables.optionsIn.errorMessageAttr === ""), false, this, function () {
return [];
}, function () {
return [React.createElement(OSWidgets.Expression, {
style: "validation-message",
value: model.variables.optionsIn.errorMessageAttr,
_idProps: {
service: idService,
uuid: "8"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._optionsInDataFetchStatus)
})];
}))));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.DatatransCard.mvc$controller", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.controller", "ShopperPortalEU_UI_Components.languageResources", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.DatatransCard.mvc$debugger", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.DatatransCard.mvc$controller.OnParametersChanged.ParametersChangedJS", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.DatatransCard.mvc$controller.Ready.InitializeJS", "ShopperPortalEU_UI_Components.model$DatatransCardChangeOptionsRec", "ShopperPortalEU_UI_Components.model$DatatransCardOptionsRec", "ShopperPortalEU_UI_Components.model$MonthYearInputOptionsRec", "ShopperPortalEU_UI_Components.model$MonthYearInputValidationOptionsRec", "ShopperPortalEU_UI_Components.model$DatatransCardGetCardInfoOptionsRec", "ShopperPortalEU_UI_Components.model$MonthYearInputChangeOptionsRec"], function (OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ComponentsController, ShopperPortalEU_UI_ComponentsLanguageResources, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_DatatransCard_mvc_Debugger, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_DatatransCard_mvc_controller_OnParametersChanged_ParametersChangedJS, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_DatatransCard_mvc_controller_Ready_InitializeJS) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {
success$Action: function (transactionIdIn) {
transactionIdIn = (transactionIdIn === undefined) ? "" : transactionIdIn;
return controller.executeActionInsideJSNode(controller._success$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(transactionIdIn, OS.DataTypes.DataTypes.Text)), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "Success");
},
error$Action: function (errorMessageIn) {
errorMessageIn = (errorMessageIn === undefined) ? "" : errorMessageIn;
return controller.executeActionInsideJSNode(controller._error$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(errorMessageIn, OS.DataTypes.DataTypes.Text)), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "Error");
},
cardNumberChange$Action: function (cardInfoIn) {
cardInfoIn = (cardInfoIn === undefined) ? "" : cardInfoIn;
return controller.executeActionInsideJSNode(controller._cardNumberChange$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(cardInfoIn, OS.DataTypes.DataTypes.Text)), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "CardNumberChange");
},
cardInfo$Action: function (cardInfoJSONIn) {
cardInfoJSONIn = (cardInfoJSONIn === undefined) ? "" : cardInfoJSONIn;
return controller.executeActionInsideJSNode(controller._cardInfo$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(cardInfoJSONIn, OS.DataTypes.DataTypes.Text)), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "CardInfo");
},
focus$Action: function () {
return controller.executeActionInsideJSNode(controller._focus$Action.bind(controller), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "Focus");
}
};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = false;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._cardNumberChange$Action = function (cardInfoIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("CardNumberChange");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.DatatransCard.CardNumberChange$vars"))());
vars.value.cardInfoInLocal = cardInfoIn;
var cardInfoJSONVar = new OS.DataTypes.VariableHolder(new (OS.Controller.BaseController.getJSONDeserializeOutputType(ShopperPortalEU_UI_ComponentsModel.DatatransCardChangeOptionsRec))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.cardInfoJSONVar = cardInfoJSONVar;
OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:lrPmFdYvQ0iUAZrK_68+Cg:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.7pxd++uV1kKoQPgftxBWRg/ClientActions.lrPmFdYvQ0iUAZrK_68+Cg:80lcPiacU+71_bl4+B+Rng", "ShopperPortalEU_UI_Components", "CardNumberChange", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:UqUQEubNsU6YtrxmOpPW6Q", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:0CvjbvwJi0SP2S3TukOTJg", callContext.id);
// ExpiryDate = Card.ExpiryDate
vars.value.expiryDateVar = model.variables.cardVar.expiryDateAttr;
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:3J_19LnHVECjJZWbSebL0g", callContext.id);
// JSON Deserialize: CardInfoJSON
cardInfoJSONVar.value.dataOut = OS.JSONUtils.deserializeFromJSON(vars.value.cardInfoInLocal, ShopperPortalEU_UI_ComponentsModel.DatatransCardChangeOptionsRec, false);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:PgHq0xpJ1kqBshqdNy60Ew", callContext.id);
// Card = CardInfoJSON.Data
model.variables.cardVar = cardInfoJSONVar.value.dataOut;
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:PgHq0xpJ1kqBshqdNy60Ew", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Card.ExpiryDate = ExpiryDate
model.variables.cardVar.expiryDateAttr = vars.value.expiryDateVar;
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:7pzMuqIFpkyqcfnw+2+_SQ", callContext.id);
// Trigger Event: OnChange
return controller.onChange$Action(model.variables.cardVar, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:ok3Xuf0BE0Cs34LbjLSdQw", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:lrPmFdYvQ0iUAZrK_68+Cg", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:lrPmFdYvQ0iUAZrK_68+Cg", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.DatatransCard.CardNumberChange$vars", [{
name: "CardInfo",
attrName: "cardInfoInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}, {
name: "ExpiryDate",
attrName: "expiryDateVar",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Date,
defaultValue: function () {
return OS.DataTypes.DateTime.defaultValue;
}
}]);
Controller.prototype._cardInfo$Action = function (cardInfoJSONIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("CardInfo");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.DatatransCard.CardInfo$vars"))());
vars.value.cardInfoJSONInLocal = cardInfoJSONIn;
var cardInfoVar = new OS.DataTypes.VariableHolder(new (OS.Controller.BaseController.getJSONDeserializeOutputType(ShopperPortalEU_UI_ComponentsModel.DatatransCardGetCardInfoOptionsRec))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.cardInfoVar = cardInfoVar;
OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:I78FQan+OkehG9vS_3KuGQ:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.7pxd++uV1kKoQPgftxBWRg/ClientActions.I78FQan+OkehG9vS_3KuGQ:3MAqVD6x_pVtQeDhkEl8cg", "ShopperPortalEU_UI_Components", "CardInfo", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:hYMLZ9U4KUizCozWbG4FNA", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:ixz8nhcjzUudoPbFpufyIw", callContext.id);
// JSON Deserialize: CardInfo
cardInfoVar.value.dataOut = OS.JSONUtils.deserializeFromJSON(vars.value.cardInfoJSONInLocal, ShopperPortalEU_UI_ComponentsModel.DatatransCardGetCardInfoOptionsRec, false);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:ZIyTbfBatUCjgv4LEYm3AA", callContext.id);
// Trigger Event: OnCardInfo
return controller.onCardInfo$Action(cardInfoVar.value.dataOut, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:Q4KXCHqb0kem_NCcqxNQ0w", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:I78FQan+OkehG9vS_3KuGQ", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:I78FQan+OkehG9vS_3KuGQ", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.DatatransCard.CardInfo$vars", [{
name: "CardInfoJSON",
attrName: "cardInfoJSONInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
Controller.prototype._focus$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Focus");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:dojPXaBtUkSd3d93Nv1sYA:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.7pxd++uV1kKoQPgftxBWRg/ClientActions.dojPXaBtUkSd3d93Nv1sYA:FGYDxHtnRLmB61GjlpQjZA", "ShopperPortalEU_UI_Components", "Focus", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:_XmaXcvYIkaqAi5BhkD0GA", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:RkmN_hsMPUC7rRrDVd6ouw", callContext.id);
// Trigger Event: OnFocus
return controller.onFocus$Action(callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:NMfvlOP6bUi9gst5eYs_rg", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:dojPXaBtUkSd3d93Nv1sYA", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:dojPXaBtUkSd3d93Nv1sYA", callContext.id);
throw ex;

});
};
Controller.prototype._error$Action = function (errorMessageIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Error");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.DatatransCard.Error$vars"))());
vars.value.errorMessageInLocal = errorMessageIn;
varBag.callContext = callContext;
varBag.vars = vars;
OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:1VFfbM8gckKHRp2+dczxfg:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.7pxd++uV1kKoQPgftxBWRg/ClientActions.1VFfbM8gckKHRp2+dczxfg:DPUF86vtQS9nZbabo3atjA", "ShopperPortalEU_UI_Components", "Error", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:Wep+wdz_U0iMymTrLs2Jog", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:K7BlTSRSqU6w8n4nbk1xlg", callContext.id);
// Trigger Event: OnError
return controller.onError$Action(vars.value.errorMessageInLocal, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:_tnUDKOtdEWBGiDuL3K+Eg", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:1VFfbM8gckKHRp2+dczxfg", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:1VFfbM8gckKHRp2+dczxfg", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.DatatransCard.Error$vars", [{
name: "ErrorMessage",
attrName: "errorMessageInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
Controller.prototype._onParametersChanged$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnParametersChanged");
callContext = controller.callContext(callContext);
var optionsJSONVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.JSONSerializeOutputType());
varBag.callContext = callContext;
varBag.optionsJSONVar = optionsJSONVar;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:saGVuxLL9kSlV92xoda2Vg:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.7pxd++uV1kKoQPgftxBWRg/ClientActions.saGVuxLL9kSlV92xoda2Vg:osjY30BdzSjSEkKD6YTvfA", "ShopperPortalEU_UI_Components", "OnParametersChanged", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:gZSl0vBxUUGSc5gEwstiGQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:EAJgeaT9yE+u0Kqvd8Awlg", callContext.id);
// Card.ExpiryDate = Options.ExpiryDate
model.variables.cardVar.expiryDateAttr = model.variables.optionsIn.expiryDateAttr;
if((OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:EHE08GRVk0WpgQ8_gmk9cA", callContext.id) && ((model.variables.objVar) !== (OS.BuiltinFunctions.nullObject())))) {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:rp2Oo7V3gkalg9Ywe7f9gw", callContext.id);
// JSON Serialize: OptionsJSON
optionsJSONVar.value.jSONOut = OS.JSONUtils.serializeToJSON(model.variables.optionsIn, true, false);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:CnI+j0w2UEWFWjC2dC5KhA", callContext.id);
// Parameters change method.
controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_DatatransCard_mvc_controller_OnParametersChanged_ParametersChangedJS, "ParametersChanged", "OnParametersChanged", {
Obj: OS.DataConversion.JSNodeParamConverter.to(model.variables.objVar, OS.DataTypes.DataTypes.Object),
Options: OS.DataConversion.JSNodeParamConverter.to(optionsJSONVar.value.jSONOut, OS.DataTypes.DataTypes.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:cTCcV6gTy06_iq55_j_fbQ", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:xcxLYG4h00+lmUP7GgJm5g", callContext.id);
}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:saGVuxLL9kSlV92xoda2Vg", callContext.id);
}

};
Controller.prototype._success$Action = function (transactionIdIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Success");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.DatatransCard.Success$vars"))());
vars.value.transactionIdInLocal = transactionIdIn;
varBag.callContext = callContext;
varBag.vars = vars;
OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:La5Tz5ku_Uy54dAfHP7hQA:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.7pxd++uV1kKoQPgftxBWRg/ClientActions.La5Tz5ku_Uy54dAfHP7hQA:rEoiLyRkHDBzD4Cjc9_wNQ", "ShopperPortalEU_UI_Components", "Success", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:H3ZQRt+7hk6n5wCHcqS25w", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:alxQMXAcmkud1E0udxU9zA", callContext.id);
// Trigger Event: OnSuccess
return controller.onSuccess$Action(vars.value.transactionIdInLocal, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:pACIoBU2UEmKlSPzuf1HEQ", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:La5Tz5ku_Uy54dAfHP7hQA", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:La5Tz5ku_Uy54dAfHP7hQA", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.DatatransCard.Success$vars", [{
name: "TransactionId",
attrName: "transactionIdInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
Controller.prototype._ready$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Ready");
callContext = controller.callContext(callContext);
var initializeJSResult = new OS.DataTypes.VariableHolder();
var optionsJSONVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.JSONSerializeOutputType());
varBag.callContext = callContext;
varBag.initializeJSResult = initializeJSResult;
varBag.optionsJSONVar = optionsJSONVar;
OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:pcp+2PubmEWBQAXSTJh0aA:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.7pxd++uV1kKoQPgftxBWRg/ClientActions.pcp+2PubmEWBQAXSTJh0aA:3ALDJmrvWZTMfOHUaQBt7g", "ShopperPortalEU_UI_Components", "Ready", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:zhJf2zqdVE2jsiitiNJPXg", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:YjiMpX+3PECoijq9WtzLNQ", callContext.id);
// Execute Action: RequireScript
model.flush();
return OS.SystemActions.requireScript(((!(model.variables.optionsIn.isProdEnvironmentAttr)) ? ("https://pay.sandbox.datatrans.com/upp/payment/js/secure-fields-2.0.0.min.js") : ("https://pay.datatrans.com/upp/payment/js/secure-fields-2.0.0.min.js")), callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:M6G7W3l4FUOdGmf03DfwLw", callContext.id);
// JSON Serialize: OptionsJSON
optionsJSONVar.value.jSONOut = OS.JSONUtils.serializeToJSON(model.variables.optionsIn, true, false);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:qte48ulcHEm1lakFOQhkMA", callContext.id);
// Initialize component.
initializeJSResult.value = controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_DatatransCard_mvc_controller_Ready_InitializeJS, "Initialize", "Ready", {
Options: OS.DataConversion.JSNodeParamConverter.to(optionsJSONVar.value.jSONOut, OS.DataTypes.DataTypes.Text),
ElementId: OS.DataConversion.JSNodeParamConverter.to(idService.getId("Element"), OS.DataTypes.DataTypes.Text),
Obj: OS.DataConversion.JSNodeParamConverter.to(null, OS.DataTypes.DataTypes.Object)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.DatatransCard.Ready$initializeJSResult"))();
jsNodeResult.objOut = OS.DataConversion.JSNodeParamConverter.from($parameters.Obj, OS.DataTypes.DataTypes.Object);
return jsNodeResult;
}, {
Success: controller.clientActionProxies.success$Action,
Error: controller.clientActionProxies.error$Action,
CardNumberChange: controller.clientActionProxies.cardNumberChange$Action,
CardInfo: controller.clientActionProxies.cardInfo$Action,
Focus: controller.clientActionProxies.focus$Action
}, {});
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:vYHN6R3+uUewrCNXIymYlQ", callContext.id);
// Obj = Initialize.Obj
model.variables.objVar = initializeJSResult.value.objOut;
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:1t8RPH6ll0+bYAJcd5lHZw", callContext.id);
// Trigger Event: OnReady
return controller.onReady$Action(model.variables.objVar, callContext);
}).then(function () {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:roHSAaVnWkG5jzb+HYWgmg", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:pcp+2PubmEWBQAXSTJh0aA", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:pcp+2PubmEWBQAXSTJh0aA", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.DatatransCard.Ready$initializeJSResult", [{
name: "Obj",
attrName: "objOut",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Object,
defaultValue: function () {
return null;
}
}]);
Controller.prototype._expiryOnChange$Action = function (currentDateInfoIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("ExpiryOnChange");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.DatatransCard.ExpiryOnChange$vars"))());
vars.value.currentDateInfoInLocal = currentDateInfoIn.clone();
varBag.callContext = callContext;
varBag.vars = vars;
OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:Ytak_d1IlEGg9GocDnlMnw:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.7pxd++uV1kKoQPgftxBWRg/ClientActions.Ytak_d1IlEGg9GocDnlMnw:Vou74nIZNT9IkIQWSpMDZA", "ShopperPortalEU_UI_Components", "ExpiryOnChange", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:nsTUofzJ0Eyao1kswe6R+A", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:Q8x4BV4DekyLJ+ao6C8ADw", callContext.id);
// Card.ExpiryDate = CurrentDateInfo.Date
model.variables.cardVar.expiryDateAttr = vars.value.currentDateInfoInLocal.dateAttr;
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:Tmo0VnzVEUervbTDtI96fg", callContext.id);
// Trigger Event: OnChange
return controller.onChange$Action(model.variables.cardVar, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:CCrBX9FAPEiQLz+DC0jbaA", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:Ytak_d1IlEGg9GocDnlMnw", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:Ytak_d1IlEGg9GocDnlMnw", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.DatatransCard.ExpiryOnChange$vars", [{
name: "CurrentDateInfo",
attrName: "currentDateInfoInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Record,
defaultValue: function () {
return new ShopperPortalEU_UI_ComponentsModel.MonthYearInputChangeOptionsRec();
},
complexType: ShopperPortalEU_UI_ComponentsModel.MonthYearInputChangeOptionsRec
}]);

Controller.prototype.cardNumberChange$Action = function (cardInfoIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._cardNumberChange$Action, callContext, cardInfoIn);

};
Controller.prototype.cardInfo$Action = function (cardInfoJSONIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._cardInfo$Action, callContext, cardInfoJSONIn);

};
Controller.prototype.focus$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._focus$Action, callContext);

};
Controller.prototype.error$Action = function (errorMessageIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._error$Action, callContext, errorMessageIn);

};
Controller.prototype.onParametersChanged$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onParametersChanged$Action, callContext);

};
Controller.prototype.success$Action = function (transactionIdIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._success$Action, callContext, transactionIdIn);

};
Controller.prototype.ready$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._ready$Action, callContext);

};
Controller.prototype.expiryOnChange$Action = function (currentDateInfoIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._expiryOnChange$Action, callContext, currentDateInfoIn);

};
Controller.prototype.onReady$Action = function () {
return Promise.resolve();
};
Controller.prototype.onError$Action = function () {
return Promise.resolve();
};
Controller.prototype.onFocus$Action = function () {
return Promise.resolve();
};
Controller.prototype.onChange$Action = function () {
return Promise.resolve();
};
Controller.prototype.onCardInfo$Action = function () {
return Promise.resolve();
};
Controller.prototype.onSuccess$Action = function () {
return Promise.resolve();
};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:7hC2bHqrKEmxvEuPSzIN0Q:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q:g5BtT+X6uN+vFl8t9PMqCQ", "ShopperPortalEU_UI_Components", "ShopperPortalEUUIComponents", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:7pxd++uV1kKoQPgftxBWRg:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.7pxd++uV1kKoQPgftxBWRg:mng+IZwttu0l_vU+a9Dojw", "ShopperPortalEU_UI_Components", "DatatransCard", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:7pxd++uV1kKoQPgftxBWRg", callContext.id);
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:7hC2bHqrKEmxvEuPSzIN0Q", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "ShopperPortalEUUIComponents/DatatransCard On Ready");
return controller.ready$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "ShopperPortalEUUIComponents/DatatransCard On Parameters Changed");
return controller.onParametersChanged$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return ShopperPortalEU_UI_ComponentsController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, ShopperPortalEU_UI_ComponentsLanguageResources);
});
define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.DatatransCard.mvc$controller.OnParametersChanged.ParametersChangedJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.Obj.parametersChanged(JSON.parse($parameters.Options));
};
});
define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.DatatransCard.mvc$controller.Ready.InitializeJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.Obj = new customDatatransCard($parameters.ElementId,JSON.parse($parameters.Options),{
    success:$actions.Success,
    error: $actions.Error,
    cardNumberChange: $actions.CardNumberChange,
    cardInfo: $actions.CardInfo,
    focus: $actions.Focus
});
};
});

define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.DatatransCard.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"ICnp8Qxaa0G+s2XLvEhgJw": {
getter: function (varBag, idService) {
return varBag.vars.value.expiryDateVar;
},
dataType: OS.DataTypes.DataTypes.Date
},
"HiPn03dkj0W57Jgd0+9q4A": {
getter: function (varBag, idService) {
return varBag.vars.value.cardInfoInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"3J_19LnHVECjJZWbSebL0g": {
getter: function (varBag, idService) {
return varBag.cardInfoJSONVar.value;
}
},
"upbQucLMUUGToOEkv1vxLQ": {
getter: function (varBag, idService) {
return varBag.vars.value.cardInfoJSONInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"ixz8nhcjzUudoPbFpufyIw": {
getter: function (varBag, idService) {
return varBag.cardInfoVar.value;
}
},
"+FZJgzYpZEG1p6bgE831TQ": {
getter: function (varBag, idService) {
return varBag.vars.value.errorMessageInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"rp2Oo7V3gkalg9Ywe7f9gw": {
getter: function (varBag, idService) {
return varBag.optionsJSONVar.value;
}
},
"CnI+j0w2UEWFWjC2dC5KhA": {
getter: function (varBag, idService) {
return varBag.parametersChangedJSResult.value;
}
},
"MmhamgPSa0qhEJQItsscXQ": {
getter: function (varBag, idService) {
return varBag.vars.value.transactionIdInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"M6G7W3l4FUOdGmf03DfwLw": {
getter: function (varBag, idService) {
return varBag.optionsJSONVar.value;
}
},
"qte48ulcHEm1lakFOQhkMA": {
getter: function (varBag, idService) {
return varBag.initializeJSResult.value;
}
},
"830khvm+ZkyQK9FSvIZizA": {
getter: function (varBag, idService) {
return varBag.vars.value.currentDateInfoInLocal;
}
},
"QW1I0C76PEajgXfJxE+a0g": {
getter: function (varBag, idService) {
return varBag.model.variables.objVar;
},
dataType: OS.DataTypes.DataTypes.Object
},
"wj7URb3iU0q_3CZwTRUJHw": {
getter: function (varBag, idService) {
return varBag.model.variables.cardVar;
}
},
"DNFTnBYUkU+zjZBwZZ6O4A": {
getter: function (varBag, idService) {
return varBag.model.variables.optionsIn;
}
},
"ZO4LJPWTV0+iHJSGKEZPiQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Element"));
})(varBag.model, idService);
}
},
"vRhul74C6E+o9OK3ClWgYQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input"));
})(varBag.model, idService);
}
},
"ZTSRNvyStk+_eprLKXnk_Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Label"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
