define("ShopperPortalEU.model$CustomListItemOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomListItemOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomListItemOptionsRecord = (function (_super) {
__extends(CustomListItemOptionsRecord, _super);
function CustomListItemOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomListItemOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomListItemOptions", "customListItemOptionsAttr", "CustomListItemOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomListItemOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomListItemOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomListItemOptionsRecord.fromStructure = function (str) {
return new CustomListItemOptionsRecord(new CustomListItemOptionsRecord.RecordClass({
customListItemOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomListItemOptionsRecord._isAnonymousRecord = true;
CustomListItemOptionsRecord.UniqueId = "00254d6f-7d70-27ff-8218-83d7da5437ac";
CustomListItemOptionsRecord.init();
return CustomListItemOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomListItemOptionsRecord = CustomListItemOptionsRecord;

});
define("ShopperPortalEU.model$ResponseRecord", ["exports", "OutSystems/ClientRuntime/Main", "reCAPTCHAReact.model", "ShopperPortalEU.model", "reCAPTCHAReact.model$ResponseRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$reCAPTCHAReact"], function (exports, OutSystems, reCAPTCHAReactModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var ResponseRecord = (function (_super) {
__extends(ResponseRecord, _super);
function ResponseRecord(defaults) {
_super.apply(this, arguments);
}
ResponseRecord.attributesToDeclare = function () {
return [
this.attr("Response", "responseAttr", "Response", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new reCAPTCHAReactModel.ResponseRec());
}, true, reCAPTCHAReactModel.ResponseRec)
].concat(_super.attributesToDeclare.call(this));
};
ResponseRecord.fromStructure = function (str) {
return new ResponseRecord(new ResponseRecord.RecordClass({
responseAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ResponseRecord._isAnonymousRecord = true;
ResponseRecord.UniqueId = "0079cc54-4607-cccf-549c-9c3a1d20eaf6";
ResponseRecord.init();
return ResponseRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.ResponseRecord = ResponseRecord;

});
define("ShopperPortalEU.model$RefundDetails_Wrapper2Record", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU.model", "ShopperPortalEU_Forms_IS.model$RefundDetails_WrapperRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Forms_IS"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var RefundDetails_Wrapper2Record = (function (_super) {
__extends(RefundDetails_Wrapper2Record, _super);
function RefundDetails_Wrapper2Record(defaults) {
_super.apply(this, arguments);
}
RefundDetails_Wrapper2Record.attributesToDeclare = function () {
return [
this.attr("RefundDetails_Wrapper", "refundDetails_WrapperAttr", "RefundDetails_Wrapper2", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Forms_ISModel.RefundDetails_WrapperRec());
}, true, ShopperPortalEU_Forms_ISModel.RefundDetails_WrapperRec)
].concat(_super.attributesToDeclare.call(this));
};
RefundDetails_Wrapper2Record.fromStructure = function (str) {
return new RefundDetails_Wrapper2Record(new RefundDetails_Wrapper2Record.RecordClass({
refundDetails_WrapperAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
RefundDetails_Wrapper2Record._isAnonymousRecord = true;
RefundDetails_Wrapper2Record.UniqueId = "be72198d-7a64-8e63-e860-8ca3ce8a9205";
RefundDetails_Wrapper2Record.init();
return RefundDetails_Wrapper2Record;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.RefundDetails_Wrapper2Record = RefundDetails_Wrapper2Record;

});
define("ShopperPortalEU.model$RefundDetails_Wrapper2RecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$RefundDetails_Wrapper2Record"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var RefundDetails_Wrapper2RecordList = (function (_super) {
__extends(RefundDetails_Wrapper2RecordList, _super);
function RefundDetails_Wrapper2RecordList(defaults) {
_super.apply(this, arguments);
}
RefundDetails_Wrapper2RecordList.itemType = ShopperPortalEUModel.RefundDetails_Wrapper2Record;
return RefundDetails_Wrapper2RecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.RefundDetails_Wrapper2RecordList = RefundDetails_Wrapper2RecordList;

});
define("ShopperPortalEU.model$CustomListItemClickableOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomListItemClickableOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomListItemClickableOptionsList = (function (_super) {
__extends(CustomListItemClickableOptionsList, _super);
function CustomListItemClickableOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomListItemClickableOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomListItemClickableOptionsRec;
return CustomListItemClickableOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomListItemClickableOptionsList = CustomListItemClickableOptionsList;

});
define("ShopperPortalEU.model$ScanBarcodeErrorList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$ScanBarcodeErrorRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var ScanBarcodeErrorList = (function (_super) {
__extends(ScanBarcodeErrorList, _super);
function ScanBarcodeErrorList(defaults) {
_super.apply(this, arguments);
}
ScanBarcodeErrorList.itemType = ShopperPortalEU_UI_ComponentsModel.ScanBarcodeErrorRec;
return ScanBarcodeErrorList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.ScanBarcodeErrorList = ScanBarcodeErrorList;

});
define("ShopperPortalEU.model$PhoneNumberInputChangeOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$PhoneNumberInputChangeOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var PhoneNumberInputChangeOptionsList = (function (_super) {
__extends(PhoneNumberInputChangeOptionsList, _super);
function PhoneNumberInputChangeOptionsList(defaults) {
_super.apply(this, arguments);
}
PhoneNumberInputChangeOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputChangeOptionsRec;
return PhoneNumberInputChangeOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.PhoneNumberInputChangeOptionsList = PhoneNumberInputChangeOptionsList;

});
define("ShopperPortalEU.model$CustomTagOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomTagOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomTagOptionsList = (function (_super) {
__extends(CustomTagOptionsList, _super);
function CustomTagOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomTagOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomTagOptionsRec;
return CustomTagOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomTagOptionsList = CustomTagOptionsList;

});
define("ShopperPortalEU.model$CustomLinkOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomLinkOptionsList = (function (_super) {
__extends(CustomLinkOptionsList, _super);
function CustomLinkOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomLinkOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomLinkOptionsRec;
return CustomLinkOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomLinkOptionsList = CustomLinkOptionsList;

});
define("ShopperPortalEU.model$CustomDropdownListValidationOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomDropdownListValidationOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomDropdownListValidationOptionsRecord = (function (_super) {
__extends(CustomDropdownListValidationOptionsRecord, _super);
function CustomDropdownListValidationOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomDropdownListValidationOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomDropdownListValidationOptions", "customDropdownListValidationOptionsAttr", "CustomDropdownListValidationOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValidationOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValidationOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomDropdownListValidationOptionsRecord.fromStructure = function (str) {
return new CustomDropdownListValidationOptionsRecord(new CustomDropdownListValidationOptionsRecord.RecordClass({
customDropdownListValidationOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomDropdownListValidationOptionsRecord._isAnonymousRecord = true;
CustomDropdownListValidationOptionsRecord.UniqueId = "03c542a1-666f-a38b-797e-c900dd937fce";
CustomDropdownListValidationOptionsRecord.init();
return CustomDropdownListValidationOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomDropdownListValidationOptionsRecord = CustomDropdownListValidationOptionsRecord;

});
define("ShopperPortalEU.model$ProgressBarOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$ProgressBarOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var ProgressBarOptionsRecord = (function (_super) {
__extends(ProgressBarOptionsRecord, _super);
function ProgressBarOptionsRecord(defaults) {
_super.apply(this, arguments);
}
ProgressBarOptionsRecord.attributesToDeclare = function () {
return [
this.attr("ProgressBarOptions", "progressBarOptionsAttr", "ProgressBarOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.ProgressBarOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.ProgressBarOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
ProgressBarOptionsRecord.fromStructure = function (str) {
return new ProgressBarOptionsRecord(new ProgressBarOptionsRecord.RecordClass({
progressBarOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ProgressBarOptionsRecord._isAnonymousRecord = true;
ProgressBarOptionsRecord.UniqueId = "1700a48e-e34c-4f19-2a0c-cbcc96f0afed";
ProgressBarOptionsRecord.init();
return ProgressBarOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.ProgressBarOptionsRecord = ProgressBarOptionsRecord;

});
define("ShopperPortalEU.model$ProgressBarOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$ProgressBarOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var ProgressBarOptionsRecordList = (function (_super) {
__extends(ProgressBarOptionsRecordList, _super);
function ProgressBarOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
ProgressBarOptionsRecordList.itemType = ShopperPortalEUModel.ProgressBarOptionsRecord;
return ProgressBarOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.ProgressBarOptionsRecordList = ProgressBarOptionsRecordList;

});
define("ShopperPortalEU.model$AnonymousFormAddList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU.model", "ShopperPortalEU_Forms_IS.model$AnonymousFormAddRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Forms_IS"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var AnonymousFormAddList = (function (_super) {
__extends(AnonymousFormAddList, _super);
function AnonymousFormAddList(defaults) {
_super.apply(this, arguments);
}
AnonymousFormAddList.itemType = ShopperPortalEU_Forms_ISModel.AnonymousFormAddRec;
return AnonymousFormAddList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.AnonymousFormAddList = AnonymousFormAddList;

});
define("ShopperPortalEU.model$CustomCarouselOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomCarouselOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomCarouselOptionsRecord = (function (_super) {
__extends(CustomCarouselOptionsRecord, _super);
function CustomCarouselOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomCarouselOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomCarouselOptions", "customCarouselOptionsAttr", "CustomCarouselOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomCarouselOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomCarouselOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomCarouselOptionsRecord.fromStructure = function (str) {
return new CustomCarouselOptionsRecord(new CustomCarouselOptionsRecord.RecordClass({
customCarouselOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomCarouselOptionsRecord._isAnonymousRecord = true;
CustomCarouselOptionsRecord.UniqueId = "04f946c7-498b-8efa-b431-1a3e2da81bc7";
CustomCarouselOptionsRecord.init();
return CustomCarouselOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomCarouselOptionsRecord = CustomCarouselOptionsRecord;

});
define("ShopperPortalEU.model$FormShopperDetailDTORec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var FormShopperDetailDTORec = (function (_super) {
__extends(FormShopperDetailDTORec, _super);
function FormShopperDetailDTORec(defaults) {
_super.apply(this, arguments);
}
FormShopperDetailDTORec.attributesToDeclare = function () {
return [
this.attr("Title", "titleAttr", "title", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("FirstName", "firstNameAttr", "firstName", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("LastName", "lastNameAttr", "lastName", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("AddressLineOne", "addressLineOneAttr", "addressLineOne", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("AddressLineTwo", "addressLineTwoAttr", "addressLineTwo", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Region", "regionAttr", "region", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("City", "cityAttr", "city", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("PostCode", "postCodeAttr", "postCode", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Email", "emailAttr", "email", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("MobileNumber", "mobileNumberAttr", "mobileNumber", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("DateOfBirth", "dateOfBirthAttr", "dateOfBirth", false, false, OS.DataTypes.DataTypes.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("TaxIdentifierNumber", "taxIdentifierNumberAttr", "taxIdentifierNumber", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("CountryOfResidenceIso", "countryOfResidenceIsoAttr", "countryOfResidenceIso", false, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true), 
this.attr("CountryOfResidenceTerritoryCode", "countryOfResidenceTerritoryCodeAttr", "countryOfResidenceTerritoryCode", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("NationalityIso", "nationalityIsoAttr", "nationalityIso", false, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true), 
this.attr("TravelDocumentType", "travelDocumentTypeAttr", "travelDocumentType", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("TravelDocumentNumber", "travelDocumentNumberAttr", "travelDocumentNumber", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("TravelDocumentIssuedByIso", "travelDocumentIssuedByIsoAttr", "travelDocumentIssuedByIso", false, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true), 
this.attr("TravelDocumentExpirationDate", "travelDocumentExpirationDateAttr", "travelDocumentExpirationDate", false, false, OS.DataTypes.DataTypes.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
FormShopperDetailDTORec.init();
return FormShopperDetailDTORec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.FormShopperDetailDTORec = FormShopperDetailDTORec;

});
define("ShopperPortalEU.model$MerchantLocationDTORec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var MerchantLocationDTORec = (function (_super) {
__extends(MerchantLocationDTORec, _super);
function MerchantLocationDTORec(defaults) {
_super.apply(this, arguments);
}
MerchantLocationDTORec.attributesToDeclare = function () {
return [
this.attr("MerchantName", "merchantNameAttr", "merchantName", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("MerchantCity", "merchantCityAttr", "merchantCity", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("MerchantCountry", "merchantCountryAttr", "merchantCountry", false, false, OS.DataTypes.DataTypes.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("HeadOfficeName", "headOfficeNameAttr", "headOfficeName", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
MerchantLocationDTORec.init();
return MerchantLocationDTORec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.MerchantLocationDTORec = MerchantLocationDTORec;

});
define("ShopperPortalEU.model$FormDetailsDTORec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$FormShopperDetailDTORec", "ShopperPortalEU.model$MerchantLocationDTORec"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var FormDetailsDTORec = (function (_super) {
__extends(FormDetailsDTORec, _super);
function FormDetailsDTORec(defaults) {
_super.apply(this, arguments);
}
FormDetailsDTORec.attributesToDeclare = function () {
return [
this.attr("FormNumber", "formNumberAttr", "formNumber", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("FormIssuedDateTime", "formIssuedDateTimeAttr", "formIssuedDateTime", false, false, OS.DataTypes.DataTypes.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("EstimatedRefundAmount", "estimatedRefundAmountAttr", "estimatedRefundAmount", false, false, OS.DataTypes.DataTypes.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("VatAmount", "vatAmountAttr", "vatAmount", false, false, OS.DataTypes.DataTypes.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("TotalAmount", "totalAmountAttr", "totalAmount", false, false, OS.DataTypes.DataTypes.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("CurrencyIso", "currencyIsoAttr", "currencyIso", false, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true), 
this.attr("CombinedFormStatus", "combinedFormStatusAttr", "combinedFormStatus", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("RefundFlow", "refundFlowAttr", "refundFlow", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("FormShopperDetails", "formShopperDetailsAttr", "formShopperDetails", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEUModel.FormShopperDetailDTORec());
}, true, ShopperPortalEUModel.FormShopperDetailDTORec), 
this.attr("MerchantLocation", "merchantLocationAttr", "merchantLocation", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEUModel.MerchantLocationDTORec());
}, true, ShopperPortalEUModel.MerchantLocationDTORec)
].concat(_super.attributesToDeclare.call(this));
};
FormDetailsDTORec.init();
return FormDetailsDTORec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.FormDetailsDTORec = FormDetailsDTORec;

});
define("ShopperPortalEU.model$FormDetailsDTORecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$FormDetailsDTORec"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var FormDetailsDTORecord = (function (_super) {
__extends(FormDetailsDTORecord, _super);
function FormDetailsDTORecord(defaults) {
_super.apply(this, arguments);
}
FormDetailsDTORecord.attributesToDeclare = function () {
return [
this.attr("FormDetailsDTO", "formDetailsDTOAttr", "FormDetailsDTO", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEUModel.FormDetailsDTORec());
}, true, ShopperPortalEUModel.FormDetailsDTORec)
].concat(_super.attributesToDeclare.call(this));
};
FormDetailsDTORecord.fromStructure = function (str) {
return new FormDetailsDTORecord(new FormDetailsDTORecord.RecordClass({
formDetailsDTOAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
FormDetailsDTORecord._isAnonymousRecord = true;
FormDetailsDTORecord.UniqueId = "94f09972-39d7-4e29-8efb-bf2c0a793ae0";
FormDetailsDTORecord.init();
return FormDetailsDTORecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.FormDetailsDTORecord = FormDetailsDTORecord;

});
define("ShopperPortalEU.model$FormDetailsDTORecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$FormDetailsDTORecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var FormDetailsDTORecordList = (function (_super) {
__extends(FormDetailsDTORecordList, _super);
function FormDetailsDTORecordList(defaults) {
_super.apply(this, arguments);
}
FormDetailsDTORecordList.itemType = ShopperPortalEUModel.FormDetailsDTORecord;
return FormDetailsDTORecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.FormDetailsDTORecordList = FormDetailsDTORecordList;

});
define("ShopperPortalEU.model$OpenPDFOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$OpenPDFOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var OpenPDFOptionsRecord = (function (_super) {
__extends(OpenPDFOptionsRecord, _super);
function OpenPDFOptionsRecord(defaults) {
_super.apply(this, arguments);
}
OpenPDFOptionsRecord.attributesToDeclare = function () {
return [
this.attr("OpenPDFOptions", "openPDFOptionsAttr", "OpenPDFOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.OpenPDFOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.OpenPDFOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
OpenPDFOptionsRecord.fromStructure = function (str) {
return new OpenPDFOptionsRecord(new OpenPDFOptionsRecord.RecordClass({
openPDFOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
OpenPDFOptionsRecord._isAnonymousRecord = true;
OpenPDFOptionsRecord.UniqueId = "05a0130e-844c-1ea6-7927-9b822b1d1325";
OpenPDFOptionsRecord.init();
return OpenPDFOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.OpenPDFOptionsRecord = OpenPDFOptionsRecord;

});
define("ShopperPortalEU.model$CustomButtonStateList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomButtonStateRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomButtonStateList = (function (_super) {
__extends(CustomButtonStateList, _super);
function CustomButtonStateList(defaults) {
_super.apply(this, arguments);
}
CustomButtonStateList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomButtonStateRec;
return CustomButtonStateList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomButtonStateList = CustomButtonStateList;

});
define("ShopperPortalEU.model$RefundPoint_WrapperRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_API.model", "ShopperPortalEU.model", "ShopperPortalEU_API.model$RefundPoint_WrapperRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_API"], function (exports, OutSystems, ShopperPortalEU_APIModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var RefundPoint_WrapperRecord = (function (_super) {
__extends(RefundPoint_WrapperRecord, _super);
function RefundPoint_WrapperRecord(defaults) {
_super.apply(this, arguments);
}
RefundPoint_WrapperRecord.attributesToDeclare = function () {
return [
this.attr("RefundPoint_Wrapper", "refundPoint_WrapperAttr", "RefundPoint_Wrapper", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_APIModel.RefundPoint_WrapperRec());
}, true, ShopperPortalEU_APIModel.RefundPoint_WrapperRec)
].concat(_super.attributesToDeclare.call(this));
};
RefundPoint_WrapperRecord.fromStructure = function (str) {
return new RefundPoint_WrapperRecord(new RefundPoint_WrapperRecord.RecordClass({
refundPoint_WrapperAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
RefundPoint_WrapperRecord._isAnonymousRecord = true;
RefundPoint_WrapperRecord.UniqueId = "06bda020-bf0a-15ae-3870-6d05dcc24904";
RefundPoint_WrapperRecord.init();
return RefundPoint_WrapperRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.RefundPoint_WrapperRecord = RefundPoint_WrapperRecord;

});
define("ShopperPortalEU.model$LayoutOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Theme.model$LayoutOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var LayoutOptionsRecord = (function (_super) {
__extends(LayoutOptionsRecord, _super);
function LayoutOptionsRecord(defaults) {
_super.apply(this, arguments);
}
LayoutOptionsRecord.attributesToDeclare = function () {
return [
this.attr("LayoutOptions", "layoutOptionsAttr", "LayoutOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ThemeModel.LayoutOptionsRec());
}, true, ShopperPortalEU_UI_ThemeModel.LayoutOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
LayoutOptionsRecord.fromStructure = function (str) {
return new LayoutOptionsRecord(new LayoutOptionsRecord.RecordClass({
layoutOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
LayoutOptionsRecord._isAnonymousRecord = true;
LayoutOptionsRecord.UniqueId = "07362bcd-ed8f-6d3b-4659-f4beee778163";
LayoutOptionsRecord.init();
return LayoutOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.LayoutOptionsRecord = LayoutOptionsRecord;

});
define("ShopperPortalEU.model$CreateCardDataList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU.model", "ShopperPortalEU_Shopper_IS.model$CreateCardDataRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CreateCardDataList = (function (_super) {
__extends(CreateCardDataList, _super);
function CreateCardDataList(defaults) {
_super.apply(this, arguments);
}
CreateCardDataList.itemType = ShopperPortalEU_Shopper_ISModel.CreateCardDataRec;
return CreateCardDataList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CreateCardDataList = CreateCardDataList;

});
define("ShopperPortalEU.model$CardStateOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CardStateOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CardStateOptionsRecord = (function (_super) {
__extends(CardStateOptionsRecord, _super);
function CardStateOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CardStateOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CardStateOptions", "cardStateOptionsAttr", "CardStateOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CardStateOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CardStateOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CardStateOptionsRecord.fromStructure = function (str) {
return new CardStateOptionsRecord(new CardStateOptionsRecord.RecordClass({
cardStateOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CardStateOptionsRecord._isAnonymousRecord = true;
CardStateOptionsRecord.UniqueId = "68932cad-17b9-73cf-5bdb-acde7e3be66f";
CardStateOptionsRecord.init();
return CardStateOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CardStateOptionsRecord = CardStateOptionsRecord;

});
define("ShopperPortalEU.model$CardStateOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CardStateOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CardStateOptionsRecordList = (function (_super) {
__extends(CardStateOptionsRecordList, _super);
function CardStateOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CardStateOptionsRecordList.itemType = ShopperPortalEUModel.CardStateOptionsRecord;
return CardStateOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CardStateOptionsRecordList = CardStateOptionsRecordList;

});
define("ShopperPortalEU.model$BooleanBooleanRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var BooleanBooleanRecord = (function (_super) {
__extends(BooleanBooleanRecord, _super);
function BooleanBooleanRecord(defaults) {
_super.apply(this, arguments);
}
BooleanBooleanRecord.attributesToDeclare = function () {
return [
this.attr("AddCreditCard", "addCreditCardAttr", "AddCreditCard", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("ShowProfile", "showProfileAttr", "ShowProfile", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
BooleanBooleanRecord._isAnonymousRecord = true;
BooleanBooleanRecord.UniqueId = "146a2f5f-425b-dcb5-e611-992983f9b693";
BooleanBooleanRecord.init();
return BooleanBooleanRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.BooleanBooleanRecord = BooleanBooleanRecord;

});
define("ShopperPortalEU.model$BooleanBooleanRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$BooleanBooleanRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var BooleanBooleanRecordList = (function (_super) {
__extends(BooleanBooleanRecordList, _super);
function BooleanBooleanRecordList(defaults) {
_super.apply(this, arguments);
}
BooleanBooleanRecordList.itemType = ShopperPortalEUModel.BooleanBooleanRecord;
return BooleanBooleanRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.BooleanBooleanRecordList = BooleanBooleanRecordList;

});
define("ShopperPortalEU.model$CustomDropdownSearchOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomDropdownSearchOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomDropdownSearchOptionsRecord = (function (_super) {
__extends(CustomDropdownSearchOptionsRecord, _super);
function CustomDropdownSearchOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomDropdownSearchOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomDropdownSearchOptions", "customDropdownSearchOptionsAttr", "CustomDropdownSearchOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomDropdownSearchOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomDropdownSearchOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomDropdownSearchOptionsRecord.fromStructure = function (str) {
return new CustomDropdownSearchOptionsRecord(new CustomDropdownSearchOptionsRecord.RecordClass({
customDropdownSearchOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomDropdownSearchOptionsRecord._isAnonymousRecord = true;
CustomDropdownSearchOptionsRecord.UniqueId = "1983924b-5f5d-c36b-652c-58ae05f45c86";
CustomDropdownSearchOptionsRecord.init();
return CustomDropdownSearchOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomDropdownSearchOptionsRecord = CustomDropdownSearchOptionsRecord;

});
define("ShopperPortalEU.model$CustomDropdownSearchOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomDropdownSearchOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomDropdownSearchOptionsRecordList = (function (_super) {
__extends(CustomDropdownSearchOptionsRecordList, _super);
function CustomDropdownSearchOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownSearchOptionsRecordList.itemType = ShopperPortalEUModel.CustomDropdownSearchOptionsRecord;
return CustomDropdownSearchOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomDropdownSearchOptionsRecordList = CustomDropdownSearchOptionsRecordList;

});
define("ShopperPortalEU.model$CustomButtonGroupOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomButtonGroupOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomButtonGroupOptionsRecord = (function (_super) {
__extends(CustomButtonGroupOptionsRecord, _super);
function CustomButtonGroupOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomButtonGroupOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomButtonGroupOptions", "customButtonGroupOptionsAttr", "CustomButtonGroupOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomButtonGroupOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomButtonGroupOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomButtonGroupOptionsRecord.fromStructure = function (str) {
return new CustomButtonGroupOptionsRecord(new CustomButtonGroupOptionsRecord.RecordClass({
customButtonGroupOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomButtonGroupOptionsRecord._isAnonymousRecord = true;
CustomButtonGroupOptionsRecord.UniqueId = "7ea98077-35c9-1190-eff4-794483f83713";
CustomButtonGroupOptionsRecord.init();
return CustomButtonGroupOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomButtonGroupOptionsRecord = CustomButtonGroupOptionsRecord;

});
define("ShopperPortalEU.model$CustomButtonGroupOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomButtonGroupOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomButtonGroupOptionsRecordList = (function (_super) {
__extends(CustomButtonGroupOptionsRecordList, _super);
function CustomButtonGroupOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomButtonGroupOptionsRecordList.itemType = ShopperPortalEUModel.CustomButtonGroupOptionsRecord;
return CustomButtonGroupOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomButtonGroupOptionsRecordList = CustomButtonGroupOptionsRecordList;

});
define("ShopperPortalEU.model$CustomAlertTypeRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomAlertTypeRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomAlertTypeRecord = (function (_super) {
__extends(CustomAlertTypeRecord, _super);
function CustomAlertTypeRecord(defaults) {
_super.apply(this, arguments);
}
CustomAlertTypeRecord.attributesToDeclare = function () {
return [
this.attr("CustomAlertType", "customAlertTypeAttr", "CustomAlertType", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomAlertTypeRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomAlertTypeRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomAlertTypeRecord.fromStructure = function (str) {
return new CustomAlertTypeRecord(new CustomAlertTypeRecord.RecordClass({
customAlertTypeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomAlertTypeRecord._isAnonymousRecord = true;
CustomAlertTypeRecord.UniqueId = "bd432fd8-7b42-5fb5-77f5-3529eb02b994";
CustomAlertTypeRecord.init();
return CustomAlertTypeRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomAlertTypeRecord = CustomAlertTypeRecord;

});
define("ShopperPortalEU.model$CustomAlertTypeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomAlertTypeRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomAlertTypeRecordList = (function (_super) {
__extends(CustomAlertTypeRecordList, _super);
function CustomAlertTypeRecordList(defaults) {
_super.apply(this, arguments);
}
CustomAlertTypeRecordList.itemType = ShopperPortalEUModel.CustomAlertTypeRecord;
return CustomAlertTypeRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomAlertTypeRecordList = CustomAlertTypeRecordList;

});
define("ShopperPortalEU.model$PaddingSideOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$PaddingSideOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var PaddingSideOptionsList = (function (_super) {
__extends(PaddingSideOptionsList, _super);
function PaddingSideOptionsList(defaults) {
_super.apply(this, arguments);
}
PaddingSideOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.PaddingSideOptionsRec;
return PaddingSideOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.PaddingSideOptionsList = PaddingSideOptionsList;

});
define("ShopperPortalEU.model$AnonymousFormsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var AnonymousFormsRec = (function (_super) {
__extends(AnonymousFormsRec, _super);
function AnonymousFormsRec(defaults) {
_super.apply(this, arguments);
}
AnonymousFormsRec.attributesToDeclare = function () {
return [
this.attr("FormNumber", "formNumberAttr", "FormNumber", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("AttempNr", "attempNrAttr", "AttempNr", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
AnonymousFormsRec.init();
return AnonymousFormsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.AnonymousFormsRec = AnonymousFormsRec;

});
define("ShopperPortalEU.model$AnonymousFormsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$AnonymousFormsRec"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var AnonymousFormsList = (function (_super) {
__extends(AnonymousFormsList, _super);
function AnonymousFormsList(defaults) {
_super.apply(this, arguments);
}
AnonymousFormsList.itemType = ShopperPortalEUModel.AnonymousFormsRec;
return AnonymousFormsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.AnonymousFormsList = AnonymousFormsList;

});
define("ShopperPortalEU.model$CustomLinkStateList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomLinkStateRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomLinkStateList = (function (_super) {
__extends(CustomLinkStateList, _super);
function CustomLinkStateList(defaults) {
_super.apply(this, arguments);
}
CustomLinkStateList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomLinkStateRec;
return CustomLinkStateList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomLinkStateList = CustomLinkStateList;

});
define("ShopperPortalEU.model$LoginOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Theme.model$LoginOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var LoginOptionsRecord = (function (_super) {
__extends(LoginOptionsRecord, _super);
function LoginOptionsRecord(defaults) {
_super.apply(this, arguments);
}
LoginOptionsRecord.attributesToDeclare = function () {
return [
this.attr("LoginOptions", "loginOptionsAttr", "LoginOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ThemeModel.LoginOptionsRec());
}, true, ShopperPortalEU_UI_ThemeModel.LoginOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
LoginOptionsRecord.fromStructure = function (str) {
return new LoginOptionsRecord(new LoginOptionsRecord.RecordClass({
loginOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
LoginOptionsRecord._isAnonymousRecord = true;
LoginOptionsRecord.UniqueId = "73bf135b-8221-5e22-5ac6-9f0e87748f9a";
LoginOptionsRecord.init();
return LoginOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.LoginOptionsRecord = LoginOptionsRecord;

});
define("ShopperPortalEU.model$LoginOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$LoginOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var LoginOptionsRecordList = (function (_super) {
__extends(LoginOptionsRecordList, _super);
function LoginOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
LoginOptionsRecordList.itemType = ShopperPortalEUModel.LoginOptionsRecord;
return LoginOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.LoginOptionsRecordList = LoginOptionsRecordList;

});
define("ShopperPortalEU.model$HeaderActionItemIconOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Theme.model$HeaderActionItemIconOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var HeaderActionItemIconOptionsRecord = (function (_super) {
__extends(HeaderActionItemIconOptionsRecord, _super);
function HeaderActionItemIconOptionsRecord(defaults) {
_super.apply(this, arguments);
}
HeaderActionItemIconOptionsRecord.attributesToDeclare = function () {
return [
this.attr("HeaderActionItemIconOptions", "headerActionItemIconOptionsAttr", "HeaderActionItemIconOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ThemeModel.HeaderActionItemIconOptionsRec());
}, true, ShopperPortalEU_UI_ThemeModel.HeaderActionItemIconOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
HeaderActionItemIconOptionsRecord.fromStructure = function (str) {
return new HeaderActionItemIconOptionsRecord(new HeaderActionItemIconOptionsRecord.RecordClass({
headerActionItemIconOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
HeaderActionItemIconOptionsRecord._isAnonymousRecord = true;
HeaderActionItemIconOptionsRecord.UniqueId = "9eef586a-beba-296c-63b9-4c28ac393f32";
HeaderActionItemIconOptionsRecord.init();
return HeaderActionItemIconOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.HeaderActionItemIconOptionsRecord = HeaderActionItemIconOptionsRecord;

});
define("ShopperPortalEU.model$HeaderActionItemIconOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$HeaderActionItemIconOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var HeaderActionItemIconOptionsRecordList = (function (_super) {
__extends(HeaderActionItemIconOptionsRecordList, _super);
function HeaderActionItemIconOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
HeaderActionItemIconOptionsRecordList.itemType = ShopperPortalEUModel.HeaderActionItemIconOptionsRecord;
return HeaderActionItemIconOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.HeaderActionItemIconOptionsRecordList = HeaderActionItemIconOptionsRecordList;

});
define("ShopperPortalEU.model$CustomDropdownListOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomDropdownListOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomDropdownListOptionsRecord = (function (_super) {
__extends(CustomDropdownListOptionsRecord, _super);
function CustomDropdownListOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomDropdownListOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomDropdownListOptions", "customDropdownListOptionsAttr", "CustomDropdownListOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomDropdownListOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomDropdownListOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomDropdownListOptionsRecord.fromStructure = function (str) {
return new CustomDropdownListOptionsRecord(new CustomDropdownListOptionsRecord.RecordClass({
customDropdownListOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomDropdownListOptionsRecord._isAnonymousRecord = true;
CustomDropdownListOptionsRecord.UniqueId = "b077a351-3174-f1d2-c45d-d1fda0d55b93";
CustomDropdownListOptionsRecord.init();
return CustomDropdownListOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomDropdownListOptionsRecord = CustomDropdownListOptionsRecord;

});
define("ShopperPortalEU.model$CustomDropdownListOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomDropdownListOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomDropdownListOptionsRecordList = (function (_super) {
__extends(CustomDropdownListOptionsRecordList, _super);
function CustomDropdownListOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownListOptionsRecordList.itemType = ShopperPortalEUModel.CustomDropdownListOptionsRecord;
return CustomDropdownListOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomDropdownListOptionsRecordList = CustomDropdownListOptionsRecordList;

});
define("ShopperPortalEU.model$PhoneNumberInputCountryOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$PhoneNumberInputCountryOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var PhoneNumberInputCountryOptionsRecord = (function (_super) {
__extends(PhoneNumberInputCountryOptionsRecord, _super);
function PhoneNumberInputCountryOptionsRecord(defaults) {
_super.apply(this, arguments);
}
PhoneNumberInputCountryOptionsRecord.attributesToDeclare = function () {
return [
this.attr("PhoneNumberInputCountryOptions", "phoneNumberInputCountryOptionsAttr", "PhoneNumberInputCountryOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputCountryOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputCountryOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
PhoneNumberInputCountryOptionsRecord.fromStructure = function (str) {
return new PhoneNumberInputCountryOptionsRecord(new PhoneNumberInputCountryOptionsRecord.RecordClass({
phoneNumberInputCountryOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
PhoneNumberInputCountryOptionsRecord._isAnonymousRecord = true;
PhoneNumberInputCountryOptionsRecord.UniqueId = "0cecba8f-7930-b607-0579-4771472db3ba";
PhoneNumberInputCountryOptionsRecord.init();
return PhoneNumberInputCountryOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.PhoneNumberInputCountryOptionsRecord = PhoneNumberInputCountryOptionsRecord;

});
define("ShopperPortalEU.model$PaddingRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$PaddingRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var PaddingRecord = (function (_super) {
__extends(PaddingRecord, _super);
function PaddingRecord(defaults) {
_super.apply(this, arguments);
}
PaddingRecord.attributesToDeclare = function () {
return [
this.attr("Padding", "paddingAttr", "Padding", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.PaddingRec());
}, true, ShopperPortalEU_UI_ComponentsModel.PaddingRec)
].concat(_super.attributesToDeclare.call(this));
};
PaddingRecord.fromStructure = function (str) {
return new PaddingRecord(new PaddingRecord.RecordClass({
paddingAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
PaddingRecord._isAnonymousRecord = true;
PaddingRecord.UniqueId = "ca8a7587-d77b-ee35-aa61-5af66f82ccce";
PaddingRecord.init();
return PaddingRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.PaddingRecord = PaddingRecord;

});
define("ShopperPortalEU.model$PaddingRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$PaddingRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var PaddingRecordList = (function (_super) {
__extends(PaddingRecordList, _super);
function PaddingRecordList(defaults) {
_super.apply(this, arguments);
}
PaddingRecordList.itemType = ShopperPortalEUModel.PaddingRecord;
return PaddingRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.PaddingRecordList = PaddingRecordList;

});
define("ShopperPortalEU.model$TextRecord", ["exports", "OutSystems/ClientRuntime/Main", "Extension.Text.model", "ShopperPortalEU.model", "Extension.Text.model$TextRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$Text"], function (exports, OutSystems, Extension_TextModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var TextRecord = (function (_super) {
__extends(TextRecord, _super);
function TextRecord(defaults) {
_super.apply(this, arguments);
}
TextRecord.attributesToDeclare = function () {
return [
this.attr("Text", "textAttr", "Text", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new Extension_TextModel.TextRec());
}, true, Extension_TextModel.TextRec)
].concat(_super.attributesToDeclare.call(this));
};
TextRecord.fromStructure = function (str) {
return new TextRecord(new TextRecord.RecordClass({
textAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
TextRecord._isAnonymousRecord = true;
TextRecord.UniqueId = "0d84b59e-ff89-87c4-71ae-b49dfa9f2c39";
TextRecord.init();
return TextRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.TextRecord = TextRecord;

});
define("ShopperPortalEU.model$CustomButtonOptionsIconRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomButtonOptionsIconRecord = (function (_super) {
__extends(CustomButtonOptionsIconRecord, _super);
function CustomButtonOptionsIconRecord(defaults) {
_super.apply(this, arguments);
}
CustomButtonOptionsIconRecord.attributesToDeclare = function () {
return [
this.attr("CustomButtonOptionsIcon", "customButtonOptionsIconAttr", "CustomButtonOptionsIcon", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsIconRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsIconRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomButtonOptionsIconRecord.fromStructure = function (str) {
return new CustomButtonOptionsIconRecord(new CustomButtonOptionsIconRecord.RecordClass({
customButtonOptionsIconAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomButtonOptionsIconRecord._isAnonymousRecord = true;
CustomButtonOptionsIconRecord.UniqueId = "95ac214c-4bbb-93aa-a566-93e12ce167e0";
CustomButtonOptionsIconRecord.init();
return CustomButtonOptionsIconRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomButtonOptionsIconRecord = CustomButtonOptionsIconRecord;

});
define("ShopperPortalEU.model$CustomButtonOptionsIconRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomButtonOptionsIconRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomButtonOptionsIconRecordList = (function (_super) {
__extends(CustomButtonOptionsIconRecordList, _super);
function CustomButtonOptionsIconRecordList(defaults) {
_super.apply(this, arguments);
}
CustomButtonOptionsIconRecordList.itemType = ShopperPortalEUModel.CustomButtonOptionsIconRecord;
return CustomButtonOptionsIconRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomButtonOptionsIconRecordList = CustomButtonOptionsIconRecordList;

});
define("ShopperPortalEU.model$CustomMessageTypeList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Theme.model$CustomMessageTypeRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomMessageTypeList = (function (_super) {
__extends(CustomMessageTypeList, _super);
function CustomMessageTypeList(defaults) {
_super.apply(this, arguments);
}
CustomMessageTypeList.itemType = ShopperPortalEU_UI_ThemeModel.CustomMessageTypeRec;
return CustomMessageTypeList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomMessageTypeList = CustomMessageTypeList;

});
define("ShopperPortalEU.model$DatePickerLabelOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$DatePickerLabelOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var DatePickerLabelOptionsRecord = (function (_super) {
__extends(DatePickerLabelOptionsRecord, _super);
function DatePickerLabelOptionsRecord(defaults) {
_super.apply(this, arguments);
}
DatePickerLabelOptionsRecord.attributesToDeclare = function () {
return [
this.attr("DatePickerLabelOptions", "datePickerLabelOptionsAttr", "DatePickerLabelOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.DatePickerLabelOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.DatePickerLabelOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
DatePickerLabelOptionsRecord.fromStructure = function (str) {
return new DatePickerLabelOptionsRecord(new DatePickerLabelOptionsRecord.RecordClass({
datePickerLabelOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
DatePickerLabelOptionsRecord._isAnonymousRecord = true;
DatePickerLabelOptionsRecord.UniqueId = "0da201aa-e13f-92d1-a845-516b82f10faa";
DatePickerLabelOptionsRecord.init();
return DatePickerLabelOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.DatePickerLabelOptionsRecord = DatePickerLabelOptionsRecord;

});
define("ShopperPortalEU.model$BarcodeOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$BarcodeOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var BarcodeOptionsRecord = (function (_super) {
__extends(BarcodeOptionsRecord, _super);
function BarcodeOptionsRecord(defaults) {
_super.apply(this, arguments);
}
BarcodeOptionsRecord.attributesToDeclare = function () {
return [
this.attr("BarcodeOptions", "barcodeOptionsAttr", "BarcodeOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.BarcodeOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.BarcodeOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
BarcodeOptionsRecord.fromStructure = function (str) {
return new BarcodeOptionsRecord(new BarcodeOptionsRecord.RecordClass({
barcodeOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
BarcodeOptionsRecord._isAnonymousRecord = true;
BarcodeOptionsRecord.UniqueId = "0fd30fdb-aead-ea13-02b9-e277d1c50713";
BarcodeOptionsRecord.init();
return BarcodeOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.BarcodeOptionsRecord = BarcodeOptionsRecord;

});
define("ShopperPortalEU.model$CustomMessageOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomMessageOptionsList = (function (_super) {
__extends(CustomMessageOptionsList, _super);
function CustomMessageOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomMessageOptionsList.itemType = ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec;
return CustomMessageOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomMessageOptionsList = CustomMessageOptionsList;

});
define("ShopperPortalEU.model$CustomIconSizeRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomIconSizeRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomIconSizeRecord = (function (_super) {
__extends(CustomIconSizeRecord, _super);
function CustomIconSizeRecord(defaults) {
_super.apply(this, arguments);
}
CustomIconSizeRecord.attributesToDeclare = function () {
return [
this.attr("CustomIconSize", "customIconSizeAttr", "CustomIconSize", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomIconSizeRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomIconSizeRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomIconSizeRecord.fromStructure = function (str) {
return new CustomIconSizeRecord(new CustomIconSizeRecord.RecordClass({
customIconSizeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomIconSizeRecord._isAnonymousRecord = true;
CustomIconSizeRecord.UniqueId = "1471df4f-b04a-f4b0-9793-30bd82154efb";
CustomIconSizeRecord.init();
return CustomIconSizeRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomIconSizeRecord = CustomIconSizeRecord;

});
define("ShopperPortalEU.model$CustomIconSizeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomIconSizeRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomIconSizeRecordList = (function (_super) {
__extends(CustomIconSizeRecordList, _super);
function CustomIconSizeRecordList(defaults) {
_super.apply(this, arguments);
}
CustomIconSizeRecordList.itemType = ShopperPortalEUModel.CustomIconSizeRecord;
return CustomIconSizeRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomIconSizeRecordList = CustomIconSizeRecordList;

});
define("ShopperPortalEU.model$HeaderStepsOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var HeaderStepsOptionsRecord = (function (_super) {
__extends(HeaderStepsOptionsRecord, _super);
function HeaderStepsOptionsRecord(defaults) {
_super.apply(this, arguments);
}
HeaderStepsOptionsRecord.attributesToDeclare = function () {
return [
this.attr("HeaderStepsOptions", "headerStepsOptionsAttr", "HeaderStepsOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ThemeModel.HeaderStepsOptionsRec());
}, true, ShopperPortalEU_UI_ThemeModel.HeaderStepsOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
HeaderStepsOptionsRecord.fromStructure = function (str) {
return new HeaderStepsOptionsRecord(new HeaderStepsOptionsRecord.RecordClass({
headerStepsOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
HeaderStepsOptionsRecord._isAnonymousRecord = true;
HeaderStepsOptionsRecord.UniqueId = "150a9fd7-7cab-7ac0-9581-6aab3545241e";
HeaderStepsOptionsRecord.init();
return HeaderStepsOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.HeaderStepsOptionsRecord = HeaderStepsOptionsRecord;

});
define("ShopperPortalEU.model$BottomBarOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Theme.model$BottomBarOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var BottomBarOptionsRecord = (function (_super) {
__extends(BottomBarOptionsRecord, _super);
function BottomBarOptionsRecord(defaults) {
_super.apply(this, arguments);
}
BottomBarOptionsRecord.attributesToDeclare = function () {
return [
this.attr("BottomBarOptions", "bottomBarOptionsAttr", "BottomBarOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ThemeModel.BottomBarOptionsRec());
}, true, ShopperPortalEU_UI_ThemeModel.BottomBarOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
BottomBarOptionsRecord.fromStructure = function (str) {
return new BottomBarOptionsRecord(new BottomBarOptionsRecord.RecordClass({
bottomBarOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
BottomBarOptionsRecord._isAnonymousRecord = true;
BottomBarOptionsRecord.UniqueId = "15becd11-9084-74a7-71df-8bee809ad738";
BottomBarOptionsRecord.init();
return BottomBarOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.BottomBarOptionsRecord = BottomBarOptionsRecord;

});
define("ShopperPortalEU.model$CircleIconIconOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CircleIconIconOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CircleIconIconOptionsRecord = (function (_super) {
__extends(CircleIconIconOptionsRecord, _super);
function CircleIconIconOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CircleIconIconOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CircleIconIconOptions", "circleIconIconOptionsAttr", "CircleIconIconOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CircleIconIconOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CircleIconIconOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CircleIconIconOptionsRecord.fromStructure = function (str) {
return new CircleIconIconOptionsRecord(new CircleIconIconOptionsRecord.RecordClass({
circleIconIconOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CircleIconIconOptionsRecord._isAnonymousRecord = true;
CircleIconIconOptionsRecord.UniqueId = "169aef85-1e8a-f9df-20bb-b8e9ce06d1e8";
CircleIconIconOptionsRecord.init();
return CircleIconIconOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CircleIconIconOptionsRecord = CircleIconIconOptionsRecord;

});
define("ShopperPortalEU.model$CustomDropdownValidationOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomDropdownValidationOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomDropdownValidationOptionsRecord = (function (_super) {
__extends(CustomDropdownValidationOptionsRecord, _super);
function CustomDropdownValidationOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomDropdownValidationOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomDropdownValidationOptions", "customDropdownValidationOptionsAttr", "CustomDropdownValidationOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomDropdownValidationOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomDropdownValidationOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomDropdownValidationOptionsRecord.fromStructure = function (str) {
return new CustomDropdownValidationOptionsRecord(new CustomDropdownValidationOptionsRecord.RecordClass({
customDropdownValidationOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomDropdownValidationOptionsRecord._isAnonymousRecord = true;
CustomDropdownValidationOptionsRecord.UniqueId = "176a1b05-3610-8d56-c491-a7a9dc0e4d0a";
CustomDropdownValidationOptionsRecord.init();
return CustomDropdownValidationOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomDropdownValidationOptionsRecord = CustomDropdownValidationOptionsRecord;

});
define("ShopperPortalEU.model$CustomLinkIconAlignmentRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomLinkIconAlignmentRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomLinkIconAlignmentRecord = (function (_super) {
__extends(CustomLinkIconAlignmentRecord, _super);
function CustomLinkIconAlignmentRecord(defaults) {
_super.apply(this, arguments);
}
CustomLinkIconAlignmentRecord.attributesToDeclare = function () {
return [
this.attr("CustomLinkIconAlignment", "customLinkIconAlignmentAttr", "CustomLinkIconAlignment", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomLinkIconAlignmentRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomLinkIconAlignmentRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomLinkIconAlignmentRecord.fromStructure = function (str) {
return new CustomLinkIconAlignmentRecord(new CustomLinkIconAlignmentRecord.RecordClass({
customLinkIconAlignmentAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomLinkIconAlignmentRecord._isAnonymousRecord = true;
CustomLinkIconAlignmentRecord.UniqueId = "ace63999-aa40-0027-4a2e-0cc9a95f0bf2";
CustomLinkIconAlignmentRecord.init();
return CustomLinkIconAlignmentRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomLinkIconAlignmentRecord = CustomLinkIconAlignmentRecord;

});
define("ShopperPortalEU.model$CustomLinkIconAlignmentRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomLinkIconAlignmentRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomLinkIconAlignmentRecordList = (function (_super) {
__extends(CustomLinkIconAlignmentRecordList, _super);
function CustomLinkIconAlignmentRecordList(defaults) {
_super.apply(this, arguments);
}
CustomLinkIconAlignmentRecordList.itemType = ShopperPortalEUModel.CustomLinkIconAlignmentRecord;
return CustomLinkIconAlignmentRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomLinkIconAlignmentRecordList = CustomLinkIconAlignmentRecordList;

});
define("ShopperPortalEU.model$UpdateCardDataList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU.model", "ShopperPortalEU_Shopper_IS.model$UpdateCardDataRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var UpdateCardDataList = (function (_super) {
__extends(UpdateCardDataList, _super);
function UpdateCardDataList(defaults) {
_super.apply(this, arguments);
}
UpdateCardDataList.itemType = ShopperPortalEU_Shopper_ISModel.UpdateCardDataRec;
return UpdateCardDataList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.UpdateCardDataList = UpdateCardDataList;

});
define("ShopperPortalEU.model$FlexDirectionRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$FlexDirectionRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var FlexDirectionRecord = (function (_super) {
__extends(FlexDirectionRecord, _super);
function FlexDirectionRecord(defaults) {
_super.apply(this, arguments);
}
FlexDirectionRecord.attributesToDeclare = function () {
return [
this.attr("FlexDirection", "flexDirectionAttr", "FlexDirection", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.FlexDirectionRec());
}, true, ShopperPortalEU_UI_ComponentsModel.FlexDirectionRec)
].concat(_super.attributesToDeclare.call(this));
};
FlexDirectionRecord.fromStructure = function (str) {
return new FlexDirectionRecord(new FlexDirectionRecord.RecordClass({
flexDirectionAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
FlexDirectionRecord._isAnonymousRecord = true;
FlexDirectionRecord.UniqueId = "eb8e4d74-b289-661e-eeb1-78f81109c0d8";
FlexDirectionRecord.init();
return FlexDirectionRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.FlexDirectionRecord = FlexDirectionRecord;

});
define("ShopperPortalEU.model$FlexDirectionRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$FlexDirectionRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var FlexDirectionRecordList = (function (_super) {
__extends(FlexDirectionRecordList, _super);
function FlexDirectionRecordList(defaults) {
_super.apply(this, arguments);
}
FlexDirectionRecordList.itemType = ShopperPortalEUModel.FlexDirectionRecord;
return FlexDirectionRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.FlexDirectionRecordList = FlexDirectionRecordList;

});
define("ShopperPortalEU.model$BottomDrawerRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$BottomDrawerRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var BottomDrawerRecord = (function (_super) {
__extends(BottomDrawerRecord, _super);
function BottomDrawerRecord(defaults) {
_super.apply(this, arguments);
}
BottomDrawerRecord.attributesToDeclare = function () {
return [
this.attr("BottomDrawer", "bottomDrawerAttr", "BottomDrawer", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.BottomDrawerRec());
}, true, ShopperPortalEU_UI_ComponentsModel.BottomDrawerRec)
].concat(_super.attributesToDeclare.call(this));
};
BottomDrawerRecord.fromStructure = function (str) {
return new BottomDrawerRecord(new BottomDrawerRecord.RecordClass({
bottomDrawerAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
BottomDrawerRecord._isAnonymousRecord = true;
BottomDrawerRecord.UniqueId = "181708c1-7064-4e07-343d-69cb33d7e193";
BottomDrawerRecord.init();
return BottomDrawerRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.BottomDrawerRecord = BottomDrawerRecord;

});
define("ShopperPortalEU.model$CustomLinkItemOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomLinkItemOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomLinkItemOptionsRecord = (function (_super) {
__extends(CustomLinkItemOptionsRecord, _super);
function CustomLinkItemOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomLinkItemOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomLinkItemOptions", "customLinkItemOptionsAttr", "CustomLinkItemOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomLinkItemOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomLinkItemOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomLinkItemOptionsRecord.fromStructure = function (str) {
return new CustomLinkItemOptionsRecord(new CustomLinkItemOptionsRecord.RecordClass({
customLinkItemOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomLinkItemOptionsRecord._isAnonymousRecord = true;
CustomLinkItemOptionsRecord.UniqueId = "19115453-898b-a8fb-7918-3e6dcaea8082";
CustomLinkItemOptionsRecord.init();
return CustomLinkItemOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomLinkItemOptionsRecord = CustomLinkItemOptionsRecord;

});
define("ShopperPortalEU.model$UpdateCardList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU.model", "ShopperPortalEU_Shopper_IS.model$UpdateCardRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var UpdateCardList = (function (_super) {
__extends(UpdateCardList, _super);
function UpdateCardList(defaults) {
_super.apply(this, arguments);
}
UpdateCardList.itemType = ShopperPortalEU_Shopper_ISModel.UpdateCardRec;
return UpdateCardList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.UpdateCardList = UpdateCardList;

});
define("ShopperPortalEU.model$DatatransCardChangeOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$DatatransCardChangeOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var DatatransCardChangeOptionsList = (function (_super) {
__extends(DatatransCardChangeOptionsList, _super);
function DatatransCardChangeOptionsList(defaults) {
_super.apply(this, arguments);
}
DatatransCardChangeOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.DatatransCardChangeOptionsRec;
return DatatransCardChangeOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.DatatransCardChangeOptionsList = DatatransCardChangeOptionsList;

});
define("ShopperPortalEU.model$CompleteDetails_AddressRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CompleteDetails_AddressRec = (function (_super) {
__extends(CompleteDetails_AddressRec, _super);
function CompleteDetails_AddressRec(defaults) {
_super.apply(this, arguments);
}
CompleteDetails_AddressRec.attributesToDeclare = function () {
return [
this.attr("Country", "countryAttr", "country", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("AddressLine1", "addressLine1Attr", "addressLine1", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("AddressLine2", "addressLine2Attr", "addressLine2", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Postcode", "postcodeAttr", "postcode", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("City", "cityAttr", "city", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("State", "stateAttr", "state", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CompleteDetails_AddressRec.init();
return CompleteDetails_AddressRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CompleteDetails_AddressRec = CompleteDetails_AddressRec;

});
define("ShopperPortalEU.model$CompleteDetails_AddressList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CompleteDetails_AddressRec"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CompleteDetails_AddressList = (function (_super) {
__extends(CompleteDetails_AddressList, _super);
function CompleteDetails_AddressList(defaults) {
_super.apply(this, arguments);
}
CompleteDetails_AddressList.itemType = ShopperPortalEUModel.CompleteDetails_AddressRec;
return CompleteDetails_AddressList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CompleteDetails_AddressList = CompleteDetails_AddressList;

});
define("ShopperPortalEU.model$CustomInputOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomInputOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomInputOptionsRecord = (function (_super) {
__extends(CustomInputOptionsRecord, _super);
function CustomInputOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomInputOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomInputOptions", "customInputOptionsAttr", "CustomInputOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomInputOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomInputOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomInputOptionsRecord.fromStructure = function (str) {
return new CustomInputOptionsRecord(new CustomInputOptionsRecord.RecordClass({
customInputOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomInputOptionsRecord._isAnonymousRecord = true;
CustomInputOptionsRecord.UniqueId = "1ac7de67-9364-5830-0e59-b60f4bb176d2";
CustomInputOptionsRecord.init();
return CustomInputOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomInputOptionsRecord = CustomInputOptionsRecord;

});
define("ShopperPortalEU.model$CustomDropdownListSelectedItemOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomDropdownListSelectedItemOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomDropdownListSelectedItemOptionsRecord = (function (_super) {
__extends(CustomDropdownListSelectedItemOptionsRecord, _super);
function CustomDropdownListSelectedItemOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomDropdownListSelectedItemOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomDropdownListSelectedItemOptions", "customDropdownListSelectedItemOptionsAttr", "CustomDropdownListSelectedItemOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomDropdownListSelectedItemOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomDropdownListSelectedItemOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomDropdownListSelectedItemOptionsRecord.fromStructure = function (str) {
return new CustomDropdownListSelectedItemOptionsRecord(new CustomDropdownListSelectedItemOptionsRecord.RecordClass({
customDropdownListSelectedItemOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomDropdownListSelectedItemOptionsRecord._isAnonymousRecord = true;
CustomDropdownListSelectedItemOptionsRecord.UniqueId = "af439dbe-5799-71e6-94b7-d2fa2475855b";
CustomDropdownListSelectedItemOptionsRecord.init();
return CustomDropdownListSelectedItemOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomDropdownListSelectedItemOptionsRecord = CustomDropdownListSelectedItemOptionsRecord;

});
define("ShopperPortalEU.model$CustomDropdownListSelectedItemOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomDropdownListSelectedItemOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomDropdownListSelectedItemOptionsRecordList = (function (_super) {
__extends(CustomDropdownListSelectedItemOptionsRecordList, _super);
function CustomDropdownListSelectedItemOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownListSelectedItemOptionsRecordList.itemType = ShopperPortalEUModel.CustomDropdownListSelectedItemOptionsRecord;
return CustomDropdownListSelectedItemOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomDropdownListSelectedItemOptionsRecordList = CustomDropdownListSelectedItemOptionsRecordList;

});
define("ShopperPortalEU.model$MenuItemIconOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Theme.model$MenuItemIconOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var MenuItemIconOptionsRecord = (function (_super) {
__extends(MenuItemIconOptionsRecord, _super);
function MenuItemIconOptionsRecord(defaults) {
_super.apply(this, arguments);
}
MenuItemIconOptionsRecord.attributesToDeclare = function () {
return [
this.attr("MenuItemIconOptions", "menuItemIconOptionsAttr", "MenuItemIconOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ThemeModel.MenuItemIconOptionsRec());
}, true, ShopperPortalEU_UI_ThemeModel.MenuItemIconOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
MenuItemIconOptionsRecord.fromStructure = function (str) {
return new MenuItemIconOptionsRecord(new MenuItemIconOptionsRecord.RecordClass({
menuItemIconOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
MenuItemIconOptionsRecord._isAnonymousRecord = true;
MenuItemIconOptionsRecord.UniqueId = "58e2bc41-b1ec-b696-790a-f08f8ffc2182";
MenuItemIconOptionsRecord.init();
return MenuItemIconOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.MenuItemIconOptionsRecord = MenuItemIconOptionsRecord;

});
define("ShopperPortalEU.model$MenuItemIconOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$MenuItemIconOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var MenuItemIconOptionsRecordList = (function (_super) {
__extends(MenuItemIconOptionsRecordList, _super);
function MenuItemIconOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
MenuItemIconOptionsRecordList.itemType = ShopperPortalEUModel.MenuItemIconOptionsRecord;
return MenuItemIconOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.MenuItemIconOptionsRecordList = MenuItemIconOptionsRecordList;

});
define("ShopperPortalEU.model$GetShopperTravelDocumentsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU.model", "ShopperPortalEU_Shopper_IS.model$GetShopperTravelDocumentsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var GetShopperTravelDocumentsList = (function (_super) {
__extends(GetShopperTravelDocumentsList, _super);
function GetShopperTravelDocumentsList(defaults) {
_super.apply(this, arguments);
}
GetShopperTravelDocumentsList.itemType = ShopperPortalEU_Shopper_ISModel.GetShopperTravelDocumentsRec;
return GetShopperTravelDocumentsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.GetShopperTravelDocumentsList = GetShopperTravelDocumentsList;

});
define("ShopperPortalEU.model$GetShopperResponseList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU.model", "ShopperPortalEU_Shopper_IS.model$GetShopperResponseRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var GetShopperResponseList = (function (_super) {
__extends(GetShopperResponseList, _super);
function GetShopperResponseList(defaults) {
_super.apply(this, arguments);
}
GetShopperResponseList.itemType = ShopperPortalEU_Shopper_ISModel.GetShopperResponseRec;
return GetShopperResponseList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.GetShopperResponseList = GetShopperResponseList;

});
define("ShopperPortalEU.model$OpenPDFOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$OpenPDFOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var OpenPDFOptionsRecordList = (function (_super) {
__extends(OpenPDFOptionsRecordList, _super);
function OpenPDFOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
OpenPDFOptionsRecordList.itemType = ShopperPortalEUModel.OpenPDFOptionsRecord;
return OpenPDFOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.OpenPDFOptionsRecordList = OpenPDFOptionsRecordList;

});
define("ShopperPortalEU.model$JustifyList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$JustifyRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var JustifyList = (function (_super) {
__extends(JustifyList, _super);
function JustifyList(defaults) {
_super.apply(this, arguments);
}
JustifyList.itemType = ShopperPortalEU_UI_ComponentsModel.JustifyRec;
return JustifyList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.JustifyList = JustifyList;

});
define("ShopperPortalEU.model$CustomInputValidationOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomInputValidationOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomInputValidationOptionsRecord = (function (_super) {
__extends(CustomInputValidationOptionsRecord, _super);
function CustomInputValidationOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomInputValidationOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomInputValidationOptions", "customInputValidationOptionsAttr", "CustomInputValidationOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomInputValidationOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomInputValidationOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomInputValidationOptionsRecord.fromStructure = function (str) {
return new CustomInputValidationOptionsRecord(new CustomInputValidationOptionsRecord.RecordClass({
customInputValidationOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomInputValidationOptionsRecord._isAnonymousRecord = true;
CustomInputValidationOptionsRecord.UniqueId = "1dc5b917-c3b5-d95e-825d-6ccc37ab1546";
CustomInputValidationOptionsRecord.init();
return CustomInputValidationOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomInputValidationOptionsRecord = CustomInputValidationOptionsRecord;

});
define("ShopperPortalEU.model$RecaptchaThemeList", ["exports", "OutSystems/ClientRuntime/Main", "reCAPTCHAReact.model", "ShopperPortalEU.model", "reCAPTCHAReact.model$RecaptchaThemeRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$reCAPTCHAReact"], function (exports, OutSystems, reCAPTCHAReactModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var RecaptchaThemeList = (function (_super) {
__extends(RecaptchaThemeList, _super);
function RecaptchaThemeList(defaults) {
_super.apply(this, arguments);
}
RecaptchaThemeList.itemType = reCAPTCHAReactModel.RecaptchaThemeRec;
return RecaptchaThemeList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.RecaptchaThemeList = RecaptchaThemeList;

});
define("ShopperPortalEU.model$CustomCardOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomCardOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomCardOptionsRecord = (function (_super) {
__extends(CustomCardOptionsRecord, _super);
function CustomCardOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomCardOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomCardOptions", "customCardOptionsAttr", "CustomCardOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomCardOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomCardOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomCardOptionsRecord.fromStructure = function (str) {
return new CustomCardOptionsRecord(new CustomCardOptionsRecord.RecordClass({
customCardOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomCardOptionsRecord._isAnonymousRecord = true;
CustomCardOptionsRecord.UniqueId = "1f966b4e-6ea9-1909-e8fe-94733ed2a61b";
CustomCardOptionsRecord.init();
return CustomCardOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomCardOptionsRecord = CustomCardOptionsRecord;

});
define("ShopperPortalEU.model$TextList", ["exports", "OutSystems/ClientRuntime/Main", "Extension.Text.model", "ShopperPortalEU.model", "Extension.Text.model$TextRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$Text"], function (exports, OutSystems, Extension_TextModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var TextList = (function (_super) {
__extends(TextList, _super);
function TextList(defaults) {
_super.apply(this, arguments);
}
TextList.itemType = Extension_TextModel.TextRec;
return TextList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.TextList = TextList;

});
define("ShopperPortalEU.model$CustomDropdownSearchOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomDropdownSearchOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomDropdownSearchOptionsList = (function (_super) {
__extends(CustomDropdownSearchOptionsList, _super);
function CustomDropdownSearchOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownSearchOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomDropdownSearchOptionsRec;
return CustomDropdownSearchOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomDropdownSearchOptionsList = CustomDropdownSearchOptionsList;

});
define("ShopperPortalEU.model$RefundDetails_WrapperList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_API.model", "ShopperPortalEU.model", "ShopperPortalEU_API.model$RefundDetails_WrapperRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_API"], function (exports, OutSystems, ShopperPortalEU_APIModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var RefundDetails_WrapperList = (function (_super) {
__extends(RefundDetails_WrapperList, _super);
function RefundDetails_WrapperList(defaults) {
_super.apply(this, arguments);
}
RefundDetails_WrapperList.itemType = ShopperPortalEU_APIModel.RefundDetails_WrapperRec;
return RefundDetails_WrapperList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.RefundDetails_WrapperList = RefundDetails_WrapperList;

});
define("ShopperPortalEU.model$CustomIconOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomIconOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomIconOptionsRecord = (function (_super) {
__extends(CustomIconOptionsRecord, _super);
function CustomIconOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomIconOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomIconOptions", "customIconOptionsAttr", "CustomIconOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomIconOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomIconOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomIconOptionsRecord.fromStructure = function (str) {
return new CustomIconOptionsRecord(new CustomIconOptionsRecord.RecordClass({
customIconOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomIconOptionsRecord._isAnonymousRecord = true;
CustomIconOptionsRecord.UniqueId = "ec3a9701-ff9a-7eb1-9cc0-07d487764911";
CustomIconOptionsRecord.init();
return CustomIconOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomIconOptionsRecord = CustomIconOptionsRecord;

});
define("ShopperPortalEU.model$CustomIconOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomIconOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomIconOptionsRecordList = (function (_super) {
__extends(CustomIconOptionsRecordList, _super);
function CustomIconOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomIconOptionsRecordList.itemType = ShopperPortalEUModel.CustomIconOptionsRecord;
return CustomIconOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomIconOptionsRecordList = CustomIconOptionsRecordList;

});
define("ShopperPortalEU.model$CustomLinkTypeRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomLinkTypeRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomLinkTypeRecord = (function (_super) {
__extends(CustomLinkTypeRecord, _super);
function CustomLinkTypeRecord(defaults) {
_super.apply(this, arguments);
}
CustomLinkTypeRecord.attributesToDeclare = function () {
return [
this.attr("CustomLinkType", "customLinkTypeAttr", "CustomLinkType", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomLinkTypeRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomLinkTypeRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomLinkTypeRecord.fromStructure = function (str) {
return new CustomLinkTypeRecord(new CustomLinkTypeRecord.RecordClass({
customLinkTypeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomLinkTypeRecord._isAnonymousRecord = true;
CustomLinkTypeRecord.UniqueId = "a4c2b7e1-219b-da6d-ad09-3fcec0e6925a";
CustomLinkTypeRecord.init();
return CustomLinkTypeRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomLinkTypeRecord = CustomLinkTypeRecord;

});
define("ShopperPortalEU.model$CustomLinkTypeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomLinkTypeRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomLinkTypeRecordList = (function (_super) {
__extends(CustomLinkTypeRecordList, _super);
function CustomLinkTypeRecordList(defaults) {
_super.apply(this, arguments);
}
CustomLinkTypeRecordList.itemType = ShopperPortalEUModel.CustomLinkTypeRecord;
return CustomLinkTypeRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomLinkTypeRecordList = CustomLinkTypeRecordList;

});
define("ShopperPortalEU.model$CustomTimelineTypeList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomTimelineTypeRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomTimelineTypeList = (function (_super) {
__extends(CustomTimelineTypeList, _super);
function CustomTimelineTypeList(defaults) {
_super.apply(this, arguments);
}
CustomTimelineTypeList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomTimelineTypeRec;
return CustomTimelineTypeList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomTimelineTypeList = CustomTimelineTypeList;

});
define("ShopperPortalEU.model$HeaderActionOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Theme.model$HeaderActionOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var HeaderActionOptionsList = (function (_super) {
__extends(HeaderActionOptionsList, _super);
function HeaderActionOptionsList(defaults) {
_super.apply(this, arguments);
}
HeaderActionOptionsList.itemType = ShopperPortalEU_UI_ThemeModel.HeaderActionOptionsRec;
return HeaderActionOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.HeaderActionOptionsList = HeaderActionOptionsList;

});
define("ShopperPortalEU.model$CardStateTypeList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CardStateTypeRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CardStateTypeList = (function (_super) {
__extends(CardStateTypeList, _super);
function CardStateTypeList(defaults) {
_super.apply(this, arguments);
}
CardStateTypeList.itemType = ShopperPortalEU_UI_ComponentsModel.CardStateTypeRec;
return CardStateTypeList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CardStateTypeList = CardStateTypeList;

});
define("ShopperPortalEU.model$GetOSRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$GetOSRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var GetOSRecord = (function (_super) {
__extends(GetOSRecord, _super);
function GetOSRecord(defaults) {
_super.apply(this, arguments);
}
GetOSRecord.attributesToDeclare = function () {
return [
this.attr("GetOS", "getOSAttr", "GetOS", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.GetOSRec());
}, true, ShopperPortalEU_UI_ComponentsModel.GetOSRec)
].concat(_super.attributesToDeclare.call(this));
};
GetOSRecord.fromStructure = function (str) {
return new GetOSRecord(new GetOSRecord.RecordClass({
getOSAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
GetOSRecord._isAnonymousRecord = true;
GetOSRecord.UniqueId = "219a09a5-d480-10e0-80ba-b5a63e8d5470";
GetOSRecord.init();
return GetOSRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.GetOSRecord = GetOSRecord;

});
define("ShopperPortalEU.model$BottomDrawerList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$BottomDrawerRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var BottomDrawerList = (function (_super) {
__extends(BottomDrawerList, _super);
function BottomDrawerList(defaults) {
_super.apply(this, arguments);
}
BottomDrawerList.itemType = ShopperPortalEU_UI_ComponentsModel.BottomDrawerRec;
return BottomDrawerList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.BottomDrawerList = BottomDrawerList;

});
define("ShopperPortalEU.model$HeaderStepsOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var HeaderStepsOptionsList = (function (_super) {
__extends(HeaderStepsOptionsList, _super);
function HeaderStepsOptionsList(defaults) {
_super.apply(this, arguments);
}
HeaderStepsOptionsList.itemType = ShopperPortalEU_UI_ThemeModel.HeaderStepsOptionsRec;
return HeaderStepsOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.HeaderStepsOptionsList = HeaderStepsOptionsList;

});
define("ShopperPortalEU.model$GetOSOptionRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$GetOSOptionRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var GetOSOptionRecord = (function (_super) {
__extends(GetOSOptionRecord, _super);
function GetOSOptionRecord(defaults) {
_super.apply(this, arguments);
}
GetOSOptionRecord.attributesToDeclare = function () {
return [
this.attr("GetOSOption", "getOSOptionAttr", "GetOSOption", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.GetOSOptionRec());
}, true, ShopperPortalEU_UI_ComponentsModel.GetOSOptionRec)
].concat(_super.attributesToDeclare.call(this));
};
GetOSOptionRecord.fromStructure = function (str) {
return new GetOSOptionRecord(new GetOSOptionRecord.RecordClass({
getOSOptionAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
GetOSOptionRecord._isAnonymousRecord = true;
GetOSOptionRecord.UniqueId = "23022557-8dcf-fa8c-9f56-e5bc76ce87a9";
GetOSOptionRecord.init();
return GetOSOptionRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.GetOSOptionRecord = GetOSOptionRecord;

});
define("ShopperPortalEU.model$HeaderStepsOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$HeaderStepsOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var HeaderStepsOptionsRecordList = (function (_super) {
__extends(HeaderStepsOptionsRecordList, _super);
function HeaderStepsOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
HeaderStepsOptionsRecordList.itemType = ShopperPortalEUModel.HeaderStepsOptionsRecord;
return HeaderStepsOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.HeaderStepsOptionsRecordList = HeaderStepsOptionsRecordList;

});
define("ShopperPortalEU.model$CustomButtonTypeRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomButtonTypeRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomButtonTypeRecord = (function (_super) {
__extends(CustomButtonTypeRecord, _super);
function CustomButtonTypeRecord(defaults) {
_super.apply(this, arguments);
}
CustomButtonTypeRecord.attributesToDeclare = function () {
return [
this.attr("CustomButtonType", "customButtonTypeAttr", "CustomButtonType", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomButtonTypeRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomButtonTypeRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomButtonTypeRecord.fromStructure = function (str) {
return new CustomButtonTypeRecord(new CustomButtonTypeRecord.RecordClass({
customButtonTypeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomButtonTypeRecord._isAnonymousRecord = true;
CustomButtonTypeRecord.UniqueId = "5deb5baa-9211-f244-214a-232ef1a5ccb3";
CustomButtonTypeRecord.init();
return CustomButtonTypeRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomButtonTypeRecord = CustomButtonTypeRecord;

});
define("ShopperPortalEU.model$CustomButtonTypeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomButtonTypeRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomButtonTypeRecordList = (function (_super) {
__extends(CustomButtonTypeRecordList, _super);
function CustomButtonTypeRecordList(defaults) {
_super.apply(this, arguments);
}
CustomButtonTypeRecordList.itemType = ShopperPortalEUModel.CustomButtonTypeRecord;
return CustomButtonTypeRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomButtonTypeRecordList = CustomButtonTypeRecordList;

});
define("ShopperPortalEU.model$CustomAlertOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomAlertOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomAlertOptionsList = (function (_super) {
__extends(CustomAlertOptionsList, _super);
function CustomAlertOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomAlertOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomAlertOptionsRec;
return CustomAlertOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomAlertOptionsList = CustomAlertOptionsList;

});
define("ShopperPortalEU.model$PaddingList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$PaddingRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var PaddingList = (function (_super) {
__extends(PaddingList, _super);
function PaddingList(defaults) {
_super.apply(this, arguments);
}
PaddingList.itemType = ShopperPortalEU_UI_ComponentsModel.PaddingRec;
return PaddingList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.PaddingList = PaddingList;

});
define("ShopperPortalEU.model$CustomTagStateRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomTagStateRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomTagStateRecord = (function (_super) {
__extends(CustomTagStateRecord, _super);
function CustomTagStateRecord(defaults) {
_super.apply(this, arguments);
}
CustomTagStateRecord.attributesToDeclare = function () {
return [
this.attr("CustomTagState", "customTagStateAttr", "CustomTagState", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomTagStateRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomTagStateRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomTagStateRecord.fromStructure = function (str) {
return new CustomTagStateRecord(new CustomTagStateRecord.RecordClass({
customTagStateAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomTagStateRecord._isAnonymousRecord = true;
CustomTagStateRecord.UniqueId = "257bb42e-a6a8-1fb0-b051-e88ca4f96cd4";
CustomTagStateRecord.init();
return CustomTagStateRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomTagStateRecord = CustomTagStateRecord;

});
define("ShopperPortalEU.model$CardBackgroundOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CardBackgroundOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CardBackgroundOptionsList = (function (_super) {
__extends(CardBackgroundOptionsList, _super);
function CardBackgroundOptionsList(defaults) {
_super.apply(this, arguments);
}
CardBackgroundOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CardBackgroundOptionsRec;
return CardBackgroundOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CardBackgroundOptionsList = CardBackgroundOptionsList;

});
define("ShopperPortalEU.model$DatePickerOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$DatePickerOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var DatePickerOptionsRecord = (function (_super) {
__extends(DatePickerOptionsRecord, _super);
function DatePickerOptionsRecord(defaults) {
_super.apply(this, arguments);
}
DatePickerOptionsRecord.attributesToDeclare = function () {
return [
this.attr("DatePickerOptions", "datePickerOptionsAttr", "DatePickerOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.DatePickerOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.DatePickerOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
DatePickerOptionsRecord.fromStructure = function (str) {
return new DatePickerOptionsRecord(new DatePickerOptionsRecord.RecordClass({
datePickerOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
DatePickerOptionsRecord._isAnonymousRecord = true;
DatePickerOptionsRecord.UniqueId = "2663b02c-8d3a-d8dd-bd98-604b72105e7f";
DatePickerOptionsRecord.init();
return DatePickerOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.DatePickerOptionsRecord = DatePickerOptionsRecord;

});
define("ShopperPortalEU.model$PhoneNumberInputSearchOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$PhoneNumberInputSearchOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var PhoneNumberInputSearchOptionsRecord = (function (_super) {
__extends(PhoneNumberInputSearchOptionsRecord, _super);
function PhoneNumberInputSearchOptionsRecord(defaults) {
_super.apply(this, arguments);
}
PhoneNumberInputSearchOptionsRecord.attributesToDeclare = function () {
return [
this.attr("PhoneNumberInputSearchOptions", "phoneNumberInputSearchOptionsAttr", "PhoneNumberInputSearchOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputSearchOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputSearchOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
PhoneNumberInputSearchOptionsRecord.fromStructure = function (str) {
return new PhoneNumberInputSearchOptionsRecord(new PhoneNumberInputSearchOptionsRecord.RecordClass({
phoneNumberInputSearchOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
PhoneNumberInputSearchOptionsRecord._isAnonymousRecord = true;
PhoneNumberInputSearchOptionsRecord.UniqueId = "2748b348-b7f1-ee07-8e42-cf5a83a6bca9";
PhoneNumberInputSearchOptionsRecord.init();
return PhoneNumberInputSearchOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.PhoneNumberInputSearchOptionsRecord = PhoneNumberInputSearchOptionsRecord;

});
define("ShopperPortalEU.model$FormInfo_WrapperList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU.model", "ShopperPortalEU_Forms_IS.model$FormInfo_WrapperRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Forms_IS"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var FormInfo_WrapperList = (function (_super) {
__extends(FormInfo_WrapperList, _super);
function FormInfo_WrapperList(defaults) {
_super.apply(this, arguments);
}
FormInfo_WrapperList.itemType = ShopperPortalEU_Forms_ISModel.FormInfo_WrapperRec;
return FormInfo_WrapperList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.FormInfo_WrapperList = FormInfo_WrapperList;

});
define("ShopperPortalEU.model$RefundSummaryRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU.model", "ShopperPortalEU_Forms_IS.model$FormInfo_WrapperRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Forms_IS", "ShopperPortalEU.model$FormInfo_WrapperList"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var RefundSummaryRec = (function (_super) {
__extends(RefundSummaryRec, _super);
function RefundSummaryRec(defaults) {
_super.apply(this, arguments);
}
RefundSummaryRec.attributesToDeclare = function () {
return [
this.attr("TotalEstimatedRefund", "totalEstimatedRefundAttr", "TotalEstimatedRefund", false, false, OS.DataTypes.DataTypes.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("Currency", "currencyAttr", "Currency", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("FormInfo_Wrapper", "formInfo_WrapperAttr", "FormInfo_Wrapper", false, false, OS.DataTypes.DataTypes.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEUModel.FormInfo_WrapperList());
}, true, ShopperPortalEUModel.FormInfo_WrapperList)
].concat(_super.attributesToDeclare.call(this));
};
RefundSummaryRec.init();
return RefundSummaryRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.RefundSummaryRec = RefundSummaryRec;

});
define("ShopperPortalEU.model$RefundSummaryRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$RefundSummaryRec"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var RefundSummaryRecord = (function (_super) {
__extends(RefundSummaryRecord, _super);
function RefundSummaryRecord(defaults) {
_super.apply(this, arguments);
}
RefundSummaryRecord.attributesToDeclare = function () {
return [
this.attr("RefundSummary", "refundSummaryAttr", "RefundSummary", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEUModel.RefundSummaryRec());
}, true, ShopperPortalEUModel.RefundSummaryRec)
].concat(_super.attributesToDeclare.call(this));
};
RefundSummaryRecord.fromStructure = function (str) {
return new RefundSummaryRecord(new RefundSummaryRecord.RecordClass({
refundSummaryAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
RefundSummaryRecord._isAnonymousRecord = true;
RefundSummaryRecord.UniqueId = "2898f779-01ba-f9e3-903f-61895214ec52";
RefundSummaryRecord.init();
return RefundSummaryRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.RefundSummaryRecord = RefundSummaryRecord;

});
define("ShopperPortalEU.model$DatatransCardChangeOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$DatatransCardChangeOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var DatatransCardChangeOptionsRecord = (function (_super) {
__extends(DatatransCardChangeOptionsRecord, _super);
function DatatransCardChangeOptionsRecord(defaults) {
_super.apply(this, arguments);
}
DatatransCardChangeOptionsRecord.attributesToDeclare = function () {
return [
this.attr("DatatransCardChangeOptions", "datatransCardChangeOptionsAttr", "DatatransCardChangeOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.DatatransCardChangeOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.DatatransCardChangeOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
DatatransCardChangeOptionsRecord.fromStructure = function (str) {
return new DatatransCardChangeOptionsRecord(new DatatransCardChangeOptionsRecord.RecordClass({
datatransCardChangeOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
DatatransCardChangeOptionsRecord._isAnonymousRecord = true;
DatatransCardChangeOptionsRecord.UniqueId = "28dad260-4c18-d507-944a-54e23309dbc9";
DatatransCardChangeOptionsRecord.init();
return DatatransCardChangeOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.DatatransCardChangeOptionsRecord = DatatransCardChangeOptionsRecord;

});
define("ShopperPortalEU.model$CreateCardRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU.model", "ShopperPortalEU_Shopper_IS.model$CreateCardRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CreateCardRecord = (function (_super) {
__extends(CreateCardRecord, _super);
function CreateCardRecord(defaults) {
_super.apply(this, arguments);
}
CreateCardRecord.attributesToDeclare = function () {
return [
this.attr("CreateCard", "createCardAttr", "CreateCard", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Shopper_ISModel.CreateCardRec());
}, true, ShopperPortalEU_Shopper_ISModel.CreateCardRec)
].concat(_super.attributesToDeclare.call(this));
};
CreateCardRecord.fromStructure = function (str) {
return new CreateCardRecord(new CreateCardRecord.RecordClass({
createCardAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CreateCardRecord._isAnonymousRecord = true;
CreateCardRecord.UniqueId = "2aa63039-c51f-079c-c2a5-f20293781d0c";
CreateCardRecord.init();
return CreateCardRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CreateCardRecord = CreateCardRecord;

});
define("ShopperPortalEU.model$DeleteCardRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU.model", "ShopperPortalEU_Shopper_IS.model$DeleteCardRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var DeleteCardRecord = (function (_super) {
__extends(DeleteCardRecord, _super);
function DeleteCardRecord(defaults) {
_super.apply(this, arguments);
}
DeleteCardRecord.attributesToDeclare = function () {
return [
this.attr("DeleteCard", "deleteCardAttr", "DeleteCard", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Shopper_ISModel.DeleteCardRec());
}, true, ShopperPortalEU_Shopper_ISModel.DeleteCardRec)
].concat(_super.attributesToDeclare.call(this));
};
DeleteCardRecord.fromStructure = function (str) {
return new DeleteCardRecord(new DeleteCardRecord.RecordClass({
deleteCardAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
DeleteCardRecord._isAnonymousRecord = true;
DeleteCardRecord.UniqueId = "2acdfd0f-8e9a-b3a5-161b-827328775995";
DeleteCardRecord.init();
return DeleteCardRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.DeleteCardRecord = DeleteCardRecord;

});
define("ShopperPortalEU.model$CustomInputIconOptionRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomInputIconOptionRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomInputIconOptionRecord = (function (_super) {
__extends(CustomInputIconOptionRecord, _super);
function CustomInputIconOptionRecord(defaults) {
_super.apply(this, arguments);
}
CustomInputIconOptionRecord.attributesToDeclare = function () {
return [
this.attr("CustomInputIconOption", "customInputIconOptionAttr", "CustomInputIconOption", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomInputIconOptionRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomInputIconOptionRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomInputIconOptionRecord.fromStructure = function (str) {
return new CustomInputIconOptionRecord(new CustomInputIconOptionRecord.RecordClass({
customInputIconOptionAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomInputIconOptionRecord._isAnonymousRecord = true;
CustomInputIconOptionRecord.UniqueId = "64a2bbde-39b5-a619-6695-5ae977b5d9e2";
CustomInputIconOptionRecord.init();
return CustomInputIconOptionRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomInputIconOptionRecord = CustomInputIconOptionRecord;

});
define("ShopperPortalEU.model$CustomInputIconOptionRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomInputIconOptionRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomInputIconOptionRecordList = (function (_super) {
__extends(CustomInputIconOptionRecordList, _super);
function CustomInputIconOptionRecordList(defaults) {
_super.apply(this, arguments);
}
CustomInputIconOptionRecordList.itemType = ShopperPortalEUModel.CustomInputIconOptionRecord;
return CustomInputIconOptionRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomInputIconOptionRecordList = CustomInputIconOptionRecordList;

});
define("ShopperPortalEU.model$ApcuesIdentifyRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var ApcuesIdentifyRec = (function (_super) {
__extends(ApcuesIdentifyRec, _super);
function ApcuesIdentifyRec(defaults) {
_super.apply(this, arguments);
}
ApcuesIdentifyRec.attributesToDeclare = function () {
return [
this.attr("Guid", "guidAttr", "Guid", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Name", "nameAttr", "Name", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Email", "emailAttr", "Email", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ApcuesIdentifyRec.init();
return ApcuesIdentifyRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.ApcuesIdentifyRec = ApcuesIdentifyRec;

});
define("ShopperPortalEU.model$ApcuesIdentifyRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$ApcuesIdentifyRec"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var ApcuesIdentifyRecord = (function (_super) {
__extends(ApcuesIdentifyRecord, _super);
function ApcuesIdentifyRecord(defaults) {
_super.apply(this, arguments);
}
ApcuesIdentifyRecord.attributesToDeclare = function () {
return [
this.attr("ApcuesIdentify", "apcuesIdentifyAttr", "ApcuesIdentify", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEUModel.ApcuesIdentifyRec());
}, true, ShopperPortalEUModel.ApcuesIdentifyRec)
].concat(_super.attributesToDeclare.call(this));
};
ApcuesIdentifyRecord.fromStructure = function (str) {
return new ApcuesIdentifyRecord(new ApcuesIdentifyRecord.RecordClass({
apcuesIdentifyAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ApcuesIdentifyRecord._isAnonymousRecord = true;
ApcuesIdentifyRecord.UniqueId = "37f214dc-5c9e-5333-b6bd-f9e30bd2e5da";
ApcuesIdentifyRecord.init();
return ApcuesIdentifyRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.ApcuesIdentifyRecord = ApcuesIdentifyRecord;

});
define("ShopperPortalEU.model$ApcuesIdentifyRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$ApcuesIdentifyRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var ApcuesIdentifyRecordList = (function (_super) {
__extends(ApcuesIdentifyRecordList, _super);
function ApcuesIdentifyRecordList(defaults) {
_super.apply(this, arguments);
}
ApcuesIdentifyRecordList.itemType = ShopperPortalEUModel.ApcuesIdentifyRecord;
return ApcuesIdentifyRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.ApcuesIdentifyRecordList = ApcuesIdentifyRecordList;

});
define("ShopperPortalEU.model$LayoutHeaderOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Theme.model$LayoutHeaderOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var LayoutHeaderOptionsList = (function (_super) {
__extends(LayoutHeaderOptionsList, _super);
function LayoutHeaderOptionsList(defaults) {
_super.apply(this, arguments);
}
LayoutHeaderOptionsList.itemType = ShopperPortalEU_UI_ThemeModel.LayoutHeaderOptionsRec;
return LayoutHeaderOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.LayoutHeaderOptionsList = LayoutHeaderOptionsList;

});
define("ShopperPortalEU.model$CustomLinkOptionsIconRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsIconRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomLinkOptionsIconRecord = (function (_super) {
__extends(CustomLinkOptionsIconRecord, _super);
function CustomLinkOptionsIconRecord(defaults) {
_super.apply(this, arguments);
}
CustomLinkOptionsIconRecord.attributesToDeclare = function () {
return [
this.attr("CustomLinkOptionsIcon", "customLinkOptionsIconAttr", "CustomLinkOptionsIcon", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomLinkOptionsIconRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomLinkOptionsIconRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomLinkOptionsIconRecord.fromStructure = function (str) {
return new CustomLinkOptionsIconRecord(new CustomLinkOptionsIconRecord.RecordClass({
customLinkOptionsIconAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomLinkOptionsIconRecord._isAnonymousRecord = true;
CustomLinkOptionsIconRecord.UniqueId = "2e019d4d-cf37-19e2-5f5f-ccc0c48f9067";
CustomLinkOptionsIconRecord.init();
return CustomLinkOptionsIconRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomLinkOptionsIconRecord = CustomLinkOptionsIconRecord;

});
define("ShopperPortalEU.model$CodeInputStateRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CodeInputStateRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CodeInputStateRecord = (function (_super) {
__extends(CodeInputStateRecord, _super);
function CodeInputStateRecord(defaults) {
_super.apply(this, arguments);
}
CodeInputStateRecord.attributesToDeclare = function () {
return [
this.attr("CodeInputState", "codeInputStateAttr", "CodeInputState", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CodeInputStateRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CodeInputStateRec)
].concat(_super.attributesToDeclare.call(this));
};
CodeInputStateRecord.fromStructure = function (str) {
return new CodeInputStateRecord(new CodeInputStateRecord.RecordClass({
codeInputStateAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CodeInputStateRecord._isAnonymousRecord = true;
CodeInputStateRecord.UniqueId = "2e188e1f-f6e1-e282-0751-f03a3843fc88";
CodeInputStateRecord.init();
return CodeInputStateRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CodeInputStateRecord = CodeInputStateRecord;

});
define("ShopperPortalEU.model$CustomImageOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomImageOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomImageOptionsList = (function (_super) {
__extends(CustomImageOptionsList, _super);
function CustomImageOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomImageOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomImageOptionsRec;
return CustomImageOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomImageOptionsList = CustomImageOptionsList;

});
define("ShopperPortalEU.model$CustomDropdownListItemOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomDropdownListItemOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomDropdownListItemOptionsRecord = (function (_super) {
__extends(CustomDropdownListItemOptionsRecord, _super);
function CustomDropdownListItemOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomDropdownListItemOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomDropdownListItemOptions", "customDropdownListItemOptionsAttr", "CustomDropdownListItemOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomDropdownListItemOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomDropdownListItemOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomDropdownListItemOptionsRecord.fromStructure = function (str) {
return new CustomDropdownListItemOptionsRecord(new CustomDropdownListItemOptionsRecord.RecordClass({
customDropdownListItemOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomDropdownListItemOptionsRecord._isAnonymousRecord = true;
CustomDropdownListItemOptionsRecord.UniqueId = "638f81a9-e8ae-8c9e-8b68-2a1762d3ac1f";
CustomDropdownListItemOptionsRecord.init();
return CustomDropdownListItemOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomDropdownListItemOptionsRecord = CustomDropdownListItemOptionsRecord;

});
define("ShopperPortalEU.model$CustomDropdownListItemOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomDropdownListItemOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomDropdownListItemOptionsRecordList = (function (_super) {
__extends(CustomDropdownListItemOptionsRecordList, _super);
function CustomDropdownListItemOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownListItemOptionsRecordList.itemType = ShopperPortalEUModel.CustomDropdownListItemOptionsRecord;
return CustomDropdownListItemOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomDropdownListItemOptionsRecordList = CustomDropdownListItemOptionsRecordList;

});
define("ShopperPortalEU.model$CustomCardStateList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomCardStateRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomCardStateList = (function (_super) {
__extends(CustomCardStateList, _super);
function CustomCardStateList(defaults) {
_super.apply(this, arguments);
}
CustomCardStateList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomCardStateRec;
return CustomCardStateList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomCardStateList = CustomCardStateList;

});
define("ShopperPortalEU.model$DatatransCardGetCardInfoDataOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$DatatransCardGetCardInfoDataOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var DatatransCardGetCardInfoDataOptionsList = (function (_super) {
__extends(DatatransCardGetCardInfoDataOptionsList, _super);
function DatatransCardGetCardInfoDataOptionsList(defaults) {
_super.apply(this, arguments);
}
DatatransCardGetCardInfoDataOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.DatatransCardGetCardInfoDataOptionsRec;
return DatatransCardGetCardInfoDataOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.DatatransCardGetCardInfoDataOptionsList = DatatransCardGetCardInfoDataOptionsList;

});
define("ShopperPortalEU.model$CustomDropdownListValidationOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomDropdownListValidationOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomDropdownListValidationOptionsList = (function (_super) {
__extends(CustomDropdownListValidationOptionsList, _super);
function CustomDropdownListValidationOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownListValidationOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValidationOptionsRec;
return CustomDropdownListValidationOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomDropdownListValidationOptionsList = CustomDropdownListValidationOptionsList;

});
define("ShopperPortalEU.model$CustomSwitchOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomSwitchOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomSwitchOptionsList = (function (_super) {
__extends(CustomSwitchOptionsList, _super);
function CustomSwitchOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomSwitchOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomSwitchOptionsRec;
return CustomSwitchOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomSwitchOptionsList = CustomSwitchOptionsList;

});
define("ShopperPortalEU.model$CustomListOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomListOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomListOptionsRecord = (function (_super) {
__extends(CustomListOptionsRecord, _super);
function CustomListOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomListOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomListOptions", "customListOptionsAttr", "CustomListOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomListOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomListOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomListOptionsRecord.fromStructure = function (str) {
return new CustomListOptionsRecord(new CustomListOptionsRecord.RecordClass({
customListOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomListOptionsRecord._isAnonymousRecord = true;
CustomListOptionsRecord.UniqueId = "a1400fca-edb5-5272-3b04-5c4be9f99386";
CustomListOptionsRecord.init();
return CustomListOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomListOptionsRecord = CustomListOptionsRecord;

});
define("ShopperPortalEU.model$CustomListOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomListOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomListOptionsRecordList = (function (_super) {
__extends(CustomListOptionsRecordList, _super);
function CustomListOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomListOptionsRecordList.itemType = ShopperPortalEUModel.CustomListOptionsRecord;
return CustomListOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomListOptionsRecordList = CustomListOptionsRecordList;

});
define("ShopperPortalEU.model$CustomDropdownOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomDropdownOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomDropdownOptionsList = (function (_super) {
__extends(CustomDropdownOptionsList, _super);
function CustomDropdownOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomDropdownOptionsRec;
return CustomDropdownOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomDropdownOptionsList = CustomDropdownOptionsList;

});
define("ShopperPortalEU.model$CircleIconIconOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CircleIconIconOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CircleIconIconOptionsList = (function (_super) {
__extends(CircleIconIconOptionsList, _super);
function CircleIconIconOptionsList(defaults) {
_super.apply(this, arguments);
}
CircleIconIconOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CircleIconIconOptionsRec;
return CircleIconIconOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CircleIconIconOptionsList = CircleIconIconOptionsList;

});
define("ShopperPortalEU.model$CustomButtonItemOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomButtonItemOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomButtonItemOptionsList = (function (_super) {
__extends(CustomButtonItemOptionsList, _super);
function CustomButtonItemOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomButtonItemOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomButtonItemOptionsRec;
return CustomButtonItemOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomButtonItemOptionsList = CustomButtonItemOptionsList;

});
define("ShopperPortalEU.model$", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var TextList = (function (_super) {
__extends(TextList, _super);
function TextList(defaults) {
_super.apply(this, arguments);
}
TextList.itemType = OS.DataTypes.DataTypes.Text;
return TextList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.TextList = TextList;

});
define("ShopperPortalEU.model$CustomDropdownCustomOptionRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomDropdownCustomOptionRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomDropdownCustomOptionRecord = (function (_super) {
__extends(CustomDropdownCustomOptionRecord, _super);
function CustomDropdownCustomOptionRecord(defaults) {
_super.apply(this, arguments);
}
CustomDropdownCustomOptionRecord.attributesToDeclare = function () {
return [
this.attr("CustomDropdownCustomOption", "customDropdownCustomOptionAttr", "CustomDropdownCustomOption", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomDropdownCustomOptionRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomDropdownCustomOptionRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomDropdownCustomOptionRecord.fromStructure = function (str) {
return new CustomDropdownCustomOptionRecord(new CustomDropdownCustomOptionRecord.RecordClass({
customDropdownCustomOptionAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomDropdownCustomOptionRecord._isAnonymousRecord = true;
CustomDropdownCustomOptionRecord.UniqueId = "3687a322-d2ea-5254-1480-006e32a7ad41";
CustomDropdownCustomOptionRecord.init();
return CustomDropdownCustomOptionRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomDropdownCustomOptionRecord = CustomDropdownCustomOptionRecord;

});
define("ShopperPortalEU.model$FlexOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$FlexOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var FlexOptionsRecord = (function (_super) {
__extends(FlexOptionsRecord, _super);
function FlexOptionsRecord(defaults) {
_super.apply(this, arguments);
}
FlexOptionsRecord.attributesToDeclare = function () {
return [
this.attr("FlexOptions", "flexOptionsAttr", "FlexOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
FlexOptionsRecord.fromStructure = function (str) {
return new FlexOptionsRecord(new FlexOptionsRecord.RecordClass({
flexOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
FlexOptionsRecord._isAnonymousRecord = true;
FlexOptionsRecord.UniqueId = "36d7e934-918c-291e-bc60-83ca9eb7f388";
FlexOptionsRecord.init();
return FlexOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.FlexOptionsRecord = FlexOptionsRecord;

});
define("ShopperPortalEU.model$CustomDropdownNullOptionRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomDropdownNullOptionRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomDropdownNullOptionRecord = (function (_super) {
__extends(CustomDropdownNullOptionRecord, _super);
function CustomDropdownNullOptionRecord(defaults) {
_super.apply(this, arguments);
}
CustomDropdownNullOptionRecord.attributesToDeclare = function () {
return [
this.attr("CustomDropdownNullOption", "customDropdownNullOptionAttr", "CustomDropdownNullOption", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomDropdownNullOptionRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomDropdownNullOptionRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomDropdownNullOptionRecord.fromStructure = function (str) {
return new CustomDropdownNullOptionRecord(new CustomDropdownNullOptionRecord.RecordClass({
customDropdownNullOptionAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomDropdownNullOptionRecord._isAnonymousRecord = true;
CustomDropdownNullOptionRecord.UniqueId = "6cfdb0e0-93fb-4738-d809-3d3ce42db1ee";
CustomDropdownNullOptionRecord.init();
return CustomDropdownNullOptionRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomDropdownNullOptionRecord = CustomDropdownNullOptionRecord;

});
define("ShopperPortalEU.model$CustomDropdownNullOptionRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomDropdownNullOptionRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomDropdownNullOptionRecordList = (function (_super) {
__extends(CustomDropdownNullOptionRecordList, _super);
function CustomDropdownNullOptionRecordList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownNullOptionRecordList.itemType = ShopperPortalEUModel.CustomDropdownNullOptionRecord;
return CustomDropdownNullOptionRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomDropdownNullOptionRecordList = CustomDropdownNullOptionRecordList;

});
define("ShopperPortalEU.model$GetShopperResponseRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU.model", "ShopperPortalEU_Shopper_IS.model$GetShopperResponseRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var GetShopperResponseRecord = (function (_super) {
__extends(GetShopperResponseRecord, _super);
function GetShopperResponseRecord(defaults) {
_super.apply(this, arguments);
}
GetShopperResponseRecord.attributesToDeclare = function () {
return [
this.attr("GetShopperResponse", "getShopperResponseAttr", "GetShopperResponse", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Shopper_ISModel.GetShopperResponseRec());
}, true, ShopperPortalEU_Shopper_ISModel.GetShopperResponseRec)
].concat(_super.attributesToDeclare.call(this));
};
GetShopperResponseRecord.fromStructure = function (str) {
return new GetShopperResponseRecord(new GetShopperResponseRecord.RecordClass({
getShopperResponseAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
GetShopperResponseRecord._isAnonymousRecord = true;
GetShopperResponseRecord.UniqueId = "d97a7288-58bb-d5f9-7397-3049472192c4";
GetShopperResponseRecord.init();
return GetShopperResponseRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.GetShopperResponseRecord = GetShopperResponseRecord;

});
define("ShopperPortalEU.model$GetShopperResponseRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$GetShopperResponseRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var GetShopperResponseRecordList = (function (_super) {
__extends(GetShopperResponseRecordList, _super);
function GetShopperResponseRecordList(defaults) {
_super.apply(this, arguments);
}
GetShopperResponseRecordList.itemType = ShopperPortalEUModel.GetShopperResponseRecord;
return GetShopperResponseRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.GetShopperResponseRecordList = GetShopperResponseRecordList;

});
define("ShopperPortalEU.model$CustomDropdownNullOptionList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomDropdownNullOptionRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomDropdownNullOptionList = (function (_super) {
__extends(CustomDropdownNullOptionList, _super);
function CustomDropdownNullOptionList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownNullOptionList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomDropdownNullOptionRec;
return CustomDropdownNullOptionList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomDropdownNullOptionList = CustomDropdownNullOptionList;

});
define("ShopperPortalEU.model$CustomOfficeInfo_WrapperList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_API.model", "ShopperPortalEU.model", "ShopperPortalEU_API.model$CustomOfficeInfo_WrapperRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_API"], function (exports, OutSystems, ShopperPortalEU_APIModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomOfficeInfo_WrapperList = (function (_super) {
__extends(CustomOfficeInfo_WrapperList, _super);
function CustomOfficeInfo_WrapperList(defaults) {
_super.apply(this, arguments);
}
CustomOfficeInfo_WrapperList.itemType = ShopperPortalEU_APIModel.CustomOfficeInfo_WrapperRec;
return CustomOfficeInfo_WrapperList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomOfficeInfo_WrapperList = CustomOfficeInfo_WrapperList;

});
define("ShopperPortalEU.model$CompleteDetails_PersonalDetailsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CompleteDetails_PersonalDetailsRec = (function (_super) {
__extends(CompleteDetails_PersonalDetailsRec, _super);
function CompleteDetails_PersonalDetailsRec(defaults) {
_super.apply(this, arguments);
}
CompleteDetails_PersonalDetailsRec.attributesToDeclare = function () {
return [
this.attr("Passport", "passportAttr", "passport", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("PassportExpiryDate", "passportExpiryDateAttr", "passportExpiryDate", false, false, OS.DataTypes.DataTypes.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("PassportCountry", "passportCountryAttr", "passportCountry", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("GivenNames", "givenNamesAttr", "givenNames", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Surname", "surnameAttr", "surname", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("BirthDate", "birthDateAttr", "birthDate", false, false, OS.DataTypes.DataTypes.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("Nationality", "nationalityAttr", "nationality", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CompleteDetails_PersonalDetailsRec.init();
return CompleteDetails_PersonalDetailsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CompleteDetails_PersonalDetailsRec = CompleteDetails_PersonalDetailsRec;

});
define("ShopperPortalEU.model$CompleteDetails_PersonalDetailsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CompleteDetails_PersonalDetailsRec"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CompleteDetails_PersonalDetailsRecord = (function (_super) {
__extends(CompleteDetails_PersonalDetailsRecord, _super);
function CompleteDetails_PersonalDetailsRecord(defaults) {
_super.apply(this, arguments);
}
CompleteDetails_PersonalDetailsRecord.attributesToDeclare = function () {
return [
this.attr("CompleteDetails_PersonalDetails", "completeDetails_PersonalDetailsAttr", "CompleteDetails_PersonalDetails", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEUModel.CompleteDetails_PersonalDetailsRec());
}, true, ShopperPortalEUModel.CompleteDetails_PersonalDetailsRec)
].concat(_super.attributesToDeclare.call(this));
};
CompleteDetails_PersonalDetailsRecord.fromStructure = function (str) {
return new CompleteDetails_PersonalDetailsRecord(new CompleteDetails_PersonalDetailsRecord.RecordClass({
completeDetails_PersonalDetailsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CompleteDetails_PersonalDetailsRecord._isAnonymousRecord = true;
CompleteDetails_PersonalDetailsRecord.UniqueId = "53a1064e-bead-f936-20b4-72ebf5f225de";
CompleteDetails_PersonalDetailsRecord.init();
return CompleteDetails_PersonalDetailsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CompleteDetails_PersonalDetailsRecord = CompleteDetails_PersonalDetailsRecord;

});
define("ShopperPortalEU.model$CompleteDetails_PersonalDetailsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CompleteDetails_PersonalDetailsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CompleteDetails_PersonalDetailsRecordList = (function (_super) {
__extends(CompleteDetails_PersonalDetailsRecordList, _super);
function CompleteDetails_PersonalDetailsRecordList(defaults) {
_super.apply(this, arguments);
}
CompleteDetails_PersonalDetailsRecordList.itemType = ShopperPortalEUModel.CompleteDetails_PersonalDetailsRecord;
return CompleteDetails_PersonalDetailsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CompleteDetails_PersonalDetailsRecordList = CompleteDetails_PersonalDetailsRecordList;

});
define("ShopperPortalEU.model$CompleteDetails_ContactRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CompleteDetails_ContactRec = (function (_super) {
__extends(CompleteDetails_ContactRec, _super);
function CompleteDetails_ContactRec(defaults) {
_super.apply(this, arguments);
}
CompleteDetails_ContactRec.attributesToDeclare = function () {
return [
this.attr("Email", "emailAttr", "email", false, false, OS.DataTypes.DataTypes.Email, function () {
return "";
}, true), 
this.attr("MobileNumber", "mobileNumberAttr", "mobileNumber", false, false, OS.DataTypes.DataTypes.PhoneNumber, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CompleteDetails_ContactRec.init();
return CompleteDetails_ContactRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CompleteDetails_ContactRec = CompleteDetails_ContactRec;

});
define("ShopperPortalEU.model$CompleteDetails_ContactRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CompleteDetails_ContactRec"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CompleteDetails_ContactRecord = (function (_super) {
__extends(CompleteDetails_ContactRecord, _super);
function CompleteDetails_ContactRecord(defaults) {
_super.apply(this, arguments);
}
CompleteDetails_ContactRecord.attributesToDeclare = function () {
return [
this.attr("CompleteDetails_Contact", "completeDetails_ContactAttr", "CompleteDetails_Contact", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEUModel.CompleteDetails_ContactRec());
}, true, ShopperPortalEUModel.CompleteDetails_ContactRec)
].concat(_super.attributesToDeclare.call(this));
};
CompleteDetails_ContactRecord.fromStructure = function (str) {
return new CompleteDetails_ContactRecord(new CompleteDetails_ContactRecord.RecordClass({
completeDetails_ContactAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CompleteDetails_ContactRecord._isAnonymousRecord = true;
CompleteDetails_ContactRecord.UniqueId = "3a24bdcc-52dd-020a-f3c0-b9262bb0a9e6";
CompleteDetails_ContactRecord.init();
return CompleteDetails_ContactRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CompleteDetails_ContactRecord = CompleteDetails_ContactRecord;

});
define("ShopperPortalEU.model$UpdateCardRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU.model", "ShopperPortalEU_Shopper_IS.model$UpdateCardRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var UpdateCardRecord = (function (_super) {
__extends(UpdateCardRecord, _super);
function UpdateCardRecord(defaults) {
_super.apply(this, arguments);
}
UpdateCardRecord.attributesToDeclare = function () {
return [
this.attr("UpdateCard", "updateCardAttr", "UpdateCard", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Shopper_ISModel.UpdateCardRec());
}, true, ShopperPortalEU_Shopper_ISModel.UpdateCardRec)
].concat(_super.attributesToDeclare.call(this));
};
UpdateCardRecord.fromStructure = function (str) {
return new UpdateCardRecord(new UpdateCardRecord.RecordClass({
updateCardAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
UpdateCardRecord._isAnonymousRecord = true;
UpdateCardRecord.UniqueId = "92948489-f574-cf5e-cee2-940c8bf3009f";
UpdateCardRecord.init();
return UpdateCardRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.UpdateCardRecord = UpdateCardRecord;

});
define("ShopperPortalEU.model$UpdateCardRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$UpdateCardRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var UpdateCardRecordList = (function (_super) {
__extends(UpdateCardRecordList, _super);
function UpdateCardRecordList(defaults) {
_super.apply(this, arguments);
}
UpdateCardRecordList.itemType = ShopperPortalEUModel.UpdateCardRecord;
return UpdateCardRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.UpdateCardRecordList = UpdateCardRecordList;

});
define("ShopperPortalEU.model$CustomDropdownListSearchOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomDropdownListSearchOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomDropdownListSearchOptionsRecord = (function (_super) {
__extends(CustomDropdownListSearchOptionsRecord, _super);
function CustomDropdownListSearchOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomDropdownListSearchOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomDropdownListSearchOptions", "customDropdownListSearchOptionsAttr", "CustomDropdownListSearchOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomDropdownListSearchOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomDropdownListSearchOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomDropdownListSearchOptionsRecord.fromStructure = function (str) {
return new CustomDropdownListSearchOptionsRecord(new CustomDropdownListSearchOptionsRecord.RecordClass({
customDropdownListSearchOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomDropdownListSearchOptionsRecord._isAnonymousRecord = true;
CustomDropdownListSearchOptionsRecord.UniqueId = "a9b0268d-037a-07ad-4b71-9610c88fde47";
CustomDropdownListSearchOptionsRecord.init();
return CustomDropdownListSearchOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomDropdownListSearchOptionsRecord = CustomDropdownListSearchOptionsRecord;

});
define("ShopperPortalEU.model$CustomDropdownListSearchOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomDropdownListSearchOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomDropdownListSearchOptionsRecordList = (function (_super) {
__extends(CustomDropdownListSearchOptionsRecordList, _super);
function CustomDropdownListSearchOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownListSearchOptionsRecordList.itemType = ShopperPortalEUModel.CustomDropdownListSearchOptionsRecord;
return CustomDropdownListSearchOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomDropdownListSearchOptionsRecordList = CustomDropdownListSearchOptionsRecordList;

});
define("ShopperPortalEU.model$LayoutAuthenticationRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var LayoutAuthenticationRec = (function (_super) {
__extends(LayoutAuthenticationRec, _super);
function LayoutAuthenticationRec(defaults) {
_super.apply(this, arguments);
}
LayoutAuthenticationRec.attributesToDeclare = function () {
return [
this.attr("IsToUseAuth", "isToUseAuthAttr", "useAuth", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return true;
}, true), 
this.attr("NotAutomaticallyRedirect", "notAutomaticallyRedirectAttr", "notAutomaticallyRedirect", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("NotCheckMaintenance", "notCheckMaintenanceAttr", "notCheckMaintenance", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
LayoutAuthenticationRec.init();
return LayoutAuthenticationRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.LayoutAuthenticationRec = LayoutAuthenticationRec;

});
define("ShopperPortalEU.model$UnescapedHTMLOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$UnescapedHTMLOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var UnescapedHTMLOptionsRecord = (function (_super) {
__extends(UnescapedHTMLOptionsRecord, _super);
function UnescapedHTMLOptionsRecord(defaults) {
_super.apply(this, arguments);
}
UnescapedHTMLOptionsRecord.attributesToDeclare = function () {
return [
this.attr("UnescapedHTMLOptions", "unescapedHTMLOptionsAttr", "UnescapedHTMLOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.UnescapedHTMLOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.UnescapedHTMLOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
UnescapedHTMLOptionsRecord.fromStructure = function (str) {
return new UnescapedHTMLOptionsRecord(new UnescapedHTMLOptionsRecord.RecordClass({
unescapedHTMLOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
UnescapedHTMLOptionsRecord._isAnonymousRecord = true;
UnescapedHTMLOptionsRecord.UniqueId = "3c413115-6718-323c-b804-e37b70c13b19";
UnescapedHTMLOptionsRecord.init();
return UnescapedHTMLOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.UnescapedHTMLOptionsRecord = UnescapedHTMLOptionsRecord;

});
define("ShopperPortalEU.model$SpacingRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$SpacingRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var SpacingRecord = (function (_super) {
__extends(SpacingRecord, _super);
function SpacingRecord(defaults) {
_super.apply(this, arguments);
}
SpacingRecord.attributesToDeclare = function () {
return [
this.attr("Spacing", "spacingAttr", "Spacing", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.SpacingRec());
}, true, ShopperPortalEU_UI_ComponentsModel.SpacingRec)
].concat(_super.attributesToDeclare.call(this));
};
SpacingRecord.fromStructure = function (str) {
return new SpacingRecord(new SpacingRecord.RecordClass({
spacingAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
SpacingRecord._isAnonymousRecord = true;
SpacingRecord.UniqueId = "3c4eb9c7-9376-5b56-adf7-a4018c42b0e8";
SpacingRecord.init();
return SpacingRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.SpacingRecord = SpacingRecord;

});
define("ShopperPortalEU.model$RefundSummaryRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$RefundSummaryRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var RefundSummaryRecordList = (function (_super) {
__extends(RefundSummaryRecordList, _super);
function RefundSummaryRecordList(defaults) {
_super.apply(this, arguments);
}
RefundSummaryRecordList.itemType = ShopperPortalEUModel.RefundSummaryRecord;
return RefundSummaryRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.RefundSummaryRecordList = RefundSummaryRecordList;

});
define("ShopperPortalEU.model$FlexItemOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$FlexItemOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var FlexItemOptionsRecord = (function (_super) {
__extends(FlexItemOptionsRecord, _super);
function FlexItemOptionsRecord(defaults) {
_super.apply(this, arguments);
}
FlexItemOptionsRecord.attributesToDeclare = function () {
return [
this.attr("FlexItemOptions", "flexItemOptionsAttr", "FlexItemOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.FlexItemOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.FlexItemOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
FlexItemOptionsRecord.fromStructure = function (str) {
return new FlexItemOptionsRecord(new FlexItemOptionsRecord.RecordClass({
flexItemOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
FlexItemOptionsRecord._isAnonymousRecord = true;
FlexItemOptionsRecord.UniqueId = "990c2662-1e4a-d6aa-17e3-dddc0179d52b";
FlexItemOptionsRecord.init();
return FlexItemOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.FlexItemOptionsRecord = FlexItemOptionsRecord;

});
define("ShopperPortalEU.model$FlexItemOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$FlexItemOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var FlexItemOptionsRecordList = (function (_super) {
__extends(FlexItemOptionsRecordList, _super);
function FlexItemOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
FlexItemOptionsRecordList.itemType = ShopperPortalEUModel.FlexItemOptionsRecord;
return FlexItemOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.FlexItemOptionsRecordList = FlexItemOptionsRecordList;

});
define("ShopperPortalEU.model$CustomDropdownValidationOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomDropdownValidationOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomDropdownValidationOptionsList = (function (_super) {
__extends(CustomDropdownValidationOptionsList, _super);
function CustomDropdownValidationOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownValidationOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomDropdownValidationOptionsRec;
return CustomDropdownValidationOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomDropdownValidationOptionsList = CustomDropdownValidationOptionsList;

});
define("ShopperPortalEU.model$CodeInputStateList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CodeInputStateRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CodeInputStateList = (function (_super) {
__extends(CodeInputStateList, _super);
function CodeInputStateList(defaults) {
_super.apply(this, arguments);
}
CodeInputStateList.itemType = ShopperPortalEU_UI_ComponentsModel.CodeInputStateRec;
return CodeInputStateList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CodeInputStateList = CodeInputStateList;

});
define("ShopperPortalEU.model$CustomDropdownOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomDropdownOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomDropdownOptionsRecord = (function (_super) {
__extends(CustomDropdownOptionsRecord, _super);
function CustomDropdownOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomDropdownOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomDropdownOptions", "customDropdownOptionsAttr", "CustomDropdownOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomDropdownOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomDropdownOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomDropdownOptionsRecord.fromStructure = function (str) {
return new CustomDropdownOptionsRecord(new CustomDropdownOptionsRecord.RecordClass({
customDropdownOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomDropdownOptionsRecord._isAnonymousRecord = true;
CustomDropdownOptionsRecord.UniqueId = "3df1d35d-e5e1-cdca-1a81-6dd845f565bc";
CustomDropdownOptionsRecord.init();
return CustomDropdownOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomDropdownOptionsRecord = CustomDropdownOptionsRecord;

});
define("ShopperPortalEU.model$PostSiteverifyResponseRecord", ["exports", "OutSystems/ClientRuntime/Main", "reCAPTCHAReact.model", "ShopperPortalEU.model", "reCAPTCHAReact.model$PostSiteverifyResponseRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$reCAPTCHAReact"], function (exports, OutSystems, reCAPTCHAReactModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var PostSiteverifyResponseRecord = (function (_super) {
__extends(PostSiteverifyResponseRecord, _super);
function PostSiteverifyResponseRecord(defaults) {
_super.apply(this, arguments);
}
PostSiteverifyResponseRecord.attributesToDeclare = function () {
return [
this.attr("PostSiteverifyResponse", "postSiteverifyResponseAttr", "PostSiteverifyResponse", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new reCAPTCHAReactModel.PostSiteverifyResponseRec());
}, true, reCAPTCHAReactModel.PostSiteverifyResponseRec)
].concat(_super.attributesToDeclare.call(this));
};
PostSiteverifyResponseRecord.fromStructure = function (str) {
return new PostSiteverifyResponseRecord(new PostSiteverifyResponseRecord.RecordClass({
postSiteverifyResponseAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
PostSiteverifyResponseRecord._isAnonymousRecord = true;
PostSiteverifyResponseRecord.UniqueId = "3e320baa-4526-8d27-7954-3bfdb317fdd1";
PostSiteverifyResponseRecord.init();
return PostSiteverifyResponseRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.PostSiteverifyResponseRecord = PostSiteverifyResponseRecord;

});
define("ShopperPortalEU.model$SPFormStatusRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model", "ShopperPortalEU.model", "ShopperPortalEU_CS.model$SPFormStatusRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_CS"], function (exports, OutSystems, ShopperPortalEU_CSModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var SPFormStatusRecord = (function (_super) {
__extends(SPFormStatusRecord, _super);
function SPFormStatusRecord(defaults) {
_super.apply(this, arguments);
}
SPFormStatusRecord.attributesToDeclare = function () {
return [
this.attr("SPFormStatus", "sPFormStatusAttr", "SPFormStatus", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_CSModel.SPFormStatusRec());
}, true, ShopperPortalEU_CSModel.SPFormStatusRec)
].concat(_super.attributesToDeclare.call(this));
};
SPFormStatusRecord.fromStructure = function (str) {
return new SPFormStatusRecord(new SPFormStatusRecord.RecordClass({
sPFormStatusAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
SPFormStatusRecord._isAnonymousRecord = true;
SPFormStatusRecord.UniqueId = "3e57435d-0124-13a2-dbac-617b836b9cf2";
SPFormStatusRecord.init();
return SPFormStatusRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.SPFormStatusRecord = SPFormStatusRecord;

});
define("ShopperPortalEU.model$CustomCheckboxOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomCheckboxOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomCheckboxOptionsRecord = (function (_super) {
__extends(CustomCheckboxOptionsRecord, _super);
function CustomCheckboxOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomCheckboxOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomCheckboxOptions", "customCheckboxOptionsAttr", "CustomCheckboxOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomCheckboxOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomCheckboxOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomCheckboxOptionsRecord.fromStructure = function (str) {
return new CustomCheckboxOptionsRecord(new CustomCheckboxOptionsRecord.RecordClass({
customCheckboxOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomCheckboxOptionsRecord._isAnonymousRecord = true;
CustomCheckboxOptionsRecord.UniqueId = "3e5aafc3-6899-6995-b076-b9e41bbe107f";
CustomCheckboxOptionsRecord.init();
return CustomCheckboxOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomCheckboxOptionsRecord = CustomCheckboxOptionsRecord;

});
define("ShopperPortalEU.model$CityInfo_WrapperRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_API.model", "ShopperPortalEU.model", "ShopperPortalEU_API.model$CityInfo_WrapperRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_API"], function (exports, OutSystems, ShopperPortalEU_APIModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CityInfo_WrapperRecord = (function (_super) {
__extends(CityInfo_WrapperRecord, _super);
function CityInfo_WrapperRecord(defaults) {
_super.apply(this, arguments);
}
CityInfo_WrapperRecord.attributesToDeclare = function () {
return [
this.attr("CityInfo_Wrapper", "cityInfo_WrapperAttr", "CityInfo_Wrapper", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_APIModel.CityInfo_WrapperRec());
}, true, ShopperPortalEU_APIModel.CityInfo_WrapperRec)
].concat(_super.attributesToDeclare.call(this));
};
CityInfo_WrapperRecord.fromStructure = function (str) {
return new CityInfo_WrapperRecord(new CityInfo_WrapperRecord.RecordClass({
cityInfo_WrapperAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CityInfo_WrapperRecord._isAnonymousRecord = true;
CityInfo_WrapperRecord.UniqueId = "ac8270ed-5a51-e287-9f5e-543890311355";
CityInfo_WrapperRecord.init();
return CityInfo_WrapperRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CityInfo_WrapperRecord = CityInfo_WrapperRecord;

});
define("ShopperPortalEU.model$CityInfo_WrapperRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CityInfo_WrapperRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CityInfo_WrapperRecordList = (function (_super) {
__extends(CityInfo_WrapperRecordList, _super);
function CityInfo_WrapperRecordList(defaults) {
_super.apply(this, arguments);
}
CityInfo_WrapperRecordList.itemType = ShopperPortalEUModel.CityInfo_WrapperRecord;
return CityInfo_WrapperRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CityInfo_WrapperRecordList = CityInfo_WrapperRecordList;

});
define("ShopperPortalEU.model$CardBackgroundOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CardBackgroundOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CardBackgroundOptionsRecord = (function (_super) {
__extends(CardBackgroundOptionsRecord, _super);
function CardBackgroundOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CardBackgroundOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CardBackgroundOptions", "cardBackgroundOptionsAttr", "CardBackgroundOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CardBackgroundOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CardBackgroundOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CardBackgroundOptionsRecord.fromStructure = function (str) {
return new CardBackgroundOptionsRecord(new CardBackgroundOptionsRecord.RecordClass({
cardBackgroundOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CardBackgroundOptionsRecord._isAnonymousRecord = true;
CardBackgroundOptionsRecord.UniqueId = "853c3fa9-2a8f-9ac6-db38-a696a50334a5";
CardBackgroundOptionsRecord.init();
return CardBackgroundOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CardBackgroundOptionsRecord = CardBackgroundOptionsRecord;

});
define("ShopperPortalEU.model$CardBackgroundOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CardBackgroundOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CardBackgroundOptionsRecordList = (function (_super) {
__extends(CardBackgroundOptionsRecordList, _super);
function CardBackgroundOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CardBackgroundOptionsRecordList.itemType = ShopperPortalEUModel.CardBackgroundOptionsRecord;
return CardBackgroundOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CardBackgroundOptionsRecordList = CardBackgroundOptionsRecordList;

});
define("ShopperPortalEU.model$CustomMessageOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomMessageOptionsRecord = (function (_super) {
__extends(CustomMessageOptionsRecord, _super);
function CustomMessageOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomMessageOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomMessageOptions", "customMessageOptionsAttr", "CustomMessageOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec());
}, true, ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomMessageOptionsRecord.fromStructure = function (str) {
return new CustomMessageOptionsRecord(new CustomMessageOptionsRecord.RecordClass({
customMessageOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomMessageOptionsRecord._isAnonymousRecord = true;
CustomMessageOptionsRecord.UniqueId = "82198c5f-6a28-d6f8-f60f-f53ae31dbc72";
CustomMessageOptionsRecord.init();
return CustomMessageOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomMessageOptionsRecord = CustomMessageOptionsRecord;

});
define("ShopperPortalEU.model$CustomMessageOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomMessageOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomMessageOptionsRecordList = (function (_super) {
__extends(CustomMessageOptionsRecordList, _super);
function CustomMessageOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomMessageOptionsRecordList.itemType = ShopperPortalEUModel.CustomMessageOptionsRecord;
return CustomMessageOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomMessageOptionsRecordList = CustomMessageOptionsRecordList;

});
define("ShopperPortalEU.model$ScanPassportErrorRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$ScanPassportErrorRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var ScanPassportErrorRecord = (function (_super) {
__extends(ScanPassportErrorRecord, _super);
function ScanPassportErrorRecord(defaults) {
_super.apply(this, arguments);
}
ScanPassportErrorRecord.attributesToDeclare = function () {
return [
this.attr("ScanPassportError", "scanPassportErrorAttr", "ScanPassportError", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.ScanPassportErrorRec());
}, true, ShopperPortalEU_UI_ComponentsModel.ScanPassportErrorRec)
].concat(_super.attributesToDeclare.call(this));
};
ScanPassportErrorRecord.fromStructure = function (str) {
return new ScanPassportErrorRecord(new ScanPassportErrorRecord.RecordClass({
scanPassportErrorAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ScanPassportErrorRecord._isAnonymousRecord = true;
ScanPassportErrorRecord.UniqueId = "9d5293ab-759e-d5d4-2408-25074a96272a";
ScanPassportErrorRecord.init();
return ScanPassportErrorRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.ScanPassportErrorRecord = ScanPassportErrorRecord;

});
define("ShopperPortalEU.model$ScanPassportErrorRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$ScanPassportErrorRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var ScanPassportErrorRecordList = (function (_super) {
__extends(ScanPassportErrorRecordList, _super);
function ScanPassportErrorRecordList(defaults) {
_super.apply(this, arguments);
}
ScanPassportErrorRecordList.itemType = ShopperPortalEUModel.ScanPassportErrorRecord;
return ScanPassportErrorRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.ScanPassportErrorRecordList = ScanPassportErrorRecordList;

});
define("ShopperPortalEU.model$HeaderActionOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Theme.model$HeaderActionOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var HeaderActionOptionsRecord = (function (_super) {
__extends(HeaderActionOptionsRecord, _super);
function HeaderActionOptionsRecord(defaults) {
_super.apply(this, arguments);
}
HeaderActionOptionsRecord.attributesToDeclare = function () {
return [
this.attr("HeaderActionOptions", "headerActionOptionsAttr", "HeaderActionOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ThemeModel.HeaderActionOptionsRec());
}, true, ShopperPortalEU_UI_ThemeModel.HeaderActionOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
HeaderActionOptionsRecord.fromStructure = function (str) {
return new HeaderActionOptionsRecord(new HeaderActionOptionsRecord.RecordClass({
headerActionOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
HeaderActionOptionsRecord._isAnonymousRecord = true;
HeaderActionOptionsRecord.UniqueId = "42291f82-e54f-123c-b29c-4e8f8804ecf6";
HeaderActionOptionsRecord.init();
return HeaderActionOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.HeaderActionOptionsRecord = HeaderActionOptionsRecord;

});
define("ShopperPortalEU.model$DatatransCardOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$DatatransCardOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var DatatransCardOptionsRecord = (function (_super) {
__extends(DatatransCardOptionsRecord, _super);
function DatatransCardOptionsRecord(defaults) {
_super.apply(this, arguments);
}
DatatransCardOptionsRecord.attributesToDeclare = function () {
return [
this.attr("DatatransCardOptions", "datatransCardOptionsAttr", "DatatransCardOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.DatatransCardOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.DatatransCardOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
DatatransCardOptionsRecord.fromStructure = function (str) {
return new DatatransCardOptionsRecord(new DatatransCardOptionsRecord.RecordClass({
datatransCardOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
DatatransCardOptionsRecord._isAnonymousRecord = true;
DatatransCardOptionsRecord.UniqueId = "f7081994-1aad-fe2b-050a-e1a1bd9b31a3";
DatatransCardOptionsRecord.init();
return DatatransCardOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.DatatransCardOptionsRecord = DatatransCardOptionsRecord;

});
define("ShopperPortalEU.model$DatatransCardOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$DatatransCardOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var DatatransCardOptionsRecordList = (function (_super) {
__extends(DatatransCardOptionsRecordList, _super);
function DatatransCardOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
DatatransCardOptionsRecordList.itemType = ShopperPortalEUModel.DatatransCardOptionsRecord;
return DatatransCardOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.DatatransCardOptionsRecordList = DatatransCardOptionsRecordList;

});
define("ShopperPortalEU.model$PaddingSideOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$PaddingSideOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var PaddingSideOptionsRecord = (function (_super) {
__extends(PaddingSideOptionsRecord, _super);
function PaddingSideOptionsRecord(defaults) {
_super.apply(this, arguments);
}
PaddingSideOptionsRecord.attributesToDeclare = function () {
return [
this.attr("PaddingSideOptions", "paddingSideOptionsAttr", "PaddingSideOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.PaddingSideOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.PaddingSideOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
PaddingSideOptionsRecord.fromStructure = function (str) {
return new PaddingSideOptionsRecord(new PaddingSideOptionsRecord.RecordClass({
paddingSideOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
PaddingSideOptionsRecord._isAnonymousRecord = true;
PaddingSideOptionsRecord.UniqueId = "431bdd9e-e57c-95cb-849a-3dd39314c220";
PaddingSideOptionsRecord.init();
return PaddingSideOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.PaddingSideOptionsRecord = PaddingSideOptionsRecord;

});
define("ShopperPortalEU.model$ApplicationHeaderRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var ApplicationHeaderRec = (function (_super) {
__extends(ApplicationHeaderRec, _super);
function ApplicationHeaderRec(defaults) {
_super.apply(this, arguments);
}
ApplicationHeaderRec.attributesToDeclare = function () {
return [
this.attr("IsLargerLogo", "isLargerLogoAttr", "largerLogo", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("ScrollTitle", "scrollTitleAttr", "scrollTitle", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ApplicationHeaderRec.init();
return ApplicationHeaderRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.ApplicationHeaderRec = ApplicationHeaderRec;

});
define("ShopperPortalEU.model$ApplicationHeaderRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$ApplicationHeaderRec"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var ApplicationHeaderRecord = (function (_super) {
__extends(ApplicationHeaderRecord, _super);
function ApplicationHeaderRecord(defaults) {
_super.apply(this, arguments);
}
ApplicationHeaderRecord.attributesToDeclare = function () {
return [
this.attr("ApplicationHeader", "applicationHeaderAttr", "ApplicationHeader", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEUModel.ApplicationHeaderRec());
}, true, ShopperPortalEUModel.ApplicationHeaderRec)
].concat(_super.attributesToDeclare.call(this));
};
ApplicationHeaderRecord.fromStructure = function (str) {
return new ApplicationHeaderRecord(new ApplicationHeaderRecord.RecordClass({
applicationHeaderAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ApplicationHeaderRecord._isAnonymousRecord = true;
ApplicationHeaderRecord.UniqueId = "441bb3c7-26b2-5a27-40d1-d7b8797e8365";
ApplicationHeaderRecord.init();
return ApplicationHeaderRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.ApplicationHeaderRecord = ApplicationHeaderRecord;

});
define("ShopperPortalEU.model$ScanPassportErrorList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$ScanPassportErrorRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var ScanPassportErrorList = (function (_super) {
__extends(ScanPassportErrorList, _super);
function ScanPassportErrorList(defaults) {
_super.apply(this, arguments);
}
ScanPassportErrorList.itemType = ShopperPortalEU_UI_ComponentsModel.ScanPassportErrorRec;
return ScanPassportErrorList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.ScanPassportErrorList = ScanPassportErrorList;

});
define("ShopperPortalEU.model$CustomInputValidationOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomInputValidationOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomInputValidationOptionsList = (function (_super) {
__extends(CustomInputValidationOptionsList, _super);
function CustomInputValidationOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomInputValidationOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomInputValidationOptionsRec;
return CustomInputValidationOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomInputValidationOptionsList = CustomInputValidationOptionsList;

});
define("ShopperPortalEU.model$ScanPassportDataRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$ScanPassportDataRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var ScanPassportDataRecord = (function (_super) {
__extends(ScanPassportDataRecord, _super);
function ScanPassportDataRecord(defaults) {
_super.apply(this, arguments);
}
ScanPassportDataRecord.attributesToDeclare = function () {
return [
this.attr("ScanPassportData", "scanPassportDataAttr", "ScanPassportData", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.ScanPassportDataRec());
}, true, ShopperPortalEU_UI_ComponentsModel.ScanPassportDataRec)
].concat(_super.attributesToDeclare.call(this));
};
ScanPassportDataRecord.fromStructure = function (str) {
return new ScanPassportDataRecord(new ScanPassportDataRecord.RecordClass({
scanPassportDataAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ScanPassportDataRecord._isAnonymousRecord = true;
ScanPassportDataRecord.UniqueId = "a545501d-baa2-1d95-5a5a-e7b648eb97dd";
ScanPassportDataRecord.init();
return ScanPassportDataRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.ScanPassportDataRecord = ScanPassportDataRecord;

});
define("ShopperPortalEU.model$ScanPassportDataRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$ScanPassportDataRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var ScanPassportDataRecordList = (function (_super) {
__extends(ScanPassportDataRecordList, _super);
function ScanPassportDataRecordList(defaults) {
_super.apply(this, arguments);
}
ScanPassportDataRecordList.itemType = ShopperPortalEUModel.ScanPassportDataRecord;
return ScanPassportDataRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.ScanPassportDataRecordList = ScanPassportDataRecordList;

});
define("ShopperPortalEU.model$ResponseRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$ResponseRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var ResponseRecordList = (function (_super) {
__extends(ResponseRecordList, _super);
function ResponseRecordList(defaults) {
_super.apply(this, arguments);
}
ResponseRecordList.itemType = ShopperPortalEUModel.ResponseRecord;
return ResponseRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.ResponseRecordList = ResponseRecordList;

});
define("ShopperPortalEU.model$CustomListOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomListOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomListOptionsList = (function (_super) {
__extends(CustomListOptionsList, _super);
function CustomListOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomListOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomListOptionsRec;
return CustomListOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomListOptionsList = CustomListOptionsList;

});
define("ShopperPortalEU.model$ApplicationHeaderOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Theme.model$ApplicationHeaderOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var ApplicationHeaderOptionsRecord = (function (_super) {
__extends(ApplicationHeaderOptionsRecord, _super);
function ApplicationHeaderOptionsRecord(defaults) {
_super.apply(this, arguments);
}
ApplicationHeaderOptionsRecord.attributesToDeclare = function () {
return [
this.attr("ApplicationHeaderOptions", "applicationHeaderOptionsAttr", "ApplicationHeaderOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ThemeModel.ApplicationHeaderOptionsRec());
}, true, ShopperPortalEU_UI_ThemeModel.ApplicationHeaderOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
ApplicationHeaderOptionsRecord.fromStructure = function (str) {
return new ApplicationHeaderOptionsRecord(new ApplicationHeaderOptionsRecord.RecordClass({
applicationHeaderOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ApplicationHeaderOptionsRecord._isAnonymousRecord = true;
ApplicationHeaderOptionsRecord.UniqueId = "9c3867d1-8601-1237-9093-e41be169d805";
ApplicationHeaderOptionsRecord.init();
return ApplicationHeaderOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.ApplicationHeaderOptionsRecord = ApplicationHeaderOptionsRecord;

});
define("ShopperPortalEU.model$ApplicationHeaderOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$ApplicationHeaderOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var ApplicationHeaderOptionsRecordList = (function (_super) {
__extends(ApplicationHeaderOptionsRecordList, _super);
function ApplicationHeaderOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
ApplicationHeaderOptionsRecordList.itemType = ShopperPortalEUModel.ApplicationHeaderOptionsRecord;
return ApplicationHeaderOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.ApplicationHeaderOptionsRecordList = ApplicationHeaderOptionsRecordList;

});
define("ShopperPortalEU.model$CustomCarouselOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomCarouselOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomCarouselOptionsList = (function (_super) {
__extends(CustomCarouselOptionsList, _super);
function CustomCarouselOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomCarouselOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomCarouselOptionsRec;
return CustomCarouselOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomCarouselOptionsList = CustomCarouselOptionsList;

});
define("ShopperPortalEU.model$OpenPDFOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$OpenPDFOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var OpenPDFOptionsList = (function (_super) {
__extends(OpenPDFOptionsList, _super);
function OpenPDFOptionsList(defaults) {
_super.apply(this, arguments);
}
OpenPDFOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.OpenPDFOptionsRec;
return OpenPDFOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.OpenPDFOptionsList = OpenPDFOptionsList;

});
define("ShopperPortalEU.model$RequestRefundCardRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU.model", "ShopperPortalEU_Shopper_IS.model$GetCardsResponseRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var RequestRefundCardRec = (function (_super) {
__extends(RequestRefundCardRec, _super);
function RequestRefundCardRec(defaults) {
_super.apply(this, arguments);
}
RequestRefundCardRec.attributesToDeclare = function () {
return [
this.attr("Card", "cardAttr", "Card", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("IsSeparated", "isSeparatedAttr", "IsSeparated", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("GetCardsResponse", "getCardsResponseAttr", "GetCardsResponse", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Shopper_ISModel.GetCardsResponseRec());
}, true, ShopperPortalEU_Shopper_ISModel.GetCardsResponseRec)
].concat(_super.attributesToDeclare.call(this));
};
RequestRefundCardRec.init();
return RequestRefundCardRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.RequestRefundCardRec = RequestRefundCardRec;

});
define("ShopperPortalEU.model$RequestRefundCardRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$RequestRefundCardRec"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var RequestRefundCardRecord = (function (_super) {
__extends(RequestRefundCardRecord, _super);
function RequestRefundCardRecord(defaults) {
_super.apply(this, arguments);
}
RequestRefundCardRecord.attributesToDeclare = function () {
return [
this.attr("RequestRefundCard", "requestRefundCardAttr", "RequestRefundCard", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEUModel.RequestRefundCardRec());
}, true, ShopperPortalEUModel.RequestRefundCardRec)
].concat(_super.attributesToDeclare.call(this));
};
RequestRefundCardRecord.fromStructure = function (str) {
return new RequestRefundCardRecord(new RequestRefundCardRecord.RecordClass({
requestRefundCardAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
RequestRefundCardRecord._isAnonymousRecord = true;
RequestRefundCardRecord.UniqueId = "c1fdb6d3-7c5b-7404-cb5f-c23412c3506c";
RequestRefundCardRecord.init();
return RequestRefundCardRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.RequestRefundCardRecord = RequestRefundCardRecord;

});
define("ShopperPortalEU.model$RequestRefundCardRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$RequestRefundCardRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var RequestRefundCardRecordList = (function (_super) {
__extends(RequestRefundCardRecordList, _super);
function RequestRefundCardRecordList(defaults) {
_super.apply(this, arguments);
}
RequestRefundCardRecordList.itemType = ShopperPortalEUModel.RequestRefundCardRecord;
return RequestRefundCardRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.RequestRefundCardRecordList = RequestRefundCardRecordList;

});
define("ShopperPortalEU.model$CodeInputValidationOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CodeInputValidationOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CodeInputValidationOptionsRecord = (function (_super) {
__extends(CodeInputValidationOptionsRecord, _super);
function CodeInputValidationOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CodeInputValidationOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CodeInputValidationOptions", "codeInputValidationOptionsAttr", "CodeInputValidationOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CodeInputValidationOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CodeInputValidationOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CodeInputValidationOptionsRecord.fromStructure = function (str) {
return new CodeInputValidationOptionsRecord(new CodeInputValidationOptionsRecord.RecordClass({
codeInputValidationOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CodeInputValidationOptionsRecord._isAnonymousRecord = true;
CodeInputValidationOptionsRecord.UniqueId = "92d540a8-d40e-01c7-36a3-f5d94a693375";
CodeInputValidationOptionsRecord.init();
return CodeInputValidationOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CodeInputValidationOptionsRecord = CodeInputValidationOptionsRecord;

});
define("ShopperPortalEU.model$CodeInputValidationOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CodeInputValidationOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CodeInputValidationOptionsRecordList = (function (_super) {
__extends(CodeInputValidationOptionsRecordList, _super);
function CodeInputValidationOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CodeInputValidationOptionsRecordList.itemType = ShopperPortalEUModel.CodeInputValidationOptionsRecord;
return CodeInputValidationOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CodeInputValidationOptionsRecordList = CodeInputValidationOptionsRecordList;

});
define("ShopperPortalEU.model$CustomInputValidationOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomInputValidationOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomInputValidationOptionsRecordList = (function (_super) {
__extends(CustomInputValidationOptionsRecordList, _super);
function CustomInputValidationOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomInputValidationOptionsRecordList.itemType = ShopperPortalEUModel.CustomInputValidationOptionsRecord;
return CustomInputValidationOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomInputValidationOptionsRecordList = CustomInputValidationOptionsRecordList;

});
define("ShopperPortalEU.model$CreateCardDataRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU.model", "ShopperPortalEU_Shopper_IS.model$CreateCardDataRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CreateCardDataRecord = (function (_super) {
__extends(CreateCardDataRecord, _super);
function CreateCardDataRecord(defaults) {
_super.apply(this, arguments);
}
CreateCardDataRecord.attributesToDeclare = function () {
return [
this.attr("CreateCardData", "createCardDataAttr", "CreateCardData", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Shopper_ISModel.CreateCardDataRec());
}, true, ShopperPortalEU_Shopper_ISModel.CreateCardDataRec)
].concat(_super.attributesToDeclare.call(this));
};
CreateCardDataRecord.fromStructure = function (str) {
return new CreateCardDataRecord(new CreateCardDataRecord.RecordClass({
createCardDataAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CreateCardDataRecord._isAnonymousRecord = true;
CreateCardDataRecord.UniqueId = "51a8e68a-2f02-433f-3762-3dcf86152272";
CreateCardDataRecord.init();
return CreateCardDataRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CreateCardDataRecord = CreateCardDataRecord;

});
define("ShopperPortalEU.model$CreateCardDataRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CreateCardDataRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CreateCardDataRecordList = (function (_super) {
__extends(CreateCardDataRecordList, _super);
function CreateCardDataRecordList(defaults) {
_super.apply(this, arguments);
}
CreateCardDataRecordList.itemType = ShopperPortalEUModel.CreateCardDataRecord;
return CreateCardDataRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CreateCardDataRecordList = CreateCardDataRecordList;

});
define("ShopperPortalEU.model$ProgressBarOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$ProgressBarOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var ProgressBarOptionsList = (function (_super) {
__extends(ProgressBarOptionsList, _super);
function ProgressBarOptionsList(defaults) {
_super.apply(this, arguments);
}
ProgressBarOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.ProgressBarOptionsRec;
return ProgressBarOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.ProgressBarOptionsList = ProgressBarOptionsList;

});
define("ShopperPortalEU.model$CustomDropdownCustomOptionList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomDropdownCustomOptionRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomDropdownCustomOptionList = (function (_super) {
__extends(CustomDropdownCustomOptionList, _super);
function CustomDropdownCustomOptionList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownCustomOptionList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomDropdownCustomOptionRec;
return CustomDropdownCustomOptionList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomDropdownCustomOptionList = CustomDropdownCustomOptionList;

});
define("ShopperPortalEU.model$Location_WrapperRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_API.model", "ShopperPortalEU.model", "ShopperPortalEU_API.model$Location_WrapperRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_API"], function (exports, OutSystems, ShopperPortalEU_APIModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var Location_WrapperRecord = (function (_super) {
__extends(Location_WrapperRecord, _super);
function Location_WrapperRecord(defaults) {
_super.apply(this, arguments);
}
Location_WrapperRecord.attributesToDeclare = function () {
return [
this.attr("Location_Wrapper", "location_WrapperAttr", "Location_Wrapper", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_APIModel.Location_WrapperRec());
}, true, ShopperPortalEU_APIModel.Location_WrapperRec)
].concat(_super.attributesToDeclare.call(this));
};
Location_WrapperRecord.fromStructure = function (str) {
return new Location_WrapperRecord(new Location_WrapperRecord.RecordClass({
location_WrapperAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
Location_WrapperRecord._isAnonymousRecord = true;
Location_WrapperRecord.UniqueId = "4f9c0484-af2e-602e-e3c9-c40fea05d8eb";
Location_WrapperRecord.init();
return Location_WrapperRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.Location_WrapperRecord = Location_WrapperRecord;

});
define("ShopperPortalEU.model$CustomButtonItemOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomButtonItemOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomButtonItemOptionsRecord = (function (_super) {
__extends(CustomButtonItemOptionsRecord, _super);
function CustomButtonItemOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomButtonItemOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomButtonItemOptions", "customButtonItemOptionsAttr", "CustomButtonItemOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomButtonItemOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomButtonItemOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomButtonItemOptionsRecord.fromStructure = function (str) {
return new CustomButtonItemOptionsRecord(new CustomButtonItemOptionsRecord.RecordClass({
customButtonItemOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomButtonItemOptionsRecord._isAnonymousRecord = true;
CustomButtonItemOptionsRecord.UniqueId = "4fd97a60-dbd6-0302-787d-21a705380777";
CustomButtonItemOptionsRecord.init();
return CustomButtonItemOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomButtonItemOptionsRecord = CustomButtonItemOptionsRecord;

});
define("ShopperPortalEU.model$FullHeightContentOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$FullHeightContentOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var FullHeightContentOptionsRecord = (function (_super) {
__extends(FullHeightContentOptionsRecord, _super);
function FullHeightContentOptionsRecord(defaults) {
_super.apply(this, arguments);
}
FullHeightContentOptionsRecord.attributesToDeclare = function () {
return [
this.attr("FullHeightContentOptions", "fullHeightContentOptionsAttr", "FullHeightContentOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.FullHeightContentOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.FullHeightContentOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
FullHeightContentOptionsRecord.fromStructure = function (str) {
return new FullHeightContentOptionsRecord(new FullHeightContentOptionsRecord.RecordClass({
fullHeightContentOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
FullHeightContentOptionsRecord._isAnonymousRecord = true;
FullHeightContentOptionsRecord.UniqueId = "4ff0cf98-6580-2aa1-828d-93be2e3ede93";
FullHeightContentOptionsRecord.init();
return FullHeightContentOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.FullHeightContentOptionsRecord = FullHeightContentOptionsRecord;

});
define("ShopperPortalEU.model$CustomRadioGroupOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomRadioGroupOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomRadioGroupOptionsRecord = (function (_super) {
__extends(CustomRadioGroupOptionsRecord, _super);
function CustomRadioGroupOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomRadioGroupOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomRadioGroupOptions", "customRadioGroupOptionsAttr", "CustomRadioGroupOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomRadioGroupOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomRadioGroupOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomRadioGroupOptionsRecord.fromStructure = function (str) {
return new CustomRadioGroupOptionsRecord(new CustomRadioGroupOptionsRecord.RecordClass({
customRadioGroupOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomRadioGroupOptionsRecord._isAnonymousRecord = true;
CustomRadioGroupOptionsRecord.UniqueId = "962b038f-5f74-231a-7f64-8a4b5c0bda40";
CustomRadioGroupOptionsRecord.init();
return CustomRadioGroupOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomRadioGroupOptionsRecord = CustomRadioGroupOptionsRecord;

});
define("ShopperPortalEU.model$CustomRadioGroupOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomRadioGroupOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomRadioGroupOptionsRecordList = (function (_super) {
__extends(CustomRadioGroupOptionsRecordList, _super);
function CustomRadioGroupOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomRadioGroupOptionsRecordList.itemType = ShopperPortalEUModel.CustomRadioGroupOptionsRecord;
return CustomRadioGroupOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomRadioGroupOptionsRecordList = CustomRadioGroupOptionsRecordList;

});
define("ShopperPortalEU.model$CustomMessageIconOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Theme.model$CustomMessageIconOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomMessageIconOptionsList = (function (_super) {
__extends(CustomMessageIconOptionsList, _super);
function CustomMessageIconOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomMessageIconOptionsList.itemType = ShopperPortalEU_UI_ThemeModel.CustomMessageIconOptionsRec;
return CustomMessageIconOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomMessageIconOptionsList = CustomMessageIconOptionsList;

});
define("ShopperPortalEU.model$Location_WrapperList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_API.model", "ShopperPortalEU.model", "ShopperPortalEU_API.model$Location_WrapperRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_API"], function (exports, OutSystems, ShopperPortalEU_APIModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var Location_WrapperList = (function (_super) {
__extends(Location_WrapperList, _super);
function Location_WrapperList(defaults) {
_super.apply(this, arguments);
}
Location_WrapperList.itemType = ShopperPortalEU_APIModel.Location_WrapperRec;
return Location_WrapperList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.Location_WrapperList = Location_WrapperList;

});
define("ShopperPortalEU.model$CustomButtonStateRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomButtonStateRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomButtonStateRecord = (function (_super) {
__extends(CustomButtonStateRecord, _super);
function CustomButtonStateRecord(defaults) {
_super.apply(this, arguments);
}
CustomButtonStateRecord.attributesToDeclare = function () {
return [
this.attr("CustomButtonState", "customButtonStateAttr", "CustomButtonState", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomButtonStateRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomButtonStateRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomButtonStateRecord.fromStructure = function (str) {
return new CustomButtonStateRecord(new CustomButtonStateRecord.RecordClass({
customButtonStateAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomButtonStateRecord._isAnonymousRecord = true;
CustomButtonStateRecord.UniqueId = "50d4a692-7ce0-b24a-6267-b730d4bd35f3";
CustomButtonStateRecord.init();
return CustomButtonStateRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomButtonStateRecord = CustomButtonStateRecord;

});
define("ShopperPortalEU.model$CountriesWithFlagsDropdownListRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CountriesWithFlagsDropdownListRec = (function (_super) {
__extends(CountriesWithFlagsDropdownListRec, _super);
function CountriesWithFlagsDropdownListRec(defaults) {
_super.apply(this, arguments);
}
CountriesWithFlagsDropdownListRec.attributesToDeclare = function () {
return [
this.attr("Flag", "flagAttr", "flag", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Value", "valueAttr", "value", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Name", "nameAttr", "name", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CountriesWithFlagsDropdownListRec.init();
return CountriesWithFlagsDropdownListRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CountriesWithFlagsDropdownListRec = CountriesWithFlagsDropdownListRec;

});
define("ShopperPortalEU.model$CountriesWithFlagsDropdownListRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CountriesWithFlagsDropdownListRec"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CountriesWithFlagsDropdownListRecord = (function (_super) {
__extends(CountriesWithFlagsDropdownListRecord, _super);
function CountriesWithFlagsDropdownListRecord(defaults) {
_super.apply(this, arguments);
}
CountriesWithFlagsDropdownListRecord.attributesToDeclare = function () {
return [
this.attr("CountriesWithFlagsDropdownList", "countriesWithFlagsDropdownListAttr", "CountriesWithFlagsDropdownList", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEUModel.CountriesWithFlagsDropdownListRec());
}, true, ShopperPortalEUModel.CountriesWithFlagsDropdownListRec)
].concat(_super.attributesToDeclare.call(this));
};
CountriesWithFlagsDropdownListRecord.fromStructure = function (str) {
return new CountriesWithFlagsDropdownListRecord(new CountriesWithFlagsDropdownListRecord.RecordClass({
countriesWithFlagsDropdownListAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CountriesWithFlagsDropdownListRecord._isAnonymousRecord = true;
CountriesWithFlagsDropdownListRecord.UniqueId = "5158e434-262f-e9e0-8e96-bab9b8fa682a";
CountriesWithFlagsDropdownListRecord.init();
return CountriesWithFlagsDropdownListRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CountriesWithFlagsDropdownListRecord = CountriesWithFlagsDropdownListRecord;

});
define("ShopperPortalEU.model$SPCountry_WrapperRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_API.model", "ShopperPortalEU.model", "ShopperPortalEU_API.model$SPCountry_WrapperRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_API"], function (exports, OutSystems, ShopperPortalEU_APIModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var SPCountry_WrapperRecord = (function (_super) {
__extends(SPCountry_WrapperRecord, _super);
function SPCountry_WrapperRecord(defaults) {
_super.apply(this, arguments);
}
SPCountry_WrapperRecord.attributesToDeclare = function () {
return [
this.attr("SPCountry_Wrapper", "sPCountry_WrapperAttr", "SPCountry_Wrapper", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_APIModel.SPCountry_WrapperRec());
}, true, ShopperPortalEU_APIModel.SPCountry_WrapperRec)
].concat(_super.attributesToDeclare.call(this));
};
SPCountry_WrapperRecord.fromStructure = function (str) {
return new SPCountry_WrapperRecord(new SPCountry_WrapperRecord.RecordClass({
sPCountry_WrapperAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
SPCountry_WrapperRecord._isAnonymousRecord = true;
SPCountry_WrapperRecord.UniqueId = "5253b707-7fe5-3ed4-cda3-c2a08cda9777";
SPCountry_WrapperRecord.init();
return SPCountry_WrapperRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.SPCountry_WrapperRecord = SPCountry_WrapperRecord;

});
define("ShopperPortalEU.model$FlexOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$FlexOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var FlexOptionsList = (function (_super) {
__extends(FlexOptionsList, _super);
function FlexOptionsList(defaults) {
_super.apply(this, arguments);
}
FlexOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec;
return FlexOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.FlexOptionsList = FlexOptionsList;

});
define("ShopperPortalEU.model$FullHeightContentAlignmentList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$FullHeightContentAlignmentRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var FullHeightContentAlignmentList = (function (_super) {
__extends(FullHeightContentAlignmentList, _super);
function FullHeightContentAlignmentList(defaults) {
_super.apply(this, arguments);
}
FullHeightContentAlignmentList.itemType = ShopperPortalEU_UI_ComponentsModel.FullHeightContentAlignmentRec;
return FullHeightContentAlignmentList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.FullHeightContentAlignmentList = FullHeightContentAlignmentList;

});
define("ShopperPortalEU.model$CustomTimelineOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomTimelineOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomTimelineOptionsRecord = (function (_super) {
__extends(CustomTimelineOptionsRecord, _super);
function CustomTimelineOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomTimelineOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomTimelineOptions", "customTimelineOptionsAttr", "CustomTimelineOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomTimelineOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomTimelineOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomTimelineOptionsRecord.fromStructure = function (str) {
return new CustomTimelineOptionsRecord(new CustomTimelineOptionsRecord.RecordClass({
customTimelineOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomTimelineOptionsRecord._isAnonymousRecord = true;
CustomTimelineOptionsRecord.UniqueId = "8a4edb1e-7a1a-b0bd-6229-0c91214c78eb";
CustomTimelineOptionsRecord.init();
return CustomTimelineOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomTimelineOptionsRecord = CustomTimelineOptionsRecord;

});
define("ShopperPortalEU.model$CustomTimelineOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomTimelineOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomTimelineOptionsRecordList = (function (_super) {
__extends(CustomTimelineOptionsRecordList, _super);
function CustomTimelineOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomTimelineOptionsRecordList.itemType = ShopperPortalEUModel.CustomTimelineOptionsRecord;
return CustomTimelineOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomTimelineOptionsRecordList = CustomTimelineOptionsRecordList;

});
define("ShopperPortalEU.model$LabelValueOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$LabelValueOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var LabelValueOptionsRecord = (function (_super) {
__extends(LabelValueOptionsRecord, _super);
function LabelValueOptionsRecord(defaults) {
_super.apply(this, arguments);
}
LabelValueOptionsRecord.attributesToDeclare = function () {
return [
this.attr("LabelValueOptions", "labelValueOptionsAttr", "LabelValueOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.LabelValueOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.LabelValueOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
LabelValueOptionsRecord.fromStructure = function (str) {
return new LabelValueOptionsRecord(new LabelValueOptionsRecord.RecordClass({
labelValueOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
LabelValueOptionsRecord._isAnonymousRecord = true;
LabelValueOptionsRecord.UniqueId = "53052aae-d28f-779c-0576-d2eb2ed88001";
LabelValueOptionsRecord.init();
return LabelValueOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.LabelValueOptionsRecord = LabelValueOptionsRecord;

});
define("ShopperPortalEU.model$CustomListItemClickableOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomListItemClickableOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomListItemClickableOptionsRecord = (function (_super) {
__extends(CustomListItemClickableOptionsRecord, _super);
function CustomListItemClickableOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomListItemClickableOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomListItemClickableOptions", "customListItemClickableOptionsAttr", "CustomListItemClickableOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomListItemClickableOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomListItemClickableOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomListItemClickableOptionsRecord.fromStructure = function (str) {
return new CustomListItemClickableOptionsRecord(new CustomListItemClickableOptionsRecord.RecordClass({
customListItemClickableOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomListItemClickableOptionsRecord._isAnonymousRecord = true;
CustomListItemClickableOptionsRecord.UniqueId = "d4e3c7f9-85af-94f7-94ec-fedeab4b4ed9";
CustomListItemClickableOptionsRecord.init();
return CustomListItemClickableOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomListItemClickableOptionsRecord = CustomListItemClickableOptionsRecord;

});
define("ShopperPortalEU.model$CustomListItemClickableOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomListItemClickableOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomListItemClickableOptionsRecordList = (function (_super) {
__extends(CustomListItemClickableOptionsRecordList, _super);
function CustomListItemClickableOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomListItemClickableOptionsRecordList.itemType = ShopperPortalEUModel.CustomListItemClickableOptionsRecord;
return CustomListItemClickableOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomListItemClickableOptionsRecordList = CustomListItemClickableOptionsRecordList;

});
define("ShopperPortalEU.model$GetShopperTravelDocumentsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU.model", "ShopperPortalEU_Shopper_IS.model$GetShopperTravelDocumentsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var GetShopperTravelDocumentsRecord = (function (_super) {
__extends(GetShopperTravelDocumentsRecord, _super);
function GetShopperTravelDocumentsRecord(defaults) {
_super.apply(this, arguments);
}
GetShopperTravelDocumentsRecord.attributesToDeclare = function () {
return [
this.attr("GetShopperTravelDocuments", "getShopperTravelDocumentsAttr", "GetShopperTravelDocuments", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Shopper_ISModel.GetShopperTravelDocumentsRec());
}, true, ShopperPortalEU_Shopper_ISModel.GetShopperTravelDocumentsRec)
].concat(_super.attributesToDeclare.call(this));
};
GetShopperTravelDocumentsRecord.fromStructure = function (str) {
return new GetShopperTravelDocumentsRecord(new GetShopperTravelDocumentsRecord.RecordClass({
getShopperTravelDocumentsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
GetShopperTravelDocumentsRecord._isAnonymousRecord = true;
GetShopperTravelDocumentsRecord.UniqueId = "647d66f0-d221-16fd-af5c-cef5e4e38375";
GetShopperTravelDocumentsRecord.init();
return GetShopperTravelDocumentsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.GetShopperTravelDocumentsRecord = GetShopperTravelDocumentsRecord;

});
define("ShopperPortalEU.model$GetShopperTravelDocumentsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$GetShopperTravelDocumentsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var GetShopperTravelDocumentsRecordList = (function (_super) {
__extends(GetShopperTravelDocumentsRecordList, _super);
function GetShopperTravelDocumentsRecordList(defaults) {
_super.apply(this, arguments);
}
GetShopperTravelDocumentsRecordList.itemType = ShopperPortalEUModel.GetShopperTravelDocumentsRecord;
return GetShopperTravelDocumentsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.GetShopperTravelDocumentsRecordList = GetShopperTravelDocumentsRecordList;

});
define("ShopperPortalEU.model$CustomDropdownCustomOptionRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomDropdownCustomOptionRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomDropdownCustomOptionRecordList = (function (_super) {
__extends(CustomDropdownCustomOptionRecordList, _super);
function CustomDropdownCustomOptionRecordList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownCustomOptionRecordList.itemType = ShopperPortalEUModel.CustomDropdownCustomOptionRecord;
return CustomDropdownCustomOptionRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomDropdownCustomOptionRecordList = CustomDropdownCustomOptionRecordList;

});
define("ShopperPortalEU.model$DatePickerValidationOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$DatePickerValidationOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var DatePickerValidationOptionsList = (function (_super) {
__extends(DatePickerValidationOptionsList, _super);
function DatePickerValidationOptionsList(defaults) {
_super.apply(this, arguments);
}
DatePickerValidationOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.DatePickerValidationOptionsRec;
return DatePickerValidationOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.DatePickerValidationOptionsList = DatePickerValidationOptionsList;

});
define("ShopperPortalEU.model$DatePickerValidationOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$DatePickerValidationOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var DatePickerValidationOptionsRecord = (function (_super) {
__extends(DatePickerValidationOptionsRecord, _super);
function DatePickerValidationOptionsRecord(defaults) {
_super.apply(this, arguments);
}
DatePickerValidationOptionsRecord.attributesToDeclare = function () {
return [
this.attr("DatePickerValidationOptions", "datePickerValidationOptionsAttr", "DatePickerValidationOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.DatePickerValidationOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.DatePickerValidationOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
DatePickerValidationOptionsRecord.fromStructure = function (str) {
return new DatePickerValidationOptionsRecord(new DatePickerValidationOptionsRecord.RecordClass({
datePickerValidationOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
DatePickerValidationOptionsRecord._isAnonymousRecord = true;
DatePickerValidationOptionsRecord.UniqueId = "fb32c8f6-5f1e-940d-2004-040fbcfe6154";
DatePickerValidationOptionsRecord.init();
return DatePickerValidationOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.DatePickerValidationOptionsRecord = DatePickerValidationOptionsRecord;

});
define("ShopperPortalEU.model$DatePickerValidationOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$DatePickerValidationOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var DatePickerValidationOptionsRecordList = (function (_super) {
__extends(DatePickerValidationOptionsRecordList, _super);
function DatePickerValidationOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
DatePickerValidationOptionsRecordList.itemType = ShopperPortalEUModel.DatePickerValidationOptionsRecord;
return DatePickerValidationOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.DatePickerValidationOptionsRecordList = DatePickerValidationOptionsRecordList;

});
define("ShopperPortalEU.model$CustomLinkItemOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomLinkItemOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomLinkItemOptionsList = (function (_super) {
__extends(CustomLinkItemOptionsList, _super);
function CustomLinkItemOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomLinkItemOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomLinkItemOptionsRec;
return CustomLinkItemOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomLinkItemOptionsList = CustomLinkItemOptionsList;

});
define("ShopperPortalEU.model$HeaderActionItemOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Theme.model$HeaderActionItemOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var HeaderActionItemOptionsList = (function (_super) {
__extends(HeaderActionItemOptionsList, _super);
function HeaderActionItemOptionsList(defaults) {
_super.apply(this, arguments);
}
HeaderActionItemOptionsList.itemType = ShopperPortalEU_UI_ThemeModel.HeaderActionItemOptionsRec;
return HeaderActionItemOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.HeaderActionItemOptionsList = HeaderActionItemOptionsList;

});
define("ShopperPortalEU.model$FormDetails_WrapperRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU.model", "ShopperPortalEU_Forms_IS.model$FormDetails_WrapperRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Forms_IS"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var FormDetails_WrapperRecord = (function (_super) {
__extends(FormDetails_WrapperRecord, _super);
function FormDetails_WrapperRecord(defaults) {
_super.apply(this, arguments);
}
FormDetails_WrapperRecord.attributesToDeclare = function () {
return [
this.attr("FormDetails_Wrapper", "formDetails_WrapperAttr", "FormDetails_Wrapper", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Forms_ISModel.FormDetails_WrapperRec());
}, true, ShopperPortalEU_Forms_ISModel.FormDetails_WrapperRec)
].concat(_super.attributesToDeclare.call(this));
};
FormDetails_WrapperRecord.fromStructure = function (str) {
return new FormDetails_WrapperRecord(new FormDetails_WrapperRecord.RecordClass({
formDetails_WrapperAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
FormDetails_WrapperRecord._isAnonymousRecord = true;
FormDetails_WrapperRecord.UniqueId = "629612d4-b284-bccc-5aeb-98c37fa5fdfd";
FormDetails_WrapperRecord.init();
return FormDetails_WrapperRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.FormDetails_WrapperRecord = FormDetails_WrapperRecord;

});
define("ShopperPortalEU.model$FormDetails_WrapperRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$FormDetails_WrapperRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var FormDetails_WrapperRecordList = (function (_super) {
__extends(FormDetails_WrapperRecordList, _super);
function FormDetails_WrapperRecordList(defaults) {
_super.apply(this, arguments);
}
FormDetails_WrapperRecordList.itemType = ShopperPortalEUModel.FormDetails_WrapperRecord;
return FormDetails_WrapperRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.FormDetails_WrapperRecordList = FormDetails_WrapperRecordList;

});
define("ShopperPortalEU.model$ApcuesIdentifyList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$ApcuesIdentifyRec"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var ApcuesIdentifyList = (function (_super) {
__extends(ApcuesIdentifyList, _super);
function ApcuesIdentifyList(defaults) {
_super.apply(this, arguments);
}
ApcuesIdentifyList.itemType = ShopperPortalEUModel.ApcuesIdentifyRec;
return ApcuesIdentifyList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.ApcuesIdentifyList = ApcuesIdentifyList;

});
define("ShopperPortalEU.model$PhoneNumberInputChangeOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$PhoneNumberInputChangeOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var PhoneNumberInputChangeOptionsRecord = (function (_super) {
__extends(PhoneNumberInputChangeOptionsRecord, _super);
function PhoneNumberInputChangeOptionsRecord(defaults) {
_super.apply(this, arguments);
}
PhoneNumberInputChangeOptionsRecord.attributesToDeclare = function () {
return [
this.attr("PhoneNumberInputChangeOptions", "phoneNumberInputChangeOptionsAttr", "PhoneNumberInputChangeOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputChangeOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputChangeOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
PhoneNumberInputChangeOptionsRecord.fromStructure = function (str) {
return new PhoneNumberInputChangeOptionsRecord(new PhoneNumberInputChangeOptionsRecord.RecordClass({
phoneNumberInputChangeOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
PhoneNumberInputChangeOptionsRecord._isAnonymousRecord = true;
PhoneNumberInputChangeOptionsRecord.UniqueId = "c7a7fece-d8b2-7099-12d6-345f1560791f";
PhoneNumberInputChangeOptionsRecord.init();
return PhoneNumberInputChangeOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.PhoneNumberInputChangeOptionsRecord = PhoneNumberInputChangeOptionsRecord;

});
define("ShopperPortalEU.model$PhoneNumberInputChangeOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$PhoneNumberInputChangeOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var PhoneNumberInputChangeOptionsRecordList = (function (_super) {
__extends(PhoneNumberInputChangeOptionsRecordList, _super);
function PhoneNumberInputChangeOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
PhoneNumberInputChangeOptionsRecordList.itemType = ShopperPortalEUModel.PhoneNumberInputChangeOptionsRecord;
return PhoneNumberInputChangeOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.PhoneNumberInputChangeOptionsRecordList = PhoneNumberInputChangeOptionsRecordList;

});
define("ShopperPortalEU.model$ScanBarcodeDataList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$ScanBarcodeDataRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var ScanBarcodeDataList = (function (_super) {
__extends(ScanBarcodeDataList, _super);
function ScanBarcodeDataList(defaults) {
_super.apply(this, arguments);
}
ScanBarcodeDataList.itemType = ShopperPortalEU_UI_ComponentsModel.ScanBarcodeDataRec;
return ScanBarcodeDataList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.ScanBarcodeDataList = ScanBarcodeDataList;

});
define("ShopperPortalEU.model$CustomButtonStateRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomButtonStateRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomButtonStateRecordList = (function (_super) {
__extends(CustomButtonStateRecordList, _super);
function CustomButtonStateRecordList(defaults) {
_super.apply(this, arguments);
}
CustomButtonStateRecordList.itemType = ShopperPortalEUModel.CustomButtonStateRecord;
return CustomButtonStateRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomButtonStateRecordList = CustomButtonStateRecordList;

});
define("ShopperPortalEU.model$CountriesWithFlagsDropdownListList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CountriesWithFlagsDropdownListRec"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CountriesWithFlagsDropdownListList = (function (_super) {
__extends(CountriesWithFlagsDropdownListList, _super);
function CountriesWithFlagsDropdownListList(defaults) {
_super.apply(this, arguments);
}
CountriesWithFlagsDropdownListList.itemType = ShopperPortalEUModel.CountriesWithFlagsDropdownListRec;
return CountriesWithFlagsDropdownListList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CountriesWithFlagsDropdownListList = CountriesWithFlagsDropdownListList;

});
define("ShopperPortalEU.model$CodeInputOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CodeInputOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CodeInputOptionsRecord = (function (_super) {
__extends(CodeInputOptionsRecord, _super);
function CodeInputOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CodeInputOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CodeInputOptions", "codeInputOptionsAttr", "CodeInputOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CodeInputOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CodeInputOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CodeInputOptionsRecord.fromStructure = function (str) {
return new CodeInputOptionsRecord(new CodeInputOptionsRecord.RecordClass({
codeInputOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CodeInputOptionsRecord._isAnonymousRecord = true;
CodeInputOptionsRecord.UniqueId = "6c3a2e79-7911-d4b0-15a7-0e7c51f36896";
CodeInputOptionsRecord.init();
return CodeInputOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CodeInputOptionsRecord = CodeInputOptionsRecord;

});
define("ShopperPortalEU.model$CodeInputOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CodeInputOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CodeInputOptionsRecordList = (function (_super) {
__extends(CodeInputOptionsRecordList, _super);
function CodeInputOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CodeInputOptionsRecordList.itemType = ShopperPortalEUModel.CodeInputOptionsRecord;
return CodeInputOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CodeInputOptionsRecordList = CodeInputOptionsRecordList;

});
define("ShopperPortalEU.model$UIConfigurationRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU.model", "ShopperPortalEU_Forms_IS.model$UIConfigurationRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Forms_IS"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var UIConfigurationRecord = (function (_super) {
__extends(UIConfigurationRecord, _super);
function UIConfigurationRecord(defaults) {
_super.apply(this, arguments);
}
UIConfigurationRecord.attributesToDeclare = function () {
return [
this.attr("UIConfiguration", "uIConfigurationAttr", "UIConfiguration", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Forms_ISModel.UIConfigurationRec());
}, true, ShopperPortalEU_Forms_ISModel.UIConfigurationRec)
].concat(_super.attributesToDeclare.call(this));
};
UIConfigurationRecord.fromStructure = function (str) {
return new UIConfigurationRecord(new UIConfigurationRecord.RecordClass({
uIConfigurationAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
UIConfigurationRecord._isAnonymousRecord = true;
UIConfigurationRecord.UniqueId = "5a0d29a6-e534-3bb6-6dde-bbbccf1b042c";
UIConfigurationRecord.init();
return UIConfigurationRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.UIConfigurationRecord = UIConfigurationRecord;

});
define("ShopperPortalEU.model$CompleteDetailsRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CompleteDetails_PersonalDetailsRec", "ShopperPortalEU.model$CompleteDetails_AddressRec", "ShopperPortalEU.model$CompleteDetails_ContactRec"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CompleteDetailsRec = (function (_super) {
__extends(CompleteDetailsRec, _super);
function CompleteDetailsRec(defaults) {
_super.apply(this, arguments);
}
CompleteDetailsRec.attributesToDeclare = function () {
return [
this.attr("IsDataFetched", "isDataFetchedAttr", "isDataFetched", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("IsSuccess", "isSuccessAttr", "isSuccess", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("PersonalDetails", "personalDetailsAttr", "personalDetails", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEUModel.CompleteDetails_PersonalDetailsRec());
}, true, ShopperPortalEUModel.CompleteDetails_PersonalDetailsRec), 
this.attr("Address", "addressAttr", "address", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEUModel.CompleteDetails_AddressRec());
}, true, ShopperPortalEUModel.CompleteDetails_AddressRec), 
this.attr("Contact", "contactAttr", "contact", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEUModel.CompleteDetails_ContactRec());
}, true, ShopperPortalEUModel.CompleteDetails_ContactRec), 
this.attr("IsSaving", "isSavingAttr", "isSaving", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CompleteDetailsRec.init();
return CompleteDetailsRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CompleteDetailsRec = CompleteDetailsRec;

});
define("ShopperPortalEU.model$CreateCardList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU.model", "ShopperPortalEU_Shopper_IS.model$CreateCardRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CreateCardList = (function (_super) {
__extends(CreateCardList, _super);
function CreateCardList(defaults) {
_super.apply(this, arguments);
}
CreateCardList.itemType = ShopperPortalEU_Shopper_ISModel.CreateCardRec;
return CreateCardList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CreateCardList = CreateCardList;

});
define("ShopperPortalEU.model$RefundSummaryList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$RefundSummaryRec"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var RefundSummaryList = (function (_super) {
__extends(RefundSummaryList, _super);
function RefundSummaryList(defaults) {
_super.apply(this, arguments);
}
RefundSummaryList.itemType = ShopperPortalEUModel.RefundSummaryRec;
return RefundSummaryList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.RefundSummaryList = RefundSummaryList;

});
define("ShopperPortalEU.model$CustomLinkItemOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomLinkItemOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomLinkItemOptionsRecordList = (function (_super) {
__extends(CustomLinkItemOptionsRecordList, _super);
function CustomLinkItemOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomLinkItemOptionsRecordList.itemType = ShopperPortalEUModel.CustomLinkItemOptionsRecord;
return CustomLinkItemOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomLinkItemOptionsRecordList = CustomLinkItemOptionsRecordList;

});
define("ShopperPortalEU.model$CustomIconFamilyList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomIconFamilyRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomIconFamilyList = (function (_super) {
__extends(CustomIconFamilyList, _super);
function CustomIconFamilyList(defaults) {
_super.apply(this, arguments);
}
CustomIconFamilyList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomIconFamilyRec;
return CustomIconFamilyList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomIconFamilyList = CustomIconFamilyList;

});
define("ShopperPortalEU.model$PassportRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var PassportRec = (function (_super) {
__extends(PassportRec, _super);
function PassportRec(defaults) {
_super.apply(this, arguments);
}
PassportRec.attributesToDeclare = function () {
return [
this.attr("Number", "numberAttr", "number", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Country", "countryAttr", "country", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("CountryISOCode", "countryISOCodeAttr", "countryISOCode", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("CountryNumericIsoCode", "countryNumericIsoCodeAttr", "countryNumericIsoCode", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("ExpirationDate", "expirationDateAttr", "expirationDate", false, false, OS.DataTypes.DataTypes.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PassportRec.init();
return PassportRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.PassportRec = PassportRec;

});
define("ShopperPortalEU.model$PassportRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$PassportRec"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var PassportRecord = (function (_super) {
__extends(PassportRecord, _super);
function PassportRecord(defaults) {
_super.apply(this, arguments);
}
PassportRecord.attributesToDeclare = function () {
return [
this.attr("Passport", "passportAttr", "Passport", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEUModel.PassportRec());
}, true, ShopperPortalEUModel.PassportRec)
].concat(_super.attributesToDeclare.call(this));
};
PassportRecord.fromStructure = function (str) {
return new PassportRecord(new PassportRecord.RecordClass({
passportAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
PassportRecord._isAnonymousRecord = true;
PassportRecord.UniqueId = "d014f791-00b2-6250-1268-9b6f0350dd2a";
PassportRecord.init();
return PassportRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.PassportRecord = PassportRecord;

});
define("ShopperPortalEU.model$PassportRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$PassportRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var PassportRecordList = (function (_super) {
__extends(PassportRecordList, _super);
function PassportRecordList(defaults) {
_super.apply(this, arguments);
}
PassportRecordList.itemType = ShopperPortalEUModel.PassportRecord;
return PassportRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.PassportRecordList = PassportRecordList;

});
define("ShopperPortalEU.model$ApplicationHeaderRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$ApplicationHeaderRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var ApplicationHeaderRecordList = (function (_super) {
__extends(ApplicationHeaderRecordList, _super);
function ApplicationHeaderRecordList(defaults) {
_super.apply(this, arguments);
}
ApplicationHeaderRecordList.itemType = ShopperPortalEUModel.ApplicationHeaderRecord;
return ApplicationHeaderRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.ApplicationHeaderRecordList = ApplicationHeaderRecordList;

});
define("ShopperPortalEU.model$CustomRadioButtonOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomRadioButtonOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomRadioButtonOptionsRecord = (function (_super) {
__extends(CustomRadioButtonOptionsRecord, _super);
function CustomRadioButtonOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomRadioButtonOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomRadioButtonOptions", "customRadioButtonOptionsAttr", "CustomRadioButtonOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomRadioButtonOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomRadioButtonOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomRadioButtonOptionsRecord.fromStructure = function (str) {
return new CustomRadioButtonOptionsRecord(new CustomRadioButtonOptionsRecord.RecordClass({
customRadioButtonOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomRadioButtonOptionsRecord._isAnonymousRecord = true;
CustomRadioButtonOptionsRecord.UniqueId = "9e2a971c-60e5-6bf3-ba1a-f412a3275e31";
CustomRadioButtonOptionsRecord.init();
return CustomRadioButtonOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomRadioButtonOptionsRecord = CustomRadioButtonOptionsRecord;

});
define("ShopperPortalEU.model$CustomRadioButtonOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomRadioButtonOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomRadioButtonOptionsRecordList = (function (_super) {
__extends(CustomRadioButtonOptionsRecordList, _super);
function CustomRadioButtonOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomRadioButtonOptionsRecordList.itemType = ShopperPortalEUModel.CustomRadioButtonOptionsRecord;
return CustomRadioButtonOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomRadioButtonOptionsRecordList = CustomRadioButtonOptionsRecordList;

});
define("ShopperPortalEU.model$CustomMessageTypeRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Theme.model$CustomMessageTypeRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomMessageTypeRecord = (function (_super) {
__extends(CustomMessageTypeRecord, _super);
function CustomMessageTypeRecord(defaults) {
_super.apply(this, arguments);
}
CustomMessageTypeRecord.attributesToDeclare = function () {
return [
this.attr("CustomMessageType", "customMessageTypeAttr", "CustomMessageType", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ThemeModel.CustomMessageTypeRec());
}, true, ShopperPortalEU_UI_ThemeModel.CustomMessageTypeRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomMessageTypeRecord.fromStructure = function (str) {
return new CustomMessageTypeRecord(new CustomMessageTypeRecord.RecordClass({
customMessageTypeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomMessageTypeRecord._isAnonymousRecord = true;
CustomMessageTypeRecord.UniqueId = "7e1373d8-7d9c-3134-5433-e8112f618f5c";
CustomMessageTypeRecord.init();
return CustomMessageTypeRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomMessageTypeRecord = CustomMessageTypeRecord;

});
define("ShopperPortalEU.model$CustomMessageTypeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomMessageTypeRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomMessageTypeRecordList = (function (_super) {
__extends(CustomMessageTypeRecordList, _super);
function CustomMessageTypeRecordList(defaults) {
_super.apply(this, arguments);
}
CustomMessageTypeRecordList.itemType = ShopperPortalEUModel.CustomMessageTypeRecord;
return CustomMessageTypeRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomMessageTypeRecordList = CustomMessageTypeRecordList;

});
define("ShopperPortalEU.model$LayoutDetailOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Theme.model$LayoutDetailOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var LayoutDetailOptionsRecord = (function (_super) {
__extends(LayoutDetailOptionsRecord, _super);
function LayoutDetailOptionsRecord(defaults) {
_super.apply(this, arguments);
}
LayoutDetailOptionsRecord.attributesToDeclare = function () {
return [
this.attr("LayoutDetailOptions", "layoutDetailOptionsAttr", "LayoutDetailOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ThemeModel.LayoutDetailOptionsRec());
}, true, ShopperPortalEU_UI_ThemeModel.LayoutDetailOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
LayoutDetailOptionsRecord.fromStructure = function (str) {
return new LayoutDetailOptionsRecord(new LayoutDetailOptionsRecord.RecordClass({
layoutDetailOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
LayoutDetailOptionsRecord._isAnonymousRecord = true;
LayoutDetailOptionsRecord.UniqueId = "5d61304a-936a-5e78-0235-643de86409f6";
LayoutDetailOptionsRecord.init();
return LayoutDetailOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.LayoutDetailOptionsRecord = LayoutDetailOptionsRecord;

});
define("ShopperPortalEU.model$PaddingSideOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$PaddingSideOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var PaddingSideOptionsRecordList = (function (_super) {
__extends(PaddingSideOptionsRecordList, _super);
function PaddingSideOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
PaddingSideOptionsRecordList.itemType = ShopperPortalEUModel.PaddingSideOptionsRecord;
return PaddingSideOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.PaddingSideOptionsRecordList = PaddingSideOptionsRecordList;

});
define("ShopperPortalEU.model$BarcodeOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$BarcodeOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var BarcodeOptionsRecordList = (function (_super) {
__extends(BarcodeOptionsRecordList, _super);
function BarcodeOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
BarcodeOptionsRecordList.itemType = ShopperPortalEUModel.BarcodeOptionsRecord;
return BarcodeOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.BarcodeOptionsRecordList = BarcodeOptionsRecordList;

});
define("ShopperPortalEU.model$MenuElementOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Theme.model$MenuElementOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var MenuElementOptionsRecord = (function (_super) {
__extends(MenuElementOptionsRecord, _super);
function MenuElementOptionsRecord(defaults) {
_super.apply(this, arguments);
}
MenuElementOptionsRecord.attributesToDeclare = function () {
return [
this.attr("MenuElementOptions", "menuElementOptionsAttr", "MenuElementOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ThemeModel.MenuElementOptionsRec());
}, true, ShopperPortalEU_UI_ThemeModel.MenuElementOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
MenuElementOptionsRecord.fromStructure = function (str) {
return new MenuElementOptionsRecord(new MenuElementOptionsRecord.RecordClass({
menuElementOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
MenuElementOptionsRecord._isAnonymousRecord = true;
MenuElementOptionsRecord.UniqueId = "fb7f0b6f-5f77-3c07-a590-0e43896abebf";
MenuElementOptionsRecord.init();
return MenuElementOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.MenuElementOptionsRecord = MenuElementOptionsRecord;

});
define("ShopperPortalEU.model$MenuElementOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$MenuElementOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var MenuElementOptionsRecordList = (function (_super) {
__extends(MenuElementOptionsRecordList, _super);
function MenuElementOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
MenuElementOptionsRecordList.itemType = ShopperPortalEUModel.MenuElementOptionsRecord;
return MenuElementOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.MenuElementOptionsRecordList = MenuElementOptionsRecordList;

});
define("ShopperPortalEU.model$BooleanRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var BooleanRecord = (function (_super) {
__extends(BooleanRecord, _super);
function BooleanRecord(defaults) {
_super.apply(this, arguments);
}
BooleanRecord.attributesToDeclare = function () {
return [
this.attr("AddErrorCallback", "addErrorCallbackAttr", "AddErrorCallback", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
BooleanRecord.fromStructure = function (str) {
return new BooleanRecord(new BooleanRecord.RecordClass({
addErrorCallbackAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
BooleanRecord._isAnonymousRecord = true;
BooleanRecord.UniqueId = "f05077a3-b416-6123-b24e-476f71932642";
BooleanRecord.init();
return BooleanRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.BooleanRecord = BooleanRecord;

});
define("ShopperPortalEU.model$BooleanRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$BooleanRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var BooleanRecordList = (function (_super) {
__extends(BooleanRecordList, _super);
function BooleanRecordList(defaults) {
_super.apply(this, arguments);
}
BooleanRecordList.itemType = ShopperPortalEUModel.BooleanRecord;
return BooleanRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.BooleanRecordList = BooleanRecordList;

});
define("ShopperPortalEU.model$LoginOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Theme.model$LoginOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var LoginOptionsList = (function (_super) {
__extends(LoginOptionsList, _super);
function LoginOptionsList(defaults) {
_super.apply(this, arguments);
}
LoginOptionsList.itemType = ShopperPortalEU_UI_ThemeModel.LoginOptionsRec;
return LoginOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.LoginOptionsList = LoginOptionsList;

});
define("ShopperPortalEU.model$FlexDirectionList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$FlexDirectionRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var FlexDirectionList = (function (_super) {
__extends(FlexDirectionList, _super);
function FlexDirectionList(defaults) {
_super.apply(this, arguments);
}
FlexDirectionList.itemType = ShopperPortalEU_UI_ComponentsModel.FlexDirectionRec;
return FlexDirectionList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.FlexDirectionList = FlexDirectionList;

});
define("ShopperPortalEU.model$DatatransCardGetCardInfoOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$DatatransCardGetCardInfoOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var DatatransCardGetCardInfoOptionsRecord = (function (_super) {
__extends(DatatransCardGetCardInfoOptionsRecord, _super);
function DatatransCardGetCardInfoOptionsRecord(defaults) {
_super.apply(this, arguments);
}
DatatransCardGetCardInfoOptionsRecord.attributesToDeclare = function () {
return [
this.attr("DatatransCardGetCardInfoOptions", "datatransCardGetCardInfoOptionsAttr", "DatatransCardGetCardInfoOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.DatatransCardGetCardInfoOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.DatatransCardGetCardInfoOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
DatatransCardGetCardInfoOptionsRecord.fromStructure = function (str) {
return new DatatransCardGetCardInfoOptionsRecord(new DatatransCardGetCardInfoOptionsRecord.RecordClass({
datatransCardGetCardInfoOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
DatatransCardGetCardInfoOptionsRecord._isAnonymousRecord = true;
DatatransCardGetCardInfoOptionsRecord.UniqueId = "cae69dc8-47e8-a684-b8e3-b5841b3d6209";
DatatransCardGetCardInfoOptionsRecord.init();
return DatatransCardGetCardInfoOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.DatatransCardGetCardInfoOptionsRecord = DatatransCardGetCardInfoOptionsRecord;

});
define("ShopperPortalEU.model$DatatransCardGetCardInfoOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$DatatransCardGetCardInfoOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var DatatransCardGetCardInfoOptionsRecordList = (function (_super) {
__extends(DatatransCardGetCardInfoOptionsRecordList, _super);
function DatatransCardGetCardInfoOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
DatatransCardGetCardInfoOptionsRecordList.itemType = ShopperPortalEUModel.DatatransCardGetCardInfoOptionsRecord;
return DatatransCardGetCardInfoOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.DatatransCardGetCardInfoOptionsRecordList = DatatransCardGetCardInfoOptionsRecordList;

});
define("ShopperPortalEU.model$FlexJustifyRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$FlexJustifyRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var FlexJustifyRecord = (function (_super) {
__extends(FlexJustifyRecord, _super);
function FlexJustifyRecord(defaults) {
_super.apply(this, arguments);
}
FlexJustifyRecord.attributesToDeclare = function () {
return [
this.attr("FlexJustify", "flexJustifyAttr", "FlexJustify", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.FlexJustifyRec());
}, true, ShopperPortalEU_UI_ComponentsModel.FlexJustifyRec)
].concat(_super.attributesToDeclare.call(this));
};
FlexJustifyRecord.fromStructure = function (str) {
return new FlexJustifyRecord(new FlexJustifyRecord.RecordClass({
flexJustifyAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
FlexJustifyRecord._isAnonymousRecord = true;
FlexJustifyRecord.UniqueId = "618b6741-e963-0839-9844-1cc2ba59f3ca";
FlexJustifyRecord.init();
return FlexJustifyRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.FlexJustifyRecord = FlexJustifyRecord;

});
define("ShopperPortalEU.model$PhoneNumberInputSearchOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$PhoneNumberInputSearchOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var PhoneNumberInputSearchOptionsList = (function (_super) {
__extends(PhoneNumberInputSearchOptionsList, _super);
function PhoneNumberInputSearchOptionsList(defaults) {
_super.apply(this, arguments);
}
PhoneNumberInputSearchOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputSearchOptionsRec;
return PhoneNumberInputSearchOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.PhoneNumberInputSearchOptionsList = PhoneNumberInputSearchOptionsList;

});
define("ShopperPortalEU.model$CustomPopupLayoutHeaderImageOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomPopupLayoutHeaderImageOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomPopupLayoutHeaderImageOptionsRecord = (function (_super) {
__extends(CustomPopupLayoutHeaderImageOptionsRecord, _super);
function CustomPopupLayoutHeaderImageOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomPopupLayoutHeaderImageOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomPopupLayoutHeaderImageOptions", "customPopupLayoutHeaderImageOptionsAttr", "CustomPopupLayoutHeaderImageOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomPopupLayoutHeaderImageOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomPopupLayoutHeaderImageOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomPopupLayoutHeaderImageOptionsRecord.fromStructure = function (str) {
return new CustomPopupLayoutHeaderImageOptionsRecord(new CustomPopupLayoutHeaderImageOptionsRecord.RecordClass({
customPopupLayoutHeaderImageOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomPopupLayoutHeaderImageOptionsRecord._isAnonymousRecord = true;
CustomPopupLayoutHeaderImageOptionsRecord.UniqueId = "f1b1471e-aa02-29ab-38f7-7e440e879aff";
CustomPopupLayoutHeaderImageOptionsRecord.init();
return CustomPopupLayoutHeaderImageOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomPopupLayoutHeaderImageOptionsRecord = CustomPopupLayoutHeaderImageOptionsRecord;

});
define("ShopperPortalEU.model$CustomPopupLayoutHeaderImageOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomPopupLayoutHeaderImageOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomPopupLayoutHeaderImageOptionsRecordList = (function (_super) {
__extends(CustomPopupLayoutHeaderImageOptionsRecordList, _super);
function CustomPopupLayoutHeaderImageOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomPopupLayoutHeaderImageOptionsRecordList.itemType = ShopperPortalEUModel.CustomPopupLayoutHeaderImageOptionsRecord;
return CustomPopupLayoutHeaderImageOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomPopupLayoutHeaderImageOptionsRecordList = CustomPopupLayoutHeaderImageOptionsRecordList;

});
define("ShopperPortalEU.model$RefundDetailsPaymentDetails_UIList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU.model", "ShopperPortalEU_Forms_IS.model$RefundDetailsPaymentDetails_UIRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Forms_IS"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var RefundDetailsPaymentDetails_UIList = (function (_super) {
__extends(RefundDetailsPaymentDetails_UIList, _super);
function RefundDetailsPaymentDetails_UIList(defaults) {
_super.apply(this, arguments);
}
RefundDetailsPaymentDetails_UIList.itemType = ShopperPortalEU_Forms_ISModel.RefundDetailsPaymentDetails_UIRec;
return RefundDetailsPaymentDetails_UIList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.RefundDetailsPaymentDetails_UIList = RefundDetailsPaymentDetails_UIList;

});
define("ShopperPortalEU.model$CardBackgroundTypeList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CardBackgroundTypeRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CardBackgroundTypeList = (function (_super) {
__extends(CardBackgroundTypeList, _super);
function CardBackgroundTypeList(defaults) {
_super.apply(this, arguments);
}
CardBackgroundTypeList.itemType = ShopperPortalEU_UI_ComponentsModel.CardBackgroundTypeRec;
return CardBackgroundTypeList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CardBackgroundTypeList = CardBackgroundTypeList;

});
define("ShopperPortalEU.model$CustomBottomBarOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomBottomBarOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomBottomBarOptionsRecord = (function (_super) {
__extends(CustomBottomBarOptionsRecord, _super);
function CustomBottomBarOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomBottomBarOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomBottomBarOptions", "customBottomBarOptionsAttr", "CustomBottomBarOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomBottomBarOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomBottomBarOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomBottomBarOptionsRecord.fromStructure = function (str) {
return new CustomBottomBarOptionsRecord(new CustomBottomBarOptionsRecord.RecordClass({
customBottomBarOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomBottomBarOptionsRecord._isAnonymousRecord = true;
CustomBottomBarOptionsRecord.UniqueId = "db20f11b-7f12-4650-0d55-53aa294e1829";
CustomBottomBarOptionsRecord.init();
return CustomBottomBarOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomBottomBarOptionsRecord = CustomBottomBarOptionsRecord;

});
define("ShopperPortalEU.model$CustomBottomBarOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomBottomBarOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomBottomBarOptionsRecordList = (function (_super) {
__extends(CustomBottomBarOptionsRecordList, _super);
function CustomBottomBarOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomBottomBarOptionsRecordList.itemType = ShopperPortalEUModel.CustomBottomBarOptionsRecord;
return CustomBottomBarOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomBottomBarOptionsRecordList = CustomBottomBarOptionsRecordList;

});
define("ShopperPortalEU.model$CustomLinkTypeList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomLinkTypeRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomLinkTypeList = (function (_super) {
__extends(CustomLinkTypeList, _super);
function CustomLinkTypeList(defaults) {
_super.apply(this, arguments);
}
CustomLinkTypeList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomLinkTypeRec;
return CustomLinkTypeList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomLinkTypeList = CustomLinkTypeList;

});
define("ShopperPortalEU.model$DatatransTokenFallbackList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU.model", "ShopperPortalEU_Shopper_IS.model$DatatransTokenFallbackRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var DatatransTokenFallbackList = (function (_super) {
__extends(DatatransTokenFallbackList, _super);
function DatatransTokenFallbackList(defaults) {
_super.apply(this, arguments);
}
DatatransTokenFallbackList.itemType = ShopperPortalEU_Shopper_ISModel.DatatransTokenFallbackRec;
return DatatransTokenFallbackList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.DatatransTokenFallbackList = DatatransTokenFallbackList;

});
define("ShopperPortalEU.model$HeaderActionItemOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Theme.model$HeaderActionItemOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var HeaderActionItemOptionsRecord = (function (_super) {
__extends(HeaderActionItemOptionsRecord, _super);
function HeaderActionItemOptionsRecord(defaults) {
_super.apply(this, arguments);
}
HeaderActionItemOptionsRecord.attributesToDeclare = function () {
return [
this.attr("HeaderActionItemOptions", "headerActionItemOptionsAttr", "HeaderActionItemOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ThemeModel.HeaderActionItemOptionsRec());
}, true, ShopperPortalEU_UI_ThemeModel.HeaderActionItemOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
HeaderActionItemOptionsRecord.fromStructure = function (str) {
return new HeaderActionItemOptionsRecord(new HeaderActionItemOptionsRecord.RecordClass({
headerActionItemOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
HeaderActionItemOptionsRecord._isAnonymousRecord = true;
HeaderActionItemOptionsRecord.UniqueId = "641743b8-afe0-cd38-e466-02710a9bc102";
HeaderActionItemOptionsRecord.init();
return HeaderActionItemOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.HeaderActionItemOptionsRecord = HeaderActionItemOptionsRecord;

});
define("ShopperPortalEU.model$DeleteCardList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU.model", "ShopperPortalEU_Shopper_IS.model$DeleteCardRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var DeleteCardList = (function (_super) {
__extends(DeleteCardList, _super);
function DeleteCardList(defaults) {
_super.apply(this, arguments);
}
DeleteCardList.itemType = ShopperPortalEU_Shopper_ISModel.DeleteCardRec;
return DeleteCardList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.DeleteCardList = DeleteCardList;

});
define("ShopperPortalEU.model$ScanPassportRec", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var ScanPassportRec = (function (_super) {
__extends(ScanPassportRec, _super);
function ScanPassportRec(defaults) {
_super.apply(this, arguments);
}
ScanPassportRec.attributesToDeclare = function () {
return [
this.attr("DateOfBirth", "dateOfBirthAttr", "dateOfBirth", false, false, OS.DataTypes.DataTypes.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("DateOfExpiry", "dateOfExpiryAttr", "dateOfExpiry", false, false, OS.DataTypes.DataTypes.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("DocumentNumber", "documentNumberAttr", "documentNumber", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("GivenNames", "givenNamesAttr", "givenNames", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Surname", "surnameAttr", "surname", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("IssuingCountryCode", "issuingCountryCodeAttr", "issuingCountryCode", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("NationalityCountryCode", "nationalityCountryCodeAttr", "nationalityCountryCode", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("PersonalNumber", "personalNumberAttr", "personalNumber", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ScanPassportRec.init();
return ScanPassportRec;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.ScanPassportRec = ScanPassportRec;

});
define("ShopperPortalEU.model$ScanPassportList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$ScanPassportRec"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var ScanPassportList = (function (_super) {
__extends(ScanPassportList, _super);
function ScanPassportList(defaults) {
_super.apply(this, arguments);
}
ScanPassportList.itemType = ShopperPortalEUModel.ScanPassportRec;
return ScanPassportList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.ScanPassportList = ScanPassportList;

});
define("ShopperPortalEU.model$CustomSeparatorOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomSeparatorOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomSeparatorOptionsRecord = (function (_super) {
__extends(CustomSeparatorOptionsRecord, _super);
function CustomSeparatorOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomSeparatorOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomSeparatorOptions", "customSeparatorOptionsAttr", "CustomSeparatorOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomSeparatorOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomSeparatorOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomSeparatorOptionsRecord.fromStructure = function (str) {
return new CustomSeparatorOptionsRecord(new CustomSeparatorOptionsRecord.RecordClass({
customSeparatorOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomSeparatorOptionsRecord._isAnonymousRecord = true;
CustomSeparatorOptionsRecord.UniqueId = "92368d99-861b-4d23-9c43-bb6e81b82ed8";
CustomSeparatorOptionsRecord.init();
return CustomSeparatorOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomSeparatorOptionsRecord = CustomSeparatorOptionsRecord;

});
define("ShopperPortalEU.model$CustomSeparatorOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomSeparatorOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomSeparatorOptionsRecordList = (function (_super) {
__extends(CustomSeparatorOptionsRecordList, _super);
function CustomSeparatorOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomSeparatorOptionsRecordList.itemType = ShopperPortalEUModel.CustomSeparatorOptionsRecord;
return CustomSeparatorOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomSeparatorOptionsRecordList = CustomSeparatorOptionsRecordList;

});
define("ShopperPortalEU.model$MerchantLocationDTORecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$MerchantLocationDTORec"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var MerchantLocationDTORecord = (function (_super) {
__extends(MerchantLocationDTORecord, _super);
function MerchantLocationDTORecord(defaults) {
_super.apply(this, arguments);
}
MerchantLocationDTORecord.attributesToDeclare = function () {
return [
this.attr("MerchantLocationDTO", "merchantLocationDTOAttr", "MerchantLocationDTO", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEUModel.MerchantLocationDTORec());
}, true, ShopperPortalEUModel.MerchantLocationDTORec)
].concat(_super.attributesToDeclare.call(this));
};
MerchantLocationDTORecord.fromStructure = function (str) {
return new MerchantLocationDTORecord(new MerchantLocationDTORecord.RecordClass({
merchantLocationDTOAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
MerchantLocationDTORecord._isAnonymousRecord = true;
MerchantLocationDTORecord.UniqueId = "8f830587-b0d4-a3db-d161-385d141db893";
MerchantLocationDTORecord.init();
return MerchantLocationDTORecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.MerchantLocationDTORecord = MerchantLocationDTORecord;

});
define("ShopperPortalEU.model$MerchantLocationDTORecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$MerchantLocationDTORecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var MerchantLocationDTORecordList = (function (_super) {
__extends(MerchantLocationDTORecordList, _super);
function MerchantLocationDTORecordList(defaults) {
_super.apply(this, arguments);
}
MerchantLocationDTORecordList.itemType = ShopperPortalEUModel.MerchantLocationDTORecord;
return MerchantLocationDTORecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.MerchantLocationDTORecordList = MerchantLocationDTORecordList;

});
define("ShopperPortalEU.model$FormShopperDetailDTOList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$FormShopperDetailDTORec"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var FormShopperDetailDTOList = (function (_super) {
__extends(FormShopperDetailDTOList, _super);
function FormShopperDetailDTOList(defaults) {
_super.apply(this, arguments);
}
FormShopperDetailDTOList.itemType = ShopperPortalEUModel.FormShopperDetailDTORec;
return FormShopperDetailDTOList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.FormShopperDetailDTOList = FormShopperDetailDTOList;

});
define("ShopperPortalEU.model$TextRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$TextRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var TextRecordList = (function (_super) {
__extends(TextRecordList, _super);
function TextRecordList(defaults) {
_super.apply(this, arguments);
}
TextRecordList.itemType = ShopperPortalEUModel.TextRecord;
return TextRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.TextRecordList = TextRecordList;

});
define("ShopperPortalEU.model$CustomPopupLayoutOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomPopupLayoutOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomPopupLayoutOptionsRecord = (function (_super) {
__extends(CustomPopupLayoutOptionsRecord, _super);
function CustomPopupLayoutOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomPopupLayoutOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomPopupLayoutOptions", "customPopupLayoutOptionsAttr", "CustomPopupLayoutOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomPopupLayoutOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomPopupLayoutOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomPopupLayoutOptionsRecord.fromStructure = function (str) {
return new CustomPopupLayoutOptionsRecord(new CustomPopupLayoutOptionsRecord.RecordClass({
customPopupLayoutOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomPopupLayoutOptionsRecord._isAnonymousRecord = true;
CustomPopupLayoutOptionsRecord.UniqueId = "67980467-8b15-58ee-c638-94ef3d3b33d5";
CustomPopupLayoutOptionsRecord.init();
return CustomPopupLayoutOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomPopupLayoutOptionsRecord = CustomPopupLayoutOptionsRecord;

});
define("ShopperPortalEU.model$DatatransTokenFallbackRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU.model", "ShopperPortalEU_Shopper_IS.model$DatatransTokenFallbackRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var DatatransTokenFallbackRecord = (function (_super) {
__extends(DatatransTokenFallbackRecord, _super);
function DatatransTokenFallbackRecord(defaults) {
_super.apply(this, arguments);
}
DatatransTokenFallbackRecord.attributesToDeclare = function () {
return [
this.attr("DatatransTokenFallback", "datatransTokenFallbackAttr", "DatatransTokenFallback", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Shopper_ISModel.DatatransTokenFallbackRec());
}, true, ShopperPortalEU_Shopper_ISModel.DatatransTokenFallbackRec)
].concat(_super.attributesToDeclare.call(this));
};
DatatransTokenFallbackRecord.fromStructure = function (str) {
return new DatatransTokenFallbackRecord(new DatatransTokenFallbackRecord.RecordClass({
datatransTokenFallbackAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
DatatransTokenFallbackRecord._isAnonymousRecord = true;
DatatransTokenFallbackRecord.UniqueId = "a00329e6-e7a4-5fa0-fa18-442f4b66f64e";
DatatransTokenFallbackRecord.init();
return DatatransTokenFallbackRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.DatatransTokenFallbackRecord = DatatransTokenFallbackRecord;

});
define("ShopperPortalEU.model$DatatransTokenFallbackRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$DatatransTokenFallbackRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var DatatransTokenFallbackRecordList = (function (_super) {
__extends(DatatransTokenFallbackRecordList, _super);
function DatatransTokenFallbackRecordList(defaults) {
_super.apply(this, arguments);
}
DatatransTokenFallbackRecordList.itemType = ShopperPortalEUModel.DatatransTokenFallbackRecord;
return DatatransTokenFallbackRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.DatatransTokenFallbackRecordList = DatatransTokenFallbackRecordList;

});
define("ShopperPortalEU.model$FullHeightContentTopOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$FullHeightContentTopOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var FullHeightContentTopOptionsRecord = (function (_super) {
__extends(FullHeightContentTopOptionsRecord, _super);
function FullHeightContentTopOptionsRecord(defaults) {
_super.apply(this, arguments);
}
FullHeightContentTopOptionsRecord.attributesToDeclare = function () {
return [
this.attr("FullHeightContentTopOptions", "fullHeightContentTopOptionsAttr", "FullHeightContentTopOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.FullHeightContentTopOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.FullHeightContentTopOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
FullHeightContentTopOptionsRecord.fromStructure = function (str) {
return new FullHeightContentTopOptionsRecord(new FullHeightContentTopOptionsRecord.RecordClass({
fullHeightContentTopOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
FullHeightContentTopOptionsRecord._isAnonymousRecord = true;
FullHeightContentTopOptionsRecord.UniqueId = "67e79585-48db-9c33-2800-1d2d0ac3e9b6";
FullHeightContentTopOptionsRecord.init();
return FullHeightContentTopOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.FullHeightContentTopOptionsRecord = FullHeightContentTopOptionsRecord;

});
define("ShopperPortalEU.model$FlexItemOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$FlexItemOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var FlexItemOptionsList = (function (_super) {
__extends(FlexItemOptionsList, _super);
function FlexItemOptionsList(defaults) {
_super.apply(this, arguments);
}
FlexItemOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.FlexItemOptionsRec;
return FlexItemOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.FlexItemOptionsList = FlexItemOptionsList;

});
define("ShopperPortalEU.model$CustomDropdownListSelectedItemOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomDropdownListSelectedItemOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomDropdownListSelectedItemOptionsList = (function (_super) {
__extends(CustomDropdownListSelectedItemOptionsList, _super);
function CustomDropdownListSelectedItemOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownListSelectedItemOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomDropdownListSelectedItemOptionsRec;
return CustomDropdownListSelectedItemOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomDropdownListSelectedItemOptionsList = CustomDropdownListSelectedItemOptionsList;

});
define("ShopperPortalEU.model$CustomButtonOptionsIconList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomButtonOptionsIconList = (function (_super) {
__extends(CustomButtonOptionsIconList, _super);
function CustomButtonOptionsIconList(defaults) {
_super.apply(this, arguments);
}
CustomButtonOptionsIconList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsIconRec;
return CustomButtonOptionsIconList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomButtonOptionsIconList = CustomButtonOptionsIconList;

});
define("ShopperPortalEU.model$CustomTagStateRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomTagStateRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomTagStateRecordList = (function (_super) {
__extends(CustomTagStateRecordList, _super);
function CustomTagStateRecordList(defaults) {
_super.apply(this, arguments);
}
CustomTagStateRecordList.itemType = ShopperPortalEUModel.CustomTagStateRecord;
return CustomTagStateRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomTagStateRecordList = CustomTagStateRecordList;

});
define("ShopperPortalEU.model$CustomCardStateRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomCardStateRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomCardStateRecord = (function (_super) {
__extends(CustomCardStateRecord, _super);
function CustomCardStateRecord(defaults) {
_super.apply(this, arguments);
}
CustomCardStateRecord.attributesToDeclare = function () {
return [
this.attr("CustomCardState", "customCardStateAttr", "CustomCardState", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomCardStateRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomCardStateRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomCardStateRecord.fromStructure = function (str) {
return new CustomCardStateRecord(new CustomCardStateRecord.RecordClass({
customCardStateAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomCardStateRecord._isAnonymousRecord = true;
CustomCardStateRecord.UniqueId = "738e8e4d-5c00-5798-690f-86c52ce82f88";
CustomCardStateRecord.init();
return CustomCardStateRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomCardStateRecord = CustomCardStateRecord;

});
define("ShopperPortalEU.model$CustomCardStateRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomCardStateRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomCardStateRecordList = (function (_super) {
__extends(CustomCardStateRecordList, _super);
function CustomCardStateRecordList(defaults) {
_super.apply(this, arguments);
}
CustomCardStateRecordList.itemType = ShopperPortalEUModel.CustomCardStateRecord;
return CustomCardStateRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomCardStateRecordList = CustomCardStateRecordList;

});
define("ShopperPortalEU.model$CardStateTypeRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CardStateTypeRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CardStateTypeRecord = (function (_super) {
__extends(CardStateTypeRecord, _super);
function CardStateTypeRecord(defaults) {
_super.apply(this, arguments);
}
CardStateTypeRecord.attributesToDeclare = function () {
return [
this.attr("CardStateType", "cardStateTypeAttr", "CardStateType", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CardStateTypeRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CardStateTypeRec)
].concat(_super.attributesToDeclare.call(this));
};
CardStateTypeRecord.fromStructure = function (str) {
return new CardStateTypeRecord(new CardStateTypeRecord.RecordClass({
cardStateTypeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CardStateTypeRecord._isAnonymousRecord = true;
CardStateTypeRecord.UniqueId = "b7d7feb7-5b30-ca61-c992-48b012ab0684";
CardStateTypeRecord.init();
return CardStateTypeRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CardStateTypeRecord = CardStateTypeRecord;

});
define("ShopperPortalEU.model$CardStateTypeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CardStateTypeRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CardStateTypeRecordList = (function (_super) {
__extends(CardStateTypeRecordList, _super);
function CardStateTypeRecordList(defaults) {
_super.apply(this, arguments);
}
CardStateTypeRecordList.itemType = ShopperPortalEUModel.CardStateTypeRecord;
return CardStateTypeRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CardStateTypeRecordList = CardStateTypeRecordList;

});
define("ShopperPortalEU.model$Location_WrapperRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$Location_WrapperRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var Location_WrapperRecordList = (function (_super) {
__extends(Location_WrapperRecordList, _super);
function Location_WrapperRecordList(defaults) {
_super.apply(this, arguments);
}
Location_WrapperRecordList.itemType = ShopperPortalEUModel.Location_WrapperRecord;
return Location_WrapperRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.Location_WrapperRecordList = Location_WrapperRecordList;

});
define("ShopperPortalEU.model$CustomSeparatorStateRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomSeparatorStateRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomSeparatorStateRecord = (function (_super) {
__extends(CustomSeparatorStateRecord, _super);
function CustomSeparatorStateRecord(defaults) {
_super.apply(this, arguments);
}
CustomSeparatorStateRecord.attributesToDeclare = function () {
return [
this.attr("CustomSeparatorState", "customSeparatorStateAttr", "CustomSeparatorState", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomSeparatorStateRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomSeparatorStateRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomSeparatorStateRecord.fromStructure = function (str) {
return new CustomSeparatorStateRecord(new CustomSeparatorStateRecord.RecordClass({
customSeparatorStateAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomSeparatorStateRecord._isAnonymousRecord = true;
CustomSeparatorStateRecord.UniqueId = "6ae9036b-dacb-bc2f-5a59-8da4a3cd1222";
CustomSeparatorStateRecord.init();
return CustomSeparatorStateRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomSeparatorStateRecord = CustomSeparatorStateRecord;

});
define("ShopperPortalEU.model$LayoutAuthenticationList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$LayoutAuthenticationRec"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var LayoutAuthenticationList = (function (_super) {
__extends(LayoutAuthenticationList, _super);
function LayoutAuthenticationList(defaults) {
_super.apply(this, arguments);
}
LayoutAuthenticationList.itemType = ShopperPortalEUModel.LayoutAuthenticationRec;
return LayoutAuthenticationList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.LayoutAuthenticationList = LayoutAuthenticationList;

});
define("ShopperPortalEU.model$JustifyRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$JustifyRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var JustifyRecord = (function (_super) {
__extends(JustifyRecord, _super);
function JustifyRecord(defaults) {
_super.apply(this, arguments);
}
JustifyRecord.attributesToDeclare = function () {
return [
this.attr("Justify", "justifyAttr", "Justify", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.JustifyRec());
}, true, ShopperPortalEU_UI_ComponentsModel.JustifyRec)
].concat(_super.attributesToDeclare.call(this));
};
JustifyRecord.fromStructure = function (str) {
return new JustifyRecord(new JustifyRecord.RecordClass({
justifyAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
JustifyRecord._isAnonymousRecord = true;
JustifyRecord.UniqueId = "6b90c8b6-6cd5-9e52-610d-399ec523877a";
JustifyRecord.init();
return JustifyRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.JustifyRecord = JustifyRecord;

});
define("ShopperPortalEU.model$RecaptchaBadgeRecord", ["exports", "OutSystems/ClientRuntime/Main", "reCAPTCHAReact.model", "ShopperPortalEU.model", "reCAPTCHAReact.model$RecaptchaBadgeRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$reCAPTCHAReact"], function (exports, OutSystems, reCAPTCHAReactModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var RecaptchaBadgeRecord = (function (_super) {
__extends(RecaptchaBadgeRecord, _super);
function RecaptchaBadgeRecord(defaults) {
_super.apply(this, arguments);
}
RecaptchaBadgeRecord.attributesToDeclare = function () {
return [
this.attr("RecaptchaBadge", "recaptchaBadgeAttr", "RecaptchaBadge", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new reCAPTCHAReactModel.RecaptchaBadgeRec());
}, true, reCAPTCHAReactModel.RecaptchaBadgeRec)
].concat(_super.attributesToDeclare.call(this));
};
RecaptchaBadgeRecord.fromStructure = function (str) {
return new RecaptchaBadgeRecord(new RecaptchaBadgeRecord.RecordClass({
recaptchaBadgeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
RecaptchaBadgeRecord._isAnonymousRecord = true;
RecaptchaBadgeRecord.UniqueId = "c7eb6330-463d-3421-e14d-c18a2ede3ffb";
RecaptchaBadgeRecord.init();
return RecaptchaBadgeRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.RecaptchaBadgeRecord = RecaptchaBadgeRecord;

});
define("ShopperPortalEU.model$RecaptchaBadgeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$RecaptchaBadgeRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var RecaptchaBadgeRecordList = (function (_super) {
__extends(RecaptchaBadgeRecordList, _super);
function RecaptchaBadgeRecordList(defaults) {
_super.apply(this, arguments);
}
RecaptchaBadgeRecordList.itemType = ShopperPortalEUModel.RecaptchaBadgeRecord;
return RecaptchaBadgeRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.RecaptchaBadgeRecordList = RecaptchaBadgeRecordList;

});
define("ShopperPortalEU.model$CompleteDetailsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CompleteDetailsRec"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CompleteDetailsRecord = (function (_super) {
__extends(CompleteDetailsRecord, _super);
function CompleteDetailsRecord(defaults) {
_super.apply(this, arguments);
}
CompleteDetailsRecord.attributesToDeclare = function () {
return [
this.attr("CompleteDetails", "completeDetailsAttr", "CompleteDetails", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEUModel.CompleteDetailsRec());
}, true, ShopperPortalEUModel.CompleteDetailsRec)
].concat(_super.attributesToDeclare.call(this));
};
CompleteDetailsRecord.fromStructure = function (str) {
return new CompleteDetailsRecord(new CompleteDetailsRecord.RecordClass({
completeDetailsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CompleteDetailsRecord._isAnonymousRecord = true;
CompleteDetailsRecord.UniqueId = "6c08ea78-35f5-cd90-9926-20e11376ede9";
CompleteDetailsRecord.init();
return CompleteDetailsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CompleteDetailsRecord = CompleteDetailsRecord;

});
define("ShopperPortalEU.model$CustomImageOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomImageOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomImageOptionsRecord = (function (_super) {
__extends(CustomImageOptionsRecord, _super);
function CustomImageOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomImageOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomImageOptions", "customImageOptionsAttr", "CustomImageOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomImageOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomImageOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomImageOptionsRecord.fromStructure = function (str) {
return new CustomImageOptionsRecord(new CustomImageOptionsRecord.RecordClass({
customImageOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomImageOptionsRecord._isAnonymousRecord = true;
CustomImageOptionsRecord.UniqueId = "6d62359a-099d-f43a-257f-8bd5e345c82b";
CustomImageOptionsRecord.init();
return CustomImageOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomImageOptionsRecord = CustomImageOptionsRecord;

});
define("ShopperPortalEU.model$ScanBarcodeErrorRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$ScanBarcodeErrorRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var ScanBarcodeErrorRecord = (function (_super) {
__extends(ScanBarcodeErrorRecord, _super);
function ScanBarcodeErrorRecord(defaults) {
_super.apply(this, arguments);
}
ScanBarcodeErrorRecord.attributesToDeclare = function () {
return [
this.attr("ScanBarcodeError", "scanBarcodeErrorAttr", "ScanBarcodeError", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.ScanBarcodeErrorRec());
}, true, ShopperPortalEU_UI_ComponentsModel.ScanBarcodeErrorRec)
].concat(_super.attributesToDeclare.call(this));
};
ScanBarcodeErrorRecord.fromStructure = function (str) {
return new ScanBarcodeErrorRecord(new ScanBarcodeErrorRecord.RecordClass({
scanBarcodeErrorAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ScanBarcodeErrorRecord._isAnonymousRecord = true;
ScanBarcodeErrorRecord.UniqueId = "83b7b38b-de8c-7fe9-1d2e-2a90d4f634d8";
ScanBarcodeErrorRecord.init();
return ScanBarcodeErrorRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.ScanBarcodeErrorRecord = ScanBarcodeErrorRecord;

});
define("ShopperPortalEU.model$ScanBarcodeErrorRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$ScanBarcodeErrorRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var ScanBarcodeErrorRecordList = (function (_super) {
__extends(ScanBarcodeErrorRecordList, _super);
function ScanBarcodeErrorRecordList(defaults) {
_super.apply(this, arguments);
}
ScanBarcodeErrorRecordList.itemType = ShopperPortalEUModel.ScanBarcodeErrorRecord;
return ScanBarcodeErrorRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.ScanBarcodeErrorRecordList = ScanBarcodeErrorRecordList;

});
define("ShopperPortalEU.model$JustifyRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$JustifyRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var JustifyRecordList = (function (_super) {
__extends(JustifyRecordList, _super);
function JustifyRecordList(defaults) {
_super.apply(this, arguments);
}
JustifyRecordList.itemType = ShopperPortalEUModel.JustifyRecord;
return JustifyRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.JustifyRecordList = JustifyRecordList;

});
define("ShopperPortalEU.model$CustomValidationMessageStateRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomValidationMessageStateRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomValidationMessageStateRecord = (function (_super) {
__extends(CustomValidationMessageStateRecord, _super);
function CustomValidationMessageStateRecord(defaults) {
_super.apply(this, arguments);
}
CustomValidationMessageStateRecord.attributesToDeclare = function () {
return [
this.attr("CustomValidationMessageState", "customValidationMessageStateAttr", "CustomValidationMessageState", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomValidationMessageStateRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomValidationMessageStateRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomValidationMessageStateRecord.fromStructure = function (str) {
return new CustomValidationMessageStateRecord(new CustomValidationMessageStateRecord.RecordClass({
customValidationMessageStateAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomValidationMessageStateRecord._isAnonymousRecord = true;
CustomValidationMessageStateRecord.UniqueId = "8bd44d05-41d5-a18f-9058-8e1bdbf0b716";
CustomValidationMessageStateRecord.init();
return CustomValidationMessageStateRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomValidationMessageStateRecord = CustomValidationMessageStateRecord;

});
define("ShopperPortalEU.model$CustomValidationMessageStateRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomValidationMessageStateRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomValidationMessageStateRecordList = (function (_super) {
__extends(CustomValidationMessageStateRecordList, _super);
function CustomValidationMessageStateRecordList(defaults) {
_super.apply(this, arguments);
}
CustomValidationMessageStateRecordList.itemType = ShopperPortalEUModel.CustomValidationMessageStateRecord;
return CustomValidationMessageStateRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomValidationMessageStateRecordList = CustomValidationMessageStateRecordList;

});
define("ShopperPortalEU.model$FlexAlignRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$FlexAlignRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var FlexAlignRecord = (function (_super) {
__extends(FlexAlignRecord, _super);
function FlexAlignRecord(defaults) {
_super.apply(this, arguments);
}
FlexAlignRecord.attributesToDeclare = function () {
return [
this.attr("FlexAlign", "flexAlignAttr", "FlexAlign", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.FlexAlignRec());
}, true, ShopperPortalEU_UI_ComponentsModel.FlexAlignRec)
].concat(_super.attributesToDeclare.call(this));
};
FlexAlignRecord.fromStructure = function (str) {
return new FlexAlignRecord(new FlexAlignRecord.RecordClass({
flexAlignAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
FlexAlignRecord._isAnonymousRecord = true;
FlexAlignRecord.UniqueId = "70505c3e-d9c1-09e1-7b33-d412e5e6f0b5";
FlexAlignRecord.init();
return FlexAlignRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.FlexAlignRecord = FlexAlignRecord;

});
define("ShopperPortalEU.model$DeleteCardBodyRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU.model", "ShopperPortalEU_Shopper_IS.model$DeleteCardBodyRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var DeleteCardBodyRecord = (function (_super) {
__extends(DeleteCardBodyRecord, _super);
function DeleteCardBodyRecord(defaults) {
_super.apply(this, arguments);
}
DeleteCardBodyRecord.attributesToDeclare = function () {
return [
this.attr("DeleteCardBody", "deleteCardBodyAttr", "DeleteCardBody", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Shopper_ISModel.DeleteCardBodyRec());
}, true, ShopperPortalEU_Shopper_ISModel.DeleteCardBodyRec)
].concat(_super.attributesToDeclare.call(this));
};
DeleteCardBodyRecord.fromStructure = function (str) {
return new DeleteCardBodyRecord(new DeleteCardBodyRecord.RecordClass({
deleteCardBodyAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
DeleteCardBodyRecord._isAnonymousRecord = true;
DeleteCardBodyRecord.UniqueId = "b237ea99-f2e2-374b-5e07-724bfc5e422c";
DeleteCardBodyRecord.init();
return DeleteCardBodyRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.DeleteCardBodyRecord = DeleteCardBodyRecord;

});
define("ShopperPortalEU.model$DeleteCardBodyRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$DeleteCardBodyRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var DeleteCardBodyRecordList = (function (_super) {
__extends(DeleteCardBodyRecordList, _super);
function DeleteCardBodyRecordList(defaults) {
_super.apply(this, arguments);
}
DeleteCardBodyRecordList.itemType = ShopperPortalEUModel.DeleteCardBodyRecord;
return DeleteCardBodyRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.DeleteCardBodyRecordList = DeleteCardBodyRecordList;

});
define("ShopperPortalEU.model$UIConfigurationList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU.model", "ShopperPortalEU_Forms_IS.model$UIConfigurationRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Forms_IS"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var UIConfigurationList = (function (_super) {
__extends(UIConfigurationList, _super);
function UIConfigurationList(defaults) {
_super.apply(this, arguments);
}
UIConfigurationList.itemType = ShopperPortalEU_Forms_ISModel.UIConfigurationRec;
return UIConfigurationList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.UIConfigurationList = UIConfigurationList;

});
define("ShopperPortalEU.model$BottomBarOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Theme.model$BottomBarOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var BottomBarOptionsList = (function (_super) {
__extends(BottomBarOptionsList, _super);
function BottomBarOptionsList(defaults) {
_super.apply(this, arguments);
}
BottomBarOptionsList.itemType = ShopperPortalEU_UI_ThemeModel.BottomBarOptionsRec;
return BottomBarOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.BottomBarOptionsList = BottomBarOptionsList;

});
define("ShopperPortalEU.model$CustomDropdownCustomValueOptionList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomDropdownCustomValueOptionRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomDropdownCustomValueOptionList = (function (_super) {
__extends(CustomDropdownCustomValueOptionList, _super);
function CustomDropdownCustomValueOptionList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownCustomValueOptionList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomDropdownCustomValueOptionRec;
return CustomDropdownCustomValueOptionList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomDropdownCustomValueOptionList = CustomDropdownCustomValueOptionList;

});
define("ShopperPortalEU.model$UpdateCardDataRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU.model", "ShopperPortalEU_Shopper_IS.model$UpdateCardDataRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var UpdateCardDataRecord = (function (_super) {
__extends(UpdateCardDataRecord, _super);
function UpdateCardDataRecord(defaults) {
_super.apply(this, arguments);
}
UpdateCardDataRecord.attributesToDeclare = function () {
return [
this.attr("UpdateCardData", "updateCardDataAttr", "UpdateCardData", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Shopper_ISModel.UpdateCardDataRec());
}, true, ShopperPortalEU_Shopper_ISModel.UpdateCardDataRec)
].concat(_super.attributesToDeclare.call(this));
};
UpdateCardDataRecord.fromStructure = function (str) {
return new UpdateCardDataRecord(new UpdateCardDataRecord.RecordClass({
updateCardDataAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
UpdateCardDataRecord._isAnonymousRecord = true;
UpdateCardDataRecord.UniqueId = "74e578f3-3808-27d7-bafc-9a0ba367ac89";
UpdateCardDataRecord.init();
return UpdateCardDataRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.UpdateCardDataRecord = UpdateCardDataRecord;

});
define("ShopperPortalEU.model$CodeInputOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CodeInputOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CodeInputOptionsList = (function (_super) {
__extends(CodeInputOptionsList, _super);
function CodeInputOptionsList(defaults) {
_super.apply(this, arguments);
}
CodeInputOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CodeInputOptionsRec;
return CodeInputOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CodeInputOptionsList = CodeInputOptionsList;

});
define("ShopperPortalEU.model$CreditCardOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CreditCardOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CreditCardOptionsRecord = (function (_super) {
__extends(CreditCardOptionsRecord, _super);
function CreditCardOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CreditCardOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CreditCardOptions", "creditCardOptionsAttr", "CreditCardOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CreditCardOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CreditCardOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CreditCardOptionsRecord.fromStructure = function (str) {
return new CreditCardOptionsRecord(new CreditCardOptionsRecord.RecordClass({
creditCardOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CreditCardOptionsRecord._isAnonymousRecord = true;
CreditCardOptionsRecord.UniqueId = "dec11bd0-7c39-4566-0d16-6deb70cb0d7e";
CreditCardOptionsRecord.init();
return CreditCardOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CreditCardOptionsRecord = CreditCardOptionsRecord;

});
define("ShopperPortalEU.model$CreditCardOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CreditCardOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CreditCardOptionsRecordList = (function (_super) {
__extends(CreditCardOptionsRecordList, _super);
function CreditCardOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CreditCardOptionsRecordList.itemType = ShopperPortalEUModel.CreditCardOptionsRecord;
return CreditCardOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CreditCardOptionsRecordList = CreditCardOptionsRecordList;

});
define("ShopperPortalEU.model$LayoutHeaderOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Theme.model$LayoutHeaderOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var LayoutHeaderOptionsRecord = (function (_super) {
__extends(LayoutHeaderOptionsRecord, _super);
function LayoutHeaderOptionsRecord(defaults) {
_super.apply(this, arguments);
}
LayoutHeaderOptionsRecord.attributesToDeclare = function () {
return [
this.attr("LayoutHeaderOptions", "layoutHeaderOptionsAttr", "LayoutHeaderOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ThemeModel.LayoutHeaderOptionsRec());
}, true, ShopperPortalEU_UI_ThemeModel.LayoutHeaderOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
LayoutHeaderOptionsRecord.fromStructure = function (str) {
return new LayoutHeaderOptionsRecord(new LayoutHeaderOptionsRecord.RecordClass({
layoutHeaderOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
LayoutHeaderOptionsRecord._isAnonymousRecord = true;
LayoutHeaderOptionsRecord.UniqueId = "7555ea85-7cc5-9f8e-b6b7-2fd90463ce87";
LayoutHeaderOptionsRecord.init();
return LayoutHeaderOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.LayoutHeaderOptionsRecord = LayoutHeaderOptionsRecord;

});
define("ShopperPortalEU.model$CustomInputIconOptionList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomInputIconOptionRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomInputIconOptionList = (function (_super) {
__extends(CustomInputIconOptionList, _super);
function CustomInputIconOptionList(defaults) {
_super.apply(this, arguments);
}
CustomInputIconOptionList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomInputIconOptionRec;
return CustomInputIconOptionList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomInputIconOptionList = CustomInputIconOptionList;

});
define("ShopperPortalEU.model$CustomColumnsItemOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomColumnsItemOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomColumnsItemOptionsRecord = (function (_super) {
__extends(CustomColumnsItemOptionsRecord, _super);
function CustomColumnsItemOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomColumnsItemOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomColumnsItemOptions", "customColumnsItemOptionsAttr", "CustomColumnsItemOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomColumnsItemOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomColumnsItemOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomColumnsItemOptionsRecord.fromStructure = function (str) {
return new CustomColumnsItemOptionsRecord(new CustomColumnsItemOptionsRecord.RecordClass({
customColumnsItemOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomColumnsItemOptionsRecord._isAnonymousRecord = true;
CustomColumnsItemOptionsRecord.UniqueId = "773960df-fa9c-834e-ef84-9693c03790ef";
CustomColumnsItemOptionsRecord.init();
return CustomColumnsItemOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomColumnsItemOptionsRecord = CustomColumnsItemOptionsRecord;

});
define("ShopperPortalEU.model$FullHeightContentBottomOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$FullHeightContentBottomOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var FullHeightContentBottomOptionsRecord = (function (_super) {
__extends(FullHeightContentBottomOptionsRecord, _super);
function FullHeightContentBottomOptionsRecord(defaults) {
_super.apply(this, arguments);
}
FullHeightContentBottomOptionsRecord.attributesToDeclare = function () {
return [
this.attr("FullHeightContentBottomOptions", "fullHeightContentBottomOptionsAttr", "FullHeightContentBottomOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.FullHeightContentBottomOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.FullHeightContentBottomOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
FullHeightContentBottomOptionsRecord.fromStructure = function (str) {
return new FullHeightContentBottomOptionsRecord(new FullHeightContentBottomOptionsRecord.RecordClass({
fullHeightContentBottomOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
FullHeightContentBottomOptionsRecord._isAnonymousRecord = true;
FullHeightContentBottomOptionsRecord.UniqueId = "77821e6d-1b60-9ae0-404e-eb923da4a3d4";
FullHeightContentBottomOptionsRecord.init();
return FullHeightContentBottomOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.FullHeightContentBottomOptionsRecord = FullHeightContentBottomOptionsRecord;

});
define("ShopperPortalEU.model$AnonymousFormsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$AnonymousFormsRec"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var AnonymousFormsRecord = (function (_super) {
__extends(AnonymousFormsRecord, _super);
function AnonymousFormsRecord(defaults) {
_super.apply(this, arguments);
}
AnonymousFormsRecord.attributesToDeclare = function () {
return [
this.attr("AnonymousForms", "anonymousFormsAttr", "AnonymousForms", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEUModel.AnonymousFormsRec());
}, true, ShopperPortalEUModel.AnonymousFormsRec)
].concat(_super.attributesToDeclare.call(this));
};
AnonymousFormsRecord.fromStructure = function (str) {
return new AnonymousFormsRecord(new AnonymousFormsRecord.RecordClass({
anonymousFormsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
AnonymousFormsRecord._isAnonymousRecord = true;
AnonymousFormsRecord.UniqueId = "d1eb8666-45af-d9db-41dc-e49c5be87e75";
AnonymousFormsRecord.init();
return AnonymousFormsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.AnonymousFormsRecord = AnonymousFormsRecord;

});
define("ShopperPortalEU.model$AnonymousFormsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$AnonymousFormsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var AnonymousFormsRecordList = (function (_super) {
__extends(AnonymousFormsRecordList, _super);
function AnonymousFormsRecordList(defaults) {
_super.apply(this, arguments);
}
AnonymousFormsRecordList.itemType = ShopperPortalEUModel.AnonymousFormsRecord;
return AnonymousFormsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.AnonymousFormsRecordList = AnonymousFormsRecordList;

});
define("ShopperPortalEU.model$CustomTagStateList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomTagStateRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomTagStateList = (function (_super) {
__extends(CustomTagStateList, _super);
function CustomTagStateList(defaults) {
_super.apply(this, arguments);
}
CustomTagStateList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomTagStateRec;
return CustomTagStateList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomTagStateList = CustomTagStateList;

});
define("ShopperPortalEU.model$DatePickerLabelOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$DatePickerLabelOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var DatePickerLabelOptionsRecordList = (function (_super) {
__extends(DatePickerLabelOptionsRecordList, _super);
function DatePickerLabelOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
DatePickerLabelOptionsRecordList.itemType = ShopperPortalEUModel.DatePickerLabelOptionsRecord;
return DatePickerLabelOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.DatePickerLabelOptionsRecordList = DatePickerLabelOptionsRecordList;

});
define("ShopperPortalEU.model$FullHeightContentOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$FullHeightContentOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var FullHeightContentOptionsRecordList = (function (_super) {
__extends(FullHeightContentOptionsRecordList, _super);
function FullHeightContentOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
FullHeightContentOptionsRecordList.itemType = ShopperPortalEUModel.FullHeightContentOptionsRecord;
return FullHeightContentOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.FullHeightContentOptionsRecordList = FullHeightContentOptionsRecordList;

});
define("ShopperPortalEU.model$AvatarOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$AvatarOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var AvatarOptionsList = (function (_super) {
__extends(AvatarOptionsList, _super);
function AvatarOptionsList(defaults) {
_super.apply(this, arguments);
}
AvatarOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.AvatarOptionsRec;
return AvatarOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.AvatarOptionsList = AvatarOptionsList;

});
define("ShopperPortalEU.model$CircleIconOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CircleIconOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CircleIconOptionsRecord = (function (_super) {
__extends(CircleIconOptionsRecord, _super);
function CircleIconOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CircleIconOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CircleIconOptions", "circleIconOptionsAttr", "CircleIconOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CircleIconOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CircleIconOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CircleIconOptionsRecord.fromStructure = function (str) {
return new CircleIconOptionsRecord(new CircleIconOptionsRecord.RecordClass({
circleIconOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CircleIconOptionsRecord._isAnonymousRecord = true;
CircleIconOptionsRecord.UniqueId = "d8c7b417-6e5c-8842-0b05-c912029a778b";
CircleIconOptionsRecord.init();
return CircleIconOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CircleIconOptionsRecord = CircleIconOptionsRecord;

});
define("ShopperPortalEU.model$CircleIconOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CircleIconOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CircleIconOptionsRecordList = (function (_super) {
__extends(CircleIconOptionsRecordList, _super);
function CircleIconOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CircleIconOptionsRecordList.itemType = ShopperPortalEUModel.CircleIconOptionsRecord;
return CircleIconOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CircleIconOptionsRecordList = CircleIconOptionsRecordList;

});
define("ShopperPortalEU.model$FullHeightContentTopOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$FullHeightContentTopOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var FullHeightContentTopOptionsRecordList = (function (_super) {
__extends(FullHeightContentTopOptionsRecordList, _super);
function FullHeightContentTopOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
FullHeightContentTopOptionsRecordList.itemType = ShopperPortalEUModel.FullHeightContentTopOptionsRecord;
return FullHeightContentTopOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.FullHeightContentTopOptionsRecordList = FullHeightContentTopOptionsRecordList;

});
define("ShopperPortalEU.model$DatatransCardOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$DatatransCardOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var DatatransCardOptionsList = (function (_super) {
__extends(DatatransCardOptionsList, _super);
function DatatransCardOptionsList(defaults) {
_super.apply(this, arguments);
}
DatatransCardOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.DatatransCardOptionsRec;
return DatatransCardOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.DatatransCardOptionsList = DatatransCardOptionsList;

});
define("ShopperPortalEU.model$CustomSwitchOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomSwitchOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomSwitchOptionsRecord = (function (_super) {
__extends(CustomSwitchOptionsRecord, _super);
function CustomSwitchOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomSwitchOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomSwitchOptions", "customSwitchOptionsAttr", "CustomSwitchOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomSwitchOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomSwitchOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomSwitchOptionsRecord.fromStructure = function (str) {
return new CustomSwitchOptionsRecord(new CustomSwitchOptionsRecord.RecordClass({
customSwitchOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomSwitchOptionsRecord._isAnonymousRecord = true;
CustomSwitchOptionsRecord.UniqueId = "7ba8714f-d841-5fdb-db21-e03825219d77";
CustomSwitchOptionsRecord.init();
return CustomSwitchOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomSwitchOptionsRecord = CustomSwitchOptionsRecord;

});
define("ShopperPortalEU.model$CardBackgroundTypeRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CardBackgroundTypeRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CardBackgroundTypeRecord = (function (_super) {
__extends(CardBackgroundTypeRecord, _super);
function CardBackgroundTypeRecord(defaults) {
_super.apply(this, arguments);
}
CardBackgroundTypeRecord.attributesToDeclare = function () {
return [
this.attr("CardBackgroundType", "cardBackgroundTypeAttr", "CardBackgroundType", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CardBackgroundTypeRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CardBackgroundTypeRec)
].concat(_super.attributesToDeclare.call(this));
};
CardBackgroundTypeRecord.fromStructure = function (str) {
return new CardBackgroundTypeRecord(new CardBackgroundTypeRecord.RecordClass({
cardBackgroundTypeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CardBackgroundTypeRecord._isAnonymousRecord = true;
CardBackgroundTypeRecord.UniqueId = "b8ec40b3-3a7a-19f4-23d7-8f3c0053af42";
CardBackgroundTypeRecord.init();
return CardBackgroundTypeRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CardBackgroundTypeRecord = CardBackgroundTypeRecord;

});
define("ShopperPortalEU.model$CardBackgroundTypeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CardBackgroundTypeRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CardBackgroundTypeRecordList = (function (_super) {
__extends(CardBackgroundTypeRecordList, _super);
function CardBackgroundTypeRecordList(defaults) {
_super.apply(this, arguments);
}
CardBackgroundTypeRecordList.itemType = ShopperPortalEUModel.CardBackgroundTypeRecord;
return CardBackgroundTypeRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CardBackgroundTypeRecordList = CardBackgroundTypeRecordList;

});
define("ShopperPortalEU.model$PassportList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$PassportRec"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var PassportList = (function (_super) {
__extends(PassportList, _super);
function PassportList(defaults) {
_super.apply(this, arguments);
}
PassportList.itemType = ShopperPortalEUModel.PassportRec;
return PassportList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.PassportList = PassportList;

});
define("ShopperPortalEU.model$CustomFlagOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomFlagOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomFlagOptionsRecord = (function (_super) {
__extends(CustomFlagOptionsRecord, _super);
function CustomFlagOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomFlagOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomFlagOptions", "customFlagOptionsAttr", "CustomFlagOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomFlagOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomFlagOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomFlagOptionsRecord.fromStructure = function (str) {
return new CustomFlagOptionsRecord(new CustomFlagOptionsRecord.RecordClass({
customFlagOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomFlagOptionsRecord._isAnonymousRecord = true;
CustomFlagOptionsRecord.UniqueId = "7cef2456-9b73-7348-8553-e2840b8a1f47";
CustomFlagOptionsRecord.init();
return CustomFlagOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomFlagOptionsRecord = CustomFlagOptionsRecord;

});
define("ShopperPortalEU.model$FormShopperDetailDTORecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$FormShopperDetailDTORec"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var FormShopperDetailDTORecord = (function (_super) {
__extends(FormShopperDetailDTORecord, _super);
function FormShopperDetailDTORecord(defaults) {
_super.apply(this, arguments);
}
FormShopperDetailDTORecord.attributesToDeclare = function () {
return [
this.attr("FormShopperDetailDTO", "formShopperDetailDTOAttr", "FormShopperDetailDTO", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEUModel.FormShopperDetailDTORec());
}, true, ShopperPortalEUModel.FormShopperDetailDTORec)
].concat(_super.attributesToDeclare.call(this));
};
FormShopperDetailDTORecord.fromStructure = function (str) {
return new FormShopperDetailDTORecord(new FormShopperDetailDTORecord.RecordClass({
formShopperDetailDTOAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
FormShopperDetailDTORecord._isAnonymousRecord = true;
FormShopperDetailDTORecord.UniqueId = "c511701c-631d-08de-9696-66739aa844e5";
FormShopperDetailDTORecord.init();
return FormShopperDetailDTORecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.FormShopperDetailDTORecord = FormShopperDetailDTORecord;

});
define("ShopperPortalEU.model$FormShopperDetailDTORecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$FormShopperDetailDTORecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var FormShopperDetailDTORecordList = (function (_super) {
__extends(FormShopperDetailDTORecordList, _super);
function FormShopperDetailDTORecordList(defaults) {
_super.apply(this, arguments);
}
FormShopperDetailDTORecordList.itemType = ShopperPortalEUModel.FormShopperDetailDTORecord;
return FormShopperDetailDTORecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.FormShopperDetailDTORecordList = FormShopperDetailDTORecordList;

});
define("ShopperPortalEU.model$CustomValidationMessageOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomValidationMessageOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomValidationMessageOptionsRecord = (function (_super) {
__extends(CustomValidationMessageOptionsRecord, _super);
function CustomValidationMessageOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomValidationMessageOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomValidationMessageOptions", "customValidationMessageOptionsAttr", "CustomValidationMessageOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomValidationMessageOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomValidationMessageOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomValidationMessageOptionsRecord.fromStructure = function (str) {
return new CustomValidationMessageOptionsRecord(new CustomValidationMessageOptionsRecord.RecordClass({
customValidationMessageOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomValidationMessageOptionsRecord._isAnonymousRecord = true;
CustomValidationMessageOptionsRecord.UniqueId = "9b216a9f-bc34-7ace-5b4d-239f72cda6a6";
CustomValidationMessageOptionsRecord.init();
return CustomValidationMessageOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomValidationMessageOptionsRecord = CustomValidationMessageOptionsRecord;

});
define("ShopperPortalEU.model$CustomValidationMessageOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomValidationMessageOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomValidationMessageOptionsRecordList = (function (_super) {
__extends(CustomValidationMessageOptionsRecordList, _super);
function CustomValidationMessageOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomValidationMessageOptionsRecordList.itemType = ShopperPortalEUModel.CustomValidationMessageOptionsRecord;
return CustomValidationMessageOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomValidationMessageOptionsRecordList = CustomValidationMessageOptionsRecordList;

});
define("ShopperPortalEU.model$LayoutBlankOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Theme.model$LayoutBlankOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var LayoutBlankOptionsList = (function (_super) {
__extends(LayoutBlankOptionsList, _super);
function LayoutBlankOptionsList(defaults) {
_super.apply(this, arguments);
}
LayoutBlankOptionsList.itemType = ShopperPortalEU_UI_ThemeModel.LayoutBlankOptionsRec;
return LayoutBlankOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.LayoutBlankOptionsList = LayoutBlankOptionsList;

});
define("ShopperPortalEU.model$CustomColumnsOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomColumnsOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomColumnsOptionsRecord = (function (_super) {
__extends(CustomColumnsOptionsRecord, _super);
function CustomColumnsOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomColumnsOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomColumnsOptions", "customColumnsOptionsAttr", "CustomColumnsOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomColumnsOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomColumnsOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomColumnsOptionsRecord.fromStructure = function (str) {
return new CustomColumnsOptionsRecord(new CustomColumnsOptionsRecord.RecordClass({
customColumnsOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomColumnsOptionsRecord._isAnonymousRecord = true;
CustomColumnsOptionsRecord.UniqueId = "80510748-bfcb-3f63-e1cf-56d102d07849";
CustomColumnsOptionsRecord.init();
return CustomColumnsOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomColumnsOptionsRecord = CustomColumnsOptionsRecord;

});
define("ShopperPortalEU.model$CustomOfficeInfo_WrapperRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_API.model", "ShopperPortalEU.model", "ShopperPortalEU_API.model$CustomOfficeInfo_WrapperRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_API"], function (exports, OutSystems, ShopperPortalEU_APIModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomOfficeInfo_WrapperRecord = (function (_super) {
__extends(CustomOfficeInfo_WrapperRecord, _super);
function CustomOfficeInfo_WrapperRecord(defaults) {
_super.apply(this, arguments);
}
CustomOfficeInfo_WrapperRecord.attributesToDeclare = function () {
return [
this.attr("CustomOfficeInfo_Wrapper", "customOfficeInfo_WrapperAttr", "CustomOfficeInfo_Wrapper", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_APIModel.CustomOfficeInfo_WrapperRec());
}, true, ShopperPortalEU_APIModel.CustomOfficeInfo_WrapperRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomOfficeInfo_WrapperRecord.fromStructure = function (str) {
return new CustomOfficeInfo_WrapperRecord(new CustomOfficeInfo_WrapperRecord.RecordClass({
customOfficeInfo_WrapperAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomOfficeInfo_WrapperRecord._isAnonymousRecord = true;
CustomOfficeInfo_WrapperRecord.UniqueId = "812b49ea-1024-42c8-5051-0f824fa0cba0";
CustomOfficeInfo_WrapperRecord.init();
return CustomOfficeInfo_WrapperRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomOfficeInfo_WrapperRecord = CustomOfficeInfo_WrapperRecord;

});
define("ShopperPortalEU.model$CustomTimelineTypeRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomTimelineTypeRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomTimelineTypeRecord = (function (_super) {
__extends(CustomTimelineTypeRecord, _super);
function CustomTimelineTypeRecord(defaults) {
_super.apply(this, arguments);
}
CustomTimelineTypeRecord.attributesToDeclare = function () {
return [
this.attr("CustomTimelineType", "customTimelineTypeAttr", "CustomTimelineType", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomTimelineTypeRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomTimelineTypeRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomTimelineTypeRecord.fromStructure = function (str) {
return new CustomTimelineTypeRecord(new CustomTimelineTypeRecord.RecordClass({
customTimelineTypeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomTimelineTypeRecord._isAnonymousRecord = true;
CustomTimelineTypeRecord.UniqueId = "812b9d97-c951-8dce-3b0c-b27b261b45ee";
CustomTimelineTypeRecord.init();
return CustomTimelineTypeRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomTimelineTypeRecord = CustomTimelineTypeRecord;

});
define("ShopperPortalEU.model$GetOSBrowserOptionList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$GetOSBrowserOptionRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var GetOSBrowserOptionList = (function (_super) {
__extends(GetOSBrowserOptionList, _super);
function GetOSBrowserOptionList(defaults) {
_super.apply(this, arguments);
}
GetOSBrowserOptionList.itemType = ShopperPortalEU_UI_ComponentsModel.GetOSBrowserOptionRec;
return GetOSBrowserOptionList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.GetOSBrowserOptionList = GetOSBrowserOptionList;

});
define("ShopperPortalEU.model$CardStateOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CardStateOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CardStateOptionsList = (function (_super) {
__extends(CardStateOptionsList, _super);
function CardStateOptionsList(defaults) {
_super.apply(this, arguments);
}
CardStateOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CardStateOptionsRec;
return CardStateOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CardStateOptionsList = CardStateOptionsList;

});
define("ShopperPortalEU.model$CardExpandableOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CardExpandableOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CardExpandableOptionsRecord = (function (_super) {
__extends(CardExpandableOptionsRecord, _super);
function CardExpandableOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CardExpandableOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CardExpandableOptions", "cardExpandableOptionsAttr", "CardExpandableOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CardExpandableOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CardExpandableOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CardExpandableOptionsRecord.fromStructure = function (str) {
return new CardExpandableOptionsRecord(new CardExpandableOptionsRecord.RecordClass({
cardExpandableOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CardExpandableOptionsRecord._isAnonymousRecord = true;
CardExpandableOptionsRecord.UniqueId = "93dab75e-a046-82db-9ad1-9c6eae5ab22d";
CardExpandableOptionsRecord.init();
return CardExpandableOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CardExpandableOptionsRecord = CardExpandableOptionsRecord;

});
define("ShopperPortalEU.model$CardExpandableOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CardExpandableOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CardExpandableOptionsRecordList = (function (_super) {
__extends(CardExpandableOptionsRecordList, _super);
function CardExpandableOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CardExpandableOptionsRecordList.itemType = ShopperPortalEUModel.CardExpandableOptionsRecord;
return CardExpandableOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CardExpandableOptionsRecordList = CardExpandableOptionsRecordList;

});
define("ShopperPortalEU.model$LayoutAuthenticationRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$LayoutAuthenticationRec"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var LayoutAuthenticationRecord = (function (_super) {
__extends(LayoutAuthenticationRecord, _super);
function LayoutAuthenticationRecord(defaults) {
_super.apply(this, arguments);
}
LayoutAuthenticationRecord.attributesToDeclare = function () {
return [
this.attr("LayoutAuthentication", "layoutAuthenticationAttr", "LayoutAuthentication", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEUModel.LayoutAuthenticationRec());
}, true, ShopperPortalEUModel.LayoutAuthenticationRec)
].concat(_super.attributesToDeclare.call(this));
};
LayoutAuthenticationRecord.fromStructure = function (str) {
return new LayoutAuthenticationRecord(new LayoutAuthenticationRecord.RecordClass({
layoutAuthenticationAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
LayoutAuthenticationRecord._isAnonymousRecord = true;
LayoutAuthenticationRecord.UniqueId = "869df46d-3689-3c76-e858-5c92b97145b5";
LayoutAuthenticationRecord.init();
return LayoutAuthenticationRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.LayoutAuthenticationRecord = LayoutAuthenticationRecord;

});
define("ShopperPortalEU.model$GetCardsResponseRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU.model", "ShopperPortalEU_Shopper_IS.model$GetCardsResponseRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var GetCardsResponseRecord = (function (_super) {
__extends(GetCardsResponseRecord, _super);
function GetCardsResponseRecord(defaults) {
_super.apply(this, arguments);
}
GetCardsResponseRecord.attributesToDeclare = function () {
return [
this.attr("GetCardsResponse", "getCardsResponseAttr", "GetCardsResponse", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Shopper_ISModel.GetCardsResponseRec());
}, true, ShopperPortalEU_Shopper_ISModel.GetCardsResponseRec)
].concat(_super.attributesToDeclare.call(this));
};
GetCardsResponseRecord.fromStructure = function (str) {
return new GetCardsResponseRecord(new GetCardsResponseRecord.RecordClass({
getCardsResponseAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
GetCardsResponseRecord._isAnonymousRecord = true;
GetCardsResponseRecord.UniqueId = "c5ad02da-ae50-7a50-e338-796338df6661";
GetCardsResponseRecord.init();
return GetCardsResponseRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.GetCardsResponseRecord = GetCardsResponseRecord;

});
define("ShopperPortalEU.model$GetCardsResponseRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$GetCardsResponseRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var GetCardsResponseRecordList = (function (_super) {
__extends(GetCardsResponseRecordList, _super);
function GetCardsResponseRecordList(defaults) {
_super.apply(this, arguments);
}
GetCardsResponseRecordList.itemType = ShopperPortalEUModel.GetCardsResponseRecord;
return GetCardsResponseRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.GetCardsResponseRecordList = GetCardsResponseRecordList;

});
define("ShopperPortalEU.model$CompleteDetails_AddressRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CompleteDetails_AddressRec"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CompleteDetails_AddressRecord = (function (_super) {
__extends(CompleteDetails_AddressRecord, _super);
function CompleteDetails_AddressRecord(defaults) {
_super.apply(this, arguments);
}
CompleteDetails_AddressRecord.attributesToDeclare = function () {
return [
this.attr("CompleteDetails_Address", "completeDetails_AddressAttr", "CompleteDetails_Address", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEUModel.CompleteDetails_AddressRec());
}, true, ShopperPortalEUModel.CompleteDetails_AddressRec)
].concat(_super.attributesToDeclare.call(this));
};
CompleteDetails_AddressRecord.fromStructure = function (str) {
return new CompleteDetails_AddressRecord(new CompleteDetails_AddressRecord.RecordClass({
completeDetails_AddressAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CompleteDetails_AddressRecord._isAnonymousRecord = true;
CompleteDetails_AddressRecord.UniqueId = "89303f11-54e5-3cb4-2b4b-1188cbc3901d";
CompleteDetails_AddressRecord.init();
return CompleteDetails_AddressRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CompleteDetails_AddressRecord = CompleteDetails_AddressRecord;

});
define("ShopperPortalEU.model$CircleIconOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CircleIconOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CircleIconOptionsList = (function (_super) {
__extends(CircleIconOptionsList, _super);
function CircleIconOptionsList(defaults) {
_super.apply(this, arguments);
}
CircleIconOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CircleIconOptionsRec;
return CircleIconOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CircleIconOptionsList = CircleIconOptionsList;

});
define("ShopperPortalEU.model$CustomValidationMessageStateList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomValidationMessageStateRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomValidationMessageStateList = (function (_super) {
__extends(CustomValidationMessageStateList, _super);
function CustomValidationMessageStateList(defaults) {
_super.apply(this, arguments);
}
CustomValidationMessageStateList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomValidationMessageStateRec;
return CustomValidationMessageStateList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomValidationMessageStateList = CustomValidationMessageStateList;

});
define("ShopperPortalEU.model$CreateCardRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CreateCardRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CreateCardRecordList = (function (_super) {
__extends(CreateCardRecordList, _super);
function CreateCardRecordList(defaults) {
_super.apply(this, arguments);
}
CreateCardRecordList.itemType = ShopperPortalEUModel.CreateCardRecord;
return CreateCardRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CreateCardRecordList = CreateCardRecordList;

});
define("ShopperPortalEU.model$CustomFlagOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomFlagOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomFlagOptionsList = (function (_super) {
__extends(CustomFlagOptionsList, _super);
function CustomFlagOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomFlagOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomFlagOptionsRec;
return CustomFlagOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomFlagOptionsList = CustomFlagOptionsList;

});
define("ShopperPortalEU.model$DatatransCardChangeOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$DatatransCardChangeOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var DatatransCardChangeOptionsRecordList = (function (_super) {
__extends(DatatransCardChangeOptionsRecordList, _super);
function DatatransCardChangeOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
DatatransCardChangeOptionsRecordList.itemType = ShopperPortalEUModel.DatatransCardChangeOptionsRecord;
return DatatransCardChangeOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.DatatransCardChangeOptionsRecordList = DatatransCardChangeOptionsRecordList;

});
define("ShopperPortalEU.model$CustomAlertTypeList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomAlertTypeRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomAlertTypeList = (function (_super) {
__extends(CustomAlertTypeList, _super);
function CustomAlertTypeList(defaults) {
_super.apply(this, arguments);
}
CustomAlertTypeList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomAlertTypeRec;
return CustomAlertTypeList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomAlertTypeList = CustomAlertTypeList;

});
define("ShopperPortalEU.model$FullHeightContentAlignmentRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$FullHeightContentAlignmentRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var FullHeightContentAlignmentRecord = (function (_super) {
__extends(FullHeightContentAlignmentRecord, _super);
function FullHeightContentAlignmentRecord(defaults) {
_super.apply(this, arguments);
}
FullHeightContentAlignmentRecord.attributesToDeclare = function () {
return [
this.attr("FullHeightContentAlignment", "fullHeightContentAlignmentAttr", "FullHeightContentAlignment", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.FullHeightContentAlignmentRec());
}, true, ShopperPortalEU_UI_ComponentsModel.FullHeightContentAlignmentRec)
].concat(_super.attributesToDeclare.call(this));
};
FullHeightContentAlignmentRecord.fromStructure = function (str) {
return new FullHeightContentAlignmentRecord(new FullHeightContentAlignmentRecord.RecordClass({
fullHeightContentAlignmentAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
FullHeightContentAlignmentRecord._isAnonymousRecord = true;
FullHeightContentAlignmentRecord.UniqueId = "e56e5290-74cb-5b14-23b8-47bb4e6088ee";
FullHeightContentAlignmentRecord.init();
return FullHeightContentAlignmentRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.FullHeightContentAlignmentRecord = FullHeightContentAlignmentRecord;

});
define("ShopperPortalEU.model$FullHeightContentAlignmentRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$FullHeightContentAlignmentRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var FullHeightContentAlignmentRecordList = (function (_super) {
__extends(FullHeightContentAlignmentRecordList, _super);
function FullHeightContentAlignmentRecordList(defaults) {
_super.apply(this, arguments);
}
FullHeightContentAlignmentRecordList.itemType = ShopperPortalEUModel.FullHeightContentAlignmentRecord;
return FullHeightContentAlignmentRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.FullHeightContentAlignmentRecordList = FullHeightContentAlignmentRecordList;

});
define("ShopperPortalEU.model$GetCardsResponseList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU.model", "ShopperPortalEU_Shopper_IS.model$GetCardsResponseRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var GetCardsResponseList = (function (_super) {
__extends(GetCardsResponseList, _super);
function GetCardsResponseList(defaults) {
_super.apply(this, arguments);
}
GetCardsResponseList.itemType = ShopperPortalEU_Shopper_ISModel.GetCardsResponseRec;
return GetCardsResponseList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.GetCardsResponseList = GetCardsResponseList;

});
define("ShopperPortalEU.model$AnonymousFormAddRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU.model", "ShopperPortalEU_Forms_IS.model$AnonymousFormAddRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Forms_IS"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var AnonymousFormAddRecord = (function (_super) {
__extends(AnonymousFormAddRecord, _super);
function AnonymousFormAddRecord(defaults) {
_super.apply(this, arguments);
}
AnonymousFormAddRecord.attributesToDeclare = function () {
return [
this.attr("AnonymousFormAdd", "anonymousFormAddAttr", "AnonymousFormAdd", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Forms_ISModel.AnonymousFormAddRec());
}, true, ShopperPortalEU_Forms_ISModel.AnonymousFormAddRec)
].concat(_super.attributesToDeclare.call(this));
};
AnonymousFormAddRecord.fromStructure = function (str) {
return new AnonymousFormAddRecord(new AnonymousFormAddRecord.RecordClass({
anonymousFormAddAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
AnonymousFormAddRecord._isAnonymousRecord = true;
AnonymousFormAddRecord.UniqueId = "d4e5474c-164d-48e5-8804-bce0ae9093e0";
AnonymousFormAddRecord.init();
return AnonymousFormAddRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.AnonymousFormAddRecord = AnonymousFormAddRecord;

});
define("ShopperPortalEU.model$AnonymousFormAddRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$AnonymousFormAddRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var AnonymousFormAddRecordList = (function (_super) {
__extends(AnonymousFormAddRecordList, _super);
function AnonymousFormAddRecordList(defaults) {
_super.apply(this, arguments);
}
AnonymousFormAddRecordList.itemType = ShopperPortalEUModel.AnonymousFormAddRecord;
return AnonymousFormAddRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.AnonymousFormAddRecordList = AnonymousFormAddRecordList;

});
define("ShopperPortalEU.model$CustomLinkOptionsIconRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomLinkOptionsIconRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomLinkOptionsIconRecordList = (function (_super) {
__extends(CustomLinkOptionsIconRecordList, _super);
function CustomLinkOptionsIconRecordList(defaults) {
_super.apply(this, arguments);
}
CustomLinkOptionsIconRecordList.itemType = ShopperPortalEUModel.CustomLinkOptionsIconRecord;
return CustomLinkOptionsIconRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomLinkOptionsIconRecordList = CustomLinkOptionsIconRecordList;

});
define("ShopperPortalEU.model$CustomButtonOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomButtonOptionsRecord = (function (_super) {
__extends(CustomButtonOptionsRecord, _super);
function CustomButtonOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomButtonOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomButtonOptions", "customButtonOptionsAttr", "CustomButtonOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomButtonOptionsRecord.fromStructure = function (str) {
return new CustomButtonOptionsRecord(new CustomButtonOptionsRecord.RecordClass({
customButtonOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomButtonOptionsRecord._isAnonymousRecord = true;
CustomButtonOptionsRecord.UniqueId = "c1c71989-9f61-b71a-d94b-f45b523c7551";
CustomButtonOptionsRecord.init();
return CustomButtonOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomButtonOptionsRecord = CustomButtonOptionsRecord;

});
define("ShopperPortalEU.model$CustomButtonOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomButtonOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomButtonOptionsRecordList = (function (_super) {
__extends(CustomButtonOptionsRecordList, _super);
function CustomButtonOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomButtonOptionsRecordList.itemType = ShopperPortalEUModel.CustomButtonOptionsRecord;
return CustomButtonOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomButtonOptionsRecordList = CustomButtonOptionsRecordList;

});
define("ShopperPortalEU.model$CompleteDetailsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CompleteDetailsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CompleteDetailsRecordList = (function (_super) {
__extends(CompleteDetailsRecordList, _super);
function CompleteDetailsRecordList(defaults) {
_super.apply(this, arguments);
}
CompleteDetailsRecordList.itemType = ShopperPortalEUModel.CompleteDetailsRecord;
return CompleteDetailsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CompleteDetailsRecordList = CompleteDetailsRecordList;

});
define("ShopperPortalEU.model$RequestRefundCardList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$RequestRefundCardRec"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var RequestRefundCardList = (function (_super) {
__extends(RequestRefundCardList, _super);
function RequestRefundCardList(defaults) {
_super.apply(this, arguments);
}
RequestRefundCardList.itemType = ShopperPortalEUModel.RequestRefundCardRec;
return RequestRefundCardList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.RequestRefundCardList = RequestRefundCardList;

});
define("ShopperPortalEU.model$CircleIconSizeList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CircleIconSizeRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CircleIconSizeList = (function (_super) {
__extends(CircleIconSizeList, _super);
function CircleIconSizeList(defaults) {
_super.apply(this, arguments);
}
CircleIconSizeList.itemType = ShopperPortalEU_UI_ComponentsModel.CircleIconSizeRec;
return CircleIconSizeList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CircleIconSizeList = CircleIconSizeList;

});
define("ShopperPortalEU.model$CustomCardOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomCardOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomCardOptionsList = (function (_super) {
__extends(CustomCardOptionsList, _super);
function CustomCardOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomCardOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomCardOptionsRec;
return CustomCardOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomCardOptionsList = CustomCardOptionsList;

});
define("ShopperPortalEU.model$RecaptchaThemeRecord", ["exports", "OutSystems/ClientRuntime/Main", "reCAPTCHAReact.model", "ShopperPortalEU.model", "reCAPTCHAReact.model$RecaptchaThemeRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$reCAPTCHAReact"], function (exports, OutSystems, reCAPTCHAReactModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var RecaptchaThemeRecord = (function (_super) {
__extends(RecaptchaThemeRecord, _super);
function RecaptchaThemeRecord(defaults) {
_super.apply(this, arguments);
}
RecaptchaThemeRecord.attributesToDeclare = function () {
return [
this.attr("RecaptchaTheme", "recaptchaThemeAttr", "RecaptchaTheme", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new reCAPTCHAReactModel.RecaptchaThemeRec());
}, true, reCAPTCHAReactModel.RecaptchaThemeRec)
].concat(_super.attributesToDeclare.call(this));
};
RecaptchaThemeRecord.fromStructure = function (str) {
return new RecaptchaThemeRecord(new RecaptchaThemeRecord.RecordClass({
recaptchaThemeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
RecaptchaThemeRecord._isAnonymousRecord = true;
RecaptchaThemeRecord.UniqueId = "9170a0d1-87d2-521b-b928-aeecab9c72d1";
RecaptchaThemeRecord.init();
return RecaptchaThemeRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.RecaptchaThemeRecord = RecaptchaThemeRecord;

});
define("ShopperPortalEU.model$CustomCheckboxOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomCheckboxOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomCheckboxOptionsList = (function (_super) {
__extends(CustomCheckboxOptionsList, _super);
function CustomCheckboxOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomCheckboxOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomCheckboxOptionsRec;
return CustomCheckboxOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomCheckboxOptionsList = CustomCheckboxOptionsList;

});
define("ShopperPortalEU.model$CustomListItemOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomListItemOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomListItemOptionsRecordList = (function (_super) {
__extends(CustomListItemOptionsRecordList, _super);
function CustomListItemOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomListItemOptionsRecordList.itemType = ShopperPortalEUModel.CustomListItemOptionsRecord;
return CustomListItemOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomListItemOptionsRecordList = CustomListItemOptionsRecordList;

});
define("ShopperPortalEU.model$CustomAlertIconOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomAlertIconOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomAlertIconOptionsList = (function (_super) {
__extends(CustomAlertIconOptionsList, _super);
function CustomAlertIconOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomAlertIconOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomAlertIconOptionsRec;
return CustomAlertIconOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomAlertIconOptionsList = CustomAlertIconOptionsList;

});
define("ShopperPortalEU.model$CustomOfficeInfo_WrapperRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomOfficeInfo_WrapperRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomOfficeInfo_WrapperRecordList = (function (_super) {
__extends(CustomOfficeInfo_WrapperRecordList, _super);
function CustomOfficeInfo_WrapperRecordList(defaults) {
_super.apply(this, arguments);
}
CustomOfficeInfo_WrapperRecordList.itemType = ShopperPortalEUModel.CustomOfficeInfo_WrapperRecord;
return CustomOfficeInfo_WrapperRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomOfficeInfo_WrapperRecordList = CustomOfficeInfo_WrapperRecordList;

});
define("ShopperPortalEU.model$CompleteDetails_PersonalDetailsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CompleteDetails_PersonalDetailsRec"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CompleteDetails_PersonalDetailsList = (function (_super) {
__extends(CompleteDetails_PersonalDetailsList, _super);
function CompleteDetails_PersonalDetailsList(defaults) {
_super.apply(this, arguments);
}
CompleteDetails_PersonalDetailsList.itemType = ShopperPortalEUModel.CompleteDetails_PersonalDetailsRec;
return CompleteDetails_PersonalDetailsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CompleteDetails_PersonalDetailsList = CompleteDetails_PersonalDetailsList;

});
define("ShopperPortalEU.model$CustomCarouselOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomCarouselOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomCarouselOptionsRecordList = (function (_super) {
__extends(CustomCarouselOptionsRecordList, _super);
function CustomCarouselOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomCarouselOptionsRecordList.itemType = ShopperPortalEUModel.CustomCarouselOptionsRecord;
return CustomCarouselOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomCarouselOptionsRecordList = CustomCarouselOptionsRecordList;

});
define("ShopperPortalEU.model$AccessInfoRecord", ["exports", "OutSystems/ClientRuntime/Main", "Auth_Europe.model", "ShopperPortalEU.model", "Auth_Europe.model$AccessInfoRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$Auth_Europe"], function (exports, OutSystems, Auth_EuropeModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var AccessInfoRecord = (function (_super) {
__extends(AccessInfoRecord, _super);
function AccessInfoRecord(defaults) {
_super.apply(this, arguments);
}
AccessInfoRecord.attributesToDeclare = function () {
return [
this.attr("AccessInfo", "accessInfoAttr", "AccessInfo", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new Auth_EuropeModel.AccessInfoRec());
}, true, Auth_EuropeModel.AccessInfoRec)
].concat(_super.attributesToDeclare.call(this));
};
AccessInfoRecord.fromStructure = function (str) {
return new AccessInfoRecord(new AccessInfoRecord.RecordClass({
accessInfoAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
AccessInfoRecord._isAnonymousRecord = true;
AccessInfoRecord.UniqueId = "9683fe1d-cb74-0ed6-b719-506d17b99a3f";
AccessInfoRecord.init();
return AccessInfoRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.AccessInfoRecord = AccessInfoRecord;

});
define("ShopperPortalEU.model$CustomButtonItemOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomButtonItemOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomButtonItemOptionsRecordList = (function (_super) {
__extends(CustomButtonItemOptionsRecordList, _super);
function CustomButtonItemOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomButtonItemOptionsRecordList.itemType = ShopperPortalEUModel.CustomButtonItemOptionsRecord;
return CustomButtonItemOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomButtonItemOptionsRecordList = CustomButtonItemOptionsRecordList;

});
define("ShopperPortalEU.model$SPFormStatusList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_CS.model", "ShopperPortalEU.model", "ShopperPortalEU_CS.model$SPFormStatusRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_CS"], function (exports, OutSystems, ShopperPortalEU_CSModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var SPFormStatusList = (function (_super) {
__extends(SPFormStatusList, _super);
function SPFormStatusList(defaults) {
_super.apply(this, arguments);
}
SPFormStatusList.itemType = ShopperPortalEU_CSModel.SPFormStatusRec;
return SPFormStatusList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.SPFormStatusList = SPFormStatusList;

});
define("ShopperPortalEU.model$CustomPopupLayoutHeaderImageOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomPopupLayoutHeaderImageOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomPopupLayoutHeaderImageOptionsList = (function (_super) {
__extends(CustomPopupLayoutHeaderImageOptionsList, _super);
function CustomPopupLayoutHeaderImageOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomPopupLayoutHeaderImageOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomPopupLayoutHeaderImageOptionsRec;
return CustomPopupLayoutHeaderImageOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomPopupLayoutHeaderImageOptionsList = CustomPopupLayoutHeaderImageOptionsList;

});
define("ShopperPortalEU.model$LayoutBlankOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Theme.model$LayoutBlankOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var LayoutBlankOptionsRecord = (function (_super) {
__extends(LayoutBlankOptionsRecord, _super);
function LayoutBlankOptionsRecord(defaults) {
_super.apply(this, arguments);
}
LayoutBlankOptionsRecord.attributesToDeclare = function () {
return [
this.attr("LayoutBlankOptions", "layoutBlankOptionsAttr", "LayoutBlankOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ThemeModel.LayoutBlankOptionsRec());
}, true, ShopperPortalEU_UI_ThemeModel.LayoutBlankOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
LayoutBlankOptionsRecord.fromStructure = function (str) {
return new LayoutBlankOptionsRecord(new LayoutBlankOptionsRecord.RecordClass({
layoutBlankOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
LayoutBlankOptionsRecord._isAnonymousRecord = true;
LayoutBlankOptionsRecord.UniqueId = "e3cec805-0d7a-87aa-4836-19b3dbee0ec0";
LayoutBlankOptionsRecord.init();
return LayoutBlankOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.LayoutBlankOptionsRecord = LayoutBlankOptionsRecord;

});
define("ShopperPortalEU.model$LayoutBlankOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$LayoutBlankOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var LayoutBlankOptionsRecordList = (function (_super) {
__extends(LayoutBlankOptionsRecordList, _super);
function LayoutBlankOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
LayoutBlankOptionsRecordList.itemType = ShopperPortalEUModel.LayoutBlankOptionsRecord;
return LayoutBlankOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.LayoutBlankOptionsRecordList = LayoutBlankOptionsRecordList;

});
define("ShopperPortalEU.model$CustomDropdownListItemOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomDropdownListItemOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomDropdownListItemOptionsList = (function (_super) {
__extends(CustomDropdownListItemOptionsList, _super);
function CustomDropdownListItemOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownListItemOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomDropdownListItemOptionsRec;
return CustomDropdownListItemOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomDropdownListItemOptionsList = CustomDropdownListItemOptionsList;

});
define("ShopperPortalEU.model$ScanPassportDataList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$ScanPassportDataRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var ScanPassportDataList = (function (_super) {
__extends(ScanPassportDataList, _super);
function ScanPassportDataList(defaults) {
_super.apply(this, arguments);
}
ScanPassportDataList.itemType = ShopperPortalEU_UI_ComponentsModel.ScanPassportDataRec;
return ScanPassportDataList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.ScanPassportDataList = ScanPassportDataList;

});
define("ShopperPortalEU.model$CustomLinkStateRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomLinkStateRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomLinkStateRecord = (function (_super) {
__extends(CustomLinkStateRecord, _super);
function CustomLinkStateRecord(defaults) {
_super.apply(this, arguments);
}
CustomLinkStateRecord.attributesToDeclare = function () {
return [
this.attr("CustomLinkState", "customLinkStateAttr", "CustomLinkState", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomLinkStateRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomLinkStateRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomLinkStateRecord.fromStructure = function (str) {
return new CustomLinkStateRecord(new CustomLinkStateRecord.RecordClass({
customLinkStateAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomLinkStateRecord._isAnonymousRecord = true;
CustomLinkStateRecord.UniqueId = "99b25a68-e71f-c7ab-86b5-bb8b521dee5b";
CustomLinkStateRecord.init();
return CustomLinkStateRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomLinkStateRecord = CustomLinkStateRecord;

});
define("ShopperPortalEU.model$CustomInputOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomInputOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomInputOptionsList = (function (_super) {
__extends(CustomInputOptionsList, _super);
function CustomInputOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomInputOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomInputOptionsRec;
return CustomInputOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomInputOptionsList = CustomInputOptionsList;

});
define("ShopperPortalEU.model$MenuOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Theme.model$MenuOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var MenuOptionsRecord = (function (_super) {
__extends(MenuOptionsRecord, _super);
function MenuOptionsRecord(defaults) {
_super.apply(this, arguments);
}
MenuOptionsRecord.attributesToDeclare = function () {
return [
this.attr("MenuOptions", "menuOptionsAttr", "MenuOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ThemeModel.MenuOptionsRec());
}, true, ShopperPortalEU_UI_ThemeModel.MenuOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
MenuOptionsRecord.fromStructure = function (str) {
return new MenuOptionsRecord(new MenuOptionsRecord.RecordClass({
menuOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
MenuOptionsRecord._isAnonymousRecord = true;
MenuOptionsRecord.UniqueId = "9ac651f3-b159-6d35-fe55-fea78c049573";
MenuOptionsRecord.init();
return MenuOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.MenuOptionsRecord = MenuOptionsRecord;

});
define("ShopperPortalEU.model$RefundPoint_WrapperList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_API.model", "ShopperPortalEU.model", "ShopperPortalEU_API.model$RefundPoint_WrapperRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_API"], function (exports, OutSystems, ShopperPortalEU_APIModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var RefundPoint_WrapperList = (function (_super) {
__extends(RefundPoint_WrapperList, _super);
function RefundPoint_WrapperList(defaults) {
_super.apply(this, arguments);
}
RefundPoint_WrapperList.itemType = ShopperPortalEU_APIModel.RefundPoint_WrapperRec;
return RefundPoint_WrapperList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.RefundPoint_WrapperList = RefundPoint_WrapperList;

});
define("ShopperPortalEU.model$BannerTypeRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Theme.model$BannerTypeRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var BannerTypeRecord = (function (_super) {
__extends(BannerTypeRecord, _super);
function BannerTypeRecord(defaults) {
_super.apply(this, arguments);
}
BannerTypeRecord.attributesToDeclare = function () {
return [
this.attr("BannerType", "bannerTypeAttr", "BannerType", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ThemeModel.BannerTypeRec());
}, true, ShopperPortalEU_UI_ThemeModel.BannerTypeRec)
].concat(_super.attributesToDeclare.call(this));
};
BannerTypeRecord.fromStructure = function (str) {
return new BannerTypeRecord(new BannerTypeRecord.RecordClass({
bannerTypeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
BannerTypeRecord._isAnonymousRecord = true;
BannerTypeRecord.UniqueId = "9e3dd88d-5f7f-2294-5932-a99d460591e7";
BannerTypeRecord.init();
return BannerTypeRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.BannerTypeRecord = BannerTypeRecord;

});
define("ShopperPortalEU.model$CustomIconFamilyRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomIconFamilyRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomIconFamilyRecord = (function (_super) {
__extends(CustomIconFamilyRecord, _super);
function CustomIconFamilyRecord(defaults) {
_super.apply(this, arguments);
}
CustomIconFamilyRecord.attributesToDeclare = function () {
return [
this.attr("CustomIconFamily", "customIconFamilyAttr", "CustomIconFamily", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomIconFamilyRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomIconFamilyRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomIconFamilyRecord.fromStructure = function (str) {
return new CustomIconFamilyRecord(new CustomIconFamilyRecord.RecordClass({
customIconFamilyAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomIconFamilyRecord._isAnonymousRecord = true;
CustomIconFamilyRecord.UniqueId = "9fc51a4a-fa2f-d647-1909-b8f8c0bf9224";
CustomIconFamilyRecord.init();
return CustomIconFamilyRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomIconFamilyRecord = CustomIconFamilyRecord;

});
define("ShopperPortalEU.model$LayoutAuthenticationRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$LayoutAuthenticationRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var LayoutAuthenticationRecordList = (function (_super) {
__extends(LayoutAuthenticationRecordList, _super);
function LayoutAuthenticationRecordList(defaults) {
_super.apply(this, arguments);
}
LayoutAuthenticationRecordList.itemType = ShopperPortalEUModel.LayoutAuthenticationRecord;
return LayoutAuthenticationRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.LayoutAuthenticationRecordList = LayoutAuthenticationRecordList;

});
define("ShopperPortalEU.model$CustomCheckboxOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomCheckboxOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomCheckboxOptionsRecordList = (function (_super) {
__extends(CustomCheckboxOptionsRecordList, _super);
function CustomCheckboxOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomCheckboxOptionsRecordList.itemType = ShopperPortalEUModel.CustomCheckboxOptionsRecord;
return CustomCheckboxOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomCheckboxOptionsRecordList = CustomCheckboxOptionsRecordList;

});
define("ShopperPortalEU.model$MenuOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$MenuOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var MenuOptionsRecordList = (function (_super) {
__extends(MenuOptionsRecordList, _super);
function MenuOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
MenuOptionsRecordList.itemType = ShopperPortalEUModel.MenuOptionsRecord;
return MenuOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.MenuOptionsRecordList = MenuOptionsRecordList;

});
define("ShopperPortalEU.model$CustomBottomBarOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomBottomBarOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomBottomBarOptionsList = (function (_super) {
__extends(CustomBottomBarOptionsList, _super);
function CustomBottomBarOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomBottomBarOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomBottomBarOptionsRec;
return CustomBottomBarOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomBottomBarOptionsList = CustomBottomBarOptionsList;

});
define("ShopperPortalEU.model$CustomSeparatorOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomSeparatorOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomSeparatorOptionsList = (function (_super) {
__extends(CustomSeparatorOptionsList, _super);
function CustomSeparatorOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomSeparatorOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomSeparatorOptionsRec;
return CustomSeparatorOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomSeparatorOptionsList = CustomSeparatorOptionsList;

});
define("ShopperPortalEU.model$MenuItemOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Theme.model$MenuItemOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var MenuItemOptionsRecord = (function (_super) {
__extends(MenuItemOptionsRecord, _super);
function MenuItemOptionsRecord(defaults) {
_super.apply(this, arguments);
}
MenuItemOptionsRecord.attributesToDeclare = function () {
return [
this.attr("MenuItemOptions", "menuItemOptionsAttr", "MenuItemOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ThemeModel.MenuItemOptionsRec());
}, true, ShopperPortalEU_UI_ThemeModel.MenuItemOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
MenuItemOptionsRecord.fromStructure = function (str) {
return new MenuItemOptionsRecord(new MenuItemOptionsRecord.RecordClass({
menuItemOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
MenuItemOptionsRecord._isAnonymousRecord = true;
MenuItemOptionsRecord.UniqueId = "a3beaa49-0ffd-95c4-b342-a6c98a67cc67";
MenuItemOptionsRecord.init();
return MenuItemOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.MenuItemOptionsRecord = MenuItemOptionsRecord;

});
define("ShopperPortalEU.model$FullHeightContentTopOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$FullHeightContentTopOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var FullHeightContentTopOptionsList = (function (_super) {
__extends(FullHeightContentTopOptionsList, _super);
function FullHeightContentTopOptionsList(defaults) {
_super.apply(this, arguments);
}
FullHeightContentTopOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.FullHeightContentTopOptionsRec;
return FullHeightContentTopOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.FullHeightContentTopOptionsList = FullHeightContentTopOptionsList;

});
define("ShopperPortalEU.model$CustomDropdownListValueOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomDropdownListValueOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomDropdownListValueOptionsRecord = (function (_super) {
__extends(CustomDropdownListValueOptionsRecord, _super);
function CustomDropdownListValueOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomDropdownListValueOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomDropdownListValueOptions", "customDropdownListValueOptionsAttr", "CustomDropdownListValueOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValueOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValueOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomDropdownListValueOptionsRecord.fromStructure = function (str) {
return new CustomDropdownListValueOptionsRecord(new CustomDropdownListValueOptionsRecord.RecordClass({
customDropdownListValueOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomDropdownListValueOptionsRecord._isAnonymousRecord = true;
CustomDropdownListValueOptionsRecord.UniqueId = "a41ccd9a-afc7-1231-96be-c3182b0c5b18";
CustomDropdownListValueOptionsRecord.init();
return CustomDropdownListValueOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomDropdownListValueOptionsRecord = CustomDropdownListValueOptionsRecord;

});
define("ShopperPortalEU.model$MenuItemOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Theme.model$MenuItemOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var MenuItemOptionsList = (function (_super) {
__extends(MenuItemOptionsList, _super);
function MenuItemOptionsList(defaults) {
_super.apply(this, arguments);
}
MenuItemOptionsList.itemType = ShopperPortalEU_UI_ThemeModel.MenuItemOptionsRec;
return MenuItemOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.MenuItemOptionsList = MenuItemOptionsList;

});
define("ShopperPortalEU.model$CustomInputOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomInputOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomInputOptionsRecordList = (function (_super) {
__extends(CustomInputOptionsRecordList, _super);
function CustomInputOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomInputOptionsRecordList.itemType = ShopperPortalEUModel.CustomInputOptionsRecord;
return CustomInputOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomInputOptionsRecordList = CustomInputOptionsRecordList;

});
define("ShopperPortalEU.model$LabelValueOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$LabelValueOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var LabelValueOptionsRecordList = (function (_super) {
__extends(LabelValueOptionsRecordList, _super);
function LabelValueOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
LabelValueOptionsRecordList.itemType = ShopperPortalEUModel.LabelValueOptionsRecord;
return LabelValueOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.LabelValueOptionsRecordList = LabelValueOptionsRecordList;

});
define("ShopperPortalEU.model$CustomMessageIconOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Theme.model$CustomMessageIconOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomMessageIconOptionsRecord = (function (_super) {
__extends(CustomMessageIconOptionsRecord, _super);
function CustomMessageIconOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomMessageIconOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomMessageIconOptions", "customMessageIconOptionsAttr", "CustomMessageIconOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ThemeModel.CustomMessageIconOptionsRec());
}, true, ShopperPortalEU_UI_ThemeModel.CustomMessageIconOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomMessageIconOptionsRecord.fromStructure = function (str) {
return new CustomMessageIconOptionsRecord(new CustomMessageIconOptionsRecord.RecordClass({
customMessageIconOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomMessageIconOptionsRecord._isAnonymousRecord = true;
CustomMessageIconOptionsRecord.UniqueId = "c3961fb6-59d7-78de-bab0-58a3eec19a04";
CustomMessageIconOptionsRecord.init();
return CustomMessageIconOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomMessageIconOptionsRecord = CustomMessageIconOptionsRecord;

});
define("ShopperPortalEU.model$CustomMessageIconOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomMessageIconOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomMessageIconOptionsRecordList = (function (_super) {
__extends(CustomMessageIconOptionsRecordList, _super);
function CustomMessageIconOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomMessageIconOptionsRecordList.itemType = ShopperPortalEUModel.CustomMessageIconOptionsRecord;
return CustomMessageIconOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomMessageIconOptionsRecordList = CustomMessageIconOptionsRecordList;

});
define("ShopperPortalEU.model$RefundPoint_WrapperRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$RefundPoint_WrapperRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var RefundPoint_WrapperRecordList = (function (_super) {
__extends(RefundPoint_WrapperRecordList, _super);
function RefundPoint_WrapperRecordList(defaults) {
_super.apply(this, arguments);
}
RefundPoint_WrapperRecordList.itemType = ShopperPortalEUModel.RefundPoint_WrapperRecord;
return RefundPoint_WrapperRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.RefundPoint_WrapperRecordList = RefundPoint_WrapperRecordList;

});
define("ShopperPortalEU.model$ScanBarcodeDataRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$ScanBarcodeDataRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var ScanBarcodeDataRecord = (function (_super) {
__extends(ScanBarcodeDataRecord, _super);
function ScanBarcodeDataRecord(defaults) {
_super.apply(this, arguments);
}
ScanBarcodeDataRecord.attributesToDeclare = function () {
return [
this.attr("ScanBarcodeData", "scanBarcodeDataAttr", "ScanBarcodeData", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.ScanBarcodeDataRec());
}, true, ShopperPortalEU_UI_ComponentsModel.ScanBarcodeDataRec)
].concat(_super.attributesToDeclare.call(this));
};
ScanBarcodeDataRecord.fromStructure = function (str) {
return new ScanBarcodeDataRecord(new ScanBarcodeDataRecord.RecordClass({
scanBarcodeDataAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ScanBarcodeDataRecord._isAnonymousRecord = true;
ScanBarcodeDataRecord.UniqueId = "ab4e2636-7b94-c906-2ea8-ffc8bea49921";
ScanBarcodeDataRecord.init();
return ScanBarcodeDataRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.ScanBarcodeDataRecord = ScanBarcodeDataRecord;

});
define("ShopperPortalEU.model$CustomFlagOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomFlagOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomFlagOptionsRecordList = (function (_super) {
__extends(CustomFlagOptionsRecordList, _super);
function CustomFlagOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomFlagOptionsRecordList.itemType = ShopperPortalEUModel.CustomFlagOptionsRecord;
return CustomFlagOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomFlagOptionsRecordList = CustomFlagOptionsRecordList;

});
define("ShopperPortalEU.model$BottomBarItemOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Theme.model$BottomBarItemOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var BottomBarItemOptionsRecord = (function (_super) {
__extends(BottomBarItemOptionsRecord, _super);
function BottomBarItemOptionsRecord(defaults) {
_super.apply(this, arguments);
}
BottomBarItemOptionsRecord.attributesToDeclare = function () {
return [
this.attr("BottomBarItemOptions", "bottomBarItemOptionsAttr", "BottomBarItemOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ThemeModel.BottomBarItemOptionsRec());
}, true, ShopperPortalEU_UI_ThemeModel.BottomBarItemOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
BottomBarItemOptionsRecord.fromStructure = function (str) {
return new BottomBarItemOptionsRecord(new BottomBarItemOptionsRecord.RecordClass({
bottomBarItemOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
BottomBarItemOptionsRecord._isAnonymousRecord = true;
BottomBarItemOptionsRecord.UniqueId = "cd13f377-7410-e063-955f-87449f73c9e3";
BottomBarItemOptionsRecord.init();
return BottomBarItemOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.BottomBarItemOptionsRecord = BottomBarItemOptionsRecord;

});
define("ShopperPortalEU.model$BottomBarItemOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$BottomBarItemOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var BottomBarItemOptionsRecordList = (function (_super) {
__extends(BottomBarItemOptionsRecordList, _super);
function BottomBarItemOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
BottomBarItemOptionsRecordList.itemType = ShopperPortalEUModel.BottomBarItemOptionsRecord;
return BottomBarItemOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.BottomBarItemOptionsRecordList = BottomBarItemOptionsRecordList;

});
define("ShopperPortalEU.model$PhoneNumberInputCountryOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$PhoneNumberInputCountryOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var PhoneNumberInputCountryOptionsRecordList = (function (_super) {
__extends(PhoneNumberInputCountryOptionsRecordList, _super);
function PhoneNumberInputCountryOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
PhoneNumberInputCountryOptionsRecordList.itemType = ShopperPortalEUModel.PhoneNumberInputCountryOptionsRecord;
return PhoneNumberInputCountryOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.PhoneNumberInputCountryOptionsRecordList = PhoneNumberInputCountryOptionsRecordList;

});
define("ShopperPortalEU.model$CustomDropdownValidationOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomDropdownValidationOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomDropdownValidationOptionsRecordList = (function (_super) {
__extends(CustomDropdownValidationOptionsRecordList, _super);
function CustomDropdownValidationOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownValidationOptionsRecordList.itemType = ShopperPortalEUModel.CustomDropdownValidationOptionsRecord;
return CustomDropdownValidationOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomDropdownValidationOptionsRecordList = CustomDropdownValidationOptionsRecordList;

});
define("ShopperPortalEU.model$ApplicationHeaderList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$ApplicationHeaderRec"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var ApplicationHeaderList = (function (_super) {
__extends(ApplicationHeaderList, _super);
function ApplicationHeaderList(defaults) {
_super.apply(this, arguments);
}
ApplicationHeaderList.itemType = ShopperPortalEUModel.ApplicationHeaderRec;
return ApplicationHeaderList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.ApplicationHeaderList = ApplicationHeaderList;

});
define("ShopperPortalEU.model$CustomLoadingOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomLoadingOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomLoadingOptionsList = (function (_super) {
__extends(CustomLoadingOptionsList, _super);
function CustomLoadingOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomLoadingOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomLoadingOptionsRec;
return CustomLoadingOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomLoadingOptionsList = CustomLoadingOptionsList;

});
define("ShopperPortalEU.model$GetOSBrowserOptionRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$GetOSBrowserOptionRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var GetOSBrowserOptionRecord = (function (_super) {
__extends(GetOSBrowserOptionRecord, _super);
function GetOSBrowserOptionRecord(defaults) {
_super.apply(this, arguments);
}
GetOSBrowserOptionRecord.attributesToDeclare = function () {
return [
this.attr("GetOSBrowserOption", "getOSBrowserOptionAttr", "GetOSBrowserOption", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.GetOSBrowserOptionRec());
}, true, ShopperPortalEU_UI_ComponentsModel.GetOSBrowserOptionRec)
].concat(_super.attributesToDeclare.call(this));
};
GetOSBrowserOptionRecord.fromStructure = function (str) {
return new GetOSBrowserOptionRecord(new GetOSBrowserOptionRecord.RecordClass({
getOSBrowserOptionAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
GetOSBrowserOptionRecord._isAnonymousRecord = true;
GetOSBrowserOptionRecord.UniqueId = "af01889a-10cd-7c1d-318e-a99a5a90c59a";
GetOSBrowserOptionRecord.init();
return GetOSBrowserOptionRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.GetOSBrowserOptionRecord = GetOSBrowserOptionRecord;

});
define("ShopperPortalEU.model$CustomFormOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomFormOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomFormOptionsRecord = (function (_super) {
__extends(CustomFormOptionsRecord, _super);
function CustomFormOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomFormOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomFormOptions", "customFormOptionsAttr", "CustomFormOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomFormOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomFormOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomFormOptionsRecord.fromStructure = function (str) {
return new CustomFormOptionsRecord(new CustomFormOptionsRecord.RecordClass({
customFormOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomFormOptionsRecord._isAnonymousRecord = true;
CustomFormOptionsRecord.UniqueId = "c9cd1982-bef8-6871-7102-5ab6268c5317";
CustomFormOptionsRecord.init();
return CustomFormOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomFormOptionsRecord = CustomFormOptionsRecord;

});
define("ShopperPortalEU.model$CustomFormOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomFormOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomFormOptionsRecordList = (function (_super) {
__extends(CustomFormOptionsRecordList, _super);
function CustomFormOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomFormOptionsRecordList.itemType = ShopperPortalEUModel.CustomFormOptionsRecord;
return CustomFormOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomFormOptionsRecordList = CustomFormOptionsRecordList;

});
define("ShopperPortalEU.model$GetOSOptionRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$GetOSOptionRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var GetOSOptionRecordList = (function (_super) {
__extends(GetOSOptionRecordList, _super);
function GetOSOptionRecordList(defaults) {
_super.apply(this, arguments);
}
GetOSOptionRecordList.itemType = ShopperPortalEUModel.GetOSOptionRecord;
return GetOSOptionRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.GetOSOptionRecordList = GetOSOptionRecordList;

});
define("ShopperPortalEU.model$PhoneNumberInputOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$PhoneNumberInputOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var PhoneNumberInputOptionsList = (function (_super) {
__extends(PhoneNumberInputOptionsList, _super);
function PhoneNumberInputOptionsList(defaults) {
_super.apply(this, arguments);
}
PhoneNumberInputOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputOptionsRec;
return PhoneNumberInputOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.PhoneNumberInputOptionsList = PhoneNumberInputOptionsList;

});
define("ShopperPortalEU.model$DatatransCardGetCardInfoDataOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$DatatransCardGetCardInfoDataOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var DatatransCardGetCardInfoDataOptionsRecord = (function (_super) {
__extends(DatatransCardGetCardInfoDataOptionsRecord, _super);
function DatatransCardGetCardInfoDataOptionsRecord(defaults) {
_super.apply(this, arguments);
}
DatatransCardGetCardInfoDataOptionsRecord.attributesToDeclare = function () {
return [
this.attr("DatatransCardGetCardInfoDataOptions", "datatransCardGetCardInfoDataOptionsAttr", "DatatransCardGetCardInfoDataOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.DatatransCardGetCardInfoDataOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.DatatransCardGetCardInfoDataOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
DatatransCardGetCardInfoDataOptionsRecord.fromStructure = function (str) {
return new DatatransCardGetCardInfoDataOptionsRecord(new DatatransCardGetCardInfoDataOptionsRecord.RecordClass({
datatransCardGetCardInfoDataOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
DatatransCardGetCardInfoDataOptionsRecord._isAnonymousRecord = true;
DatatransCardGetCardInfoDataOptionsRecord.UniqueId = "d96bb604-5259-b7b2-4495-486306ac2958";
DatatransCardGetCardInfoDataOptionsRecord.init();
return DatatransCardGetCardInfoDataOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.DatatransCardGetCardInfoDataOptionsRecord = DatatransCardGetCardInfoDataOptionsRecord;

});
define("ShopperPortalEU.model$DatatransCardGetCardInfoDataOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$DatatransCardGetCardInfoDataOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var DatatransCardGetCardInfoDataOptionsRecordList = (function (_super) {
__extends(DatatransCardGetCardInfoDataOptionsRecordList, _super);
function DatatransCardGetCardInfoDataOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
DatatransCardGetCardInfoDataOptionsRecordList.itemType = ShopperPortalEUModel.DatatransCardGetCardInfoDataOptionsRecord;
return DatatransCardGetCardInfoDataOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.DatatransCardGetCardInfoDataOptionsRecordList = DatatransCardGetCardInfoDataOptionsRecordList;

});
define("ShopperPortalEU.model$UIConfigurationRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$UIConfigurationRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var UIConfigurationRecordList = (function (_super) {
__extends(UIConfigurationRecordList, _super);
function UIConfigurationRecordList(defaults) {
_super.apply(this, arguments);
}
UIConfigurationRecordList.itemType = ShopperPortalEUModel.UIConfigurationRecord;
return UIConfigurationRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.UIConfigurationRecordList = UIConfigurationRecordList;

});
define("ShopperPortalEU.model$RefundDetails_WrapperRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_API.model", "ShopperPortalEU.model", "ShopperPortalEU_API.model$RefundDetails_WrapperRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_API"], function (exports, OutSystems, ShopperPortalEU_APIModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var RefundDetails_WrapperRecord = (function (_super) {
__extends(RefundDetails_WrapperRecord, _super);
function RefundDetails_WrapperRecord(defaults) {
_super.apply(this, arguments);
}
RefundDetails_WrapperRecord.attributesToDeclare = function () {
return [
this.attr("RefundDetails_Wrapper", "refundDetails_WrapperAttr", "RefundDetails_Wrapper", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_APIModel.RefundDetails_WrapperRec());
}, true, ShopperPortalEU_APIModel.RefundDetails_WrapperRec)
].concat(_super.attributesToDeclare.call(this));
};
RefundDetails_WrapperRecord.fromStructure = function (str) {
return new RefundDetails_WrapperRecord(new RefundDetails_WrapperRecord.RecordClass({
refundDetails_WrapperAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
RefundDetails_WrapperRecord._isAnonymousRecord = true;
RefundDetails_WrapperRecord.UniqueId = "b280a0c9-d9e3-c34c-50e7-b2c999e3f733";
RefundDetails_WrapperRecord.init();
return RefundDetails_WrapperRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.RefundDetails_WrapperRecord = RefundDetails_WrapperRecord;

});
define("ShopperPortalEU.model$CompleteDetailsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CompleteDetailsRec"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CompleteDetailsList = (function (_super) {
__extends(CompleteDetailsList, _super);
function CompleteDetailsList(defaults) {
_super.apply(this, arguments);
}
CompleteDetailsList.itemType = ShopperPortalEUModel.CompleteDetailsRec;
return CompleteDetailsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CompleteDetailsList = CompleteDetailsList;

});
define("ShopperPortalEU.model$CustomIconFamilyRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomIconFamilyRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomIconFamilyRecordList = (function (_super) {
__extends(CustomIconFamilyRecordList, _super);
function CustomIconFamilyRecordList(defaults) {
_super.apply(this, arguments);
}
CustomIconFamilyRecordList.itemType = ShopperPortalEUModel.CustomIconFamilyRecord;
return CustomIconFamilyRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomIconFamilyRecordList = CustomIconFamilyRecordList;

});
define("ShopperPortalEU.model$CustomDropdownListValidationOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomDropdownListValidationOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomDropdownListValidationOptionsRecordList = (function (_super) {
__extends(CustomDropdownListValidationOptionsRecordList, _super);
function CustomDropdownListValidationOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownListValidationOptionsRecordList.itemType = ShopperPortalEUModel.CustomDropdownListValidationOptionsRecord;
return CustomDropdownListValidationOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomDropdownListValidationOptionsRecordList = CustomDropdownListValidationOptionsRecordList;

});
define("ShopperPortalEU.model$FullHeightContentBottomOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$FullHeightContentBottomOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var FullHeightContentBottomOptionsRecordList = (function (_super) {
__extends(FullHeightContentBottomOptionsRecordList, _super);
function FullHeightContentBottomOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
FullHeightContentBottomOptionsRecordList.itemType = ShopperPortalEUModel.FullHeightContentBottomOptionsRecord;
return FullHeightContentBottomOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.FullHeightContentBottomOptionsRecordList = FullHeightContentBottomOptionsRecordList;

});
define("ShopperPortalEU.model$CustomDropdownListOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomDropdownListOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomDropdownListOptionsList = (function (_super) {
__extends(CustomDropdownListOptionsList, _super);
function CustomDropdownListOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownListOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomDropdownListOptionsRec;
return CustomDropdownListOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomDropdownListOptionsList = CustomDropdownListOptionsList;

});
define("ShopperPortalEU.model$CustomSeparatorLabelOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomSeparatorLabelOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomSeparatorLabelOptionsList = (function (_super) {
__extends(CustomSeparatorLabelOptionsList, _super);
function CustomSeparatorLabelOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomSeparatorLabelOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomSeparatorLabelOptionsRec;
return CustomSeparatorLabelOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomSeparatorLabelOptionsList = CustomSeparatorLabelOptionsList;

});
define("ShopperPortalEU.model$PhoneNumberInputCountryOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$PhoneNumberInputCountryOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var PhoneNumberInputCountryOptionsList = (function (_super) {
__extends(PhoneNumberInputCountryOptionsList, _super);
function PhoneNumberInputCountryOptionsList(defaults) {
_super.apply(this, arguments);
}
PhoneNumberInputCountryOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputCountryOptionsRec;
return PhoneNumberInputCountryOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.PhoneNumberInputCountryOptionsList = PhoneNumberInputCountryOptionsList;

});
define("ShopperPortalEU.model$CompleteDetails_ContactRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CompleteDetails_ContactRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CompleteDetails_ContactRecordList = (function (_super) {
__extends(CompleteDetails_ContactRecordList, _super);
function CompleteDetails_ContactRecordList(defaults) {
_super.apply(this, arguments);
}
CompleteDetails_ContactRecordList.itemType = ShopperPortalEUModel.CompleteDetails_ContactRecord;
return CompleteDetails_ContactRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CompleteDetails_ContactRecordList = CompleteDetails_ContactRecordList;

});
define("ShopperPortalEU.model$CustomLinkIconAlignmentList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomLinkIconAlignmentRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomLinkIconAlignmentList = (function (_super) {
__extends(CustomLinkIconAlignmentList, _super);
function CustomLinkIconAlignmentList(defaults) {
_super.apply(this, arguments);
}
CustomLinkIconAlignmentList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomLinkIconAlignmentRec;
return CustomLinkIconAlignmentList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomLinkIconAlignmentList = CustomLinkIconAlignmentList;

});
define("ShopperPortalEU.model$PostSiteverifyResponseList", ["exports", "OutSystems/ClientRuntime/Main", "reCAPTCHAReact.model", "ShopperPortalEU.model", "reCAPTCHAReact.model$PostSiteverifyResponseRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$reCAPTCHAReact"], function (exports, OutSystems, reCAPTCHAReactModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var PostSiteverifyResponseList = (function (_super) {
__extends(PostSiteverifyResponseList, _super);
function PostSiteverifyResponseList(defaults) {
_super.apply(this, arguments);
}
PostSiteverifyResponseList.itemType = reCAPTCHAReactModel.PostSiteverifyResponseRec;
return PostSiteverifyResponseList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.PostSiteverifyResponseList = PostSiteverifyResponseList;

});
define("ShopperPortalEU.model$CustomButtonIconAlignmentRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomButtonIconAlignmentRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomButtonIconAlignmentRecord = (function (_super) {
__extends(CustomButtonIconAlignmentRecord, _super);
function CustomButtonIconAlignmentRecord(defaults) {
_super.apply(this, arguments);
}
CustomButtonIconAlignmentRecord.attributesToDeclare = function () {
return [
this.attr("CustomButtonIconAlignment", "customButtonIconAlignmentAttr", "CustomButtonIconAlignment", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomButtonIconAlignmentRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomButtonIconAlignmentRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomButtonIconAlignmentRecord.fromStructure = function (str) {
return new CustomButtonIconAlignmentRecord(new CustomButtonIconAlignmentRecord.RecordClass({
customButtonIconAlignmentAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomButtonIconAlignmentRecord._isAnonymousRecord = true;
CustomButtonIconAlignmentRecord.UniqueId = "b6c89ce1-fc47-84f4-dab1-55a9efea3489";
CustomButtonIconAlignmentRecord.init();
return CustomButtonIconAlignmentRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomButtonIconAlignmentRecord = CustomButtonIconAlignmentRecord;

});
define("ShopperPortalEU.model$CustomLoadingOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomLoadingOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomLoadingOptionsRecord = (function (_super) {
__extends(CustomLoadingOptionsRecord, _super);
function CustomLoadingOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomLoadingOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomLoadingOptions", "customLoadingOptionsAttr", "CustomLoadingOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomLoadingOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomLoadingOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomLoadingOptionsRecord.fromStructure = function (str) {
return new CustomLoadingOptionsRecord(new CustomLoadingOptionsRecord.RecordClass({
customLoadingOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomLoadingOptionsRecord._isAnonymousRecord = true;
CustomLoadingOptionsRecord.UniqueId = "ebc677c9-b8b0-9c98-ea26-376582f23c2a";
CustomLoadingOptionsRecord.init();
return CustomLoadingOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomLoadingOptionsRecord = CustomLoadingOptionsRecord;

});
define("ShopperPortalEU.model$CustomLoadingOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomLoadingOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomLoadingOptionsRecordList = (function (_super) {
__extends(CustomLoadingOptionsRecordList, _super);
function CustomLoadingOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomLoadingOptionsRecordList.itemType = ShopperPortalEUModel.CustomLoadingOptionsRecord;
return CustomLoadingOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomLoadingOptionsRecordList = CustomLoadingOptionsRecordList;

});
define("ShopperPortalEU.model$DatatransCardGetCardInfoOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$DatatransCardGetCardInfoOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var DatatransCardGetCardInfoOptionsList = (function (_super) {
__extends(DatatransCardGetCardInfoOptionsList, _super);
function DatatransCardGetCardInfoOptionsList(defaults) {
_super.apply(this, arguments);
}
DatatransCardGetCardInfoOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.DatatransCardGetCardInfoOptionsRec;
return DatatransCardGetCardInfoOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.DatatransCardGetCardInfoOptionsList = DatatransCardGetCardInfoOptionsList;

});
define("ShopperPortalEU.model$CustomDropdownCustomValueOptionRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomDropdownCustomValueOptionRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomDropdownCustomValueOptionRecord = (function (_super) {
__extends(CustomDropdownCustomValueOptionRecord, _super);
function CustomDropdownCustomValueOptionRecord(defaults) {
_super.apply(this, arguments);
}
CustomDropdownCustomValueOptionRecord.attributesToDeclare = function () {
return [
this.attr("CustomDropdownCustomValueOption", "customDropdownCustomValueOptionAttr", "CustomDropdownCustomValueOption", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomDropdownCustomValueOptionRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomDropdownCustomValueOptionRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomDropdownCustomValueOptionRecord.fromStructure = function (str) {
return new CustomDropdownCustomValueOptionRecord(new CustomDropdownCustomValueOptionRecord.RecordClass({
customDropdownCustomValueOptionAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomDropdownCustomValueOptionRecord._isAnonymousRecord = true;
CustomDropdownCustomValueOptionRecord.UniqueId = "b7331f1e-ac60-fdfb-5015-f3bf20385d17";
CustomDropdownCustomValueOptionRecord.init();
return CustomDropdownCustomValueOptionRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomDropdownCustomValueOptionRecord = CustomDropdownCustomValueOptionRecord;

});
define("ShopperPortalEU.model$SpacingRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$SpacingRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var SpacingRecordList = (function (_super) {
__extends(SpacingRecordList, _super);
function SpacingRecordList(defaults) {
_super.apply(this, arguments);
}
SpacingRecordList.itemType = ShopperPortalEUModel.SpacingRecord;
return SpacingRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.SpacingRecordList = SpacingRecordList;

});
define("ShopperPortalEU.model$UnescapedHTMLOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$UnescapedHTMLOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var UnescapedHTMLOptionsRecordList = (function (_super) {
__extends(UnescapedHTMLOptionsRecordList, _super);
function UnescapedHTMLOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
UnescapedHTMLOptionsRecordList.itemType = ShopperPortalEUModel.UnescapedHTMLOptionsRecord;
return UnescapedHTMLOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.UnescapedHTMLOptionsRecordList = UnescapedHTMLOptionsRecordList;

});
define("ShopperPortalEU.model$CustomTagOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomTagOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomTagOptionsRecord = (function (_super) {
__extends(CustomTagOptionsRecord, _super);
function CustomTagOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomTagOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomTagOptions", "customTagOptionsAttr", "CustomTagOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomTagOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomTagOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomTagOptionsRecord.fromStructure = function (str) {
return new CustomTagOptionsRecord(new CustomTagOptionsRecord.RecordClass({
customTagOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomTagOptionsRecord._isAnonymousRecord = true;
CustomTagOptionsRecord.UniqueId = "b93fabe1-2a5a-dd45-bc14-ca9eb0393b97";
CustomTagOptionsRecord.init();
return CustomTagOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomTagOptionsRecord = CustomTagOptionsRecord;

});
define("ShopperPortalEU.model$SPFormStatusRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$SPFormStatusRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var SPFormStatusRecordList = (function (_super) {
__extends(SPFormStatusRecordList, _super);
function SPFormStatusRecordList(defaults) {
_super.apply(this, arguments);
}
SPFormStatusRecordList.itemType = ShopperPortalEUModel.SPFormStatusRecord;
return SPFormStatusRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.SPFormStatusRecordList = SPFormStatusRecordList;

});
define("ShopperPortalEU.model$DatePickerLabelOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$DatePickerLabelOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var DatePickerLabelOptionsList = (function (_super) {
__extends(DatePickerLabelOptionsList, _super);
function DatePickerLabelOptionsList(defaults) {
_super.apply(this, arguments);
}
DatePickerLabelOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.DatePickerLabelOptionsRec;
return DatePickerLabelOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.DatePickerLabelOptionsList = DatePickerLabelOptionsList;

});
define("ShopperPortalEU.model$CreditCardOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CreditCardOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CreditCardOptionsList = (function (_super) {
__extends(CreditCardOptionsList, _super);
function CreditCardOptionsList(defaults) {
_super.apply(this, arguments);
}
CreditCardOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CreditCardOptionsRec;
return CreditCardOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CreditCardOptionsList = CreditCardOptionsList;

});
define("ShopperPortalEU.model$FlexJustifyList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$FlexJustifyRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var FlexJustifyList = (function (_super) {
__extends(FlexJustifyList, _super);
function FlexJustifyList(defaults) {
_super.apply(this, arguments);
}
FlexJustifyList.itemType = ShopperPortalEU_UI_ComponentsModel.FlexJustifyRec;
return FlexJustifyList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.FlexJustifyList = FlexJustifyList;

});
define("ShopperPortalEU.model$CustomSeparatorLabelOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomSeparatorLabelOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomSeparatorLabelOptionsRecord = (function (_super) {
__extends(CustomSeparatorLabelOptionsRecord, _super);
function CustomSeparatorLabelOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomSeparatorLabelOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomSeparatorLabelOptions", "customSeparatorLabelOptionsAttr", "CustomSeparatorLabelOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomSeparatorLabelOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomSeparatorLabelOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomSeparatorLabelOptionsRecord.fromStructure = function (str) {
return new CustomSeparatorLabelOptionsRecord(new CustomSeparatorLabelOptionsRecord.RecordClass({
customSeparatorLabelOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomSeparatorLabelOptionsRecord._isAnonymousRecord = true;
CustomSeparatorLabelOptionsRecord.UniqueId = "c70bbeb2-8e00-5a88-ca09-3f44957cc933";
CustomSeparatorLabelOptionsRecord.init();
return CustomSeparatorLabelOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomSeparatorLabelOptionsRecord = CustomSeparatorLabelOptionsRecord;

});
define("ShopperPortalEU.model$CustomSeparatorLabelOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomSeparatorLabelOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomSeparatorLabelOptionsRecordList = (function (_super) {
__extends(CustomSeparatorLabelOptionsRecordList, _super);
function CustomSeparatorLabelOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomSeparatorLabelOptionsRecordList.itemType = ShopperPortalEUModel.CustomSeparatorLabelOptionsRecord;
return CustomSeparatorLabelOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomSeparatorLabelOptionsRecordList = CustomSeparatorLabelOptionsRecordList;

});
define("ShopperPortalEU.model$CircleIconSizeRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CircleIconSizeRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CircleIconSizeRecord = (function (_super) {
__extends(CircleIconSizeRecord, _super);
function CircleIconSizeRecord(defaults) {
_super.apply(this, arguments);
}
CircleIconSizeRecord.attributesToDeclare = function () {
return [
this.attr("CircleIconSize", "circleIconSizeAttr", "CircleIconSize", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CircleIconSizeRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CircleIconSizeRec)
].concat(_super.attributesToDeclare.call(this));
};
CircleIconSizeRecord.fromStructure = function (str) {
return new CircleIconSizeRecord(new CircleIconSizeRecord.RecordClass({
circleIconSizeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CircleIconSizeRecord._isAnonymousRecord = true;
CircleIconSizeRecord.UniqueId = "bddc3ada-0a86-0a35-3606-6f845feda09e";
CircleIconSizeRecord.init();
return CircleIconSizeRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CircleIconSizeRecord = CircleIconSizeRecord;

});
define("ShopperPortalEU.model$SpacingList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$SpacingRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var SpacingList = (function (_super) {
__extends(SpacingList, _super);
function SpacingList(defaults) {
_super.apply(this, arguments);
}
SpacingList.itemType = ShopperPortalEU_UI_ComponentsModel.SpacingRec;
return SpacingList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.SpacingList = SpacingList;

});
define("ShopperPortalEU.model$AvatarOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$AvatarOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var AvatarOptionsRecord = (function (_super) {
__extends(AvatarOptionsRecord, _super);
function AvatarOptionsRecord(defaults) {
_super.apply(this, arguments);
}
AvatarOptionsRecord.attributesToDeclare = function () {
return [
this.attr("AvatarOptions", "avatarOptionsAttr", "AvatarOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.AvatarOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.AvatarOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
AvatarOptionsRecord.fromStructure = function (str) {
return new AvatarOptionsRecord(new AvatarOptionsRecord.RecordClass({
avatarOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
AvatarOptionsRecord._isAnonymousRecord = true;
AvatarOptionsRecord.UniqueId = "f2104811-e735-d6e4-8802-0b6d192df54d";
AvatarOptionsRecord.init();
return AvatarOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.AvatarOptionsRecord = AvatarOptionsRecord;

});
define("ShopperPortalEU.model$AvatarOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$AvatarOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var AvatarOptionsRecordList = (function (_super) {
__extends(AvatarOptionsRecordList, _super);
function AvatarOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
AvatarOptionsRecordList.itemType = ShopperPortalEUModel.AvatarOptionsRecord;
return AvatarOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.AvatarOptionsRecordList = AvatarOptionsRecordList;

});
define("ShopperPortalEU.model$FlexAlignRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$FlexAlignRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var FlexAlignRecordList = (function (_super) {
__extends(FlexAlignRecordList, _super);
function FlexAlignRecordList(defaults) {
_super.apply(this, arguments);
}
FlexAlignRecordList.itemType = ShopperPortalEUModel.FlexAlignRecord;
return FlexAlignRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.FlexAlignRecordList = FlexAlignRecordList;

});
define("ShopperPortalEU.model$UpdateCardDataRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$UpdateCardDataRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var UpdateCardDataRecordList = (function (_super) {
__extends(UpdateCardDataRecordList, _super);
function UpdateCardDataRecordList(defaults) {
_super.apply(this, arguments);
}
UpdateCardDataRecordList.itemType = ShopperPortalEUModel.UpdateCardDataRecord;
return UpdateCardDataRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.UpdateCardDataRecordList = UpdateCardDataRecordList;

});
define("ShopperPortalEU.model$CreditCardSwipeOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CreditCardSwipeOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CreditCardSwipeOptionsList = (function (_super) {
__extends(CreditCardSwipeOptionsList, _super);
function CreditCardSwipeOptionsList(defaults) {
_super.apply(this, arguments);
}
CreditCardSwipeOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CreditCardSwipeOptionsRec;
return CreditCardSwipeOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CreditCardSwipeOptionsList = CreditCardSwipeOptionsList;

});
define("ShopperPortalEU.model$CreditCardSwipeOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CreditCardSwipeOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CreditCardSwipeOptionsRecord = (function (_super) {
__extends(CreditCardSwipeOptionsRecord, _super);
function CreditCardSwipeOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CreditCardSwipeOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CreditCardSwipeOptions", "creditCardSwipeOptionsAttr", "CreditCardSwipeOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CreditCardSwipeOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CreditCardSwipeOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CreditCardSwipeOptionsRecord.fromStructure = function (str) {
return new CreditCardSwipeOptionsRecord(new CreditCardSwipeOptionsRecord.RecordClass({
creditCardSwipeOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CreditCardSwipeOptionsRecord._isAnonymousRecord = true;
CreditCardSwipeOptionsRecord.UniqueId = "c0d3f1f3-edd6-58e3-3223-7b329f1b797c";
CreditCardSwipeOptionsRecord.init();
return CreditCardSwipeOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CreditCardSwipeOptionsRecord = CreditCardSwipeOptionsRecord;

});
define("ShopperPortalEU.model$CustomAlertIconOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomAlertIconOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomAlertIconOptionsRecord = (function (_super) {
__extends(CustomAlertIconOptionsRecord, _super);
function CustomAlertIconOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomAlertIconOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomAlertIconOptions", "customAlertIconOptionsAttr", "CustomAlertIconOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomAlertIconOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomAlertIconOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomAlertIconOptionsRecord.fromStructure = function (str) {
return new CustomAlertIconOptionsRecord(new CustomAlertIconOptionsRecord.RecordClass({
customAlertIconOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomAlertIconOptionsRecord._isAnonymousRecord = true;
CustomAlertIconOptionsRecord.UniqueId = "ff317186-7d52-091d-6b49-f22c7fe7e4d2";
CustomAlertIconOptionsRecord.init();
return CustomAlertIconOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomAlertIconOptionsRecord = CustomAlertIconOptionsRecord;

});
define("ShopperPortalEU.model$CustomAlertIconOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomAlertIconOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomAlertIconOptionsRecordList = (function (_super) {
__extends(CustomAlertIconOptionsRecordList, _super);
function CustomAlertIconOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomAlertIconOptionsRecordList.itemType = ShopperPortalEUModel.CustomAlertIconOptionsRecord;
return CustomAlertIconOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomAlertIconOptionsRecordList = CustomAlertIconOptionsRecordList;

});
define("ShopperPortalEU.model$RefundDetails_Wrapper2List", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU.model", "ShopperPortalEU_Forms_IS.model$RefundDetails_WrapperRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Forms_IS"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var RefundDetails_Wrapper2List = (function (_super) {
__extends(RefundDetails_Wrapper2List, _super);
function RefundDetails_Wrapper2List(defaults) {
_super.apply(this, arguments);
}
RefundDetails_Wrapper2List.itemType = ShopperPortalEU_Forms_ISModel.RefundDetails_WrapperRec;
return RefundDetails_Wrapper2List;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.RefundDetails_Wrapper2List = RefundDetails_Wrapper2List;

});
define("ShopperPortalEU.model$SPCountry_WrapperList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_API.model", "ShopperPortalEU.model", "ShopperPortalEU_API.model$SPCountry_WrapperRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_API"], function (exports, OutSystems, ShopperPortalEU_APIModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var SPCountry_WrapperList = (function (_super) {
__extends(SPCountry_WrapperList, _super);
function SPCountry_WrapperList(defaults) {
_super.apply(this, arguments);
}
SPCountry_WrapperList.itemType = ShopperPortalEU_APIModel.SPCountry_WrapperRec;
return SPCountry_WrapperList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.SPCountry_WrapperList = SPCountry_WrapperList;

});
define("ShopperPortalEU.model$CustomListItemOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomListItemOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomListItemOptionsList = (function (_super) {
__extends(CustomListItemOptionsList, _super);
function CustomListItemOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomListItemOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomListItemOptionsRec;
return CustomListItemOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomListItemOptionsList = CustomListItemOptionsList;

});
define("ShopperPortalEU.model$ScanPassportRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$ScanPassportRec"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var ScanPassportRecord = (function (_super) {
__extends(ScanPassportRecord, _super);
function ScanPassportRecord(defaults) {
_super.apply(this, arguments);
}
ScanPassportRecord.attributesToDeclare = function () {
return [
this.attr("ScanPassport", "scanPassportAttr", "ScanPassport", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEUModel.ScanPassportRec());
}, true, ShopperPortalEUModel.ScanPassportRec)
].concat(_super.attributesToDeclare.call(this));
};
ScanPassportRecord.fromStructure = function (str) {
return new ScanPassportRecord(new ScanPassportRecord.RecordClass({
scanPassportAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ScanPassportRecord._isAnonymousRecord = true;
ScanPassportRecord.UniqueId = "e6da5e4e-a6bc-9e55-069d-f19ce91d8690";
ScanPassportRecord.init();
return ScanPassportRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.ScanPassportRecord = ScanPassportRecord;

});
define("ShopperPortalEU.model$ScanPassportRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$ScanPassportRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var ScanPassportRecordList = (function (_super) {
__extends(ScanPassportRecordList, _super);
function ScanPassportRecordList(defaults) {
_super.apply(this, arguments);
}
ScanPassportRecordList.itemType = ShopperPortalEUModel.ScanPassportRecord;
return ScanPassportRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.ScanPassportRecordList = ScanPassportRecordList;

});
define("ShopperPortalEU.model$ApplicationHeaderOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Theme.model$ApplicationHeaderOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var ApplicationHeaderOptionsList = (function (_super) {
__extends(ApplicationHeaderOptionsList, _super);
function ApplicationHeaderOptionsList(defaults) {
_super.apply(this, arguments);
}
ApplicationHeaderOptionsList.itemType = ShopperPortalEU_UI_ThemeModel.ApplicationHeaderOptionsRec;
return ApplicationHeaderOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.ApplicationHeaderOptionsList = ApplicationHeaderOptionsList;

});
define("ShopperPortalEU.model$DeleteCardBodyList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU.model", "ShopperPortalEU_Shopper_IS.model$DeleteCardBodyRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS"], function (exports, OutSystems, ShopperPortalEU_Shopper_ISModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var DeleteCardBodyList = (function (_super) {
__extends(DeleteCardBodyList, _super);
function DeleteCardBodyList(defaults) {
_super.apply(this, arguments);
}
DeleteCardBodyList.itemType = ShopperPortalEU_Shopper_ISModel.DeleteCardBodyRec;
return DeleteCardBodyList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.DeleteCardBodyList = DeleteCardBodyList;

});
define("ShopperPortalEU.model$GetOSRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$GetOSRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var GetOSRecordList = (function (_super) {
__extends(GetOSRecordList, _super);
function GetOSRecordList(defaults) {
_super.apply(this, arguments);
}
GetOSRecordList.itemType = ShopperPortalEUModel.GetOSRecord;
return GetOSRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.GetOSRecordList = GetOSRecordList;

});
define("ShopperPortalEU.model$LayoutOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Theme.model$LayoutOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var LayoutOptionsList = (function (_super) {
__extends(LayoutOptionsList, _super);
function LayoutOptionsList(defaults) {
_super.apply(this, arguments);
}
LayoutOptionsList.itemType = ShopperPortalEU_UI_ThemeModel.LayoutOptionsRec;
return LayoutOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.LayoutOptionsList = LayoutOptionsList;

});
define("ShopperPortalEU.model$CustomColumnsOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomColumnsOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomColumnsOptionsList = (function (_super) {
__extends(CustomColumnsOptionsList, _super);
function CustomColumnsOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomColumnsOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomColumnsOptionsRec;
return CustomColumnsOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomColumnsOptionsList = CustomColumnsOptionsList;

});
define("ShopperPortalEU.model$CustomCardOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomCardOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomCardOptionsRecordList = (function (_super) {
__extends(CustomCardOptionsRecordList, _super);
function CustomCardOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomCardOptionsRecordList.itemType = ShopperPortalEUModel.CustomCardOptionsRecord;
return CustomCardOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomCardOptionsRecordList = CustomCardOptionsRecordList;

});
define("ShopperPortalEU.model$CompleteDetails_ContactList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CompleteDetails_ContactRec"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CompleteDetails_ContactList = (function (_super) {
__extends(CompleteDetails_ContactList, _super);
function CompleteDetails_ContactList(defaults) {
_super.apply(this, arguments);
}
CompleteDetails_ContactList.itemType = ShopperPortalEUModel.CompleteDetails_ContactRec;
return CompleteDetails_ContactList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CompleteDetails_ContactList = CompleteDetails_ContactList;

});
define("ShopperPortalEU.model$LayoutDetailOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Theme.model$LayoutDetailOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var LayoutDetailOptionsList = (function (_super) {
__extends(LayoutDetailOptionsList, _super);
function LayoutDetailOptionsList(defaults) {
_super.apply(this, arguments);
}
LayoutDetailOptionsList.itemType = ShopperPortalEU_UI_ThemeModel.LayoutDetailOptionsRec;
return LayoutDetailOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.LayoutDetailOptionsList = LayoutDetailOptionsList;

});
define("ShopperPortalEU.model$LayoutHeaderOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$LayoutHeaderOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var LayoutHeaderOptionsRecordList = (function (_super) {
__extends(LayoutHeaderOptionsRecordList, _super);
function LayoutHeaderOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
LayoutHeaderOptionsRecordList.itemType = ShopperPortalEUModel.LayoutHeaderOptionsRecord;
return LayoutHeaderOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.LayoutHeaderOptionsRecordList = LayoutHeaderOptionsRecordList;

});
define("ShopperPortalEU.model$CodeInputStateRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CodeInputStateRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CodeInputStateRecordList = (function (_super) {
__extends(CodeInputStateRecordList, _super);
function CodeInputStateRecordList(defaults) {
_super.apply(this, arguments);
}
CodeInputStateRecordList.itemType = ShopperPortalEUModel.CodeInputStateRecord;
return CodeInputStateRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CodeInputStateRecordList = CodeInputStateRecordList;

});
define("ShopperPortalEU.model$LayoutDetailOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$LayoutDetailOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var LayoutDetailOptionsRecordList = (function (_super) {
__extends(LayoutDetailOptionsRecordList, _super);
function LayoutDetailOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
LayoutDetailOptionsRecordList.itemType = ShopperPortalEUModel.LayoutDetailOptionsRecord;
return LayoutDetailOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.LayoutDetailOptionsRecordList = LayoutDetailOptionsRecordList;

});
define("ShopperPortalEU.model$CustomIconSizeList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomIconSizeRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomIconSizeList = (function (_super) {
__extends(CustomIconSizeList, _super);
function CustomIconSizeList(defaults) {
_super.apply(this, arguments);
}
CustomIconSizeList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomIconSizeRec;
return CustomIconSizeList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomIconSizeList = CustomIconSizeList;

});
define("ShopperPortalEU.model$CustomDropdownOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomDropdownOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomDropdownOptionsRecordList = (function (_super) {
__extends(CustomDropdownOptionsRecordList, _super);
function CustomDropdownOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownOptionsRecordList.itemType = ShopperPortalEUModel.CustomDropdownOptionsRecord;
return CustomDropdownOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomDropdownOptionsRecordList = CustomDropdownOptionsRecordList;

});
define("ShopperPortalEU.model$BannerTypeList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Theme.model$BannerTypeRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var BannerTypeList = (function (_super) {
__extends(BannerTypeList, _super);
function BannerTypeList(defaults) {
_super.apply(this, arguments);
}
BannerTypeList.itemType = ShopperPortalEU_UI_ThemeModel.BannerTypeRec;
return BannerTypeList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.BannerTypeList = BannerTypeList;

});
define("ShopperPortalEU.model$DatePickerOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$DatePickerOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var DatePickerOptionsList = (function (_super) {
__extends(DatePickerOptionsList, _super);
function DatePickerOptionsList(defaults) {
_super.apply(this, arguments);
}
DatePickerOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.DatePickerOptionsRec;
return DatePickerOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.DatePickerOptionsList = DatePickerOptionsList;

});
define("ShopperPortalEU.model$MenuItemIconOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Theme.model$MenuItemIconOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var MenuItemIconOptionsList = (function (_super) {
__extends(MenuItemIconOptionsList, _super);
function MenuItemIconOptionsList(defaults) {
_super.apply(this, arguments);
}
MenuItemIconOptionsList.itemType = ShopperPortalEU_UI_ThemeModel.MenuItemIconOptionsRec;
return MenuItemIconOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.MenuItemIconOptionsList = MenuItemIconOptionsList;

});
define("ShopperPortalEU.model$PhoneNumberInputOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$PhoneNumberInputOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var PhoneNumberInputOptionsRecord = (function (_super) {
__extends(PhoneNumberInputOptionsRecord, _super);
function PhoneNumberInputOptionsRecord(defaults) {
_super.apply(this, arguments);
}
PhoneNumberInputOptionsRecord.attributesToDeclare = function () {
return [
this.attr("PhoneNumberInputOptions", "phoneNumberInputOptionsAttr", "PhoneNumberInputOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.PhoneNumberInputOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
PhoneNumberInputOptionsRecord.fromStructure = function (str) {
return new PhoneNumberInputOptionsRecord(new PhoneNumberInputOptionsRecord.RecordClass({
phoneNumberInputOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
PhoneNumberInputOptionsRecord._isAnonymousRecord = true;
PhoneNumberInputOptionsRecord.UniqueId = "cf47b8ae-2d86-70b4-8e58-e2af18b79a46";
PhoneNumberInputOptionsRecord.init();
return PhoneNumberInputOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.PhoneNumberInputOptionsRecord = PhoneNumberInputOptionsRecord;

});
define("ShopperPortalEU.model$CustomInputAlignmentRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomInputAlignmentRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomInputAlignmentRecord = (function (_super) {
__extends(CustomInputAlignmentRecord, _super);
function CustomInputAlignmentRecord(defaults) {
_super.apply(this, arguments);
}
CustomInputAlignmentRecord.attributesToDeclare = function () {
return [
this.attr("CustomInputAlignment", "customInputAlignmentAttr", "CustomInputAlignment", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomInputAlignmentRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomInputAlignmentRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomInputAlignmentRecord.fromStructure = function (str) {
return new CustomInputAlignmentRecord(new CustomInputAlignmentRecord.RecordClass({
customInputAlignmentAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomInputAlignmentRecord._isAnonymousRecord = true;
CustomInputAlignmentRecord.UniqueId = "cf759aae-280c-38f3-fd8c-f441c9cbd57b";
CustomInputAlignmentRecord.init();
return CustomInputAlignmentRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomInputAlignmentRecord = CustomInputAlignmentRecord;

});
define("ShopperPortalEU.model$CustomOpacityOptions2Record", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomOpacityOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomOpacityOptions2Record = (function (_super) {
__extends(CustomOpacityOptions2Record, _super);
function CustomOpacityOptions2Record(defaults) {
_super.apply(this, arguments);
}
CustomOpacityOptions2Record.attributesToDeclare = function () {
return [
this.attr("CustomOpacityOptions", "customOpacityOptionsAttr", "CustomOpacityOptions2", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomOpacityOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomOpacityOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomOpacityOptions2Record.fromStructure = function (str) {
return new CustomOpacityOptions2Record(new CustomOpacityOptions2Record.RecordClass({
customOpacityOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomOpacityOptions2Record._isAnonymousRecord = true;
CustomOpacityOptions2Record.UniqueId = "dd31c204-8f3a-0cca-e32b-f0c9aff8536d";
CustomOpacityOptions2Record.init();
return CustomOpacityOptions2Record;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomOpacityOptions2Record = CustomOpacityOptions2Record;

});
define("ShopperPortalEU.model$CustomOpacityOptions2RecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomOpacityOptions2Record"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomOpacityOptions2RecordList = (function (_super) {
__extends(CustomOpacityOptions2RecordList, _super);
function CustomOpacityOptions2RecordList(defaults) {
_super.apply(this, arguments);
}
CustomOpacityOptions2RecordList.itemType = ShopperPortalEUModel.CustomOpacityOptions2Record;
return CustomOpacityOptions2RecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomOpacityOptions2RecordList = CustomOpacityOptions2RecordList;

});
define("ShopperPortalEU.model$CustomAlertOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomAlertOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomAlertOptionsRecord = (function (_super) {
__extends(CustomAlertOptionsRecord, _super);
function CustomAlertOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomAlertOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomAlertOptions", "customAlertOptionsAttr", "CustomAlertOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomAlertOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomAlertOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomAlertOptionsRecord.fromStructure = function (str) {
return new CustomAlertOptionsRecord(new CustomAlertOptionsRecord.RecordClass({
customAlertOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomAlertOptionsRecord._isAnonymousRecord = true;
CustomAlertOptionsRecord.UniqueId = "f79064ce-5d85-efc7-46d7-684bfd60db7a";
CustomAlertOptionsRecord.init();
return CustomAlertOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomAlertOptionsRecord = CustomAlertOptionsRecord;

});
define("ShopperPortalEU.model$CustomAlertOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomAlertOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomAlertOptionsRecordList = (function (_super) {
__extends(CustomAlertOptionsRecordList, _super);
function CustomAlertOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomAlertOptionsRecordList.itemType = ShopperPortalEUModel.CustomAlertOptionsRecord;
return CustomAlertOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomAlertOptionsRecordList = CustomAlertOptionsRecordList;

});
define("ShopperPortalEU.model$AccessInfoRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$AccessInfoRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var AccessInfoRecordList = (function (_super) {
__extends(AccessInfoRecordList, _super);
function AccessInfoRecordList(defaults) {
_super.apply(this, arguments);
}
AccessInfoRecordList.itemType = ShopperPortalEUModel.AccessInfoRecord;
return AccessInfoRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.AccessInfoRecordList = AccessInfoRecordList;

});
define("ShopperPortalEU.model$CustomTimelineOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomTimelineOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomTimelineOptionsList = (function (_super) {
__extends(CustomTimelineOptionsList, _super);
function CustomTimelineOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomTimelineOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomTimelineOptionsRec;
return CustomTimelineOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomTimelineOptionsList = CustomTimelineOptionsList;

});
define("ShopperPortalEU.model$CustomDropdownListSearchOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomDropdownListSearchOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomDropdownListSearchOptionsList = (function (_super) {
__extends(CustomDropdownListSearchOptionsList, _super);
function CustomDropdownListSearchOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownListSearchOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomDropdownListSearchOptionsRec;
return CustomDropdownListSearchOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomDropdownListSearchOptionsList = CustomDropdownListSearchOptionsList;

});
define("ShopperPortalEU.model$CustomLinkOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomLinkOptionsRecord = (function (_super) {
__extends(CustomLinkOptionsRecord, _super);
function CustomLinkOptionsRecord(defaults) {
_super.apply(this, arguments);
}
CustomLinkOptionsRecord.attributesToDeclare = function () {
return [
this.attr("CustomLinkOptions", "customLinkOptionsAttr", "CustomLinkOptions", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomLinkOptionsRec());
}, true, ShopperPortalEU_UI_ComponentsModel.CustomLinkOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
CustomLinkOptionsRecord.fromStructure = function (str) {
return new CustomLinkOptionsRecord(new CustomLinkOptionsRecord.RecordClass({
customLinkOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CustomLinkOptionsRecord._isAnonymousRecord = true;
CustomLinkOptionsRecord.UniqueId = "d2597cc5-d0b0-a559-c0a6-089a78c28a11";
CustomLinkOptionsRecord.init();
return CustomLinkOptionsRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.CustomLinkOptionsRecord = CustomLinkOptionsRecord;

});
define("ShopperPortalEU.model$CustomInputAlignmentRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomInputAlignmentRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomInputAlignmentRecordList = (function (_super) {
__extends(CustomInputAlignmentRecordList, _super);
function CustomInputAlignmentRecordList(defaults) {
_super.apply(this, arguments);
}
CustomInputAlignmentRecordList.itemType = ShopperPortalEUModel.CustomInputAlignmentRecord;
return CustomInputAlignmentRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomInputAlignmentRecordList = CustomInputAlignmentRecordList;

});
define("ShopperPortalEU.model$CustomDropdownListValueOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomDropdownListValueOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomDropdownListValueOptionsRecordList = (function (_super) {
__extends(CustomDropdownListValueOptionsRecordList, _super);
function CustomDropdownListValueOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownListValueOptionsRecordList.itemType = ShopperPortalEUModel.CustomDropdownListValueOptionsRecord;
return CustomDropdownListValueOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomDropdownListValueOptionsRecordList = CustomDropdownListValueOptionsRecordList;

});
define("ShopperPortalEU.model$BottomBarItemOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Theme.model$BottomBarItemOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var BottomBarItemOptionsList = (function (_super) {
__extends(BottomBarItemOptionsList, _super);
function BottomBarItemOptionsList(defaults) {
_super.apply(this, arguments);
}
BottomBarItemOptionsList.itemType = ShopperPortalEU_UI_ThemeModel.BottomBarItemOptionsRec;
return BottomBarItemOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.BottomBarItemOptionsList = BottomBarItemOptionsList;

});
define("ShopperPortalEU.model$CustomPopupLayoutOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomPopupLayoutOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomPopupLayoutOptionsRecordList = (function (_super) {
__extends(CustomPopupLayoutOptionsRecordList, _super);
function CustomPopupLayoutOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomPopupLayoutOptionsRecordList.itemType = ShopperPortalEUModel.CustomPopupLayoutOptionsRecord;
return CustomPopupLayoutOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomPopupLayoutOptionsRecordList = CustomPopupLayoutOptionsRecordList;

});
define("ShopperPortalEU.model$RecaptchaThemeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$RecaptchaThemeRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var RecaptchaThemeRecordList = (function (_super) {
__extends(RecaptchaThemeRecordList, _super);
function RecaptchaThemeRecordList(defaults) {
_super.apply(this, arguments);
}
RecaptchaThemeRecordList.itemType = ShopperPortalEUModel.RecaptchaThemeRecord;
return RecaptchaThemeRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.RecaptchaThemeRecordList = RecaptchaThemeRecordList;

});
define("ShopperPortalEU.model$CustomColumnsOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomColumnsOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomColumnsOptionsRecordList = (function (_super) {
__extends(CustomColumnsOptionsRecordList, _super);
function CustomColumnsOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomColumnsOptionsRecordList.itemType = ShopperPortalEUModel.CustomColumnsOptionsRecord;
return CustomColumnsOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomColumnsOptionsRecordList = CustomColumnsOptionsRecordList;

});
define("ShopperPortalEU.model$CustomColumnsItemOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomColumnsItemOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomColumnsItemOptionsRecordList = (function (_super) {
__extends(CustomColumnsItemOptionsRecordList, _super);
function CustomColumnsItemOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomColumnsItemOptionsRecordList.itemType = ShopperPortalEUModel.CustomColumnsItemOptionsRecord;
return CustomColumnsItemOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomColumnsItemOptionsRecordList = CustomColumnsItemOptionsRecordList;

});
define("ShopperPortalEU.model$CustomButtonGroupOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomButtonGroupOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomButtonGroupOptionsList = (function (_super) {
__extends(CustomButtonGroupOptionsList, _super);
function CustomButtonGroupOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomButtonGroupOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomButtonGroupOptionsRec;
return CustomButtonGroupOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomButtonGroupOptionsList = CustomButtonGroupOptionsList;

});
define("ShopperPortalEU.model$FullHeightContentOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$FullHeightContentOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var FullHeightContentOptionsList = (function (_super) {
__extends(FullHeightContentOptionsList, _super);
function FullHeightContentOptionsList(defaults) {
_super.apply(this, arguments);
}
FullHeightContentOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.FullHeightContentOptionsRec;
return FullHeightContentOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.FullHeightContentOptionsList = FullHeightContentOptionsList;

});
define("ShopperPortalEU.model$HeaderActionOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$HeaderActionOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var HeaderActionOptionsRecordList = (function (_super) {
__extends(HeaderActionOptionsRecordList, _super);
function HeaderActionOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
HeaderActionOptionsRecordList.itemType = ShopperPortalEUModel.HeaderActionOptionsRecord;
return HeaderActionOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.HeaderActionOptionsRecordList = HeaderActionOptionsRecordList;

});
define("ShopperPortalEU.model$CircleIconIconOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CircleIconIconOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CircleIconIconOptionsRecordList = (function (_super) {
__extends(CircleIconIconOptionsRecordList, _super);
function CircleIconIconOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CircleIconIconOptionsRecordList.itemType = ShopperPortalEUModel.CircleIconIconOptionsRecord;
return CircleIconIconOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CircleIconIconOptionsRecordList = CircleIconIconOptionsRecordList;

});
define("ShopperPortalEU.model$ScanBarcodeDataRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$ScanBarcodeDataRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var ScanBarcodeDataRecordList = (function (_super) {
__extends(ScanBarcodeDataRecordList, _super);
function ScanBarcodeDataRecordList(defaults) {
_super.apply(this, arguments);
}
ScanBarcodeDataRecordList.itemType = ShopperPortalEUModel.ScanBarcodeDataRecord;
return ScanBarcodeDataRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.ScanBarcodeDataRecordList = ScanBarcodeDataRecordList;

});
define("ShopperPortalEU.model$CustomFormOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomFormOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomFormOptionsList = (function (_super) {
__extends(CustomFormOptionsList, _super);
function CustomFormOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomFormOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomFormOptionsRec;
return CustomFormOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomFormOptionsList = CustomFormOptionsList;

});
define("ShopperPortalEU.model$CustomInputAlignmentList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomInputAlignmentRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomInputAlignmentList = (function (_super) {
__extends(CustomInputAlignmentList, _super);
function CustomInputAlignmentList(defaults) {
_super.apply(this, arguments);
}
CustomInputAlignmentList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomInputAlignmentRec;
return CustomInputAlignmentList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomInputAlignmentList = CustomInputAlignmentList;

});
define("ShopperPortalEU.model$CustomDropdownCustomValueOptionRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomDropdownCustomValueOptionRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomDropdownCustomValueOptionRecordList = (function (_super) {
__extends(CustomDropdownCustomValueOptionRecordList, _super);
function CustomDropdownCustomValueOptionRecordList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownCustomValueOptionRecordList.itemType = ShopperPortalEUModel.CustomDropdownCustomValueOptionRecord;
return CustomDropdownCustomValueOptionRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomDropdownCustomValueOptionRecordList = CustomDropdownCustomValueOptionRecordList;

});
define("ShopperPortalEU.model$CustomTagOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomTagOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomTagOptionsRecordList = (function (_super) {
__extends(CustomTagOptionsRecordList, _super);
function CustomTagOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomTagOptionsRecordList.itemType = ShopperPortalEUModel.CustomTagOptionsRecord;
return CustomTagOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomTagOptionsRecordList = CustomTagOptionsRecordList;

});
define("ShopperPortalEU.model$BannerTypeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$BannerTypeRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var BannerTypeRecordList = (function (_super) {
__extends(BannerTypeRecordList, _super);
function BannerTypeRecordList(defaults) {
_super.apply(this, arguments);
}
BannerTypeRecordList.itemType = ShopperPortalEUModel.BannerTypeRecord;
return BannerTypeRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.BannerTypeRecordList = BannerTypeRecordList;

});
define("ShopperPortalEU.model$FullHeightContentBottomOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$FullHeightContentBottomOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var FullHeightContentBottomOptionsList = (function (_super) {
__extends(FullHeightContentBottomOptionsList, _super);
function FullHeightContentBottomOptionsList(defaults) {
_super.apply(this, arguments);
}
FullHeightContentBottomOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.FullHeightContentBottomOptionsRec;
return FullHeightContentBottomOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.FullHeightContentBottomOptionsList = FullHeightContentBottomOptionsList;

});
define("ShopperPortalEU.model$FormInfo_WrapperRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU.model", "ShopperPortalEU_Forms_IS.model$FormInfo_WrapperRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Forms_IS"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var FormInfo_WrapperRecord = (function (_super) {
__extends(FormInfo_WrapperRecord, _super);
function FormInfo_WrapperRecord(defaults) {
_super.apply(this, arguments);
}
FormInfo_WrapperRecord.attributesToDeclare = function () {
return [
this.attr("FormInfo_Wrapper", "formInfo_WrapperAttr", "FormInfo_Wrapper", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Forms_ISModel.FormInfo_WrapperRec());
}, true, ShopperPortalEU_Forms_ISModel.FormInfo_WrapperRec)
].concat(_super.attributesToDeclare.call(this));
};
FormInfo_WrapperRecord.fromStructure = function (str) {
return new FormInfo_WrapperRecord(new FormInfo_WrapperRecord.RecordClass({
formInfo_WrapperAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
FormInfo_WrapperRecord._isAnonymousRecord = true;
FormInfo_WrapperRecord.UniqueId = "f047d9e7-03f8-1ce5-e685-3c380a706f58";
FormInfo_WrapperRecord.init();
return FormInfo_WrapperRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.FormInfo_WrapperRecord = FormInfo_WrapperRecord;

});
define("ShopperPortalEU.model$FormInfo_WrapperRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$FormInfo_WrapperRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var FormInfo_WrapperRecordList = (function (_super) {
__extends(FormInfo_WrapperRecordList, _super);
function FormInfo_WrapperRecordList(defaults) {
_super.apply(this, arguments);
}
FormInfo_WrapperRecordList.itemType = ShopperPortalEUModel.FormInfo_WrapperRecord;
return FormInfo_WrapperRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.FormInfo_WrapperRecordList = FormInfo_WrapperRecordList;

});
define("ShopperPortalEU.model$HeaderActionItemOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$HeaderActionItemOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var HeaderActionItemOptionsRecordList = (function (_super) {
__extends(HeaderActionItemOptionsRecordList, _super);
function HeaderActionItemOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
HeaderActionItemOptionsRecordList.itemType = ShopperPortalEUModel.HeaderActionItemOptionsRecord;
return HeaderActionItemOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.HeaderActionItemOptionsRecordList = HeaderActionItemOptionsRecordList;

});
define("ShopperPortalEU.model$CustomSwitchOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomSwitchOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomSwitchOptionsRecordList = (function (_super) {
__extends(CustomSwitchOptionsRecordList, _super);
function CustomSwitchOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomSwitchOptionsRecordList.itemType = ShopperPortalEUModel.CustomSwitchOptionsRecord;
return CustomSwitchOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomSwitchOptionsRecordList = CustomSwitchOptionsRecordList;

});
define("ShopperPortalEU.model$RecaptchaBadgeList", ["exports", "OutSystems/ClientRuntime/Main", "reCAPTCHAReact.model", "ShopperPortalEU.model", "reCAPTCHAReact.model$RecaptchaBadgeRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$reCAPTCHAReact"], function (exports, OutSystems, reCAPTCHAReactModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var RecaptchaBadgeList = (function (_super) {
__extends(RecaptchaBadgeList, _super);
function RecaptchaBadgeList(defaults) {
_super.apply(this, arguments);
}
RecaptchaBadgeList.itemType = reCAPTCHAReactModel.RecaptchaBadgeRec;
return RecaptchaBadgeList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.RecaptchaBadgeList = RecaptchaBadgeList;

});
define("ShopperPortalEU.model$CustomLinkOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomLinkOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomLinkOptionsRecordList = (function (_super) {
__extends(CustomLinkOptionsRecordList, _super);
function CustomLinkOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomLinkOptionsRecordList.itemType = ShopperPortalEUModel.CustomLinkOptionsRecord;
return CustomLinkOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomLinkOptionsRecordList = CustomLinkOptionsRecordList;

});
define("ShopperPortalEU.model$CompleteDetails_AddressRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CompleteDetails_AddressRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CompleteDetails_AddressRecordList = (function (_super) {
__extends(CompleteDetails_AddressRecordList, _super);
function CompleteDetails_AddressRecordList(defaults) {
_super.apply(this, arguments);
}
CompleteDetails_AddressRecordList.itemType = ShopperPortalEUModel.CompleteDetails_AddressRecord;
return CompleteDetails_AddressRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CompleteDetails_AddressRecordList = CompleteDetails_AddressRecordList;

});
define("ShopperPortalEU.model$BottomBarOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$BottomBarOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var BottomBarOptionsRecordList = (function (_super) {
__extends(BottomBarOptionsRecordList, _super);
function BottomBarOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
BottomBarOptionsRecordList.itemType = ShopperPortalEUModel.BottomBarOptionsRecord;
return BottomBarOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.BottomBarOptionsRecordList = BottomBarOptionsRecordList;

});
define("ShopperPortalEU.model$GetOSOptionList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$GetOSOptionRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var GetOSOptionList = (function (_super) {
__extends(GetOSOptionList, _super);
function GetOSOptionList(defaults) {
_super.apply(this, arguments);
}
GetOSOptionList.itemType = ShopperPortalEU_UI_ComponentsModel.GetOSOptionRec;
return GetOSOptionList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.GetOSOptionList = GetOSOptionList;

});
define("ShopperPortalEU.model$FlexJustifyRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$FlexJustifyRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var FlexJustifyRecordList = (function (_super) {
__extends(FlexJustifyRecordList, _super);
function FlexJustifyRecordList(defaults) {
_super.apply(this, arguments);
}
FlexJustifyRecordList.itemType = ShopperPortalEUModel.FlexJustifyRecord;
return FlexJustifyRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.FlexJustifyRecordList = FlexJustifyRecordList;

});
define("ShopperPortalEU.model$GetOSList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$GetOSRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var GetOSList = (function (_super) {
__extends(GetOSList, _super);
function GetOSList(defaults) {
_super.apply(this, arguments);
}
GetOSList.itemType = ShopperPortalEU_UI_ComponentsModel.GetOSRec;
return GetOSList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.GetOSList = GetOSList;

});
define("ShopperPortalEU.model$HeaderActionItemIconOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Theme.model$HeaderActionItemIconOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var HeaderActionItemIconOptionsList = (function (_super) {
__extends(HeaderActionItemIconOptionsList, _super);
function HeaderActionItemIconOptionsList(defaults) {
_super.apply(this, arguments);
}
HeaderActionItemIconOptionsList.itemType = ShopperPortalEU_UI_ThemeModel.HeaderActionItemIconOptionsRec;
return HeaderActionItemIconOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.HeaderActionItemIconOptionsList = HeaderActionItemIconOptionsList;

});
define("ShopperPortalEU.model$SPCountry_WrapperRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$SPCountry_WrapperRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var SPCountry_WrapperRecordList = (function (_super) {
__extends(SPCountry_WrapperRecordList, _super);
function SPCountry_WrapperRecordList(defaults) {
_super.apply(this, arguments);
}
SPCountry_WrapperRecordList.itemType = ShopperPortalEUModel.SPCountry_WrapperRecord;
return SPCountry_WrapperRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.SPCountry_WrapperRecordList = SPCountry_WrapperRecordList;

});
define("ShopperPortalEU.model$CardExpandableOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CardExpandableOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CardExpandableOptionsList = (function (_super) {
__extends(CardExpandableOptionsList, _super);
function CardExpandableOptionsList(defaults) {
_super.apply(this, arguments);
}
CardExpandableOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CardExpandableOptionsRec;
return CardExpandableOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CardExpandableOptionsList = CardExpandableOptionsList;

});
define("ShopperPortalEU.model$CustomRadioButtonOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomRadioButtonOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomRadioButtonOptionsList = (function (_super) {
__extends(CustomRadioButtonOptionsList, _super);
function CustomRadioButtonOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomRadioButtonOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomRadioButtonOptionsRec;
return CustomRadioButtonOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomRadioButtonOptionsList = CustomRadioButtonOptionsList;

});
define("ShopperPortalEU.model$CustomOpacityOptions2List", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomOpacityOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomOpacityOptions2List = (function (_super) {
__extends(CustomOpacityOptions2List, _super);
function CustomOpacityOptions2List(defaults) {
_super.apply(this, arguments);
}
CustomOpacityOptions2List.itemType = ShopperPortalEU_UI_ComponentsModel.CustomOpacityOptionsRec;
return CustomOpacityOptions2List;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomOpacityOptions2List = CustomOpacityOptions2List;

});
define("ShopperPortalEU.model$CustomButtonTypeList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomButtonTypeRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomButtonTypeList = (function (_super) {
__extends(CustomButtonTypeList, _super);
function CustomButtonTypeList(defaults) {
_super.apply(this, arguments);
}
CustomButtonTypeList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomButtonTypeRec;
return CustomButtonTypeList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomButtonTypeList = CustomButtonTypeList;

});
define("ShopperPortalEU.model$FormDetailsDTOList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$FormDetailsDTORec"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var FormDetailsDTOList = (function (_super) {
__extends(FormDetailsDTOList, _super);
function FormDetailsDTOList(defaults) {
_super.apply(this, arguments);
}
FormDetailsDTOList.itemType = ShopperPortalEUModel.FormDetailsDTORec;
return FormDetailsDTOList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.FormDetailsDTOList = FormDetailsDTOList;

});
define("ShopperPortalEU.model$BottomDrawerRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$BottomDrawerRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var BottomDrawerRecordList = (function (_super) {
__extends(BottomDrawerRecordList, _super);
function BottomDrawerRecordList(defaults) {
_super.apply(this, arguments);
}
BottomDrawerRecordList.itemType = ShopperPortalEUModel.BottomDrawerRecord;
return BottomDrawerRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.BottomDrawerRecordList = BottomDrawerRecordList;

});
define("ShopperPortalEU.model$CustomTimelineTypeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomTimelineTypeRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomTimelineTypeRecordList = (function (_super) {
__extends(CustomTimelineTypeRecordList, _super);
function CustomTimelineTypeRecordList(defaults) {
_super.apply(this, arguments);
}
CustomTimelineTypeRecordList.itemType = ShopperPortalEUModel.CustomTimelineTypeRecord;
return CustomTimelineTypeRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomTimelineTypeRecordList = CustomTimelineTypeRecordList;

});
define("ShopperPortalEU.model$GetOSBrowserOptionRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$GetOSBrowserOptionRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var GetOSBrowserOptionRecordList = (function (_super) {
__extends(GetOSBrowserOptionRecordList, _super);
function GetOSBrowserOptionRecordList(defaults) {
_super.apply(this, arguments);
}
GetOSBrowserOptionRecordList.itemType = ShopperPortalEUModel.GetOSBrowserOptionRecord;
return GetOSBrowserOptionRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.GetOSBrowserOptionRecordList = GetOSBrowserOptionRecordList;

});
define("ShopperPortalEU.model$CustomButtonOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomButtonOptionsList = (function (_super) {
__extends(CustomButtonOptionsList, _super);
function CustomButtonOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomButtonOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRec;
return CustomButtonOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomButtonOptionsList = CustomButtonOptionsList;

});
define("ShopperPortalEU.model$PhoneNumberInputSearchOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$PhoneNumberInputSearchOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var PhoneNumberInputSearchOptionsRecordList = (function (_super) {
__extends(PhoneNumberInputSearchOptionsRecordList, _super);
function PhoneNumberInputSearchOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
PhoneNumberInputSearchOptionsRecordList.itemType = ShopperPortalEUModel.PhoneNumberInputSearchOptionsRecord;
return PhoneNumberInputSearchOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.PhoneNumberInputSearchOptionsRecordList = PhoneNumberInputSearchOptionsRecordList;

});
define("ShopperPortalEU.model$CustomSeparatorStateRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomSeparatorStateRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomSeparatorStateRecordList = (function (_super) {
__extends(CustomSeparatorStateRecordList, _super);
function CustomSeparatorStateRecordList(defaults) {
_super.apply(this, arguments);
}
CustomSeparatorStateRecordList.itemType = ShopperPortalEUModel.CustomSeparatorStateRecord;
return CustomSeparatorStateRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomSeparatorStateRecordList = CustomSeparatorStateRecordList;

});
define("ShopperPortalEU.model$RefundDetailsPaymentDetails_UIRecord", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU.model", "ShopperPortalEU_Forms_IS.model$RefundDetailsPaymentDetails_UIRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Forms_IS"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var RefundDetailsPaymentDetails_UIRecord = (function (_super) {
__extends(RefundDetailsPaymentDetails_UIRecord, _super);
function RefundDetailsPaymentDetails_UIRecord(defaults) {
_super.apply(this, arguments);
}
RefundDetailsPaymentDetails_UIRecord.attributesToDeclare = function () {
return [
this.attr("RefundDetailsPaymentDetails_UI", "refundDetailsPaymentDetails_UIAttr", "RefundDetailsPaymentDetails_UI", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Forms_ISModel.RefundDetailsPaymentDetails_UIRec());
}, true, ShopperPortalEU_Forms_ISModel.RefundDetailsPaymentDetails_UIRec)
].concat(_super.attributesToDeclare.call(this));
};
RefundDetailsPaymentDetails_UIRecord.fromStructure = function (str) {
return new RefundDetailsPaymentDetails_UIRecord(new RefundDetailsPaymentDetails_UIRecord.RecordClass({
refundDetailsPaymentDetails_UIAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
RefundDetailsPaymentDetails_UIRecord._isAnonymousRecord = true;
RefundDetailsPaymentDetails_UIRecord.UniqueId = "ffc630bc-e3cb-eed0-2402-e2bc158867d9";
RefundDetailsPaymentDetails_UIRecord.init();
return RefundDetailsPaymentDetails_UIRecord;
})(OS.DataTypes.GenericRecord);
ShopperPortalEUModel.RefundDetailsPaymentDetails_UIRecord = RefundDetailsPaymentDetails_UIRecord;

});
define("ShopperPortalEU.model$RefundDetailsPaymentDetails_UIRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$RefundDetailsPaymentDetails_UIRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var RefundDetailsPaymentDetails_UIRecordList = (function (_super) {
__extends(RefundDetailsPaymentDetails_UIRecordList, _super);
function RefundDetailsPaymentDetails_UIRecordList(defaults) {
_super.apply(this, arguments);
}
RefundDetailsPaymentDetails_UIRecordList.itemType = ShopperPortalEUModel.RefundDetailsPaymentDetails_UIRecord;
return RefundDetailsPaymentDetails_UIRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.RefundDetailsPaymentDetails_UIRecordList = RefundDetailsPaymentDetails_UIRecordList;

});
define("ShopperPortalEU.model$CustomLinkOptionsIconList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsIconRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomLinkOptionsIconList = (function (_super) {
__extends(CustomLinkOptionsIconList, _super);
function CustomLinkOptionsIconList(defaults) {
_super.apply(this, arguments);
}
CustomLinkOptionsIconList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomLinkOptionsIconRec;
return CustomLinkOptionsIconList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomLinkOptionsIconList = CustomLinkOptionsIconList;

});
define("ShopperPortalEU.model$UnescapedHTMLOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$UnescapedHTMLOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var UnescapedHTMLOptionsList = (function (_super) {
__extends(UnescapedHTMLOptionsList, _super);
function UnescapedHTMLOptionsList(defaults) {
_super.apply(this, arguments);
}
UnescapedHTMLOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.UnescapedHTMLOptionsRec;
return UnescapedHTMLOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.UnescapedHTMLOptionsList = UnescapedHTMLOptionsList;

});
define("ShopperPortalEU.model$DatePickerOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$DatePickerOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var DatePickerOptionsRecordList = (function (_super) {
__extends(DatePickerOptionsRecordList, _super);
function DatePickerOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
DatePickerOptionsRecordList.itemType = ShopperPortalEUModel.DatePickerOptionsRecord;
return DatePickerOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.DatePickerOptionsRecordList = DatePickerOptionsRecordList;

});
define("ShopperPortalEU.model$CreditCardSwipeOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CreditCardSwipeOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CreditCardSwipeOptionsRecordList = (function (_super) {
__extends(CreditCardSwipeOptionsRecordList, _super);
function CreditCardSwipeOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CreditCardSwipeOptionsRecordList.itemType = ShopperPortalEUModel.CreditCardSwipeOptionsRecord;
return CreditCardSwipeOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CreditCardSwipeOptionsRecordList = CreditCardSwipeOptionsRecordList;

});
define("ShopperPortalEU.model$MenuElementOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Theme.model$MenuElementOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var MenuElementOptionsList = (function (_super) {
__extends(MenuElementOptionsList, _super);
function MenuElementOptionsList(defaults) {
_super.apply(this, arguments);
}
MenuElementOptionsList.itemType = ShopperPortalEU_UI_ThemeModel.MenuElementOptionsRec;
return MenuElementOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.MenuElementOptionsList = MenuElementOptionsList;

});
define("ShopperPortalEU.model$PostSiteverifyResponseRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$PostSiteverifyResponseRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var PostSiteverifyResponseRecordList = (function (_super) {
__extends(PostSiteverifyResponseRecordList, _super);
function PostSiteverifyResponseRecordList(defaults) {
_super.apply(this, arguments);
}
PostSiteverifyResponseRecordList.itemType = ShopperPortalEUModel.PostSiteverifyResponseRecord;
return PostSiteverifyResponseRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.PostSiteverifyResponseRecordList = PostSiteverifyResponseRecordList;

});
define("ShopperPortalEU.model$CountriesWithFlagsDropdownListRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CountriesWithFlagsDropdownListRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CountriesWithFlagsDropdownListRecordList = (function (_super) {
__extends(CountriesWithFlagsDropdownListRecordList, _super);
function CountriesWithFlagsDropdownListRecordList(defaults) {
_super.apply(this, arguments);
}
CountriesWithFlagsDropdownListRecordList.itemType = ShopperPortalEUModel.CountriesWithFlagsDropdownListRecord;
return CountriesWithFlagsDropdownListRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CountriesWithFlagsDropdownListRecordList = CountriesWithFlagsDropdownListRecordList;

});
define("ShopperPortalEU.model$CircleIconSizeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CircleIconSizeRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CircleIconSizeRecordList = (function (_super) {
__extends(CircleIconSizeRecordList, _super);
function CircleIconSizeRecordList(defaults) {
_super.apply(this, arguments);
}
CircleIconSizeRecordList.itemType = ShopperPortalEUModel.CircleIconSizeRecord;
return CircleIconSizeRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CircleIconSizeRecordList = CircleIconSizeRecordList;

});
define("ShopperPortalEU.model$CustomLinkStateRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomLinkStateRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomLinkStateRecordList = (function (_super) {
__extends(CustomLinkStateRecordList, _super);
function CustomLinkStateRecordList(defaults) {
_super.apply(this, arguments);
}
CustomLinkStateRecordList.itemType = ShopperPortalEUModel.CustomLinkStateRecord;
return CustomLinkStateRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomLinkStateRecordList = CustomLinkStateRecordList;

});
define("ShopperPortalEU.model$LabelValueOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$LabelValueOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var LabelValueOptionsList = (function (_super) {
__extends(LabelValueOptionsList, _super);
function LabelValueOptionsList(defaults) {
_super.apply(this, arguments);
}
LabelValueOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.LabelValueOptionsRec;
return LabelValueOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.LabelValueOptionsList = LabelValueOptionsList;

});
define("ShopperPortalEU.model$CustomRadioGroupOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomRadioGroupOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomRadioGroupOptionsList = (function (_super) {
__extends(CustomRadioGroupOptionsList, _super);
function CustomRadioGroupOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomRadioGroupOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomRadioGroupOptionsRec;
return CustomRadioGroupOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomRadioGroupOptionsList = CustomRadioGroupOptionsList;

});
define("ShopperPortalEU.model$FlexAlignList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$FlexAlignRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var FlexAlignList = (function (_super) {
__extends(FlexAlignList, _super);
function FlexAlignList(defaults) {
_super.apply(this, arguments);
}
FlexAlignList.itemType = ShopperPortalEU_UI_ComponentsModel.FlexAlignRec;
return FlexAlignList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.FlexAlignList = FlexAlignList;

});
define("ShopperPortalEU.model$AccessInfoList", ["exports", "OutSystems/ClientRuntime/Main", "Auth_Europe.model", "ShopperPortalEU.model", "Auth_Europe.model$AccessInfoRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$Auth_Europe"], function (exports, OutSystems, Auth_EuropeModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var AccessInfoList = (function (_super) {
__extends(AccessInfoList, _super);
function AccessInfoList(defaults) {
_super.apply(this, arguments);
}
AccessInfoList.itemType = Auth_EuropeModel.AccessInfoRec;
return AccessInfoList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.AccessInfoList = AccessInfoList;

});
define("ShopperPortalEU.model$BarcodeOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$BarcodeOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var BarcodeOptionsList = (function (_super) {
__extends(BarcodeOptionsList, _super);
function BarcodeOptionsList(defaults) {
_super.apply(this, arguments);
}
BarcodeOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.BarcodeOptionsRec;
return BarcodeOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.BarcodeOptionsList = BarcodeOptionsList;

});
define("ShopperPortalEU.model$ResponseList", ["exports", "OutSystems/ClientRuntime/Main", "reCAPTCHAReact.model", "ShopperPortalEU.model", "reCAPTCHAReact.model$ResponseRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$reCAPTCHAReact"], function (exports, OutSystems, reCAPTCHAReactModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var ResponseList = (function (_super) {
__extends(ResponseList, _super);
function ResponseList(defaults) {
_super.apply(this, arguments);
}
ResponseList.itemType = reCAPTCHAReactModel.ResponseRec;
return ResponseList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.ResponseList = ResponseList;

});
define("ShopperPortalEU.model$CustomColumnsItemOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomColumnsItemOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomColumnsItemOptionsList = (function (_super) {
__extends(CustomColumnsItemOptionsList, _super);
function CustomColumnsItemOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomColumnsItemOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomColumnsItemOptionsRec;
return CustomColumnsItemOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomColumnsItemOptionsList = CustomColumnsItemOptionsList;

});
define("ShopperPortalEU.model$CustomDropdownListValueOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomDropdownListValueOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomDropdownListValueOptionsList = (function (_super) {
__extends(CustomDropdownListValueOptionsList, _super);
function CustomDropdownListValueOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomDropdownListValueOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValueOptionsRec;
return CustomDropdownListValueOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomDropdownListValueOptionsList = CustomDropdownListValueOptionsList;

});
define("ShopperPortalEU.model$FormDetails_WrapperList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU.model", "ShopperPortalEU_Forms_IS.model$FormDetails_WrapperRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Forms_IS"], function (exports, OutSystems, ShopperPortalEU_Forms_ISModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var FormDetails_WrapperList = (function (_super) {
__extends(FormDetails_WrapperList, _super);
function FormDetails_WrapperList(defaults) {
_super.apply(this, arguments);
}
FormDetails_WrapperList.itemType = ShopperPortalEU_Forms_ISModel.FormDetails_WrapperRec;
return FormDetails_WrapperList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.FormDetails_WrapperList = FormDetails_WrapperList;

});
define("ShopperPortalEU.model$CustomButtonIconAlignmentRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomButtonIconAlignmentRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomButtonIconAlignmentRecordList = (function (_super) {
__extends(CustomButtonIconAlignmentRecordList, _super);
function CustomButtonIconAlignmentRecordList(defaults) {
_super.apply(this, arguments);
}
CustomButtonIconAlignmentRecordList.itemType = ShopperPortalEUModel.CustomButtonIconAlignmentRecord;
return CustomButtonIconAlignmentRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomButtonIconAlignmentRecordList = CustomButtonIconAlignmentRecordList;

});
define("ShopperPortalEU.model$CustomButtonIconAlignmentList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomButtonIconAlignmentRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomButtonIconAlignmentList = (function (_super) {
__extends(CustomButtonIconAlignmentList, _super);
function CustomButtonIconAlignmentList(defaults) {
_super.apply(this, arguments);
}
CustomButtonIconAlignmentList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomButtonIconAlignmentRec;
return CustomButtonIconAlignmentList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomButtonIconAlignmentList = CustomButtonIconAlignmentList;

});
define("ShopperPortalEU.model$CustomImageOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$CustomImageOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomImageOptionsRecordList = (function (_super) {
__extends(CustomImageOptionsRecordList, _super);
function CustomImageOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
CustomImageOptionsRecordList.itemType = ShopperPortalEUModel.CustomImageOptionsRecord;
return CustomImageOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomImageOptionsRecordList = CustomImageOptionsRecordList;

});
define("ShopperPortalEU.model$FlexOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$FlexOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var FlexOptionsRecordList = (function (_super) {
__extends(FlexOptionsRecordList, _super);
function FlexOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
FlexOptionsRecordList.itemType = ShopperPortalEUModel.FlexOptionsRecord;
return FlexOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.FlexOptionsRecordList = FlexOptionsRecordList;

});
define("ShopperPortalEU.model$MenuOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Theme.model$MenuOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme"], function (exports, OutSystems, ShopperPortalEU_UI_ThemeModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var MenuOptionsList = (function (_super) {
__extends(MenuOptionsList, _super);
function MenuOptionsList(defaults) {
_super.apply(this, arguments);
}
MenuOptionsList.itemType = ShopperPortalEU_UI_ThemeModel.MenuOptionsRec;
return MenuOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.MenuOptionsList = MenuOptionsList;

});
define("ShopperPortalEU.model$CodeInputValidationOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CodeInputValidationOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CodeInputValidationOptionsList = (function (_super) {
__extends(CodeInputValidationOptionsList, _super);
function CodeInputValidationOptionsList(defaults) {
_super.apply(this, arguments);
}
CodeInputValidationOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CodeInputValidationOptionsRec;
return CodeInputValidationOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CodeInputValidationOptionsList = CodeInputValidationOptionsList;

});
define("ShopperPortalEU.model$CityInfo_WrapperList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_API.model", "ShopperPortalEU.model", "ShopperPortalEU_API.model$CityInfo_WrapperRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_API"], function (exports, OutSystems, ShopperPortalEU_APIModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CityInfo_WrapperList = (function (_super) {
__extends(CityInfo_WrapperList, _super);
function CityInfo_WrapperList(defaults) {
_super.apply(this, arguments);
}
CityInfo_WrapperList.itemType = ShopperPortalEU_APIModel.CityInfo_WrapperRec;
return CityInfo_WrapperList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CityInfo_WrapperList = CityInfo_WrapperList;

});
define("ShopperPortalEU.model$MerchantLocationDTOList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$MerchantLocationDTORec"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var MerchantLocationDTOList = (function (_super) {
__extends(MerchantLocationDTOList, _super);
function MerchantLocationDTOList(defaults) {
_super.apply(this, arguments);
}
MerchantLocationDTOList.itemType = ShopperPortalEUModel.MerchantLocationDTORec;
return MerchantLocationDTOList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.MerchantLocationDTOList = MerchantLocationDTOList;

});
define("ShopperPortalEU.model$CustomPopupLayoutOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomPopupLayoutOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomPopupLayoutOptionsList = (function (_super) {
__extends(CustomPopupLayoutOptionsList, _super);
function CustomPopupLayoutOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomPopupLayoutOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomPopupLayoutOptionsRec;
return CustomPopupLayoutOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomPopupLayoutOptionsList = CustomPopupLayoutOptionsList;

});
define("ShopperPortalEU.model$DeleteCardRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$DeleteCardRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var DeleteCardRecordList = (function (_super) {
__extends(DeleteCardRecordList, _super);
function DeleteCardRecordList(defaults) {
_super.apply(this, arguments);
}
DeleteCardRecordList.itemType = ShopperPortalEUModel.DeleteCardRecord;
return DeleteCardRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.DeleteCardRecordList = DeleteCardRecordList;

});
define("ShopperPortalEU.model$CustomSeparatorStateList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomSeparatorStateRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomSeparatorStateList = (function (_super) {
__extends(CustomSeparatorStateList, _super);
function CustomSeparatorStateList(defaults) {
_super.apply(this, arguments);
}
CustomSeparatorStateList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomSeparatorStateRec;
return CustomSeparatorStateList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomSeparatorStateList = CustomSeparatorStateList;

});
define("ShopperPortalEU.model$RefundDetails_WrapperRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$RefundDetails_WrapperRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var RefundDetails_WrapperRecordList = (function (_super) {
__extends(RefundDetails_WrapperRecordList, _super);
function RefundDetails_WrapperRecordList(defaults) {
_super.apply(this, arguments);
}
RefundDetails_WrapperRecordList.itemType = ShopperPortalEUModel.RefundDetails_WrapperRecord;
return RefundDetails_WrapperRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.RefundDetails_WrapperRecordList = RefundDetails_WrapperRecordList;

});
define("ShopperPortalEU.model$MenuItemOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$MenuItemOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var MenuItemOptionsRecordList = (function (_super) {
__extends(MenuItemOptionsRecordList, _super);
function MenuItemOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
MenuItemOptionsRecordList.itemType = ShopperPortalEUModel.MenuItemOptionsRecord;
return MenuItemOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.MenuItemOptionsRecordList = MenuItemOptionsRecordList;

});
define("ShopperPortalEU.model$PhoneNumberInputOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$PhoneNumberInputOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var PhoneNumberInputOptionsRecordList = (function (_super) {
__extends(PhoneNumberInputOptionsRecordList, _super);
function PhoneNumberInputOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
PhoneNumberInputOptionsRecordList.itemType = ShopperPortalEUModel.PhoneNumberInputOptionsRecord;
return PhoneNumberInputOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.PhoneNumberInputOptionsRecordList = PhoneNumberInputOptionsRecordList;

});
define("ShopperPortalEU.model$CustomValidationMessageOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomValidationMessageOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomValidationMessageOptionsList = (function (_super) {
__extends(CustomValidationMessageOptionsList, _super);
function CustomValidationMessageOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomValidationMessageOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomValidationMessageOptionsRec;
return CustomValidationMessageOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomValidationMessageOptionsList = CustomValidationMessageOptionsList;

});
define("ShopperPortalEU.model$LayoutOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.model$LayoutOptionsRecord"], function (exports, OutSystems, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var LayoutOptionsRecordList = (function (_super) {
__extends(LayoutOptionsRecordList, _super);
function LayoutOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
LayoutOptionsRecordList.itemType = ShopperPortalEUModel.LayoutOptionsRecord;
return LayoutOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.LayoutOptionsRecordList = LayoutOptionsRecordList;

});
define("ShopperPortalEU.model$CustomIconOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model$CustomIconOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components"], function (exports, OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUModel) {
var OS = OutSystems.Internal;
var CustomIconOptionsList = (function (_super) {
__extends(CustomIconOptionsList, _super);
function CustomIconOptionsList(defaults) {
_super.apply(this, arguments);
}
CustomIconOptionsList.itemType = ShopperPortalEU_UI_ComponentsModel.CustomIconOptionsRec;
return CustomIconOptionsList;
})(OS.DataTypes.GenericRecordList);
ShopperPortalEUModel.CustomIconOptionsList = CustomIconOptionsList;

});
define("ShopperPortalEU.model", ["exports", "OutSystems/ClientRuntime/Main"], function (exports, OutSystems) {
var OS = OutSystems.Internal;
var ShopperPortalEUModel = exports;
Object.defineProperty(ShopperPortalEUModel, "module", {
get: function () {
return OS.ApplicationInfo.getModules()["a39a55b1-a77d-4201-9e63-13cf01c8ea2a"];
}
});

ShopperPortalEUModel.staticEntities = {};
ShopperPortalEUModel.staticEntities.sPFormStatus = {};
var getSPFormStatusRecord = function (record) {
return OS.ApplicationInfo.getModules()["5f9664ac-af6d-4553-af07-ef3e366dfe88"].staticEntities["fbf43fd7-21ba-4911-a301-a6b77599ca4c"][record];
};
Object.defineProperty(ShopperPortalEUModel.staticEntities.sPFormStatus, "preRefundClaimRejected", {
get: function () {
return getSPFormStatusRecord("027b4946-de19-47fc-8a1c-0ad444d807bf");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.sPFormStatus, "preRefundClaimOngoing", {
get: function () {
return getSPFormStatusRecord("04b06f22-59a4-49c0-80b5-23e30caa6e4f");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.sPFormStatus, "preCustomsInspectionRequired", {
get: function () {
return getSPFormStatusRecord("14cc82e2-957e-4f8f-a37d-a7900f51e536");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.sPFormStatus, "preRefundRevoked_RB8", {
get: function () {
return getSPFormStatusRecord("1f3ba60c-bc66-497f-97cd-efdc574874f5");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.sPFormStatus, "postRefundClaimRejected", {
get: function () {
return getSPFormStatusRecord("3366f6fe-154b-4c79-b6b0-8e492d1c0e70");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.sPFormStatus, "postRefundOnHold", {
get: function () {
return getSPFormStatusRecord("38c905a5-64ae-428b-9b4b-4d29d8fce714");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.sPFormStatus, "postRefundApproved_RA3", {
get: function () {
return getSPFormStatusRecord("3b8ce5ef-4cd9-4fba-8ab1-c51c5cfb3e0f");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.sPFormStatus, "preRefundRevoked_RB4", {
get: function () {
return getSPFormStatusRecord("43819221-0247-4c22-9f92-84232e50022c");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.sPFormStatus, "postRefundClaimCancelled_VA6", {
get: function () {
return getSPFormStatusRecord("4b5676ae-81ea-475f-9cb0-67d465a79d57");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.sPFormStatus, "refundClaimPending", {
get: function () {
return getSPFormStatusRecord("5048c975-e7a0-4391-9238-91f80c4e703a");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.sPFormStatus, "preRefundRevoked_RB7", {
get: function () {
return getSPFormStatusRecord("5907711b-d366-40fb-9d98-b8d78104fb2a");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.sPFormStatus, "postRefundClaimExpired_VA5", {
get: function () {
return getSPFormStatusRecord("5d1778de-efb7-4b9c-a4a3-9c03f08c7057");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.sPFormStatus, "preRefundClaimCompleted_RB3", {
get: function () {
return getSPFormStatusRecord("6cdc4424-31d8-4959-b9c2-15fcc045d0b9");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.sPFormStatus, "preRefundClaimCancelled", {
get: function () {
return getSPFormStatusRecord("78ce7dc6-d1e4-4114-bc3a-7c9b671710fa");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.sPFormStatus, "preGetCustomsApproval", {
get: function () {
return getSPFormStatusRecord("7e0f7c79-5177-43ce-aa5f-e8fb67db71ba");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.sPFormStatus, "postRefundClaimCancelled_RA9", {
get: function () {
return getSPFormStatusRecord("895a5bf8-72f2-45fb-b862-e918b4573e59");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.sPFormStatus, "postRefunded_RA7", {
get: function () {
return getSPFormStatusRecord("960ee4c6-05f6-4086-8b6c-4dd7dbfb8a42");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.sPFormStatus, "preUpdateRefundDetails", {
get: function () {
return getSPFormStatusRecord("99688444-4770-4b6f-9378-49e36e616939");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.sPFormStatus, "postRefundDetailsRequired", {
get: function () {
return getSPFormStatusRecord("ab960dd4-4691-4d84-8d20-c1bd43ce89e6");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.sPFormStatus, "postRefundClaimExpired_RA8", {
get: function () {
return getSPFormStatusRecord("b7be8186-c786-43f3-8972-b345ed28b995");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.sPFormStatus, "postGetCustomsApproval", {
get: function () {
return getSPFormStatusRecord("bb7d65af-552b-485c-954d-30006dd1fa8c");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.sPFormStatus, "postRefundApproved_RA11", {
get: function () {
return getSPFormStatusRecord("cf654140-6869-45df-a236-903380d51c7e");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.sPFormStatus, "postRefundInProgress", {
get: function () {
return getSPFormStatusRecord("d50d900f-2dad-4cd2-88fb-20446450a3f3");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.sPFormStatus, "postRefunded_RA10", {
get: function () {
return getSPFormStatusRecord("d960ec0f-1506-4c0b-aa07-8c388704e023");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.sPFormStatus, "preRefundClaimCompleted_RB6", {
get: function () {
return getSPFormStatusRecord("f2372b04-3269-4df2-8f6f-39e905fa97c6");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.sPFormStatus, "postCustomsInspectionRequired", {
get: function () {
return getSPFormStatusRecord("f36f9d17-5cd4-4bab-bc30-240b1e6d3a51");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.sPFormStatus, "postUpdateRefundDetails", {
get: function () {
return getSPFormStatusRecord("fd776400-6f57-44df-a1bf-ec7084dcd23a");
}
});

ShopperPortalEUModel.staticEntities.bannerType = {};
var getBannerTypeRecord = function (record) {
return OS.ApplicationInfo.getModules()["c65988d6-7505-42fe-87db-3f85bb4d520d"].staticEntities["463d4b7b-5e44-419e-a346-23e3a2e8ed75"][record];
};
Object.defineProperty(ShopperPortalEUModel.staticEntities.bannerType, "travel", {
get: function () {
return getBannerTypeRecord("8bcb6612-ea66-4999-935c-5d0d65ff50c1");
}
});

ShopperPortalEUModel.staticEntities.customMessageType = {};
var getCustomMessageTypeRecord = function (record) {
return OS.ApplicationInfo.getModules()["c65988d6-7505-42fe-87db-3f85bb4d520d"].staticEntities["4fe6b2fc-c2ed-4e3e-aa6e-3a8e162773aa"][record];
};
Object.defineProperty(ShopperPortalEUModel.staticEntities.customMessageType, "warning", {
get: function () {
return getCustomMessageTypeRecord("5f7c1c60-4966-4803-be86-87bc10007a33");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.customMessageType, "neutral", {
get: function () {
return getCustomMessageTypeRecord("90939e3e-5b5c-4e5b-a572-9a3f74a90f5d");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.customMessageType, "error", {
get: function () {
return getCustomMessageTypeRecord("992b9b75-b842-4a44-aa84-2d93c186f4b0");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.customMessageType, "success", {
get: function () {
return getCustomMessageTypeRecord("a901764b-8c93-4ac2-ba90-0c9148b14a61");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.customMessageType, "info", {
get: function () {
return getCustomMessageTypeRecord("cddffef1-8412-45e8-944c-4f8916c63e8a");
}
});

ShopperPortalEUModel.staticEntities.recaptchaTheme = {};
var getRecaptchaThemeRecord = function (record) {
return OS.ApplicationInfo.getModules()["ce1cf6a3-f9a3-4f8c-802b-1dffe8936086"].staticEntities["aa99bc77-8209-4a9b-b099-fd40d5cf48fc"][record];
};
Object.defineProperty(ShopperPortalEUModel.staticEntities.recaptchaTheme, "light", {
get: function () {
return getRecaptchaThemeRecord("66fffa5d-83fd-4750-abac-aa40e105c040");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.recaptchaTheme, "dark", {
get: function () {
return getRecaptchaThemeRecord("894951ca-9b25-40bb-bbb7-cb52e657ec2a");
}
});

ShopperPortalEUModel.staticEntities.recaptchaBadge = {};
var getRecaptchaBadgeRecord = function (record) {
return OS.ApplicationInfo.getModules()["ce1cf6a3-f9a3-4f8c-802b-1dffe8936086"].staticEntities["f84539a1-a65e-4250-a668-c7372b6b3f6e"][record];
};
Object.defineProperty(ShopperPortalEUModel.staticEntities.recaptchaBadge, "bottomRight", {
get: function () {
return getRecaptchaBadgeRecord("8aecdd60-fbec-4c03-8fe9-8cd3eb20d78a");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.recaptchaBadge, "bottomLeft", {
get: function () {
return getRecaptchaBadgeRecord("ba402e31-0fe5-4cc6-a8fb-78b27c869cdd");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.recaptchaBadge, "inline", {
get: function () {
return getRecaptchaBadgeRecord("de8828bc-1fe0-4d3e-8c31-7d9aabc6e805");
}
});

ShopperPortalEUModel.staticEntities.customTagState = {};
var getCustomTagStateRecord = function (record) {
return OS.ApplicationInfo.getModules()["e7bb7e26-af64-4f69-9436-0768d54ea01b"].staticEntities["0ecb397c-3ce5-471f-b18f-87158598df3a"][record];
};
Object.defineProperty(ShopperPortalEUModel.staticEntities.customTagState, "error", {
get: function () {
return getCustomTagStateRecord("04940de8-397c-4994-96fc-567cc3bb20b1");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.customTagState, "new", {
get: function () {
return getCustomTagStateRecord("2155d0da-5bf6-4aa3-93ff-4b1503152d74");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.customTagState, "success", {
get: function () {
return getCustomTagStateRecord("3ee16a50-b2ad-406b-957c-64848a014a00");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.customTagState, "neutral", {
get: function () {
return getCustomTagStateRecord("c0f27e66-d8bf-42e4-9a1a-3513dce3a21d");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.customTagState, "info", {
get: function () {
return getCustomTagStateRecord("c0f66ae5-a24d-4d28-ad01-728a7a41fea0");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.customTagState, "warning", {
get: function () {
return getCustomTagStateRecord("ccc52884-abd4-414f-bdfb-97412fa5bd64");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.customTagState, "neutralDark", {
get: function () {
return getCustomTagStateRecord("d89d1c3c-871e-4b16-8580-f20a79b9c223");
}
});

ShopperPortalEUModel.staticEntities.fullHeightContentAlignment = {};
var getFullHeightContentAlignmentRecord = function (record) {
return OS.ApplicationInfo.getModules()["e7bb7e26-af64-4f69-9436-0768d54ea01b"].staticEntities["275b2903-24c0-41da-bfca-19e4261c515f"][record];
};
Object.defineProperty(ShopperPortalEUModel.staticEntities.fullHeightContentAlignment, "end", {
get: function () {
return getFullHeightContentAlignmentRecord("1a4a4a52-89af-420b-826e-870139e0a764");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.fullHeightContentAlignment, "start", {
get: function () {
return getFullHeightContentAlignmentRecord("442c5a48-536b-4d15-9ceb-e0c0f8de7b89");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.fullHeightContentAlignment, "center", {
get: function () {
return getFullHeightContentAlignmentRecord("896ea577-e650-407b-99c3-a8e7a5a1d3a2");
}
});

ShopperPortalEUModel.staticEntities.customLinkIconAlignment = {};
var getCustomLinkIconAlignmentRecord = function (record) {
return OS.ApplicationInfo.getModules()["e7bb7e26-af64-4f69-9436-0768d54ea01b"].staticEntities["27df98a3-902b-455f-9703-410f19c4e19f"][record];
};
Object.defineProperty(ShopperPortalEUModel.staticEntities.customLinkIconAlignment, "right", {
get: function () {
return getCustomLinkIconAlignmentRecord("239358b2-c3ff-4402-b772-29f76cf4471e");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.customLinkIconAlignment, "left", {
get: function () {
return getCustomLinkIconAlignmentRecord("9f35fcbf-1ba0-4c3c-bb32-35d9ea26c3fc");
}
});

ShopperPortalEUModel.staticEntities.customIconFamily = {};
var getCustomIconFamilyRecord = function (record) {
return OS.ApplicationInfo.getModules()["e7bb7e26-af64-4f69-9436-0768d54ea01b"].staticEntities["3cac8f18-453c-4266-bac7-1e6a4c9a927d"][record];
};
Object.defineProperty(ShopperPortalEUModel.staticEntities.customIconFamily, "material", {
get: function () {
return getCustomIconFamilyRecord("6174a3e0-352f-4bd6-a3d8-02e7c57b11bc");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.customIconFamily, "planet", {
get: function () {
return getCustomIconFamilyRecord("df8e6450-0b1f-4ee9-b565-0c9de741e710");
}
});

ShopperPortalEUModel.staticEntities.customLinkType = {};
var getCustomLinkTypeRecord = function (record) {
return OS.ApplicationInfo.getModules()["e7bb7e26-af64-4f69-9436-0768d54ea01b"].staticEntities["3ded79d0-1eeb-4afc-9820-e2a9cd2f07ad"][record];
};
Object.defineProperty(ShopperPortalEUModel.staticEntities.customLinkType, "buttonPrimary", {
get: function () {
return getCustomLinkTypeRecord("26dc0d36-7d32-408a-b62e-57db318984b3");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.customLinkType, "buttonSecondary", {
get: function () {
return getCustomLinkTypeRecord("933bcf14-9342-44d1-b4d5-ea1788895732");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.customLinkType, "primary", {
get: function () {
return getCustomLinkTypeRecord("a60f4830-69c1-4149-b2f0-9dd655ee4749");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.customLinkType, "buttonReverse", {
get: function () {
return getCustomLinkTypeRecord("b6dd4bf3-2e25-4c18-a0b5-29c05e017b50");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.customLinkType, "ghost", {
get: function () {
return getCustomLinkTypeRecord("cf404bd0-1fb5-407c-8dd6-0b94939919ac");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.customLinkType, "secondary", {
get: function () {
return getCustomLinkTypeRecord("f665bf28-64f7-424d-9bc1-b7670a4a30f8");
}
});

ShopperPortalEUModel.staticEntities.customTimelineType = {};
var getCustomTimelineTypeRecord = function (record) {
return OS.ApplicationInfo.getModules()["e7bb7e26-af64-4f69-9436-0768d54ea01b"].staticEntities["4823f731-14b1-4c91-a901-6ef6cbf22f33"][record];
};
Object.defineProperty(ShopperPortalEUModel.staticEntities.customTimelineType, "redo", {
get: function () {
return getCustomTimelineTypeRecord("2b8fd845-df5b-4fa1-9da0-dcc51029cfb3");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.customTimelineType, "next", {
get: function () {
return getCustomTimelineTypeRecord("41004cbd-08c1-429e-8581-6b9bac99fa77");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.customTimelineType, "current", {
get: function () {
return getCustomTimelineTypeRecord("4f558cb6-300a-475e-be6c-93b45faf97e6");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.customTimelineType, "past", {
get: function () {
return getCustomTimelineTypeRecord("92d0b3aa-6c37-409c-8e33-d4084f94f11e");
}
});

ShopperPortalEUModel.staticEntities.justify = {};
var getJustifyRecord = function (record) {
return OS.ApplicationInfo.getModules()["e7bb7e26-af64-4f69-9436-0768d54ea01b"].staticEntities["611abea5-5a8a-4090-84d3-aa7203275f0b"][record];
};
Object.defineProperty(ShopperPortalEUModel.staticEntities.justify, "start", {
get: function () {
return getJustifyRecord("1b9b0ffb-2c5c-45d5-91ad-de6e564943fc");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.justify, "center", {
get: function () {
return getJustifyRecord("4e4a5e9d-6bbc-4cce-9d99-54c7b6abbbb7");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.justify, "end", {
get: function () {
return getJustifyRecord("c80bab53-af52-48b1-a544-95aa15113f22");
}
});

ShopperPortalEUModel.staticEntities.customIconSize = {};
var getCustomIconSizeRecord = function (record) {
return OS.ApplicationInfo.getModules()["e7bb7e26-af64-4f69-9436-0768d54ea01b"].staticEntities["61ccda77-5a92-45e8-9d19-9a6741575ccf"][record];
};
Object.defineProperty(ShopperPortalEUModel.staticEntities.customIconSize, "large", {
get: function () {
return getCustomIconSizeRecord("59be3f66-dacf-482a-8f70-2f16fe36af65");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.customIconSize, "extraSmall", {
get: function () {
return getCustomIconSizeRecord("6b0d7c1e-80e7-45f4-9532-04cf71317cf9");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.customIconSize, "small", {
get: function () {
return getCustomIconSizeRecord("a61035e3-7d0f-416c-9242-af27cde5b6ee");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.customIconSize, "base", {
get: function () {
return getCustomIconSizeRecord("de82cee7-2ecd-46fe-a554-5f2b265579c9");
}
});

ShopperPortalEUModel.staticEntities.customLinkState = {};
var getCustomLinkStateRecord = function (record) {
return OS.ApplicationInfo.getModules()["e7bb7e26-af64-4f69-9436-0768d54ea01b"].staticEntities["7c64bdb6-fc37-4fb1-9451-121ad1dbc22e"][record];
};
Object.defineProperty(ShopperPortalEUModel.staticEntities.customLinkState, "danger", {
get: function () {
return getCustomLinkStateRecord("2e521704-9eee-45b2-a57f-a56f19d6e677");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.customLinkState, "warning", {
get: function () {
return getCustomLinkStateRecord("90db5b14-f165-4a25-8be0-9621bb22a7e0");
}
});

ShopperPortalEUModel.staticEntities.customButtonState = {};
var getCustomButtonStateRecord = function (record) {
return OS.ApplicationInfo.getModules()["e7bb7e26-af64-4f69-9436-0768d54ea01b"].staticEntities["8b04d908-50f0-4f5a-952b-2f22c38a7acf"][record];
};
Object.defineProperty(ShopperPortalEUModel.staticEntities.customButtonState, "danger", {
get: function () {
return getCustomButtonStateRecord("3d3d7afd-db9e-44ca-aca3-808f1aaf320b");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.customButtonState, "warning", {
get: function () {
return getCustomButtonStateRecord("ca4d4eeb-e0c6-435f-b85b-c6a9f5d1efe2");
}
});

ShopperPortalEUModel.staticEntities.customButtonType = {};
var getCustomButtonTypeRecord = function (record) {
return OS.ApplicationInfo.getModules()["e7bb7e26-af64-4f69-9436-0768d54ea01b"].staticEntities["8c5a83db-2664-4f8f-8019-2297fbe82e1a"][record];
};
Object.defineProperty(ShopperPortalEUModel.staticEntities.customButtonType, "reverse", {
get: function () {
return getCustomButtonTypeRecord("1bd1b1dc-b4b5-48b7-86c8-759eee56a01e");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.customButtonType, "linkPrimary", {
get: function () {
return getCustomButtonTypeRecord("24f80528-798e-4118-b7ab-b91e4c8d27ea");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.customButtonType, "primary", {
get: function () {
return getCustomButtonTypeRecord("6d7431ba-62ac-4878-876c-0bde65e81bc6");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.customButtonType, "ghost", {
get: function () {
return getCustomButtonTypeRecord("7f50385b-81c3-4e07-bbb1-fa0d7a0cfaff");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.customButtonType, "linkSecondary", {
get: function () {
return getCustomButtonTypeRecord("87fc3e98-f356-4f50-85d2-e2798190fdd4");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.customButtonType, "secondary", {
get: function () {
return getCustomButtonTypeRecord("a3589a12-16b2-4aac-8068-e53e17db2fd8");
}
});

ShopperPortalEUModel.staticEntities.cardBackgroundType = {};
var getCardBackgroundTypeRecord = function (record) {
return OS.ApplicationInfo.getModules()["e7bb7e26-af64-4f69-9436-0768d54ea01b"].staticEntities["8d02131d-8a23-4884-8dca-814a70ac6143"][record];
};
Object.defineProperty(ShopperPortalEUModel.staticEntities.cardBackgroundType, "flight", {
get: function () {
return getCardBackgroundTypeRecord("714aa0d8-22e4-4608-95be-3b55efde18a2");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.cardBackgroundType, "refund", {
get: function () {
return getCardBackgroundTypeRecord("a4d45485-d42d-47ce-ac4e-6d374dc5b7ca");
}
});

ShopperPortalEUModel.staticEntities.customAlertType = {};
var getCustomAlertTypeRecord = function (record) {
return OS.ApplicationInfo.getModules()["e7bb7e26-af64-4f69-9436-0768d54ea01b"].staticEntities["9b912be9-9a66-474a-8adc-c5b38eefd9dd"][record];
};
Object.defineProperty(ShopperPortalEUModel.staticEntities.customAlertType, "neutral", {
get: function () {
return getCustomAlertTypeRecord("3d27974b-5ac6-45cc-afff-1473eadf8e5b");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.customAlertType, "success", {
get: function () {
return getCustomAlertTypeRecord("468b8403-942b-462e-b083-61b605c82abc");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.customAlertType, "error", {
get: function () {
return getCustomAlertTypeRecord("9be40092-2833-4c83-a952-4489b0703689");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.customAlertType, "warning", {
get: function () {
return getCustomAlertTypeRecord("c2dcecda-b999-4d18-a4cc-2e023db2826a");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.customAlertType, "info", {
get: function () {
return getCustomAlertTypeRecord("f6e56421-8df1-4572-9835-9c2ba19a4cc7");
}
});

ShopperPortalEUModel.staticEntities.circleIconSize = {};
var getCircleIconSizeRecord = function (record) {
return OS.ApplicationInfo.getModules()["e7bb7e26-af64-4f69-9436-0768d54ea01b"].staticEntities["b1869945-d2a5-4b6a-89cf-e4eb715d9fa7"][record];
};
Object.defineProperty(ShopperPortalEUModel.staticEntities.circleIconSize, "medium", {
get: function () {
return getCircleIconSizeRecord("a8d31fdd-40e0-4aa2-95fc-f7b637c3ea4d");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.circleIconSize, "large", {
get: function () {
return getCircleIconSizeRecord("bbed6181-4810-4df0-8d38-ff1229a33589");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.circleIconSize, "default", {
get: function () {
return getCircleIconSizeRecord("fa8ec6d0-0025-4dee-b81b-86c4e3f34c7d");
}
});

ShopperPortalEUModel.staticEntities.flexAlign = {};
var getFlexAlignRecord = function (record) {
return OS.ApplicationInfo.getModules()["e7bb7e26-af64-4f69-9436-0768d54ea01b"].staticEntities["b8e9386b-1b91-418d-9b78-e9d0fab2dbe8"][record];
};
Object.defineProperty(ShopperPortalEUModel.staticEntities.flexAlign, "center", {
get: function () {
return getFlexAlignRecord("9d2f074f-fee8-40cb-8295-186b001830c9");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.flexAlign, "start", {
get: function () {
return getFlexAlignRecord("cf0f97bd-db28-4fde-98a8-15d8d84e712b");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.flexAlign, "end", {
get: function () {
return getFlexAlignRecord("d11edd7a-4cb2-4027-b4b0-7ac006b3f796");
}
});

ShopperPortalEUModel.staticEntities.customSeparatorState = {};
var getCustomSeparatorStateRecord = function (record) {
return OS.ApplicationInfo.getModules()["e7bb7e26-af64-4f69-9436-0768d54ea01b"].staticEntities["c17edeb0-858e-475b-b1b8-37f726bcd95e"][record];
};
Object.defineProperty(ShopperPortalEUModel.staticEntities.customSeparatorState, "default", {
get: function () {
return getCustomSeparatorStateRecord("686aeb51-da93-4999-8b15-6aa3418ce28c");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.customSeparatorState, "lighter", {
get: function () {
return getCustomSeparatorStateRecord("7914e06d-14c2-4ab7-9fbd-a5c765e1052c");
}
});

ShopperPortalEUModel.staticEntities.flexDirection = {};
var getFlexDirectionRecord = function (record) {
return OS.ApplicationInfo.getModules()["e7bb7e26-af64-4f69-9436-0768d54ea01b"].staticEntities["c8f9728d-d6df-4153-8f27-e61678ea77a0"][record];
};
Object.defineProperty(ShopperPortalEUModel.staticEntities.flexDirection, "row", {
get: function () {
return getFlexDirectionRecord("3ae4da0b-63ea-492d-b71f-f775e3f93288");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.flexDirection, "columnReverse", {
get: function () {
return getFlexDirectionRecord("4d0cfd93-b5fe-4ac1-b9d9-a9ca9f64de31");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.flexDirection, "rowReverse", {
get: function () {
return getFlexDirectionRecord("bbd4c36d-5035-470c-8469-e830db667660");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.flexDirection, "column", {
get: function () {
return getFlexDirectionRecord("f461ffff-e107-428a-8ff1-11e997c220a5");
}
});

ShopperPortalEUModel.staticEntities.customValidationMessageState = {};
var getCustomValidationMessageStateRecord = function (record) {
return OS.ApplicationInfo.getModules()["e7bb7e26-af64-4f69-9436-0768d54ea01b"].staticEntities["cd28deba-4841-4daf-a31b-226171324958"][record];
};
Object.defineProperty(ShopperPortalEUModel.staticEntities.customValidationMessageState, "warning", {
get: function () {
return getCustomValidationMessageStateRecord("5f444ee1-234f-4bc0-9bc7-eb62ad095369");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.customValidationMessageState, "error", {
get: function () {
return getCustomValidationMessageStateRecord("76a3c1de-6513-4a8b-8299-0b7537b04735");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.customValidationMessageState, "success", {
get: function () {
return getCustomValidationMessageStateRecord("915a0210-dc25-4c06-a249-cb3d90441fe2");
}
});

ShopperPortalEUModel.staticEntities.cardStateType = {};
var getCardStateTypeRecord = function (record) {
return OS.ApplicationInfo.getModules()["e7bb7e26-af64-4f69-9436-0768d54ea01b"].staticEntities["cda633b3-44e4-4d03-b041-4ee42266a05a"][record];
};
Object.defineProperty(ShopperPortalEUModel.staticEntities.cardStateType, "warning", {
get: function () {
return getCardStateTypeRecord("2267ce4f-86c5-4534-9a05-9bc4c1a2b8a6");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.cardStateType, "success", {
get: function () {
return getCardStateTypeRecord("3358c40b-9c87-49f1-8f5a-cd589557c30e");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.cardStateType, "info", {
get: function () {
return getCardStateTypeRecord("9dce627a-d246-40cc-a52b-296c2b8e66e5");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.cardStateType, "error", {
get: function () {
return getCardStateTypeRecord("cb221e47-9ec7-4a77-af8c-f1208585d4c4");
}
});

ShopperPortalEUModel.staticEntities.codeInputState = {};
var getCodeInputStateRecord = function (record) {
return OS.ApplicationInfo.getModules()["e7bb7e26-af64-4f69-9436-0768d54ea01b"].staticEntities["ce00e3a6-a3cd-4660-89c4-de0800674aef"][record];
};
Object.defineProperty(ShopperPortalEUModel.staticEntities.codeInputState, "error", {
get: function () {
return getCodeInputStateRecord("30337f78-a9d9-4669-8c35-e38d7a62a512");
}
});

ShopperPortalEUModel.staticEntities.customButtonIconAlignment = {};
var getCustomButtonIconAlignmentRecord = function (record) {
return OS.ApplicationInfo.getModules()["e7bb7e26-af64-4f69-9436-0768d54ea01b"].staticEntities["e1049605-6162-45c0-85f6-6dd6976bc502"][record];
};
Object.defineProperty(ShopperPortalEUModel.staticEntities.customButtonIconAlignment, "right", {
get: function () {
return getCustomButtonIconAlignmentRecord("28784f91-9d54-4ace-bfc0-9fb69b8ac54e");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.customButtonIconAlignment, "left", {
get: function () {
return getCustomButtonIconAlignmentRecord("3e6ab0aa-bf1d-475c-bdb1-fb5d7a2c8ee0");
}
});

ShopperPortalEUModel.staticEntities.customInputAlignment = {};
var getCustomInputAlignmentRecord = function (record) {
return OS.ApplicationInfo.getModules()["e7bb7e26-af64-4f69-9436-0768d54ea01b"].staticEntities["ec2451cf-be71-47f2-b9dd-3285b941dafb"][record];
};
Object.defineProperty(ShopperPortalEUModel.staticEntities.customInputAlignment, "right", {
get: function () {
return getCustomInputAlignmentRecord("0d1dbf94-80f6-4fc2-b3ec-ad21eda284d7");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.customInputAlignment, "center", {
get: function () {
return getCustomInputAlignmentRecord("ebd102d3-8599-4d4d-9a6d-b2e033f438ee");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.customInputAlignment, "left", {
get: function () {
return getCustomInputAlignmentRecord("f08a937e-d0ad-41c1-9e43-8e24286b5404");
}
});

ShopperPortalEUModel.staticEntities.flexJustify = {};
var getFlexJustifyRecord = function (record) {
return OS.ApplicationInfo.getModules()["e7bb7e26-af64-4f69-9436-0768d54ea01b"].staticEntities["f0ae093d-265f-4f7c-9a9d-b1e6fc1c462e"][record];
};
Object.defineProperty(ShopperPortalEUModel.staticEntities.flexJustify, "spaceEvenly", {
get: function () {
return getFlexJustifyRecord("1841bbb4-f242-4e5a-a8e4-316b4f46d16f");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.flexJustify, "end", {
get: function () {
return getFlexJustifyRecord("2c834e3e-828b-444a-89c1-07d3a80fde5b");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.flexJustify, "spaceBetween", {
get: function () {
return getFlexJustifyRecord("337f5727-2160-4a6a-bf56-d3b0ce06d600");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.flexJustify, "start", {
get: function () {
return getFlexJustifyRecord("a18f1ed7-49c1-4621-ba05-878b7755951f");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.flexJustify, "center", {
get: function () {
return getFlexJustifyRecord("dfd66d6c-751a-4d79-833a-7a0bac1e8f97");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.flexJustify, "spaceAround", {
get: function () {
return getFlexJustifyRecord("ed58348f-9e1a-46c3-91a4-fac6ea8b0bfd");
}
});

ShopperPortalEUModel.staticEntities.customCardState = {};
var getCustomCardStateRecord = function (record) {
return OS.ApplicationInfo.getModules()["e7bb7e26-af64-4f69-9436-0768d54ea01b"].staticEntities["f7cf750e-f7cb-49ce-a9c0-60616b0a93f7"][record];
};
Object.defineProperty(ShopperPortalEUModel.staticEntities.customCardState, "info", {
get: function () {
return getCustomCardStateRecord("4485603b-f17d-439f-925e-e0785d10d8b7");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.customCardState, "error", {
get: function () {
return getCustomCardStateRecord("44dd481a-40e6-4b83-8346-58e06a8a633f");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.customCardState, "success", {
get: function () {
return getCustomCardStateRecord("b110272d-4692-4414-802b-47142369262b");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.customCardState, "inactive", {
get: function () {
return getCustomCardStateRecord("ba500e36-41d1-40b6-91e5-4c0cfdd50e05");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.customCardState, "warning", {
get: function () {
return getCustomCardStateRecord("dfe090fc-c277-47d0-a449-830e7270426b");
}
});

ShopperPortalEUModel.staticEntities.spacing = {};
var getSpacingRecord = function (record) {
return OS.ApplicationInfo.getModules()["e7bb7e26-af64-4f69-9436-0768d54ea01b"].staticEntities["fc23d15e-13f5-404c-960e-61d739e364fd"][record];
};
Object.defineProperty(ShopperPortalEUModel.staticEntities.spacing, "space6", {
get: function () {
return getSpacingRecord("0ecce298-a52a-4e15-b4cc-adad15e3614c");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.spacing, "space11", {
get: function () {
return getSpacingRecord("10bbed59-20f9-4c08-8390-7d7dd0c13779");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.spacing, "space9", {
get: function () {
return getSpacingRecord("30ea0ec9-d4db-498c-9462-f8ae7bb7a417");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.spacing, "space4", {
get: function () {
return getSpacingRecord("43217c61-8425-4bd8-bf20-364b8f21786a");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.spacing, "space1", {
get: function () {
return getSpacingRecord("86e5d5c7-011c-43ed-80ed-90d7080be0e6");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.spacing, "space3", {
get: function () {
return getSpacingRecord("8778abb9-572e-4cfa-8a1a-181350f6a7c2");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.spacing, "space8", {
get: function () {
return getSpacingRecord("88882ef4-8e95-4422-9ce2-6db61a769b76");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.spacing, "space12", {
get: function () {
return getSpacingRecord("8d947462-0124-4b32-b7fc-249f8995c8c4");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.spacing, "space10", {
get: function () {
return getSpacingRecord("99e552d0-70f0-4225-b5af-454f6231fc6b");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.spacing, "none", {
get: function () {
return getSpacingRecord("c9ea514c-8e2a-425e-9b4f-3542dd14d75f");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.spacing, "space5", {
get: function () {
return getSpacingRecord("ca0ae05c-3f6f-4ce2-a63e-2345ed4ab914");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.spacing, "space2", {
get: function () {
return getSpacingRecord("ee48a7d2-7f38-45c6-ad79-f9482625a1f2");
}
});

Object.defineProperty(ShopperPortalEUModel.staticEntities.spacing, "space7", {
get: function () {
return getSpacingRecord("f88ed216-e852-4a68-8f5e-c87f8ac31967");
}
});

});
