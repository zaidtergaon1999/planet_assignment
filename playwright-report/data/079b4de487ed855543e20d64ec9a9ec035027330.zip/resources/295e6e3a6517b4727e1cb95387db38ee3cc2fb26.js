define("reCAPTCHAReact.referencesHealth$HTTPRequestHandler", [], function () {
// Reference to producer 'HTTPRequestHandler' is OK.
});
define("reCAPTCHAReact.referencesHealth$ServiceCenter", [], function () {
// Reference to producer 'ServiceCenter' is OK.
});
define("reCAPTCHAReact.referencesHealth$Users", [], function () {
// Reference to producer 'Users' is OK.
});
define("reCAPTCHAReact.referencesHealth", [], function () {
});
