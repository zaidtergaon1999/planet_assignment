define("ShopperPortalEU_UI_Components.Private.MouseEvents.mvc$model", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("IsBound", "isBoundVar", "IsBound", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("MouseObj", "mouseObjVar", "MouseObj", true, false, OS.DataTypes.DataTypes.Object, function () {
return null;
}, false), 
this.attr("WidgetId", "widgetIdIn", "WidgetId", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, false), 
this.attr("_widgetIdInDataFetchStatus", "_widgetIdInDataFetchStatus", "_widgetIdInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("PreventDefaults", "preventDefaultsIn", "PreventDefaults", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return true;
}, false), 
this.attr("_preventDefaultsInDataFetchStatus", "_preventDefaultsInDataFetchStatus", "_preventDefaultsInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return false;
}
});

Model.prototype.setInputs = function (inputs) {
if("WidgetId" in inputs) {
this.variables.widgetIdIn = inputs.WidgetId;
if("_widgetIdInDataFetchStatus" in inputs) {
this.variables._widgetIdInDataFetchStatus = inputs._widgetIdInDataFetchStatus;
}

}

if("PreventDefaults" in inputs) {
this.variables.preventDefaultsIn = inputs.PreventDefaults;
if("_preventDefaultsInDataFetchStatus" in inputs) {
this.variables._preventDefaultsInDataFetchStatus = inputs._preventDefaultsInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "Private.MouseEvents");
});
define("ShopperPortalEU_UI_Components.Private.MouseEvents.mvc$view", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.controller", "react", "OutSystems/ReactView/Main", "ShopperPortalEU_UI_Components.Private.MouseEvents.mvc$model", "ShopperPortalEU_UI_Components.Private.MouseEvents.mvc$controller"], function (OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ComponentsController, React, OSView, ShopperPortalEU_UI_Components_Private_MouseEvents_mvc_model, ShopperPortalEU_UI_Components_Private_MouseEvents_mvc_controller) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            var thisIsInstanceOfSuper = this instanceof _super;
            if (thisIsInstanceOfSuper == false) {
                return;
            }

            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "Private.MouseEvents";
        View.getCssDependencies = function() {
            return [];
        };
        View.getJsDependencies = function() {
            return ["scripts/ShopperPortalEU_UI_Components.mouseTrack.js"];
        };
        View.getBlocks = function() {
            return [];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return ShopperPortalEU_UI_Components_Private_MouseEvents_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return ShopperPortalEU_UI_Components_Private_MouseEvents_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties());
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("ShopperPortalEU_UI_Components.Private.MouseEvents.mvc$controller", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.controller", "ShopperPortalEU_UI_Components.languageResources", "ShopperPortalEU_UI_Components.Private.MouseEvents.mvc$debugger", "ShopperPortalEU_UI_Components.Private.MouseEvents.mvc$controller.OnReady.BindEventsJS", "ShopperPortalEU_UI_Components.Private.MouseEvents.mvc$controller.OnDestroy.DestroyJS", "ShopperPortalEU_UI_Components.Private.MouseEvents.mvc$controller.OnParametersChanged.SetPreventDefaultJS"], function (OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ComponentsController, ShopperPortalEU_UI_ComponentsLanguageResources, ShopperPortalEU_UI_Components_Private_MouseEvents_mvc_Debugger, ShopperPortalEU_UI_Components_Private_MouseEvents_mvc_controller_OnReady_BindEventsJS, ShopperPortalEU_UI_Components_Private_MouseEvents_mvc_controller_OnDestroy_DestroyJS, ShopperPortalEU_UI_Components_Private_MouseEvents_mvc_controller_OnParametersChanged_SetPreventDefaultJS) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {
onStart$Action: function (xIn, yIn) {
xIn = (xIn === undefined) ? 0 : xIn;
yIn = (yIn === undefined) ? 0 : yIn;
return controller.executeActionInsideJSNode(controller._onStart$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(xIn, OS.DataTypes.DataTypes.Integer), OS.DataConversion.JSNodeParamConverter.from(yIn, OS.DataTypes.DataTypes.Integer)), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "OnStart");
},
onMove$Action: function (evtIn, xIn, yIn, offsetXIn, offsetYIn) {
evtIn = (evtIn === undefined) ? null : evtIn;
xIn = (xIn === undefined) ? 0 : xIn;
yIn = (yIn === undefined) ? 0 : yIn;
offsetXIn = (offsetXIn === undefined) ? 0 : offsetXIn;
offsetYIn = (offsetYIn === undefined) ? 0 : offsetYIn;
return controller.executeActionInsideJSNode(controller._onMove$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(evtIn, OS.DataTypes.DataTypes.Object), OS.DataConversion.JSNodeParamConverter.from(xIn, OS.DataTypes.DataTypes.Integer), OS.DataConversion.JSNodeParamConverter.from(yIn, OS.DataTypes.DataTypes.Integer), OS.DataConversion.JSNodeParamConverter.from(offsetXIn, OS.DataTypes.DataTypes.Integer), OS.DataConversion.JSNodeParamConverter.from(offsetYIn, OS.DataTypes.DataTypes.Integer)), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "OnMove");
},
onEnd$Action: function (xIn, yIn, offsetXIn, offsetYIn, timeTakenIn) {
xIn = (xIn === undefined) ? 0 : xIn;
yIn = (yIn === undefined) ? 0 : yIn;
offsetXIn = (offsetXIn === undefined) ? 0 : offsetXIn;
offsetYIn = (offsetYIn === undefined) ? 0 : offsetYIn;
timeTakenIn = (timeTakenIn === undefined) ? 0 : timeTakenIn;
return controller.executeActionInsideJSNode(controller._onEnd$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(xIn, OS.DataTypes.DataTypes.Integer), OS.DataConversion.JSNodeParamConverter.from(yIn, OS.DataTypes.DataTypes.Integer), OS.DataConversion.JSNodeParamConverter.from(offsetXIn, OS.DataTypes.DataTypes.Integer), OS.DataConversion.JSNodeParamConverter.from(offsetYIn, OS.DataTypes.DataTypes.Integer), OS.DataConversion.JSNodeParamConverter.from(timeTakenIn, OS.DataTypes.DataTypes.Integer)), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "OnEnd");
}
};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = false;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._onMove$Action = function (evtIn, xIn, yIn, offsetXIn, offsetYIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnMove");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.Private.MouseEvents.OnMove$vars"))());
vars.value.evtInLocal = evtIn;
vars.value.xInLocal = xIn;
vars.value.yInLocal = yIn;
vars.value.offsetXInLocal = offsetXIn;
vars.value.offsetYInLocal = offsetYIn;
varBag.callContext = callContext;
varBag.vars = vars;
OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:5BciGOvXDUm8OV7OEGB7pw:/NRWebFlows.r84yxAaI7UmCCc1n0vDBhg/NodesShownInESpaceTree.F213dqC25EqLqCbTkJFArw/ClientActions.5BciGOvXDUm8OV7OEGB7pw:EBOrbY+jNfffzILYrXo9rg", "ShopperPortalEU_UI_Components", "OnMove", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:px5tjr8c5ECDcErcNXa2ng", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:vVJjMpmi0EKnE0_sTPOQIA", callContext.id);
// Trigger Event: Move
return controller.move$Action(OS.BuiltinFunctions.integerToDecimal(vars.value.xInLocal), OS.BuiltinFunctions.integerToDecimal(vars.value.yInLocal), OS.BuiltinFunctions.integerToDecimal(vars.value.offsetXInLocal), OS.BuiltinFunctions.integerToDecimal(vars.value.offsetYInLocal), vars.value.evtInLocal, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:I7zWJmZ5X06Zy4VRHPziMQ", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:5BciGOvXDUm8OV7OEGB7pw", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:5BciGOvXDUm8OV7OEGB7pw", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("ShopperPortalEU_UI_Components.Private.MouseEvents.OnMove$vars", [{
name: "Evt",
attrName: "evtInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Object,
defaultValue: function () {
return null;
}
}, {
name: "X",
attrName: "xInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Integer,
defaultValue: function () {
return 0;
}
}, {
name: "Y",
attrName: "yInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Integer,
defaultValue: function () {
return 0;
}
}, {
name: "OffsetX",
attrName: "offsetXInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Integer,
defaultValue: function () {
return 0;
}
}, {
name: "OffsetY",
attrName: "offsetYInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Integer,
defaultValue: function () {
return 0;
}
}]);
Controller.prototype._onEnd$Action = function (xIn, yIn, offsetXIn, offsetYIn, timeTakenIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnEnd");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.Private.MouseEvents.OnEnd$vars"))());
vars.value.xInLocal = xIn;
vars.value.yInLocal = yIn;
vars.value.offsetXInLocal = offsetXIn;
vars.value.offsetYInLocal = offsetYIn;
vars.value.timeTakenInLocal = timeTakenIn;
varBag.callContext = callContext;
varBag.vars = vars;
OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:zBSwXiQw3UaajSQGj62jUQ:/NRWebFlows.r84yxAaI7UmCCc1n0vDBhg/NodesShownInESpaceTree.F213dqC25EqLqCbTkJFArw/ClientActions.zBSwXiQw3UaajSQGj62jUQ:6Rqhi6w5y_GzToxPRsQv+Q", "ShopperPortalEU_UI_Components", "OnEnd", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:BWWglf5+e0OynHQH8PxgyQ", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:yMqHfCSYi0OIW6u5YSn1fQ", callContext.id);
// Trigger Event: End
return controller.end$Action(OS.BuiltinFunctions.integerToDecimal(vars.value.xInLocal), OS.BuiltinFunctions.integerToDecimal(vars.value.yInLocal), OS.BuiltinFunctions.integerToDecimal(vars.value.offsetXInLocal), OS.BuiltinFunctions.integerToDecimal(vars.value.offsetYInLocal), OS.BuiltinFunctions.integerToDecimal(vars.value.timeTakenInLocal), callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:MRZI37XY2UKw9XK77jHxqw", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:zBSwXiQw3UaajSQGj62jUQ", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:zBSwXiQw3UaajSQGj62jUQ", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("ShopperPortalEU_UI_Components.Private.MouseEvents.OnEnd$vars", [{
name: "X",
attrName: "xInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Integer,
defaultValue: function () {
return 0;
}
}, {
name: "Y",
attrName: "yInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Integer,
defaultValue: function () {
return 0;
}
}, {
name: "OffsetX",
attrName: "offsetXInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Integer,
defaultValue: function () {
return 0;
}
}, {
name: "OffsetY",
attrName: "offsetYInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Integer,
defaultValue: function () {
return 0;
}
}, {
name: "TimeTaken",
attrName: "timeTakenInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Integer,
defaultValue: function () {
return 0;
}
}]);
Controller.prototype._onReady$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnReady");
callContext = controller.callContext(callContext);
var bindEventsJSResult = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.bindEventsJSResult = bindEventsJSResult;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:KWaug+tRp0uDbEAzRKurFw:/NRWebFlows.r84yxAaI7UmCCc1n0vDBhg/NodesShownInESpaceTree.F213dqC25EqLqCbTkJFArw/ClientActions.KWaug+tRp0uDbEAzRKurFw:i1FFaZBmWldqATbiDCYCPw", "ShopperPortalEU_UI_Components", "OnReady", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:MSvVkuNE7kehH8IMFrk0zg", callContext.id);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:ypaF9kJdyEWdfLsVWFlnPw", callContext.id);
bindEventsJSResult.value = controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_Private_MouseEvents_mvc_controller_OnReady_BindEventsJS, "BindEvents", "OnReady", {
PreventDefaults: OS.DataConversion.JSNodeParamConverter.to(model.variables.preventDefaultsIn, OS.DataTypes.DataTypes.Boolean),
WidgetId: OS.DataConversion.JSNodeParamConverter.to(model.variables.widgetIdIn, OS.DataTypes.DataTypes.Text),
isBound: OS.DataConversion.JSNodeParamConverter.to(false, OS.DataTypes.DataTypes.Boolean),
Obj: OS.DataConversion.JSNodeParamConverter.to(null, OS.DataTypes.DataTypes.Object)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.Private.MouseEvents.OnReady$bindEventsJSResult"))();
jsNodeResult.isBoundOut = OS.DataConversion.JSNodeParamConverter.from($parameters.isBound, OS.DataTypes.DataTypes.Boolean);
jsNodeResult.objOut = OS.DataConversion.JSNodeParamConverter.from($parameters.Obj, OS.DataTypes.DataTypes.Object);
return jsNodeResult;
}, {
OnStart: controller.clientActionProxies.onStart$Action,
OnMove: controller.clientActionProxies.onMove$Action,
OnEnd: controller.clientActionProxies.onEnd$Action
}, {});
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:UykUEStcL0OKaWCV8YJyXA", callContext.id);
// IsBound = BindEvents.isBound
model.variables.isBoundVar = bindEventsJSResult.value.isBoundOut;
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:UykUEStcL0OKaWCV8YJyXA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// MouseObj = BindEvents.Obj
model.variables.mouseObjVar = bindEventsJSResult.value.objOut;
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:ncrrwpfzs0GTRAuc9w8+LA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:KWaug+tRp0uDbEAzRKurFw", callContext.id);
}

};
Controller.registerVariableGroupType("ShopperPortalEU_UI_Components.Private.MouseEvents.OnReady$bindEventsJSResult", [{
name: "isBound",
attrName: "isBoundOut",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "Obj",
attrName: "objOut",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Object,
defaultValue: function () {
return null;
}
}]);
Controller.prototype._onDestroy$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnDestroy");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:H2pLoib3N0OR11Q4YGzCGA:/NRWebFlows.r84yxAaI7UmCCc1n0vDBhg/NodesShownInESpaceTree.F213dqC25EqLqCbTkJFArw/ClientActions.H2pLoib3N0OR11Q4YGzCGA:fMwdvKs7PBmVKy1J0yQqmw", "ShopperPortalEU_UI_Components", "OnDestroy", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:pR5tEHCQG0mZxYkEdAURtg", callContext.id);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:Q+0YPYRkuUSh4NKjTh2iVQ", callContext.id);
controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_Private_MouseEvents_mvc_controller_OnDestroy_DestroyJS, "Destroy", "OnDestroy", {
Obj: OS.DataConversion.JSNodeParamConverter.to(model.variables.mouseObjVar, OS.DataTypes.DataTypes.Object)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:2SEOn+IZzkKqE4Ylxm0wKA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:H2pLoib3N0OR11Q4YGzCGA", callContext.id);
}

};
Controller.prototype._onParametersChanged$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnParametersChanged");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:bbQ6pC8uOUOs5N7izZqD0Q:/NRWebFlows.r84yxAaI7UmCCc1n0vDBhg/NodesShownInESpaceTree.F213dqC25EqLqCbTkJFArw/ClientActions.bbQ6pC8uOUOs5N7izZqD0Q:OHkQgorIuj4WiT9WpUjN9w", "ShopperPortalEU_UI_Components", "OnParametersChanged", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:IcnT12dL4UKjD31Mq2_HKg", callContext.id);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:cMDB2dLvakSHXX4IROmmHw", callContext.id);
controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_Private_MouseEvents_mvc_controller_OnParametersChanged_SetPreventDefaultJS, "SetPreventDefault", "OnParametersChanged", {
Prevent: OS.DataConversion.JSNodeParamConverter.to(model.variables.preventDefaultsIn, OS.DataTypes.DataTypes.Boolean),
Obj: OS.DataConversion.JSNodeParamConverter.to(model.variables.mouseObjVar, OS.DataTypes.DataTypes.Object)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:GUI7US4prk2NoB31XGd1mQ", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:bbQ6pC8uOUOs5N7izZqD0Q", callContext.id);
}

};
Controller.prototype._onStart$Action = function (xIn, yIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnStart");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.Private.MouseEvents.OnStart$vars"))());
vars.value.xInLocal = xIn;
vars.value.yInLocal = yIn;
varBag.callContext = callContext;
varBag.vars = vars;
OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:CScY3fy7WEuOlr96CAeNFQ:/NRWebFlows.r84yxAaI7UmCCc1n0vDBhg/NodesShownInESpaceTree.F213dqC25EqLqCbTkJFArw/ClientActions.CScY3fy7WEuOlr96CAeNFQ:ILgvRZmA3yda4TuVOTtbwQ", "ShopperPortalEU_UI_Components", "OnStart", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:m++sT220U0ivSQf89c1tSw", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:7Xk4hWLiIEC34KBttjl2Uw", callContext.id);
// Trigger Event: Start
return controller.start$Action(OS.BuiltinFunctions.integerToDecimal(vars.value.xInLocal), OS.BuiltinFunctions.integerToDecimal(vars.value.yInLocal), callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:SXt5V8Zbh02paQRs5vSjVQ", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:CScY3fy7WEuOlr96CAeNFQ", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:CScY3fy7WEuOlr96CAeNFQ", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("ShopperPortalEU_UI_Components.Private.MouseEvents.OnStart$vars", [{
name: "X",
attrName: "xInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Integer,
defaultValue: function () {
return 0;
}
}, {
name: "Y",
attrName: "yInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Integer,
defaultValue: function () {
return 0;
}
}]);
Controller.prototype._onInitialize$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnInitialize");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:Q8F77t0qoEyl4rJy26qtdw:/NRWebFlows.r84yxAaI7UmCCc1n0vDBhg/NodesShownInESpaceTree.F213dqC25EqLqCbTkJFArw/ClientActions.Q8F77t0qoEyl4rJy26qtdw:2gCNJ1ekN6KrjUNmuOVgeA", "ShopperPortalEU_UI_Components", "OnInitialize", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:XsOSjrWiMU2tYN1Go8pa3w", callContext.id);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:Rl9uSY_IlkmFZoaU3MMi4w", callContext.id);
// IsBound = False
model.variables.isBoundVar = false;
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:7SOmvmwCi0GPaJ6jjAfyrw", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:Q8F77t0qoEyl4rJy26qtdw", callContext.id);
}

};

Controller.prototype.onMove$Action = function (evtIn, xIn, yIn, offsetXIn, offsetYIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onMove$Action, callContext, evtIn, xIn, yIn, offsetXIn, offsetYIn);

};
Controller.prototype.onEnd$Action = function (xIn, yIn, offsetXIn, offsetYIn, timeTakenIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onEnd$Action, callContext, xIn, yIn, offsetXIn, offsetYIn, timeTakenIn);

};
Controller.prototype.onReady$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onReady$Action, callContext);

};
Controller.prototype.onDestroy$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onDestroy$Action, callContext);

};
Controller.prototype.onParametersChanged$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onParametersChanged$Action, callContext);

};
Controller.prototype.onStart$Action = function (xIn, yIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onStart$Action, callContext, xIn, yIn);

};
Controller.prototype.onInitialize$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onInitialize$Action, callContext);

};
Controller.prototype.end$Action = function () {
return Promise.resolve();
};
Controller.prototype.move$Action = function () {
return Promise.resolve();
};
Controller.prototype.start$Action = function () {
return Promise.resolve();
};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:r84yxAaI7UmCCc1n0vDBhg:/NRWebFlows.r84yxAaI7UmCCc1n0vDBhg:w6dvmGti0C1iYa118KocVg", "ShopperPortalEU_UI_Components", "Private", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:F213dqC25EqLqCbTkJFArw:/NRWebFlows.r84yxAaI7UmCCc1n0vDBhg/NodesShownInESpaceTree.F213dqC25EqLqCbTkJFArw:Msj0RLc1LPkENfn7+5Do8g", "ShopperPortalEU_UI_Components", "MouseEvents", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:F213dqC25EqLqCbTkJFArw", callContext.id);
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:r84yxAaI7UmCCc1n0vDBhg", callContext.id);
};
Controller.prototype.onInitializeEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Private/MouseEvents On Initialize");
return controller.onInitialize$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onReadyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Private/MouseEvents On Ready");
return controller.onReady$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Private/MouseEvents On Destroy");
return controller.onDestroy$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onParametersChangedEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Private/MouseEvents On Parameters Changed");
return controller.onParametersChanged$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return ShopperPortalEU_UI_ComponentsController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, ShopperPortalEU_UI_ComponentsLanguageResources);
});
define("ShopperPortalEU_UI_Components.Private.MouseEvents.mvc$controller.OnReady.BindEventsJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var mouseTrack = new MouseTrack();
$parameters.isBound = false;

var el = document.getElementById($parameters.WidgetId);

if (el) {
    mouseTrack.init(el, $actions.OnStart, $actions.OnMove, $actions.OnEnd);
    mouseTrack.setPreventDefault($parameters.PreventDefaults);
    $parameters.isBound = true;
}


$parameters.Obj = mouseTrack;
};
});
define("ShopperPortalEU_UI_Components.Private.MouseEvents.mvc$controller.OnDestroy.DestroyJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.Obj.destroy();
};
});
define("ShopperPortalEU_UI_Components.Private.MouseEvents.mvc$controller.OnParametersChanged.SetPreventDefaultJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.Obj.setPreventDefault($parameters.Prevent);
};
});

define("ShopperPortalEU_UI_Components.Private.MouseEvents.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"SixCLtUucUqjGuhdQq47Ag": {
getter: function (varBag, idService) {
return varBag.vars.value.evtInLocal;
},
dataType: OS.DataTypes.DataTypes.Object
},
"DvgLp2aNrkmfnhJCbYvfVQ": {
getter: function (varBag, idService) {
return varBag.vars.value.xInLocal;
},
dataType: OS.DataTypes.DataTypes.Integer
},
"WbP8myiElUafJQ19qTrxaA": {
getter: function (varBag, idService) {
return varBag.vars.value.yInLocal;
},
dataType: OS.DataTypes.DataTypes.Integer
},
"eoM61xVEBEmBx6cGFJT3yQ": {
getter: function (varBag, idService) {
return varBag.vars.value.offsetXInLocal;
},
dataType: OS.DataTypes.DataTypes.Integer
},
"sO0j8dMLb02sazcV62RbdA": {
getter: function (varBag, idService) {
return varBag.vars.value.offsetYInLocal;
},
dataType: OS.DataTypes.DataTypes.Integer
},
"ZJq0M2CbI0e5xTpPU6gmvg": {
getter: function (varBag, idService) {
return varBag.vars.value.xInLocal;
},
dataType: OS.DataTypes.DataTypes.Integer
},
"gZGwUlqlFkycpNkWc15PMQ": {
getter: function (varBag, idService) {
return varBag.vars.value.yInLocal;
},
dataType: OS.DataTypes.DataTypes.Integer
},
"4ANOKKKPZkCSPdlDQXQq4w": {
getter: function (varBag, idService) {
return varBag.vars.value.offsetXInLocal;
},
dataType: OS.DataTypes.DataTypes.Integer
},
"qgr5R9r+wU2iByiGQlr1vA": {
getter: function (varBag, idService) {
return varBag.vars.value.offsetYInLocal;
},
dataType: OS.DataTypes.DataTypes.Integer
},
"ek1ZMTmVDEyvop4Omv2oIA": {
getter: function (varBag, idService) {
return varBag.vars.value.timeTakenInLocal;
},
dataType: OS.DataTypes.DataTypes.Integer
},
"ypaF9kJdyEWdfLsVWFlnPw": {
getter: function (varBag, idService) {
return varBag.bindEventsJSResult.value;
}
},
"Q+0YPYRkuUSh4NKjTh2iVQ": {
getter: function (varBag, idService) {
return varBag.destroyJSResult.value;
}
},
"cMDB2dLvakSHXX4IROmmHw": {
getter: function (varBag, idService) {
return varBag.setPreventDefaultJSResult.value;
}
},
"Ji1HiKOg5EeV9Q9diI8x7g": {
getter: function (varBag, idService) {
return varBag.vars.value.xInLocal;
},
dataType: OS.DataTypes.DataTypes.Integer
},
"mjT4wG3ntEaujvsRCsyGoA": {
getter: function (varBag, idService) {
return varBag.vars.value.yInLocal;
},
dataType: OS.DataTypes.DataTypes.Integer
},
"ytHOLkcIxkmVMnhms5Qvtg": {
getter: function (varBag, idService) {
return varBag.model.variables.isBoundVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"iqByAc0_FE6D3RzdFLw7AA": {
getter: function (varBag, idService) {
return varBag.model.variables.mouseObjVar;
},
dataType: OS.DataTypes.DataTypes.Object
},
"S2VInlGbJUudn2K0zqSbQA": {
getter: function (varBag, idService) {
return varBag.model.variables.widgetIdIn;
},
dataType: OS.DataTypes.DataTypes.Text
},
"T4lWz10rA0OFeKMixo9u4A": {
getter: function (varBag, idService) {
return varBag.model.variables.preventDefaultsIn;
},
dataType: OS.DataTypes.DataTypes.Boolean
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
