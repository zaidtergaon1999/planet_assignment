class headerAction {
  constructor(id, options) {
    this.element = document.getElementById(id);
    this.elements = {
      link: this.element.getElementsByTagName('a')[0] || this.element.getElementsByTagName('button')[0]
    };
    this.options = options;
    this._build();
  }
  _setProps() {
    if (this.elements.link) {
      if (this.options.testId) {
        this.elements.link.setAttribute('data-testid', this.options.testId);
      }
    }
  }
  _build() {
    this._setProps();
  }
}