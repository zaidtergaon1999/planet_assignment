define("ShopperPortalEU_UI_Components.referencesHealth$ServiceCenter", [], function () {
// Reference to producer 'ServiceCenter' is OK.
});
define("ShopperPortalEU_UI_Components.referencesHealth$ShopperPortalEU_IS", [], function () {
// Reference to producer 'ShopperPortalEU_IS' is OK.
});
define("ShopperPortalEU_UI_Components.referencesHealth$Users", [], function () {
// Reference to producer 'Users' is OK.
});
define("ShopperPortalEU_UI_Components.referencesHealth", [], function () {
});
