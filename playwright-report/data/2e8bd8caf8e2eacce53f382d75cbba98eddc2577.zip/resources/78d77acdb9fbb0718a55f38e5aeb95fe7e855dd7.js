define("reCAPTCHAReact.model$ResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "reCAPTCHAReact.model"], function (exports, OutSystems, reCAPTCHAReactModel) {
var OS = OutSystems.Internal;
var ResponseRec = (function (_super) {
__extends(ResponseRec, _super);
function ResponseRec(defaults) {
_super.apply(this, arguments);
}
ResponseRec.attributesToDeclare = function () {
return [
this.attr("Success", "successAttr", "Success", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return true;
}, true), 
this.attr("ErrorMessage", "errorMessageAttr", "ErrorMessage", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Token", "tokenAttr", "Token", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ResponseRec.init();
return ResponseRec;
})(OS.DataTypes.GenericRecord);
reCAPTCHAReactModel.ResponseRec = ResponseRec;

});
define("reCAPTCHAReact.model$ResponseRecord", ["exports", "OutSystems/ClientRuntime/Main", "reCAPTCHAReact.model", "reCAPTCHAReact.model$ResponseRec"], function (exports, OutSystems, reCAPTCHAReactModel) {
var OS = OutSystems.Internal;
var ResponseRecord = (function (_super) {
__extends(ResponseRecord, _super);
function ResponseRecord(defaults) {
_super.apply(this, arguments);
}
ResponseRecord.attributesToDeclare = function () {
return [
this.attr("Response", "responseAttr", "Response", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new reCAPTCHAReactModel.ResponseRec());
}, true, reCAPTCHAReactModel.ResponseRec)
].concat(_super.attributesToDeclare.call(this));
};
ResponseRecord.fromStructure = function (str) {
return new ResponseRecord(new ResponseRecord.RecordClass({
responseAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ResponseRecord._isAnonymousRecord = true;
ResponseRecord.UniqueId = "0079cc54-4607-cccf-549c-9c3a1d20eaf6";
ResponseRecord.init();
return ResponseRecord;
})(OS.DataTypes.GenericRecord);
reCAPTCHAReactModel.ResponseRecord = ResponseRecord;

});
define("reCAPTCHAReact.model$RecaptchaThemeRec", ["exports", "OutSystems/ClientRuntime/Main", "reCAPTCHAReact.model"], function (exports, OutSystems, reCAPTCHAReactModel) {
var OS = OutSystems.Internal;
var RecaptchaThemeRec = (function (_super) {
__extends(RecaptchaThemeRec, _super);
function RecaptchaThemeRec(defaults) {
_super.apply(this, arguments);
}
RecaptchaThemeRec.attributesToDeclare = function () {
return [
this.attr("Value", "valueAttr", "Value", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
RecaptchaThemeRec.fromStructure = function (str) {
return new RecaptchaThemeRec(new RecaptchaThemeRec.RecordClass({
valueAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
RecaptchaThemeRec.init();
return RecaptchaThemeRec;
})(OS.DataTypes.GenericRecord);
reCAPTCHAReactModel.RecaptchaThemeRec = RecaptchaThemeRec;

});
define("reCAPTCHAReact.model$RecaptchaSizeRec", ["exports", "OutSystems/ClientRuntime/Main", "reCAPTCHAReact.model"], function (exports, OutSystems, reCAPTCHAReactModel) {
var OS = OutSystems.Internal;
var RecaptchaSizeRec = (function (_super) {
__extends(RecaptchaSizeRec, _super);
function RecaptchaSizeRec(defaults) {
_super.apply(this, arguments);
}
RecaptchaSizeRec.attributesToDeclare = function () {
return [
this.attr("Value", "valueAttr", "Value", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
RecaptchaSizeRec.fromStructure = function (str) {
return new RecaptchaSizeRec(new RecaptchaSizeRec.RecordClass({
valueAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
RecaptchaSizeRec.init();
return RecaptchaSizeRec;
})(OS.DataTypes.GenericRecord);
reCAPTCHAReactModel.RecaptchaSizeRec = RecaptchaSizeRec;

});
define("reCAPTCHAReact.model$ResultRec", ["exports", "OutSystems/ClientRuntime/Main", "reCAPTCHAReact.model"], function (exports, OutSystems, reCAPTCHAReactModel) {
var OS = OutSystems.Internal;
var ResultRec = (function (_super) {
__extends(ResultRec, _super);
function ResultRec(defaults) {
_super.apply(this, arguments);
}
ResultRec.attributesToDeclare = function () {
return [
this.attr("Success", "successAttr", "Success", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return true;
}, true), 
this.attr("ErrorMessage", "errorMessageAttr", "ErrorMessage", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ResultRec.init();
return ResultRec;
})(OS.DataTypes.GenericRecord);
reCAPTCHAReactModel.ResultRec = ResultRec;

});
define("reCAPTCHAReact.model$ResultList", ["exports", "OutSystems/ClientRuntime/Main", "reCAPTCHAReact.model", "reCAPTCHAReact.model$ResultRec"], function (exports, OutSystems, reCAPTCHAReactModel) {
var OS = OutSystems.Internal;
var ResultList = (function (_super) {
__extends(ResultList, _super);
function ResultList(defaults) {
_super.apply(this, arguments);
}
ResultList.itemType = reCAPTCHAReactModel.ResultRec;
return ResultList;
})(OS.DataTypes.GenericRecordList);
reCAPTCHAReactModel.ResultList = ResultList;

});
define("reCAPTCHAReact.model$RecaptchaSizeRecord", ["exports", "OutSystems/ClientRuntime/Main", "reCAPTCHAReact.model", "reCAPTCHAReact.model$RecaptchaSizeRec"], function (exports, OutSystems, reCAPTCHAReactModel) {
var OS = OutSystems.Internal;
var RecaptchaSizeRecord = (function (_super) {
__extends(RecaptchaSizeRecord, _super);
function RecaptchaSizeRecord(defaults) {
_super.apply(this, arguments);
}
RecaptchaSizeRecord.attributesToDeclare = function () {
return [
this.attr("RecaptchaSize", "recaptchaSizeAttr", "RecaptchaSize", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new reCAPTCHAReactModel.RecaptchaSizeRec());
}, true, reCAPTCHAReactModel.RecaptchaSizeRec)
].concat(_super.attributesToDeclare.call(this));
};
RecaptchaSizeRecord.fromStructure = function (str) {
return new RecaptchaSizeRecord(new RecaptchaSizeRecord.RecordClass({
recaptchaSizeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
RecaptchaSizeRecord._isAnonymousRecord = true;
RecaptchaSizeRecord.UniqueId = "2c14fa18-9e07-036b-6a69-72a98d8ff884";
RecaptchaSizeRecord.init();
return RecaptchaSizeRecord;
})(OS.DataTypes.GenericRecord);
reCAPTCHAReactModel.RecaptchaSizeRecord = RecaptchaSizeRecord;

});
define("reCAPTCHAReact.model$RecaptchaSizeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "reCAPTCHAReact.model", "reCAPTCHAReact.model$RecaptchaSizeRecord"], function (exports, OutSystems, reCAPTCHAReactModel) {
var OS = OutSystems.Internal;
var RecaptchaSizeRecordList = (function (_super) {
__extends(RecaptchaSizeRecordList, _super);
function RecaptchaSizeRecordList(defaults) {
_super.apply(this, arguments);
}
RecaptchaSizeRecordList.itemType = reCAPTCHAReactModel.RecaptchaSizeRecord;
return RecaptchaSizeRecordList;
})(OS.DataTypes.GenericRecordList);
reCAPTCHAReactModel.RecaptchaSizeRecordList = RecaptchaSizeRecordList;

});
define("reCAPTCHAReact.model$RecaptchaThemeList", ["exports", "OutSystems/ClientRuntime/Main", "reCAPTCHAReact.model", "reCAPTCHAReact.model$RecaptchaThemeRec"], function (exports, OutSystems, reCAPTCHAReactModel) {
var OS = OutSystems.Internal;
var RecaptchaThemeList = (function (_super) {
__extends(RecaptchaThemeList, _super);
function RecaptchaThemeList(defaults) {
_super.apply(this, arguments);
}
RecaptchaThemeList.itemType = reCAPTCHAReactModel.RecaptchaThemeRec;
return RecaptchaThemeList;
})(OS.DataTypes.GenericRecordList);
reCAPTCHAReactModel.RecaptchaThemeList = RecaptchaThemeList;

});
define("reCAPTCHAReact.model$", ["exports", "OutSystems/ClientRuntime/Main", "reCAPTCHAReact.model"], function (exports, OutSystems, reCAPTCHAReactModel) {
var OS = OutSystems.Internal;
var TextList = (function (_super) {
__extends(TextList, _super);
function TextList(defaults) {
_super.apply(this, arguments);
}
TextList.itemType = OS.DataTypes.DataTypes.Text;
return TextList;
})(OS.DataTypes.GenericRecordList);
reCAPTCHAReactModel.TextList = TextList;

});
define("reCAPTCHAReact.model$PostSiteverifyResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "reCAPTCHAReact.model"], function (exports, OutSystems, reCAPTCHAReactModel) {
var OS = OutSystems.Internal;
var PostSiteverifyResponseRec = (function (_super) {
__extends(PostSiteverifyResponseRec, _super);
function PostSiteverifyResponseRec(defaults) {
_super.apply(this, arguments);
}
PostSiteverifyResponseRec.attributesToDeclare = function () {
return [
this.attr("Success", "successAttr", "success", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("Score", "scoreAttr", "score", false, false, OS.DataTypes.DataTypes.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("Action", "actionAttr", "action", false, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("Challenge_ts", "challenge_tsAttr", "challenge_ts", true, false, OS.DataTypes.DataTypes.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("Hostname", "hostnameAttr", "hostname", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true), 
this.attr("ErrorCodes", "errorCodesAttr", "error-codes", false, false, OS.DataTypes.DataTypes.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new OS.DataTypes.TextList());
}, true, OS.DataTypes.TextList)
].concat(_super.attributesToDeclare.call(this));
};
PostSiteverifyResponseRec.init();
return PostSiteverifyResponseRec;
})(OS.DataTypes.GenericRecord);
reCAPTCHAReactModel.PostSiteverifyResponseRec = PostSiteverifyResponseRec;

});
define("reCAPTCHAReact.model$PostSiteverifyResponseRecord", ["exports", "OutSystems/ClientRuntime/Main", "reCAPTCHAReact.model", "reCAPTCHAReact.model$PostSiteverifyResponseRec"], function (exports, OutSystems, reCAPTCHAReactModel) {
var OS = OutSystems.Internal;
var PostSiteverifyResponseRecord = (function (_super) {
__extends(PostSiteverifyResponseRecord, _super);
function PostSiteverifyResponseRecord(defaults) {
_super.apply(this, arguments);
}
PostSiteverifyResponseRecord.attributesToDeclare = function () {
return [
this.attr("PostSiteverifyResponse", "postSiteverifyResponseAttr", "PostSiteverifyResponse", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new reCAPTCHAReactModel.PostSiteverifyResponseRec());
}, true, reCAPTCHAReactModel.PostSiteverifyResponseRec)
].concat(_super.attributesToDeclare.call(this));
};
PostSiteverifyResponseRecord.fromStructure = function (str) {
return new PostSiteverifyResponseRecord(new PostSiteverifyResponseRecord.RecordClass({
postSiteverifyResponseAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
PostSiteverifyResponseRecord._isAnonymousRecord = true;
PostSiteverifyResponseRecord.UniqueId = "3e320baa-4526-8d27-7954-3bfdb317fdd1";
PostSiteverifyResponseRecord.init();
return PostSiteverifyResponseRecord;
})(OS.DataTypes.GenericRecord);
reCAPTCHAReactModel.PostSiteverifyResponseRecord = PostSiteverifyResponseRecord;

});
define("reCAPTCHAReact.model$ResponseRecordList", ["exports", "OutSystems/ClientRuntime/Main", "reCAPTCHAReact.model", "reCAPTCHAReact.model$ResponseRecord"], function (exports, OutSystems, reCAPTCHAReactModel) {
var OS = OutSystems.Internal;
var ResponseRecordList = (function (_super) {
__extends(ResponseRecordList, _super);
function ResponseRecordList(defaults) {
_super.apply(this, arguments);
}
ResponseRecordList.itemType = reCAPTCHAReactModel.ResponseRecord;
return ResponseRecordList;
})(OS.DataTypes.GenericRecordList);
reCAPTCHAReactModel.ResponseRecordList = ResponseRecordList;

});
define("reCAPTCHAReact.model$BooleanRecord", ["exports", "OutSystems/ClientRuntime/Main", "reCAPTCHAReact.model"], function (exports, OutSystems, reCAPTCHAReactModel) {
var OS = OutSystems.Internal;
var BooleanRecord = (function (_super) {
__extends(BooleanRecord, _super);
function BooleanRecord(defaults) {
_super.apply(this, arguments);
}
BooleanRecord.attributesToDeclare = function () {
return [
this.attr("AddErrorCallback", "addErrorCallbackAttr", "AddErrorCallback", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
BooleanRecord.fromStructure = function (str) {
return new BooleanRecord(new BooleanRecord.RecordClass({
addErrorCallbackAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
BooleanRecord._isAnonymousRecord = true;
BooleanRecord.UniqueId = "f05077a3-b416-6123-b24e-476f71932642";
BooleanRecord.init();
return BooleanRecord;
})(OS.DataTypes.GenericRecord);
reCAPTCHAReactModel.BooleanRecord = BooleanRecord;

});
define("reCAPTCHAReact.model$BooleanRecordList", ["exports", "OutSystems/ClientRuntime/Main", "reCAPTCHAReact.model", "reCAPTCHAReact.model$BooleanRecord"], function (exports, OutSystems, reCAPTCHAReactModel) {
var OS = OutSystems.Internal;
var BooleanRecordList = (function (_super) {
__extends(BooleanRecordList, _super);
function BooleanRecordList(defaults) {
_super.apply(this, arguments);
}
BooleanRecordList.itemType = reCAPTCHAReactModel.BooleanRecord;
return BooleanRecordList;
})(OS.DataTypes.GenericRecordList);
reCAPTCHAReactModel.BooleanRecordList = BooleanRecordList;

});
define("reCAPTCHAReact.model$RecaptchaBadgeRec", ["exports", "OutSystems/ClientRuntime/Main", "reCAPTCHAReact.model"], function (exports, OutSystems, reCAPTCHAReactModel) {
var OS = OutSystems.Internal;
var RecaptchaBadgeRec = (function (_super) {
__extends(RecaptchaBadgeRec, _super);
function RecaptchaBadgeRec(defaults) {
_super.apply(this, arguments);
}
RecaptchaBadgeRec.attributesToDeclare = function () {
return [
this.attr("Value", "valueAttr", "Value", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
RecaptchaBadgeRec.fromStructure = function (str) {
return new RecaptchaBadgeRec(new RecaptchaBadgeRec.RecordClass({
valueAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
RecaptchaBadgeRec.init();
return RecaptchaBadgeRec;
})(OS.DataTypes.GenericRecord);
reCAPTCHAReactModel.RecaptchaBadgeRec = RecaptchaBadgeRec;

});
define("reCAPTCHAReact.model$RecaptchaBadgeRecord", ["exports", "OutSystems/ClientRuntime/Main", "reCAPTCHAReact.model", "reCAPTCHAReact.model$RecaptchaBadgeRec"], function (exports, OutSystems, reCAPTCHAReactModel) {
var OS = OutSystems.Internal;
var RecaptchaBadgeRecord = (function (_super) {
__extends(RecaptchaBadgeRecord, _super);
function RecaptchaBadgeRecord(defaults) {
_super.apply(this, arguments);
}
RecaptchaBadgeRecord.attributesToDeclare = function () {
return [
this.attr("RecaptchaBadge", "recaptchaBadgeAttr", "RecaptchaBadge", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new reCAPTCHAReactModel.RecaptchaBadgeRec());
}, true, reCAPTCHAReactModel.RecaptchaBadgeRec)
].concat(_super.attributesToDeclare.call(this));
};
RecaptchaBadgeRecord.fromStructure = function (str) {
return new RecaptchaBadgeRecord(new RecaptchaBadgeRecord.RecordClass({
recaptchaBadgeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
RecaptchaBadgeRecord._isAnonymousRecord = true;
RecaptchaBadgeRecord.UniqueId = "c7eb6330-463d-3421-e14d-c18a2ede3ffb";
RecaptchaBadgeRecord.init();
return RecaptchaBadgeRecord;
})(OS.DataTypes.GenericRecord);
reCAPTCHAReactModel.RecaptchaBadgeRecord = RecaptchaBadgeRecord;

});
define("reCAPTCHAReact.model$RecaptchaBadgeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "reCAPTCHAReact.model", "reCAPTCHAReact.model$RecaptchaBadgeRecord"], function (exports, OutSystems, reCAPTCHAReactModel) {
var OS = OutSystems.Internal;
var RecaptchaBadgeRecordList = (function (_super) {
__extends(RecaptchaBadgeRecordList, _super);
function RecaptchaBadgeRecordList(defaults) {
_super.apply(this, arguments);
}
RecaptchaBadgeRecordList.itemType = reCAPTCHAReactModel.RecaptchaBadgeRecord;
return RecaptchaBadgeRecordList;
})(OS.DataTypes.GenericRecordList);
reCAPTCHAReactModel.RecaptchaBadgeRecordList = RecaptchaBadgeRecordList;

});
define("reCAPTCHAReact.model$RecaptchaSizeList", ["exports", "OutSystems/ClientRuntime/Main", "reCAPTCHAReact.model", "reCAPTCHAReact.model$RecaptchaSizeRec"], function (exports, OutSystems, reCAPTCHAReactModel) {
var OS = OutSystems.Internal;
var RecaptchaSizeList = (function (_super) {
__extends(RecaptchaSizeList, _super);
function RecaptchaSizeList(defaults) {
_super.apply(this, arguments);
}
RecaptchaSizeList.itemType = reCAPTCHAReactModel.RecaptchaSizeRec;
return RecaptchaSizeList;
})(OS.DataTypes.GenericRecordList);
reCAPTCHAReactModel.RecaptchaSizeList = RecaptchaSizeList;

});
define("reCAPTCHAReact.model$ResultRecord", ["exports", "OutSystems/ClientRuntime/Main", "reCAPTCHAReact.model", "reCAPTCHAReact.model$ResultRec"], function (exports, OutSystems, reCAPTCHAReactModel) {
var OS = OutSystems.Internal;
var ResultRecord = (function (_super) {
__extends(ResultRecord, _super);
function ResultRecord(defaults) {
_super.apply(this, arguments);
}
ResultRecord.attributesToDeclare = function () {
return [
this.attr("Result", "resultAttr", "Result", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new reCAPTCHAReactModel.ResultRec());
}, true, reCAPTCHAReactModel.ResultRec)
].concat(_super.attributesToDeclare.call(this));
};
ResultRecord.fromStructure = function (str) {
return new ResultRecord(new ResultRecord.RecordClass({
resultAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ResultRecord._isAnonymousRecord = true;
ResultRecord.UniqueId = "8037dfe8-8e0e-9b76-b1a9-791a6871471c";
ResultRecord.init();
return ResultRecord;
})(OS.DataTypes.GenericRecord);
reCAPTCHAReactModel.ResultRecord = ResultRecord;

});
define("reCAPTCHAReact.model$BooleanBooleanRecord", ["exports", "OutSystems/ClientRuntime/Main", "reCAPTCHAReact.model"], function (exports, OutSystems, reCAPTCHAReactModel) {
var OS = OutSystems.Internal;
var BooleanBooleanRecord = (function (_super) {
__extends(BooleanBooleanRecord, _super);
function BooleanBooleanRecord(defaults) {
_super.apply(this, arguments);
}
BooleanBooleanRecord.attributesToDeclare = function () {
return [
this.attr("AddErrorCallback", "addErrorCallbackAttr", "AddErrorCallback", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true), 
this.attr("AddExpiredCallback", "addExpiredCallbackAttr", "AddExpiredCallback", false, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
BooleanBooleanRecord._isAnonymousRecord = true;
BooleanBooleanRecord.UniqueId = "8c016635-72be-0761-773b-9980049a44b2";
BooleanBooleanRecord.init();
return BooleanBooleanRecord;
})(OS.DataTypes.GenericRecord);
reCAPTCHAReactModel.BooleanBooleanRecord = BooleanBooleanRecord;

});
define("reCAPTCHAReact.model$RecaptchaThemeRecord", ["exports", "OutSystems/ClientRuntime/Main", "reCAPTCHAReact.model", "reCAPTCHAReact.model$RecaptchaThemeRec"], function (exports, OutSystems, reCAPTCHAReactModel) {
var OS = OutSystems.Internal;
var RecaptchaThemeRecord = (function (_super) {
__extends(RecaptchaThemeRecord, _super);
function RecaptchaThemeRecord(defaults) {
_super.apply(this, arguments);
}
RecaptchaThemeRecord.attributesToDeclare = function () {
return [
this.attr("RecaptchaTheme", "recaptchaThemeAttr", "RecaptchaTheme", false, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new reCAPTCHAReactModel.RecaptchaThemeRec());
}, true, reCAPTCHAReactModel.RecaptchaThemeRec)
].concat(_super.attributesToDeclare.call(this));
};
RecaptchaThemeRecord.fromStructure = function (str) {
return new RecaptchaThemeRecord(new RecaptchaThemeRecord.RecordClass({
recaptchaThemeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
RecaptchaThemeRecord._isAnonymousRecord = true;
RecaptchaThemeRecord.UniqueId = "9170a0d1-87d2-521b-b928-aeecab9c72d1";
RecaptchaThemeRecord.init();
return RecaptchaThemeRecord;
})(OS.DataTypes.GenericRecord);
reCAPTCHAReactModel.RecaptchaThemeRecord = RecaptchaThemeRecord;

});
define("reCAPTCHAReact.model$ResultRecordList", ["exports", "OutSystems/ClientRuntime/Main", "reCAPTCHAReact.model", "reCAPTCHAReact.model$ResultRecord"], function (exports, OutSystems, reCAPTCHAReactModel) {
var OS = OutSystems.Internal;
var ResultRecordList = (function (_super) {
__extends(ResultRecordList, _super);
function ResultRecordList(defaults) {
_super.apply(this, arguments);
}
ResultRecordList.itemType = reCAPTCHAReactModel.ResultRecord;
return ResultRecordList;
})(OS.DataTypes.GenericRecordList);
reCAPTCHAReactModel.ResultRecordList = ResultRecordList;

});
define("reCAPTCHAReact.model$PostSiteverifyResponseList", ["exports", "OutSystems/ClientRuntime/Main", "reCAPTCHAReact.model", "reCAPTCHAReact.model$PostSiteverifyResponseRec"], function (exports, OutSystems, reCAPTCHAReactModel) {
var OS = OutSystems.Internal;
var PostSiteverifyResponseList = (function (_super) {
__extends(PostSiteverifyResponseList, _super);
function PostSiteverifyResponseList(defaults) {
_super.apply(this, arguments);
}
PostSiteverifyResponseList.itemType = reCAPTCHAReactModel.PostSiteverifyResponseRec;
return PostSiteverifyResponseList;
})(OS.DataTypes.GenericRecordList);
reCAPTCHAReactModel.PostSiteverifyResponseList = PostSiteverifyResponseList;

});
define("reCAPTCHAReact.model$RecaptchaThemeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "reCAPTCHAReact.model", "reCAPTCHAReact.model$RecaptchaThemeRecord"], function (exports, OutSystems, reCAPTCHAReactModel) {
var OS = OutSystems.Internal;
var RecaptchaThemeRecordList = (function (_super) {
__extends(RecaptchaThemeRecordList, _super);
function RecaptchaThemeRecordList(defaults) {
_super.apply(this, arguments);
}
RecaptchaThemeRecordList.itemType = reCAPTCHAReactModel.RecaptchaThemeRecord;
return RecaptchaThemeRecordList;
})(OS.DataTypes.GenericRecordList);
reCAPTCHAReactModel.RecaptchaThemeRecordList = RecaptchaThemeRecordList;

});
define("reCAPTCHAReact.model$BooleanBooleanRecordList", ["exports", "OutSystems/ClientRuntime/Main", "reCAPTCHAReact.model", "reCAPTCHAReact.model$BooleanBooleanRecord"], function (exports, OutSystems, reCAPTCHAReactModel) {
var OS = OutSystems.Internal;
var BooleanBooleanRecordList = (function (_super) {
__extends(BooleanBooleanRecordList, _super);
function BooleanBooleanRecordList(defaults) {
_super.apply(this, arguments);
}
BooleanBooleanRecordList.itemType = reCAPTCHAReactModel.BooleanBooleanRecord;
return BooleanBooleanRecordList;
})(OS.DataTypes.GenericRecordList);
reCAPTCHAReactModel.BooleanBooleanRecordList = BooleanBooleanRecordList;

});
define("reCAPTCHAReact.model$RecaptchaBadgeList", ["exports", "OutSystems/ClientRuntime/Main", "reCAPTCHAReact.model", "reCAPTCHAReact.model$RecaptchaBadgeRec"], function (exports, OutSystems, reCAPTCHAReactModel) {
var OS = OutSystems.Internal;
var RecaptchaBadgeList = (function (_super) {
__extends(RecaptchaBadgeList, _super);
function RecaptchaBadgeList(defaults) {
_super.apply(this, arguments);
}
RecaptchaBadgeList.itemType = reCAPTCHAReactModel.RecaptchaBadgeRec;
return RecaptchaBadgeList;
})(OS.DataTypes.GenericRecordList);
reCAPTCHAReactModel.RecaptchaBadgeList = RecaptchaBadgeList;

});
define("reCAPTCHAReact.model$PostSiteverifyResponseRecordList", ["exports", "OutSystems/ClientRuntime/Main", "reCAPTCHAReact.model", "reCAPTCHAReact.model$PostSiteverifyResponseRecord"], function (exports, OutSystems, reCAPTCHAReactModel) {
var OS = OutSystems.Internal;
var PostSiteverifyResponseRecordList = (function (_super) {
__extends(PostSiteverifyResponseRecordList, _super);
function PostSiteverifyResponseRecordList(defaults) {
_super.apply(this, arguments);
}
PostSiteverifyResponseRecordList.itemType = reCAPTCHAReactModel.PostSiteverifyResponseRecord;
return PostSiteverifyResponseRecordList;
})(OS.DataTypes.GenericRecordList);
reCAPTCHAReactModel.PostSiteverifyResponseRecordList = PostSiteverifyResponseRecordList;

});
define("reCAPTCHAReact.model$ResponseList", ["exports", "OutSystems/ClientRuntime/Main", "reCAPTCHAReact.model", "reCAPTCHAReact.model$ResponseRec"], function (exports, OutSystems, reCAPTCHAReactModel) {
var OS = OutSystems.Internal;
var ResponseList = (function (_super) {
__extends(ResponseList, _super);
function ResponseList(defaults) {
_super.apply(this, arguments);
}
ResponseList.itemType = reCAPTCHAReactModel.ResponseRec;
return ResponseList;
})(OS.DataTypes.GenericRecordList);
reCAPTCHAReactModel.ResponseList = ResponseList;

});
define("reCAPTCHAReact.model", ["exports", "OutSystems/ClientRuntime/Main"], function (exports, OutSystems) {
var OS = OutSystems.Internal;
var reCAPTCHAReactModel = exports;
Object.defineProperty(reCAPTCHAReactModel, "module", {
get: function () {
return OS.ApplicationInfo.getModules()["ce1cf6a3-f9a3-4f8c-802b-1dffe8936086"];
}
});

reCAPTCHAReactModel.staticEntities = {};
reCAPTCHAReactModel.staticEntities.recaptchaSize = {};
var getRecaptchaSizeRecord = function (record) {
return reCAPTCHAReactModel.module.staticEntities["aa5c5f18-85cd-47ad-87bd-ae9940b81d0b"][record];
};
Object.defineProperty(reCAPTCHAReactModel.staticEntities.recaptchaSize, "compact", {
get: function () {
return getRecaptchaSizeRecord("84c8d646-189a-43ae-bc5f-26f71abd38e8");
}
});

Object.defineProperty(reCAPTCHAReactModel.staticEntities.recaptchaSize, "normal", {
get: function () {
return getRecaptchaSizeRecord("8df08fc9-9743-4dbd-9632-489bc9291184");
}
});

reCAPTCHAReactModel.staticEntities.recaptchaTheme = {};
var getRecaptchaThemeRecord = function (record) {
return reCAPTCHAReactModel.module.staticEntities["aa99bc77-8209-4a9b-b099-fd40d5cf48fc"][record];
};
Object.defineProperty(reCAPTCHAReactModel.staticEntities.recaptchaTheme, "light", {
get: function () {
return getRecaptchaThemeRecord("66fffa5d-83fd-4750-abac-aa40e105c040");
}
});

Object.defineProperty(reCAPTCHAReactModel.staticEntities.recaptchaTheme, "dark", {
get: function () {
return getRecaptchaThemeRecord("894951ca-9b25-40bb-bbb7-cb52e657ec2a");
}
});

reCAPTCHAReactModel.staticEntities.recaptchaBadge = {};
var getRecaptchaBadgeRecord = function (record) {
return reCAPTCHAReactModel.module.staticEntities["f84539a1-a65e-4250-a668-c7372b6b3f6e"][record];
};
Object.defineProperty(reCAPTCHAReactModel.staticEntities.recaptchaBadge, "bottomRight", {
get: function () {
return getRecaptchaBadgeRecord("8aecdd60-fbec-4c03-8fe9-8cd3eb20d78a");
}
});

Object.defineProperty(reCAPTCHAReactModel.staticEntities.recaptchaBadge, "bottomLeft", {
get: function () {
return getRecaptchaBadgeRecord("ba402e31-0fe5-4cc6-a8fb-78b27c869cdd");
}
});

Object.defineProperty(reCAPTCHAReactModel.staticEntities.recaptchaBadge, "inline", {
get: function () {
return getRecaptchaBadgeRecord("de8828bc-1fe0-4d3e-8c31-7d9aabc6e805");
}
});

});
