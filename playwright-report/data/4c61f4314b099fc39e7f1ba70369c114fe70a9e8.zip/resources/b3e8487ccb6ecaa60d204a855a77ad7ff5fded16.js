class customDropdown {
  constructor(id, options, events, list) {
    this.class = "custom-dropdown";
    this.element = document.getElementById(id);
    this.elementsClasses = {
      custom: {
        value: this.class.concat('__custom-value'),
        dropdown: this.class.concat('__custom-dropdown'),
        search: this.class.concat('__search'),
        options: this.class.concat('__options'),
        option: this.class.concat('__option'),
        overlay: this.class.concat('__overlay')
      }
    };
    this.stateClasses = {
      disabled: this.class.concat('--disabled'),
      notValid: this.class.concat('--not-valid'),
      null: {
        dropdown: this.class.concat('--null-value'),
        option: this.elementsClasses.custom.option.concat('--null')
      },
      custom: {
        open: this.class.concat('--open'),
        empty: this.class.concat('--empty'),
        search: this.class.concat('--search'),
        noSearchResults: this.class.concat('--no-search-results'),
        optionSelected: this.elementsClasses.custom.option.concat('--selected'),
        optionHighlighted: this.elementsClasses.custom.option.concat('--highlighted'),
        optionHidden: this.elementsClasses.custom.option.concat('--hidden'),
      }
    };
    this.elements = {
      select: this.element.querySelector('select'),
      custom: {
        value: null,
        dropdown: null,
        search: null,
        options: null
      },
      overlay: this.element.lastElementChild
    };
    this.customOptions = {
      optionSelected: null,
      open: false,
      highlightedOption: null
    };
    this.listeners = {
      _optionClick: this._optionClick.bind(this),
      _customClick: this._customClick.bind(this),
      _search: this._search.bind(this),
      _hover: this._hover.bind(this),
      _focus: this._focus.bind(this),
      _blur: this._blur.bind(this),
      _openKeydown: this._openKeydown.bind(this),
      _keydown: this._keydown.bind(this),
      _changeNative: this._changeNative.bind(this),
      _overlayClick: this._overlayClick.bind(this),
      _setHeight: this._setHeight.bind(this),
      _scrollReset: this._scrollReset.bind(this)
    };
    this.options = options;
    this.events = events;
    this.list = list;
    this._build();
  }
  _scrollReset() {
    window.scrollTo(0, 0);
    this.elements.overlay.scrollIntoView();
  }
  _setHeight() {
    this.element.style.setProperty('--dropdown-height', this.elements.custom.dropdown.offsetHeight + 'px');
  }
  _close() {
    this.open = false;
    this.element.classList.remove(this.stateClasses.custom.open);
    document.body.removeEventListener('keydown', this.listeners._keydown);
    document.body.removeEventListener('keydown', this.listeners._openKeydown);
    this.elements.custom.value.focus();
    setTimeout(this.events.close, 200);
  }
  _open() {
    this.open = true;
    document.body.addEventListener('keydown', this.listeners._keydown);
    document.body.removeEventListener('keydown', this.listeners._openKeydown);
    this.events.open();
  }
  _checkNullNative() {
    this.elements.select.selectedOptions[0].text === this.options.null.text ? this.element.classList.add(this.stateClasses.null.dropdown) : this.element.classList.remove(this.stateClasses.null.dropdown);
  }
  _changeNative(e) {
    this._checkNullNative();
  }
  _overlayClick(e) {
    this._close();
  }
  _customClick(e) {
    e.stopPropagation();
    this.toggle();
  }
  _set(el) {
    this.events.customChange(JSON.stringify({
      value: el.dataset.value,
      text: el.dataset.text
    }));
    this._close();
  }
  _optionClick(e) {
    e.stopPropagation();
    this._set(e.target);
  }
   _scrollIntoView(el) {
    if (el && el.scrollIntoViewIfNeeded) {
      el.scrollIntoViewIfNeeded();
    }
  }
  _setHighlighted(el,s) {
    if (el) {
      if (this.customOptions.highlightedOption) {
        this.customOptions.highlightedOption.classList.remove(this.stateClasses.custom.optionHighlighted);
      }
      this.customOptions.highlightedOption = el;
      this.customOptions.highlightedOption.classList.add(this.stateClasses.custom.optionHighlighted);
      if(s){
        this._scrollIntoView(el);
      }
    }
  }
  _setFocus() {
    this.elements.custom.value.focus();
  }
  _focus(e) {
    document.body.addEventListener('keydown', this.listeners._openKeydown);
    this.elements.custom.value.addEventListener('blur', this.listeners._blur);
  }
  _hover(e) {
    e.stopPropagation();
    this._setHighlighted(e.currentTarget,false);
  }
  _blur(e) {
    document.body.removeEventListener('keydown', this.listeners._openKeydown);
    this.elements.custom.value.removeEventListener('blur', this.listeners._blur);
  }
  _goUp() {
    if (this.customOptions.highlightedOption) {
      let previous = Array.from(this.elements.custom.options.children).findLast((el, i) => i < Number(this.customOptions.highlightedOption.dataset.position) && !el.classList.contains(this.stateClasses.custom.optionHidden));
      previous = previous || Array.from(this.elements.custom.options.children).findLast(el => !el.classList.contains(this.stateClasses.custom.optionHidden));
      this._setHighlighted(previous,true);
    }
  }
  _goDown() {
    if (this.customOptions.highlightedOption) {
      let next = Array.from(this.elements.custom.options.children).find((el, i) => i > Number(this.customOptions.highlightedOption.dataset.position) && !el.classList.contains(this.stateClasses.custom.optionHidden));
      next = next || Array.from(this.elements.custom.options.children).find(el => !el.classList.contains(this.stateClasses.custom.optionHidden));
      this._setHighlighted(next,true);
    }
  }
  _openKeydown(e) {
    if (e.key === 'ArrowDown') {
      this._open();
      e.stopPropagation();
      e.preventDefault();
      document.body.removeEventListener('keydown', this.listeners._openKeydown);
    }
  }
  _keydown(e) {
    switch (e.key) {
      case 'Enter':
        this._set(this.customOptions.highlightedOption);
        e.preventDefault();
        e.stopPropagation();
        break;
      case 'ArrowDown':
        this._goDown();
        e.preventDefault();
        e.stopPropagation();
        break;
      case 'ArrowUp':
        this._goUp();
        e.preventDefault();
        e.stopPropagation();
        break;
      case 'Tab':
        this._close();
        e.stopPropagation();
        break;
      case 'Escape':
        this._close();
        this._setFocus();
        e.stopPropagation();
        e.preventDefault();
        break;
    }
  }
  _search(e) {
    if (e) {
      e.stopPropagation();
    }
    var hideAll = true;
    [...this.elements.custom.options.children].forEach(opt => {
      if (opt.dataset.text.toLowerCase().includes(this.elements.custom.search.value.toLowerCase())) {
        opt.classList.remove(this.stateClasses.custom.optionHidden);
        hideAll = false;
      } else {
        opt.classList.add(this.stateClasses.custom.optionHidden);
      }
    });
    if (hideAll) {
      this.element.classList.add(this.stateClasses.custom.noSearchResults);
    } else {
      this.element.classList.remove(this.stateClasses.custom.noSearchResults);
      this._setHighlighted(Array.from(this.elements.custom.options.children).find(x => !x.classList.contains(this.stateClasses.custom.optionHidden)),false);
    }
  }
  _setOptions() {
    if (this.elements.custom.options) {
      this.elements.custom.options.innerHTML = '';
    }
    this.customOptions.optionSelected = null;
    this.elements.custom.value.setAttribute('tabindex', this.elements.select.disabled ? -1 : 0);
    this.list.length >= 12 ? this.element.classList.add(this.stateClasses.custom.search) : this.element.classList.remove(this.stateClasses.custom.search);
    var list = this.list;
    if (this.options.null.text) {
      list = [this.options.null, ...list];
    }
    list.forEach((opt, i) => {
      let option = document.createElement('div');
      option.classList.add(this.elementsClasses.custom.option);
      option.dataset.value = opt.value;
      option.dataset.text = opt.text;
      option.dataset.position = i;
      option.innerText = option.dataset.text;
      if (option.innerText === this.elements.select.selectedOptions[0].text) {
        this.customOptions.optionSelected = option;
        option.classList.add(this.stateClasses.custom.optionSelected);
      }
      if (this.options.null.text && option.dataset.text === this.options.null.text) {
        option.classList.add(this.stateClasses.null.option);
      }
      option.addEventListener('mouseover', this.listeners._hover);
      option.addEventListener('click', this.listeners._optionClick);
      if (this.elements.custom.options) {
        this.elements.custom.options.append(option);
      }
    });
    if (this.element.classList.contains(this.stateClasses.custom.search) && this.elements.custom.search) {
      this._search();
    }
    list.length ? this.element.classList.remove(this.stateClasses.custom.empty) : this.element.classList.add(this.stateClasses.custom.empty);
    if (this.customOptions.optionSelected) {
      this.elements.custom.value.innerText = this.customOptions.optionSelected.dataset.text;
      this.customOptions.optionSelected.classList.contains(this.stateClasses.null.option) ? this.element.classList.add(this.stateClasses.null.dropdown) : this.element.classList.remove(this.stateClasses.null.dropdown);
      this._setHighlighted(this.customOptions.optionSelected,true);
    }
  }
  _updateCustom() {
    if (!this.options.native) {
      this._setOptions();
    }
  }
  _buildCustom() {
    if (!this.options.native) {
      this.elements.custom.value = this.element.getElementsByClassName(this.elementsClasses.custom.value)[0];
      this.elements.custom.value.addEventListener('click', this.listeners._customClick);
      this.elements.custom.value.addEventListener('focus', this.listeners._focus);
      this.elements.overlay.addEventListener('click', this.listeners._overlayClick);
      this._setOptions();
    }
  }
  _dropdownAttributes() {
    this.elements.select.disabled ? this.element.classList.add(this.stateClasses.disabled) : this.element.classList.remove(this.stateClasses.disabled);
    this.elements.select.parentElement.classList.contains('not-valid') ? this.element.classList.add(this.stateClasses.notValid) : this.element.classList.remove(this.stateClasses.notValid);
    this.options.testId ? this.elements.select.setAttribute('data-testid', this.options.testId) : this.elements.select.removeAttribute('data-testid');
  }
  _setNull() {
    if (this.options.null.text) {
      if (this.options.native) {
        this.elements.select.removeEventListener('change', this.listeners._changeNative);
        let nullOption = [...this.elements.select.options].find(x => x.text === this.options.null.text);
        if (nullOption) {
          this.elements.select.addEventListener('change', this.listeners._changeNative);
          nullOption.classList.add(this.stateClasses.null.option);
          this._checkNullNative();
        }
      }
    }
  }
  _build() {
    this._dropdownAttributes();
    this._setNull();
    this._buildCustom();
  }
  dropdownRendered() {
    this.elements.custom.dropdown = this.element.getElementsByClassName(this.elementsClasses.custom.dropdown)[0];
    this.elements.custom.search = this.element.querySelector('.' + this.elementsClasses.custom.search + ' [data-input]');
    this.elements.custom.options = this.element.getElementsByClassName(this.elementsClasses.custom.options)[0];
    this.elements.custom.search.addEventListener('input', this.listeners._search);
    if (this.elements.custom.search && this.list.length) {
      this.elements.custom.search.focus();
      setTimeout(this.listeners._scrollReset, 400);
    }
    setTimeout(this.listeners._setHeight, 0);
    this._setOptions();
    this.element.classList.add(this.stateClasses.custom.open);
  }
  toggle() {
    this.open ? this._close() : this._open();
  }
  destroy() {
    if (!this.options.native) {
      document.body.removeEventListener('keydown', this.listeners._keydown);
      document.body.removeEventListener('keydown', this.listeners._openKeydown);
    }
  }
  render() {
    this._dropdownAttributes();
    this._setNull();
    this._updateCustom();
  }
  parametersChanged(options, list) {
    this.options = options;
    this.list = list;
  }
}