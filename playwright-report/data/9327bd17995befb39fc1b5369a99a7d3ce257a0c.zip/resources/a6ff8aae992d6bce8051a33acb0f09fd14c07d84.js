define("ShopperPortalEU_UI_Components.Private.TouchEvents.mvc$model", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model"], function (OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("IsBound", "isBoundVar", "IsBound", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("GestureObj", "gestureObjVar", "GestureObj", true, false, OS.DataTypes.DataTypes.Object, function () {
return null;
}, false), 
this.attr("WidgetId", "widgetIdIn", "WidgetId", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, false), 
this.attr("_widgetIdInDataFetchStatus", "_widgetIdInDataFetchStatus", "_widgetIdInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("PreventDefaults", "preventDefaultsIn", "PreventDefaults", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return true;
}, false), 
this.attr("_preventDefaultsInDataFetchStatus", "_preventDefaultsInDataFetchStatus", "_preventDefaultsInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return false;
}
});

Model.prototype.setInputs = function (inputs) {
if("WidgetId" in inputs) {
this.variables.widgetIdIn = inputs.WidgetId;
if("_widgetIdInDataFetchStatus" in inputs) {
this.variables._widgetIdInDataFetchStatus = inputs._widgetIdInDataFetchStatus;
}

}

if("PreventDefaults" in inputs) {
this.variables.preventDefaultsIn = inputs.PreventDefaults;
if("_preventDefaultsInDataFetchStatus" in inputs) {
this.variables._preventDefaultsInDataFetchStatus = inputs._preventDefaultsInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "Private.TouchEvents");
});
define("ShopperPortalEU_UI_Components.Private.TouchEvents.mvc$view", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.controller", "react", "OutSystems/ReactView/Main", "ShopperPortalEU_UI_Components.Private.TouchEvents.mvc$model", "ShopperPortalEU_UI_Components.Private.TouchEvents.mvc$controller"], function (OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ComponentsController, React, OSView, ShopperPortalEU_UI_Components_Private_TouchEvents_mvc_model, ShopperPortalEU_UI_Components_Private_TouchEvents_mvc_controller) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            var thisIsInstanceOfSuper = this instanceof _super;
            if (thisIsInstanceOfSuper == false) {
                return;
            }

            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "Private.TouchEvents";
        View.getCssDependencies = function() {
            return [];
        };
        View.getJsDependencies = function() {
            return ["scripts/ShopperPortalEU_UI_Components.TouchTrack.js"];
        };
        View.getBlocks = function() {
            return [];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return ShopperPortalEU_UI_Components_Private_TouchEvents_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return ShopperPortalEU_UI_Components_Private_TouchEvents_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), $if(false, false, this, function () {
return [];
}, function () {
return [];
}));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("ShopperPortalEU_UI_Components.Private.TouchEvents.mvc$controller", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.controller", "ShopperPortalEU_UI_Components.languageResources", "ShopperPortalEU_UI_Components.Private.TouchEvents.mvc$debugger", "ShopperPortalEU_UI_Components.Private.TouchEvents.mvc$controller.OnDestroy.DestroyJS", "ShopperPortalEU_UI_Components.Private.TouchEvents.mvc$controller.OnReady.BindEventsJS", "ShopperPortalEU_UI_Components.Private.TouchEvents.mvc$controller.OnParametersChanged.SetPreventDefaultJS"], function (OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ComponentsController, ShopperPortalEU_UI_ComponentsLanguageResources, ShopperPortalEU_UI_Components_Private_TouchEvents_mvc_Debugger, ShopperPortalEU_UI_Components_Private_TouchEvents_mvc_controller_OnDestroy_DestroyJS, ShopperPortalEU_UI_Components_Private_TouchEvents_mvc_controller_OnReady_BindEventsJS, ShopperPortalEU_UI_Components_Private_TouchEvents_mvc_controller_OnParametersChanged_SetPreventDefaultJS) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {
onStart$Action: function (xIn, yIn) {
xIn = (xIn === undefined) ? 0 : xIn;
yIn = (yIn === undefined) ? 0 : yIn;
return controller.executeActionInsideJSNode(controller._onStart$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(xIn, OS.DataTypes.DataTypes.Integer), OS.DataConversion.JSNodeParamConverter.from(yIn, OS.DataTypes.DataTypes.Integer)), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "OnStart");
},
onMove$Action: function (evtIn, xIn, yIn, offsetXIn, offsetYIn) {
evtIn = (evtIn === undefined) ? null : evtIn;
xIn = (xIn === undefined) ? 0 : xIn;
yIn = (yIn === undefined) ? 0 : yIn;
offsetXIn = (offsetXIn === undefined) ? 0 : offsetXIn;
offsetYIn = (offsetYIn === undefined) ? 0 : offsetYIn;
return controller.executeActionInsideJSNode(controller._onMove$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(evtIn, OS.DataTypes.DataTypes.Object), OS.DataConversion.JSNodeParamConverter.from(xIn, OS.DataTypes.DataTypes.Integer), OS.DataConversion.JSNodeParamConverter.from(yIn, OS.DataTypes.DataTypes.Integer), OS.DataConversion.JSNodeParamConverter.from(offsetXIn, OS.DataTypes.DataTypes.Integer), OS.DataConversion.JSNodeParamConverter.from(offsetYIn, OS.DataTypes.DataTypes.Integer)), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "OnMove");
},
onEnd$Action: function (xIn, yIn, offsetXIn, offsetYIn, timeTakenIn) {
xIn = (xIn === undefined) ? 0 : xIn;
yIn = (yIn === undefined) ? 0 : yIn;
offsetXIn = (offsetXIn === undefined) ? 0 : offsetXIn;
offsetYIn = (offsetYIn === undefined) ? 0 : offsetYIn;
timeTakenIn = (timeTakenIn === undefined) ? 0 : timeTakenIn;
return controller.executeActionInsideJSNode(controller._onEnd$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(xIn, OS.DataTypes.DataTypes.Integer), OS.DataConversion.JSNodeParamConverter.from(yIn, OS.DataTypes.DataTypes.Integer), OS.DataConversion.JSNodeParamConverter.from(offsetXIn, OS.DataTypes.DataTypes.Integer), OS.DataConversion.JSNodeParamConverter.from(offsetYIn, OS.DataTypes.DataTypes.Integer), OS.DataConversion.JSNodeParamConverter.from(timeTakenIn, OS.DataTypes.DataTypes.Integer)), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "OnEnd");
}
};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = false;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._onDestroy$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnDestroy");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:kvAVO4OARkOSmR2t1EFJNA:/NRWebFlows.r84yxAaI7UmCCc1n0vDBhg/NodesShownInESpaceTree.U2xLBAAB_06fn9bjTQqqnQ/ClientActions.kvAVO4OARkOSmR2t1EFJNA:wg0ybS4y7xJBB5Zw8+BP1g", "ShopperPortalEU_UI_Components", "OnDestroy", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:CLIMBOjIbEmU00JUij78cA", callContext.id);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:Pk44xOQ6dE+byV0jl7Po4g", callContext.id);
controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_Private_TouchEvents_mvc_controller_OnDestroy_DestroyJS, "Destroy", "OnDestroy", {
Obj: OS.DataConversion.JSNodeParamConverter.to(model.variables.gestureObjVar, OS.DataTypes.DataTypes.Object)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:e5DbxcCxX02FO47Whj7vAQ", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:kvAVO4OARkOSmR2t1EFJNA", callContext.id);
}

};
Controller.prototype._onMove$Action = function (evtIn, xIn, yIn, offsetXIn, offsetYIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnMove");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.Private.TouchEvents.OnMove$vars"))());
vars.value.evtInLocal = evtIn;
vars.value.xInLocal = xIn;
vars.value.yInLocal = yIn;
vars.value.offsetXInLocal = offsetXIn;
vars.value.offsetYInLocal = offsetYIn;
varBag.callContext = callContext;
varBag.vars = vars;
OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:ri8LXnQRK0muYqtBwGL7GA:/NRWebFlows.r84yxAaI7UmCCc1n0vDBhg/NodesShownInESpaceTree.U2xLBAAB_06fn9bjTQqqnQ/ClientActions.ri8LXnQRK0muYqtBwGL7GA:MFYMMFVi1BEFlwyWRaPoUw", "ShopperPortalEU_UI_Components", "OnMove", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:u63ZV2adg0+j6arhGgQlfg", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:8e3UBxEi30a_hp9rLTwGWA", callContext.id);
// Trigger Event: Move
return controller.move$Action(OS.BuiltinFunctions.integerToDecimal(vars.value.xInLocal), OS.BuiltinFunctions.integerToDecimal(vars.value.yInLocal), OS.BuiltinFunctions.integerToDecimal(vars.value.offsetXInLocal), OS.BuiltinFunctions.integerToDecimal(vars.value.offsetYInLocal), vars.value.evtInLocal, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:NrH1HJ2sJ0O2XhIZcWk9hA", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:ri8LXnQRK0muYqtBwGL7GA", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:ri8LXnQRK0muYqtBwGL7GA", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("ShopperPortalEU_UI_Components.Private.TouchEvents.OnMove$vars", [{
name: "Evt",
attrName: "evtInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Object,
defaultValue: function () {
return null;
}
}, {
name: "X",
attrName: "xInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Integer,
defaultValue: function () {
return 0;
}
}, {
name: "Y",
attrName: "yInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Integer,
defaultValue: function () {
return 0;
}
}, {
name: "OffsetX",
attrName: "offsetXInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Integer,
defaultValue: function () {
return 0;
}
}, {
name: "OffsetY",
attrName: "offsetYInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Integer,
defaultValue: function () {
return 0;
}
}]);
Controller.prototype._onStart$Action = function (xIn, yIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnStart");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.Private.TouchEvents.OnStart$vars"))());
vars.value.xInLocal = xIn;
vars.value.yInLocal = yIn;
varBag.callContext = callContext;
varBag.vars = vars;
OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:dyoSaVw_pUyOyngfhRwO2A:/NRWebFlows.r84yxAaI7UmCCc1n0vDBhg/NodesShownInESpaceTree.U2xLBAAB_06fn9bjTQqqnQ/ClientActions.dyoSaVw_pUyOyngfhRwO2A:DBCxNjz4VyKiO0Fhb09+TA", "ShopperPortalEU_UI_Components", "OnStart", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:KsVskZgInEeB0TBWBTOHJw", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:yGYDg6zGOEScq+rvKHJzzA", callContext.id);
// Trigger Event: Start
return controller.start$Action(OS.BuiltinFunctions.integerToDecimal(vars.value.xInLocal), OS.BuiltinFunctions.integerToDecimal(vars.value.yInLocal), callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:4kJN02gRN0mh2Kbqd+lBsg", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:dyoSaVw_pUyOyngfhRwO2A", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:dyoSaVw_pUyOyngfhRwO2A", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("ShopperPortalEU_UI_Components.Private.TouchEvents.OnStart$vars", [{
name: "X",
attrName: "xInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Integer,
defaultValue: function () {
return 0;
}
}, {
name: "Y",
attrName: "yInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Integer,
defaultValue: function () {
return 0;
}
}]);
Controller.prototype._onEnd$Action = function (xIn, yIn, offsetXIn, offsetYIn, timeTakenIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnEnd");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.Private.TouchEvents.OnEnd$vars"))());
vars.value.xInLocal = xIn;
vars.value.yInLocal = yIn;
vars.value.offsetXInLocal = offsetXIn;
vars.value.offsetYInLocal = offsetYIn;
vars.value.timeTakenInLocal = timeTakenIn;
varBag.callContext = callContext;
varBag.vars = vars;
OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:C56JeQdsekSxKedeMxTAGg:/NRWebFlows.r84yxAaI7UmCCc1n0vDBhg/NodesShownInESpaceTree.U2xLBAAB_06fn9bjTQqqnQ/ClientActions.C56JeQdsekSxKedeMxTAGg:3Ed5gjg6jVnnutHFS9FiBg", "ShopperPortalEU_UI_Components", "OnEnd", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:8BZNISavU0GBwifVWkMTUQ", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:uaKRV3AvRE2jDBriWkaf1Q", callContext.id);
// Trigger Event: End
return controller.end$Action(OS.BuiltinFunctions.integerToDecimal(vars.value.xInLocal), OS.BuiltinFunctions.integerToDecimal(vars.value.yInLocal), OS.BuiltinFunctions.integerToDecimal(vars.value.offsetXInLocal), OS.BuiltinFunctions.integerToDecimal(vars.value.offsetYInLocal), OS.BuiltinFunctions.integerToDecimal(vars.value.timeTakenInLocal), callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:yQQCqWrAAEapymA4mBhSag", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:C56JeQdsekSxKedeMxTAGg", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:C56JeQdsekSxKedeMxTAGg", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("ShopperPortalEU_UI_Components.Private.TouchEvents.OnEnd$vars", [{
name: "X",
attrName: "xInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Integer,
defaultValue: function () {
return 0;
}
}, {
name: "Y",
attrName: "yInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Integer,
defaultValue: function () {
return 0;
}
}, {
name: "OffsetX",
attrName: "offsetXInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Integer,
defaultValue: function () {
return 0;
}
}, {
name: "OffsetY",
attrName: "offsetYInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Integer,
defaultValue: function () {
return 0;
}
}, {
name: "TimeTaken",
attrName: "timeTakenInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Integer,
defaultValue: function () {
return 0;
}
}]);
Controller.prototype._onReady$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnReady");
callContext = controller.callContext(callContext);
var bindEventsJSResult = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.bindEventsJSResult = bindEventsJSResult;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:8SrktFd2j0Cy2VD6sO51PA:/NRWebFlows.r84yxAaI7UmCCc1n0vDBhg/NodesShownInESpaceTree.U2xLBAAB_06fn9bjTQqqnQ/ClientActions.8SrktFd2j0Cy2VD6sO51PA:P22M3siyLG5Lm+dLRl+5ug", "ShopperPortalEU_UI_Components", "OnReady", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:NTwYK7lXtku7vmeHoTO5QA", callContext.id);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:POM1i02dQ0GJmsAg64hEOg", callContext.id);
bindEventsJSResult.value = controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_Private_TouchEvents_mvc_controller_OnReady_BindEventsJS, "BindEvents", "OnReady", {
WidgetId: OS.DataConversion.JSNodeParamConverter.to(model.variables.widgetIdIn, OS.DataTypes.DataTypes.Text),
isBound: OS.DataConversion.JSNodeParamConverter.to(false, OS.DataTypes.DataTypes.Boolean),
Obj: OS.DataConversion.JSNodeParamConverter.to(null, OS.DataTypes.DataTypes.Object)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.Private.TouchEvents.OnReady$bindEventsJSResult"))();
jsNodeResult.isBoundOut = OS.DataConversion.JSNodeParamConverter.from($parameters.isBound, OS.DataTypes.DataTypes.Boolean);
jsNodeResult.objOut = OS.DataConversion.JSNodeParamConverter.from($parameters.Obj, OS.DataTypes.DataTypes.Object);
return jsNodeResult;
}, {
OnStart: controller.clientActionProxies.onStart$Action,
OnMove: controller.clientActionProxies.onMove$Action,
OnEnd: controller.clientActionProxies.onEnd$Action
}, {});
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:pn8_Tj_txUq36MSoKP_CHw", callContext.id);
// IsBound = BindEvents.isBound
model.variables.isBoundVar = bindEventsJSResult.value.isBoundOut;
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:pn8_Tj_txUq36MSoKP_CHw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// GestureObj = BindEvents.Obj
model.variables.gestureObjVar = bindEventsJSResult.value.objOut;
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:cy+TnwydSEO3Tm4O0AqohA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:8SrktFd2j0Cy2VD6sO51PA", callContext.id);
}

};
Controller.registerVariableGroupType("ShopperPortalEU_UI_Components.Private.TouchEvents.OnReady$bindEventsJSResult", [{
name: "isBound",
attrName: "isBoundOut",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "Obj",
attrName: "objOut",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Object,
defaultValue: function () {
return null;
}
}]);
Controller.prototype._onInitialize$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnInitialize");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:03Ue4GFrB02eUEHeF4enGw:/NRWebFlows.r84yxAaI7UmCCc1n0vDBhg/NodesShownInESpaceTree.U2xLBAAB_06fn9bjTQqqnQ/ClientActions.03Ue4GFrB02eUEHeF4enGw:ELVFd0mdq+43v9x74Kj8ng", "ShopperPortalEU_UI_Components", "OnInitialize", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:HtCBPa1QlUmkrIoyUlLmwQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:qad4vwwXo0e4+HGcOmIYTw", callContext.id);
// IsBound = False
model.variables.isBoundVar = false;
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:HVI9USHf40WUUfEBWhZTSA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:03Ue4GFrB02eUEHeF4enGw", callContext.id);
}

};
Controller.prototype._onParametersChanged$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnParametersChanged");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:pNZr9ydry0q_3luRMSQOXw:/NRWebFlows.r84yxAaI7UmCCc1n0vDBhg/NodesShownInESpaceTree.U2xLBAAB_06fn9bjTQqqnQ/ClientActions.pNZr9ydry0q_3luRMSQOXw:2s24KrIgxWNXp7H7bDWtsQ", "ShopperPortalEU_UI_Components", "OnParametersChanged", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:1mgaZIaO4EOPuqAIhzIByA", callContext.id);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:YcEKzjd_yEOORLSXa81KZA", callContext.id);
controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_Private_TouchEvents_mvc_controller_OnParametersChanged_SetPreventDefaultJS, "SetPreventDefault", "OnParametersChanged", {
Prevent: OS.DataConversion.JSNodeParamConverter.to(model.variables.preventDefaultsIn, OS.DataTypes.DataTypes.Boolean),
Obj: OS.DataConversion.JSNodeParamConverter.to(model.variables.gestureObjVar, OS.DataTypes.DataTypes.Object)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:MbUKbzv2XU24l3zSndWP5w", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:pNZr9ydry0q_3luRMSQOXw", callContext.id);
}

};

Controller.prototype.onDestroy$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onDestroy$Action, callContext);

};
Controller.prototype.onMove$Action = function (evtIn, xIn, yIn, offsetXIn, offsetYIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onMove$Action, callContext, evtIn, xIn, yIn, offsetXIn, offsetYIn);

};
Controller.prototype.onStart$Action = function (xIn, yIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onStart$Action, callContext, xIn, yIn);

};
Controller.prototype.onEnd$Action = function (xIn, yIn, offsetXIn, offsetYIn, timeTakenIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onEnd$Action, callContext, xIn, yIn, offsetXIn, offsetYIn, timeTakenIn);

};
Controller.prototype.onReady$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onReady$Action, callContext);

};
Controller.prototype.onInitialize$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onInitialize$Action, callContext);

};
Controller.prototype.onParametersChanged$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onParametersChanged$Action, callContext);

};
Controller.prototype.move$Action = function () {
return Promise.resolve();
};
Controller.prototype.end$Action = function () {
return Promise.resolve();
};
Controller.prototype.start$Action = function () {
return Promise.resolve();
};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:r84yxAaI7UmCCc1n0vDBhg:/NRWebFlows.r84yxAaI7UmCCc1n0vDBhg:w6dvmGti0C1iYa118KocVg", "ShopperPortalEU_UI_Components", "Private", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:U2xLBAAB_06fn9bjTQqqnQ:/NRWebFlows.r84yxAaI7UmCCc1n0vDBhg/NodesShownInESpaceTree.U2xLBAAB_06fn9bjTQqqnQ:v0meeahdM+rxuvo_CMkNEw", "ShopperPortalEU_UI_Components", "TouchEvents", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:U2xLBAAB_06fn9bjTQqqnQ", callContext.id);
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:r84yxAaI7UmCCc1n0vDBhg", callContext.id);
};
Controller.prototype.onInitializeEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Private/TouchEvents On Initialize");
return controller.onInitialize$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onReadyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Private/TouchEvents On Ready");
return controller.onReady$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Private/TouchEvents On Destroy");
return controller.onDestroy$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onParametersChangedEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Private/TouchEvents On Parameters Changed");
return controller.onParametersChanged$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return ShopperPortalEU_UI_ComponentsController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, ShopperPortalEU_UI_ComponentsLanguageResources);
});
define("ShopperPortalEU_UI_Components.Private.TouchEvents.mvc$controller.OnDestroy.DestroyJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.Obj.destroy();
};
});
define("ShopperPortalEU_UI_Components.Private.TouchEvents.mvc$controller.OnReady.BindEventsJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var touchTrack = new TouchTrack();
$parameters.isBound = false;

var el = document.getElementById($parameters.WidgetId);

if (el) {
    touchTrack.init(el, $actions.OnStart, $actions.OnMove, $actions.OnEnd);
    $parameters.isBound = true;
}


$parameters.Obj = touchTrack;
};
});
define("ShopperPortalEU_UI_Components.Private.TouchEvents.mvc$controller.OnParametersChanged.SetPreventDefaultJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.Obj.setPreventDefault($parameters.Prevent);
};
});

define("ShopperPortalEU_UI_Components.Private.TouchEvents.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"Pk44xOQ6dE+byV0jl7Po4g": {
getter: function (varBag, idService) {
return varBag.destroyJSResult.value;
}
},
"qLTSMQuPNEWh5M+IbXvpBw": {
getter: function (varBag, idService) {
return varBag.vars.value.evtInLocal;
},
dataType: OS.DataTypes.DataTypes.Object
},
"oOkAPzrjLEyAT3Gi6W3pvA": {
getter: function (varBag, idService) {
return varBag.vars.value.xInLocal;
},
dataType: OS.DataTypes.DataTypes.Integer
},
"PlAQfTCLo0aezLap0S3r8A": {
getter: function (varBag, idService) {
return varBag.vars.value.yInLocal;
},
dataType: OS.DataTypes.DataTypes.Integer
},
"xum4MBCvJUmHppukj_nmaA": {
getter: function (varBag, idService) {
return varBag.vars.value.offsetXInLocal;
},
dataType: OS.DataTypes.DataTypes.Integer
},
"rMLR1HueekuKoPlg4wQr0A": {
getter: function (varBag, idService) {
return varBag.vars.value.offsetYInLocal;
},
dataType: OS.DataTypes.DataTypes.Integer
},
"MTMADicypEK12owreGFSJw": {
getter: function (varBag, idService) {
return varBag.vars.value.xInLocal;
},
dataType: OS.DataTypes.DataTypes.Integer
},
"WCfeQA7P20S5ZmLoQwQViQ": {
getter: function (varBag, idService) {
return varBag.vars.value.yInLocal;
},
dataType: OS.DataTypes.DataTypes.Integer
},
"uUXwvXReXUamop9bfNsOqw": {
getter: function (varBag, idService) {
return varBag.vars.value.xInLocal;
},
dataType: OS.DataTypes.DataTypes.Integer
},
"RM5uk8J3GUWm9zSe4nZAdg": {
getter: function (varBag, idService) {
return varBag.vars.value.yInLocal;
},
dataType: OS.DataTypes.DataTypes.Integer
},
"infyBr6u70i1PnSiHvn9jw": {
getter: function (varBag, idService) {
return varBag.vars.value.offsetXInLocal;
},
dataType: OS.DataTypes.DataTypes.Integer
},
"F7Gp50QRDkmtxzzHzIfoWA": {
getter: function (varBag, idService) {
return varBag.vars.value.offsetYInLocal;
},
dataType: OS.DataTypes.DataTypes.Integer
},
"_+DkbAxe5kCzTB9vjWgMiQ": {
getter: function (varBag, idService) {
return varBag.vars.value.timeTakenInLocal;
},
dataType: OS.DataTypes.DataTypes.Integer
},
"POM1i02dQ0GJmsAg64hEOg": {
getter: function (varBag, idService) {
return varBag.bindEventsJSResult.value;
}
},
"YcEKzjd_yEOORLSXa81KZA": {
getter: function (varBag, idService) {
return varBag.setPreventDefaultJSResult.value;
}
},
"NbAsrPvFPECzKO_oNs8Now": {
getter: function (varBag, idService) {
return varBag.model.variables.isBoundVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"nHR6_QfihEejMprX9OrM4w": {
getter: function (varBag, idService) {
return varBag.model.variables.gestureObjVar;
},
dataType: OS.DataTypes.DataTypes.Object
},
"KNMiP1ARoUOhVaBbDi8SPg": {
getter: function (varBag, idService) {
return varBag.model.variables.widgetIdIn;
},
dataType: OS.DataTypes.DataTypes.Text
},
"S6653G4nKUWZ9hSTqAZYyg": {
getter: function (varBag, idService) {
return varBag.model.variables.preventDefaultsIn;
},
dataType: OS.DataTypes.DataTypes.Boolean
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
