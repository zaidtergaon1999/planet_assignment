define("ShopperPortalEU.CreditCard.MyWallet.mvc$model", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Theme.controller", "ShopperPortalEU_Shopper_IS.controller", "ShopperPortalEU.controller$FormatMaskedCard", "ShopperPortalEU_Shopper_IS.model$GetCardsResponseRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS", "ShopperPortalEU.model$GetCardsResponseList", "ShopperPortalEU_UI_Theme.model$LayoutDetailOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU_UI_Components.model$CustomColumnsOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$CreditCardOptionsRec", "ShopperPortalEU_UI_Components.model$CreditCardSwipeOptionsRec", "ShopperPortalEU_UI_Components.model$CustomTagOptionsRec", "ShopperPortalEU_UI_Components.model$FlexOptionsRec", "ShopperPortalEU_UI_Components.model$CustomSwitchOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconRec", "ShopperPortalEU_UI_Components.model$CustomIconOptionsRec", "ShopperPortalEU_UI_Components.model$CustomPopupLayoutOptionsRec", "ShopperPortalEU_UI_Components.model$CustomPopupLayoutHeaderImageOptionsRec", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", "ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger", "ShopperPortalEU_Shopper_IS.model$UpdateCardRec", "ShopperPortalEU_Shopper_IS.controller$UpdateCard", "ShopperPortalEU.controller$DefaultErrorMessage", "ShopperPortalEU_Shopper_IS.model$UpdateCardDataRec", "ShopperPortalEU_Shopper_IS.controller$GetCards", "ShopperPortalEU_Shopper_IS.model$DeleteCardRec", "ShopperPortalEU_Shopper_IS.controller$DeleteCreditCard", "ShopperPortalEU_Shopper_IS.model$DeleteCardBodyRec"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_Shopper_ISModel, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ThemeController, ShopperPortalEU_Shopper_ISController) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("IsDataFetched", "isDataFetchedVar", "IsDataFetched", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("Cards", "cardsVar", "Cards", true, false, OS.DataTypes.DataTypes.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEUModel.GetCardsResponseList());
}, false, ShopperPortalEUModel.GetCardsResponseList), 
this.attr("ShowDeleteCardPopup", "showDeleteCardPopupVar", "ShowDeleteCardPopup", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("CardSelected", "cardSelectedVar", "CardSelected", true, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_Shopper_ISModel.GetCardsResponseRec());
}, false, ShopperPortalEU_Shopper_ISModel.GetCardsResponseRec)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {
Switch1: OS.Model.ValidationWidgetRecord
};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return true;
}
});

Model.prototype.setInputs = function (inputs) {
};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "CreditCard.MyWallet");
});
define("ShopperPortalEU.CreditCard.MyWallet.mvc$view", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Theme.controller", "ShopperPortalEU_Shopper_IS.controller", "react", "OutSystems/ReactView/Main", "ShopperPortalEU.CreditCard.MyWallet.mvc$model", "ShopperPortalEU.CreditCard.MyWallet.mvc$controller", "ShopperPortalEU.clientVariables", "ShopperPortalEU.Layouts.LayoutDetail.mvc$view", "OutSystems/ReactWidgets/Main", "ShopperPortalEU.LayoutsComponents.Back.mvc$view", "ShopperPortalEU.Common.DataLoading.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomColumns.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CreditCard.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomTag.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.Flex.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomSwitch.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomButton.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomButtonItem.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomIcon.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomPopup.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomPopupLayout.mvc$view", "ShopperPortalEU.controller$FormatMaskedCard", "ShopperPortalEU_Shopper_IS.model$GetCardsResponseRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS", "ShopperPortalEU.model$GetCardsResponseList", "ShopperPortalEU_UI_Theme.model$LayoutDetailOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU_UI_Components.model$CustomColumnsOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$CreditCardOptionsRec", "ShopperPortalEU_UI_Components.model$CreditCardSwipeOptionsRec", "ShopperPortalEU_UI_Components.model$CustomTagOptionsRec", "ShopperPortalEU_UI_Components.model$FlexOptionsRec", "ShopperPortalEU_UI_Components.model$CustomSwitchOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconRec", "ShopperPortalEU_UI_Components.model$CustomIconOptionsRec", "ShopperPortalEU_UI_Components.model$CustomPopupLayoutOptionsRec", "ShopperPortalEU_UI_Components.model$CustomPopupLayoutHeaderImageOptionsRec", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", "ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger", "ShopperPortalEU_Shopper_IS.model$UpdateCardRec", "ShopperPortalEU_Shopper_IS.controller$UpdateCard", "ShopperPortalEU.controller$DefaultErrorMessage", "ShopperPortalEU_Shopper_IS.model$UpdateCardDataRec", "ShopperPortalEU_Shopper_IS.controller$GetCards", "ShopperPortalEU_Shopper_IS.model$DeleteCardRec", "ShopperPortalEU_Shopper_IS.controller$DeleteCreditCard", "ShopperPortalEU_Shopper_IS.model$DeleteCardBodyRec"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_Shopper_ISModel, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ThemeController, ShopperPortalEU_Shopper_ISController, React, OSView, ShopperPortalEU_CreditCard_MyWallet_mvc_model, ShopperPortalEU_CreditCard_MyWallet_mvc_controller, ShopperPortalEUClientVariables, ShopperPortalEU_Layouts_LayoutDetail_mvc_view, OSWidgets, ShopperPortalEU_LayoutsComponents_Back_mvc_view, ShopperPortalEU_Common_DataLoading_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomColumns_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CreditCard_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomTag_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomSwitch_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomIcon_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomPopup_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomPopupLayout_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            var thisIsInstanceOfSuper = this instanceof _super;
            if (thisIsInstanceOfSuper == false) {
                return;
            }

            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "CreditCard.MyWallet";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css", "css/ShopperPortalEU_UI_Theme.ShopperPortalEUUITheme.css", "css/ShopperPortalEU.ShopperPortalEU.css", "css/ShopperPortalEU_UI_Theme.ShopperPortalEUUITheme.extra.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [ShopperPortalEU_Layouts_LayoutDetail_mvc_view, ShopperPortalEU_LayoutsComponents_Back_mvc_view, ShopperPortalEU_Common_DataLoading_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomColumns_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CreditCard_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomTag_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomSwitch_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomIcon_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomPopup_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomPopupLayout_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return ShopperPortalEU_CreditCard_MyWallet_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return ShopperPortalEU_CreditCard_MyWallet_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "Shopper Portal EU - My wallet";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(ShopperPortalEU_Layouts_LayoutDetail_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
afterAuthentication$Action: function (isAuthenticatedIn) {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Layouts/LayoutDetail AfterAuthentication");
return controller.onAfterAuthentication$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "0",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
headerLeft: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_LayoutsComponents_Back_mvc_view, {
inputs: {
ManualRedirect: true
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onClick$Action: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "LayoutsComponents/Back OnClick");
controller.backOnClick$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "1",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}),
headerCenter: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "MyWallet"
},
value: "My wallet",
_idProps: {
service: idService,
uuid: "2"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
headerRight: PlaceholderContent.Empty,
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_Common_DataLoading_mvc_view, {
inputs: {
IsDataFetched: model.variables.isDataFetchedVar
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "3",
alias: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomColumns_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("WEV1JdCk0kWLDhk3M4HvSg.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomColumnsOptionsRec();
rec.columnsAttr = 1;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space4;
rec.justifyAttr = ShopperPortalEUModel.staticEntities.justify.center;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "4",
alias: "4"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.List, {
animateItems: true,
extendedProperties: {
"disable-virtualization": "True"
},
gridProperties: {
classes: "OSFillParent"
},
mode: /*Default*/ 0,
source: model.variables.cardsVar,
style: "list list-group",
tag: "div",
_idProps: {
service: idService,
uuid: "5"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new IteratorPlaceholderContent(function (idService, callContext) {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CreditCard_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("UPotKp4EGkCeulGhW21cTA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CreditCardOptionsRec();
rec.testIdAttr = ("Card_" + (model.variables.cardsVar.getCurrentRowNumber(callContext.iterationContext)).toString());
rec.typeAttr = model.variables.cardsVar.getCurrent(callContext.iterationContext).paymentMethodAttr;
rec.swipeAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CreditCardSwipeOptionsRec();
rec.swipeToDeleteAttr = true;
return rec;
}();
return rec;
}();
}, function () {
return model.variables.cardsVar.getCurrentRowNumber(callContext.iterationContext);
}, function () {
return model.variables.cardsVar.getCurrent(callContext.iterationContext).paymentMethodAttr;
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onDelete$Action: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ShopperPortalEUUIComponents/CreditCard OnDelete");
controller.openDeleteCardPopup$Action(model.variables.cardsVar.getCurrent(callContext.iterationContext), controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "6",
alias: "5"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
rightContent: new PlaceholderContent(function () {
return [$if(model.variables.cardsVar.getCurrent(callContext.iterationContext).isDefaultAttr, false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomTag_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("gQvjaJ_4t0CRIePF_8+qHA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomTagOptionsRec();
rec.testIdAttr = ("CardDefault_" + (model.variables.cardsVar.getCurrentRowNumber(callContext.iterationContext)).toString());
return rec;
}();
}, function () {
return model.variables.cardsVar.getCurrentRowNumber(callContext.iterationContext);
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "7",
alias: "6"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Default",
_idProps: {
service: idService,
uuid: "8"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
})];
}, function () {
return [];
})];
}),
number: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": ("CardMaskedNumber_" + (model.variables.cardsVar.getCurrentRowNumber(callContext.iterationContext)).toString())
},
value: model.getCachedValue(idService.getId("yhebAAOdzE6VIJ2L9dYOVw.Value"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.formatMaskedCard$Action(model.variables.cardsVar.getCurrent(callContext.iterationContext).maskedCardNumberAttr, callContext).outputOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
}, function () {
return model.variables.cardsVar.getCurrent(callContext.iterationContext).maskedCardNumberAttr;
}),
_idProps: {
service: idService,
uuid: "9"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
expiryDate: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": ("CardExpiryDate_" + (model.variables.cardsVar.getCurrentRowNumber(callContext.iterationContext)).toString())
},
value: model.getCachedValue(idService.getId("ReWmycEOAkWiC3+qyLSipA.Value"), function () {
return OS.BuiltinFunctions.formatDateTime(model.variables.cardsVar.getCurrent(callContext.iterationContext).expiryDateFormatAttr, "MM/yy");
}, function () {
return model.variables.cardsVar.getCurrent(callContext.iterationContext).expiryDateFormatAttr;
}),
_idProps: {
service: idService,
uuid: "10"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
cardHolder: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": ("CardHolderName_" + (model.variables.cardsVar.getCurrentRowNumber(callContext.iterationContext)).toString())
},
value: model.getCachedValue(idService.getId("7cdaRFyTI0C15ajfBV+KHA.Value"), function () {
return (((OS.BuiltinFunctions.length(model.variables.cardsVar.getCurrent(callContext.iterationContext).cardHolderNameAttr) <= 17)) ? (model.variables.cardsVar.getCurrent(callContext.iterationContext).cardHolderNameAttr) : ((OS.BuiltinFunctions.substr(model.variables.cardsVar.getCurrent(callContext.iterationContext).cardHolderNameAttr, 0, 17) + "...")));
}, function () {
return model.variables.cardsVar.getCurrent(callContext.iterationContext).cardHolderNameAttr;
}),
_idProps: {
service: idService,
uuid: "11"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
empty: PlaceholderContent.Empty,
backContent: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("__hih5uXvkK1hExQnIuxDw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.alignAttr = ShopperPortalEUModel.staticEntities.flexAlign.center;
rec.justifyAttr = ShopperPortalEUModel.staticEntities.flexJustify.spaceBetween;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
rec.wrapAttr = true;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "12",
alias: "7"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomSwitch_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("X4_XQiLZfEGrL6RgcVweog.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomSwitchOptionsRec();
rec.testIdAttr = (("CardDefault_" + (model.variables.cardsVar.getCurrentRowNumber(callContext.iterationContext)).toString()) + "_");
return rec;
}();
}, function () {
return model.variables.cardsVar.getCurrentRowNumber(callContext.iterationContext);
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "13",
alias: "8"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
switch: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Switch, {
_validationProps: {
validationService: validationService
},
enabled: true,
onChange: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "CreditCard/MyWallet/Switch1 OnChange");
return controller.isDefaultOnClick$Action(function () {
var rec = new ShopperPortalEU_Shopper_ISModel.GetCardsResponseRec();
rec.isDefaultAttr = model.variables.cardsVar.getCurrent(callContext.iterationContext).isDefaultAttr;
rec.tokenValueAttr = model.variables.cardsVar.getCurrent(callContext.iterationContext).tokenValueAttr;
rec.tokenProviderAttr = model.variables.cardsVar.getCurrent(callContext.iterationContext).tokenProviderAttr;
return rec;
}(), model.variables.cardsVar.getCurrentRowNumber(callContext.iterationContext), controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
style: "switch",
variable: model.createVariable(OS.DataTypes.DataTypes.Boolean, model.variables.cardsVar.getCurrent(callContext.iterationContext).isDefaultAttr, function (value) {
model.variables.cardsVar.getCurrent(callContext.iterationContext).isDefaultAttr = value;
}),
_idProps: {
service: idService,
name: "Switch1"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
label: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
targetWidget: "Switch1",
_idProps: {
service: idService,
uuid: "15"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
value: "Set as default",
_idProps: {
service: idService,
uuid: "16"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables.cardsVar.getCurrent(callContext.iterationContext).isDefaultAttr)]
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("k_2c2MAoGkqSxqYLi+kWKQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRec();
rec.testIdAttr = "deleteCard";
rec.typeAttr = ShopperPortalEUModel.staticEntities.customButtonType.primary;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "17",
alias: "9"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
button: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
gridProperties: {
classes: "OSFillParent"
},
isDefault: false,
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "CreditCard/MyWallet/Button OnClick");
controller.openDeleteCardPopup$Action(model.variables.cardsVar.getCurrent(callContext.iterationContext), controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn",
visible: true,
_idProps: {
service: idService,
uuid: "18"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("XXjDo1iChkGlRmhhUMn7OQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonItemOptionsRec();
rec.iconAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsIconRec();
rec.nameAttr = "delete";
return rec;
}();
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "19",
alias: "10"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: PlaceholderContent.Empty
},
_dependencies: []
}))];
})
},
_dependencies: []
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.cardsVar.getCurrent(callContext.iterationContext).isDefaultAttr), asPrimitiveValue(model.variables.cardsVar.getCurrentRowNumber(callContext.iterationContext))]
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.cardsVar.getCurrentRowNumber(callContext.iterationContext)), asPrimitiveValue(model.variables.cardsVar.getCurrent(callContext.iterationContext).cardHolderNameAttr), asPrimitiveValue(model.variables.cardsVar.getCurrent(callContext.iterationContext).expiryDateFormatAttr), asPrimitiveValue(model.variables.cardsVar.getCurrent(callContext.iterationContext).maskedCardNumberAttr), asPrimitiveValue(model.variables.cardsVar.getCurrent(callContext.iterationContext).isDefaultAttr)]
})];
}, callContext, idService, "1")
},
_dependencies: []
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CreditCard_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("NMLyfupYkk+_SNOtLJzrug.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CreditCardOptionsRec();
rec.isEmptyAttr = true;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onEmptyClick$Action: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ShopperPortalEUUIComponents/CreditCard OnEmptyClick");
controller.creditCardOnEmptyClick$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "20",
alias: "11"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
rightContent: PlaceholderContent.Empty,
number: PlaceholderContent.Empty,
expiryDate: PlaceholderContent.Empty,
cardHolder: PlaceholderContent.Empty,
empty: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("KzaPZAoHykmtPINm5czACw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.alignAttr = ShopperPortalEUModel.staticEntities.flexAlign.center;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
rec.wrapAttr = false;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "21",
alias: "12"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomIcon_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("QJmF8Iv4a0SJumM49SCoLw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomIconOptionsRec();
rec.nameAttr = "add";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "22",
alias: "13"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}), React.createElement(OSWidgets.Expression, {
value: "Add card",
_idProps: {
service: idService,
uuid: "23"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
})];
}),
backContent: PlaceholderContent.Empty
},
_dependencies: []
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.cardsVar)]
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomPopup_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "24",
alias: "14"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
popup: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Popup, {
showPopup: model.variables.showDeleteCardPopupVar,
style: "popup-dialog",
_idProps: {
service: idService,
uuid: "25"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomPopupLayout_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onOverlayClick$Action: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ShopperPortalEUUIComponents/CustomPopupLayout OnOverlayClick");
controller.closeDeleteCardPopup$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "26",
alias: "15"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
title: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Delete card",
_idProps: {
service: idService,
uuid: "27"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: model.getCachedValue(idService.getId("bjjDxwAuwka+J6Yzhl9NEQ.Value"), function () {
return (("Are you sure you want to delete the card ending in " + OS.BuiltinFunctions.substr(model.variables.cardSelectedVar.maskedCardNumberAttr, (OS.BuiltinFunctions.length(model.variables.cardSelectedVar.maskedCardNumberAttr) - 4), 4)) + "? Any submitted refunds will continue to be proccessed to this card.");
}, function () {
return model.variables.cardSelectedVar.maskedCardNumberAttr;
}),
_idProps: {
service: idService,
uuid: "28"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
actions: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("IxVDKw9bB0uwupMcpaMrqA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.justifyAttr = ShopperPortalEUModel.staticEntities.flexJustify.spaceBetween;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "29",
alias: "16"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("D8lo5eItPUuBz33sVwBgkA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRec();
rec.testIdAttr = "Close-id";
rec.typeAttr = ShopperPortalEUModel.staticEntities.customButtonType.reverse;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "30",
alias: "17"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
button: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: false,
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "CreditCard/MyWallet/Button OnClick");
controller.closeDeleteCardPopup$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn",
visible: true,
_idProps: {
service: idService,
uuid: "31"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "32",
alias: "18"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Cancel",
_idProps: {
service: idService,
uuid: "33"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("KyzX6CcbhUC_mi8weXY_iw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRec();
rec.testIdAttr = "Close-id";
rec.typeAttr = ShopperPortalEUModel.staticEntities.customButtonType.primary;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "34",
alias: "19"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
button: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: false,
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "CreditCard/MyWallet/Button OnClick");
return controller.onDeleteCard$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
style: "btn",
visible: true,
_idProps: {
service: idService,
uuid: "35"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "36",
alias: "20"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Delete",
_idProps: {
service: idService,
uuid: "37"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
})];
})
},
_dependencies: []
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.cardSelectedVar.maskedCardNumberAttr)]
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables.cardSelectedVar.maskedCardNumberAttr), asPrimitiveValue(model.variables.showDeleteCardPopupVar)]
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.cardSelectedVar.maskedCardNumberAttr), asPrimitiveValue(model.variables.showDeleteCardPopupVar), asPrimitiveValue(model.variables.cardsVar)]
})];
}),
bottom: PlaceholderContent.Empty
},
_dependencies: [asPrimitiveValue(model.variables.cardSelectedVar.maskedCardNumberAttr), asPrimitiveValue(model.variables.showDeleteCardPopupVar), asPrimitiveValue(model.variables.cardsVar), asPrimitiveValue(model.variables.isDataFetchedVar)]
}));
        };
        return View;
    })(OSView.BaseView.BaseWebScreen);
	
    return View;
});
define("ShopperPortalEU.CreditCard.MyWallet.mvc$controller", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Theme.controller", "ShopperPortalEU_Shopper_IS.controller", "ShopperPortalEU.languageResources", "ShopperPortalEU.clientVariables", "ShopperPortalEU.CreditCard.MyWallet.mvc$debugger", "ShopperPortalEU.CreditCard.controller", "ShopperPortalEU.controller$FormatMaskedCard", "ShopperPortalEU_Shopper_IS.model$GetCardsResponseRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS", "ShopperPortalEU.model$GetCardsResponseList", "ShopperPortalEU_UI_Theme.model$LayoutDetailOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU_UI_Components.model$CustomColumnsOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$CreditCardOptionsRec", "ShopperPortalEU_UI_Components.model$CreditCardSwipeOptionsRec", "ShopperPortalEU_UI_Components.model$CustomTagOptionsRec", "ShopperPortalEU_UI_Components.model$FlexOptionsRec", "ShopperPortalEU_UI_Components.model$CustomSwitchOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconRec", "ShopperPortalEU_UI_Components.model$CustomIconOptionsRec", "ShopperPortalEU_UI_Components.model$CustomPopupLayoutOptionsRec", "ShopperPortalEU_UI_Components.model$CustomPopupLayoutHeaderImageOptionsRec", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", "ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger", "ShopperPortalEU_Shopper_IS.model$UpdateCardRec", "ShopperPortalEU_Shopper_IS.controller$UpdateCard", "ShopperPortalEU.controller$DefaultErrorMessage", "ShopperPortalEU_Shopper_IS.model$UpdateCardDataRec", "ShopperPortalEU_Shopper_IS.controller$GetCards", "ShopperPortalEU_Shopper_IS.model$DeleteCardRec", "ShopperPortalEU_Shopper_IS.controller$DeleteCreditCard", "ShopperPortalEU_Shopper_IS.model$DeleteCardBodyRec"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_Shopper_ISModel, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ThemeController, ShopperPortalEU_Shopper_ISController, ShopperPortalEULanguageResources, ShopperPortalEUClientVariables, ShopperPortalEU_CreditCard_MyWallet_mvc_Debugger, ShopperPortalEU_CreditCardController) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = true;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._onInitialize$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnInitialize");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:w9VyBKPEcEG2TdjFwl4ttQ:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.LginJlkFIEek4mCs_hfVAA/ClientActions.w9VyBKPEcEG2TdjFwl4ttQ:H7eQwbSwEQJh2b+zfux7yA", "ShopperPortalEU", "OnInitialize", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:dUdZ4dXjJki8UpvHbdgcYQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:IphblEjOuEOPRqY5ICbykg", callContext.id);
// ShowDeleteCardPopup = False
model.variables.showDeleteCardPopupVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:IphblEjOuEOPRqY5ICbykg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// FromCarouselAddCard = False
ShopperPortalEUClientVariables.setFromCarouselAddCard(false);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:peK6QoUbm0i4TRApT+iw8g", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:w9VyBKPEcEG2TdjFwl4ttQ", callContext.id);
}

};
Controller.prototype._backOnClick$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("BackOnClick");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:u6QZBtaeREeL0_oEhSChqw:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.LginJlkFIEek4mCs_hfVAA/ClientActions.u6QZBtaeREeL0_oEhSChqw:9+NBqwEG6nJI8O2UHzoEzA", "ShopperPortalEU", "BackOnClick", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:c1Ppea3a8EOifAC7E+Ln2w", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:hftEFqTGOkeiIaLWNzeftQ", callContext.id);
// Destination: /ShopperPortalEU/MyProfile
return OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "MyProfile", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:u6QZBtaeREeL0_oEhSChqw", callContext.id);
}

};
Controller.prototype._closeDeleteCardPopup$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("CloseDeleteCardPopup");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:EEoCXJgy30mZO0h5k5pcmA:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.LginJlkFIEek4mCs_hfVAA/ClientActions.EEoCXJgy30mZO0h5k5pcmA:Qwa5tRk61NeZpms520BDug", "ShopperPortalEU", "CloseDeleteCardPopup", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:4IhtFjlqGU27NWX1AF6S8g", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:xp9dXLJ8akiZw70+myIE4A", callContext.id);
// ShowDeleteCardPopup = False
model.variables.showDeleteCardPopupVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:xl7xf8TPy0iBtzISJuMEQA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:EEoCXJgy30mZO0h5k5pcmA", callContext.id);
}

};
Controller.prototype._isDefaultOnClick$Action = function (cardIn, cardIndexIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("IsDefaultOnClick");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.CreditCard.MyWallet.IsDefaultOnClick$vars"))());
vars.value.cardInLocal = cardIn.clone();
vars.value.cardIndexInLocal = cardIndexIn;
var updateCardVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.vars = vars;
varBag.updateCardVar = updateCardVar;
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:zwqQXSbaX0u6Wu36rpoVnQ:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.LginJlkFIEek4mCs_hfVAA/ClientActions.zwqQXSbaX0u6Wu36rpoVnQ:PekjaOHRVjFHuNGMoazoGw", "ShopperPortalEU", "IsDefaultOnClick", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:dI7LtUalYEqmDiLzN5w0IQ", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
// Foreach Cards
callContext.iterationContext.registerIterationStart(model.variables.cardsVar);
try {var cardsIterator = callContext.iterationContext.getIterator(model.variables.cardsVar);
var cardsIndex = 0;
while ((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:psmTDc2gZUKMLc_SL6K_mg", callContext.id) && (cardsIndex < model.variables.cardsVar.length))) {
cardsIterator.currentRowNumber = cardsIndex;
// IsDefault & notCurrentCard ?
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:6bwPU4r3AU2gKwH2vcW41w", callContext.id) && (model.variables.cardsVar.getItem(cardsIndex.valueOf()).isDefaultAttr && ((model.variables.cardsVar.getCurrentRowNumber(callContext.iterationContext)) !== (vars.value.cardIndexInLocal))))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:6lwH291Ku0iwOLWFdakcBw", callContext.id);
// Cards.Current.IsDefault = False
model.variables.cardsVar.getItem(cardsIndex.valueOf()).isDefaultAttr = false;
}

cardsIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(model.variables.cardsVar);
}

OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:+MfvUlXFDUu0SVw8SP0FHQ", callContext.id);
// Execute Action: UpdateCard
model.flush();
return ShopperPortalEU_Shopper_ISController.default.updateCard$Action(function () {
var rec = new ShopperPortalEU_Shopper_ISModel.UpdateCardRec();
rec.shopperGuidAttr = ShopperPortalEUClientVariables.getShopperGuid();
rec.updateCardDataAttr = function () {
var rec = new ShopperPortalEU_Shopper_ISModel.UpdateCardDataRec();
rec.tokenValueAttr = vars.value.cardInLocal.tokenValueAttr;
rec.tokenProviderAttr = vars.value.cardInLocal.tokenProviderAttr;
rec.isDefaultAttr = vars.value.cardInLocal.isDefaultAttr;
return rec;
}();
return rec;
}(), callContext).then(function (value) {
updateCardVar.value = value;
}).then(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:bvW6po_vjkWmMJoBL3du8g", callContext.id) && updateCardVar.value.isSuccessOut)) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:2zgtB+r11U24nVxmkDaeCg", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:aYdjDZlWYUGOqU+K4FLc4w", callContext.id);
// Execute Action: ErrorMessage
ShopperPortalEU_UI_ThemeController.default.customMessageTrigger$Action(function () {
var rec = new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customMessageType.error;
rec.titleAttr = updateCardVar.value.errorMessageOut;
rec.contentAttr = OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.defaultErrorMessage$Action(callContext).errorMessageOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
rec.testIdAttr = "Error";
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:0nEVIiWKFkqOFLlS+px1ng", callContext.id);
}

});
}).then(function (res) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:zwqQXSbaX0u6Wu36rpoVnQ", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:zwqQXSbaX0u6Wu36rpoVnQ", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("ShopperPortalEU.CreditCard.MyWallet.IsDefaultOnClick$vars", [{
name: "Card",
attrName: "cardInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Record,
defaultValue: function () {
return new ShopperPortalEU_Shopper_ISModel.GetCardsResponseRec();
},
complexType: ShopperPortalEU_Shopper_ISModel.GetCardsResponseRec
}, {
name: "CardIndex",
attrName: "cardIndexInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Integer,
defaultValue: function () {
return 0;
}
}]);
Controller.prototype._onAfterAuthentication$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnAfterAuthentication");
callContext = controller.callContext(callContext);
var getCardsVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.getCardsVar = getCardsVar;
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:sN44Z5oY8k6pyzQJvjHlvQ:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.LginJlkFIEek4mCs_hfVAA/ClientActions.sN44Z5oY8k6pyzQJvjHlvQ:FQmj5GXf3jwjtMt_3lnS0g", "ShopperPortalEU", "OnAfterAuthentication", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:dkELN7+_s0GuuQ4R7UH_oQ", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:F5f3s_6aUUWfFP835SCGBA", callContext.id);
// Execute Action: GetCards
model.flush();
return ShopperPortalEU_Shopper_ISController.default.getCards$Action(ShopperPortalEUClientVariables.getShopperGuid(), callContext).then(function (value) {
getCardsVar.value = value;
}).then(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:fisfmUQJ60ez63aO9WBPSA", callContext.id) && getCardsVar.value.isSuccessOut)) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:gJwSrFPUVkqLBfamLf+qSA", callContext.id);
// Cards = GetCards.Cards
model.variables.cardsVar = getCardsVar.value.cardsOut;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:6WX6AVaf2UqvoPJsU8JZwg", callContext.id);
// IsDataFetched = True
model.variables.isDataFetchedVar = true;
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:rmo6UcjJZ0ijvjk_jhQVGg", callContext.id);
// Execute Action: ErrorMessage2
ShopperPortalEU_UI_ThemeController.default.customMessageTrigger$Action(function () {
var rec = new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customMessageType.error;
rec.titleAttr = getCardsVar.value.errorMessageOut;
rec.contentAttr = OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.defaultErrorMessage$Action(callContext).errorMessageOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
rec.testIdAttr = "Error";
return rec;
}(), callContext);
}

OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:g4xRPLH1VUGDF9so0ncmkg", callContext.id);
// ShopperCards = GetCards.Cards.Length
ShopperPortalEUClientVariables.setShopperCards(getCardsVar.value.cardsOut.length);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:kxWcDwSiRky3iooi4TLgYg", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:sN44Z5oY8k6pyzQJvjHlvQ", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:sN44Z5oY8k6pyzQJvjHlvQ", callContext.id);
throw ex;

});
};
Controller.prototype._openDeleteCardPopup$Action = function (cardToBeDeletedIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OpenDeleteCardPopup");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.CreditCard.MyWallet.OpenDeleteCardPopup$vars"))());
vars.value.cardToBeDeletedInLocal = cardToBeDeletedIn.clone();
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:8jLbrEVajUu17w5EiXrxWA:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.LginJlkFIEek4mCs_hfVAA/ClientActions.8jLbrEVajUu17w5EiXrxWA:ONgeMKqTeBeadqVXBkgSLg", "ShopperPortalEU", "OpenDeleteCardPopup", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:DhGgW4nD3UWA9lnlu5U9VA", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:JfSQUMq140i4W4Wx9I49_g", callContext.id);
// CardSelected = CardToBeDeleted
model.variables.cardSelectedVar = vars.value.cardToBeDeletedInLocal;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:DLWo43meyU2+mRiCncrhVg", callContext.id);
// ShowDeleteCardPopup = True
model.variables.showDeleteCardPopupVar = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:+HQAT7wJk0mhWyt1v_RR0w", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:8jLbrEVajUu17w5EiXrxWA", callContext.id);
}

};
Controller.registerVariableGroupType("ShopperPortalEU.CreditCard.MyWallet.OpenDeleteCardPopup$vars", [{
name: "CardToBeDeleted",
attrName: "cardToBeDeletedInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Record,
defaultValue: function () {
return new ShopperPortalEU_Shopper_ISModel.GetCardsResponseRec();
},
complexType: ShopperPortalEU_Shopper_ISModel.GetCardsResponseRec
}]);
Controller.prototype._creditCardOnEmptyClick$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("CreditCardOnEmptyClick");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:N6+UtM+cXEaot5l4+ou+1g:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.LginJlkFIEek4mCs_hfVAA/ClientActions.N6+UtM+cXEaot5l4+ou+1g:5SQKwdtRIIWuFHwl79oFqQ", "ShopperPortalEU", "CreditCardOnEmptyClick", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:VG41kraB30idxhTKYjCNtg", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Hc63t9n1dkyog35H4pR8EQ", callContext.id);
// Destination: /ShopperPortalEU/AddCard
return OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "AddCard", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:N6+UtM+cXEaot5l4+ou+1g", callContext.id);
}

};
Controller.prototype._onDeleteCard$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnDeleteCard");
callContext = controller.callContext(callContext);
var getCardsVar = new OS.DataTypes.VariableHolder();
var deleteCreditCardVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.getCardsVar = getCardsVar;
varBag.deleteCreditCardVar = deleteCreditCardVar;
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:QcIz2TXsu02DN7ODJWdqUw:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.LginJlkFIEek4mCs_hfVAA/ClientActions.QcIz2TXsu02DN7ODJWdqUw:8Xj_ZfD0HJNDmr4AHsQ_cQ", "ShopperPortalEU", "OnDeleteCard", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:EgCK9QhKm0iseXLRoGEg8A", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:sbP1jtBc4kKtl_MTKWfZFA", callContext.id);
// IsDataFetched = False
model.variables.isDataFetchedVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:eMlV2WrtTU2Zjzm3t92tfg", callContext.id);
// Execute Action: DeleteCreditCard
model.flush();
return ShopperPortalEU_Shopper_ISController.default.deleteCreditCard$Action(function () {
var rec = new ShopperPortalEU_Shopper_ISModel.DeleteCardRec();
rec.shopperGuidAttr = ShopperPortalEUClientVariables.getShopperGuid();
rec.deleteCardBodyAttr = function () {
var rec = new ShopperPortalEU_Shopper_ISModel.DeleteCardBodyRec();
rec.tokenValueAttr = model.variables.cardSelectedVar.tokenValueAttr;
rec.tokenProviderAttr = model.variables.cardSelectedVar.tokenProviderAttr;
return rec;
}();
return rec;
}(), callContext).then(function (value) {
deleteCreditCardVar.value = value;
}).then(function () {
// Success
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:bedSqrM7_0+xXSZTDITKjg", callContext.id) && deleteCreditCardVar.value.isSuccessOut)) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:DFDjo2HbGUOqNPbV7+0saA", callContext.id);
// Execute Action: GetCards
model.flush();
return ShopperPortalEU_Shopper_ISController.default.getCards$Action(ShopperPortalEUClientVariables.getShopperGuid(), callContext).then(function (value) {
getCardsVar.value = value;
}).then(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:dlu3WA_5EEqJthrIKB0Bsw", callContext.id) && getCardsVar.value.isSuccessOut)) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:oy_otbszRkSYiq2j9ZtBNw", callContext.id);
// Cards = GetCards.Cards
model.variables.cardsVar = getCardsVar.value.cardsOut;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:oy_otbszRkSYiq2j9ZtBNw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// ShopperCards = GetCards.Cards.Length
ShopperPortalEUClientVariables.setShopperCards(getCardsVar.value.cardsOut.length);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:xJLReJA0UEeHrx06OjXenA", callContext.id);
// ShowDeleteCardPopup = False
model.variables.showDeleteCardPopupVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Dt_JobiCyEuFm2pmG4QLEQ", callContext.id);
// Execute Action: Success
ShopperPortalEU_UI_ThemeController.default.customMessageTrigger$Action(function () {
var rec = new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customMessageType.success;
rec.titleAttr = "Card deleted";
return rec;
}(), callContext);
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:bi2oJvm4UUSbkil8I55b+Q", callContext.id) && !(model.variables.cardsVar.isEmpty))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:agH0Pr1TzEyMjuOwyE89Qg", callContext.id);
// IsDataFetched = True
model.variables.isDataFetchedVar = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:jTmnwIhj906mfUdmYIWq4Q", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Vo5pQVV1J0a14AHddjMjNQ", callContext.id);
// Destination: /ShopperPortalEU/MyProfile
return OS.Flow.returnAsync(OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "MyProfile", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.None), callContext, true));
}

} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Q9iH9fDXMEqSjAwZ_kAdHQ", callContext.id);
// Execute Action: ErrorMessage2
ShopperPortalEU_UI_ThemeController.default.customMessageTrigger$Action(function () {
var rec = new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customMessageType.error;
rec.titleAttr = getCardsVar.value.errorMessageOut;
rec.contentAttr = OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.defaultErrorMessage$Action(callContext).errorMessageOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
rec.testIdAttr = "Error";
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:K52KArnGHEmupzIjOFP4wg", callContext.id);
// IsDataFetched = True
model.variables.isDataFetchedVar = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:wLJ0MWbG40ORjV1xwzaGnQ", callContext.id);
}

});
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:8NZhOSOh406LHGT9NFs9dg", callContext.id);
// Execute Action: ErrorMessage
ShopperPortalEU_UI_ThemeController.default.customMessageTrigger$Action(function () {
var rec = new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customMessageType.error;
rec.titleAttr = deleteCreditCardVar.value.errorMessageOut;
rec.contentAttr = OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.defaultErrorMessage$Action(callContext).errorMessageOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
rec.testIdAttr = "Error";
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:jp2Xl8k7kU+xVnN8J_XR0g", callContext.id);
// IsDataFetched = True
model.variables.isDataFetchedVar = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Rr79T06n7ECE6bECiMKsvg", callContext.id);
}

});
});
}).then(function (res) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:QcIz2TXsu02DN7ODJWdqUw", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:QcIz2TXsu02DN7ODJWdqUw", callContext.id);
throw ex;

});
};

Controller.prototype.onInitialize$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onInitialize$Action, callContext);

};
Controller.prototype.backOnClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._backOnClick$Action, callContext);

};
Controller.prototype.closeDeleteCardPopup$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._closeDeleteCardPopup$Action, callContext);

};
Controller.prototype.isDefaultOnClick$Action = function (cardIn, cardIndexIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._isDefaultOnClick$Action, callContext, cardIn, cardIndexIn);

};
Controller.prototype.onAfterAuthentication$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onAfterAuthentication$Action, callContext);

};
Controller.prototype.openDeleteCardPopup$Action = function (cardToBeDeletedIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._openDeleteCardPopup$Action, callContext, cardToBeDeletedIn);

};
Controller.prototype.creditCardOnEmptyClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._creditCardOnEmptyClick$Action, callContext);

};
Controller.prototype.onDeleteCard$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onDeleteCard$Action, callContext);

};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:fWtJs57lI0qCTlwkcDoxDA:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA:ONNPtNNl6kvn+nbnL5quzA", "ShopperPortalEU", "CreditCard", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:LginJlkFIEek4mCs_hfVAA:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.LginJlkFIEek4mCs_hfVAA:+iOhAnF_onV3beHFuqLBvA", "ShopperPortalEU", "MyWallet", "NRNodes.WebScreen", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:LginJlkFIEek4mCs_hfVAA", callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:fWtJs57lI0qCTlwkcDoxDA", callContext.id);
};
Controller.prototype.onInitializeEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "CreditCard/MyWallet On Initialize");
return controller.onInitialize$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return ShopperPortalEU_CreditCardController.default.handleError(ex, this.callContext());
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return ShopperPortalEUController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, ShopperPortalEULanguageResources);
});

define("ShopperPortalEU.CreditCard.MyWallet.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"sGLF6rxp7kOjQZHt5IyW7A": {
getter: function (varBag, idService) {
return varBag.vars.value.cardInLocal;
}
},
"ukCrpPQJokKv+a_wyFUfAA": {
getter: function (varBag, idService) {
return varBag.vars.value.cardIndexInLocal;
},
dataType: OS.DataTypes.DataTypes.Integer
},
"+MfvUlXFDUu0SVw8SP0FHQ": {
getter: function (varBag, idService) {
return varBag.updateCardVar.value;
}
},
"F5f3s_6aUUWfFP835SCGBA": {
getter: function (varBag, idService) {
return varBag.getCardsVar.value;
}
},
"BmrHbq8UMUuPqTSaXkbD1g": {
getter: function (varBag, idService) {
return varBag.vars.value.cardToBeDeletedInLocal;
}
},
"DFDjo2HbGUOqNPbV7+0saA": {
getter: function (varBag, idService) {
return varBag.getCardsVar.value;
}
},
"eMlV2WrtTU2Zjzm3t92tfg": {
getter: function (varBag, idService) {
return varBag.deleteCreditCardVar.value;
}
},
"IBIrkwsdX0q5UA00L2N+_Q": {
getter: function (varBag, idService) {
return varBag.model.variables.isDataFetchedVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"_48Uzhp6+E2bf89ipSNIcA": {
getter: function (varBag, idService) {
return varBag.model.variables.cardsVar;
}
},
"18VGi6qAPk2vNKkk5iApRA": {
getter: function (varBag, idService) {
return varBag.model.variables.showDeleteCardPopupVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"kWQ2AIU7akyKUYvFTpblJQ": {
getter: function (varBag, idService) {
return varBag.model.variables.cardSelectedVar;
}
},
"HfxcDodMjEuCSoS1fcE_xw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderLeft"));
})(varBag.model, idService);
}
},
"++aFCynBvEiWYOUCl4y+4w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderCenter"));
})(varBag.model, idService);
}
},
"mLsypD8bbk+rtuJ0CrhC6Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderRight"));
})(varBag.model, idService);
}
},
"VJcccMSO5Eq84tisQImVlA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"+MdLUvM3BkusnJwFikj9Mw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"+86QuhL9PUGkHwgOtSH37w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"7mjBcSzMBUio4_hLOo1T0g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("RightContent"));
})(varBag.model, idService);
}
},
"ZKMQwJBMp0KnP_EiVIyQIw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"yQeKJAO+CkOoGZyV2hRHxQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Number"));
})(varBag.model, idService);
}
},
"AHh2ngydXEy8IH0Dv4J8eg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("ExpiryDate"));
})(varBag.model, idService);
}
},
"sB_djAZeBEas2iPodR87DA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("CardHolder"));
})(varBag.model, idService);
}
},
"vYOsmWMTA0y7Cd7WNI1G+Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Empty"));
})(varBag.model, idService);
}
},
"0UHnM67C0Eq2NJtAP8qJSw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("BackContent"));
})(varBag.model, idService);
}
},
"JkJPzj6DF0Cc_Jl2iQfWrw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"DaN1vsVxqkKkQ2R2C4ad+A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Switch"));
})(varBag.model, idService);
}
},
"8BkCMMbW202AWZ+n4avCQQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Switch1"));
})(varBag.model, idService);
}
},
"XqV0Iv6NSUOcnYIiWOHmng": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Label"));
})(varBag.model, idService);
}
},
"vZPXrzPFykShE4SkpjIyrQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Button"));
})(varBag.model, idService);
}
},
"VhYZPpMGsE2j0Rt+gPFaSg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"uGStLZc5JkmN2vX7+0pwXQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("RightContent"));
})(varBag.model, idService);
}
},
"9Klt+SQpN0e8v7ZgwCEPMA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Number"));
})(varBag.model, idService);
}
},
"jga_WQMZMka2NQinn+DKyg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("ExpiryDate"));
})(varBag.model, idService);
}
},
"1lkHqB38dUKOFZgJ6nzsNg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("CardHolder"));
})(varBag.model, idService);
}
},
"CvAU0lDTuEy2eZMEbCKpwQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Empty"));
})(varBag.model, idService);
}
},
"BxG1vSrSbUyxlxn6tBz5UA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"IQ0484zGc0qbY0wSpvCkHg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("BackContent"));
})(varBag.model, idService);
}
},
"16GKzTvRYEm9rYNqERcUKQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Popup"));
})(varBag.model, idService);
}
},
"QE2KRkqqokuRElj1VDPgcQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"ii8AA9iCwUWgMeOv47wiQQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"bjQSfd2L1EOl2fl2iVYIfg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Actions"));
})(varBag.model, idService);
}
},
"uhdPE2D6_EC5skoRocAxGg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"mIM2wlP3l0mvbZwEsk14fQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Button"));
})(varBag.model, idService);
}
},
"KbWrGjbI4E+meSvL1UP8og": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"4S5DlwWIlEuzB0mMl5stMg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Button"));
})(varBag.model, idService);
}
},
"r7WEUAsMf0+uuvJ0Vaa7aA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"Qx7vzwNNFEWr4jpKx4_P7A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Bottom"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
