define("ShopperPortalEU.appDefinition", ["OutSystems/ClientRuntime/Main"], function (OutSystems) {
var OS = OutSystems.Internal;
return {
environmentKey: "9901269e-007b-499d-a5c5-d38e1db2bba9",
environmentName: "Global TES",
applicationKey: "585643ef-6965-4626-a771-dcbb2140764a",
applicationName: "Shopper Portal EU",
userProviderName: "Users",
debugEnabled: true,
homeModuleName: "ShopperPortalEU",
homeModuleKey: "a39a55b1-a77d-4201-9e63-13cf01c8ea2a",
homeModuleControllerName: "ShopperPortalEU.controller",
homeModuleLanguageResourcesName: "ShopperPortalEU.languageResources",
defaultTransition: "Fade",
errorPageConfig: {
showExceptionStack: false
},
isWeb: true,
personalArea: null,
showWatermark: false
};
});
