define("ShopperPortalEU.Profile.ConfirmPassport.mvc$model", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Theme.controller", "ShopperPortalEU_Shopper_IS.controller", "ShopperPortalEU.Layouts.LayoutDetail.mvc$model", "ShopperPortalEU.LayoutsComponents.Back.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.FullHeightContent.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomColumns.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.LabelValue.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomButton.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomButtonItem.mvc$model", "ShopperPortalEU.controller$FormatEmptyString", "ShopperPortalEU.controller$FormatDate", "ShopperPortalEU.controller$GetCountryName", "ShopperPortalEU.model$ScanPassportRec", "ShopperPortalEU_UI_Theme.model$LayoutDetailOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU_UI_Components.model$FullHeightContentOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$FullHeightContentTopOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentBottomOptionsRec", "ShopperPortalEU_UI_Components.model$CustomColumnsOptionsRec", "ShopperPortalEU_UI_Components.model$LabelValueOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconRec", "ShopperPortalEU.controller$ClarityEvent", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", "ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger", "ShopperPortalEU.controller$ClarityEventPassportAlreadyExists", "ShopperPortalEU_Shopper_IS.controller$CreateTravelDocument", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS", "ShopperPortalEU.controller$DefaultErrorMessage"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ThemeController, ShopperPortalEU_Shopper_ISController, ShopperPortalEU_Layouts_LayoutDetail_mvcModel, ShopperPortalEU_LayoutsComponents_Back_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomColumns_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_LabelValue_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvcModel) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("IsSaving", "isSavingVar", "IsSaving", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("Passport", "passportVar", "Passport", true, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEUModel.ScanPassportRec());
}, false, ShopperPortalEUModel.ScanPassportRec)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Model._hasValidationWidgetsValue = undefined;
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
if((Model._hasValidationWidgetsValue === undefined)) {
Model._hasValidationWidgetsValue = ((((((ShopperPortalEU_Layouts_LayoutDetail_mvcModel.hasValidationWidgets || ShopperPortalEU_LayoutsComponents_Back_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomColumns_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_LabelValue_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvcModel.hasValidationWidgets);
}

return Model._hasValidationWidgetsValue;
}
});

Model.prototype.setInputs = function (inputs) {
};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "Profile.ConfirmPassport");
});
define("ShopperPortalEU.Profile.ConfirmPassport.mvc$view", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Theme.controller", "ShopperPortalEU_Shopper_IS.controller", "react", "OutSystems/ReactView/Main", "ShopperPortalEU.Profile.ConfirmPassport.mvc$model", "ShopperPortalEU.Profile.ConfirmPassport.mvc$controller", "ShopperPortalEU.clientVariables", "ShopperPortalEU.Layouts.LayoutDetail.mvc$view", "OutSystems/ReactWidgets/Main", "ShopperPortalEU.LayoutsComponents.Back.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.FullHeightContent.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomColumns.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.LabelValue.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomButton.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomButtonItem.mvc$view", "ShopperPortalEU.controller$FormatEmptyString", "ShopperPortalEU.controller$FormatDate", "ShopperPortalEU.controller$GetCountryName", "ShopperPortalEU.model$ScanPassportRec", "ShopperPortalEU_UI_Theme.model$LayoutDetailOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU_UI_Components.model$FullHeightContentOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$FullHeightContentTopOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentBottomOptionsRec", "ShopperPortalEU_UI_Components.model$CustomColumnsOptionsRec", "ShopperPortalEU_UI_Components.model$LabelValueOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconRec", "ShopperPortalEU.controller$ClarityEvent", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", "ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger", "ShopperPortalEU.controller$ClarityEventPassportAlreadyExists", "ShopperPortalEU_Shopper_IS.controller$CreateTravelDocument", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS", "ShopperPortalEU.controller$DefaultErrorMessage"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ThemeController, ShopperPortalEU_Shopper_ISController, React, OSView, ShopperPortalEU_Profile_ConfirmPassport_mvc_model, ShopperPortalEU_Profile_ConfirmPassport_mvc_controller, ShopperPortalEUClientVariables, ShopperPortalEU_Layouts_LayoutDetail_mvc_view, OSWidgets, ShopperPortalEU_LayoutsComponents_Back_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomColumns_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_LabelValue_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            var thisIsInstanceOfSuper = this instanceof _super;
            if (thisIsInstanceOfSuper == false) {
                return;
            }

            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "Profile.ConfirmPassport";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css", "css/ShopperPortalEU_UI_Theme.ShopperPortalEUUITheme.css", "css/ShopperPortalEU.ShopperPortalEU.css", "css/ShopperPortalEU_UI_Theme.ShopperPortalEUUITheme.extra.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [ShopperPortalEU_Layouts_LayoutDetail_mvc_view, ShopperPortalEU_LayoutsComponents_Back_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomColumns_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_LabelValue_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return ShopperPortalEU_Profile_ConfirmPassport_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return ShopperPortalEU_Profile_ConfirmPassport_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "Shopper Portal EU - Confirm passport details";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(ShopperPortalEU_Layouts_LayoutDetail_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("gZOl1HeMGkWiG1PbjhRK2w.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ThemeModel.LayoutDetailOptionsRec();
rec.headerStepsAttr = function () {
var rec = new ShopperPortalEU_UI_ThemeModel.HeaderStepsOptionsRec();
rec.stepsAttr = (((ShopperPortalEUClientVariables.getScanPassportRedirect() === 1)) ? (0) : (4));
rec.currentStepAttr = (((ShopperPortalEUClientVariables.getScanPassportRedirect() === 1)) ? (0) : (3));
return rec;
}();
return rec;
}();
}, function () {
return ShopperPortalEUClientVariables.getScanPassportRedirect();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "0",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
headerLeft: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_LayoutsComponents_Back_mvc_view, {
inputs: {
ManualRedirect: true
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onClick$Action: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "LayoutsComponents/Back OnClick");
controller.back$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "1",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}),
headerCenter: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "ConfirmPassportTitle"
},
value: model.getCachedValue(idService.getId("stKbirDi+0ivIlc3BbADnQ.Value"), function () {
return (((ShopperPortalEUClientVariables.getScanPassportRedirect() === 0)) ? ("Confirm passport details") : ("Add Passport"));
}, function () {
return ShopperPortalEUClientVariables.getScanPassportRedirect();
}),
_idProps: {
service: idService,
uuid: "2"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
headerRight: PlaceholderContent.Empty,
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("VqssK1hIDE2d940anyeJ5A.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FullHeightContentOptionsRec();
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space4;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "3",
alias: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
top: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomColumns_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("W0NED49rakuljDlNeKdr8g.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomColumnsOptionsRec();
rec.columnsAttr = 1;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space4;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "4",
alias: "4"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_LabelValue_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("OdPl_RpGAUGqjNDsG49QGw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.LabelValueOptionsRec();
rec.testIdAttr = "PassportNumber";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "5",
alias: "5"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
label: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Passport number",
_idProps: {
service: idService,
uuid: "6"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
value: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: model.getCachedValue(idService.getId("1a2gNUjR5EaHQ1Tv3ipv7A.Value"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.formatEmptyString$Action(OS.BuiltinFunctions.trim(model.variables.passportVar.documentNumberAttr), callContext).formattedStringOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
}, function () {
return model.variables.passportVar.documentNumberAttr;
}),
_idProps: {
service: idService,
uuid: "7"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.passportVar.documentNumberAttr)]
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_LabelValue_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("yyYhM+Bk5kGTrkzozB0RhQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.LabelValueOptionsRec();
rec.testIdAttr = "PassportDateOfExpiry";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "8",
alias: "6"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
label: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Passport date of expiry",
_idProps: {
service: idService,
uuid: "9"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
value: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: model.getCachedValue(idService.getId("kvcHFnKygkqI0olP1SkJ0g.Value"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.formatDate$Action(OS.BuiltinFunctions.dateTimeToDate(model.variables.passportVar.dateOfExpiryAttr), callContext).formattedDateOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
}, function () {
return model.variables.passportVar.dateOfExpiryAttr;
}),
_idProps: {
service: idService,
uuid: "10"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.passportVar.dateOfExpiryAttr)]
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_LabelValue_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("9cnYB0OcQ0mg3PvssGvuZQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.LabelValueOptionsRec();
rec.testIdAttr = "PassportCountry";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "11",
alias: "7"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
label: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Passport country",
_idProps: {
service: idService,
uuid: "12"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
value: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: model.getCachedValue(idService.getId("VSgocULtvEW2q6PV26auOg.Value"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.formatEmptyString$Action(OS.BuiltinFunctions.trim(OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.getCountryName$Action(model.variables.passportVar.issuingCountryCodeAttr, callContext).nameOut;
}, OS.DataTypes.DataTypes.Text, callContext.id)), callContext).formattedStringOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
}, function () {
return model.variables.passportVar.issuingCountryCodeAttr;
}),
_idProps: {
service: idService,
uuid: "13"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.passportVar.issuingCountryCodeAttr)]
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "body-3",
visible: true,
_idProps: {
service: idService,
uuid: "14"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "IncorrectDetailsDescription"
},
value: "Incorrect details? ",
_idProps: {
service: idService,
uuid: "15"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("vPsvq0ZUkkWjexUhjCHXQQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRec();
rec.testIdAttr = "ScanPassportAgainLink";
rec.typeAttr = ShopperPortalEUModel.staticEntities.customButtonType.linkPrimary;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "16",
alias: "8"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
button: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: false,
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Profile/ConfirmPassport/Button OnClick");
controller.scanPassportAgain$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn",
visible: true,
_idProps: {
service: idService,
uuid: "17"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "18",
alias: "9"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Scan passport again",
_idProps: {
service: idService,
uuid: "19"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables.passportVar.issuingCountryCodeAttr), asPrimitiveValue(model.variables.passportVar.dateOfExpiryAttr), asPrimitiveValue(model.variables.passportVar.documentNumberAttr)]
})];
}),
bottom: new PlaceholderContent(function () {
return [$if((ShopperPortalEUClientVariables.getScanPassportRedirect() === 0), false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("HQFbezvtokS2S78qhjvLoA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRec();
rec.testIdAttr = "ConfirmButton";
rec.typeAttr = ShopperPortalEUModel.staticEntities.customButtonType.primary;
rec.isLoadingAttr = model.variables.isSavingVar;
rec.isFullWidthAttr = true;
return rec;
}();
}, function () {
return model.variables.isSavingVar;
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "20",
alias: "10"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
button: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: false,
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Profile/ConfirmPassport/Button OnClick");
return controller.save$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
style: "btn",
visible: true,
_idProps: {
service: idService,
uuid: "21"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "22",
alias: "11"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Confirm and continue",
_idProps: {
service: idService,
uuid: "23"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
})];
}, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("ajyyFzLS1keoF1hSut6gwA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRec();
rec.testIdAttr = "CancelPassportButton";
rec.typeAttr = ShopperPortalEUModel.staticEntities.customButtonType.reverse;
rec.isFullWidthAttr = true;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "24",
alias: "12"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
button: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: false,
onClick: function () {
_this.validateWidget("");
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Profile/ConfirmPassport/Button OnClick");
controller.cancel$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});


;
},
style: "btn",
visible: true,
_idProps: {
service: idService,
uuid: "25"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "26",
alias: "13"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Cancel",
_idProps: {
service: idService,
uuid: "27"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-top-04",
visible: true,
_idProps: {
service: idService,
uuid: "28"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("lGRNhu4760aE1sp9y0fihQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRec();
rec.testIdAttr = "SavePassportButton";
rec.typeAttr = ShopperPortalEUModel.staticEntities.customButtonType.primary;
rec.isLoadingAttr = model.variables.isSavingVar;
rec.isFullWidthAttr = true;
return rec;
}();
}, function () {
return model.variables.isSavingVar;
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "29",
alias: "14"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
button: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: false,
onClick: function () {
_this.validateWidget("");
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Profile/ConfirmPassport/Button OnClick");
return controller.save$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});

;
},
style: "btn",
visible: true,
_idProps: {
service: idService,
uuid: "30"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "31",
alias: "15"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Save",
_idProps: {
service: idService,
uuid: "32"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
}))];
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.isSavingVar), asPrimitiveValue(ShopperPortalEUClientVariables.getScanPassportRedirect()), asPrimitiveValue(model.variables.passportVar.issuingCountryCodeAttr), asPrimitiveValue(model.variables.passportVar.dateOfExpiryAttr), asPrimitiveValue(model.variables.passportVar.documentNumberAttr)]
})];
}),
bottom: PlaceholderContent.Empty
},
_dependencies: [asPrimitiveValue(model.variables.isSavingVar), asPrimitiveValue(model.variables.passportVar.issuingCountryCodeAttr), asPrimitiveValue(model.variables.passportVar.dateOfExpiryAttr), asPrimitiveValue(model.variables.passportVar.documentNumberAttr), asPrimitiveValue(ShopperPortalEUClientVariables.getScanPassportRedirect())]
}));
        };
        return View;
    })(OSView.BaseView.BaseWebScreen);
	
    return View;
});
define("ShopperPortalEU.Profile.ConfirmPassport.mvc$controller", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Theme.controller", "ShopperPortalEU_Shopper_IS.controller", "ShopperPortalEU.languageResources", "ShopperPortalEU.clientVariables", "ShopperPortalEU.Profile.ConfirmPassport.mvc$debugger", "ShopperPortalEU.Profile.controller", "ShopperPortalEU.controller$FormatEmptyString", "ShopperPortalEU.controller$FormatDate", "ShopperPortalEU.controller$GetCountryName", "ShopperPortalEU.model$ScanPassportRec", "ShopperPortalEU_UI_Theme.model$LayoutDetailOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU_UI_Components.model$FullHeightContentOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$FullHeightContentTopOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentBottomOptionsRec", "ShopperPortalEU_UI_Components.model$CustomColumnsOptionsRec", "ShopperPortalEU_UI_Components.model$LabelValueOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconRec", "ShopperPortalEU.controller$ClarityEvent", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", "ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger", "ShopperPortalEU.controller$ClarityEventPassportAlreadyExists", "ShopperPortalEU_Shopper_IS.controller$CreateTravelDocument", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS", "ShopperPortalEU.controller$DefaultErrorMessage"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ThemeController, ShopperPortalEU_Shopper_ISController, ShopperPortalEULanguageResources, ShopperPortalEUClientVariables, ShopperPortalEU_Profile_ConfirmPassport_mvc_Debugger, ShopperPortalEU_ProfileController) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = true;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._onInitialize$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnInitialize");
callContext = controller.callContext(callContext);
var scanPassportFromJSONVar = new OS.DataTypes.VariableHolder(new (OS.Controller.BaseController.getJSONDeserializeOutputType(ShopperPortalEUModel.ScanPassportRec))());
varBag.callContext = callContext;
varBag.scanPassportFromJSONVar = scanPassportFromJSONVar;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:6HqACx+f3EysW7qI4N+ZNQ:/NRWebFlows.G6g8LlI0+UqpwXA+JmvtFg/NodesShownInESpaceTree.5ku8_Q3ggkuag3Gx5bCGSw/ClientActions.6HqACx+f3EysW7qI4N+ZNQ:5nesokaiWypL8KrBjAZb3w", "ShopperPortalEU", "OnInitialize", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:mVeytZeB3UOXVJSWb7WH2A", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:v4Xfo48mGkaKcYTp98IRww", callContext.id);
// JSON Deserialize: ScanPassportFromJSON
scanPassportFromJSONVar.value.dataOut = OS.JSONUtils.deserializeFromJSON(ShopperPortalEUClientVariables.getShopperPassportDataTemp(), ShopperPortalEUModel.ScanPassportRec, false);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:plcNxa6Fbkexs4mHAEpb5w", callContext.id);
// Passport = ScanPassportFromJSON.Data
model.variables.passportVar = scanPassportFromJSONVar.value.dataOut;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:rwIG2DDEB0yWZWdnjjiqQg", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:6HqACx+f3EysW7qI4N+ZNQ", callContext.id);
}

};
Controller.prototype._scanPassportAgain$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("ScanPassportAgain");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:Fx1COFcwgUKfPqDwR1DJfg:/NRWebFlows.G6g8LlI0+UqpwXA+JmvtFg/NodesShownInESpaceTree.5ku8_Q3ggkuag3Gx5bCGSw/ClientActions.Fx1COFcwgUKfPqDwR1DJfg:tkXl0ltDglA4Z6VcLCcNqg", "ShopperPortalEU", "ScanPassportAgain", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:p89DDn31VE28a75tRx2_HA", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:FR6byhVtUUGk+5KZkFCfLw", callContext.id);
// Execute Action: ClarityEvent
ShopperPortalEUController.default.clarityEvent$Action("ScanPassportAgain_link", callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:piPp32Stf0ezP+J3wGeLMA", callContext.id);
// Destination: /ShopperPortalEU/ScanPassport
return OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "ScanPassport", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:Fx1COFcwgUKfPqDwR1DJfg", callContext.id);
}

};
Controller.prototype._cancel$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Cancel");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:V5Azb0_Wv0OsLVqrps1G0g:/NRWebFlows.G6g8LlI0+UqpwXA+JmvtFg/NodesShownInESpaceTree.5ku8_Q3ggkuag3Gx5bCGSw/ClientActions.V5Azb0_Wv0OsLVqrps1G0g:0trQ5Q1Rujlg4jWFeJjd1w", "ShopperPortalEU", "Cancel", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:fu5tQ33SC0aADyooSLo7zA", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ib+mc__xsESuKk7BoB6ZsA", callContext.id);
// Execute Action: ClarityEvent
ShopperPortalEUController.default.clarityEvent$Action("PassportCancel_btn", callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Wy8e+nogfESQQQdFZaf5GQ", callContext.id);
// Destination: /ShopperPortalEU/Passports
return OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "Passports", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:V5Azb0_Wv0OsLVqrps1G0g", callContext.id);
}

};
Controller.prototype._save$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Save");
callContext = controller.callContext(callContext);
var allExceptionsVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.ErrorHandlerOutputType());
var createTravelDocumentVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.allExceptionsVar = allExceptionsVar;
varBag.createTravelDocumentVar = createTravelDocumentVar;
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:riT6z8lvMEeIxU6DRX+7IQ:/NRWebFlows.G6g8LlI0+UqpwXA+JmvtFg/NodesShownInESpaceTree.5ku8_Q3ggkuag3Gx5bCGSw/ClientActions.riT6z8lvMEeIxU6DRX+7IQ:mekh2+_wdcooIJe3k1y5BA", "ShopperPortalEU", "Save", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:iwYE1qBKzUmZhihfVHCYEQ", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:JNTqewCy2kOqljADZ5VFVw", callContext.id);
// IsSaving = True
model.variables.isSavingVar = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Ag4Uik34KEmbK9rMJ3uZng", callContext.id);
// Execute Action: ClarityEvent
ShopperPortalEUController.default.clarityEvent$Action((((ShopperPortalEUClientVariables.getScanPassportRedirect() === 0)) ? ("ConfirmContinue_btn") : ("SavePassport_btn")), callContext);
// Valid expiry date
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:plqSKNq3I0mz_V5tNGg6bA", callContext.id) && OS.BuiltinFunctions.dateTimeToDate(model.variables.passportVar.dateOfExpiryAttr).gte(OS.BuiltinFunctions.currDate()))) {
// Valid number and country 
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:2HStltLve0mQ0S3rZrCZvQ", callContext.id) && (((model.variables.passportVar.issuingCountryCodeAttr) !== ("")) && ((model.variables.passportVar.documentNumberAttr) !== (""))))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:JPqY8ZsJQk+jPNlmnE1bkQ", callContext.id);
// Execute Action: CreateTravelDocument
model.flush();
return ShopperPortalEU_Shopper_ISController.default.createTravelDocument$Action(ShopperPortalEUClientVariables.getShopperGuid(), model.variables.passportVar.documentNumberAttr, OS.BuiltinFunctions.textToLongInteger(model.variables.passportVar.issuingCountryCodeAttr), OS.BuiltinFunctions.dateTimeToDate(model.variables.passportVar.dateOfExpiryAttr), callContext).then(function (value) {
createTravelDocumentVar.value = value;
}).then(function () {
// Success
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:fQ_7AFSFKk6VsLTZG6wGFw", callContext.id) && createTravelDocumentVar.value.isSuccessOut)) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:rl476kxrOEy6FyKCeBwOEg", callContext.id);
// ShopperPassports = ShopperPassports + 1
ShopperPortalEUClientVariables.setShopperPassports((ShopperPortalEUClientVariables.getShopperPassports() + 1));
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:rl476kxrOEy6FyKCeBwOEg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// IsSaving = False
model.variables.isSavingVar = false;
// Add passport flow ?
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:trHyXGqIEU2mukblANePKg", callContext.id) && (ShopperPortalEUClientVariables.getScanPassportRedirect() === 1))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:AqD9I650y0OKu6o1Q3sKZg", callContext.id);
// Execute Action: CreatePassportSuccess
ShopperPortalEU_UI_ThemeController.default.customMessageTrigger$Action(function () {
var rec = new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customMessageType.success;
rec.titleAttr = "Passport added";
rec.testIdAttr = "PassportAddedConfirmation";
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Q14WQ6d8PkulHe3PV99j1Q", callContext.id);
// Destination: /ShopperPortalEU/Passports
return OS.Flow.returnAsync(OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "Passports", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true));
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:TuRqxgg4oEyEss5JAJy_rg", callContext.id);
// Destination: /ShopperPortalEU/CompleteDetails
return OS.Flow.returnAsync(OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "CompleteDetails", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true));
}

} else {
// Travel document already exists
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:6Nlq9phGTkWfnXWtECs8IQ", callContext.id) && (createTravelDocumentVar.value.errorCodeOut === "D6008"))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:yiY4nS0bB06ArtIz6OSbEA", callContext.id);
// Execute Action: ClarityPassportCreate
ShopperPortalEUController.default.clarityEventPassportAlreadyExists$Action(callContext);
}

OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:7Q2K7xhYSEicvrCipgfimg", callContext.id);
// Execute Action: CreatePassportError
ShopperPortalEU_UI_ThemeController.default.customMessageTrigger$Action(function () {
var rec = new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customMessageType.error;
rec.titleAttr = "Failed to confirm passport details";
rec.contentAttr = OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.defaultErrorMessage$Action(callContext).errorMessageOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
rec.testIdAttr = "PassportConfirmError";
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:h2YM656nhEy2NWBJh9svtg", callContext.id);
// IsSaving = False
model.variables.isSavingVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:zBUCROF82UKiHGhOKwqjMg", callContext.id);
}

});
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:0tF4nL4oikyPqk7Q_BEOTA", callContext.id);
// Execute Action: InvalidPassportMessage
ShopperPortalEU_UI_ThemeController.default.customMessageTrigger$Action(function () {
var rec = new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customMessageType.error;
rec.titleAttr = "Passport invalid";
rec.contentAttr = "Use a valid passport to continue.";
rec.testIdAttr = "PassportExpiredErrorMessage";
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:shbHxsYFe0qHHug98Q_DVw", callContext.id);
// IsSaving = False
model.variables.isSavingVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:LEDI8D7uME2zGTrftd7wUA", callContext.id);
}

});
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Q2eiAhlwMEu4j0S69zGSgQ", callContext.id);
// Execute Action: DateOfExpiryMessage
ShopperPortalEU_UI_ThemeController.default.customMessageTrigger$Action(function () {
var rec = new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customMessageType.error;
rec.titleAttr = "Passport expired";
rec.contentAttr = (("Your passport expired on " + OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.formatDate$Action(OS.BuiltinFunctions.dateTimeToDate(model.variables.passportVar.dateOfExpiryAttr), callContext).formattedDateOut;
}, OS.DataTypes.DataTypes.Text, callContext.id)) + ".<br>Use a valid passport to continue.");
rec.testIdAttr = "PassportExpiredErrorMessage";
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:5h7LUGKP10y68C1UYrI1hw", callContext.id);
// IsSaving = False
model.variables.isSavingVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:MbKgTkNGb02u2Wij1R8Fbg", callContext.id);
}

});
}).catch(function (ex) {
OS.Logger.trace("ConfirmPassport.Save", OS.Exceptions.getMessage(ex), ex.name);
// Handle Error: AllExceptions
if(!(OS.Exceptions.isSystem(ex))) {
OS.Logger.error(null, ex);
allExceptionsVar.value.exceptionMessageAttr = OS.Exceptions.getMessage(ex);
OutSystemsDebugger.handleException(allExceptionsVar.value.exceptionMessageAttr, callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:lOpXDnl3ek+sx2EhQZIoZA", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:piUhoA1L20OMwKi3063VbA", callContext.id);
// IsSaving = False
model.variables.isSavingVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:y1rhhArU70ecyZhTsqjRbQ", callContext.id);
// Execute Action: GenericErrorMessage
ShopperPortalEU_UI_ThemeController.default.customMessageTrigger$Action(function () {
var rec = new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customMessageType.error;
rec.titleAttr = "Failed to confirm passport details";
rec.contentAttr = OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.defaultErrorMessage$Action(callContext).errorMessageOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
rec.testIdAttr = "PassportConfirmGenericError";
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:wEvXXTayR06GuFTQFN+bXg", callContext.id);
return OS.Flow.returnAsync();

});
}

throw ex;
}).then(function (res) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:riT6z8lvMEeIxU6DRX+7IQ", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:riT6z8lvMEeIxU6DRX+7IQ", callContext.id);
throw ex;

});
};
Controller.prototype._back$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Back");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:jxs7+0VIP0Kr5mbS1nkOIg:/NRWebFlows.G6g8LlI0+UqpwXA+JmvtFg/NodesShownInESpaceTree.5ku8_Q3ggkuag3Gx5bCGSw/ClientActions.jxs7+0VIP0Kr5mbS1nkOIg:6n6_ZbSJl212Dh2E0GjAhQ", "ShopperPortalEU", "Back", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:6tr2rPeYfkCAOhR0dBOTDQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:2V50MiGGg0OTjon7Af+Dxg", callContext.id);
// Destination: /ShopperPortalEU/ScanPassport
return OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "ScanPassport", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:jxs7+0VIP0Kr5mbS1nkOIg", callContext.id);
}

};

Controller.prototype.onInitialize$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onInitialize$Action, callContext);

};
Controller.prototype.scanPassportAgain$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._scanPassportAgain$Action, callContext);

};
Controller.prototype.cancel$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._cancel$Action, callContext);

};
Controller.prototype.save$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._save$Action, callContext);

};
Controller.prototype.back$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._back$Action, callContext);

};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:G6g8LlI0+UqpwXA+JmvtFg:/NRWebFlows.G6g8LlI0+UqpwXA+JmvtFg:yposeKjmRCh6Km0A8t9bYg", "ShopperPortalEU", "Profile", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:5ku8_Q3ggkuag3Gx5bCGSw:/NRWebFlows.G6g8LlI0+UqpwXA+JmvtFg/NodesShownInESpaceTree.5ku8_Q3ggkuag3Gx5bCGSw:WwFIhtHkiSlUz+fet6ug4g", "ShopperPortalEU", "ConfirmPassport", "NRNodes.WebScreen", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:5ku8_Q3ggkuag3Gx5bCGSw", callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:G6g8LlI0+UqpwXA+JmvtFg", callContext.id);
};
Controller.prototype.onInitializeEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Profile/ConfirmPassport On Initialize");
return controller.onInitialize$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return ShopperPortalEU_ProfileController.default.handleError(ex, this.callContext());
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return ShopperPortalEUController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, ShopperPortalEULanguageResources);
});

define("ShopperPortalEU.Profile.ConfirmPassport.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"v4Xfo48mGkaKcYTp98IRww": {
getter: function (varBag, idService) {
return varBag.scanPassportFromJSONVar.value;
}
},
"lOpXDnl3ek+sx2EhQZIoZA": {
getter: function (varBag, idService) {
return varBag.allExceptionsVar.value;
}
},
"JPqY8ZsJQk+jPNlmnE1bkQ": {
getter: function (varBag, idService) {
return varBag.createTravelDocumentVar.value;
}
},
"eNf2QhufD0WGAwgQ2sC_ZQ": {
getter: function (varBag, idService) {
return varBag.model.variables.isSavingVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"OXWEB2+GT0CyN+CyJE6GOQ": {
getter: function (varBag, idService) {
return varBag.model.variables.passportVar;
}
},
"WaCydPK5TUSYgfM6+4TIOw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderLeft"));
})(varBag.model, idService);
}
},
"V5kOpZPuREWxdcW7kIV1iA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderCenter"));
})(varBag.model, idService);
}
},
"xLuZjlsCsE+iEzhR75sDjA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderRight"));
})(varBag.model, idService);
}
},
"BCq14krWOE2f1FFrgvpnZQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"zwtiJopEbEy4zZUJJ56_fw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Top"));
})(varBag.model, idService);
}
},
"ZxJLN4QL00iQ9sYtAzuslQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"c6xgtR5w80WelaZDctME8w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Label"));
})(varBag.model, idService);
}
},
"j8dY5a0ONUSCB1SbjGsCqw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Value"));
})(varBag.model, idService);
}
},
"ar2JYyJlykSckbGqZEL0Lg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Label"));
})(varBag.model, idService);
}
},
"ZyEOQi9YTEa1g3OvhyP75w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Value"));
})(varBag.model, idService);
}
},
"9mTN6kuAvECQnjN7y+Tqew": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Label"));
})(varBag.model, idService);
}
},
"SwdFL2dBgkCztgKFkVAaJw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Value"));
})(varBag.model, idService);
}
},
"VFgDHjVYEk6byYEwRqZjXg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Button"));
})(varBag.model, idService);
}
},
"EkT_DZm2MEWJCNXPCox_7Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"q2lkQRu55Uyfpegtnra+tw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Bottom"));
})(varBag.model, idService);
}
},
"+W9VOMTb1kSwd+9+xY2HSg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Button"));
})(varBag.model, idService);
}
},
"zMEu+3MH+0W6fiICRXSAsw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"pdw3tQsslUqZnk6AkkAT7w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Button"));
})(varBag.model, idService);
}
},
"YMTr9HeUC0qfAzAdV4NLuw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"RW_G0HNqIkOhSscQR4o9ag": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Button"));
})(varBag.model, idService);
}
},
"3IsXcwX4V0aBbCBqMnMIJg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"qVV9FY5zdUy31MBYB1gj9g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Bottom"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
