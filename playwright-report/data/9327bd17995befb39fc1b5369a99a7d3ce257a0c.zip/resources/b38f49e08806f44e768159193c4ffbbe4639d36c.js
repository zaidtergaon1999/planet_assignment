define("ShopperPortalEU.InternalComponents.RefundSteps_WB.mvc$model", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCard.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomButton.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomButtonItem.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomAlert.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.BulletsList.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.BulletsListItem.mvc$model", "ShopperPortalEU_UI_Components.model$CustomCardOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconRec", "ShopperPortalEU_UI_Components.model$CustomAlertOptionsRec", "ShopperPortalEU_UI_Components.model$CustomAlertIconOptionsRec", "ShopperPortalEU.controller$ClarityEvent"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEUController, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCard_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomAlert_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_BulletsList_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_BulletsListItem_mvcModel) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("IsToShowRefundBtn", "isToShowRefundBtnVar", "IsToShowRefundBtn", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("FormStatusLabel", "formStatusLabelIn", "FormStatusLabel", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, false), 
this.attr("_formStatusLabelInDataFetchStatus", "_formStatusLabelInDataFetchStatus", "_formStatusLabelInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("FormStatusId", "formStatusIdIn", "FormStatusId", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, false), 
this.attr("_formStatusIdInDataFetchStatus", "_formStatusIdInDataFetchStatus", "_formStatusIdInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Model._hasValidationWidgetsValue = undefined;
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
if((Model._hasValidationWidgetsValue === undefined)) {
Model._hasValidationWidgetsValue = (((((ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCard_mvcModel.hasValidationWidgets || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomAlert_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_BulletsList_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_BulletsListItem_mvcModel.hasValidationWidgets);
}

return Model._hasValidationWidgetsValue;
}
});

Model.prototype.setInputs = function (inputs) {
if("FormStatusLabel" in inputs) {
this.variables.formStatusLabelIn = inputs.FormStatusLabel;
if("_formStatusLabelInDataFetchStatus" in inputs) {
this.variables._formStatusLabelInDataFetchStatus = inputs._formStatusLabelInDataFetchStatus;
}

}

if("FormStatusId" in inputs) {
this.variables.formStatusIdIn = inputs.FormStatusId;
if("_formStatusIdInDataFetchStatus" in inputs) {
this.variables._formStatusIdInDataFetchStatus = inputs._formStatusIdInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "InternalComponents.RefundSteps_WB");
});
define("ShopperPortalEU.InternalComponents.RefundSteps_WB.mvc$view", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Components.model", "react", "OutSystems/ReactView/Main", "ShopperPortalEU.InternalComponents.RefundSteps_WB.mvc$model", "ShopperPortalEU.InternalComponents.RefundSteps_WB.mvc$controller", "ShopperPortalEU.clientVariables", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCard.mvc$view", "OutSystems/ReactWidgets/Main", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomButton.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomButtonItem.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomAlert.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.BulletsList.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.BulletsListItem.mvc$view", "ShopperPortalEU_UI_Components.model$CustomCardOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconRec", "ShopperPortalEU_UI_Components.model$CustomAlertOptionsRec", "ShopperPortalEU_UI_Components.model$CustomAlertIconOptionsRec", "ShopperPortalEU.controller$ClarityEvent"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_UI_ComponentsModel, React, OSView, ShopperPortalEU_InternalComponents_RefundSteps_WB_mvc_model, ShopperPortalEU_InternalComponents_RefundSteps_WB_mvc_controller, ShopperPortalEUClientVariables, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCard_mvc_view, OSWidgets, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomAlert_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_BulletsList_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_BulletsListItem_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            var thisIsInstanceOfSuper = this instanceof _super;
            if (thisIsInstanceOfSuper == false) {
                return;
            }

            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "InternalComponents.RefundSteps_WB";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCard_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomAlert_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_BulletsList_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_BulletsListItem_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return ShopperPortalEU_InternalComponents_RefundSteps_WB_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return ShopperPortalEU_InternalComponents_RefundSteps_WB_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCard_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("IQGAxhqnR0GvZSW_SYJsZA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomCardOptionsRec();
rec.stateAttr = ((((((model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.postRefundApproved_RA3) || (model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.postRefundApproved_RA11)) || (model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.postRefundInProgress)) || (model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.preRefundClaimOngoing))) ? (ShopperPortalEUModel.staticEntities.customCardState.info) : (ShopperPortalEUModel.staticEntities.customCardState.warning));
rec.testIdAttr = "RefundStepsCard";
return rec;
}();
}, function () {
return model.variables.formStatusIdIn;
}),
_optionsInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._formStatusIdInDataFetchStatus)
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "0",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "RefundSteps_StatusTitle"
},
style: "heading6 text-primary-35",
value: model.variables.formStatusLabelIn,
_idProps: {
service: idService,
uuid: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._formStatusLabelInDataFetchStatus)
}), $if((model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.postGetCustomsApproval), false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-top-01 body-3 text-primary-35",
visible: true,
_idProps: {
service: idService,
uuid: "2"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "RefundSteps_Text_Pos1"
},
value: "Go to Customs at your point of departure to validate your Planet Tax Free form. This must be done before leaving the EU, or visit Swiss Customs if you only shopped in Switzerland. Bring your ID, form, goods, and receipt.",
_idProps: {
service: idService,
uuid: "3"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "RefundSteps_Text_Pos2"
},
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
style: "font-bold",
value: "\r\n\r\nIs your form already validated?",
_idProps: {
service: idService,
uuid: "4"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "RefundSteps_Text_Pos3"
},
value: " Drop it in a Planet box/point (if available) or mail it using the prepaid envelope.",
_idProps: {
service: idService,
uuid: "5"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, {
inputs: {
ExtendedClass: "margin-top-02",
Options: model.getCachedValue(idService.getId("wnH7j_Mo80av5nNwDM0Nlw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRec();
rec.testIdAttr = "RefundStepsCardButton";
rec.typeAttr = ShopperPortalEUModel.staticEntities.customButtonType.primary;
rec.isFullWidthAttr = true;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "6",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
button: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: false,
onClick: function () {
OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "Locations", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default));
},
style: "btn",
visible: true,
_idProps: {
service: idService,
uuid: "7"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("uGTRgcaP+kOUON_GSqL_Jg.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonItemOptionsRec();
rec.iconAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsIconRec();
rec.nameAttr = "pin_drop";
return rec;
}();
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "8",
alias: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Find Customs",
_idProps: {
service: idService,
uuid: "9"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
})];
}, function () {
return [$if((model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.postCustomsInspectionRequired), false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-top-01 body-3 text-primary-35",
visible: true,
_idProps: {
service: idService,
uuid: "10"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "RefundSteps_Text_Pos1"
},
value: "Go to Customs to validate your unused goods.",
_idProps: {
service: idService,
uuid: "11"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("217yGd09yUClQb3LkB5YjA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRec();
rec.testIdAttr = "RefundStepsCardButton";
rec.typeAttr = ShopperPortalEUModel.staticEntities.customButtonType.primary;
rec.isFullWidthAttr = true;
return rec;
}();
}),
ExtendedClass: "margin-top-02"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "12",
alias: "4"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
button: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: false,
onClick: function () {
OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "Locations", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default));
},
style: "btn",
visible: true,
_idProps: {
service: idService,
uuid: "13"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("CkR4X_FR5UKl7CD7cBUXkA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonItemOptionsRec();
rec.iconAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsIconRec();
rec.nameAttr = "pin_drop";
return rec;
}();
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "14",
alias: "5"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Find Customs",
_idProps: {
service: idService,
uuid: "15"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
})];
}, function () {
return [$if((model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.postRefundDetailsRequired), false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-top-01 body-3 text-primary-35",
visible: true,
_idProps: {
service: idService,
uuid: "16"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "RefundSteps_Text_Pos1"
},
value: "The refund method is missing.",
_idProps: {
service: idService,
uuid: "17"
},
_widgetRecordProvider: widgetsRecordProvider
})), $if(model.variables.isToShowRefundBtnVar, false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("ODj6pvuFRk+IWrTJRqmUbQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRec();
rec.testIdAttr = "RefundStepsCardButton";
rec.typeAttr = ShopperPortalEUModel.staticEntities.customButtonType.primary;
rec.isFullWidthAttr = true;
return rec;
}();
}),
ExtendedClass: "margin-top-02"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "18",
alias: "6"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
button: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: false,
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "InternalComponents/RefundSteps_WB/Button OnClick");
controller.requestRefund$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn",
visible: true,
_idProps: {
service: idService,
uuid: "19"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("umuHCn5IGE6yu7KLq2ovgQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonItemOptionsRec();
rec.iconAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsIconRec();
rec.nameAttr = "redeem";
return rec;
}();
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "20",
alias: "7"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Request refund",
_idProps: {
service: idService,
uuid: "21"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
})];
}, function () {
return [];
})];
}, function () {
return [$if((model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.postRefundInProgress), false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-top-01 body-3 text-primary-35",
visible: true,
_idProps: {
service: idService,
uuid: "22"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "RefundSteps_Text_Pos1"
},
value: "Your refund is in progress. We kindly ask for your patience as this process may take some time to be finalised.",
_idProps: {
service: idService,
uuid: "23"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
}, function () {
return [$if(((model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.postRefundApproved_RA3) || (model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.postRefundApproved_RA11)), false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-top-01 body-3 text-primary-35",
visible: true,
_idProps: {
service: idService,
uuid: "24"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "RefundSteps_Text_Pos1"
},
value: "Your refund has been approved and we are currently processing it. We\'ll inform you once the process is complete.\r\n\r\nWe kindly ask for your patience as this process may take some time to be finalised.",
_idProps: {
service: idService,
uuid: "25"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
}, function () {
return [$if((model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.postRefundOnHold), false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-top-01 body-3 text-primary-35",
visible: true,
_idProps: {
service: idService,
uuid: "26"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "RefundSteps_Text_Pos1"
},
value: "Your refund is on hold due to missing required documents or refund details.\r\nContact Customer Support for further details.",
_idProps: {
service: idService,
uuid: "27"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("fWpi0Ynw7kWwJL7fTqEZGQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRec();
rec.testIdAttr = "RefundStepsCardButton";
rec.typeAttr = ShopperPortalEUModel.staticEntities.customButtonType.primary;
rec.isFullWidthAttr = true;
return rec;
}();
}),
ExtendedClass: "margin-top-02"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "28",
alias: "8"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
button: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: false,
onClick: function () {
OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "Help", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default));
},
style: "btn",
visible: true,
_idProps: {
service: idService,
uuid: "29"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("xqY6sKylBUOLrwcpRsr2uQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonItemOptionsRec();
rec.iconAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsIconRec();
rec.nameAttr = "person";
return rec;
}();
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "30",
alias: "9"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Contact Customer Support",
_idProps: {
service: idService,
uuid: "31"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
})];
}, function () {
return [$if((model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.postUpdateRefundDetails), false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-top-01 body-3 text-primary-35",
visible: true,
_idProps: {
service: idService,
uuid: "32"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "RefundSteps_Text_Pos1"
},
value: "We were unable to process your refund due to incorrect credit card details provided or an unsuccessful transaction.\r\nContact Customer Support to update the credit card details.",
_idProps: {
service: idService,
uuid: "33"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, {
inputs: {
ExtendedClass: "margin-top-02",
Options: model.getCachedValue(idService.getId("_9sOOCsahEqaOE_fetpvYA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRec();
rec.testIdAttr = "RefundStepsCardButton";
rec.typeAttr = ShopperPortalEUModel.staticEntities.customButtonType.primary;
rec.isFullWidthAttr = true;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "34",
alias: "10"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
button: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: false,
onClick: function () {
OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "Help", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default));
},
style: "btn",
visible: true,
_idProps: {
service: idService,
uuid: "35"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("+8eDn__+OUOc_XGVGBHfDw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonItemOptionsRec();
rec.iconAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsIconRec();
rec.nameAttr = "person";
return rec;
}();
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "36",
alias: "11"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Contact Customer Support",
_idProps: {
service: idService,
uuid: "37"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
})];
}, function () {
return [$if((model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.preGetCustomsApproval), false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-top-01 body-3 text-primary-35",
visible: true,
_idProps: {
service: idService,
uuid: "38"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "RefundSteps_Text_Pos1"
},
value: "Go to Customs at your point of departure to validate your Planet Tax Free form. This must be done before leaving the EU, or visit Swiss Customs if you only shopped in Switzerland. Bring your ID, form, goods, and receipt.",
_idProps: {
service: idService,
uuid: "39"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "RefundSteps_Text_Pos2"
},
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
style: "font-bold",
value: "\r\n\r\nIs your form already validated?",
_idProps: {
service: idService,
uuid: "40"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "RefundSteps_Text_Pos3"
},
value: " Drop it in a Planet box/point (if available) or mail it using the prepaid envelope.",
_idProps: {
service: idService,
uuid: "41"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, {
inputs: {
ExtendedClass: "margin-top-02",
Options: model.getCachedValue(idService.getId("PifcB+HtZEOyCE5qbdGIwg.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRec();
rec.testIdAttr = "RefundStepsCardButton";
rec.typeAttr = ShopperPortalEUModel.staticEntities.customButtonType.primary;
rec.isFullWidthAttr = true;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "42",
alias: "12"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
button: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: false,
onClick: function () {
OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "Locations", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default));
},
style: "btn",
visible: true,
_idProps: {
service: idService,
uuid: "43"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("sI1wwHo9JkiITUDrvQX0Yw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonItemOptionsRec();
rec.iconAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsIconRec();
rec.nameAttr = "pin_drop";
return rec;
}();
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "44",
alias: "13"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Find Customs",
_idProps: {
service: idService,
uuid: "45"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
})];
}, function () {
return [$if((model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.preCustomsInspectionRequired), false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-top-01 body-3 text-primary-35",
visible: true,
_idProps: {
service: idService,
uuid: "46"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "RefundSteps_Text_Pos1"
},
value: "Go to Customs to validate your unused goods.",
_idProps: {
service: idService,
uuid: "47"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("kkwgtu7VnkuIVvk_giTEVA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRec();
rec.testIdAttr = "RefundStepsCardButton";
rec.typeAttr = ShopperPortalEUModel.staticEntities.customButtonType.primary;
rec.isFullWidthAttr = true;
return rec;
}();
}),
ExtendedClass: "margin-top-02"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "48",
alias: "14"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
button: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: false,
onClick: function () {
OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "Locations", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default));
},
style: "btn",
visible: true,
_idProps: {
service: idService,
uuid: "49"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("8_I_mbNdEkGoJb9qB2TN4A.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonItemOptionsRec();
rec.iconAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsIconRec();
rec.nameAttr = "pin_drop";
return rec;
}();
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "50",
alias: "15"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Find Customs",
_idProps: {
service: idService,
uuid: "51"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
})];
}, function () {
return [$if((model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.preRefundClaimOngoing), false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-top-01 body-3 text-primary-35",
visible: true,
_idProps: {
service: idService,
uuid: "52"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "RefundSteps_Text_Pos1"
},
value: "Your refund claim is ongoing. We are currently checking and processing it.",
_idProps: {
service: idService,
uuid: "53"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
}, function () {
return [$if((model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.preUpdateRefundDetails), false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-top-01 body-3 text-primary-35",
visible: true,
_idProps: {
service: idService,
uuid: "54"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "RefundSteps_Text_Pos1"
},
value: "We were unable to process your refund due to incorrect card details provided. Please contact Customer Service to update the card details.",
_idProps: {
service: idService,
uuid: "55"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, {
inputs: {
ExtendedClass: "margin-top-02",
Options: model.getCachedValue(idService.getId("yzQ5AMT6rEqncvxK830vgA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRec();
rec.testIdAttr = "RefundStepsCardButton";
rec.typeAttr = ShopperPortalEUModel.staticEntities.customButtonType.primary;
rec.isFullWidthAttr = true;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "56",
alias: "16"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
button: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: false,
onClick: function () {
OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "Help", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default));
},
style: "btn",
visible: true,
_idProps: {
service: idService,
uuid: "57"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("L1q2126WLk2B+wG39tUIJA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonItemOptionsRec();
rec.iconAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsIconRec();
rec.nameAttr = "person";
return rec;
}();
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "58",
alias: "17"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Contact Customer Support",
_idProps: {
service: idService,
uuid: "59"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
})];
}, function () {
return [];
})];
})];
})];
})];
})];
})];
})];
})];
})];
})];
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.isToShowRefundBtnVar), asPrimitiveValue(model.variables.formStatusIdIn), asPrimitiveValue(model.variables._formStatusIdInDataFetchStatus), asPrimitiveValue(model.variables._formStatusLabelInDataFetchStatus), asPrimitiveValue(model.variables.formStatusLabelIn)]
}), $if(((((model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.postGetCustomsApproval) || (model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.postCustomsInspectionRequired)) || (model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.preGetCustomsApproval)) || (model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.preCustomsInspectionRequired)), false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomAlert_mvc_view, {
inputs: {
ExtendedClass: "margin-top-02",
Options: model.getCachedValue(idService.getId("8vSL+tRmKUiAD56BexRjag.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomAlertOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customAlertType.warning;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "60",
alias: "18"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
title: new PlaceholderContent(function () {
return [$if(((model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.postCustomsInspectionRequired) || (model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.preCustomsInspectionRequired)), false, this, function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "PostCustomsInspectionRequiredWarning_Title"
},
value: "Don’t forget to bring:",
_idProps: {
service: idService,
uuid: "61"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}, function () {
return [$if((model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.preGetCustomsApproval), false, this, function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "PreGetCustomsApprovalWarning_Title"
},
value: "Finish the Tax Free process within 21 days of receiving the refund",
_idProps: {
service: idService,
uuid: "62"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}, function () {
return [];
})];
})];
}),
content: new PlaceholderContent(function () {
return [$if((model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.postGetCustomsApproval), false, this, function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "PostGetCustomsApprovalWarning_Label"
},
value: "You must complete this step to receive your refund.",
_idProps: {
service: idService,
uuid: "63"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}, function () {
return [$if((model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.preGetCustomsApproval), false, this, function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "PreGetCustomsApprovalWarning_Label"
},
value: "If you don’t complete it, we’ll have to charge you the total VAT plus additional fees.",
_idProps: {
service: idService,
uuid: "64"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}, function () {
return [$if(((model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.postCustomsInspectionRequired) || (model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.preCustomsInspectionRequired)), false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_BulletsList_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "65",
alias: "19"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
list: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.AdvancedHtml, {
tag: "ul",
_idProps: {
service: idService,
uuid: "66"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_BulletsListItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "67",
alias: "20"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "PostCustomsInspectionRequiredWarning_TravelDocumentLabel"
},
value: "ID travel document",
_idProps: {
service: idService,
uuid: "68"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_BulletsListItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "69",
alias: "21"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "PostCustomsInspectionRequiredWarning_PlanetTaxFreeFormLabel"
},
value: "Planet Tax Free form",
_idProps: {
service: idService,
uuid: "70"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_BulletsListItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "71",
alias: "22"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "PostCustomsInspectionRequiredWarning_UnusedGoodsLabel"
},
value: "Unused goods",
_idProps: {
service: idService,
uuid: "72"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_BulletsListItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "73",
alias: "23"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "PostCustomsInspectionRequiredWarning_ReceiptsLabel"
},
value: "Receipts",
_idProps: {
service: idService,
uuid: "74"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
})];
}, function () {
return [];
})];
})];
})];
})
},
_dependencies: [asPrimitiveValue(model.variables._formStatusIdInDataFetchStatus), asPrimitiveValue(model.variables.formStatusIdIn)]
})];
}, function () {
return [];
}));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("ShopperPortalEU.InternalComponents.RefundSteps_WB.mvc$controller", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.languageResources", "ShopperPortalEU.clientVariables", "ShopperPortalEU.InternalComponents.RefundSteps_WB.mvc$debugger", "ShopperPortalEU_UI_Components.model$CustomCardOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconRec", "ShopperPortalEU_UI_Components.model$CustomAlertOptionsRec", "ShopperPortalEU_UI_Components.model$CustomAlertIconOptionsRec", "ShopperPortalEU.controller$ClarityEvent"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEULanguageResources, ShopperPortalEUClientVariables, ShopperPortalEU_InternalComponents_RefundSteps_WB_mvc_Debugger) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = true;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._requestRefund$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("RequestRefund");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:qEfFDQvAkUib_ok9G82ovw:/NRWebFlows.WLZg9jO0M0aiRlyqBkvkgg/NodesShownInESpaceTree.6xhUyqTPqEW5sKNr7qweaw/ClientActions.qEfFDQvAkUib_ok9G82ovw:bM1lr0wEtdMAMOYPGBAAgg", "ShopperPortalEU", "RequestRefund", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:hbFflm5KmUOZK5kQ9uXa0A", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ssC98sMAJ0uKPB0etojqTA", callContext.id);
// IsFromFormDetailsOrStepScreen = True
ShopperPortalEUClientVariables.setIsFromFormDetailsOrStepScreen(true);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:3vXIBm0RHUOV0vo6Qx6k8w", callContext.id);
// Execute Action: ClarityEvent
ShopperPortalEUController.default.clarityEvent$Action("ReqestRefundFromTFFdetail_btn", callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:aF5B8W20g0abBYOstT55zg", callContext.id);
// Destination: /ShopperPortalEU/RequestRefund
return OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "RequestRefund", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:qEfFDQvAkUib_ok9G82ovw", callContext.id);
}

};
Controller.prototype._onReady$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnReady");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:rlnqaFGVPUio6uidzn9Iaw:/NRWebFlows.WLZg9jO0M0aiRlyqBkvkgg/NodesShownInESpaceTree.6xhUyqTPqEW5sKNr7qweaw/ClientActions.rlnqaFGVPUio6uidzn9Iaw:d5NYYLt3pbrxZtVv5MQm+A", "ShopperPortalEU", "OnReady", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:_Jw6SSFWdUGCtOQQTEdbog", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:iOEcQ_lIqkud+e7dTlKKwQ", callContext.id);
// IsToShowRefundBtn = FormStatusId = PostRefundDetailsRequired and notIsFormRequestRefundTriggered
model.variables.isToShowRefundBtnVar = ((model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.postRefundDetailsRequired) && !(ShopperPortalEUClientVariables.getIsFormRequestRefundTriggered()));
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:k6o5cH_VP0Ogcx2iXZgI8w", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:rlnqaFGVPUio6uidzn9Iaw", callContext.id);
}

};

Controller.prototype.requestRefund$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._requestRefund$Action, callContext);

};
Controller.prototype.onReady$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onReady$Action, callContext);

};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:WLZg9jO0M0aiRlyqBkvkgg:/NRWebFlows.WLZg9jO0M0aiRlyqBkvkgg:eI2Gsuu43vLy9LWSnrwTXg", "ShopperPortalEU", "InternalComponents", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:6xhUyqTPqEW5sKNr7qweaw:/NRWebFlows.WLZg9jO0M0aiRlyqBkvkgg/NodesShownInESpaceTree.6xhUyqTPqEW5sKNr7qweaw:GG2pxbIAUeeKLvvMslMmdQ", "ShopperPortalEU", "RefundSteps_WB", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:6xhUyqTPqEW5sKNr7qweaw", callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:WLZg9jO0M0aiRlyqBkvkgg", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "InternalComponents/RefundSteps_WB On Ready");
return controller.onReady$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return ShopperPortalEUController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, ShopperPortalEULanguageResources);
});

define("ShopperPortalEU.InternalComponents.RefundSteps_WB.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"gnObv2QcSUG47DLK9nL7ww": {
getter: function (varBag, idService) {
return varBag.model.variables.isToShowRefundBtnVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"9yIdlZ21PUeU1EtIcf0UsA": {
getter: function (varBag, idService) {
return varBag.model.variables.formStatusLabelIn;
},
dataType: OS.DataTypes.DataTypes.Text
},
"GraVWbJxyE2ZRBG3A7l3mg": {
getter: function (varBag, idService) {
return varBag.model.variables.formStatusIdIn;
},
dataType: OS.DataTypes.DataTypes.Text
},
"ggRj2t7CHUKSU0N2rrsqdQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"IqhS+X0_iE+wQhh4fuelWA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("PostGetCustomsApproval2"));
})(varBag.model, idService);
}
},
"Dun5swK8REyAXetaBhP9Jw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Button"));
})(varBag.model, idService);
}
},
"8pR4BoHgSUey0OcNvQNBVQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"VWTY5ZVCX0CHL47pj7cJyw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("PostCustomsInspectionRequired2"));
})(varBag.model, idService);
}
},
"XIlAHbtbI0atokPBiOe8Lw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Button"));
})(varBag.model, idService);
}
},
"3WkU_VlapUKKCJBwylskoA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"KkLZRRzQYkKumb3eLJU61Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("PostRefundDetailsRequired"));
})(varBag.model, idService);
}
},
"G2wKyJAp206PBsSQmKb_aA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("IsToShowRefundBtn2"));
})(varBag.model, idService);
}
},
"_7zNrDUIrk+x9ljj7eri0g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Button"));
})(varBag.model, idService);
}
},
"8HjxbabGU0mPUB6cqsKTRA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"o0UmNsMRZUeijbpnSo2piw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("PostRefundInProgress"));
})(varBag.model, idService);
}
},
"zJwjR59Tuk+pLcFFY1HVRw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("PostRefundApproved"));
})(varBag.model, idService);
}
},
"VDA_qMPKtEKZ5ECIOqcnjw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("PostRefundOnHold"));
})(varBag.model, idService);
}
},
"xi9viegQYkyuUPUrez5vsg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Button"));
})(varBag.model, idService);
}
},
"c54WB7FBZU+0RyIA1Swqpg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"Jm+yqVSbMEy1E_+6GXqvlA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("PostUpdateRefundDetails"));
})(varBag.model, idService);
}
},
"pLu5yejlj0iKdr3aUFFCbQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Button"));
})(varBag.model, idService);
}
},
"j9JtsE+ToE+HLj+USshjLg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"+ZLrwFmZwEyXluMu00oVhA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("PreGetCustomsApproval3"));
})(varBag.model, idService);
}
},
"9KjvIzQmkkC8jXk2aVi2Yg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Button"));
})(varBag.model, idService);
}
},
"KXTd1+lIeU+Szo4lTeaueA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"NeS6t7Fr+Uu1WseJYl78bw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("PreCustomsInspectionRequired2"));
})(varBag.model, idService);
}
},
"ORoBZQARpECNvW2f8gOyqw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Button"));
})(varBag.model, idService);
}
},
"O2wXRKmm+kunSb2hEAfvxw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"dTjIEZT+9024ECswUizBOg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("PreRefundClaimOngoing"));
})(varBag.model, idService);
}
},
"ZaCse9OVIU2jRm8f8kGu2A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("PreUpdateRefundDetails"));
})(varBag.model, idService);
}
},
"Ldn90fbD70SbmvQ1gT9Ouw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Button"));
})(varBag.model, idService);
}
},
"VGtw9mUuG0e0th7V86gQ2w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"yYvxgahNvUe5KdyjFoWefg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("GetCustomsApproval_CustomsInspectionRequir"));
})(varBag.model, idService);
}
},
"lOxkm62YREGrvRGp_cVyew": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"aP14QulwnEaQx1gqtnnIMA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("PostCustomsInspectionRequired_Title"));
})(varBag.model, idService);
}
},
"xhY+Dkho20iKyo4tk3sFNQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("PreGetCustomsApproval_Title"));
})(varBag.model, idService);
}
},
"LOzbDWfvJEKuOJaB46y63g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"WSTzPdN0LEKNM_gUrSGTQg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("PostGetCustomsApproval"));
})(varBag.model, idService);
}
},
"JIfylakf502IeLPC0CuRJQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("PreGetCustomsApproval"));
})(varBag.model, idService);
}
},
"Yg0ebTQo4UyVu7bFZN30HA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("PostCustomsInspectionRequired"));
})(varBag.model, idService);
}
},
"XLu+D2AYwkqBr5ppB_YGBQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("List"));
})(varBag.model, idService);
}
},
"2nY7nuR88EmUqh+TZxr1jw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"F5cFnfSeRUSpq6IdoK5HaQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"S0fIErPFkEWaGjTfonb9+w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"gYXdxcmMUUm1sGHvz5AmMQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
