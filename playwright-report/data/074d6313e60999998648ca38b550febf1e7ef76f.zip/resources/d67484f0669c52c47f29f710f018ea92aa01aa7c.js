define("ShopperPortalEU.Refund.RefundSteps.mvc$model", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.Layouts.LayoutDetail.mvc$model", "ShopperPortalEU.LayoutsComponents.Back.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.FullHeightContent.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomTimeline.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomTimelineItem.mvc$model", "ShopperPortalEU.InternalComponents.RefundSteps_WB.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomPopup.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomPopupLayout.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.Flex.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomButton.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomButtonItem.mvc$model", "ShopperPortalEU_UI_Theme.model$LayoutDetailOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU_UI_Components.model$FullHeightContentOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$FullHeightContentTopOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentBottomOptionsRec", "ShopperPortalEU_UI_Components.model$CustomTimelineOptionsRec", "ShopperPortalEU_UI_Components.model$CustomPopupLayoutOptionsRec", "ShopperPortalEU_UI_Components.model$CustomPopupLayoutHeaderImageOptionsRec", "ShopperPortalEU_UI_Components.model$FlexOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconRec"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_Layouts_LayoutDetail_mvcModel, ShopperPortalEU_LayoutsComponents_Back_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomTimeline_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomTimelineItem_mvcModel, ShopperPortalEU_InternalComponents_RefundSteps_WB_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomPopup_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomPopupLayout_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvcModel) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("ShowPopupAlreadySend", "showPopupAlreadySendVar", "ShowPopupAlreadySend", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("FormStatusLabel", "formStatusLabelIn", "FormStatusLabel", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, false), 
this.attr("_formStatusLabelInDataFetchStatus", "_formStatusLabelInDataFetchStatus", "_formStatusLabelInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("FormStatusId", "formStatusIdIn", "FormStatusId", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, false), 
this.attr("_formStatusIdInDataFetchStatus", "_formStatusIdInDataFetchStatus", "_formStatusIdInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Model._hasValidationWidgetsValue = undefined;
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
if((Model._hasValidationWidgetsValue === undefined)) {
Model._hasValidationWidgetsValue = ((((((((((ShopperPortalEU_Layouts_LayoutDetail_mvcModel.hasValidationWidgets || ShopperPortalEU_LayoutsComponents_Back_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomTimeline_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomTimelineItem_mvcModel.hasValidationWidgets) || ShopperPortalEU_InternalComponents_RefundSteps_WB_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomPopup_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomPopupLayout_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvcModel.hasValidationWidgets);
}

return Model._hasValidationWidgetsValue;
}
});

Model.prototype.setInputs = function (inputs) {
if("FormStatusLabel" in inputs) {
this.variables.formStatusLabelIn = OS.DataConversion.ServerDataConverter.from(inputs.FormStatusLabel, OS.DataTypes.DataTypes.Text);
}

if("FormStatusId" in inputs) {
this.variables.formStatusIdIn = OS.DataConversion.ServerDataConverter.from(inputs.FormStatusId, OS.DataTypes.DataTypes.Text);
}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "Refund.RefundSteps");
});
define("ShopperPortalEU.Refund.RefundSteps.mvc$view", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.model", "react", "OutSystems/ReactView/Main", "ShopperPortalEU.Refund.RefundSteps.mvc$model", "ShopperPortalEU.Refund.RefundSteps.mvc$controller", "ShopperPortalEU.clientVariables", "ShopperPortalEU.Layouts.LayoutDetail.mvc$view", "OutSystems/ReactWidgets/Main", "ShopperPortalEU.LayoutsComponents.Back.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.FullHeightContent.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomTimeline.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomTimelineItem.mvc$view", "ShopperPortalEU.InternalComponents.RefundSteps_WB.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomPopup.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomPopupLayout.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.Flex.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomButton.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomButtonItem.mvc$view", "ShopperPortalEU_UI_Theme.model$LayoutDetailOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU_UI_Components.model$FullHeightContentOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$FullHeightContentTopOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentBottomOptionsRec", "ShopperPortalEU_UI_Components.model$CustomTimelineOptionsRec", "ShopperPortalEU_UI_Components.model$CustomPopupLayoutOptionsRec", "ShopperPortalEU_UI_Components.model$CustomPopupLayoutHeaderImageOptionsRec", "ShopperPortalEU_UI_Components.model$FlexOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconRec"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ComponentsModel, React, OSView, ShopperPortalEU_Refund_RefundSteps_mvc_model, ShopperPortalEU_Refund_RefundSteps_mvc_controller, ShopperPortalEUClientVariables, ShopperPortalEU_Layouts_LayoutDetail_mvc_view, OSWidgets, ShopperPortalEU_LayoutsComponents_Back_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomTimeline_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomTimelineItem_mvc_view, ShopperPortalEU_InternalComponents_RefundSteps_WB_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomPopup_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomPopupLayout_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            var thisIsInstanceOfSuper = this instanceof _super;
            if (thisIsInstanceOfSuper == false) {
                return;
            }

            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "Refund.RefundSteps";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css", "css/ShopperPortalEU_UI_Theme.ShopperPortalEUUITheme.css", "css/ShopperPortalEU.ShopperPortalEU.css", "css/ShopperPortalEU_UI_Theme.ShopperPortalEUUITheme.extra.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [ShopperPortalEU_Layouts_LayoutDetail_mvc_view, ShopperPortalEU_LayoutsComponents_Back_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomTimeline_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomTimelineItem_mvc_view, ShopperPortalEU_InternalComponents_RefundSteps_WB_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomPopup_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomPopupLayout_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return ShopperPortalEU_Refund_RefundSteps_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return ShopperPortalEU_Refund_RefundSteps_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "Shopper Portal EU - Refund steps";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(ShopperPortalEU_Layouts_LayoutDetail_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "0",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
headerLeft: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_LayoutsComponents_Back_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "1",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}),
headerCenter: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "RefundSteps"
},
value: "Refund steps",
_idProps: {
service: idService,
uuid: "2"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
headerRight: PlaceholderContent.Empty,
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "3",
alias: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
top: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomTimeline_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "4",
alias: "4"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
items: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomTimelineItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "5",
alias: "5"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
title: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "RefundSteps_PlanetTaxFreeForm"
},
value: "Planet Tax Free form",
_idProps: {
service: idService,
uuid: "6"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
content: PlaceholderContent.Empty
},
_dependencies: []
}), $if(((((model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.preGetCustomsApproval) || (model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.preCustomsInspectionRequired)) || (model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.preRefundClaimOngoing)) || (model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.preUpdateRefundDetails)), false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomTimelineItem_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("st7fpIaJ+kChJzzrr++UyA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomTimelineOptionsRec();
rec.stateAttr = (((model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.preRefundClaimOngoing)) ? (ShopperPortalEUModel.staticEntities.customTimelineType.redo) : (ShopperPortalEUModel.staticEntities.customTimelineType.past));
return rec;
}();
}, function () {
return model.variables.formStatusIdIn;
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "7",
alias: "6"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
title: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "RefundSteps_ProvideMissingInformation_Or_UpdateRefundDetails"
},
value: "Refund requested",
_idProps: {
service: idService,
uuid: "8"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
content: new PlaceholderContent(function () {
return [$if((model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.preRefundClaimOngoing), false, this, function () {
return [React.createElement(ShopperPortalEU_InternalComponents_RefundSteps_WB_mvc_view, {
inputs: {
FormStatusId: model.variables.formStatusIdIn,
FormStatusLabel: model.variables.formStatusLabelIn
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "9",
alias: "7"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}, function () {
return [];
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.formStatusLabelIn), asPrimitiveValue(model.variables.formStatusIdIn)]
})];
}, function () {
return [];
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomTimelineItem_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("qzqQ0_kMPkCw535tIUSAIw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomTimelineOptionsRec();
rec.stateAttr = ((((((model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.postGetCustomsApproval) || (model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.postCustomsInspectionRequired)) || (model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.preGetCustomsApproval)) || (model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.preCustomsInspectionRequired))) ? (ShopperPortalEUModel.staticEntities.customTimelineType.current) : (ShopperPortalEUModel.staticEntities.customTimelineType.past));
return rec;
}();
}, function () {
return model.variables.formStatusIdIn;
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "10",
alias: "8"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
title: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "RefundSteps_Validate_Or_Validated"
},
value: model.getCachedValue(idService.getId("g89sqPKCwU+MInt2akGDQg.Value"), function () {
return ((((((model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.postGetCustomsApproval) || (model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.postCustomsInspectionRequired)) || (model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.preGetCustomsApproval)) || (model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.preCustomsInspectionRequired))) ? ("Validate") : ("Validated"));
}, function () {
return model.variables.formStatusIdIn;
}),
_idProps: {
service: idService,
uuid: "11"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
content: new PlaceholderContent(function () {
return [$if(((((model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.postGetCustomsApproval) || (model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.postCustomsInspectionRequired)) || (model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.preGetCustomsApproval)) || (model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.preCustomsInspectionRequired)), false, this, function () {
return [React.createElement(ShopperPortalEU_InternalComponents_RefundSteps_WB_mvc_view, {
inputs: {
FormStatusId: model.variables.formStatusIdIn,
FormStatusLabel: model.variables.formStatusLabelIn
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "12",
alias: "9"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}, function () {
return [];
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomPopup_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "13",
alias: "10"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
popup: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Popup, {
showPopup: model.variables.showPopupAlreadySendVar,
style: "popup-dialog",
_idProps: {
service: idService,
uuid: "14"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomPopupLayout_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onOverlayClick$Action: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ShopperPortalEUUIComponents/CustomPopupLayout OnOverlayClick");
controller.toggleAlreadySend_Popup$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "15",
alias: "11"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
title: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Did you already send us the Planet Tax Free form?",
_idProps: {
service: idService,
uuid: "16"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
content: new PlaceholderContent(function () {
return ["Please allow some time for this information to be updated."];
}),
actions: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("aTiUdCi_uECbBQGVS6ocSw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.justifyAttr = ShopperPortalEUModel.staticEntities.flexJustify.center;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.none;
rec.wrapAttr = false;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "17",
alias: "12"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("jC3wVVfLl0m8XFW5YwPUIQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customButtonType.primary;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "18",
alias: "13"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
button: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: false,
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Refund/RefundSteps/Button OnClick");
controller.toggleAlreadySend_Popup$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn",
visible: true,
_idProps: {
service: idService,
uuid: "19"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "20",
alias: "14"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Close",
_idProps: {
service: idService,
uuid: "21"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
})];
})
},
_dependencies: []
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables.showPopupAlreadySendVar)]
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.showPopupAlreadySendVar), asPrimitiveValue(model.variables.formStatusLabelIn), asPrimitiveValue(model.variables.formStatusIdIn)]
}), $if((((model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.preGetCustomsApproval) || (model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.preCustomsInspectionRequired)) || (model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.preRefundClaimOngoing)), false, this, function () {
return [];
}, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomTimelineItem_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("GwfGJXaUuUiejCVWJWOw9w.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomTimelineOptionsRec();
rec.stateAttr = ((((model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.postGetCustomsApproval) || (model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.postCustomsInspectionRequired))) ? (ShopperPortalEUModel.staticEntities.customTimelineType.next) : (((((model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.postRefundDetailsRequired) || (model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.preUpdateRefundDetails))) ? (ShopperPortalEUModel.staticEntities.customTimelineType.current) : ((((((model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.postRefundApproved_RA3) || (model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.postRefundApproved_RA11)) || (model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.postRefundInProgress))) ? (ShopperPortalEUModel.staticEntities.customTimelineType.redo) : (ShopperPortalEUModel.staticEntities.customTimelineType.past))))));
return rec;
}();
}, function () {
return model.variables.formStatusIdIn;
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "22",
alias: "15"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
title: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "RefundSteps_UpdateRefundDetails_Or_RefundDetailsUpdated"
},
value: model.getCachedValue(idService.getId("4RyN68vcMkuTBkC+g4J4lQ.Value"), function () {
return ((((((model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.postGetCustomsApproval) || (model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.postCustomsInspectionRequired)) || (model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.postRefundDetailsRequired)) || (model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.preUpdateRefundDetails))) ? ("Update refund details") : ("Refund details updated"));
}, function () {
return model.variables.formStatusIdIn;
}),
_idProps: {
service: idService,
uuid: "23"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
content: new PlaceholderContent(function () {
return [$if((((((model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.postRefundDetailsRequired) || (model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.postRefundApproved_RA3)) || (model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.postRefundApproved_RA11)) || (model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.postRefundInProgress)) || (model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.preUpdateRefundDetails)), false, this, function () {
return [React.createElement(ShopperPortalEU_InternalComponents_RefundSteps_WB_mvc_view, {
inputs: {
FormStatusId: model.variables.formStatusIdIn,
FormStatusLabel: model.variables.formStatusLabelIn
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "24",
alias: "16"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}, function () {
return [];
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.formStatusLabelIn), asPrimitiveValue(model.variables.formStatusIdIn)]
})];
}), $if(((model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.postRefundOnHold) || (model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.postUpdateRefundDetails)), false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomTimelineItem_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("17FXtc5RG0S+KVwtLVBn0Q.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomTimelineOptionsRec();
rec.stateAttr = ShopperPortalEUModel.staticEntities.customTimelineType.current;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "25",
alias: "17"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
title: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "RefundSteps_ProvideMissingInformation_Or_UpdateRefundDetails"
},
value: model.getCachedValue(idService.getId("UfZArW5LaUmKdGQ5GZ1DqA.Value"), function () {
return (((model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.postRefundOnHold)) ? ("Provide missing information") : ("Update refund details"));
}, function () {
return model.variables.formStatusIdIn;
}),
_idProps: {
service: idService,
uuid: "26"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_InternalComponents_RefundSteps_WB_mvc_view, {
inputs: {
FormStatusId: model.variables.formStatusIdIn,
FormStatusLabel: model.variables.formStatusLabelIn
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "27",
alias: "18"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.formStatusLabelIn), asPrimitiveValue(model.variables.formStatusIdIn)]
})];
}, function () {
return [];
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.showPopupAlreadySendVar), asPrimitiveValue(model.variables.formStatusLabelIn), asPrimitiveValue(model.variables.formStatusIdIn)]
})];
}),
bottom: new PlaceholderContent(function () {
return [$if(((((model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.postGetCustomsApproval) || (model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.postCustomsInspectionRequired)) || (model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.preGetCustomsApproval)) || (model.variables.formStatusIdIn === ShopperPortalEUModel.staticEntities.sPFormStatus.preCustomsInspectionRequired)), false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("+1WJVMNQcEuwSg_qhVO7Eg.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customButtonType.linkPrimary;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "28",
alias: "19"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
button: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: false,
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Refund/RefundSteps/Button OnClick");
controller.toggleAlreadySend_Popup$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn",
visible: true,
_idProps: {
service: idService,
uuid: "29"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("pQohEdaaAESabfIG7gS87A.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonItemOptionsRec();
rec.iconAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsIconRec();
rec.nameAttr = "help";
return rec;
}();
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "30",
alias: "20"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Did you already send us the Planet Tax Free form?",
_idProps: {
service: idService,
uuid: "31"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
})];
}, function () {
return [];
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.showPopupAlreadySendVar), asPrimitiveValue(model.variables.formStatusLabelIn), asPrimitiveValue(model.variables.formStatusIdIn)]
})];
}),
bottom: PlaceholderContent.Empty
},
_dependencies: [asPrimitiveValue(model.variables.showPopupAlreadySendVar), asPrimitiveValue(model.variables.formStatusLabelIn), asPrimitiveValue(model.variables.formStatusIdIn)]
}));
        };
        return View;
    })(OSView.BaseView.BaseWebScreen);
	
    return View;
});
define("ShopperPortalEU.Refund.RefundSteps.mvc$controller", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU.languageResources", "ShopperPortalEU.clientVariables", "ShopperPortalEU.Refund.RefundSteps.mvc$debugger", "ShopperPortalEU.Refund.controller", "ShopperPortalEU_UI_Theme.model$LayoutDetailOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU_UI_Components.model$FullHeightContentOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$FullHeightContentTopOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentBottomOptionsRec", "ShopperPortalEU_UI_Components.model$CustomTimelineOptionsRec", "ShopperPortalEU_UI_Components.model$CustomPopupLayoutOptionsRec", "ShopperPortalEU_UI_Components.model$CustomPopupLayoutHeaderImageOptionsRec", "ShopperPortalEU_UI_Components.model$FlexOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconRec"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEULanguageResources, ShopperPortalEUClientVariables, ShopperPortalEU_Refund_RefundSteps_mvc_Debugger, ShopperPortalEU_RefundController) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = true;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._toggleAlreadySend_Popup$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("ToggleAlreadySend_Popup");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:GOrfCPmI3EacI302KI6Yaw:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.+d9aXkUFL0ynqHpbq8Blww/ClientActions.GOrfCPmI3EacI302KI6Yaw:ig1Qzjc0c1HIk3nwkFX6Gg", "ShopperPortalEU", "ToggleAlreadySend_Popup", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:bpwMKLPkQkK1tOrl91b38g", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:DvNrscUs+EOfVKdSsAqltg", callContext.id);
// ShowPopupAlreadySend = notShowPopupAlreadySend
model.variables.showPopupAlreadySendVar = !(model.variables.showPopupAlreadySendVar);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:I41yAaUB7k+TihARS6+yYw", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:GOrfCPmI3EacI302KI6Yaw", callContext.id);
}

};

Controller.prototype.toggleAlreadySend_Popup$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._toggleAlreadySend_Popup$Action, callContext);

};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:VcUw8y2coUi7OQ+l92mkmQ:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ:1Ox1BferNhnfzrugqQ41yg", "ShopperPortalEU", "Refund", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:+d9aXkUFL0ynqHpbq8Blww:/NRWebFlows.VcUw8y2coUi7OQ+l92mkmQ/NodesShownInESpaceTree.+d9aXkUFL0ynqHpbq8Blww:JG2nq7qkH7vVLmKE59lydQ", "ShopperPortalEU", "RefundSteps", "NRNodes.WebScreen", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:+d9aXkUFL0ynqHpbq8Blww", callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:VcUw8y2coUi7OQ+l92mkmQ", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return ShopperPortalEU_RefundController.default.handleError(ex, this.callContext());
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return ShopperPortalEUController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, ShopperPortalEULanguageResources);
});

define("ShopperPortalEU.Refund.RefundSteps.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"p75spdYL+UyfwlCx7Z7BOQ": {
getter: function (varBag, idService) {
return varBag.model.variables.showPopupAlreadySendVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"PcehCBSL_ky8uzPtYzA+_w": {
getter: function (varBag, idService) {
return varBag.model.variables.formStatusLabelIn;
},
dataType: OS.DataTypes.DataTypes.Text
},
"wgyKwySSp0KSovJHhsAGVA": {
getter: function (varBag, idService) {
return varBag.model.variables.formStatusIdIn;
},
dataType: OS.DataTypes.DataTypes.Text
},
"uNDpUGlArkWeenwo+p9uUw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderLeft"));
})(varBag.model, idService);
}
},
"dAHfCvQVWEK3mVXyd5AQbQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderCenter"));
})(varBag.model, idService);
}
},
"OcqKlvSv5k2XjFLAtuEyQw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderRight"));
})(varBag.model, idService);
}
},
"WEOKUwEdLkO4w4AERyZZYg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"LPd6whm5WkSjyP9hHX+rXQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Top"));
})(varBag.model, idService);
}
},
"UCLa5mxwDkqwe9D3zslyrg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Items"));
})(varBag.model, idService);
}
},
"qUW0sGL89ESQk0QNwBEQqA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"PK43vzGJUkGfe8mUwLEexw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"jua5n_YX0U2_WDSessXuAg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("ManyStatuses"));
})(varBag.model, idService);
}
},
"W_Q_+AD74UGChZEUANrF9g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"fxT86A2WFU+PpoCEyimgrw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"w+vuCMuxH0+mEZCXjMkc5A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("PreRefundClaimOngoing"));
})(varBag.model, idService);
}
},
"6_4TTu6JW0GOlhxAsETdsQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"Kho39uMXhUeC1+jsYiCoug": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"cTefAPZKWkuwaHLMBwwgJA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("GetCustomsApproval_CustomsInspectionRequired"));
})(varBag.model, idService);
}
},
"EZb8DNp4k0Wr0OlX6_yfSA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Popup"));
})(varBag.model, idService);
}
},
"B9nfI2Yy4UikTXJZLObC8g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"_DT+15j+EE+nuGcoeFkqiA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"mVwLZJkzaEiD1UGn5+kU8w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Actions"));
})(varBag.model, idService);
}
},
"ItyAPX8Keke7TiEIaXUAkA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"+ftkabcKN0Sh+zWw3WxAFw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Button"));
})(varBag.model, idService);
}
},
"lkQTbv+MvEe66mbNe_j1fQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"KVFclpPrLEOys8fdEnbAkw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("ManyStatuses2"));
})(varBag.model, idService);
}
},
"cHGrh9A5dUGACFqicDFdNg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"X1by798yokaqmYzbstoZAQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"+jUc6CVbn0+o_EmkWWHN+g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("PostRefundOnHold_PostUpdateRefundDetails"));
})(varBag.model, idService);
}
},
"i5h+gLKRVU+d+a4cbRcTFg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"frOd9dKoY0CU27wr1E4Xkw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"j8lD6Do6KkqwHMv2AiQ1bQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Bottom"));
})(varBag.model, idService);
}
},
"pMcAAufSDkWEwop336Vn2w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("GetCustomsApproval_CustomsInspectionRequired2"));
})(varBag.model, idService);
}
},
"u_5JhC+fFUSuZhjHcbLE9g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Button"));
})(varBag.model, idService);
}
},
"fkO_p0eaB0iqoQo1hid4rA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"L7MtLcR_DECjVxF1Ng25Uw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Bottom"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
