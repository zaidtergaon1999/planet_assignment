define("Users.referencesHealth$AsynchronousLogging", [], function () {
// Reference to producer 'AsynchronousLogging' is OK.
});
define("Users.referencesHealth$Authentication", [], function () {
// Reference to producer 'Authentication' is OK.
});
define("Users.referencesHealth$BinaryData", [], function () {
// Reference to producer 'BinaryData' is OK.
});
define("Users.referencesHealth$HTTPRequestHandler", [], function () {
// Reference to producer 'HTTPRequestHandler' is OK.
});
define("Users.referencesHealth$PlatformPasswordUtils", [], function () {
// Reference to producer 'PlatformPasswordUtils' is OK.
});
define("Users.referencesHealth$PlatformRuntime_API", [], function () {
// Reference to producer 'PlatformRuntime_API' is OK.
});
define("Users.referencesHealth$RichWidgets", [], function () {
// Reference to producer 'RichWidgets' is OK.
});
define("Users.referencesHealth$SAMLAuthentication", [], function () {
// Reference to producer 'SAMLAuthentication' is OK.
});
define("Users.referencesHealth$Sanitization", [], function () {
// Reference to producer 'Sanitization' is OK.
});
define("Users.referencesHealth$ServiceCenter", [], function () {
// Reference to producer 'ServiceCenter' is OK.
});
define("Users.referencesHealth$Text", [], function () {
// Reference to producer 'Text' is OK.
});
define("Users.referencesHealth$UsersSecurity", [], function () {
// Reference to producer 'UsersSecurity' is OK.
});
define("Users.referencesHealth$Xml", [], function () {
// Reference to producer 'Xml' is OK.
});
define("Users.referencesHealth$Zip", [], function () {
// Reference to producer 'Zip' is OK.
});
define("Users.referencesHealth", [], function () {
});
