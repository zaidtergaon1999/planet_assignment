define("Custom404Plugin.model", ["exports", "OutSystems/ClientRuntime/Main"], function (exports, OutSystems) {
var OS = OutSystems.Internal;
var Custom404PluginModel = exports;
Object.defineProperty(Custom404PluginModel, "module", {
get: function () {
return OS.ApplicationInfo.getModules()["ef4d00ca-5aae-4ef2-8f33-5ec87f56d789"];
}
});

Custom404PluginModel.staticEntities = {};
});
