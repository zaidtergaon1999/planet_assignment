define("ShopperPortalEU.CreditCard.AddCard.mvc$model", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Theme.controller", "ShopperPortalEU_UI_Components.model$DatatransCardChangeOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Theme.model$LayoutDetailOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU_UI_Components.model$FullHeightContentOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentTopOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentBottomOptionsRec", "ShopperPortalEU_Forms_IS.model$FormInfo_WrapperRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Forms_IS", "ShopperPortalEU.model$FormInfo_WrapperList", "ShopperPortalEU_Forms_IS.model$RefundDetails_WrapperRec", "ShopperPortalEU_Forms_IS.model$FormDetails_WrapperRec", "ShopperPortalEU_Forms_IS.model$UIConfigurationRec", "ShopperPortalEU_Forms_IS.model$RefundDetailsPaymentDetails_UIRec", "ShopperPortalEU_Shopper_IS.model$DatatransTokenFallbackRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS", "ShopperPortalEU_UI_Components.model$CustomCheckboxOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconRec", "ShopperPortalEU.controller$CheckValidCard", "ShopperPortalEU.controller$ClarityEvent", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", "ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger", "ShopperPortalEU.controller$DefaultErrorMessage"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_Forms_ISModel, ShopperPortalEU_Shopper_ISModel, ShopperPortalEUController, ShopperPortalEU_UI_ThemeController) {
var OS = OutSystems.Internal;

var GetDataDataActRec = (function (_super) {
__extends(GetDataDataActRec, _super);
function GetDataDataActRec(defaults) {
_super.apply(this, arguments);
}
GetDataDataActRec.attributesToDeclare = function () {
return [
this.attr("MerchantId", "merchantIdOut", "MerchantId", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
GetDataDataActRec.fromStructure = function (str) {
return new GetDataDataActRec(new GetDataDataActRec.RecordClass({
merchantIdOut: OS.DataTypes.ImmutableBase.getData(str)
}));
};
GetDataDataActRec.init();
return GetDataDataActRec;
})(OS.Model.DataSourceRecord);

var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("IsDefaultCard", "isDefaultCardVar", "IsDefaultCard", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("IsCardSubmitting", "isCardSubmittingVar", "IsCardSubmitting", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("IsToSubmitCard", "isToSubmitCardVar", "IsToSubmitCard", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("CardDetailsData", "cardDetailsDataVar", "CardDetailsData", true, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.DatatransCardChangeOptionsRec());
}, false, ShopperPortalEU_UI_ComponentsModel.DatatransCardChangeOptionsRec), 
this.attr("CardErrorMessage", "cardErrorMessageVar", "CardErrorMessage", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, false), 
this.attr("IsExpiryDateError", "isExpiryDateErrorVar", "IsExpiryDateError", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("GetData", "getDataDataAct", "getDataDataAct", true, true, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new GetDataDataActRec());
}, true, GetDataDataActRec)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {
Checkbox_IsDefaulCard: OS.Model.ValidationWidgetRecord
};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return true;
}
});

Model.prototype.setInputs = function (inputs) {
};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "CreditCard.AddCard");
});
define("ShopperPortalEU.CreditCard.AddCard.mvc$view", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_UI_Theme.controller", "react", "OutSystems/ReactView/Main", "ShopperPortalEU.CreditCard.AddCard.mvc$model", "ShopperPortalEU.CreditCard.AddCard.mvc$controller", "ShopperPortalEU.clientVariables", "ShopperPortalEU.Layouts.LayoutDetail.mvc$view", "OutSystems/ReactWidgets/Main", "ShopperPortalEU.LayoutsComponents.Back.mvc$view", "ShopperPortalEU.Common.Secure.mvc$view", "ShopperPortalEU.Common.DataLoading.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.FullHeightContent.mvc$view", "ShopperPortalEU.InternalComponents.DatatransTokenization_WB.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCheckbox.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomButton.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomButtonItem.mvc$view", "ShopperPortalEU_UI_Components.model$DatatransCardChangeOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Theme.model$LayoutDetailOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU_UI_Components.model$FullHeightContentOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentTopOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentBottomOptionsRec", "ShopperPortalEU_Forms_IS.model$FormInfo_WrapperRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Forms_IS", "ShopperPortalEU.model$FormInfo_WrapperList", "ShopperPortalEU_Forms_IS.model$RefundDetails_WrapperRec", "ShopperPortalEU_Forms_IS.model$FormDetails_WrapperRec", "ShopperPortalEU_Forms_IS.model$UIConfigurationRec", "ShopperPortalEU_Forms_IS.model$RefundDetailsPaymentDetails_UIRec", "ShopperPortalEU_Shopper_IS.model$DatatransTokenFallbackRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS", "ShopperPortalEU_UI_Components.model$CustomCheckboxOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconRec", "ShopperPortalEU.controller$CheckValidCard", "ShopperPortalEU.controller$ClarityEvent", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", "ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger", "ShopperPortalEU.controller$DefaultErrorMessage"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_Forms_ISModel, ShopperPortalEU_Shopper_ISModel, ShopperPortalEU_UI_ThemeController, React, OSView, ShopperPortalEU_CreditCard_AddCard_mvc_model, ShopperPortalEU_CreditCard_AddCard_mvc_controller, ShopperPortalEUClientVariables, ShopperPortalEU_Layouts_LayoutDetail_mvc_view, OSWidgets, ShopperPortalEU_LayoutsComponents_Back_mvc_view, ShopperPortalEU_Common_Secure_mvc_view, ShopperPortalEU_Common_DataLoading_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvc_view, ShopperPortalEU_InternalComponents_DatatransTokenization_WB_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCheckbox_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            var thisIsInstanceOfSuper = this instanceof _super;
            if (thisIsInstanceOfSuper == false) {
                return;
            }

            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "CreditCard.AddCard";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css", "css/ShopperPortalEU_UI_Theme.ShopperPortalEUUITheme.css", "css/ShopperPortalEU.ShopperPortalEU.css", "css/ShopperPortalEU_UI_Theme.ShopperPortalEUUITheme.extra.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [ShopperPortalEU_Layouts_LayoutDetail_mvc_view, ShopperPortalEU_LayoutsComponents_Back_mvc_view, ShopperPortalEU_Common_Secure_mvc_view, ShopperPortalEU_Common_DataLoading_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvc_view, ShopperPortalEU_InternalComponents_DatatransTokenization_WB_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCheckbox_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return ShopperPortalEU_CreditCard_AddCard_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return ShopperPortalEU_CreditCard_AddCard_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "Shopper Portal EU - Add card";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(ShopperPortalEU_Layouts_LayoutDetail_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "0",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
headerLeft: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_LayoutsComponents_Back_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "1",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}),
headerCenter: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "AddCard"
},
value: "Add card",
_idProps: {
service: idService,
uuid: "2"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
headerRight: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_Common_Secure_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "3",
alias: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}),
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_Common_DataLoading_mvc_view, {
inputs: {
IsDataFetched: model.variables.getDataDataAct.isDataFetchedAttr
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "4",
alias: "4"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "5",
alias: "5"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
top: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_InternalComponents_DatatransTokenization_WB_mvc_view, {
inputs: {
IsToSaveNewCard: true,
MerchantId: model.variables.getDataDataAct.merchantIdOut,
_merchantIdInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getDataDataAct.dataFetchStatusAttr),
IsFromAddCardScreen: true,
CardDetailsData: model.variables.cardDetailsDataVar,
IsExpiryDateError: model.variables.isExpiryDateErrorVar,
IsDefaultCard: model.variables.isDefaultCardVar,
IsToSubmitCard: model.variables.isToSubmitCardVar,
CardErrorMessage: model.variables.cardErrorMessageVar
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
cardSubmitted$Action: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "InternalComponents/DatatransTokenization_WB CardSubmitted");
controller.onCardSubmitted$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
updateParameters$Action: function (cardDetailsDataIn, cardErrorMessageIn, isExpiryDateErrorIn) {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "InternalComponents/DatatransTokenization_WB UpdateParameters");
controller.onParametersChanged$Action(cardDetailsDataIn, cardErrorMessageIn, isExpiryDateErrorIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
errorSavingCard$Action: function (errorMessageIn, isCreateCardGenericErrorIn) {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "InternalComponents/DatatransTokenization_WB ErrorSavingCard");
controller.onErrorSavingCard$Action(errorMessageIn, isCreateCardGenericErrorIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "6",
alias: "6"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-top-04",
visible: true,
_idProps: {
service: idService,
uuid: "7"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCheckbox_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("AEqnDJxBlUGMJC5ad6j6SQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomCheckboxOptionsRec();
rec.testIdAttr = "SaveAsDefault";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "8",
alias: "7"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
checkbox: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Checkbox, {
_validationProps: {
validationService: validationService
},
enabled: true,
onChange: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "CreditCard/AddCard/Checkbox_IsDefaulCard OnChange");
controller.checkbox_IsDefaulCardOnChange$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "checkbox",
variable: model.createVariable(OS.DataTypes.DataTypes.Boolean, model.variables.isDefaultCardVar, function (value) {
model.variables.isDefaultCardVar = value;
}),
_idProps: {
service: idService,
name: "Checkbox_IsDefaulCard"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
label: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Label, {
extendedProperties: {
"data-testid": "CheckboxDefault_Label"
},
gridProperties: {
classes: "OSFillParent"
},
targetWidget: "Checkbox_IsDefaulCard",
_idProps: {
service: idService,
uuid: "10"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
value: "Save as default",
_idProps: {
service: idService,
uuid: "11"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables.isDefaultCardVar)]
}))];
}),
bottom: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("pzyYNKn4GU+gXlmxIL7l0Q.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRec();
rec.testIdAttr = "SaveCardButton";
rec.typeAttr = ShopperPortalEUModel.staticEntities.customButtonType.primary;
rec.isLoadingAttr = model.variables.isCardSubmittingVar;
rec.isFullWidthAttr = true;
return rec;
}();
}, function () {
return model.variables.isCardSubmittingVar;
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "12",
alias: "8"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
button: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: model.getCachedValue(idService.getId("LabJu3YVIEGyRStdn6jp4Q.Enabled"), function () {
return (((model.variables.cardDetailsDataVar.lengthAttr > 0) && !(model.variables.cardDetailsDataVar.expiryDateAttr.equals(OS.BuiltinFunctions.nullDate()))) && ((model.variables.cardDetailsDataVar.cardHolderNameAttr) !== ("")));
}, function () {
return model.variables.cardDetailsDataVar.lengthAttr;
}, function () {
return model.variables.cardDetailsDataVar.expiryDateAttr;
}, function () {
return model.variables.cardDetailsDataVar.cardHolderNameAttr;
}),
isDefault: false,
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "CreditCard/AddCard/Button OnClick");
controller.save$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn",
visible: true,
_idProps: {
service: idService,
uuid: "13"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "14",
alias: "9"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Save",
_idProps: {
service: idService,
uuid: "15"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables.cardDetailsDataVar.cardHolderNameAttr), asPrimitiveValue(model.variables.cardDetailsDataVar.expiryDateAttr), asPrimitiveValue(model.variables.cardDetailsDataVar.lengthAttr)]
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.isCardSubmittingVar), asPrimitiveValue(model.variables.cardErrorMessageVar), asPrimitiveValue(model.variables.isToSubmitCardVar), asPrimitiveValue(model.variables.isDefaultCardVar), asPrimitiveValue(model.variables.isExpiryDateErrorVar), asPrimitiveValue(model.variables.cardDetailsDataVar), asPrimitiveValue(model.variables.getDataDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.getDataDataAct.merchantIdOut)]
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.isCardSubmittingVar), asPrimitiveValue(model.variables.cardErrorMessageVar), asPrimitiveValue(model.variables.isToSubmitCardVar), asPrimitiveValue(model.variables.isDefaultCardVar), asPrimitiveValue(model.variables.isExpiryDateErrorVar), asPrimitiveValue(model.variables.cardDetailsDataVar), asPrimitiveValue(model.variables.getDataDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.getDataDataAct.merchantIdOut)]
})];
}),
bottom: PlaceholderContent.Empty
},
_dependencies: [asPrimitiveValue(model.variables.isCardSubmittingVar), asPrimitiveValue(model.variables.cardErrorMessageVar), asPrimitiveValue(model.variables.isToSubmitCardVar), asPrimitiveValue(model.variables.isDefaultCardVar), asPrimitiveValue(model.variables.isExpiryDateErrorVar), asPrimitiveValue(model.variables.cardDetailsDataVar), asPrimitiveValue(model.variables.getDataDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.getDataDataAct.merchantIdOut), asPrimitiveValue(model.variables.getDataDataAct.isDataFetchedAttr)]
}));
        };
        return View;
    })(OSView.BaseView.BaseWebScreen);
	
    return View;
});
define("ShopperPortalEU.CreditCard.AddCard.mvc$controller", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_Forms_IS.model", "ShopperPortalEU_Shopper_IS.model", "ShopperPortalEU_UI_Theme.controller", "ShopperPortalEU.languageResources", "ShopperPortalEU.clientVariables", "ShopperPortalEU.CreditCard.AddCard.mvc$debugger", "ShopperPortalEU.CreditCard.controller", "ShopperPortalEU_UI_Components.model$DatatransCardChangeOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Theme.model$LayoutDetailOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU_UI_Components.model$FullHeightContentOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentTopOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentBottomOptionsRec", "ShopperPortalEU_Forms_IS.model$FormInfo_WrapperRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Forms_IS", "ShopperPortalEU.model$FormInfo_WrapperList", "ShopperPortalEU_Forms_IS.model$RefundDetails_WrapperRec", "ShopperPortalEU_Forms_IS.model$FormDetails_WrapperRec", "ShopperPortalEU_Forms_IS.model$UIConfigurationRec", "ShopperPortalEU_Forms_IS.model$RefundDetailsPaymentDetails_UIRec", "ShopperPortalEU_Shopper_IS.model$DatatransTokenFallbackRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_Shopper_IS", "ShopperPortalEU_UI_Components.model$CustomCheckboxOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconRec", "ShopperPortalEU.controller$CheckValidCard", "ShopperPortalEU.controller$ClarityEvent", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", "ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger", "ShopperPortalEU.controller$DefaultErrorMessage"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_Forms_ISModel, ShopperPortalEU_Shopper_ISModel, ShopperPortalEU_UI_ThemeController, ShopperPortalEULanguageResources, ShopperPortalEUClientVariables, ShopperPortalEU_CreditCard_AddCard_mvc_Debugger, ShopperPortalEU_CreditCardController) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {
getData$DataActRefresh: 0
};
this.dataFetchDependentsGraph = {
getData$DataActRefresh: []
};
this.shouldSendClientVarsToDataSources = true;
}
// Server Actions

// Aggregates and Data Actions
Controller.prototype.getData$DataActRefresh = function (callContext) {
var model = this.model;
var controller = this.controller;
var callContext = controller.callContext(callContext);
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:pcS21yiulUeJzM8PGQhh_A:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.iCqHOxjxjUudbgh3BjFFEw/DataActions.pcS21yiulUeJzM8PGQhh_A:Q81nOvW_IdzMH_SQBvZwDQ", "ShopperPortalEU", "GetData", "NRFlows.DataScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.setThreadStartName(callContext.id, "CreditCard/AddCard/GetData");
return controller.callDataAction("DataActionGetData", "screenservices/ShopperPortalEU/CreditCard/AddCard/DataActionGetData", "96m8LQru1kBuWxYbUAWixA", function (b) {
model.variables.getDataDataAct.dataFetchStatusAttr = b;
}, function (json) {
model.variables.getDataDataAct.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getDataDataAct.constructor));
}, undefined, OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, callContext, ShopperPortalEUClientVariables, false);

}, function () {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:pcS21yiulUeJzM8PGQhh_A", callContext.id);
controller.popDebuggerContext(callContext);

});
};

Controller.prototype.dataFetchActionNames = ["getData$DataActRefresh"];
// Client Actions
Controller.prototype._save$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Save");
callContext = controller.callContext(callContext);
var checkValidCardVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.checkValidCardVar = checkValidCardVar;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:EhzxA2+wKk+2S3Nokl5YKA:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.iCqHOxjxjUudbgh3BjFFEw/ClientActions.EhzxA2+wKk+2S3Nokl5YKA:qtAvesv4KPR2YYDbzWR91w", "ShopperPortalEU", "Save", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:U9Ss1etShk+SiX84apC3xw", callContext.id);
// ResetCardErrorMessage
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:prRzrrP9Xkq_kc6NFsabsw", callContext.id);
// CardErrorMessage = ""
model.variables.cardErrorMessageVar = "";
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:prRzrrP9Xkq_kc6NFsabsw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// IsExpiryDateError = False
model.variables.isExpiryDateErrorVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:prRzrrP9Xkq_kc6NFsabsw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// IsCardSubmitting = True
model.variables.isCardSubmittingVar = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:jmHUrZCM8ECs9LisspvdjQ", callContext.id);
// Execute Action: CheckValidCard
checkValidCardVar.value = ShopperPortalEUController.default.checkValidCard$Action(model.variables.cardDetailsDataVar.expiryDateAttr, model.variables.cardDetailsDataVar, callContext);

// Valid Card ?
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Vd4K16OjG0264dpXNRuEqg", callContext.id) && checkValidCardVar.value.isValidOut)) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:2dv_cQu5ckWlilA1dcdwpQ", callContext.id);
// IsToSubmitCard = True
model.variables.isToSubmitCardVar = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:TU7V4ZdEqki3mab1O21tsw", callContext.id);
} else {
// ErrorMessage
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:R1k35qgEUkeCcpq7s0s3Ow", callContext.id);
// CardErrorMessage = CheckValidCard.ErrorMessage
model.variables.cardErrorMessageVar = checkValidCardVar.value.errorMessageOut;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:R1k35qgEUkeCcpq7s0s3Ow", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// IsCardSubmitting = False
model.variables.isCardSubmittingVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:R1k35qgEUkeCcpq7s0s3Ow", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// IsExpiryDateError = CheckValidCard.IsExpiryDateError
model.variables.isExpiryDateErrorVar = checkValidCardVar.value.isExpiryDateErrorOut;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:uFNSLJX3DEy3F2rRqpUIyw", callContext.id);
}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:EhzxA2+wKk+2S3Nokl5YKA", callContext.id);
}

};
Controller.prototype._onParametersChanged$Action = function (event_CardDetailsDataIn, event_CardErrorMessageIn, event_IsExpiryDateErrorIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnParametersChanged");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.CreditCard.AddCard.OnParametersChanged$vars"))());
vars.value.event_CardDetailsDataInLocal = event_CardDetailsDataIn.clone();
vars.value.event_CardErrorMessageInLocal = event_CardErrorMessageIn;
vars.value.event_IsExpiryDateErrorInLocal = event_IsExpiryDateErrorIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:jxQKIVIB8USiKliG8RHMWw:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.iCqHOxjxjUudbgh3BjFFEw/ClientActions.jxQKIVIB8USiKliG8RHMWw:trdESVjG9b5Gapt1v5qZ3Q", "ShopperPortalEU", "OnParametersChanged", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:26b_FKoIekin+X6m4n0TPQ", callContext.id);
// Update vars
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:_GAQJFMx6UykSjcQcsHIQw", callContext.id);
// CardDetailsData = Event_CardDetailsData
model.variables.cardDetailsDataVar = vars.value.event_CardDetailsDataInLocal;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:_GAQJFMx6UykSjcQcsHIQw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// CardErrorMessage = Event_CardErrorMessage
model.variables.cardErrorMessageVar = vars.value.event_CardErrorMessageInLocal;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:_GAQJFMx6UykSjcQcsHIQw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// IsExpiryDateError = Event_IsExpiryDateError
model.variables.isExpiryDateErrorVar = vars.value.event_IsExpiryDateErrorInLocal;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:MQFN4Tb0_0OzHqh_fq5KJw", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:jxQKIVIB8USiKliG8RHMWw", callContext.id);
}

};
Controller.registerVariableGroupType("ShopperPortalEU.CreditCard.AddCard.OnParametersChanged$vars", [{
name: "Event_CardDetailsData",
attrName: "event_CardDetailsDataInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Record,
defaultValue: function () {
return new ShopperPortalEU_UI_ComponentsModel.DatatransCardChangeOptionsRec();
},
complexType: ShopperPortalEU_UI_ComponentsModel.DatatransCardChangeOptionsRec
}, {
name: "Event_CardErrorMessage",
attrName: "event_CardErrorMessageInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}, {
name: "Event_IsExpiryDateError",
attrName: "event_IsExpiryDateErrorInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Boolean,
defaultValue: function () {
return false;
}
}]);
Controller.prototype._onCardSubmitted$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnCardSubmitted");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:KlbQXQzpC0is3W8QOEzfpw:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.iCqHOxjxjUudbgh3BjFFEw/ClientActions.KlbQXQzpC0is3W8QOEzfpw:SIvlYQX_jMZf_Py4lRocOg", "ShopperPortalEU", "OnCardSubmitted", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:NLzfdgUJAkW0y874KF8D1Q", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:_ETDWZDOikqtKTmb91lwBA", callContext.id);
// IsToSubmitCard = False
model.variables.isToSubmitCardVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:DvZRvqEYLEaOUoSvzoyS7w", callContext.id);
// Execute Action: ClarityEvent
ShopperPortalEUController.default.clarityEvent$Action("SaveCardWallet_btn", callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:m0EzHsBOeEOPdVvowYuSDA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:KlbQXQzpC0is3W8QOEzfpw", callContext.id);
}

};
Controller.prototype._checkbox_IsDefaulCardOnChange$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Checkbox_IsDefaulCardOnChange");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:l9TZndSAAkeRaAMRzefJfg:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.iCqHOxjxjUudbgh3BjFFEw/ClientActions.l9TZndSAAkeRaAMRzefJfg:AxBUJi90ZuB_prbyiCno7w", "ShopperPortalEU", "Checkbox_IsDefaulCardOnChange", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:uoTDG2+Qk0+2dWE23p3Hcg", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:GbN9UzCbh06LpaaE2XIVaQ", callContext.id) && model.variables.isDefaultCardVar)) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:NHfGPwDNOUuR+OvH3Z4Zcg", callContext.id);
// Execute Action: ClarityEvent
ShopperPortalEUController.default.clarityEvent$Action("SetAsDefaultWallet_check", callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Hvj5q3W_SEKLLyE40NJDSg", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Hvj5q3W_SEKLLyE40NJDSg", callContext.id);
}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:l9TZndSAAkeRaAMRzefJfg", callContext.id);
}

};
Controller.prototype._onErrorSavingCard$Action = function (errorMessageIn, isCreateCardGenericErrorIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnErrorSavingCard");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.CreditCard.AddCard.OnErrorSavingCard$vars"))());
vars.value.errorMessageInLocal = errorMessageIn;
vars.value.isCreateCardGenericErrorInLocal = isCreateCardGenericErrorIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:LOi0_ufFe0yySlOvDWXCYw:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.iCqHOxjxjUudbgh3BjFFEw/ClientActions.LOi0_ufFe0yySlOvDWXCYw:W4G21CAS9ptKgQ4p01nmYg", "ShopperPortalEU", "OnErrorSavingCard", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:8kmh6kSEskGD1LM0YvGe6A", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:WId9ZyfWY02luYOs4TyNWQ", callContext.id);
// IsCardSubmitting = False
model.variables.isCardSubmittingVar = false;
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:8FH_2GdUBUWHmcCLrYMr4g", callContext.id) && vars.value.isCreateCardGenericErrorInLocal)) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:4IPN_+dFLEKQf1CpDQ9qgQ", callContext.id);
// Execute Action: ErrorMessage2
ShopperPortalEU_UI_ThemeController.default.customMessageTrigger$Action(function () {
var rec = new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customMessageType.error;
rec.titleAttr = vars.value.errorMessageInLocal;
rec.contentAttr = OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.defaultErrorMessage$Action(callContext).errorMessageOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
rec.testIdAttr = "Error";
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:PgqHoXMt+Eqa9mcKTR_T_A", callContext.id);
} else {
// ErrorMessage
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:I+Ss95TpXUm5awZXH0ya7g", callContext.id);
// CardErrorMessage = ErrorMessage
model.variables.cardErrorMessageVar = vars.value.errorMessageInLocal;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:sloL_uzyxUOUe0GehUbjNg", callContext.id);
}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:LOi0_ufFe0yySlOvDWXCYw", callContext.id);
}

};
Controller.registerVariableGroupType("ShopperPortalEU.CreditCard.AddCard.OnErrorSavingCard$vars", [{
name: "ErrorMessage",
attrName: "errorMessageInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}, {
name: "IsCreateCardGenericError",
attrName: "isCreateCardGenericErrorInLocal",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Boolean,
defaultValue: function () {
return false;
}
}]);

Controller.prototype.save$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._save$Action, callContext);

};
Controller.prototype.onParametersChanged$Action = function (event_CardDetailsDataIn, event_CardErrorMessageIn, event_IsExpiryDateErrorIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onParametersChanged$Action, callContext, event_CardDetailsDataIn, event_CardErrorMessageIn, event_IsExpiryDateErrorIn);

};
Controller.prototype.onCardSubmitted$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onCardSubmitted$Action, callContext);

};
Controller.prototype.checkbox_IsDefaulCardOnChange$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._checkbox_IsDefaulCardOnChange$Action, callContext);

};
Controller.prototype.onErrorSavingCard$Action = function (errorMessageIn, isCreateCardGenericErrorIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onErrorSavingCard$Action, callContext, errorMessageIn, isCreateCardGenericErrorIn);

};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:fWtJs57lI0qCTlwkcDoxDA:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA:ONNPtNNl6kvn+nbnL5quzA", "ShopperPortalEU", "CreditCard", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:iCqHOxjxjUudbgh3BjFFEw:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.iCqHOxjxjUudbgh3BjFFEw:LVyQBGTgjlS10zX3l6j19Q", "ShopperPortalEU", "AddCard", "NRNodes.WebScreen", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:iCqHOxjxjUudbgh3BjFFEw", callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:fWtJs57lI0qCTlwkcDoxDA", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return ShopperPortalEU_CreditCardController.default.handleError(ex, this.callContext());
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return ShopperPortalEUController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, ShopperPortalEULanguageResources);
});

define("ShopperPortalEU.CreditCard.AddCard.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"jmHUrZCM8ECs9LisspvdjQ": {
getter: function (varBag, idService) {
return varBag.checkValidCardVar.value;
}
},
"3Wo_YrW5ik6BmQeUEd+Dng": {
getter: function (varBag, idService) {
return varBag.vars.value.event_CardDetailsDataInLocal;
}
},
"2t_Rls+sMkO7COiodhABYg": {
getter: function (varBag, idService) {
return varBag.vars.value.event_CardErrorMessageInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"gcbpwVASeUS_0XQqa9BAVw": {
getter: function (varBag, idService) {
return varBag.vars.value.event_IsExpiryDateErrorInLocal;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"e6awWHxTdkatcn0tNPn+gw": {
getter: function (varBag, idService) {
return varBag.vars.value.errorMessageInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"kktvHcm_uEOMEpURkZOvSw": {
getter: function (varBag, idService) {
return varBag.vars.value.isCreateCardGenericErrorInLocal;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"oBw5tbpCqUGID_qv2CHtlQ": {
getter: function (varBag, idService) {
return varBag.model.variables.isDefaultCardVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"EkG0_uB3FUGIMvBwVwRAzQ": {
getter: function (varBag, idService) {
return varBag.model.variables.isCardSubmittingVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"Bwzd6AnxcEyfF4YelxVuyg": {
getter: function (varBag, idService) {
return varBag.model.variables.isToSubmitCardVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"DSZfVH+blkSDP8C0eSY2fg": {
getter: function (varBag, idService) {
return varBag.model.variables.cardDetailsDataVar;
}
},
"QVh84MMlbkin0xLJUFsmVg": {
getter: function (varBag, idService) {
return varBag.model.variables.cardErrorMessageVar;
},
dataType: OS.DataTypes.DataTypes.Text
},
"jD8jXNQg8Euw9PCquUXJkw": {
getter: function (varBag, idService) {
return varBag.model.variables.isExpiryDateErrorVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"pcS21yiulUeJzM8PGQhh_A": {
getter: function (varBag, idService) {
return varBag.model.variables.getDataDataAct;
}
},
"xOCHuO4jv06uhvU_viSQ6g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderLeft"));
})(varBag.model, idService);
}
},
"SSTWuLwS9kS8h5c6nCWXzw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderCenter"));
})(varBag.model, idService);
}
},
"biABr4jVdU+iTyKqT6zBsg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderRight"));
})(varBag.model, idService);
}
},
"Z461cukZ7E+RqiUl_1uGoA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"gv9GsYi1Dk658U32OcAwsQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"QegiT_gUfkOxc90Mvut33Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Top"));
})(varBag.model, idService);
}
},
"8roT5mu4e02AM7sG8iXyMg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Checkbox"));
})(varBag.model, idService);
}
},
"yK8+Mf+0sUODXuWQWqVVkA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Checkbox_IsDefaulCard"));
})(varBag.model, idService);
}
},
"_y_p82eubUOX8nG+tb7CBw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Label"));
})(varBag.model, idService);
}
},
"_Nrrn8EiTEK115E7N219_w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Bottom"));
})(varBag.model, idService);
}
},
"Irt1PojAFk60Qqq+o6LRbg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Button"));
})(varBag.model, idService);
}
},
"mg_kIWnq5EWaf1YDTpFF+Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"PC+KmViSFU2VJU4vaeeifw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Bottom"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
