define("reCAPTCHAReact.controller$Execute", ["exports", "OutSystems/ClientRuntime/Main", "reCAPTCHAReact.model", "reCAPTCHAReact.controller", "reCAPTCHAReact.controller$Execute.v2ExecuteJS", "reCAPTCHAReact.model$ResultRec"], function (exports, OutSystems, reCAPTCHAReactModel, reCAPTCHAReactController, reCAPTCHAReact_controller_Execute_v2ExecuteJS) {
var OS = OutSystems.Internal;
reCAPTCHAReactController.default.execute$Action = function (widget_idIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("reCAPTCHAReact.Execute$vars"))());
vars.value.widget_idInLocal = widget_idIn;
var allExceptionsVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.ErrorHandlerOutputType());
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("reCAPTCHAReact.Execute$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.allExceptionsVar = allExceptionsVar;
varBag.outVars = outVars;
try {try {OutSystemsDebugger.push("o_YczqP5jE+AKx3_6JNghg:A6QPFAsA40ea0VSHrqCdkw:/ClientActionFlows.A6QPFAsA40ea0VSHrqCdkw:VaG5ndzNTigT_LsPLsqT9g", "reCAPTCHAReact", "Execute", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("o_YczqP5jE+AKx3_6JNghg:3y3EkIUASU2A9Lmv9eCxeg", callContext.id);
OutSystemsDebugger.handleBreakpoint("o_YczqP5jE+AKx3_6JNghg:cxXaGiLFJku7OwEjHGh3lA", callContext.id);
controller.safeExecuteJSNode(reCAPTCHAReact_controller_Execute_v2ExecuteJS, "v2Execute", "Execute", {
Widget_id: OS.DataConversion.JSNodeParamConverter.to(vars.value.widget_idInLocal, OS.DataTypes.DataTypes.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("o_YczqP5jE+AKx3_6JNghg:_1ZazuBo1UKWjhpz5NfuzQ", callContext.id);
} catch (ex) {
(function () {
OS.Logger.trace("Execute.Execute", OS.Exceptions.getMessage(ex), ex.name);
// Handle Error: AllExceptions
if(!(OS.Exceptions.isSystem(ex))) {
OS.Logger.error(null, ex);
allExceptionsVar.value.exceptionMessageAttr = OS.Exceptions.getMessage(ex);
OutSystemsDebugger.handleException(allExceptionsVar.value.exceptionMessageAttr, callContext.id);
OutSystemsDebugger.handleBreakpoint("o_YczqP5jE+AKx3_6JNghg:HU4AHrbXaUO4gotjuz4H3w", callContext.id);
OutSystemsDebugger.handleBreakpoint("o_YczqP5jE+AKx3_6JNghg:GxrXbA2enUeLxcIQNI0ZRQ", callContext.id);
// Result.Success = False
outVars.value.resultOut.successAttr = false;
OutSystemsDebugger.handleBreakpoint("o_YczqP5jE+AKx3_6JNghg:GxrXbA2enUeLxcIQNI0ZRQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Result.ErrorMessage = AllExceptions.ExceptionMessage
outVars.value.resultOut.errorMessageAttr = allExceptionsVar.value.exceptionMessageAttr;
OutSystemsDebugger.handleBreakpoint("o_YczqP5jE+AKx3_6JNghg:6aGnaSKpDE6V8WCw9Rq8MQ", callContext.id);
return outVars.value;

}

throw ex;
})();
}

return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("o_YczqP5jE+AKx3_6JNghg:A6QPFAsA40ea0VSHrqCdkw", callContext.id);
}

};
var controller = reCAPTCHAReactController.default;
reCAPTCHAReactController.default.constructor.registerVariableGroupType("reCAPTCHAReact.Execute$vars", [{
name: "Widget_id",
attrName: "widget_idInLocal",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
reCAPTCHAReactController.default.constructor.registerVariableGroupType("reCAPTCHAReact.Execute$outVars", [{
name: "Result",
attrName: "resultOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Record,
defaultValue: function () {
return new reCAPTCHAReactModel.ResultRec();
},
complexType: reCAPTCHAReactModel.ResultRec
}]);
reCAPTCHAReactController.default.clientActionProxies.execute$Action = function (widget_idIn) {
widget_idIn = (widget_idIn === undefined) ? "" : widget_idIn;
return controller.executeActionInsideJSNode(reCAPTCHAReactController.default.execute$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(widget_idIn, OS.DataTypes.DataTypes.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Result: actionResults.resultOut
};
});
};
});
define("reCAPTCHAReact.controller$Execute.v2ExecuteJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
if($parameters.Widget_id !== "") {
    grecaptcha.execute($parameters.Widget_id);
} else {
    grecaptcha.execute();
}

};
});

define("reCAPTCHAReact.controller$GetResponse", ["exports", "OutSystems/ClientRuntime/Main", "reCAPTCHAReact.model", "reCAPTCHAReact.controller", "reCAPTCHAReact.controller$GetResponse.GetResponseJS", "reCAPTCHAReact.model$ResponseRec"], function (exports, OutSystems, reCAPTCHAReactModel, reCAPTCHAReactController, reCAPTCHAReact_controller_GetResponse_GetResponseJS) {
var OS = OutSystems.Internal;
reCAPTCHAReactController.default.getResponse$Action = function (widget_idIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("reCAPTCHAReact.GetResponse$vars"))());
vars.value.widget_idInLocal = widget_idIn;
var allExceptionsVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.ErrorHandlerOutputType());
var getResponseJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("reCAPTCHAReact.GetResponse$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.allExceptionsVar = allExceptionsVar;
varBag.getResponseJSResult = getResponseJSResult;
varBag.outVars = outVars;
try {try {OutSystemsDebugger.push("o_YczqP5jE+AKx3_6JNghg:4l0p8qxVIku8d42IM1iVkQ:/ClientActionFlows.4l0p8qxVIku8d42IM1iVkQ:m8h_mU3mSF5KBeTTa33mdA", "reCAPTCHAReact", "GetResponse", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("o_YczqP5jE+AKx3_6JNghg:Jzfe+uABdE2cOX2rc8mzyQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("o_YczqP5jE+AKx3_6JNghg:hYgRdwNku0CjwFtfAoxROA", callContext.id);
getResponseJSResult.value = controller.safeExecuteJSNode(reCAPTCHAReact_controller_GetResponse_GetResponseJS, "GetResponse", "GetResponse", {
Widget_id: OS.DataConversion.JSNodeParamConverter.to(vars.value.widget_idInLocal, OS.DataTypes.DataTypes.Text),
Response: OS.DataConversion.JSNodeParamConverter.to("", OS.DataTypes.DataTypes.Text)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("reCAPTCHAReact.GetResponse$getResponseJSResult"))();
jsNodeResult.responseOut = OS.DataConversion.JSNodeParamConverter.from($parameters.Response, OS.DataTypes.DataTypes.Text);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("o_YczqP5jE+AKx3_6JNghg:6BsFRWo5XUSnOtvF7VEvDA", callContext.id);
// Response.Token = GetResponse.Response
outVars.value.responseOut.tokenAttr = getResponseJSResult.value.responseOut;
OutSystemsDebugger.handleBreakpoint("o_YczqP5jE+AKx3_6JNghg:qj06EORhAEyTxOeEa9pDBQ", callContext.id);
} catch (ex) {
(function () {
OS.Logger.trace("GetResponse.GetResponse", OS.Exceptions.getMessage(ex), ex.name);
// Handle Error: AllExceptions
if(!(OS.Exceptions.isSystem(ex))) {
OS.Logger.error(null, ex);
allExceptionsVar.value.exceptionMessageAttr = OS.Exceptions.getMessage(ex);
OutSystemsDebugger.handleException(allExceptionsVar.value.exceptionMessageAttr, callContext.id);
OutSystemsDebugger.handleBreakpoint("o_YczqP5jE+AKx3_6JNghg:5uq60dDhCUWuUXbbkJMCrw", callContext.id);
OutSystemsDebugger.handleBreakpoint("o_YczqP5jE+AKx3_6JNghg:UX0f3SIZyUWmCif85xAGow", callContext.id);
// Response.Success = False
outVars.value.responseOut.successAttr = false;
OutSystemsDebugger.handleBreakpoint("o_YczqP5jE+AKx3_6JNghg:UX0f3SIZyUWmCif85xAGow", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Response.ErrorMessage = AllExceptions.ExceptionMessage
outVars.value.responseOut.errorMessageAttr = allExceptionsVar.value.exceptionMessageAttr;
OutSystemsDebugger.handleBreakpoint("o_YczqP5jE+AKx3_6JNghg:YX+wkVLPMkW45jCXWsb5EQ", callContext.id);
return outVars.value;

}

throw ex;
})();
}

return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("o_YczqP5jE+AKx3_6JNghg:4l0p8qxVIku8d42IM1iVkQ", callContext.id);
}

};
var controller = reCAPTCHAReactController.default;
reCAPTCHAReactController.default.constructor.registerVariableGroupType("reCAPTCHAReact.GetResponse$vars", [{
name: "Widget_id",
attrName: "widget_idInLocal",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
reCAPTCHAReactController.default.constructor.registerVariableGroupType("reCAPTCHAReact.GetResponse$getResponseJSResult", [{
name: "Response",
attrName: "responseOut",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
reCAPTCHAReactController.default.constructor.registerVariableGroupType("reCAPTCHAReact.GetResponse$outVars", [{
name: "Response",
attrName: "responseOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Record,
defaultValue: function () {
return new reCAPTCHAReactModel.ResponseRec();
},
complexType: reCAPTCHAReactModel.ResponseRec
}]);
reCAPTCHAReactController.default.clientActionProxies.getResponse$Action = function (widget_idIn) {
widget_idIn = (widget_idIn === undefined) ? "" : widget_idIn;
return controller.executeActionInsideJSNode(reCAPTCHAReactController.default.getResponse$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(widget_idIn, OS.DataTypes.DataTypes.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Response: actionResults.responseOut
};
});
};
});
define("reCAPTCHAReact.controller$GetResponse.GetResponseJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
if($parameters.Widget_id !== "") {
    $parameters.Response = grecaptcha.getResponse($parameters.Widget_id);
} else {
    $parameters.Response = grecaptcha.getResponse();
}

};
});

define("reCAPTCHAReact.controller$Reset", ["exports", "OutSystems/ClientRuntime/Main", "reCAPTCHAReact.model", "reCAPTCHAReact.controller", "reCAPTCHAReact.controller$Reset.ResetJS", "reCAPTCHAReact.model$ResultRec"], function (exports, OutSystems, reCAPTCHAReactModel, reCAPTCHAReactController, reCAPTCHAReact_controller_Reset_ResetJS) {
var OS = OutSystems.Internal;
reCAPTCHAReactController.default.reset$Action = function (widget_idIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("reCAPTCHAReact.Reset$vars"))());
vars.value.widget_idInLocal = widget_idIn;
var allExceptionsVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.ErrorHandlerOutputType());
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("reCAPTCHAReact.Reset$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.allExceptionsVar = allExceptionsVar;
varBag.outVars = outVars;
try {try {OutSystemsDebugger.push("o_YczqP5jE+AKx3_6JNghg:mh4CHAdhrkeCE5PVBn0HHQ:/ClientActionFlows.mh4CHAdhrkeCE5PVBn0HHQ:ee9gRSmMrgJjtAef4WtP+Q", "reCAPTCHAReact", "Reset", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("o_YczqP5jE+AKx3_6JNghg:xAG4FY8C+U2nQ_7PqjKPAg", callContext.id);
OutSystemsDebugger.handleBreakpoint("o_YczqP5jE+AKx3_6JNghg:Q0zYnfN3TkWeXhZeCDjphQ", callContext.id);
controller.safeExecuteJSNode(reCAPTCHAReact_controller_Reset_ResetJS, "Reset", "Reset", {
Widget_id: OS.DataConversion.JSNodeParamConverter.to(vars.value.widget_idInLocal, OS.DataTypes.DataTypes.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("o_YczqP5jE+AKx3_6JNghg:FI6lk83UE0e_S3yEZbrxHA", callContext.id);
} catch (ex) {
(function () {
OS.Logger.trace("Reset.Reset", OS.Exceptions.getMessage(ex), ex.name);
// Handle Error: AllExceptions
if(!(OS.Exceptions.isSystem(ex))) {
OS.Logger.error(null, ex);
allExceptionsVar.value.exceptionMessageAttr = OS.Exceptions.getMessage(ex);
OutSystemsDebugger.handleException(allExceptionsVar.value.exceptionMessageAttr, callContext.id);
OutSystemsDebugger.handleBreakpoint("o_YczqP5jE+AKx3_6JNghg:ZFIC81ytFkKoUBRm7kpI9Q", callContext.id);
OutSystemsDebugger.handleBreakpoint("o_YczqP5jE+AKx3_6JNghg:DjOKcLCwgk+YFQe1PpCTkg", callContext.id);
// Result.Success = False
outVars.value.resultOut.successAttr = false;
OutSystemsDebugger.handleBreakpoint("o_YczqP5jE+AKx3_6JNghg:DjOKcLCwgk+YFQe1PpCTkg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Result.ErrorMessage = AllExceptions.ExceptionMessage
outVars.value.resultOut.errorMessageAttr = allExceptionsVar.value.exceptionMessageAttr;
OutSystemsDebugger.handleBreakpoint("o_YczqP5jE+AKx3_6JNghg:dLrAH5W5hUeYhAlEH+gQSw", callContext.id);
return outVars.value;

}

throw ex;
})();
}

return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("o_YczqP5jE+AKx3_6JNghg:mh4CHAdhrkeCE5PVBn0HHQ", callContext.id);
}

};
var controller = reCAPTCHAReactController.default;
reCAPTCHAReactController.default.constructor.registerVariableGroupType("reCAPTCHAReact.Reset$vars", [{
name: "Widget_id",
attrName: "widget_idInLocal",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
reCAPTCHAReactController.default.constructor.registerVariableGroupType("reCAPTCHAReact.Reset$outVars", [{
name: "Result",
attrName: "resultOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Record,
defaultValue: function () {
return new reCAPTCHAReactModel.ResultRec();
},
complexType: reCAPTCHAReactModel.ResultRec
}]);
reCAPTCHAReactController.default.clientActionProxies.reset$Action = function (widget_idIn) {
widget_idIn = (widget_idIn === undefined) ? "" : widget_idIn;
return controller.executeActionInsideJSNode(reCAPTCHAReactController.default.reset$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(widget_idIn, OS.DataTypes.DataTypes.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Result: actionResults.resultOut
};
});
};
});
define("reCAPTCHAReact.controller$Reset.ResetJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
if($parameters.Widget_id !== "") {
    grecaptcha.reset($parameters.Widget_id);
} else {
    grecaptcha.reset();
}

};
});

define("reCAPTCHAReact.controller$v3Execute", ["exports", "OutSystems/ClientRuntime/Main", "reCAPTCHAReact.model", "reCAPTCHAReact.controller", "reCAPTCHAReact.controller$v3Execute.v3ExecuteJS", "reCAPTCHAReact.model$ResponseRec"], function (exports, OutSystems, reCAPTCHAReactModel, reCAPTCHAReactController, reCAPTCHAReact_controller_v3Execute_v3ExecuteJS) {
var OS = OutSystems.Internal;
reCAPTCHAReactController.default.v3Execute$Action = function (recaptchaIdIn, actionIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("reCAPTCHAReact.v3Execute$vars"))());
vars.value.recaptchaIdInLocal = recaptchaIdIn;
vars.value.actionInLocal = actionIn;
var allExceptionsVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.ErrorHandlerOutputType());
var v3ExecuteJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("reCAPTCHAReact.v3Execute$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.allExceptionsVar = allExceptionsVar;
varBag.v3ExecuteJSResult = v3ExecuteJSResult;
varBag.outVars = outVars;
OutSystemsDebugger.push("o_YczqP5jE+AKx3_6JNghg:0IlsQqOWfkCy3iZ4OOeYvw:/ClientActionFlows.0IlsQqOWfkCy3iZ4OOeYvw:z1w56P3MthpGlvt874ikWg", "reCAPTCHAReact", "v3Execute", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("o_YczqP5jE+AKx3_6JNghg:RIZ0AWwdA0yFyiBRO2UcIg", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("o_YczqP5jE+AKx3_6JNghg:iQGjMdBoLUa0TBaVRGoWqw", callContext.id);
// The Id of the Recaptcha v3, returned in the callback
return controller.safeExecuteAsyncJSNode(reCAPTCHAReact_controller_v3Execute_v3ExecuteJS, "v3Execute", "v3Execute", {
RecaptchaId: OS.DataConversion.JSNodeParamConverter.to(vars.value.recaptchaIdInLocal, OS.DataTypes.DataTypes.Text),
Action: OS.DataConversion.JSNodeParamConverter.to(vars.value.actionInLocal, OS.DataTypes.DataTypes.Text),
Success: OS.DataConversion.JSNodeParamConverter.to(true, OS.DataTypes.DataTypes.Boolean),
ErrorMessage: OS.DataConversion.JSNodeParamConverter.to("", OS.DataTypes.DataTypes.Text),
Token: OS.DataConversion.JSNodeParamConverter.to("", OS.DataTypes.DataTypes.Text)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("reCAPTCHAReact.v3Execute$v3ExecuteJSResult"))();
jsNodeResult.successOut = OS.DataConversion.JSNodeParamConverter.from($parameters.Success, OS.DataTypes.DataTypes.Boolean);
jsNodeResult.errorMessageOut = OS.DataConversion.JSNodeParamConverter.from($parameters.ErrorMessage, OS.DataTypes.DataTypes.Text);
jsNodeResult.tokenOut = OS.DataConversion.JSNodeParamConverter.from($parameters.Token, OS.DataTypes.DataTypes.Text);
return jsNodeResult;
}, {}, {}).then(function (results) {
v3ExecuteJSResult.value = results;
}).then(function () {
OutSystemsDebugger.handleBreakpoint("o_YczqP5jE+AKx3_6JNghg:NeTM6fG3t0GzpGtQNB_eaw", callContext.id);
// Response.Token = v3Execute.Token
outVars.value.responseOut.tokenAttr = v3ExecuteJSResult.value.tokenOut;
OutSystemsDebugger.handleBreakpoint("o_YczqP5jE+AKx3_6JNghg:NeTM6fG3t0GzpGtQNB_eaw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Response.Success = v3Execute.Success
outVars.value.responseOut.successAttr = v3ExecuteJSResult.value.successOut;
OutSystemsDebugger.handleBreakpoint("o_YczqP5jE+AKx3_6JNghg:NeTM6fG3t0GzpGtQNB_eaw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// Response.ErrorMessage = v3Execute.ErrorMessage
outVars.value.responseOut.errorMessageAttr = v3ExecuteJSResult.value.errorMessageOut;
OutSystemsDebugger.handleBreakpoint("o_YczqP5jE+AKx3_6JNghg:o+BKRh9zVk6QI41ePiklRw", callContext.id);
});
}).catch(function (ex) {
OS.Logger.trace("v3Execute.v3Execute", OS.Exceptions.getMessage(ex), ex.name);
// Handle Error: AllExceptions
if(!(OS.Exceptions.isSystem(ex))) {
OS.Logger.error(null, ex);
allExceptionsVar.value.exceptionMessageAttr = OS.Exceptions.getMessage(ex);
OutSystemsDebugger.handleException(allExceptionsVar.value.exceptionMessageAttr, callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("o_YczqP5jE+AKx3_6JNghg:pmbgnGZs5Ue1pNJA2jYzWA", callContext.id);
OutSystemsDebugger.handleBreakpoint("o_YczqP5jE+AKx3_6JNghg:7hla97tV5E6pVwgqOn1TRQ", callContext.id);
// Response.Success = False
outVars.value.responseOut.successAttr = false;
OutSystemsDebugger.handleBreakpoint("o_YczqP5jE+AKx3_6JNghg:7hla97tV5E6pVwgqOn1TRQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Response.ErrorMessage = AllExceptions.ExceptionMessage
outVars.value.responseOut.errorMessageAttr = allExceptionsVar.value.exceptionMessageAttr;
OutSystemsDebugger.handleBreakpoint("o_YczqP5jE+AKx3_6JNghg:faqIj0bhbk+WcybBTTPWxw", callContext.id);
return OS.Flow.returnAsync(outVars.value);

});
}

throw ex;
}).then(function () {
return outVars.value;
}).then(function (res) {
OutSystemsDebugger.pop("o_YczqP5jE+AKx3_6JNghg:0IlsQqOWfkCy3iZ4OOeYvw", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("o_YczqP5jE+AKx3_6JNghg:0IlsQqOWfkCy3iZ4OOeYvw", callContext.id);
throw ex;

});
};
var controller = reCAPTCHAReactController.default;
reCAPTCHAReactController.default.constructor.registerVariableGroupType("reCAPTCHAReact.v3Execute$vars", [{
name: "RecaptchaId",
attrName: "recaptchaIdInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}, {
name: "Action",
attrName: "actionInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
reCAPTCHAReactController.default.constructor.registerVariableGroupType("reCAPTCHAReact.v3Execute$v3ExecuteJSResult", [{
name: "Success",
attrName: "successOut",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Boolean,
defaultValue: function () {
return true;
}
}, {
name: "ErrorMessage",
attrName: "errorMessageOut",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}, {
name: "Token",
attrName: "tokenOut",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
reCAPTCHAReactController.default.constructor.registerVariableGroupType("reCAPTCHAReact.v3Execute$outVars", [{
name: "Response",
attrName: "responseOut",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Record,
defaultValue: function () {
return new reCAPTCHAReactModel.ResponseRec();
},
complexType: reCAPTCHAReactModel.ResponseRec
}]);
reCAPTCHAReactController.default.clientActionProxies.v3Execute$Action = function (recaptchaIdIn, actionIn) {
recaptchaIdIn = (recaptchaIdIn === undefined) ? "" : recaptchaIdIn;
actionIn = (actionIn === undefined) ? "" : actionIn;
return controller.executeActionInsideJSNode(reCAPTCHAReactController.default.v3Execute$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(recaptchaIdIn, OS.DataTypes.DataTypes.Text), OS.DataConversion.JSNodeParamConverter.from(actionIn, OS.DataTypes.DataTypes.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Response: actionResults.responseOut
};
});
};
});
define("reCAPTCHAReact.controller$v3Execute.v3ExecuteJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
return new Promise(function ($resolve, $reject) {
grecaptcha.ready(function() {
    grecaptcha.execute($parameters.RecaptchaId, {action: $parameters.Action})
    .then(function(token) {
        $parameters.Token = token;
        $resolve();
    })
    .catch(function(error){
        // an error will be thrown if action name is invalid
        // this avoid the console "uncaught on promise"
        $parameters.Success = false;
        $parameters.ErrorMessage = error;
        $resolve();
    });
});

});
};
});

define("reCAPTCHAReact.controller", ["exports", "OutSystems/ClientRuntime/Main", "reCAPTCHAReact.model", "reCAPTCHAReact.controller$debugger"], function (exports, OutSystems, reCAPTCHAReactModel, reCAPTCHAReact_Controller_debugger) {
var OS = OutSystems.Internal;
var reCAPTCHAReactController = exports;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
}
Controller.prototype.clientActionProxies = {};
Controller.prototype.roles = {};
Controller.prototype.defaultTimeout = 10;
Controller.prototype.getDefaultTimeout = function () {
return reCAPTCHAReactController.default.defaultTimeout;
};
Controller.prototype.getClientActionProxies = function (controller) {
var _this = this;
var thisController = controller;
return Object.keys(this.clientActionProxies).reduce(function (acc, actionName) {
acc[actionName] = function () {
if(thisController.isActive()) {
return _this.clientActionProxies[actionName].apply(thisController, arguments);
}

return Promise.resolve();
};
return acc;
}, {});
};
return Controller;
})(OS.Controller.BaseModuleController);
reCAPTCHAReactController.default = new Controller(null, "reCAPTCHAReact");
});
define("reCAPTCHAReact.controller$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"_eRLlwzGr0attJdRDM+L6g": {
getter: function (varBag, idService) {
return varBag.vars.value.widget_idInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"_4QWA114KkqvO85WLUywvA": {
getter: function (varBag, idService) {
return varBag.outVars.value.resultOut;
}
},
"HU4AHrbXaUO4gotjuz4H3w": {
getter: function (varBag, idService) {
return varBag.allExceptionsVar.value;
}
},
"cxXaGiLFJku7OwEjHGh3lA": {
getter: function (varBag, idService) {
return varBag.v2ExecuteJSResult.value;
}
},
"Zia1rDXNFUmDhwO1gRkJYw": {
getter: function (varBag, idService) {
return varBag.vars.value.widget_idInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"bHi0kQhasEa+QSoCCX8ZSg": {
getter: function (varBag, idService) {
return varBag.outVars.value.resultOut;
}
},
"ZFIC81ytFkKoUBRm7kpI9Q": {
getter: function (varBag, idService) {
return varBag.allExceptionsVar.value;
}
},
"Q0zYnfN3TkWeXhZeCDjphQ": {
getter: function (varBag, idService) {
return varBag.resetJSResult.value;
}
},
"7ytv2mK+oEm81ouP1E1e7A": {
getter: function (varBag, idService) {
return varBag.vars.value.recaptchaIdInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"CHnv3R40ZEmuRqQwWVPocg": {
getter: function (varBag, idService) {
return varBag.vars.value.actionInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"v9GhqDRcAEe5FmUtrdtX_Q": {
getter: function (varBag, idService) {
return varBag.outVars.value.responseOut;
}
},
"pmbgnGZs5Ue1pNJA2jYzWA": {
getter: function (varBag, idService) {
return varBag.allExceptionsVar.value;
}
},
"iQGjMdBoLUa0TBaVRGoWqw": {
getter: function (varBag, idService) {
return varBag.v3ExecuteJSResult.value;
}
},
"ua2TxYdjakue2TzIeBn7DQ": {
getter: function (varBag, idService) {
return varBag.vars.value.widget_idInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"I9yw+_Nbe0uHDietPodnyg": {
getter: function (varBag, idService) {
return varBag.outVars.value.responseOut;
}
},
"5uq60dDhCUWuUXbbkJMCrw": {
getter: function (varBag, idService) {
return varBag.allExceptionsVar.value;
}
},
"hYgRdwNku0CjwFtfAoxROA": {
getter: function (varBag, idService) {
return varBag.getResponseJSResult.value;
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
