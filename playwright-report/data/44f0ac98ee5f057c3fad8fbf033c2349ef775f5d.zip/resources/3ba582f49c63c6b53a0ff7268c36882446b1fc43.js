define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.ScanBarcode.mvc$model", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.model$ScanBarcodePropertiesRec", "ShopperPortalEU_UI_Components.model$ScanBarcodeDataRec", "ShopperPortalEU_UI_Components.model$ScanBarcodeErrorRec"], function (OutSystems, ShopperPortalEU_UI_ComponentsModel) {
var OS = OutSystems.Internal;

var GetLicenseDataActRec = (function (_super) {
__extends(GetLicenseDataActRec, _super);
function GetLicenseDataActRec(defaults) {
_super.apply(this, arguments);
}
GetLicenseDataActRec.attributesToDeclare = function () {
return [
this.attr("License", "licenseOut", "License", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
GetLicenseDataActRec.fromStructure = function (str) {
return new GetLicenseDataActRec(new GetLicenseDataActRec.RecordClass({
licenseOut: OS.DataTypes.ImmutableBase.getData(str)
}));
};
GetLicenseDataActRec.init();
return GetLicenseDataActRec;
})(OS.Model.DataSourceRecord);

var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("Obj", "objVar", "Obj", true, false, OS.DataTypes.DataTypes.Object, function () {
return null;
}, false), 
this.attr("Properties", "propertiesVar", "Properties", true, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.ScanBarcodePropertiesRec());
}, false, ShopperPortalEU_UI_ComponentsModel.ScanBarcodePropertiesRec), 
this.attr("ExtendedClass", "extendedClassIn", "ExtendedClass", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, false), 
this.attr("_extendedClassInDataFetchStatus", "_extendedClassInDataFetchStatus", "_extendedClassInDataFetchStatus", true, false, OS.DataTypes.DataTypes.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("GetLicense", "getLicenseDataAct", "getLicenseDataAct", true, true, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new GetLicenseDataActRec());
}, true, GetLicenseDataActRec)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return false;
}
});

Model.prototype.setInputs = function (inputs) {
if("ExtendedClass" in inputs) {
this.variables.extendedClassIn = inputs.ExtendedClass;
if("_extendedClassInDataFetchStatus" in inputs) {
this.variables._extendedClassInDataFetchStatus = inputs._extendedClassInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "ShopperPortalEUUIComponents.ScanBarcode");
});
define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.ScanBarcode.mvc$view", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.controller", "react", "OutSystems/ReactView/Main", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.ScanBarcode.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.ScanBarcode.mvc$controller", "OutSystems/ReactWidgets/Main", "ShopperPortalEU_UI_Components.model$ScanBarcodePropertiesRec", "ShopperPortalEU_UI_Components.model$ScanBarcodeDataRec", "ShopperPortalEU_UI_Components.model$ScanBarcodeErrorRec"], function (OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ComponentsController, React, OSView, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_ScanBarcode_mvc_model, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_ScanBarcode_mvc_controller, OSWidgets) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            var thisIsInstanceOfSuper = this instanceof _super;
            if (thisIsInstanceOfSuper == false) {
                return;
            }

            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "ShopperPortalEUUIComponents.ScanBarcode";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css"];
        };
        View.getJsDependencies = function() {
            return ["scripts/ShopperPortalEU_UI_Components.anylineJS.js", "scripts/ShopperPortalEU_UI_Components.scanBarcode.js"];
        };
        View.getBlocks = function() {
            return [];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_ScanBarcode_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_ScanBarcode_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: model.getCachedValue(idService.getId("Element.Style"), function () {
return ("scan-barcode" + (((model.variables.extendedClassIn === "")) ? ("") : ((" " + model.variables.extendedClassIn))));
}, function () {
return model.variables.extendedClassIn;
}),
visible: true,
_idProps: {
service: idService,
name: "Element"
},
_widgetRecordProvider: widgetsRecordProvider,
style_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._extendedClassInDataFetchStatus)
}));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.ScanBarcode.mvc$controller", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Components.controller", "ShopperPortalEU_UI_Components.languageResources", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.ScanBarcode.mvc$debugger", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.ScanBarcode.mvc$controller.OnDestroy.DestroyJS", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.ScanBarcode.mvc$controller.Ready.InitializeJS", "ShopperPortalEU_UI_Components.model$ScanBarcodePropertiesRec", "ShopperPortalEU_UI_Components.model$ScanBarcodeDataRec", "ShopperPortalEU_UI_Components.model$ScanBarcodeErrorRec"], function (OutSystems, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ComponentsController, ShopperPortalEU_UI_ComponentsLanguageResources, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_ScanBarcode_mvc_Debugger, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_ScanBarcode_mvc_controller_OnDestroy_DestroyJS, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_ScanBarcode_mvc_controller_Ready_InitializeJS) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {
load$Action: function () {
return controller.executeActionInsideJSNode(controller._load$Action.bind(controller), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "Load");
},
result$Action: function (dataIn) {
dataIn = (dataIn === undefined) ? "" : dataIn;
return controller.executeActionInsideJSNode(controller._result$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(dataIn, OS.DataTypes.DataTypes.Text)), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "Result");
},
error$Action: function (dataIn) {
dataIn = (dataIn === undefined) ? "" : dataIn;
return controller.executeActionInsideJSNode(controller._error$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(dataIn, OS.DataTypes.DataTypes.Text)), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "Error");
}
};
this.dataFetchDependenciesOriginal = {
getLicense$DataActRefresh: 0
};
this.dataFetchDependentsGraph = {
getLicense$DataActRefresh: []
};
this.shouldSendClientVarsToDataSources = false;
}
// Server Actions

// Aggregates and Data Actions
Controller.prototype.getLicense$DataActRefresh = function (callContext) {
var model = this.model;
var controller = this.controller;
var callContext = controller.callContext(callContext);
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:+Y5XTwrLpkiZCtxYcUFz1w:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.wRXMr3fAhE+JUyjgqVQXTw/DataActions.+Y5XTwrLpkiZCtxYcUFz1w:COVOXwadopnq1mooiPYUnQ", "ShopperPortalEU_UI_Components", "GetLicense", "NRFlows.DataScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.setThreadStartName(callContext.id, "ShopperPortalEUUIComponents/ScanBarcode/GetLicense");
return controller.callDataAction("DataActionGetLicense", "screenservices/ShopperPortalEU_UI_Components/ShopperPortalEUUIComponents/ScanBarcode/DataActionGetLicense", "jUr2eL+nE0O8LbjMFA87SQ", function (b) {
model.variables.getLicenseDataAct.dataFetchStatusAttr = b;
}, function (json) {
model.variables.getLicenseDataAct.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getLicenseDataAct.constructor));
}, undefined, OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, callContext, undefined, false).then(function () {
OutSystemsDebugger.setThreadStartName(callContext.id, "ShopperPortalEUUIComponents/ScanBarcode/GetLicense On After Fetch");
return controller._ready$Action(controller.callContext(callContext));

});

}, function () {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:+Y5XTwrLpkiZCtxYcUFz1w", callContext.id);
controller.popDebuggerContext(callContext);

});
};

Controller.prototype.dataFetchActionNames = ["getLicense$DataActRefresh"];
// Client Actions
Controller.prototype._result$Action = function (dataIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Result");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.ScanBarcode.Result$vars"))());
vars.value.dataInLocal = dataIn;
var resultFromJSONVar = new OS.DataTypes.VariableHolder(new (OS.Controller.BaseController.getJSONDeserializeOutputType(ShopperPortalEU_UI_ComponentsModel.ScanBarcodeDataRec))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.resultFromJSONVar = resultFromJSONVar;
OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:TWz4DAVYtUaUSb6WoOcIjg:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.wRXMr3fAhE+JUyjgqVQXTw/ClientActions.TWz4DAVYtUaUSb6WoOcIjg:OZ6CDNtxqdp8HCh6OPLEpQ", "ShopperPortalEU_UI_Components", "Result", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:fAVptU062k6toVmj2_1kwA", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:5UO+3vPxSk2fYxy+T59MHg", callContext.id);
// JSON Deserialize: ResultFromJSON
resultFromJSONVar.value.dataOut = OS.JSONUtils.deserializeFromJSON(vars.value.dataInLocal, ShopperPortalEU_UI_ComponentsModel.ScanBarcodeDataRec, false);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:FA_ees+01k+GgZz7WD0Daw", callContext.id);
// Trigger Event: OnResult
return controller.onResult$Action(resultFromJSONVar.value.dataOut, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:jizKzHXRIk2ihcMlm4c0zA", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:TWz4DAVYtUaUSb6WoOcIjg", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:TWz4DAVYtUaUSb6WoOcIjg", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.ScanBarcode.Result$vars", [{
name: "Data",
attrName: "dataInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
Controller.prototype._onDestroy$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnDestroy");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:7yDfHDStGUucfuQB5S04GA:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.wRXMr3fAhE+JUyjgqVQXTw/ClientActions.7yDfHDStGUucfuQB5S04GA:hZidJ5x5rDMx8b2yAaSHQw", "ShopperPortalEU_UI_Components", "OnDestroy", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:92lzmjEiH0uoZct2AU++fg", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:rGf8PNpygk6bOiUGejkBIw", callContext.id) && ((model.variables.objVar) !== (OS.BuiltinFunctions.nullObject())))) {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:PHzmw3mN6EqwW4VKquwB8Q", callContext.id);
// Destroy method.
controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_ScanBarcode_mvc_controller_OnDestroy_DestroyJS, "Destroy", "OnDestroy", {
Obj: OS.DataConversion.JSNodeParamConverter.to(model.variables.objVar, OS.DataTypes.DataTypes.Object)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:rUHIAKRuCkaN4RNDdB4WEA", callContext.id);
// Obj = NullObject
model.variables.objVar = OS.BuiltinFunctions.nullObject();
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:oRK0JRyXlUCoFOuDArKQdA", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:C4XeV7sS_kavlUzFhcyRig", callContext.id);
}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:7yDfHDStGUucfuQB5S04GA", callContext.id);
}

};
Controller.prototype._ready$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Ready");
callContext = controller.callContext(callContext);
var initializeJSResult = new OS.DataTypes.VariableHolder();
var propertiesJSONVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.JSONSerializeOutputType());
varBag.callContext = callContext;
varBag.initializeJSResult = initializeJSResult;
varBag.propertiesJSONVar = propertiesJSONVar;
OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:xXjkZSiUoU6nxJRB_RgNWA:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.wRXMr3fAhE+JUyjgqVQXTw/ClientActions.xXjkZSiUoU6nxJRB_RgNWA:Gx8o3vP0Z3jvRO8SnDgzeg", "ShopperPortalEU_UI_Components", "Ready", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:Sb_FbnvldkynAPKVM2zbDA", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
// Has license
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:Q2dnAeD3jky5jIU1g_fkRw", callContext.id) && ((model.variables.getLicenseDataAct.licenseOut) !== ("")))) {
// Properties
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:ukT70oPU0kiAS1LqQcnY_g", callContext.id);
// Properties.License = GetLicense.License
model.variables.propertiesVar.licenseAttr = model.variables.getLicenseDataAct.licenseOut;
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:gCZDYYoyyU+1VVKsTvAnsA", callContext.id);
// JSON Serialize: PropertiesJSON
propertiesJSONVar.value.jSONOut = OS.JSONUtils.serializeToJSON(model.variables.propertiesVar, true, false);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:2E5gLkx5uU+fYjjtzDI25A", callContext.id);
// Initialize component.
initializeJSResult.value = controller.safeExecuteJSNode(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_ScanBarcode_mvc_controller_Ready_InitializeJS, "Initialize", "Ready", {
ElementId: OS.DataConversion.JSNodeParamConverter.to(idService.getId("Element"), OS.DataTypes.DataTypes.Text),
Properties: OS.DataConversion.JSNodeParamConverter.to(propertiesJSONVar.value.jSONOut, OS.DataTypes.DataTypes.Text),
Obj: OS.DataConversion.JSNodeParamConverter.to(null, OS.DataTypes.DataTypes.Object)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.ScanBarcode.Ready$initializeJSResult"))();
jsNodeResult.objOut = OS.DataConversion.JSNodeParamConverter.from($parameters.Obj, OS.DataTypes.DataTypes.Object);
return jsNodeResult;
}, {
Load: controller.clientActionProxies.load$Action,
Result: controller.clientActionProxies.result$Action,
Error: controller.clientActionProxies.error$Action
}, {});
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:5pVzPW1IyUqvqPf3Ul44EQ", callContext.id);
// Obj = Initialize.Obj
model.variables.objVar = initializeJSResult.value.objOut;
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:u423ZZwXVkqHx+O81r1P3g", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:VAHMC+Vdu0y82J8bz7SoCg", callContext.id);
// Trigger Event: OnError
return controller.onError$Action(function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.ScanBarcodeErrorRec();
rec.codeAttr = "1";
rec.messageAttr = "Invalid license";
return rec;
}(), callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:7cm4+NC+a0a2wtvldNeJXg", callContext.id);
});
}

});
}).then(function (res) {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:xXjkZSiUoU6nxJRB_RgNWA", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:xXjkZSiUoU6nxJRB_RgNWA", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.ScanBarcode.Ready$initializeJSResult", [{
name: "Obj",
attrName: "objOut",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Object,
defaultValue: function () {
return null;
}
}]);
Controller.prototype._load$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Load");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:CuxKf2pqPUyzjews4fqv8Q:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.wRXMr3fAhE+JUyjgqVQXTw/ClientActions.CuxKf2pqPUyzjews4fqv8Q:wTZdox_7ASQ2NU429Xq8VA", "ShopperPortalEU_UI_Components", "Load", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:fqwy5AFP7ECKN3hOx1gIkA", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:9psTAoy1o0mdbLXkTp8k1g", callContext.id);
// Trigger Event: OnLoad
return controller.onLoad$Action(callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:pXScWoDGbESBs4XkpPBDcg", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:CuxKf2pqPUyzjews4fqv8Q", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:CuxKf2pqPUyzjews4fqv8Q", callContext.id);
throw ex;

});
};
Controller.prototype._error$Action = function (dataIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Error");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.ScanBarcode.Error$vars"))());
vars.value.dataInLocal = dataIn;
var errorFromJSONVar = new OS.DataTypes.VariableHolder(new (OS.Controller.BaseController.getJSONDeserializeOutputType(ShopperPortalEU_UI_ComponentsModel.ScanBarcodeErrorRec))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.errorFromJSONVar = errorFromJSONVar;
OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:P5HV9coYYESKs6LKCNU2wQ:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.wRXMr3fAhE+JUyjgqVQXTw/ClientActions.P5HV9coYYESKs6LKCNU2wQ:iWHwXbgjqbtOJ34T+P56DA", "ShopperPortalEU_UI_Components", "Error", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:u8cEcCt+cE+LAGADYkrX1Q", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:EQq5NZ5LgE+z4c_jzfhZzw", callContext.id);
// JSON Deserialize: ErrorFromJSON
errorFromJSONVar.value.dataOut = OS.JSONUtils.deserializeFromJSON(vars.value.dataInLocal, ShopperPortalEU_UI_ComponentsModel.ScanBarcodeErrorRec, false);
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:bw3Vm5FZRU2H08PT11iROA", callContext.id);
// Trigger Event: OnError
return controller.onError$Action(errorFromJSONVar.value.dataOut, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("Jn6752SvaU+UNgdo1U6gGw:yNT4UuadUEaa1UUiAxeoiQ", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:P5HV9coYYESKs6LKCNU2wQ", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:P5HV9coYYESKs6LKCNU2wQ", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.ScanBarcode.Error$vars", [{
name: "Data",
attrName: "dataInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);

Controller.prototype.result$Action = function (dataIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._result$Action, callContext, dataIn);

};
Controller.prototype.onDestroy$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onDestroy$Action, callContext);

};
Controller.prototype.ready$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._ready$Action, callContext);

};
Controller.prototype.load$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._load$Action, callContext);

};
Controller.prototype.error$Action = function (dataIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._error$Action, callContext, dataIn);

};
Controller.prototype.onResult$Action = function () {
return Promise.resolve();
};
Controller.prototype.onLoad$Action = function () {
return Promise.resolve();
};
Controller.prototype.onError$Action = function () {
return Promise.resolve();
};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:7hC2bHqrKEmxvEuPSzIN0Q:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q:g5BtT+X6uN+vFl8t9PMqCQ", "ShopperPortalEU_UI_Components", "ShopperPortalEUUIComponents", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("Jn6752SvaU+UNgdo1U6gGw:wRXMr3fAhE+JUyjgqVQXTw:/NRWebFlows.7hC2bHqrKEmxvEuPSzIN0Q/NodesShownInESpaceTree.wRXMr3fAhE+JUyjgqVQXTw:YCXmVZlCUgNDTNirMFtHSw", "ShopperPortalEU_UI_Components", "ScanBarcode", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:wRXMr3fAhE+JUyjgqVQXTw", callContext.id);
OutSystemsDebugger.pop("Jn6752SvaU+UNgdo1U6gGw:7hC2bHqrKEmxvEuPSzIN0Q", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "ShopperPortalEUUIComponents/ScanBarcode On Destroy");
return controller.onDestroy$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return ShopperPortalEU_UI_ComponentsController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, ShopperPortalEU_UI_ComponentsLanguageResources);
});
define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.ScanBarcode.mvc$controller.OnDestroy.DestroyJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.Obj.destroy();
};
});
define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.ScanBarcode.mvc$controller.Ready.InitializeJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.Obj = new scanBarcode($parameters.ElementId,JSON.parse($parameters.Properties),{
    load:$actions.Load,
    result:$actions.Result,
    error:$actions.Error
});
};
});

define("ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.ScanBarcode.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"HGxcdXZxokaOm1fIOgkcGg": {
getter: function (varBag, idService) {
return varBag.vars.value.dataInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"5UO+3vPxSk2fYxy+T59MHg": {
getter: function (varBag, idService) {
return varBag.resultFromJSONVar.value;
}
},
"PHzmw3mN6EqwW4VKquwB8Q": {
getter: function (varBag, idService) {
return varBag.destroyJSResult.value;
}
},
"gCZDYYoyyU+1VVKsTvAnsA": {
getter: function (varBag, idService) {
return varBag.propertiesJSONVar.value;
}
},
"2E5gLkx5uU+fYjjtzDI25A": {
getter: function (varBag, idService) {
return varBag.initializeJSResult.value;
}
},
"JUeED2YA1kWtyxxsp3V6ZA": {
getter: function (varBag, idService) {
return varBag.vars.value.dataInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"EQq5NZ5LgE+z4c_jzfhZzw": {
getter: function (varBag, idService) {
return varBag.errorFromJSONVar.value;
}
},
"F_uF9V7K3kWLvftBdac0cQ": {
getter: function (varBag, idService) {
return varBag.model.variables.objVar;
},
dataType: OS.DataTypes.DataTypes.Object
},
"5+hm0M_TQEG4L0+2Oia4AQ": {
getter: function (varBag, idService) {
return varBag.model.variables.propertiesVar;
}
},
"abOXiikaLkKmu+spMxN8PA": {
getter: function (varBag, idService) {
return varBag.model.variables.extendedClassIn;
},
dataType: OS.DataTypes.DataTypes.Text
},
"+Y5XTwrLpkiZCtxYcUFz1w": {
getter: function (varBag, idService) {
return varBag.model.variables.getLicenseDataAct;
}
},
"qnVtbx82wk++aIHJdDuzTg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Element"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
