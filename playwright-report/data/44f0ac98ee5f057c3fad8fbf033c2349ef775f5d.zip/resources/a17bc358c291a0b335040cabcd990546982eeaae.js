class scanPassport {
  constructor(id, properties, events) {
    this.class = 'scan-passport';
    this.element = document.getElementById(id);
    this.properties = properties;
    this.events = events;
    this.listeners = {
      _load: this._load.bind(this),
      _result: this._result.bind(this),
      _error: this._error.bind(this)
    };
    this.anylineObj = null;
    this.destroyed = false;
    this._build();
  }
  _formatDate(dt) {
    if (dt) {
      let formattedDate = new Date(`${dt.substring(2, 4)}/${dt.substring(4, 6)}/${dt.substring(0, 2)}`);
      return formattedDate;
    } else {
      return '';
    }
  }
  _load() {
    if (!this.destroyed) {
      this.events.load();
    }

  }
  _error(data) {
    if (!this.destroyed) {
      this.events.error(JSON.stringify(data));
    }
  }
  _result(data) {
    if (!this.destroyed) {
      var dataObj = data.result.mrzResult;
      //Only passport document type supported
      if (dataObj.documentType[0] === 'P') {
        dataObj.dateOfBirth = this._formatDate(dataObj.dateOfBirth);
        dataObj.dateOfExpiry = this._formatDate(dataObj.dateOfExpiry);
        this.events.result(JSON.stringify(dataObj));
      } else {
        this._error({
          code: '0',
          message: 'Invalid document'
        });
      }
    }

  }
  _setData() {
    let data = {
      preset: 'universalid_mrz',
      config: {
        cancelOnResult: false
      },
      viewConfig: {
        cutouts: [{
          cutoutConfig: {
            strokeWidth: 4,
            cornerRadius: 8,
            strokeColor: 'FFFFFF',
            feedbackStrokeColor: 'FFFFFF'
          },
          scanFeedback: {
            style: 'contour_point',
            strokeColor: 'FFFFFF',
            fillColor: 'FFFFFF',
            strokeWidth: 1,
            cornerRadius: 8,
            vibrateOnResult: true
          },
        }],
      },
      license: this.properties.license,
      element: this.element,
      mirrorOnDesktop: false,
      loadingScreen: '<div data-container="" class="custom-loading"><div data-container="" class="custom-loading__content"><div data-container="" class="custom-loading__loading"><div data-container="" class="custom-loading__loading-item"><div data-container="" class="custom-loading__loading-item-bubble"></div></div><div data-container="" class="custom-loading__loading-item"><div data-container="" class="custom-loading__loading-item-bubble"></div></div><div data-container="" class="custom-loading__loading-item"><div data-container="" class="custom-loading__loading-item-bubble"></div></div><div data-container="" class="custom-loading__loading-item"><div data-container="" class="custom-loading__loading-item-bubble"></div></div><div data-container="" class="custom-loading__loading-item"><div data-container="" class="custom-loading__loading-item-bubble"></div></div><div data-container="" class="custom-loading__loading-item"><div data-container="" class="custom-loading__loading-item-bubble"></div></div><div data-container="" class="custom-loading__loading-item"><div data-container="" class="custom-loading__loading-item-bubble"></div></div><div data-container="" class="custom-loading__loading-item"><div data-container="" class="custom-loading__loading-item-bubble"></div></div></div></div></div>'
    };
    return data;
  }
  destroy() {
    if (this.anylineObj && this.anylineObj.state === "scanning") {
      this.destroyed = true;
      this.anylineObj.stopScanning();
    }
  }
  _build() {
    this.anylineObj = anylinejs.init(this._setData());
    this.anylineObj.onLoad = this.listeners._load;
    this.anylineObj.onResult = this.listeners._result;
    this.anylineObj.onError = this.listeners._error;
    this.anylineObj.startScanning().catch((data) => { });
  }
}