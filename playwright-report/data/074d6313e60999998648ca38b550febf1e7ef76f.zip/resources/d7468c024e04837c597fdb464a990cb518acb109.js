define("ShopperPortalEU.Authentication.VerifyIdentityCode.mvc$model", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Theme.controller", "ShopperPortalEU.controller", "Auth_Europe.controller", "ShopperPortalEU_UI_Components.controller", "ShopperPortalEU.Layouts.LayoutDetail.mvc$model", "ShopperPortalEU.LayoutsComponents.Back.mvc$model", "ShopperPortalEU.Common.DataLoading.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.FullHeightContent.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.Flex.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomIcon.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomLink.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomLinkItem.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CodeInput.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomAlert.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomLoading.mvc$model", "ShopperPortalEU_UI_Theme.model$LayoutDetailOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU_UI_Components.model$FullHeightContentOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$FullHeightContentTopOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentBottomOptionsRec", "ShopperPortalEU_UI_Components.model$FlexOptionsRec", "ShopperPortalEU_UI_Components.model$CustomIconOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsIconRec", "ShopperPortalEU_UI_Components.model$CodeInputOptionsRec", "ShopperPortalEU_UI_Components.model$CodeInputValidationOptionsRec", "ShopperPortalEU_UI_Components.model$CustomAlertOptionsRec", "ShopperPortalEU_UI_Components.model$CustomAlertIconOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLoadingOptionsRec", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", "ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger", "ShopperPortalEU.controller$ClarityEvent", "Auth_Europe.controller$SendCode", "ShopperPortalEU.referencesHealth$Auth_Europe", "Auth_Europe.controller$VerifyCode", "ShopperPortalEU_UI_Theme.model$CustomMessageIconOptionsRec", "ShopperPortalEU_UI_Components.model$GetOSRec", "ShopperPortalEU_UI_Components.controller$GetOS"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ThemeController, ShopperPortalEUController, Auth_EuropeController, ShopperPortalEU_UI_ComponentsController, ShopperPortalEU_Layouts_LayoutDetail_mvcModel, ShopperPortalEU_LayoutsComponents_Back_mvcModel, ShopperPortalEU_Common_DataLoading_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomIcon_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLink_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLinkItem_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CodeInput_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomAlert_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLoading_mvcModel) {
var OS = OutSystems.Internal;

var GetAuthInfoAndSitePropertiesDataActRec = (function (_super) {
__extends(GetAuthInfoAndSitePropertiesDataActRec, _super);
function GetAuthInfoAndSitePropertiesDataActRec(defaults) {
_super.apply(this, arguments);
}
GetAuthInfoAndSitePropertiesDataActRec.attributesToDeclare = function () {
return [
this.attr("ResendCodeCountdownTime", "resendCodeCountdownTimeOut", "ResendCodeCountdownTime", true, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, true), 
this.attr("MaskedEmail", "maskedEmailOut", "MaskedEmail", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
GetAuthInfoAndSitePropertiesDataActRec.init();
return GetAuthInfoAndSitePropertiesDataActRec;
})(OS.Model.DataSourceRecord);

var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("CodeToVerify", "codeToVerifyVar", "CodeToVerify", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, false), 
this.attr("IsVerifingCode", "isVerifingCodeVar", "IsVerifingCode", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("ShowResendLink", "showResendLinkVar", "ShowResendLink", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("ResendCodeTime", "resendCodeTimeVar", "ResendCodeTime", true, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, false), 
this.attr("TimeToResend", "timeToResendVar", "TimeToResend", true, false, OS.DataTypes.DataTypes.Integer, function () {
return 0;
}, false), 
this.attr("IsCodeInvalid", "isCodeInvalidVar", "IsCodeInvalid", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("IsCodeExpired", "isCodeExpiredVar", "IsCodeExpired", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("GetAuthInfoAndSiteProperties", "getAuthInfoAndSitePropertiesDataAct", "getAuthInfoAndSitePropertiesDataAct", true, true, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new GetAuthInfoAndSitePropertiesDataActRec());
}, true, GetAuthInfoAndSitePropertiesDataActRec)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Model._hasValidationWidgetsValue = undefined;
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
if((Model._hasValidationWidgetsValue === undefined)) {
Model._hasValidationWidgetsValue = ((((((((((ShopperPortalEU_Layouts_LayoutDetail_mvcModel.hasValidationWidgets || ShopperPortalEU_LayoutsComponents_Back_mvcModel.hasValidationWidgets) || ShopperPortalEU_Common_DataLoading_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomIcon_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLink_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLinkItem_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CodeInput_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomAlert_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLoading_mvcModel.hasValidationWidgets);
}

return Model._hasValidationWidgetsValue;
}
});

Model.prototype.setInputs = function (inputs) {
};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "Authentication.VerifyIdentityCode");
});
define("ShopperPortalEU.Authentication.VerifyIdentityCode.mvc$view", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Theme.controller", "Auth_Europe.controller", "ShopperPortalEU_UI_Components.controller", "react", "OutSystems/ReactView/Main", "ShopperPortalEU.Authentication.VerifyIdentityCode.mvc$model", "ShopperPortalEU.Authentication.VerifyIdentityCode.mvc$controller", "ShopperPortalEU.clientVariables", "ShopperPortalEU.Layouts.LayoutDetail.mvc$view", "OutSystems/ReactWidgets/Main", "ShopperPortalEU.LayoutsComponents.Back.mvc$view", "ShopperPortalEU.Common.DataLoading.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.FullHeightContent.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.Flex.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomIcon.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomLink.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomLinkItem.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CodeInput.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomAlert.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomLoading.mvc$view", "ShopperPortalEU_UI_Theme.model$LayoutDetailOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU_UI_Components.model$FullHeightContentOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$FullHeightContentTopOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentBottomOptionsRec", "ShopperPortalEU_UI_Components.model$FlexOptionsRec", "ShopperPortalEU_UI_Components.model$CustomIconOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsIconRec", "ShopperPortalEU_UI_Components.model$CodeInputOptionsRec", "ShopperPortalEU_UI_Components.model$CodeInputValidationOptionsRec", "ShopperPortalEU_UI_Components.model$CustomAlertOptionsRec", "ShopperPortalEU_UI_Components.model$CustomAlertIconOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLoadingOptionsRec", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", "ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger", "ShopperPortalEU.controller$ClarityEvent", "Auth_Europe.controller$SendCode", "ShopperPortalEU.referencesHealth$Auth_Europe", "Auth_Europe.controller$VerifyCode", "ShopperPortalEU_UI_Theme.model$CustomMessageIconOptionsRec", "ShopperPortalEU_UI_Components.model$GetOSRec", "ShopperPortalEU_UI_Components.controller$GetOS"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ThemeController, Auth_EuropeController, ShopperPortalEU_UI_ComponentsController, React, OSView, ShopperPortalEU_Authentication_VerifyIdentityCode_mvc_model, ShopperPortalEU_Authentication_VerifyIdentityCode_mvc_controller, ShopperPortalEUClientVariables, ShopperPortalEU_Layouts_LayoutDetail_mvc_view, OSWidgets, ShopperPortalEU_LayoutsComponents_Back_mvc_view, ShopperPortalEU_Common_DataLoading_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomIcon_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLink_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLinkItem_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CodeInput_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomAlert_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLoading_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            var thisIsInstanceOfSuper = this instanceof _super;
            if (thisIsInstanceOfSuper == false) {
                return;
            }

            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "Authentication.VerifyIdentityCode";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css", "css/ShopperPortalEU_UI_Theme.ShopperPortalEUUITheme.css", "css/ShopperPortalEU.ShopperPortalEU.css", "css/ShopperPortalEU_UI_Theme.ShopperPortalEUUITheme.extra.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [ShopperPortalEU_Layouts_LayoutDetail_mvc_view, ShopperPortalEU_LayoutsComponents_Back_mvc_view, ShopperPortalEU_Common_DataLoading_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomIcon_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLink_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLinkItem_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CodeInput_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomAlert_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLoading_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return ShopperPortalEU_Authentication_VerifyIdentityCode_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return ShopperPortalEU_Authentication_VerifyIdentityCode_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "Shopper Portal EU - Verify Identity Code";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(ShopperPortalEU_Layouts_LayoutDetail_mvc_view, {
inputs: {
Auth: model.getCachedValue(idService.getId("bnjqR458O0SI7Wvc8FdzrQ.Auth"), function () {
return function () {
var rec = new ShopperPortalEUModel.LayoutAuthenticationRec();
rec.isToUseAuthAttr = false;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "0",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
headerLeft: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_LayoutsComponents_Back_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "1",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}),
headerCenter: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_Common_DataLoading_mvc_view, {
inputs: {
IsDataFetched: model.variables.getAuthInfoAndSitePropertiesDataAct.isDataFetchedAttr
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "2",
alias: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "VerifyPhoneEmailScreen"
},
value: model.getCachedValue(idService.getId("8zphojblBkmss69gqNt9iA.Value"), function () {
return ("Verify your " + ((model.variables.getAuthInfoAndSitePropertiesDataAct.isDataFetchedAttr) ? ("email") : ("")));
}, function () {
return model.variables.getAuthInfoAndSitePropertiesDataAct.isDataFetchedAttr;
}),
_idProps: {
service: idService,
uuid: "3"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.getAuthInfoAndSitePropertiesDataAct.isDataFetchedAttr)]
})];
}),
headerRight: PlaceholderContent.Empty,
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_Common_DataLoading_mvc_view, {
inputs: {
IsDataFetched: model.variables.getAuthInfoAndSitePropertiesDataAct.isDataFetchedAttr
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "4",
alias: "4"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("7SBT+Y0a50y1uVoBcW15xw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FullHeightContentOptionsRec();
rec.bottomAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FullHeightContentBottomOptionsRec();
rec.horizontalAlignmentAttr = ShopperPortalEUModel.staticEntities.fullHeightContentAlignment.center;
return rec;
}();
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "5",
alias: "5"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
top: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("kajSLz7LykWNI3CF6LmGqA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.alignAttr = ShopperPortalEUModel.staticEntities.flexAlign.center;
rec.directionAttr = ShopperPortalEUModel.staticEntities.flexDirection.column;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space5;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "6",
alias: "6"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "7"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
ExtendedClass: "text-align-center",
Options: model.getCachedValue(idService.getId("QLhlSnvNK0OAwHT9yBbhGw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.alignAttr = ShopperPortalEUModel.staticEntities.flexAlign.center;
rec.justifyAttr = ShopperPortalEUModel.staticEntities.flexJustify.center;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space1;
rec.wrapAttr = true;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "8",
alias: "7"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomIcon_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("kqRi_TiQJ026BIEfL3t7NA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomIconOptionsRec();
rec.nameAttr = "email";
rec.sizeAttr = ShopperPortalEUModel.staticEntities.customIconSize.extraSmall;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "9",
alias: "8"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "body-3 text-primary-black",
visible: true,
_idProps: {
service: idService,
uuid: "10"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "EmailPhoneLabel"
},
value: ("Enter the code we sent to " + model.variables.getAuthInfoAndSitePropertiesDataAct.maskedEmailOut),
_idProps: {
service: idService,
uuid: "11"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getAuthInfoAndSitePropertiesDataAct.dataFetchStatusAttr)
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables.getAuthInfoAndSitePropertiesDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.getAuthInfoAndSitePropertiesDataAct.maskedEmailOut)]
}), $if(((OS.BuiltinFunctions.index(model.variables.getAuthInfoAndSitePropertiesDataAct.maskedEmailOut, "gmail", 0, false, false)) !== (-1)), false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-top-02 text-align-center body-3",
visible: true,
_idProps: {
service: idService,
name: "OpenEmail_ctn"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLink_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("3DjeNSyy+0+K3bgs9ZPrPw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomLinkOptionsRec();
rec.testIdAttr = "gmail_Link-id";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "13",
alias: "9"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
link: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Link, {
enabled: true,
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Authentication/VerifyIdentityCode/Link OnClick");
controller.gmailLinkOnClick$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
visible: true,
_idProps: {
service: idService,
uuid: "14"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLinkItem_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("VtI9GCtKMk20SJ60obBhqA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomLinkItemOptionsRec();
rec.iconAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomLinkOptionsIconRec();
rec.nameAttr = "open_in_new";
rec.alignmentAttr = ShopperPortalEUModel.staticEntities.customLinkIconAlignment.right;
return rec;
}();
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "15",
alias: "10"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Open Gmail",
_idProps: {
service: idService,
uuid: "16"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
}))];
}, function () {
return [];
})), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CodeInput_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("9HvTQBuV2UORatl7fqVA1Q.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CodeInputOptionsRec();
rec.testIdAttr = "codeinput-id";
rec.codeAttr = model.variables.codeToVerifyVar;
rec.focusOnStartAttr = true;
rec.validationAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CodeInputValidationOptionsRec();
rec.stateAttr = (((model.variables.isCodeInvalidVar || model.variables.isCodeExpiredVar)) ? (ShopperPortalEUModel.staticEntities.codeInputState.error) : (OS.BuiltinFunctions.nullTextIdentifier()));
rec.messageAttr = ((model.variables.isCodeInvalidVar) ? ("This code is not correct. Please try again.") : (((model.variables.isCodeExpiredVar) ? ("This code has expired") : (""))));
return rec;
}();
return rec;
}();
}, function () {
return model.variables.codeToVerifyVar;
}, function () {
return model.variables.isCodeInvalidVar;
}, function () {
return model.variables.isCodeExpiredVar;
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onChange$Action: function (currentCodeIn, isFilledIn) {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ShopperPortalEUUIComponents/CodeInput OnChange");
return controller.inputVerifyCodeOnChange$Action(currentCodeIn, isFilledIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "17",
alias: "11"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.isCodeExpiredVar), asPrimitiveValue(model.variables.isCodeInvalidVar), asPrimitiveValue(model.variables.codeToVerifyVar), asPrimitiveValue(model.variables.getAuthInfoAndSitePropertiesDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.getAuthInfoAndSitePropertiesDataAct.maskedEmailOut)]
}), $if(model.variables.isCodeInvalidVar, false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomAlert_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("ssTDsXCN3EqIZi4hpCIm3g.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomAlertOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customAlertType.neutral;
rec.iconAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomAlertIconOptionsRec();
rec.nameAttr = "support_agent";
return rec;
}();
return rec;
}();
}),
ExtendedClass: "margin-top-07"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "18",
alias: "12"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
title: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Are you still experiencing issues?",
_idProps: {
service: idService,
uuid: "19"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Have your passport ready and contact ",
_idProps: {
service: idService,
uuid: "20"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLink_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("UkSSrkEgw0OBzZ+TDzFVrA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomLinkOptionsRec();
rec.testIdAttr = "CustomerSupportLink-id";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "21",
alias: "13"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
link: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Link, {
enabled: true,
transition: OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default),
url: OS.Navigation.generateScreenURL("ShopperPortalEU", "Help", {}),
visible: true,
_idProps: {
service: idService,
uuid: "22"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLinkItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "23",
alias: "14"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Customer Support.",
_idProps: {
service: idService,
uuid: "24"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
})];
})
},
_dependencies: []
})];
}, function () {
return [];
}), $if(model.variables.isVerifingCodeVar, false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLoading_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("b1fqqxMEZkiYxfkk8jXZiQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomLoadingOptionsRec();
rec.showAttr = true;
rec.textAttr = "Verifying...";
rec.isFullScreenAttr = true;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "25",
alias: "15"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}, function () {
return [];
})];
}),
bottom: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
style: "text-align: center;"
},
style: "text-align-center body-3",
visible: true,
_idProps: {
service: idService,
uuid: "26"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "text-primary-35 margin-bottom-02",
visible: true,
_idProps: {
service: idService,
uuid: "27"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "TipEmail2"
},
value: "Didn\'t receive the code ? Check your email spam folder",
_idProps: {
service: idService,
uuid: "28"
},
_widgetRecordProvider: widgetsRecordProvider
})), $if(model.variables.showResendLinkVar, false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLink_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("nMyp7WlZZU+lkL0HHQ_JXA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomLinkOptionsRec();
rec.testIdAttr = "ResendCodeLink-id";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "29",
alias: "16"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
link: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Link, {
enabled: true,
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Authentication/VerifyIdentityCode/Link OnClick");
return controller.resendCodeOnClick$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
visible: true,
_idProps: {
service: idService,
uuid: "30"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomLinkItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "31",
alias: "17"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "32"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
value: "Resend code",
_idProps: {
service: idService,
uuid: "33"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
})];
}, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("Z+SZBTqxZkqKU4cxYDfgoQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.alignAttr = ShopperPortalEUModel.staticEntities.flexAlign.center;
rec.justifyAttr = ShopperPortalEUModel.staticEntities.flexJustify.center;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space1;
rec.wrapAttr = false;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "34",
alias: "18"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomIcon_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("wG0GE4oElkaGetbkvUrNgQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomIconOptionsRec();
rec.nameAttr = "timer";
rec.sizeAttr = ShopperPortalEUModel.staticEntities.customIconSize.extraSmall;
rec.colorAttr = "var(--color-primary-55)";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "35",
alias: "19"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "text-primary-55",
visible: true,
_idProps: {
service: idService,
uuid: "36"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
value: "Resend code in ",
_idProps: {
service: idService,
uuid: "37"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Expression, {
style: "font-bold",
value: ((model.variables.timeToResendVar).toString() + "s"),
_idProps: {
service: idService,
uuid: "38"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables.timeToResendVar)]
})];
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables.timeToResendVar), asPrimitiveValue(model.variables.showResendLinkVar), asPrimitiveValue(model.variables.isVerifingCodeVar), asPrimitiveValue(model.variables.isCodeExpiredVar), asPrimitiveValue(model.variables.isCodeInvalidVar), asPrimitiveValue(model.variables.codeToVerifyVar), asPrimitiveValue(model.variables.getAuthInfoAndSitePropertiesDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.getAuthInfoAndSitePropertiesDataAct.maskedEmailOut)]
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.timeToResendVar), asPrimitiveValue(model.variables.showResendLinkVar), asPrimitiveValue(model.variables.isVerifingCodeVar), asPrimitiveValue(model.variables.isCodeExpiredVar), asPrimitiveValue(model.variables.isCodeInvalidVar), asPrimitiveValue(model.variables.codeToVerifyVar), asPrimitiveValue(model.variables.getAuthInfoAndSitePropertiesDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.getAuthInfoAndSitePropertiesDataAct.maskedEmailOut)]
})];
}),
bottom: PlaceholderContent.Empty
},
_dependencies: [asPrimitiveValue(model.variables.timeToResendVar), asPrimitiveValue(model.variables.showResendLinkVar), asPrimitiveValue(model.variables.isVerifingCodeVar), asPrimitiveValue(model.variables.isCodeExpiredVar), asPrimitiveValue(model.variables.isCodeInvalidVar), asPrimitiveValue(model.variables.codeToVerifyVar), asPrimitiveValue(model.variables.getAuthInfoAndSitePropertiesDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.getAuthInfoAndSitePropertiesDataAct.maskedEmailOut), asPrimitiveValue(model.variables.getAuthInfoAndSitePropertiesDataAct.isDataFetchedAttr)]
}));
        };
        return View;
    })(OSView.BaseView.BaseWebScreen);
	
    return View;
});
define("ShopperPortalEU.Authentication.VerifyIdentityCode.mvc$controller", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Theme.controller", "Auth_Europe.controller", "ShopperPortalEU_UI_Components.controller", "ShopperPortalEU.languageResources", "ShopperPortalEU.clientVariables", "ShopperPortalEU.Authentication.VerifyIdentityCode.mvc$debugger", "ShopperPortalEU.Authentication.controller", "ShopperPortalEU.Authentication.VerifyIdentityCode.mvc$controller.GmailLinkOnClick.RedirectToURLJS", "ShopperPortalEU.Authentication.VerifyIdentityCode.mvc$controller.OnInitialize.SmsOTPAPIJS", "ShopperPortalEU.Authentication.VerifyIdentityCode.mvc$controller.StartCountdown_ResendCode.StartCountDownTimerJS", "ShopperPortalEU.Authentication.VerifyIdentityCode.mvc$controller.StopCountdown_ResendCode.stopResendTimerJS", "ShopperPortalEU_UI_Theme.model$LayoutDetailOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU_UI_Components.model$FullHeightContentOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$FullHeightContentTopOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentBottomOptionsRec", "ShopperPortalEU_UI_Components.model$FlexOptionsRec", "ShopperPortalEU_UI_Components.model$CustomIconOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLinkOptionsIconRec", "ShopperPortalEU_UI_Components.model$CodeInputOptionsRec", "ShopperPortalEU_UI_Components.model$CodeInputValidationOptionsRec", "ShopperPortalEU_UI_Components.model$CustomAlertOptionsRec", "ShopperPortalEU_UI_Components.model$CustomAlertIconOptionsRec", "ShopperPortalEU_UI_Components.model$CustomLoadingOptionsRec", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", "ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger", "ShopperPortalEU.controller$ClarityEvent", "Auth_Europe.controller$SendCode", "ShopperPortalEU.referencesHealth$Auth_Europe", "Auth_Europe.controller$VerifyCode", "ShopperPortalEU_UI_Theme.model$CustomMessageIconOptionsRec", "ShopperPortalEU_UI_Components.model$GetOSRec", "ShopperPortalEU_UI_Components.controller$GetOS"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ThemeController, Auth_EuropeController, ShopperPortalEU_UI_ComponentsController, ShopperPortalEULanguageResources, ShopperPortalEUClientVariables, ShopperPortalEU_Authentication_VerifyIdentityCode_mvc_Debugger, ShopperPortalEU_AuthenticationController, ShopperPortalEU_Authentication_VerifyIdentityCode_mvc_controller_GmailLinkOnClick_RedirectToURLJS, ShopperPortalEU_Authentication_VerifyIdentityCode_mvc_controller_OnInitialize_SmsOTPAPIJS, ShopperPortalEU_Authentication_VerifyIdentityCode_mvc_controller_StartCountdown_ResendCode_StartCountDownTimerJS, ShopperPortalEU_Authentication_VerifyIdentityCode_mvc_controller_StopCountdown_ResendCode_stopResendTimerJS) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {
onCodeSubmitted$Action: function (oTPCodeIn) {
oTPCodeIn = (oTPCodeIn === undefined) ? "" : oTPCodeIn;
return controller.executeActionInsideJSNode(controller._onCodeSubmitted$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(oTPCodeIn, OS.DataTypes.DataTypes.Text)), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "OnCodeSubmitted");
},
onError$Action: function (errorMessageIn) {
errorMessageIn = (errorMessageIn === undefined) ? "" : errorMessageIn;
return controller.executeActionInsideJSNode(controller._onError$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(errorMessageIn, OS.DataTypes.DataTypes.Text)), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "OnError");
},
timerResend_OnElapsed$Action: function () {
return controller.executeActionInsideJSNode(controller._timerResend_OnElapsed$Action.bind(controller), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "TimerResend_OnElapsed");
},
timerResend_Update$Action: function (secondsLeftIn) {
secondsLeftIn = (secondsLeftIn === undefined) ? 0 : secondsLeftIn;
return controller.executeActionInsideJSNode(controller._timerResend_Update$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(secondsLeftIn, OS.DataTypes.DataTypes.Integer)), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "TimerResend_Update");
}
};
this.dataFetchDependenciesOriginal = {
getAuthInfoAndSiteProperties$DataActRefresh: 0
};
this.dataFetchDependentsGraph = {
getAuthInfoAndSiteProperties$DataActRefresh: []
};
this.shouldSendClientVarsToDataSources = true;
}
// Server Actions

// Aggregates and Data Actions
Controller.prototype.getAuthInfoAndSiteProperties$DataActRefresh = function (callContext) {
var model = this.model;
var controller = this.controller;
var callContext = controller.callContext(callContext);
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:Zfx8iPpVsUihP3ccNA6GVA:/NRWebFlows.ozCJCRi2BU2OkqD4Zl84lQ/NodesShownInESpaceTree.b88Y+d17p0CuMa2uuNNQMQ/DataActions.Zfx8iPpVsUihP3ccNA6GVA:33dWVPqk+Bo44vTCzZGvww", "ShopperPortalEU", "GetAuthInfoAndSiteProperties", "NRFlows.DataScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.setThreadStartName(callContext.id, "Authentication/VerifyIdentityCode/GetAuthInfoAndSiteProperties");
return controller.callDataAction("DataActionGetAuthInfoAndSiteProperties", "screenservices/ShopperPortalEU/Authentication/VerifyIdentityCode/DataActionGetAuthInfoAndSiteProperties", "GNtq8HyVbydX7Zocyv_8Pg", function (b) {
model.variables.getAuthInfoAndSitePropertiesDataAct.dataFetchStatusAttr = b;
}, function (json) {
model.variables.getAuthInfoAndSitePropertiesDataAct.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getAuthInfoAndSitePropertiesDataAct.constructor));
}, undefined, OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, callContext, ShopperPortalEUClientVariables, false).then(function () {
OutSystemsDebugger.setThreadStartName(callContext.id, "Authentication/VerifyIdentityCode/GetAuthInfoAndSiteProperties On After Fetch");
controller._onAfterFetch$Action(controller.callContext(callContext));

});

}, function () {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:Zfx8iPpVsUihP3ccNA6GVA", callContext.id);
controller.popDebuggerContext(callContext);

});
};

Controller.prototype.dataFetchActionNames = ["getAuthInfoAndSiteProperties$DataActRefresh"];
// Client Actions
Controller.prototype._onDestroy$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnDestroy");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:E4eoGPXYxka3yyjTUx6Gqw:/NRWebFlows.ozCJCRi2BU2OkqD4Zl84lQ/NodesShownInESpaceTree.b88Y+d17p0CuMa2uuNNQMQ/ClientActions.E4eoGPXYxka3yyjTUx6Gqw:4aeVsBLoWb7nGmZIxWcw5g", "ShopperPortalEU", "OnDestroy", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:5Cr0eaFPik+xvDvVVmjJgw", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:U3YGRCplQUy0Wo+7dp_XKw", callContext.id);
// Execute Action: StopCountdown_ResendCode
controller._stopCountdown_ResendCode$Action(callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:2R8s6BwlXkGP3NTdn+LOww", callContext.id);
// ResendCodeSeconds = -1
ShopperPortalEUClientVariables.setResendCodeSeconds(-1);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:07scAFDrDEesk0Uf9oqVRA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:E4eoGPXYxka3yyjTUx6Gqw", callContext.id);
}

};
Controller.prototype._onAfterFetch$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnAfterFetch");
callContext = controller.callContext(callContext);
var allExceptionsVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.ErrorHandlerOutputType());
varBag.callContext = callContext;
varBag.allExceptionsVar = allExceptionsVar;
try {try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:8HBYGUiY3EiNvHyAu8Dlpg:/NRWebFlows.ozCJCRi2BU2OkqD4Zl84lQ/NodesShownInESpaceTree.b88Y+d17p0CuMa2uuNNQMQ/ClientActions.8HBYGUiY3EiNvHyAu8Dlpg:n7xg+q75_7+gjwysuZ5u_w", "ShopperPortalEU", "OnAfterFetch", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:miTenoC0o0OqaB7DLyy96w", callContext.id);
// MaskedPhoneEmail  not empty ?
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:9vFqtuNuW0OCpfH3FSjR8g", callContext.id) && ((model.variables.getAuthInfoAndSitePropertiesDataAct.maskedEmailOut) !== ("")))) {
// TimeToResend & ShowResendLink
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:tD1Eyp4dF0KUDVAuuVpPtA", callContext.id);
// TimeToResend = If
model.variables.timeToResendVar = (((ShopperPortalEUClientVariables.getResendCodeSeconds() === -1)) ? (model.variables.getAuthInfoAndSitePropertiesDataAct.resendCodeCountdownTimeOut) : (ShopperPortalEUClientVariables.getResendCodeSeconds()));
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:tD1Eyp4dF0KUDVAuuVpPtA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// ShowResendLink = TimeToResend < 1
model.variables.showResendLinkVar = (model.variables.timeToResendVar < 1);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:qQ+1Mnm17U+c7VbRWmAj6A", callContext.id);
// Execute Action: StartCountdown_ResendCode
controller._startCountdown_ResendCode$Action(model.variables.getAuthInfoAndSitePropertiesDataAct.resendCodeCountdownTimeOut, callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:tWQ95_62xE2LTTvMipqx4w", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:SUzzWoj5r0qoTaAhodgrFg", callContext.id);
// Destination: /ShopperPortalEU/VerifyIdentity
return OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "VerifyIdentity", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true);
}

} catch (ex) {
(function () {
OS.Logger.trace("VerifyIdentityCode.OnAfterFetch", OS.Exceptions.getMessage(ex), ex.name);
// Handle Error: AllExceptions
if(!(OS.Exceptions.isSystem(ex))) {
OS.Logger.error(null, ex);
allExceptionsVar.value.exceptionMessageAttr = OS.Exceptions.getMessage(ex);
OutSystemsDebugger.handleException(allExceptionsVar.value.exceptionMessageAttr, callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:CXQESkzfEkasHIHJLPv_dg", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:0vNA_xRTW0ufotqYCiBMCA", callContext.id);
// Execute Action: CustomMessageTrigger
ShopperPortalEU_UI_ThemeController.default.customMessageTrigger$Action(function () {
var rec = new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customMessageType.error;
rec.contentAttr = allExceptionsVar.value.exceptionMessageAttr;
rec.testIdAttr = "ErrorAuth";
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:PCPRRH0yXU2RzJ8YNZuYfQ", callContext.id);
return ;

}

throw ex;
})();
}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:8HBYGUiY3EiNvHyAu8Dlpg", callContext.id);
}

};
Controller.prototype._inputVerifyCodeOnChange$Action = function (currentCodeIn, isFilledIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("InputVerifyCodeOnChange");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.Authentication.VerifyIdentityCode.InputVerifyCodeOnChange$vars"))());
vars.value.currentCodeInLocal = currentCodeIn;
vars.value.isFilledInLocal = isFilledIn;
var sendCodeVar = new OS.DataTypes.VariableHolder();
var verifyCodeVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.vars = vars;
varBag.sendCodeVar = sendCodeVar;
varBag.verifyCodeVar = verifyCodeVar;
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:4Ru4HyIgEka7ahaTMxPHcw:/NRWebFlows.ozCJCRi2BU2OkqD4Zl84lQ/NodesShownInESpaceTree.b88Y+d17p0CuMa2uuNNQMQ/ClientActions.4Ru4HyIgEka7ahaTMxPHcw:QzBwcwStmwImLJAnDpvTKw", "ShopperPortalEU", "InputVerifyCodeOnChange", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:9AR_cANNEku9CVOgL6Fmbg", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
// SetVariables
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:5zBWdzSWm0GyU8EEwX4I2A", callContext.id);
// CodeToVerify = CurrentCode
model.variables.codeToVerifyVar = vars.value.currentCodeInLocal;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:5zBWdzSWm0GyU8EEwX4I2A", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// IsCodeExpired = False
model.variables.isCodeExpiredVar = false;
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:6N1DTjV+mkee_TMnzLr1Ig", callContext.id) && vars.value.isFilledInLocal)) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:6w1KlhCDdk6VgBe4c8ZImg", callContext.id);
// IsVerifingCode = True
model.variables.isVerifingCodeVar = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:6w1KlhCDdk6VgBe4c8ZImg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// IsCodeInvalid = False
model.variables.isCodeInvalidVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:rY+ni9_n+0Km0Z4kJY64SA", callContext.id);
// Execute Action: ClarityEvent
ShopperPortalEUController.default.clarityEvent$Action("VerificationCodeFilled", callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:jnRk_Naq00OzgEI78bB98A", callContext.id);
// Execute Action: VerifyCode
model.flush();
return Auth_EuropeController.default.verifyCode$Action(ShopperPortalEUClientVariables.getEmail(), true, model.variables.codeToVerifyVar, callContext).then(function (value) {
verifyCodeVar.value = value;
}).then(function () {
// IsAuthenticated
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:hAKicRsEd0KVaCruLrt1Wg", callContext.id) && verifyCodeVar.value.isAuthenticatedOut)) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:qd0sYULjtEGMJkFzbvMFzg", callContext.id);
} else {
// IsInvalid code
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:dCPS+VocCUSenYmeGylGSA", callContext.id) && (OS.BuiltinFunctions.index(verifyCodeVar.value.errorMessageOut, "expire", 0, false, false) === -1))) {
// ResetLocalVars
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:2PttT52v+0urvdkZeHqXzg", callContext.id);
// IsVerifingCode = False
model.variables.isVerifingCodeVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:2PttT52v+0urvdkZeHqXzg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// IsCodeInvalid = True
model.variables.isCodeInvalidVar = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:SxAo7RT3vUmYuC9MmpA9Jw", callContext.id);
// Execute Action: InvalidCodeEvent
ShopperPortalEUController.default.clarityEvent$Action("VerificationCodeInvalid", callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:y+xjLeWYJ0iH9SpaM1mQfw", callContext.id);
} else {
// Update flags
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:r5MVOc01REeTMGypf5v91w", callContext.id);
// IsCodeExpired = True
model.variables.isCodeExpiredVar = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:r5MVOc01REeTMGypf5v91w", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// IsVerifingCode = False
model.variables.isVerifingCodeVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:r5MVOc01REeTMGypf5v91w", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// ShowResendLink = False
model.variables.showResendLinkVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:qZPm16sQD0iszXLvnYL0Bg", callContext.id);
// Execute Action: CustomMessageTrigger
ShopperPortalEU_UI_ThemeController.default.customMessageTrigger$Action(function () {
var rec = new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customMessageType.neutral;
rec.titleAttr = "We\'ve sent you another code";
rec.iconAttr = function () {
var rec = new ShopperPortalEU_UI_ThemeModel.CustomMessageIconOptionsRec();
rec.nameAttr = "mail";
rec.isFilledAttr = true;
return rec;
}();
rec.testIdAttr = "inputCodeMessage-id";
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:SZ1dU5TbmkC_ZGI_RtUHEw", callContext.id);
// Execute Action: StopCountdown_ResendCode
controller._stopCountdown_ResendCode$Action(callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:KwUQu9Ie4U2ZhGDaqOUFig", callContext.id);
// Execute Action: SendCode
model.flush();
return Auth_EuropeController.default.sendCode$Action(ShopperPortalEUClientVariables.getEmail(), true, callContext).then(function (value) {
sendCodeVar.value = value;
}).then(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:N5dJhde3GUeRJgbNvifArA", callContext.id);
// Execute Action: StartCountdown_ResendCode
controller._startCountdown_ResendCode$Action(model.variables.getAuthInfoAndSitePropertiesDataAct.resendCodeCountdownTimeOut, callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:tM+MWVl0+EOonKOWe8mDbg", callContext.id);
});
}

});
}

});
});
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:7LY7uSsS30+FfD49ehpSKA", callContext.id);
// IsCodeInvalid = False
model.variables.isCodeInvalidVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:tJ5TVUeTLEKjz4NnuQiMWg", callContext.id);
}

});
}).then(function (res) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:4Ru4HyIgEka7ahaTMxPHcw", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:4Ru4HyIgEka7ahaTMxPHcw", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("ShopperPortalEU.Authentication.VerifyIdentityCode.InputVerifyCodeOnChange$vars", [{
name: "CurrentCode",
attrName: "currentCodeInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}, {
name: "IsFilled",
attrName: "isFilledInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Boolean,
defaultValue: function () {
return false;
}
}]);
Controller.prototype._resendCodeOnClick$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("ResendCodeOnClick");
callContext = controller.callContext(callContext);
var sendCodeVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.sendCodeVar = sendCodeVar;
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:_wVYR16ZwU6zWo5t2OUjOg:/NRWebFlows.ozCJCRi2BU2OkqD4Zl84lQ/NodesShownInESpaceTree.b88Y+d17p0CuMa2uuNNQMQ/ClientActions._wVYR16ZwU6zWo5t2OUjOg:hFVk4qxRExGleBUPKAtGHQ", "ShopperPortalEU", "ResendCodeOnClick", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:qeIK5DohH0KS9nRMcHrvtw", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:GhEZzPdBp0+Obbz+d50Hsw", callContext.id);
// Execute Action: StopCountdown_ResendCode
controller._stopCountdown_ResendCode$Action(callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Rf+lqCWVhEmqdpWXQGVbVQ", callContext.id);
// Execute Action: SendCode
model.flush();
return Auth_EuropeController.default.sendCode$Action(ShopperPortalEUClientVariables.getEmail(), true, callContext).then(function (value) {
sendCodeVar.value = value;
}).then(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:g+wQl3JRBk+861xPqit3EQ", callContext.id);
// Execute Action: CustomMessageTrigger
ShopperPortalEU_UI_ThemeController.default.customMessageTrigger$Action(function () {
var rec = new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customMessageType.success;
rec.contentAttr = "New code sent";
rec.testIdAttr = "ResendCodeMessage-id";
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:uVA0s_1mlEm_NgvG4QFiQw", callContext.id);
// Execute Action: StartCountdown_ResendCode
controller._startCountdown_ResendCode$Action(model.variables.getAuthInfoAndSitePropertiesDataAct.resendCodeCountdownTimeOut, callContext);
// ResetLocalVars
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ym+fXb5ZrEaUcMuLmFqnYA", callContext.id);
// CodeToVerify = ""
model.variables.codeToVerifyVar = "";
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ym+fXb5ZrEaUcMuLmFqnYA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// ShowResendLink = False
model.variables.showResendLinkVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ym+fXb5ZrEaUcMuLmFqnYA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// IsCodeInvalid = False
model.variables.isCodeInvalidVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:VJ+Ek9rL_0eqfp8U2iCQvA", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:_wVYR16ZwU6zWo5t2OUjOg", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:_wVYR16ZwU6zWo5t2OUjOg", callContext.id);
throw ex;

});
};
Controller.prototype._onError$Action = function (errorMessageIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnError");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.Authentication.VerifyIdentityCode.OnError$vars"))());
vars.value.errorMessageInLocal = errorMessageIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:y4nMXSns70y4RdEyHNZneA:/NRWebFlows.ozCJCRi2BU2OkqD4Zl84lQ/NodesShownInESpaceTree.b88Y+d17p0CuMa2uuNNQMQ/ClientActions.y4nMXSns70y4RdEyHNZneA:KJILkUiytxAbP7lwSWzkSA", "ShopperPortalEU", "OnError", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:OtNJwMi_I06DRZ840Q0kfg", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:1_6LF44FZUG9fwvE+sd1OA", callContext.id);
// Execute Action: LogMessage
OS.SystemActions.logMessage(("Error: " + vars.value.errorMessageInLocal), "SPEU_OTP", callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:sC+REJLGOkunmLxXi1JDCg", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:y4nMXSns70y4RdEyHNZneA", callContext.id);
}

};
Controller.registerVariableGroupType("ShopperPortalEU.Authentication.VerifyIdentityCode.OnError$vars", [{
name: "ErrorMessage",
attrName: "errorMessageInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
Controller.prototype._onCodeSubmitted$Action = function (oTPCodeIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnCodeSubmitted");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.Authentication.VerifyIdentityCode.OnCodeSubmitted$vars"))());
vars.value.oTPCodeInLocal = oTPCodeIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:oiz+YaQb90O3ZdVF9C8kjQ:/NRWebFlows.ozCJCRi2BU2OkqD4Zl84lQ/NodesShownInESpaceTree.b88Y+d17p0CuMa2uuNNQMQ/ClientActions.oiz+YaQb90O3ZdVF9C8kjQ:7u_uP4pFpJrTnQss1S0_dw", "ShopperPortalEU", "OnCodeSubmitted", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:G6ez+eVOyESj4NHy6G1Dfg", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:8fhuPNmTzUezyYZSBc1XYg", callContext.id);
// CodeToVerify = OTPCode
model.variables.codeToVerifyVar = vars.value.oTPCodeInLocal;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:rNyl+uZ4J0WIzzJN2e2y6Q", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:oiz+YaQb90O3ZdVF9C8kjQ", callContext.id);
}

};
Controller.registerVariableGroupType("ShopperPortalEU.Authentication.VerifyIdentityCode.OnCodeSubmitted$vars", [{
name: "OTPCode",
attrName: "oTPCodeInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Text,
defaultValue: function () {
return "";
}
}]);
Controller.prototype._gmailLinkOnClick$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("GmailLinkOnClick");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:V5YijMc4uEm8m453l1CbQg:/NRWebFlows.ozCJCRi2BU2OkqD4Zl84lQ/NodesShownInESpaceTree.b88Y+d17p0CuMa2uuNNQMQ/ClientActions.V5YijMc4uEm8m453l1CbQg:8v0upf9hEFF6RqcwB0PQvw", "ShopperPortalEU", "GmailLinkOnClick", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ylHKM55OYUSw0Z4Tb2GJnw", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:MUqwyUpwa0u_XYRP_P29Cw", callContext.id);
// Execute Action: ClarityEvent
ShopperPortalEUController.default.clarityEvent$Action("OpenGmail_link", callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Aex1VKcQHUeAFNRR9vsPcA", callContext.id);
controller.safeExecuteJSNode(ShopperPortalEU_Authentication_VerifyIdentityCode_mvc_controller_GmailLinkOnClick_RedirectToURLJS, "RedirectToURL", "GmailLinkOnClick", {
URL: OS.DataConversion.JSNodeParamConverter.to("https://gmail.com", OS.DataTypes.DataTypes.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:BvDpC90i4kKvNbLDAF9N0w", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:V5YijMc4uEm8m453l1CbQg", callContext.id);
}

};
Controller.prototype._onInitialize$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnInitialize");
callContext = controller.callContext(callContext);
var smsOTPAPIJSResult = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.smsOTPAPIJSResult = smsOTPAPIJSResult;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:zD+qlmnkU0aWUweP1NpsbQ:/NRWebFlows.ozCJCRi2BU2OkqD4Zl84lQ/NodesShownInESpaceTree.b88Y+d17p0CuMa2uuNNQMQ/ClientActions.zD+qlmnkU0aWUweP1NpsbQ:MjMKIBQVa+WzyF_qKKu6cA", "ShopperPortalEU", "OnInitialize", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:7uN5rdIbj0CKBwj8shOteQ", callContext.id);
// Android device ?
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Dhc6Z_zii0SU2P3SY3jyJQ", callContext.id) && (OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEU_UI_ComponentsController.default.getOS$Action(callContext).oSOut;
}, OS.DataTypes.DataTypes.Record, callContext.id).oSAttr.nameAttr === "android"))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:+T5XoZQ9aU+WJygt_Cn4mw", callContext.id);
smsOTPAPIJSResult.value = controller.safeExecuteJSNode(ShopperPortalEU_Authentication_VerifyIdentityCode_mvc_controller_OnInitialize_SmsOTPAPIJS, "SmsOTPAPI", "OnInitialize", {
AC: OS.DataConversion.JSNodeParamConverter.to(null, OS.DataTypes.DataTypes.Object)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("ShopperPortalEU.Authentication.VerifyIdentityCode.OnInitialize$smsOTPAPIJSResult"))();
jsNodeResult.aCOut = OS.DataConversion.JSNodeParamConverter.from($parameters.AC, OS.DataTypes.DataTypes.Object);
return jsNodeResult;
}, {
OnCodeSubmitted: controller.clientActionProxies.onCodeSubmitted$Action,
OnError: controller.clientActionProxies.onError$Action
}, {});
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:BAOJ0ydioUGO5vDANC+n+A", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:d6T2JarW7k6TGnfYaTb2wA", callContext.id);
}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:zD+qlmnkU0aWUweP1NpsbQ", callContext.id);
}

};
Controller.registerVariableGroupType("ShopperPortalEU.Authentication.VerifyIdentityCode.OnInitialize$smsOTPAPIJSResult", [{
name: "AC",
attrName: "aCOut",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Object,
defaultValue: function () {
return null;
}
}]);
Controller.prototype._startCountdown_ResendCode$Action = function (timeToResendCodeIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("StartCountdown_ResendCode");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.Authentication.VerifyIdentityCode.StartCountdown_ResendCode$vars"))());
vars.value.timeToResendCodeInLocal = timeToResendCodeIn;
var startCountDownTimerJSResult = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.vars = vars;
varBag.startCountDownTimerJSResult = startCountDownTimerJSResult;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:9kLMsBP50EG4wbWoJB7mKQ:/NRWebFlows.ozCJCRi2BU2OkqD4Zl84lQ/NodesShownInESpaceTree.b88Y+d17p0CuMa2uuNNQMQ/ClientActions.9kLMsBP50EG4wbWoJB7mKQ:iJ+sdP5QRaFoycXX_gEXRQ", "ShopperPortalEU", "StartCountdown_ResendCode", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:S1gYwYPyuUu+5ay3l9iwkg", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:d22Q1XSoxE+oASxaI_11_Q", callContext.id);
// ResendCodeSeconds = TimeToResendCode
ShopperPortalEUClientVariables.setResendCodeSeconds(vars.value.timeToResendCodeInLocal);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:pqZFim4+B0C7aHSBQ+JCBg", callContext.id);
startCountDownTimerJSResult.value = controller.safeExecuteJSNode(ShopperPortalEU_Authentication_VerifyIdentityCode_mvc_controller_StartCountdown_ResendCode_StartCountDownTimerJS, "StartCountDownTimer", "StartCountdown_ResendCode", {
TimeToResendCode: OS.DataConversion.JSNodeParamConverter.to(vars.value.timeToResendCodeInLocal, OS.DataTypes.DataTypes.Integer),
ResendCodeTime: OS.DataConversion.JSNodeParamConverter.to(0, OS.DataTypes.DataTypes.Integer)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("ShopperPortalEU.Authentication.VerifyIdentityCode.StartCountdown_ResendCode$startCountDownTimerJSResult"))();
jsNodeResult.resendCodeTimeOut = OS.DataConversion.JSNodeParamConverter.from($parameters.ResendCodeTime, OS.DataTypes.DataTypes.Integer);
return jsNodeResult;
}, {
TimerResend_OnElapsed: controller.clientActionProxies.timerResend_OnElapsed$Action,
TimerResend_Update: controller.clientActionProxies.timerResend_Update$Action
}, {});
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:t4akTda+d0+vinjWd8NTYA", callContext.id);
// ResendCodeTime = StartCountDownTimer.ResendCodeTime
model.variables.resendCodeTimeVar = startCountDownTimerJSResult.value.resendCodeTimeOut;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:NeLFeiNfCkuYC3WFYb7BeA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:9kLMsBP50EG4wbWoJB7mKQ", callContext.id);
}

};
Controller.registerVariableGroupType("ShopperPortalEU.Authentication.VerifyIdentityCode.StartCountdown_ResendCode$vars", [{
name: "TimeToResendCode",
attrName: "timeToResendCodeInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Integer,
defaultValue: function () {
return 0;
}
}]);
Controller.registerVariableGroupType("ShopperPortalEU.Authentication.VerifyIdentityCode.StartCountdown_ResendCode$startCountDownTimerJSResult", [{
name: "ResendCodeTime",
attrName: "resendCodeTimeOut",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Integer,
defaultValue: function () {
return 0;
}
}]);
Controller.prototype._stopCountdown_ResendCode$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("StopCountdown_ResendCode");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:VXrZvwZvK0mezDl9hH5Ryw:/NRWebFlows.ozCJCRi2BU2OkqD4Zl84lQ/NodesShownInESpaceTree.b88Y+d17p0CuMa2uuNNQMQ/ClientActions.VXrZvwZvK0mezDl9hH5Ryw:t9QbWNK1gXGTZ8Dc0OuD1A", "ShopperPortalEU", "StopCountdown_ResendCode", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:0ie4gNkEJEi2MIJ96AAxkw", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:__svi19+2kWjw4HXV60pgQ", callContext.id);
// ResendCodeSeconds = -1
ShopperPortalEUClientVariables.setResendCodeSeconds(-1);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:WvSc15S5HUiACJ1uGSN+RQ", callContext.id);
controller.safeExecuteJSNode(ShopperPortalEU_Authentication_VerifyIdentityCode_mvc_controller_StopCountdown_ResendCode_stopResendTimerJS, "stopResendTimer", "StopCountdown_ResendCode", {
ResendCodeTime: OS.DataConversion.JSNodeParamConverter.to(model.variables.resendCodeTimeVar, OS.DataTypes.DataTypes.Integer)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:2ZDbhwSsR0GMS1nvnBURQw", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:VXrZvwZvK0mezDl9hH5Ryw", callContext.id);
}

};
Controller.prototype._timerResend_OnElapsed$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("TimerResend_OnElapsed");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:+Bn51Ua0GkygvL4vhf+_Iw:/NRWebFlows.ozCJCRi2BU2OkqD4Zl84lQ/NodesShownInESpaceTree.b88Y+d17p0CuMa2uuNNQMQ/ClientActions.+Bn51Ua0GkygvL4vhf+_Iw:JZ6ZkT+CxvVo2rm4M8gXOA", "ShopperPortalEU", "TimerResend_OnElapsed", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:o31X4Jvomk6_Sg2PGi9vqQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:NggcWe5KgkmTKejLgSXIIg", callContext.id);
// ResendCodeSeconds = -1
ShopperPortalEUClientVariables.setResendCodeSeconds(-1);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:UVgDZv71YUmtHArHhB+W7A", callContext.id);
// ShowResendLink = True
model.variables.showResendLinkVar = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ZQf8f7Zbe0uc4csOAysGuw", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:+Bn51Ua0GkygvL4vhf+_Iw", callContext.id);
}

};
Controller.prototype._timerResend_Update$Action = function (secondsLeftIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("TimerResend_Update");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.Authentication.VerifyIdentityCode.TimerResend_Update$vars"))());
vars.value.secondsLeftInLocal = secondsLeftIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:17Ey7pdts0qwfrbZ5dOG3A:/NRWebFlows.ozCJCRi2BU2OkqD4Zl84lQ/NodesShownInESpaceTree.b88Y+d17p0CuMa2uuNNQMQ/ClientActions.17Ey7pdts0qwfrbZ5dOG3A:EuFvrGNClE7fwtzMm9kVyg", "ShopperPortalEU", "TimerResend_Update", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Yb4mwkQ+xUuzUzZzVXIHyA", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:E_5UiZ8ORUmI6wYbaPcErg", callContext.id);
// ResendCodeSeconds = SecondsLeft
ShopperPortalEUClientVariables.setResendCodeSeconds(vars.value.secondsLeftInLocal);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:yFRrlOskiU28gPoSLCmqJg", callContext.id);
// TimeToResend = SecondsLeft
model.variables.timeToResendVar = vars.value.secondsLeftInLocal;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:pjQvJwTa_kKyzGWGdk_VxA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:17Ey7pdts0qwfrbZ5dOG3A", callContext.id);
}

};
Controller.registerVariableGroupType("ShopperPortalEU.Authentication.VerifyIdentityCode.TimerResend_Update$vars", [{
name: "SecondsLeft",
attrName: "secondsLeftInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Integer,
defaultValue: function () {
return 0;
}
}]);

Controller.prototype.onDestroy$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onDestroy$Action, callContext);

};
Controller.prototype.onAfterFetch$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onAfterFetch$Action, callContext);

};
Controller.prototype.inputVerifyCodeOnChange$Action = function (currentCodeIn, isFilledIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._inputVerifyCodeOnChange$Action, callContext, currentCodeIn, isFilledIn);

};
Controller.prototype.resendCodeOnClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._resendCodeOnClick$Action, callContext);

};
Controller.prototype.onError$Action = function (errorMessageIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onError$Action, callContext, errorMessageIn);

};
Controller.prototype.onCodeSubmitted$Action = function (oTPCodeIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onCodeSubmitted$Action, callContext, oTPCodeIn);

};
Controller.prototype.gmailLinkOnClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._gmailLinkOnClick$Action, callContext);

};
Controller.prototype.onInitialize$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onInitialize$Action, callContext);

};
Controller.prototype.startCountdown_ResendCode$Action = function (timeToResendCodeIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._startCountdown_ResendCode$Action, callContext, timeToResendCodeIn);

};
Controller.prototype.stopCountdown_ResendCode$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._stopCountdown_ResendCode$Action, callContext);

};
Controller.prototype.timerResend_OnElapsed$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._timerResend_OnElapsed$Action, callContext);

};
Controller.prototype.timerResend_Update$Action = function (secondsLeftIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._timerResend_Update$Action, callContext, secondsLeftIn);

};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:ozCJCRi2BU2OkqD4Zl84lQ:/NRWebFlows.ozCJCRi2BU2OkqD4Zl84lQ:EruRjKvlJ0FVyQ96YiDGmw", "ShopperPortalEU", "Authentication", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:b88Y+d17p0CuMa2uuNNQMQ:/NRWebFlows.ozCJCRi2BU2OkqD4Zl84lQ/NodesShownInESpaceTree.b88Y+d17p0CuMa2uuNNQMQ:SgSO46o_NiaTARo2yjgEVw", "ShopperPortalEU", "VerifyIdentityCode", "NRNodes.WebScreen", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:b88Y+d17p0CuMa2uuNNQMQ", callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:ozCJCRi2BU2OkqD4Zl84lQ", callContext.id);
};
Controller.prototype.onInitializeEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Authentication/VerifyIdentityCode On Initialize");
return controller.onInitialize$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Authentication/VerifyIdentityCode On Destroy");
return controller.onDestroy$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return ShopperPortalEU_AuthenticationController.default.handleError(ex, this.callContext());
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return ShopperPortalEUController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, ShopperPortalEULanguageResources);
});
define("ShopperPortalEU.Authentication.VerifyIdentityCode.mvc$controller.GmailLinkOnClick.RedirectToURLJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
window.open($parameters.URL,"_blank");
};
});
define("ShopperPortalEU.Authentication.VerifyIdentityCode.mvc$controller.OnInitialize.SmsOTPAPIJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.AC = new AbortController();

setTimeout(() => {
  // abort after 20 minutes
  $parameters.AC.abort();
}, 20 * 60 * 1000);
  
navigator.credentials.get({
  signal: $parameters.AC.signal,
  otp: {
    transport: ["sms"]
  }
}).then(otp => {
    $actions.OnCodeSubmitted(otp.code);
}).catch(err => {
    if(err.code){
        $actions.OnError(err.message);
    }
});
};
});
define("ShopperPortalEU.Authentication.VerifyIdentityCode.mvc$controller.StartCountdown_ResendCode.StartCountDownTimerJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var timeleft = $parameters.TimeToResendCode;
var resendcode = setInterval(function(){
  if(timeleft <= 0){
    clearInterval(resendcode);
    $actions.TimerResend_OnElapsed();
 } else {
    $actions.TimerResend_Update(timeleft);
  }
  timeleft -= 1;
}, 1000);

$parameters.ResendCodeTime = resendcode;
};
});
define("ShopperPortalEU.Authentication.VerifyIdentityCode.mvc$controller.StopCountdown_ResendCode.stopResendTimerJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
if ($parameters.ResendCodeTime!= 0) {
    clearInterval($parameters.ResendCodeTime);
}
};
});

define("ShopperPortalEU.Authentication.VerifyIdentityCode.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"CXQESkzfEkasHIHJLPv_dg": {
getter: function (varBag, idService) {
return varBag.allExceptionsVar.value;
}
},
"1DIYmfEbSkq0SgAbXOlz4A": {
getter: function (varBag, idService) {
return varBag.vars.value.currentCodeInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"kOXd2vH5uUyMhS5gV_+kMw": {
getter: function (varBag, idService) {
return varBag.vars.value.isFilledInLocal;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"KwUQu9Ie4U2ZhGDaqOUFig": {
getter: function (varBag, idService) {
return varBag.sendCodeVar.value;
}
},
"jnRk_Naq00OzgEI78bB98A": {
getter: function (varBag, idService) {
return varBag.verifyCodeVar.value;
}
},
"Rf+lqCWVhEmqdpWXQGVbVQ": {
getter: function (varBag, idService) {
return varBag.sendCodeVar.value;
}
},
"pAu9sQTVck6TeB49pjvLeA": {
getter: function (varBag, idService) {
return varBag.vars.value.errorMessageInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"lDG17dJICU+jAyJ0Wh6zgw": {
getter: function (varBag, idService) {
return varBag.vars.value.oTPCodeInLocal;
},
dataType: OS.DataTypes.DataTypes.Text
},
"Aex1VKcQHUeAFNRR9vsPcA": {
getter: function (varBag, idService) {
return varBag.redirectToURLJSResult.value;
}
},
"+T5XoZQ9aU+WJygt_Cn4mw": {
getter: function (varBag, idService) {
return varBag.smsOTPAPIJSResult.value;
}
},
"0yngUM1ZLEmMGDNFxSx7UQ": {
getter: function (varBag, idService) {
return varBag.vars.value.timeToResendCodeInLocal;
},
dataType: OS.DataTypes.DataTypes.Integer
},
"pqZFim4+B0C7aHSBQ+JCBg": {
getter: function (varBag, idService) {
return varBag.startCountDownTimerJSResult.value;
}
},
"WvSc15S5HUiACJ1uGSN+RQ": {
getter: function (varBag, idService) {
return varBag.stopResendTimerJSResult.value;
}
},
"Wu56_3fvo0qGOlcCPknBJg": {
getter: function (varBag, idService) {
return varBag.vars.value.secondsLeftInLocal;
},
dataType: OS.DataTypes.DataTypes.Integer
},
"gfTm89WB60u3wlmPNeHAmQ": {
getter: function (varBag, idService) {
return varBag.model.variables.codeToVerifyVar;
},
dataType: OS.DataTypes.DataTypes.Text
},
"IxiqBMjMLUSRw3Rs38AKwQ": {
getter: function (varBag, idService) {
return varBag.model.variables.isVerifingCodeVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"ITzsStF8QkieWkTWHcOoQA": {
getter: function (varBag, idService) {
return varBag.model.variables.showResendLinkVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"rrBmFzJVKECTaFGff7CSSg": {
getter: function (varBag, idService) {
return varBag.model.variables.resendCodeTimeVar;
},
dataType: OS.DataTypes.DataTypes.Integer
},
"J6rVvHXtYUiRJE0E_YGGZQ": {
getter: function (varBag, idService) {
return varBag.model.variables.timeToResendVar;
},
dataType: OS.DataTypes.DataTypes.Integer
},
"ZbQep62pgEu4koH+cy7GeA": {
getter: function (varBag, idService) {
return varBag.model.variables.isCodeInvalidVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"vvGoBQYOqEKCak2CvZyjuw": {
getter: function (varBag, idService) {
return varBag.model.variables.isCodeExpiredVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"Zfx8iPpVsUihP3ccNA6GVA": {
getter: function (varBag, idService) {
return varBag.model.variables.getAuthInfoAndSitePropertiesDataAct;
}
},
"OjGYMRVkzEWkK1FNQAm8QA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderLeft"));
})(varBag.model, idService);
}
},
"wSAkifHHIEiP3vXl1c79dw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderCenter"));
})(varBag.model, idService);
}
},
"W3xVjle40k+msprKKzo2DA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"MuViLEDCbUeXkOR4m3L50Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderRight"));
})(varBag.model, idService);
}
},
"IOhTdaXjikujvM9M8JTrUw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"rTHHb727tUGcJitZpMxeRw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"2KMZqksBOkCRiPUrcpHS7Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Top"));
})(varBag.model, idService);
}
},
"v8YF_EhmYUCWCuhTV93wiQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"Z5qtA3VoeEqEJrYnwUiD9g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"HiUNxwStxUCrJJBIwcGSCw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("IsGmail"));
})(varBag.model, idService);
}
},
"f8VAGAE44UC1CluQH71+cA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("OpenEmail_ctn"));
})(varBag.model, idService);
}
},
"Q0StocQ2g0C+E8OsYq+r_Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Link"));
})(varBag.model, idService);
}
},
"yrTy60RP80aLficEMpOPsA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"RNJ6vd9a+UeEmgBWdsjJNw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("IsCodeInsertedInvalid"));
})(varBag.model, idService);
}
},
"zN+eaOiq3UKLHe1pilCi1w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"FhwS8i+nPUWfHyrDp4NmyA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"z7_0YwCa0UW9Kw0VXdZjxw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Link"));
})(varBag.model, idService);
}
},
"nnSskDCBMEescDhUn5YhjA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"yV7_j8qKRkGFbbemmppMJQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("IsVerifyCode"));
})(varBag.model, idService);
}
},
"2B3aON5Qm0usFYe4zvOYUA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Bottom"));
})(varBag.model, idService);
}
},
"FGip33ZC5UWqLAXN8Q2Vqg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("ShowResendLink2"));
})(varBag.model, idService);
}
},
"0AXedwttD0OM_HkhBIB_yg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Link"));
})(varBag.model, idService);
}
},
"megL6LA8NEybM7v9RxxKFg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"Op3t+GTXD0aDTkkf4eIAFA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"kCgyEQ7reUii0M60wmRp2A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Bottom"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
