define("ShopperPortalEU_API.referencesHealth$ServiceCenter", [], function () {
// Reference to producer 'ServiceCenter' is OK.
});
define("ShopperPortalEU_API.referencesHealth$ShopperPortalEU_Bootstrap_CS", [], function () {
// Reference to producer 'ShopperPortalEU_Bootstrap_CS' is OK.
});
define("ShopperPortalEU_API.referencesHealth$ShopperPortalEU_CS", [], function () {
// Reference to producer 'ShopperPortalEU_CS' is OK.
});
define("ShopperPortalEU_API.referencesHealth$ShopperPortalEU_IS", [], function () {
// Reference to producer 'ShopperPortalEU_IS' is OK.
});
define("ShopperPortalEU_API.referencesHealth$ShopperPortalEUMM_IS", [], function () {
// Reference to producer 'ShopperPortalEUMM_IS' is OK.
});
define("ShopperPortalEU_API.referencesHealth$Users", [], function () {
// Reference to producer 'Users' is OK.
});
define("ShopperPortalEU_API.referencesHealth", [], function () {
});
