define("ShopperPortalEU.Profile.ScanPassport.mvc$model", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Theme.controller", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Components.controller", "ShopperPortalEU.model$ScanPassportRec", "ShopperPortalEU_UI_Theme.model$LayoutDetailOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$CustomButtonItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconRec", "ShopperPortalEU_UI_Components.model$FullHeightContentOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentTopOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentBottomOptionsRec", "ShopperPortalEU_UI_Components.model$FlexOptionsRec", "ShopperPortalEU_UI_Components.model$CustomIconOptionsRec", "ShopperPortalEU_UI_Components.model$CustomImageOptionsRec", "ShopperPortalEU_UI_Components.model$CustomOpacityOptionsRec", "ShopperPortalEU_UI_Components.model$CustomPopupLayoutOptionsRec", "ShopperPortalEU_UI_Components.model$CustomPopupLayoutHeaderImageOptionsRec", "ShopperPortalEU_UI_Components.model$CustomColumnsOptionsRec", "ShopperPortalEU_UI_Components.model$CustomInputOptionsRec", "ShopperPortalEU_UI_Components.model$CustomInputIconOptionRec", "ShopperPortalEU_UI_Components.model$CustomInputValidationOptionsRec", "ShopperPortalEU_UI_Components.model$DatePickerOptionsRec", "ShopperPortalEU_UI_Components.model$DatePickerLabelOptionsRec", "ShopperPortalEU_UI_Components.model$DatePickerValidationOptionsRec", "ShopperPortalEU.model$CountriesWithFlagsDropdownListList", "ShopperPortalEU_UI_Components.model$CustomDropdownListValidationOptionsRec", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", "ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger", "ShopperPortalEU_UI_Components.model$CustomDropdownListValueOptionsRec", "ShopperPortalEU.controller$ClarityEvent", "ShopperPortalEU_UI_Components.model$GetOSRec", "ShopperPortalEU_UI_Components.controller$GetOS", "ShopperPortalEU.controller$DefaultErrorMessage", "ShopperPortalEU_UI_Components.model$ScanPassportErrorRec", "ShopperPortalEU_UI_Components.model$ScanPassportDataRec", "ShopperPortalEU.controller$FormatPassportData", "ShopperPortalEU_UI_Theme.controller$CustomMessageHide", "ShopperPortalEU.controller$FormatDate"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ThemeController, ShopperPortalEUController, ShopperPortalEU_UI_ComponentsController) {
var OS = OutSystems.Internal;

var GetCountriesDataActRec = (function (_super) {
__extends(GetCountriesDataActRec, _super);
function GetCountriesDataActRec(defaults) {
_super.apply(this, arguments);
}
GetCountriesDataActRec.attributesToDeclare = function () {
return [
this.attr("Countries", "countriesOut", "Countries", true, false, OS.DataTypes.DataTypes.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEUModel.CountriesWithFlagsDropdownListList());
}, true, ShopperPortalEUModel.CountriesWithFlagsDropdownListList)
].concat(_super.attributesToDeclare.call(this));
};
GetCountriesDataActRec.fromStructure = function (str) {
return new GetCountriesDataActRec(new GetCountriesDataActRec.RecordClass({
countriesOut: OS.DataTypes.ImmutableBase.getData(str)
}));
};
GetCountriesDataActRec.init();
return GetCountriesDataActRec;
})(OS.Model.DataSourceRecord);
var GetDataDataActRec = (function (_super) {
__extends(GetDataDataActRec, _super);
function GetDataDataActRec(defaults) {
_super.apply(this, arguments);
}
GetDataDataActRec.attributesToDeclare = function () {
return [
this.attr("IsDemoEnvironment", "isDemoEnvironmentOut", "IsDemoEnvironment", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
GetDataDataActRec.fromStructure = function (str) {
return new GetDataDataActRec(new GetDataDataActRec.RecordClass({
isDemoEnvironmentOut: OS.DataTypes.ImmutableBase.getData(str)
}));
};
GetDataDataActRec.init();
return GetDataDataActRec;
})(OS.Model.DataSourceRecord);

var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("ShowTips", "showTipsVar", "ShowTips", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("Timeout", "timeoutVar", "Timeout", true, false, OS.DataTypes.DataTypes.Object, function () {
return null;
}, false), 
this.attr("IsScanLoaded", "isScanLoadedVar", "IsScanLoaded", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("ShowCameraBlockedPopup", "showCameraBlockedPopupVar", "ShowCameraBlockedPopup", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("EnterPassportManually", "enterPassportManuallyVar", "EnterPassportManually", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("PassportManualData", "passportManualDataVar", "PassportManualData", true, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEUModel.ScanPassportRec());
}, false, ShopperPortalEUModel.ScanPassportRec), 
this.attr("GetCountries", "getCountriesDataAct", "getCountriesDataAct", true, true, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new GetCountriesDataActRec());
}, true, GetCountriesDataActRec), 
this.attr("GetData", "getDataDataAct", "getDataDataAct", true, true, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new GetDataDataActRec());
}, true, GetDataDataActRec)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {
Input_PassportNumber: OS.Model.ValidationWidgetRecord
};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return true;
}
});

Model.prototype.setInputs = function (inputs) {
};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "Profile.ScanPassport");
});
define("ShopperPortalEU.Profile.ScanPassport.mvc$view", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Theme.controller", "ShopperPortalEU_UI_Components.controller", "react", "OutSystems/ReactView/Main", "ShopperPortalEU.Profile.ScanPassport.mvc$model", "ShopperPortalEU.Profile.ScanPassport.mvc$controller", "ShopperPortalEU.clientVariables", "ShopperPortalEU.Layouts.LayoutDetail.mvc$view", "OutSystems/ReactWidgets/Main", "ShopperPortalEU.LayoutsComponents.Back.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomButton.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomButtonItem.mvc$view", "ShopperPortalEU.Common.DataLoading.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.FullHeightContent.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.ScanPassport.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.Flex.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomIcon.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomImage.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomOpacity.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomPopup.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomPopupLayout.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomColumns.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomInput.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.DatePicker.mvc$view", "ShopperPortalEU.Common.CountryDropdown.mvc$view", "ShopperPortalEU.model$ScanPassportRec", "ShopperPortalEU_UI_Theme.model$LayoutDetailOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$CustomButtonItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconRec", "ShopperPortalEU_UI_Components.model$FullHeightContentOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentTopOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentBottomOptionsRec", "ShopperPortalEU_UI_Components.model$FlexOptionsRec", "ShopperPortalEU_UI_Components.model$CustomIconOptionsRec", "ShopperPortalEU_UI_Components.model$CustomImageOptionsRec", "ShopperPortalEU_UI_Components.model$CustomOpacityOptionsRec", "ShopperPortalEU_UI_Components.model$CustomPopupLayoutOptionsRec", "ShopperPortalEU_UI_Components.model$CustomPopupLayoutHeaderImageOptionsRec", "ShopperPortalEU_UI_Components.model$CustomColumnsOptionsRec", "ShopperPortalEU_UI_Components.model$CustomInputOptionsRec", "ShopperPortalEU_UI_Components.model$CustomInputIconOptionRec", "ShopperPortalEU_UI_Components.model$CustomInputValidationOptionsRec", "ShopperPortalEU_UI_Components.model$DatePickerOptionsRec", "ShopperPortalEU_UI_Components.model$DatePickerLabelOptionsRec", "ShopperPortalEU_UI_Components.model$DatePickerValidationOptionsRec", "ShopperPortalEU.model$CountriesWithFlagsDropdownListList", "ShopperPortalEU_UI_Components.model$CustomDropdownListValidationOptionsRec", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", "ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger", "ShopperPortalEU_UI_Components.model$CustomDropdownListValueOptionsRec", "ShopperPortalEU.controller$ClarityEvent", "ShopperPortalEU_UI_Components.model$GetOSRec", "ShopperPortalEU_UI_Components.controller$GetOS", "ShopperPortalEU.controller$DefaultErrorMessage", "ShopperPortalEU_UI_Components.model$ScanPassportErrorRec", "ShopperPortalEU_UI_Components.model$ScanPassportDataRec", "ShopperPortalEU.controller$FormatPassportData", "ShopperPortalEU_UI_Theme.controller$CustomMessageHide", "ShopperPortalEU.controller$FormatDate"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ThemeController, ShopperPortalEU_UI_ComponentsController, React, OSView, ShopperPortalEU_Profile_ScanPassport_mvc_model, ShopperPortalEU_Profile_ScanPassport_mvc_controller, ShopperPortalEUClientVariables, ShopperPortalEU_Layouts_LayoutDetail_mvc_view, OSWidgets, ShopperPortalEU_LayoutsComponents_Back_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, ShopperPortalEU_Common_DataLoading_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_ScanPassport_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomIcon_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomImage_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomOpacity_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomPopup_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomPopupLayout_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomColumns_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomInput_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_DatePicker_mvc_view, ShopperPortalEU_Common_CountryDropdown_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            var thisIsInstanceOfSuper = this instanceof _super;
            if (thisIsInstanceOfSuper == false) {
                return;
            }

            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "Profile.ScanPassport";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css", "css/ShopperPortalEU_UI_Theme.ShopperPortalEUUITheme.css", "css/ShopperPortalEU.ShopperPortalEU.css", "css/ShopperPortalEU_UI_Theme.ShopperPortalEUUITheme.extra.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [ShopperPortalEU_Layouts_LayoutDetail_mvc_view, ShopperPortalEU_LayoutsComponents_Back_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, ShopperPortalEU_Common_DataLoading_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_ScanPassport_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomIcon_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomImage_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomOpacity_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomPopup_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomPopupLayout_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomColumns_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomInput_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_DatePicker_mvc_view, ShopperPortalEU_Common_CountryDropdown_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return ShopperPortalEU_Profile_ScanPassport_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return ShopperPortalEU_Profile_ScanPassport_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "Shopper Portal EU - Scan Passport";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(ShopperPortalEU_Layouts_LayoutDetail_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("Tce_8sV260+ozwgtm0HLuA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ThemeModel.LayoutDetailOptionsRec();
rec.darkModeAttr = true;
return rec;
}();
}),
Auth: model.getCachedValue(idService.getId("Tce_8sV260+ozwgtm0HLuA.Auth"), function () {
return function () {
var rec = new ShopperPortalEUModel.LayoutAuthenticationRec();
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "0",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
headerLeft: new PlaceholderContent(function () {
return [$if(model.variables.isScanLoadedVar, false, this, function () {
return [$if((ShopperPortalEUClientVariables.getScanPassportRedirect() === 0), false, this, function () {
return [React.createElement(ShopperPortalEU_LayoutsComponents_Back_mvc_view, {
inputs: {
ManualRedirect: true
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onClick$Action: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "LayoutsComponents/Back OnClick");
controller.closeOnClick$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "1",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}, function () {
return [];
})];
}, function () {
return [];
})];
}),
headerCenter: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Scan passport",
_idProps: {
service: idService,
uuid: "2"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
headerRight: new PlaceholderContent(function () {
return [$if(model.variables.isScanLoadedVar, false, this, function () {
return [$if((ShopperPortalEUClientVariables.getScanPassportRedirect() === 1), false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("kU2+CY9vOkGXuH1gdsYGRg.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRec();
rec.testIdAttr = "CloseScanPassportScreen";
rec.typeAttr = ShopperPortalEUModel.staticEntities.customButtonType.linkSecondary;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "3",
alias: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
button: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: false,
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Profile/ScanPassport/Button OnClick");
controller.closeOnClick$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn",
visible: true,
_idProps: {
service: idService,
uuid: "4"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("2pQqTAsWX0+VgE2YovDi1g.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonItemOptionsRec();
rec.iconAttr = function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsIconRec();
rec.nameAttr = "close";
return rec;
}();
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "5",
alias: "4"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: PlaceholderContent.Empty
},
_dependencies: []
}))];
})
},
_dependencies: []
})];
}, function () {
return [];
})];
}, function () {
return [];
})];
}),
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_Common_DataLoading_mvc_view, {
inputs: {
IsDataFetched: model.variables.getDataDataAct.isDataFetchedAttr
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "6",
alias: "5"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_FullHeightContent_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("aF5yJiEN2UmeYl_oK5ka7A.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FullHeightContentOptionsRec();
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space5;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "7",
alias: "6"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
top: new PlaceholderContent(function () {
return [$if(!(model.variables.enterPassportManuallyVar), false, this, function () {
return [React.createElement(OSWidgets.Expression, {
value: "You must use the same passport for scanning and your tax-free purchases.",
_idProps: {
service: idService,
uuid: "8"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_ScanPassport_mvc_view, {
inputs: {
ExtendedClass: "margin-top-04"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onResult$Action: function (dataIn) {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ShopperPortalEUUIComponents/ScanPassport OnResult");
return controller.scanPassportOnResult$Action(dataIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
onError$Action: function (errorIn) {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ShopperPortalEUUIComponents/ScanPassport OnError");
return controller.scanPassportOnError$Action(errorIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
onLoad$Action: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ShopperPortalEUUIComponents/ScanPassport OnLoad");
controller.scanPassportOnLoad$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "9",
alias: "7"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
ExtendedClass: "margin-top-06",
Options: model.getCachedValue(idService.getId("UgkNhCBGYkCrFm+Kbr_K6A.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
rec.wrapAttr = false;
rec.lineHeightResetAttr = true;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "10",
alias: "8"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomIcon_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("KJZGNNv_Y0+oWqOz0iZgyg.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomIconOptionsRec();
rec.nameAttr = "center_focus_weak";
rec.sizeAttr = ShopperPortalEUModel.staticEntities.customIconSize.extraSmall;
rec.isFilledAttr = true;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "11",
alias: "9"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "12"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
value: "Scan the two lines at the bottom of your passport",
_idProps: {
service: idService,
uuid: "13"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomImage_mvc_view, {
inputs: {
ExtendedClass: "margin-top-03"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "14",
alias: "10"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
image: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Image, {
type: /*External*/ 1,
url: "/ShopperPortalEU_UI_Resources/img/ShopperPortalEU_UI_Resources.passport_mrz.svg",
_idProps: {
service: idService,
uuid: "15"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomOpacity_mvc_view, {
inputs: {
ExtendedClass: "margin-top-05",
Options: model.getCachedValue(idService.getId("46GuNxWC6E6Rff2vyy9zTQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomOpacityOptionsRec();
rec.valueAttr = OS.BuiltinFunctions.integerToDecimal(((model.variables.showTipsVar) ? (1) : (0)));
rec.isAnimatedAttr = true;
return rec;
}();
}, function () {
return model.variables.showTipsVar;
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "16",
alias: "11"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("aervrsHei0yafYdp+1YY+Q.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.alignAttr = ShopperPortalEUModel.staticEntities.flexAlign.center;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
rec.wrapAttr = false;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "17",
alias: "12"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomIcon_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("qcaZ2nknnEqY0y8w18TWOQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomIconOptionsRec();
rec.nameAttr = "fit_screen";
rec.sizeAttr = ShopperPortalEUModel.staticEntities.customIconSize.extraSmall;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "18",
alias: "13"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}), React.createElement(OSWidgets.Expression, {
value: "Align within the on-screen frame",
_idProps: {
service: idService,
uuid: "19"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
ExtendedClass: "margin-top-04",
Options: model.getCachedValue(idService.getId("5Hqz141DI0KgpF7xnTU9YA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.alignAttr = ShopperPortalEUModel.staticEntities.flexAlign.center;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
rec.wrapAttr = false;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "20",
alias: "14"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomIcon_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("fa5I_CGdmEW37pcfsSYdAQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomIconOptionsRec();
rec.nameAttr = "front_hand";
rec.sizeAttr = ShopperPortalEUModel.staticEntities.customIconSize.extraSmall;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "21",
alias: "15"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}), React.createElement(OSWidgets.Expression, {
value: "Hold your passport still",
_idProps: {
service: idService,
uuid: "22"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
ExtendedClass: "margin-top-04",
Options: model.getCachedValue(idService.getId("D1OcmWGER0a2U4jv5VHbOQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.alignAttr = ShopperPortalEUModel.staticEntities.flexAlign.center;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
rec.wrapAttr = false;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "23",
alias: "16"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomIcon_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("uoPfkwjPIkiWRt40rezLXw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomIconOptionsRec();
rec.nameAttr = "light_mode";
rec.sizeAttr = ShopperPortalEUModel.staticEntities.customIconSize.extraSmall;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "24",
alias: "17"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}), React.createElement(OSWidgets.Expression, {
value: "Make sure there is good light",
_idProps: {
service: idService,
uuid: "25"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
})];
})
},
_dependencies: []
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomPopup_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "26",
alias: "18"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
popup: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Popup, {
showPopup: model.variables.showCameraBlockedPopupVar,
style: "popup-dialog",
_idProps: {
service: idService,
uuid: "27"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomPopupLayout_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "28",
alias: "19"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
title: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "CameraBlockedPopupTitle"
},
value: "Allow camera access",
_idProps: {
service: idService,
uuid: "29"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "CameraBlockedPopupContent"
},
value: "Check your browser permissions, usually in the address bar, to allow camera access for passport scanning.",
_idProps: {
service: idService,
uuid: "30"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
actions: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("D6v8eSg0QUKnSwacQ7zNAg.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.justifyAttr = ShopperPortalEUModel.staticEntities.flexJustify.center;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.none;
rec.wrapAttr = false;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "31",
alias: "20"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("pN+DNFZGq0O7+uj+5yWRIw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRec();
rec.testIdAttr = "CameraBlockedPopupOk";
rec.typeAttr = ShopperPortalEUModel.staticEntities.customButtonType.primary;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "32",
alias: "21"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
button: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: false,
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Profile/ScanPassport/Button OnClick");
controller.okCameraBlockedPopup$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn",
visible: true,
_idProps: {
service: idService,
uuid: "33"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "34",
alias: "22"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Ok",
_idProps: {
service: idService,
uuid: "35"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
})];
})
},
_dependencies: []
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables.showCameraBlockedPopupVar)]
})];
}, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomColumns_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("kUOYcLxPxk6BpRPV2aLZ5A.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomColumnsOptionsRec();
rec.columnsAttr = 1;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space4;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "36",
alias: "23"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomInput_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("wuqaQqfbRUayNBjyqsdI4g.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomInputOptionsRec();
rec.testIdAttr = "PassportNumber";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "37",
alias: "24"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
label: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
mandatory: true,
targetWidget: "Input_PassportNumber",
_idProps: {
service: idService,
uuid: "38"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
value: "Passport number",
_idProps: {
service: idService,
uuid: "39"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
}),
input: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Input, {
_validationProps: {
validationService: validationService
},
enabled: true,
gridProperties: {
classes: "OSFillParent"
},
inputType: /*Text*/ 0,
mandatory: true,
maxLength: 50,
style: "form-control",
variable: model.createVariable(OS.DataTypes.DataTypes.Text, model.variables.passportManualDataVar.documentNumberAttr, function (value) {
model.variables.passportManualDataVar.documentNumberAttr = value;
}),
_idProps: {
service: idService,
name: "Input_PassportNumber"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
description: PlaceholderContent.Empty
},
_dependencies: [asPrimitiveValue(model.variables.passportManualDataVar.documentNumberAttr)]
}), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_DatePicker_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("Sw21VHg0aUC+vIbExRjFEw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.DatePickerOptionsRec();
rec.testIdAttr = "PassportDateOfExpiry";
rec.dateAttr = OS.BuiltinFunctions.dateTimeToDate(model.variables.passportManualDataVar.dateOfExpiryAttr);
rec.isMandatoryAttr = true;
rec.minDateAttr = OS.BuiltinFunctions.dateTimeToDate(OS.BuiltinFunctions.addDays(OS.BuiltinFunctions.currDate(), 1));
return rec;
}();
}, function () {
return model.variables.passportManualDataVar.dateOfExpiryAttr;
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onChange$Action: function (currentDateIn) {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "ShopperPortalEUUIComponents/DatePicker OnChange");
controller.passportExpiryDateOnChange$Action(currentDateIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "41",
alias: "25"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
label: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
_idProps: {
service: idService,
uuid: "42"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
value: "Passport date of expiry",
_idProps: {
service: idService,
uuid: "43"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
})
},
_dependencies: []
}), React.createElement(ShopperPortalEU_Common_CountryDropdown_mvc_view, {
inputs: {
Selected: model.variables.passportManualDataVar.issuingCountryCodeAttr,
IsMandatory: true,
NativeLabel: "Passport country",
List: model.variables.getCountriesDataAct.countriesOut,
_listInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getCountriesDataAct.dataFetchStatusAttr),
NullValue: "0",
HasNullValue: true,
TestId: "PassportCountry",
OpenedLabel: "Select passport country"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onChange$Action: function (currentCountryIn) {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common/CountryDropdown OnChange");
controller.passportCountryOnChange$Action(currentCountryIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "44",
alias: "26"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
label: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Passport country",
_idProps: {
service: idService,
uuid: "45"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.getCountriesDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.getCountriesDataAct.countriesOut), asPrimitiveValue(model.variables.passportManualDataVar.issuingCountryCodeAttr), asPrimitiveValue(model.variables.passportManualDataVar.dateOfExpiryAttr), asPrimitiveValue(model.variables.passportManualDataVar.documentNumberAttr)]
})];
})];
}),
bottom: new PlaceholderContent(function () {
return [$if(model.variables.getDataDataAct.isDemoEnvironmentOut, false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomColumns_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("Mvxf4Yvwn0aqgVd7U02zLA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomColumnsOptionsRec();
rec.columnsAttr = 1;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "46",
alias: "27"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("vg7XJPTurkmUjNs_IQOTPQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRec();
rec.testIdAttr = "EnterPassportManuallyButton";
rec.typeAttr = ShopperPortalEUModel.staticEntities.customButtonType.linkPrimary;
rec.isFullWidthAttr = true;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "47",
alias: "28"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
button: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: false,
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Profile/ScanPassport/Button OnClick");
return controller.togglePassportManually$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
style: "btn",
visible: true,
_idProps: {
service: idService,
uuid: "48"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "49",
alias: "29"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: model.getCachedValue(idService.getId("U604GfwKmkO72+C6oLOjZA.Value"), function () {
return ((!(model.variables.enterPassportManuallyVar)) ? ("Enter passport manually") : ("Scan passport"));
}, function () {
return model.variables.enterPassportManuallyVar;
}),
_idProps: {
service: idService,
uuid: "50"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.enterPassportManuallyVar)]
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables.enterPassportManuallyVar)]
}), $if(model.variables.enterPassportManuallyVar, false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButton_mvc_view, {
inputs: {
ExtendedClass: "margin-top-04",
Options: model.getCachedValue(idService.getId("cztISIWv50G19MJuR04PwQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomButtonOptionsRec();
rec.testIdAttr = "ConfirmPassportButton";
rec.typeAttr = ShopperPortalEUModel.staticEntities.customButtonType.primary;
rec.isFullWidthAttr = true;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "51",
alias: "30"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
button: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: false,
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Profile/ScanPassport/Button OnClick");
controller.confirm$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn",
visible: true,
_idProps: {
service: idService,
uuid: "52"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomButtonItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "53",
alias: "31"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Confirm",
_idProps: {
service: idService,
uuid: "54"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
})
},
_dependencies: []
})];
}, function () {
return [];
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.enterPassportManuallyVar)]
})];
}, function () {
return [];
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.getDataDataAct.isDemoEnvironmentOut), asPrimitiveValue(model.variables.getDataDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.getCountriesDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.getCountriesDataAct.countriesOut), asPrimitiveValue(model.variables.passportManualDataVar.issuingCountryCodeAttr), asPrimitiveValue(model.variables.passportManualDataVar.dateOfExpiryAttr), asPrimitiveValue(model.variables.passportManualDataVar.documentNumberAttr), asPrimitiveValue(model.variables.showCameraBlockedPopupVar), asPrimitiveValue(model.variables.showTipsVar), asPrimitiveValue(model.variables.enterPassportManuallyVar)]
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.getDataDataAct.isDemoEnvironmentOut), asPrimitiveValue(model.variables.getDataDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.getCountriesDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.getCountriesDataAct.countriesOut), asPrimitiveValue(model.variables.passportManualDataVar.issuingCountryCodeAttr), asPrimitiveValue(model.variables.passportManualDataVar.dateOfExpiryAttr), asPrimitiveValue(model.variables.passportManualDataVar.documentNumberAttr), asPrimitiveValue(model.variables.showCameraBlockedPopupVar), asPrimitiveValue(model.variables.showTipsVar), asPrimitiveValue(model.variables.enterPassportManuallyVar)]
})];
}),
bottom: PlaceholderContent.Empty
},
_dependencies: [asPrimitiveValue(model.variables.getDataDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.getCountriesDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.getCountriesDataAct.countriesOut), asPrimitiveValue(model.variables.passportManualDataVar.issuingCountryCodeAttr), asPrimitiveValue(model.variables.passportManualDataVar.dateOfExpiryAttr), asPrimitiveValue(model.variables.passportManualDataVar.documentNumberAttr), asPrimitiveValue(model.variables.showCameraBlockedPopupVar), asPrimitiveValue(model.variables.showTipsVar), asPrimitiveValue(model.variables.enterPassportManuallyVar), asPrimitiveValue(model.variables.getDataDataAct.isDemoEnvironmentOut), asPrimitiveValue(model.variables.getDataDataAct.isDataFetchedAttr), asPrimitiveValue(ShopperPortalEUClientVariables.getScanPassportRedirect()), asPrimitiveValue(model.variables.isScanLoadedVar)]
}));
        };
        return View;
    })(OSView.BaseView.BaseWebScreen);
	
    return View;
});
define("ShopperPortalEU.Profile.ScanPassport.mvc$controller", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Theme.controller", "ShopperPortalEU_UI_Components.controller", "ShopperPortalEU.languageResources", "ShopperPortalEU.clientVariables", "ShopperPortalEU.Profile.ScanPassport.mvc$debugger", "ShopperPortalEU.Profile.controller", "ShopperPortalEU.Profile.ScanPassport.mvc$controller.ClearTimeout.ClearJS", "ShopperPortalEU.Profile.ScanPassport.mvc$controller.SetTimeout.SetTimeoutJS", "ShopperPortalEU.model$ScanPassportRec", "ShopperPortalEU_UI_Theme.model$LayoutDetailOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$HeaderStepsOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Components.model$CustomButtonItemOptionsRec", "ShopperPortalEU_UI_Components.model$CustomButtonOptionsIconRec", "ShopperPortalEU_UI_Components.model$FullHeightContentOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentTopOptionsRec", "ShopperPortalEU_UI_Components.model$FullHeightContentBottomOptionsRec", "ShopperPortalEU_UI_Components.model$FlexOptionsRec", "ShopperPortalEU_UI_Components.model$CustomIconOptionsRec", "ShopperPortalEU_UI_Components.model$CustomImageOptionsRec", "ShopperPortalEU_UI_Components.model$CustomOpacityOptionsRec", "ShopperPortalEU_UI_Components.model$CustomPopupLayoutOptionsRec", "ShopperPortalEU_UI_Components.model$CustomPopupLayoutHeaderImageOptionsRec", "ShopperPortalEU_UI_Components.model$CustomColumnsOptionsRec", "ShopperPortalEU_UI_Components.model$CustomInputOptionsRec", "ShopperPortalEU_UI_Components.model$CustomInputIconOptionRec", "ShopperPortalEU_UI_Components.model$CustomInputValidationOptionsRec", "ShopperPortalEU_UI_Components.model$DatePickerOptionsRec", "ShopperPortalEU_UI_Components.model$DatePickerLabelOptionsRec", "ShopperPortalEU_UI_Components.model$DatePickerValidationOptionsRec", "ShopperPortalEU.model$CountriesWithFlagsDropdownListList", "ShopperPortalEU_UI_Components.model$CustomDropdownListValidationOptionsRec", "ShopperPortalEU_UI_Theme.model$CustomMessageOptionsRec", "ShopperPortalEU_UI_Theme.controller$CustomMessageTrigger", "ShopperPortalEU_UI_Components.model$CustomDropdownListValueOptionsRec", "ShopperPortalEU.controller$ClarityEvent", "ShopperPortalEU_UI_Components.model$GetOSRec", "ShopperPortalEU_UI_Components.controller$GetOS", "ShopperPortalEU.controller$DefaultErrorMessage", "ShopperPortalEU_UI_Components.model$ScanPassportErrorRec", "ShopperPortalEU_UI_Components.model$ScanPassportDataRec", "ShopperPortalEU.controller$FormatPassportData", "ShopperPortalEU_UI_Theme.controller$CustomMessageHide", "ShopperPortalEU.controller$FormatDate"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ThemeController, ShopperPortalEU_UI_ComponentsController, ShopperPortalEULanguageResources, ShopperPortalEUClientVariables, ShopperPortalEU_Profile_ScanPassport_mvc_Debugger, ShopperPortalEU_ProfileController, ShopperPortalEU_Profile_ScanPassport_mvc_controller_ClearTimeout_ClearJS, ShopperPortalEU_Profile_ScanPassport_mvc_controller_SetTimeout_SetTimeoutJS) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {
showTips$Action: function () {
return controller.executeActionInsideJSNode(controller._showTips$Action.bind(controller), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "ShowTips");
}
};
this.dataFetchDependenciesOriginal = {
getCountries$DataActRefresh: -1,
getData$DataActRefresh: 0
};
this.dataFetchDependentsGraph = {
getCountries$DataActRefresh: [],
getData$DataActRefresh: []
};
this.shouldSendClientVarsToDataSources = true;
}
// Server Actions

// Aggregates and Data Actions
Controller.prototype.getCountries$DataActRefresh = function (callContext) {
var model = this.model;
var controller = this.controller;
var callContext = controller.callContext(callContext);
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:orocSYa4Z0COixIHorScEg:/NRWebFlows.G6g8LlI0+UqpwXA+JmvtFg/NodesShownInESpaceTree.ovtS7TckN0qoV_dPp1DlxA/DataActions.orocSYa4Z0COixIHorScEg:xKeSGsd0qgAmHNACj5uhRg", "ShopperPortalEU", "GetCountries", "NRFlows.DataScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.setThreadStartName(callContext.id, "Profile/ScanPassport/GetCountries");
return controller.callDataAction("DataActionGetCountries", "screenservices/ShopperPortalEU/Profile/ScanPassport/DataActionGetCountries", "lI6MlJj7XlNy9+blzqKzeA", function (b) {
model.variables.getCountriesDataAct.dataFetchStatusAttr = b;
}, function (json) {
model.variables.getCountriesDataAct.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getCountriesDataAct.constructor));
}, undefined, OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, callContext, ShopperPortalEUClientVariables, false);

}, function () {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:orocSYa4Z0COixIHorScEg", callContext.id);
controller.popDebuggerContext(callContext);

});
};
Controller.prototype.getData$DataActRefresh = function (callContext) {
var model = this.model;
var controller = this.controller;
var callContext = controller.callContext(callContext);
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:Ucwe9W6xbk68TQixJC6a8A:/NRWebFlows.G6g8LlI0+UqpwXA+JmvtFg/NodesShownInESpaceTree.ovtS7TckN0qoV_dPp1DlxA/DataActions.Ucwe9W6xbk68TQixJC6a8A:A2SRrouVJ0GhYoYTxAAuIQ", "ShopperPortalEU", "GetData", "NRFlows.DataScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.setThreadStartName(callContext.id, "Profile/ScanPassport/GetData");
return controller.callDataAction("DataActionGetData", "screenservices/ShopperPortalEU/Profile/ScanPassport/DataActionGetData", "+x0VHQmd6OkD5cX3wjhdug", function (b) {
model.variables.getDataDataAct.dataFetchStatusAttr = b;
}, function (json) {
model.variables.getDataDataAct.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getDataDataAct.constructor));
}, undefined, OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, callContext, ShopperPortalEUClientVariables, false);

}, function () {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:Ucwe9W6xbk68TQixJC6a8A", callContext.id);
controller.popDebuggerContext(callContext);

});
};

Controller.prototype.dataFetchActionNames = ["getCountries$DataActRefresh", "getData$DataActRefresh"];
// Client Actions
Controller.prototype._onInitialize$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnInitialize");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:SZpgHVq24UC8KW9M26D9Ww:/NRWebFlows.G6g8LlI0+UqpwXA+JmvtFg/NodesShownInESpaceTree.ovtS7TckN0qoV_dPp1DlxA/ClientActions.SZpgHVq24UC8KW9M26D9Ww:T8sxmMbysnZ9a7H8O+aRKQ", "ShopperPortalEU", "OnInitialize", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:vTBFLPHv2Um9aRjRqr3AbQ", callContext.id);
// Reset data
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:DaZGrJuAyEGkfysQ8WgqmQ", callContext.id);
// ShowTips = False
model.variables.showTipsVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:DaZGrJuAyEGkfysQ8WgqmQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// IsScanLoaded = False
model.variables.isScanLoadedVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:DaZGrJuAyEGkfysQ8WgqmQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// ShopperPassportDataTemp = ""
ShopperPortalEUClientVariables.setShopperPassportDataTemp("");
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:DaZGrJuAyEGkfysQ8WgqmQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// EnterPassportManually = False
model.variables.enterPassportManuallyVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:DaZGrJuAyEGkfysQ8WgqmQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// PassportManualData.IssuingCountryCode = "0"
model.variables.passportManualDataVar.issuingCountryCodeAttr = "0";
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:8GuqN_nG60qp3NXjwremMg", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:SZpgHVq24UC8KW9M26D9Ww", callContext.id);
}

};
Controller.prototype._showTips$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("ShowTips");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:vNanIe+TP0anngcCa7rKxg:/NRWebFlows.G6g8LlI0+UqpwXA+JmvtFg/NodesShownInESpaceTree.ovtS7TckN0qoV_dPp1DlxA/ClientActions.vNanIe+TP0anngcCa7rKxg:Tqojh_SQCuL1wl21Jj3hKQ", "ShopperPortalEU", "ShowTips", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:w+5Xw_606kyVNxW1jsH+9g", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:tQptrgsmukSdTbadID_Sqw", callContext.id);
// ShowTips = True
model.variables.showTipsVar = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:sVUASN6WUk6fwhaeHHZBfg", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:vNanIe+TP0anngcCa7rKxg", callContext.id);
}

};
Controller.prototype._clearTimeout$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("ClearTimeout");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:kGGlLWwA4kqolQC8b0_yuw:/NRWebFlows.G6g8LlI0+UqpwXA+JmvtFg/NodesShownInESpaceTree.ovtS7TckN0qoV_dPp1DlxA/ClientActions.kGGlLWwA4kqolQC8b0_yuw:EwI0LItm3FybwlQoBvf6fQ", "ShopperPortalEU", "ClearTimeout", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:0np0thMJxUOuIcg1RKeyXw", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:lejBfH9LFEWKXuxKeSiW+w", callContext.id) && ((model.variables.timeoutVar) !== (OS.BuiltinFunctions.nullObject())))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:cm9A+oS_qk2Vf4WmM3m9Og", callContext.id);
controller.safeExecuteJSNode(ShopperPortalEU_Profile_ScanPassport_mvc_controller_ClearTimeout_ClearJS, "Clear", "ClearTimeout", {
Timeout: OS.DataConversion.JSNodeParamConverter.to(model.variables.timeoutVar, OS.DataTypes.DataTypes.Object)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:f0m4U4Tf0UWPlg2qACFwBw", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:f0m4U4Tf0UWPlg2qACFwBw", callContext.id);
}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:kGGlLWwA4kqolQC8b0_yuw", callContext.id);
}

};
Controller.prototype._redirectBack$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("RedirectBack");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:eb5ROaLBuEmQcv+pgkbNlA:/NRWebFlows.G6g8LlI0+UqpwXA+JmvtFg/NodesShownInESpaceTree.ovtS7TckN0qoV_dPp1DlxA/ClientActions.eb5ROaLBuEmQcv+pgkbNlA:_5KiuzfY4DuKqSll0F4AGw", "ShopperPortalEU", "RedirectBack", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Pf2epwlu0EGfPD6SSFz07g", callContext.id);
// Entry flow
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:+xgBLOjbpkaflt7u0joK9A", callContext.id) && (ShopperPortalEUClientVariables.getScanPassportRedirect() === 0))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Zi7jGB8X+EWzyq9Awgg8pA", callContext.id);
// Destination: /ShopperPortalEU/PassportDetails
return OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "PassportDetails", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true);
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:dw_FEHcnRUK8LbRckzBD6A", callContext.id);
// Destination: /ShopperPortalEU/Passports
return OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "Passports", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true);
}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:eb5ROaLBuEmQcv+pgkbNlA", callContext.id);
}

};
Controller.prototype._passportExpiryDateOnChange$Action = function (currentDateIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("PassportExpiryDateOnChange");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.Profile.ScanPassport.PassportExpiryDateOnChange$vars"))());
vars.value.currentDateInLocal = currentDateIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:vkz+hNo7oEmRD6+olNUWyw:/NRWebFlows.G6g8LlI0+UqpwXA+JmvtFg/NodesShownInESpaceTree.ovtS7TckN0qoV_dPp1DlxA/ClientActions.vkz+hNo7oEmRD6+olNUWyw:Wq9gMUJfzxNELOxxxtzqjw", "ShopperPortalEU", "PassportExpiryDateOnChange", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:kevlTFLVjU2WKRK0l4Ux_Q", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:5RMw_AJC80aVC23WPV_qPA", callContext.id);
// PassportManualData.DateOfExpiry = CurrentDate
model.variables.passportManualDataVar.dateOfExpiryAttr = vars.value.currentDateInLocal;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:3LUTY31N4UKdRtvTFp1g1g", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:vkz+hNo7oEmRD6+olNUWyw", callContext.id);
}

};
Controller.registerVariableGroupType("ShopperPortalEU.Profile.ScanPassport.PassportExpiryDateOnChange$vars", [{
name: "CurrentDate",
attrName: "currentDateInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Date,
defaultValue: function () {
return OS.DataTypes.DateTime.defaultValue;
}
}]);
Controller.prototype._setTimeout$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("SetTimeout");
callContext = controller.callContext(callContext);
var setTimeoutJSResult = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.setTimeoutJSResult = setTimeoutJSResult;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:8Csfh9CdJkqw1kcaZnZfxQ:/NRWebFlows.G6g8LlI0+UqpwXA+JmvtFg/NodesShownInESpaceTree.ovtS7TckN0qoV_dPp1DlxA/ClientActions.8Csfh9CdJkqw1kcaZnZfxQ:_j6BaF3UY4i7k4wGnPhhYw", "ShopperPortalEU", "SetTimeout", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:BHN9Z8Q_qUCFSpzD8cNOBw", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:6kywtAS7QEetdD46s7fbFA", callContext.id);
setTimeoutJSResult.value = controller.safeExecuteJSNode(ShopperPortalEU_Profile_ScanPassport_mvc_controller_SetTimeout_SetTimeoutJS, "SetTimeout", "SetTimeout", {
Timeout: OS.DataConversion.JSNodeParamConverter.to(null, OS.DataTypes.DataTypes.Object)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("ShopperPortalEU.Profile.ScanPassport.SetTimeout$setTimeoutJSResult"))();
jsNodeResult.timeoutOut = OS.DataConversion.JSNodeParamConverter.from($parameters.Timeout, OS.DataTypes.DataTypes.Object);
return jsNodeResult;
}, {
ShowTips: controller.clientActionProxies.showTips$Action
}, {});
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:uXcH_1G02Ee2GjS9kuCtZg", callContext.id);
// Timeout = SetTimeout.Timeout
model.variables.timeoutVar = setTimeoutJSResult.value.timeoutOut;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:_Ij1I2C4x0K7jHiw3JjfWw", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:8Csfh9CdJkqw1kcaZnZfxQ", callContext.id);
}

};
Controller.registerVariableGroupType("ShopperPortalEU.Profile.ScanPassport.SetTimeout$setTimeoutJSResult", [{
name: "Timeout",
attrName: "timeoutOut",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Object,
defaultValue: function () {
return null;
}
}]);
Controller.prototype._confirm$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Confirm");
callContext = controller.callContext(callContext);
var passportJSONVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.JSONSerializeOutputType());
varBag.callContext = callContext;
varBag.passportJSONVar = passportJSONVar;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:kxepiIwVJ0KxR66_7XXyfA:/NRWebFlows.G6g8LlI0+UqpwXA+JmvtFg/NodesShownInESpaceTree.ovtS7TckN0qoV_dPp1DlxA/ClientActions.kxepiIwVJ0KxR66_7XXyfA:jayGgXVHjemomca6vghV6Q", "ShopperPortalEU", "Confirm", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:E9XiSP6fW0KIWZePjTE5cQ", callContext.id);
// Valid
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ybmy5vgg8keFrFihkcSAgQ", callContext.id) && (((OS.BuiltinFunctions.dateTimeToDate(model.variables.passportManualDataVar.dateOfExpiryAttr).gt(OS.BuiltinFunctions.currDate()) && ((model.variables.passportManualDataVar.documentNumberAttr) !== (""))) && ((model.variables.passportManualDataVar.issuingCountryCodeAttr) !== (""))) && ((model.variables.passportManualDataVar.issuingCountryCodeAttr) !== ("0"))))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:qM4gINziYUmsQE5U_7U8iw", callContext.id);
// JSON Serialize: PassportJSON
passportJSONVar.value.jSONOut = OS.JSONUtils.serializeToJSON(model.variables.passportManualDataVar, false, false);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:mmwE0uprIEKbgI7Lu84wQQ", callContext.id);
// ShopperPassportDataTemp = PassportJSON.JSON
ShopperPortalEUClientVariables.setShopperPassportDataTemp(passportJSONVar.value.jSONOut);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:IJ42NdjHwkSqwY67I3EQaQ", callContext.id);
// Destination: /ShopperPortalEU/ConfirmPassport
return OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "ConfirmPassport", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true);
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:esOBe1A31EClAYOku6u5rQ", callContext.id);
// Execute Action: InvalidPassportMessage
ShopperPortalEU_UI_ThemeController.default.customMessageTrigger$Action(function () {
var rec = new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customMessageType.error;
rec.titleAttr = "Invalid passport data";
rec.testIdAttr = "ManuallyInvalidPassportDataMessage";
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:TTACr2c6yUuVzzo26ehSeg", callContext.id);
}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:kxepiIwVJ0KxR66_7XXyfA", callContext.id);
}

};
Controller.prototype._passportCountryOnChange$Action = function (currentCountryIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("PassportCountryOnChange");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.Profile.ScanPassport.PassportCountryOnChange$vars"))());
vars.value.currentCountryInLocal = currentCountryIn.clone();
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:99LZjdTHrESlukneUMa_nQ:/NRWebFlows.G6g8LlI0+UqpwXA+JmvtFg/NodesShownInESpaceTree.ovtS7TckN0qoV_dPp1DlxA/ClientActions.99LZjdTHrESlukneUMa_nQ:WsvKUre6kO1rN4AIT9RVEA", "ShopperPortalEU", "PassportCountryOnChange", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:w1_WUH5BU0ih7oH9QSpF3g", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:EWhCRkqiUEebOzx_Bb7wQQ", callContext.id);
// PassportManualData.IssuingCountryCode = CurrentCountry.Value
model.variables.passportManualDataVar.issuingCountryCodeAttr = vars.value.currentCountryInLocal.valueAttr;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:_uw3_nETWEKxV_oTAfk4XA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:99LZjdTHrESlukneUMa_nQ", callContext.id);
}

};
Controller.registerVariableGroupType("ShopperPortalEU.Profile.ScanPassport.PassportCountryOnChange$vars", [{
name: "CurrentCountry",
attrName: "currentCountryInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Record,
defaultValue: function () {
return new ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValueOptionsRec();
},
complexType: ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValueOptionsRec
}]);
Controller.prototype._scanPassportOnLoad$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("ScanPassportOnLoad");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:CnlPkas250OF912ovhCKeg:/NRWebFlows.G6g8LlI0+UqpwXA+JmvtFg/NodesShownInESpaceTree.ovtS7TckN0qoV_dPp1DlxA/ClientActions.CnlPkas250OF912ovhCKeg:Zm8NsBDC5wxa6mIet+hEUQ", "ShopperPortalEU", "ScanPassportOnLoad", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:k+zXfnne3EeE4g0hdmK7yg", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:suKJM4Trq0iQlWs4UnxDMQ", callContext.id);
// IsScanLoaded = True
model.variables.isScanLoadedVar = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:JM4B5BYXQ0K3nd8I+YyVoA", callContext.id);
// Execute Action: SetTimeout
controller._setTimeout$Action(callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:YiFO8iaoBUqJIYrfShAPJQ", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:CnlPkas250OF912ovhCKeg", callContext.id);
}

};
Controller.prototype._okCameraBlockedPopup$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OkCameraBlockedPopup");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:ZR2lnKUxV0OOvFgVtT+zRA:/NRWebFlows.G6g8LlI0+UqpwXA+JmvtFg/NodesShownInESpaceTree.ovtS7TckN0qoV_dPp1DlxA/ClientActions.ZR2lnKUxV0OOvFgVtT+zRA:7LX150svLzhXIUBXio56wQ", "ShopperPortalEU", "OkCameraBlockedPopup", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:LaHQ+ZLx5EOKhU1R7D8NyA", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:KIdNidZKJkijzvLPDFLnng", callContext.id);
// ShowCameraBlockedPopup = False
model.variables.showCameraBlockedPopupVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:LDMsWc4l7Ei0dp+u02Wlpw", callContext.id);
// Execute Action: RedirectBack
controller._redirectBack$Action(callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:hhqgLlVmBkWwzDrjJ+NEvw", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:ZR2lnKUxV0OOvFgVtT+zRA", callContext.id);
}

};
Controller.prototype._onDestroy$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnDestroy");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:AbHWrxwQZUaS_ML2DIq6GA:/NRWebFlows.G6g8LlI0+UqpwXA+JmvtFg/NodesShownInESpaceTree.ovtS7TckN0qoV_dPp1DlxA/ClientActions.AbHWrxwQZUaS_ML2DIq6GA:JeCNLeJKfwmBX6xrpEKcoA", "ShopperPortalEU", "OnDestroy", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:eYc1mj_ZPkKdJhRb_emF1w", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:03Oc_lXCgUi03ylUXlJu7A", callContext.id);
// Execute Action: ClearTimeout
controller._clearTimeout$Action(callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:thCdEcX6VUyIuiQXnWqNDg", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:AbHWrxwQZUaS_ML2DIq6GA", callContext.id);
}

};
Controller.prototype._closeOnClick$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("CloseOnClick");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:4fHwwmLZhUuCW6TrITIdUQ:/NRWebFlows.G6g8LlI0+UqpwXA+JmvtFg/NodesShownInESpaceTree.ovtS7TckN0qoV_dPp1DlxA/ClientActions.4fHwwmLZhUuCW6TrITIdUQ:4PhpruiZwOBR2_niBQbIpg", "ShopperPortalEU", "CloseOnClick", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:sotzztvp1keIARazYnETsA", callContext.id);
// Reset passport data
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:wJ8KsxSv4ECf5NDFJe1EOw", callContext.id);
// ShopperPassportDataTemp = ""
ShopperPortalEUClientVariables.setShopperPassportDataTemp("");
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:TCB1neTg1kOh2Mu6Qw+Rjw", callContext.id);
// Execute Action: ClearTimeout
controller._clearTimeout$Action(callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:BLRCWbYw6Ey7reKMVo9TFg", callContext.id);
// Execute Action: ClarityEvent
ShopperPortalEUController.default.clarityEvent$Action("CloseScanPassport_btn", callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:46nYTkTXDEqCJ73L7K128w", callContext.id);
// Execute Action: RedirectBack
controller._redirectBack$Action(callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:RQBy5xjfg0q+5xmnmcxvmw", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:4fHwwmLZhUuCW6TrITIdUQ", callContext.id);
}

};
Controller.prototype._scanPassportOnError$Action = function (dataIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("ScanPassportOnError");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.Profile.ScanPassport.ScanPassportOnError$vars"))());
vars.value.dataInLocal = dataIn.clone();
var getOSVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.vars = vars;
varBag.getOSVar = getOSVar;
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:OZkF0qEipEOdc5kmvJ9mYA:/NRWebFlows.G6g8LlI0+UqpwXA+JmvtFg/NodesShownInESpaceTree.ovtS7TckN0qoV_dPp1DlxA/ClientActions.OZkF0qEipEOdc5kmvJ9mYA:0M+VQ9NUN8_yRkWREcS_+w", "ShopperPortalEU", "ScanPassportOnError", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:9J7VgLbRBkKT9YUnN79zUg", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:x1Vc9mtec0yuoZJHaDXKMg", callContext.id);
// IsScanLoaded = True
model.variables.isScanLoadedVar = true;
// Reset passport data
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:FImaejZNAES7KVyvjE3cPw", callContext.id);
// ShopperPassportDataTemp = ""
ShopperPortalEUClientVariables.setShopperPassportDataTemp("");
// Valid document
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:70nlZXaN3ESA3mgwwwOrSw", callContext.id) && ((vars.value.dataInLocal.codeAttr) !== ("0")))) {
// Camera allowed ?
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:xXSJGo0kt0qnWyQoSf78DQ", callContext.id) && ((vars.value.dataInLocal.codeAttr) !== ("1")))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:s3U50SxPNUWGOKe2XjMQzg", callContext.id);
// Execute Action: ErrorMessage
ShopperPortalEU_UI_ThemeController.default.customMessageTrigger$Action(function () {
var rec = new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customMessageType.error;
rec.titleAttr = "Error scanning passport.";
rec.contentAttr = OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.defaultErrorMessage$Action(callContext).errorMessageOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:JbBiFw1oukyVNlxLSiRtAA", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:qSYAvygSNECPJU6h+e48tQ", callContext.id);
// Execute Action: GetOS
getOSVar.value = ShopperPortalEU_UI_ComponentsController.default.getOS$Action(callContext);

OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:LkELN7tua0GLYgtAbYvk_g", callContext.id);
// ShowCameraBlockedPopup = notGetOS.OS.OS.Name = "ios" or GetOS.OS.OS.Name = "macos"
model.variables.showCameraBlockedPopupVar = !(((getOSVar.value.oSOut.oSAttr.nameAttr === "ios") || (getOSVar.value.oSOut.oSAttr.nameAttr === "macos")));
// Show popup
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:Qw5bi52vNEihs6NORaj9YQ", callContext.id) && model.variables.showCameraBlockedPopupVar)) {
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:iscS_giJZEilVJjNlUhxbw", callContext.id) && model.variables.getDataDataAct.isDemoEnvironmentOut)) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:jxzTf0gcEUiph_TKpk0yuA", callContext.id);
// Execute Action: CustomMessageTrigger
ShopperPortalEU_UI_ThemeController.default.customMessageTrigger$Action(function () {
var rec = new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customMessageType.info;
rec.titleAttr = "Camera blocked";
rec.contentAttr = "This message only appears in demo environments.";
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:nA8Hq0pUhEa8_vCizjabiA", callContext.id);
// Execute Action: TogglePassportManually
return controller._togglePassportManually$Action(callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:BMtwuZSsREWe+6NaRhvqYA", callContext.id);
});
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:BMtwuZSsREWe+6NaRhvqYA", callContext.id);
}

});
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:jieM3C0FlUOY3mfWq0aPhQ", callContext.id);
// Execute Action: RedirectBack
controller._redirectBack$Action(callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:BMtwuZSsREWe+6NaRhvqYA", callContext.id);
}

});
}

});
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ADE1RGYbukCMcoGrz2vQNw", callContext.id);
// Execute Action: InvalidDocumentError
ShopperPortalEU_UI_ThemeController.default.customMessageTrigger$Action(function () {
var rec = new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customMessageType.error;
rec.titleAttr = "Only passports can be scanned.";
rec.contentAttr = OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.defaultErrorMessage$Action(callContext).errorMessageOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
rec.testIdAttr = "InvalidDocumentErrorMessage";
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:1WbhzNvAQU6lrhLzjJjtlQ", callContext.id);
}

});
}).then(function (res) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:OZkF0qEipEOdc5kmvJ9mYA", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:OZkF0qEipEOdc5kmvJ9mYA", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("ShopperPortalEU.Profile.ScanPassport.ScanPassportOnError$vars", [{
name: "Data",
attrName: "dataInLocal",
mandatory: false,
dataType: OS.DataTypes.DataTypes.Record,
defaultValue: function () {
return new ShopperPortalEU_UI_ComponentsModel.ScanPassportErrorRec();
},
complexType: ShopperPortalEU_UI_ComponentsModel.ScanPassportErrorRec
}]);
Controller.prototype._scanPassportOnResult$Action = function (dataIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("ScanPassportOnResult");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.Profile.ScanPassport.ScanPassportOnResult$vars"))());
vars.value.dataInLocal = dataIn.clone();
var formatPassportDataVar = new OS.DataTypes.VariableHolder();
var passportToJSONVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.JSONSerializeOutputType());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.formatPassportDataVar = formatPassportDataVar;
varBag.passportToJSONVar = passportToJSONVar;
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:h9tk1DfmmEq0GA_qpaWLkw:/NRWebFlows.G6g8LlI0+UqpwXA+JmvtFg/NodesShownInESpaceTree.ovtS7TckN0qoV_dPp1DlxA/ClientActions.h9tk1DfmmEq0GA_qpaWLkw:UftH56+I_yWODGQyP9gIbg", "ShopperPortalEU", "ScanPassportOnResult", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:y+i6d6hnU0+uQEuqYvIHtQ", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:GpmqkjLh5UyKcY3VCHsIbA", callContext.id);
// ShowTips = False
model.variables.showTipsVar = false;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:FAuQ0qEVoEKGx2ewICDsdQ", callContext.id);
// Execute Action: ClearTimeout
controller._clearTimeout$Action(callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:d0V2R_ZM_0qoUBO8AZtevQ", callContext.id);
// Execute Action: FormatPassportData
model.flush();
return ShopperPortalEUController.default.formatPassportData$Action(vars.value.dataInLocal, callContext).then(function (value) {
formatPassportDataVar.value = value;
}).then(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:bT9h_pNF3EaTTknv6ykzVg", callContext.id);
// JSON Serialize: PassportToJSON
passportToJSONVar.value.jSONOut = OS.JSONUtils.serializeToJSON(formatPassportDataVar.value.formattedPassportOut, false, false);
// ShopperPassportDataTemp & IsToFetchShopperDetails
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:WcLa5Zcs70yZSfTUlohicA", callContext.id);
// ShopperPassportDataTemp = PassportToJSON.JSON
ShopperPortalEUClientVariables.setShopperPassportDataTemp(passportToJSONVar.value.jSONOut);
}).then(function () {
// Valid expiry date
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:kR7Y_yY530CwPBL95wNjAA", callContext.id) && OS.BuiltinFunctions.dateTimeToDate(vars.value.dataInLocal.dateOfExpiryAttr).gt(OS.BuiltinFunctions.currDate()))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:5fvyewmWakCjKLqTCxWAsQ", callContext.id);
// Execute Action: CustomMessageHide
ShopperPortalEU_UI_ThemeController.default.customMessageHide$Action(false, callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:3QvEcCpGi0iv4sJT6twUrw", callContext.id);
// Destination: /ShopperPortalEU/ConfirmPassport
return OS.Flow.returnAsync(OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("ShopperPortalEU", "ConfirmPassport", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true));
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:l89QAxCSmkq9cX8SDhv_LA", callContext.id);
// Execute Action: ClarityEvent
ShopperPortalEUController.default.clarityEvent$Action("PassportExpired_error", callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:3SE50NoXC0KAJI9RMe4Rmw", callContext.id);
// Execute Action: DateOfExpiryMessage
ShopperPortalEU_UI_ThemeController.default.customMessageTrigger$Action(function () {
var rec = new ShopperPortalEU_UI_ThemeModel.CustomMessageOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customMessageType.error;
rec.titleAttr = "Passport expired";
rec.contentAttr = (("Your passport expired on " + OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.formatDate$Action(OS.BuiltinFunctions.dateTimeToDate(vars.value.dataInLocal.dateOfExpiryAttr), callContext).formattedDateOut;
}, OS.DataTypes.DataTypes.Text, callContext.id)) + ".<br>Use a valid passport to continue.");
rec.testIdAttr = "PassportExpiredErrorMessage";
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:F9hL68m_pkeMgsgbU7+P9A", callContext.id);
}

});
}).then(function (res) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:h9tk1DfmmEq0GA_qpaWLkw", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:h9tk1DfmmEq0GA_qpaWLkw", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("ShopperPortalEU.Profile.ScanPassport.ScanPassportOnResult$vars", [{
name: "Data",
attrName: "dataInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Record,
defaultValue: function () {
return new ShopperPortalEU_UI_ComponentsModel.ScanPassportDataRec();
},
complexType: ShopperPortalEU_UI_ComponentsModel.ScanPassportDataRec
}]);
Controller.prototype._togglePassportManually$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("TogglePassportManually");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:pILr7udBskOIZjOvFUVoCw:/NRWebFlows.G6g8LlI0+UqpwXA+JmvtFg/NodesShownInESpaceTree.ovtS7TckN0qoV_dPp1DlxA/ClientActions.pILr7udBskOIZjOvFUVoCw:jl+01QYR+1l7hI4WYbwJRg", "ShopperPortalEU", "TogglePassportManually", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:aph237v3bUawJtsDe4_izQ", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:P6dPNXgsfEy2LnEKccZsHw", callContext.id);
// EnterPassportManually = notEnterPassportManually
model.variables.enterPassportManuallyVar = !(model.variables.enterPassportManuallyVar);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:P6dPNXgsfEy2LnEKccZsHw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// IsScanLoaded = False
model.variables.isScanLoadedVar = false;
// Get countries ?
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:1ru+qGAtO0WobS8RKVQAJA", callContext.id) && (model.variables.enterPassportManuallyVar && model.variables.getCountriesDataAct.countriesOut.isEmpty))) {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:DsgsjVCVH02zQk4z_9AhVQ", callContext.id);
// Refresh Query: GetCountries
var result = controller.getCountries$DataActRefresh(callContext);
model.flush();
return result.then(function () {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:amUsQmRFa0GO+lvoDhi0BQ", callContext.id);
});
} else {
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:2r3_s5Og1k2mmiE3PrQhgw", callContext.id);
}

});
}).then(function (res) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:pILr7udBskOIZjOvFUVoCw", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:pILr7udBskOIZjOvFUVoCw", callContext.id);
throw ex;

});
};

Controller.prototype.onInitialize$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onInitialize$Action, callContext);

};
Controller.prototype.showTips$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._showTips$Action, callContext);

};
Controller.prototype.clearTimeout$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._clearTimeout$Action, callContext);

};
Controller.prototype.redirectBack$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._redirectBack$Action, callContext);

};
Controller.prototype.passportExpiryDateOnChange$Action = function (currentDateIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._passportExpiryDateOnChange$Action, callContext, currentDateIn);

};
Controller.prototype.setTimeout$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._setTimeout$Action, callContext);

};
Controller.prototype.confirm$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._confirm$Action, callContext);

};
Controller.prototype.passportCountryOnChange$Action = function (currentCountryIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._passportCountryOnChange$Action, callContext, currentCountryIn);

};
Controller.prototype.scanPassportOnLoad$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._scanPassportOnLoad$Action, callContext);

};
Controller.prototype.okCameraBlockedPopup$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._okCameraBlockedPopup$Action, callContext);

};
Controller.prototype.onDestroy$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onDestroy$Action, callContext);

};
Controller.prototype.closeOnClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._closeOnClick$Action, callContext);

};
Controller.prototype.scanPassportOnError$Action = function (dataIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._scanPassportOnError$Action, callContext, dataIn);

};
Controller.prototype.scanPassportOnResult$Action = function (dataIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._scanPassportOnResult$Action, callContext, dataIn);

};
Controller.prototype.togglePassportManually$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._togglePassportManually$Action, callContext);

};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:G6g8LlI0+UqpwXA+JmvtFg:/NRWebFlows.G6g8LlI0+UqpwXA+JmvtFg:yposeKjmRCh6Km0A8t9bYg", "ShopperPortalEU", "Profile", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:ovtS7TckN0qoV_dPp1DlxA:/NRWebFlows.G6g8LlI0+UqpwXA+JmvtFg/NodesShownInESpaceTree.ovtS7TckN0qoV_dPp1DlxA:IOcKsLy89VIYpKc9j9jOzA", "ShopperPortalEU", "ScanPassport", "NRNodes.WebScreen", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:ovtS7TckN0qoV_dPp1DlxA", callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:G6g8LlI0+UqpwXA+JmvtFg", callContext.id);
};
Controller.prototype.onInitializeEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Profile/ScanPassport On Initialize");
return controller.onInitialize$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Profile/ScanPassport On Destroy");
return controller.onDestroy$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return ShopperPortalEU_ProfileController.default.handleError(ex, this.callContext());
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return ShopperPortalEUController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, ShopperPortalEULanguageResources);
});
define("ShopperPortalEU.Profile.ScanPassport.mvc$controller.ClearTimeout.ClearJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
clearTimeout($parameters.Timeout);
};
});
define("ShopperPortalEU.Profile.ScanPassport.mvc$controller.SetTimeout.SetTimeoutJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.Timeout = setTimeout($actions.ShowTips,10000);
};
});

define("ShopperPortalEU.Profile.ScanPassport.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"cm9A+oS_qk2Vf4WmM3m9Og": {
getter: function (varBag, idService) {
return varBag.clearJSResult.value;
}
},
"ELUECYYcFUyIyuAN1rvzaA": {
getter: function (varBag, idService) {
return varBag.vars.value.currentDateInLocal;
},
dataType: OS.DataTypes.DataTypes.Date
},
"6kywtAS7QEetdD46s7fbFA": {
getter: function (varBag, idService) {
return varBag.setTimeoutJSResult.value;
}
},
"qM4gINziYUmsQE5U_7U8iw": {
getter: function (varBag, idService) {
return varBag.passportJSONVar.value;
}
},
"jg8WYv1V+kmdS6k8jKgZxQ": {
getter: function (varBag, idService) {
return varBag.vars.value.currentCountryInLocal;
}
},
"ptt8mXuI_k+s55lku4aP8w": {
getter: function (varBag, idService) {
return varBag.vars.value.dataInLocal;
}
},
"qSYAvygSNECPJU6h+e48tQ": {
getter: function (varBag, idService) {
return varBag.getOSVar.value;
}
},
"r_l0fDmeoU6iZFPhst9Jog": {
getter: function (varBag, idService) {
return varBag.vars.value.dataInLocal;
}
},
"d0V2R_ZM_0qoUBO8AZtevQ": {
getter: function (varBag, idService) {
return varBag.formatPassportDataVar.value;
}
},
"bT9h_pNF3EaTTknv6ykzVg": {
getter: function (varBag, idService) {
return varBag.passportToJSONVar.value;
}
},
"qgGjHyq2ok6a1oQclKSRSg": {
getter: function (varBag, idService) {
return varBag.model.variables.showTipsVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"Lq9aBzdEmU2u6_1wsj3S2A": {
getter: function (varBag, idService) {
return varBag.model.variables.timeoutVar;
},
dataType: OS.DataTypes.DataTypes.Object
},
"TwJLt1mkVUetpwFt6MMukA": {
getter: function (varBag, idService) {
return varBag.model.variables.isScanLoadedVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"Oj0mQ+cBX0i_5GUqvYyCvg": {
getter: function (varBag, idService) {
return varBag.model.variables.showCameraBlockedPopupVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"UcMnBlfOT0y92rsI6q87rw": {
getter: function (varBag, idService) {
return varBag.model.variables.enterPassportManuallyVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"pv+N6IaB_kGl2HVL8BQSOA": {
getter: function (varBag, idService) {
return varBag.model.variables.passportManualDataVar;
}
},
"orocSYa4Z0COixIHorScEg": {
getter: function (varBag, idService) {
return varBag.model.variables.getCountriesDataAct;
}
},
"Ucwe9W6xbk68TQixJC6a8A": {
getter: function (varBag, idService) {
return varBag.model.variables.getDataDataAct;
}
},
"uNo3tE4bQU+xZdAePuDdqA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderLeft"));
})(varBag.model, idService);
}
},
"y_fRGA_EZkqmr3NdCFoS5g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderCenter"));
})(varBag.model, idService);
}
},
"whV2ccHZ7U6AM03H5Dm2sA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderRight"));
})(varBag.model, idService);
}
},
"xRccanblFkKWxAm5W7Keow": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("AddPassportFlow"));
})(varBag.model, idService);
}
},
"DlqvTyVsXEeJpKITIlfA2w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Button"));
})(varBag.model, idService);
}
},
"_G9vW6uczEylji+QmirqXQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"XT1Ywr23wE+3CfKrwAdgDw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"ApEbnbGg5kWA4FlZTYBKrQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"Wb4fiTnHDEuOp8DoslHEwg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Top"));
})(varBag.model, idService);
}
},
"hKDXCiOhjk+AZ64jRQkscA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"a9hIdoCr+0u12TV0B231bA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Image"));
})(varBag.model, idService);
}
},
"cmeizikMy0Kvmdj_5Nn_eg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"ca+Efwco8kmDQuPQXkdOUA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"M6nj77xfJka4UusOibL5aA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"ijlP_K8W8Ee7PhhZgyXekw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"+lNhQZOn6UG98nR5U7gX7w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Popup"));
})(varBag.model, idService);
}
},
"9l9JbN4btECdreTSOG96uQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"1vH7RJ3fPkWnF65kDmQedg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"aC8o7IPgTkaVWS86i0deNw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Actions"));
})(varBag.model, idService);
}
},
"02kxF4oDjU+KLzd3Nj0ygQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"xUd7nQvc5UCxIBXqXpnmvw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Button"));
})(varBag.model, idService);
}
},
"DXkoU3kRZU6qWDgQdJ2edg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"_kFNNNL3Lk6AIYz4ZqLpKg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"5ipff+ckOEC3OTosziH+uw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Label"));
})(varBag.model, idService);
}
},
"xUG5sAQrC0K8RXif_0gWUQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input"));
})(varBag.model, idService);
}
},
"4GKx5fIwt0iXhLce+b_pFA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input_PassportNumber"));
})(varBag.model, idService);
}
},
"mVJ6G+jioUSgYwxIZx9ilA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Description"));
})(varBag.model, idService);
}
},
"9bPHxza0k0eS6chNh2f2aw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Label"));
})(varBag.model, idService);
}
},
"DsCOph02YkmlnPfnnhtojQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Label"));
})(varBag.model, idService);
}
},
"QUKaHo0l1E+Qlsc6afACoQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Bottom"));
})(varBag.model, idService);
}
},
"wirZKDdvKUiLxE_v8BATrw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"otXn+w7kWUeTISGmNR_bGQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Button"));
})(varBag.model, idService);
}
},
"7jepWlK6wUuORCeqos0zWw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"PPBZTWQRb0uMM0FkqBy4gg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Button"));
})(varBag.model, idService);
}
},
"3BdkpEoFpk65fwLvCWKCFA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"RaYO5SpBWkCwl3HkJ_318A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Bottom"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
