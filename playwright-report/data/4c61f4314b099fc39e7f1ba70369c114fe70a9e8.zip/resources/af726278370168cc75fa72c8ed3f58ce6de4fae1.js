define("ShopperPortalEU.Support.CountryRules.mvc$model", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_API.model", "ShopperPortalEU.Layouts.Layout.mvc$model", "ShopperPortalEU.LayoutsComponents.Menu.mvc$model", "ShopperPortalEU.LayoutsComponents.ApplicationHeader.mvc$model", "ShopperPortalEU.Common.DataLoading.mvc$model", "ShopperPortalEU.Common.CountryDropdown.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomAlert.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.Flex.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCard.mvc$model", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomSeparator.mvc$model", "ShopperPortalEU.controller$TRuleWrapper", "ShopperPortalEU_UI_Components.model$CustomDropdownListValueOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Theme.model$LayoutOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$LayoutHeaderOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU.model$ApplicationHeaderRec", "ShopperPortalEU.model$CountriesWithFlagsDropdownListList", "ShopperPortalEU_UI_Components.model$CustomDropdownListValidationOptionsRec", "ShopperPortalEU_UI_Components.model$CustomAlertOptionsRec", "ShopperPortalEU_UI_Components.model$CustomAlertIconOptionsRec", "ShopperPortalEU_UI_Components.model$FlexOptionsRec", "ShopperPortalEU_UI_Components.model$CustomCardOptionsRec", "ShopperPortalEU_UI_Components.model$CustomSeparatorOptionsRec", "ShopperPortalEU_UI_Components.model$CustomSeparatorLabelOptionsRec", "ShopperPortalEU_API.model$SPCountry_WrapperRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_API", "ShopperPortalEU.model$SPCountry_WrapperList", "ShopperPortalEU_API.model$Location_WrapperRec"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_APIModel, ShopperPortalEU_Layouts_Layout_mvcModel, ShopperPortalEU_LayoutsComponents_Menu_mvcModel, ShopperPortalEU_LayoutsComponents_ApplicationHeader_mvcModel, ShopperPortalEU_Common_DataLoading_mvcModel, ShopperPortalEU_Common_CountryDropdown_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomAlert_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCard_mvcModel, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomSeparator_mvcModel) {
var OS = OutSystems.Internal;

var GetCountriesAndUserLocationDataActRec = (function (_super) {
__extends(GetCountriesAndUserLocationDataActRec, _super);
function GetCountriesAndUserLocationDataActRec(defaults) {
_super.apply(this, arguments);
}
GetCountriesAndUserLocationDataActRec.attributesToDeclare = function () {
return [
this.attr("EUCountryList", "eUCountryListOut", "EUCountryList", true, false, OS.DataTypes.DataTypes.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEUModel.SPCountry_WrapperList());
}, true, ShopperPortalEUModel.SPCountry_WrapperList), 
this.attr("Location", "locationOut", "Location", true, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_APIModel.Location_WrapperRec());
}, true, ShopperPortalEU_APIModel.Location_WrapperRec), 
this.attr("IP", "iPOut", "IP", true, false, OS.DataTypes.DataTypes.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
GetCountriesAndUserLocationDataActRec.init();
return GetCountriesAndUserLocationDataActRec;
})(OS.Model.DataSourceRecord);

var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("CountrySelected", "countrySelectedVar", "CountrySelected", true, false, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValueOptionsRec());
}, false, ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValueOptionsRec), 
this.attr("IsScreenReady", "isScreenReadyVar", "IsScreenReady", true, false, OS.DataTypes.DataTypes.Boolean, function () {
return false;
}, false), 
this.attr("GetCountriesAndUserLocation", "getCountriesAndUserLocationDataAct", "getCountriesAndUserLocationDataAct", true, true, OS.DataTypes.DataTypes.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new GetCountriesAndUserLocationDataActRec());
}, true, GetCountriesAndUserLocationDataActRec)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Model._hasValidationWidgetsValue = undefined;
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
if((Model._hasValidationWidgetsValue === undefined)) {
Model._hasValidationWidgetsValue = ((((((((ShopperPortalEU_Layouts_Layout_mvcModel.hasValidationWidgets || ShopperPortalEU_LayoutsComponents_Menu_mvcModel.hasValidationWidgets) || ShopperPortalEU_LayoutsComponents_ApplicationHeader_mvcModel.hasValidationWidgets) || ShopperPortalEU_Common_DataLoading_mvcModel.hasValidationWidgets) || ShopperPortalEU_Common_CountryDropdown_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomAlert_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCard_mvcModel.hasValidationWidgets) || ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomSeparator_mvcModel.hasValidationWidgets);
}

return Model._hasValidationWidgetsValue;
}
});

Model.prototype.setInputs = function (inputs) {
};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "Support.CountryRules");
});
define("ShopperPortalEU.Support.CountryRules.mvc$view", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_API.model", "react", "OutSystems/ReactView/Main", "ShopperPortalEU.Support.CountryRules.mvc$model", "ShopperPortalEU.Support.CountryRules.mvc$controller", "ShopperPortalEU.clientVariables", "ShopperPortalEU.Layouts.Layout.mvc$view", "OutSystems/ReactWidgets/Main", "ShopperPortalEU.LayoutsComponents.Menu.mvc$view", "ShopperPortalEU.LayoutsComponents.ApplicationHeader.mvc$view", "ShopperPortalEU.Common.DataLoading.mvc$view", "ShopperPortalEU.Common.CountryDropdown.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomAlert.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.Flex.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomCard.mvc$view", "ShopperPortalEU_UI_Components.ShopperPortalEUUIComponents.CustomSeparator.mvc$view", "ShopperPortalEU.controller$TRuleWrapper", "ShopperPortalEU_UI_Components.model$CustomDropdownListValueOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Theme.model$LayoutOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$LayoutHeaderOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU.model$ApplicationHeaderRec", "ShopperPortalEU.model$CountriesWithFlagsDropdownListList", "ShopperPortalEU_UI_Components.model$CustomDropdownListValidationOptionsRec", "ShopperPortalEU_UI_Components.model$CustomAlertOptionsRec", "ShopperPortalEU_UI_Components.model$CustomAlertIconOptionsRec", "ShopperPortalEU_UI_Components.model$FlexOptionsRec", "ShopperPortalEU_UI_Components.model$CustomCardOptionsRec", "ShopperPortalEU_UI_Components.model$CustomSeparatorOptionsRec", "ShopperPortalEU_UI_Components.model$CustomSeparatorLabelOptionsRec", "ShopperPortalEU_API.model$SPCountry_WrapperRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_API", "ShopperPortalEU.model$SPCountry_WrapperList", "ShopperPortalEU_API.model$Location_WrapperRec"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_APIModel, React, OSView, ShopperPortalEU_Support_CountryRules_mvc_model, ShopperPortalEU_Support_CountryRules_mvc_controller, ShopperPortalEUClientVariables, ShopperPortalEU_Layouts_Layout_mvc_view, OSWidgets, ShopperPortalEU_LayoutsComponents_Menu_mvc_view, ShopperPortalEU_LayoutsComponents_ApplicationHeader_mvc_view, ShopperPortalEU_Common_DataLoading_mvc_view, ShopperPortalEU_Common_CountryDropdown_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomAlert_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCard_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomSeparator_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            var thisIsInstanceOfSuper = this instanceof _super;
            if (thisIsInstanceOfSuper == false) {
                return;
            }

            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "Support.CountryRules";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css", "css/ShopperPortalEU_UI_Theme.ShopperPortalEUUITheme.css", "css/ShopperPortalEU.ShopperPortalEU.css", "css/ShopperPortalEU_UI_Theme.ShopperPortalEUUITheme.extra.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [ShopperPortalEU_Layouts_Layout_mvc_view, ShopperPortalEU_LayoutsComponents_Menu_mvc_view, ShopperPortalEU_LayoutsComponents_ApplicationHeader_mvc_view, ShopperPortalEU_Common_DataLoading_mvc_view, ShopperPortalEU_Common_CountryDropdown_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomAlert_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCard_mvc_view, ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomSeparator_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return ShopperPortalEU_Support_CountryRules_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return ShopperPortalEU_Support_CountryRules_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "Shopper Portal EU - Country rules";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(ShopperPortalEU_Layouts_Layout_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "0",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
headerLeft: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_LayoutsComponents_Menu_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "1",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}),
headerCenter: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_LayoutsComponents_ApplicationHeader_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("bkI7WDuMEECz3dSZ1fkSNQ.Options"), function () {
return function () {
var rec = new ShopperPortalEUModel.ApplicationHeaderRec();
rec.scrollTitleAttr = "Country rules";
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "2",
alias: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}),
headerRight: PlaceholderContent.Empty,
headerBottom: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "heading6 text-align-center",
visible: true,
_idProps: {
service: idService,
uuid: "3"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "CountryRulesTitle"
},
value: "Country rules",
_idProps: {
service: idService,
uuid: "4"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
}),
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_Common_DataLoading_mvc_view, {
inputs: {
IsDataFetched: model.variables.isScreenReadyVar
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "5",
alias: "4"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(ShopperPortalEU_Common_CountryDropdown_mvc_view, {
inputs: {
List: model.getCachedValue(idService.getId("onKLpkWWUE+d0BEleu10+w.List"), function () {
return OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.getCountriesAndUserLocationDataAct.eUCountryListOut, new ShopperPortalEUModel.CountriesWithFlagsDropdownListList(), function (source, target) {
target.flagAttr = source.code2Attr;
target.valueAttr = source.code2Attr;
target.nameAttr = source.nameAttr;
return target;
});
}, function () {
return model.variables.getCountriesAndUserLocationDataAct.eUCountryListOut;
}),
_listInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getCountriesAndUserLocationDataAct.dataFetchStatusAttr),
TestId: "CountryRuleDropdown",
OpenedLabel: "Select country",
Selected: model.variables.countrySelectedVar.valueAttr,
Validation: model.getCachedValue(idService.getId("onKLpkWWUE+d0BEleu10+w.Validation"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValidationOptionsRec();
return rec;
}();
}),
NativeLabel: "Country"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onChange$Action: function (currentCountryIn) {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common/CountryDropdown OnChange");
controller.countryOnChange$Action(currentCountryIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "6",
alias: "5"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
label: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: "Country",
_idProps: {
service: idService,
uuid: "7"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}), $if(((OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("countryRule_tips1", model.variables.countrySelectedVar.valueAttr, callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id)) !== ("")), false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomAlert_mvc_view, {
inputs: {
ExtendedClass: "margin-top-04",
Options: model.getCachedValue(idService.getId("hF1MOWXSyEej7+TJz_ur2A.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomAlertOptionsRec();
rec.typeAttr = ShopperPortalEUModel.staticEntities.customAlertType.info;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "8",
alias: "6"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
title: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "Tips"
},
value: "Tips",
_idProps: {
service: idService,
uuid: "9"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "countryRule_tips1"
},
value: model.getCachedValue(idService.getId("xrR5IbgEyUe0vjwkqsM2lg.Value"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("countryRule_tips1", model.variables.countrySelectedVar.valueAttr, callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
}, function () {
return model.variables.countrySelectedVar.valueAttr;
}),
_idProps: {
service: idService,
uuid: "10"
},
_widgetRecordProvider: widgetsRecordProvider
}), $if(((OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("countryRule_tips2", model.variables.countrySelectedVar.valueAttr, callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id)) !== ("")), false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
ExtendedClass: "margin-top-01",
Options: model.getCachedValue(idService.getId("7Z_89ltV1kiKcZZ+DlojLw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.justifyAttr = ShopperPortalEUModel.staticEntities.flexJustify.spaceBetween;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space1;
rec.wrapAttr = false;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "11",
alias: "7"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "countryRule_tips2"
},
value: model.getCachedValue(idService.getId("+KcTmkwSf0uag2vQt0F97A.Value"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("countryRule_tips2", model.variables.countrySelectedVar.valueAttr, callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
}, function () {
return model.variables.countrySelectedVar.valueAttr;
}),
_idProps: {
service: idService,
uuid: "12"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.countrySelectedVar.valueAttr)]
})];
}, function () {
return [];
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.countrySelectedVar.valueAttr)]
})];
}, function () {
return [];
}), $if(((((OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("countryRule_currency", model.variables.countrySelectedVar.valueAttr, callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id)) !== ("")) || ((OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("countryRule_vatRate1", model.variables.countrySelectedVar.valueAttr, callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id)) !== (""))) || ((OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("countryRule_minSpend1", model.variables.countrySelectedVar.valueAttr, callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id)) !== (""))), false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCard_mvc_view, {
inputs: {
ExtendedClass: "margin-top-04"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "13",
alias: "8"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [$if(((OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("countryRule_currency", model.variables.countrySelectedVar.valueAttr, callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id)) !== ("")), false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "heading6",
visible: true,
_idProps: {
service: idService,
uuid: "14"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "Currency"
},
value: "Currency",
_idProps: {
service: idService,
uuid: "15"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "body-4 margin-top-01",
visible: true,
_idProps: {
service: idService,
uuid: "16"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "countryRule_currency"
},
value: model.getCachedValue(idService.getId("eLEE1A0ijkKCP+eaWAGWCA.Value"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("countryRule_currency", model.variables.countrySelectedVar.valueAttr, callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
}, function () {
return model.variables.countrySelectedVar.valueAttr;
}),
_idProps: {
service: idService,
uuid: "17"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomSeparator_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("Na6st9mc_kSMqPtK2JqaNg.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomSeparatorOptionsRec();
rec.marginTopAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
rec.marginBottomAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
rec.stateAttr = ShopperPortalEUModel.staticEntities.customSeparatorState.lighter;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "18",
alias: "9"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}, function () {
return [];
}), $if(((OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("countryRule_vatRate1", model.variables.countrySelectedVar.valueAttr, callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id)) !== ("")), false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "heading6",
visible: true,
_idProps: {
service: idService,
uuid: "19"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "VAT rate"
},
value: "VAT rate",
_idProps: {
service: idService,
uuid: "20"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "body-4 margin-top-01",
visible: true,
_idProps: {
service: idService,
uuid: "21"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("JPjwyXWzlk2ygM5aIdNvlw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.justifyAttr = ShopperPortalEUModel.staticEntities.flexJustify.spaceBetween;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space1;
rec.wrapAttr = false;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "22",
alias: "10"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "countryRule_vatRate1"
},
style: "text-align-right",
value: model.getCachedValue(idService.getId("t7dY5C869UmkN_ANQvAeug.Value"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("countryRule_vatRate1", model.variables.countrySelectedVar.valueAttr, callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
}, function () {
return model.variables.countrySelectedVar.valueAttr;
}),
_idProps: {
service: idService,
uuid: "23"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.countrySelectedVar.valueAttr)]
}), $if(((OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("countryRule_vatRate2", model.variables.countrySelectedVar.valueAttr, callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id)) !== ("")), false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("IZSz1LZlaU2x0WowZaSNKg.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.justifyAttr = ShopperPortalEUModel.staticEntities.flexJustify.spaceBetween;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space1;
rec.wrapAttr = false;
return rec;
}();
}),
ExtendedClass: "margin-top-01"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "24",
alias: "11"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "countryRule_vatRate2"
},
value: model.getCachedValue(idService.getId("dZTiFbVMLU+3AsnEtib04A.Value"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("countryRule_vatRate2", model.variables.countrySelectedVar.valueAttr, callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
}, function () {
return model.variables.countrySelectedVar.valueAttr;
}),
_idProps: {
service: idService,
uuid: "25"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.countrySelectedVar.valueAttr)]
})];
}, function () {
return [];
}), $if(((OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("countryRule_vatRate3", model.variables.countrySelectedVar.valueAttr, callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id)) !== ("")), false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
ExtendedClass: "margin-top-01",
Options: model.getCachedValue(idService.getId("BUHF3yE8zkSEj99KjW1QXA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.justifyAttr = ShopperPortalEUModel.staticEntities.flexJustify.spaceBetween;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space1;
rec.wrapAttr = false;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "26",
alias: "12"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "countryRule_vatRate3"
},
value: model.getCachedValue(idService.getId("__1aIHl0b0KJe8u9mnuZVQ.Value"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("countryRule_vatRate3", model.variables.countrySelectedVar.valueAttr, callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
}, function () {
return model.variables.countrySelectedVar.valueAttr;
}),
_idProps: {
service: idService,
uuid: "27"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.countrySelectedVar.valueAttr)]
})];
}, function () {
return [];
}), $if(((OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("countryRule_vatRate4", model.variables.countrySelectedVar.valueAttr, callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id)) !== ("")), false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("Ay0VbBR42U66BZZlF7zbOA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.justifyAttr = ShopperPortalEUModel.staticEntities.flexJustify.spaceBetween;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space1;
rec.wrapAttr = false;
return rec;
}();
}),
ExtendedClass: "margin-top-01"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "28",
alias: "13"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "countryRule_vatRate4"
},
value: model.getCachedValue(idService.getId("pc4GkxIBK0y_3_2wuOcLeQ.Value"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("countryRule_vatRate4", model.variables.countrySelectedVar.valueAttr, callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
}, function () {
return model.variables.countrySelectedVar.valueAttr;
}),
_idProps: {
service: idService,
uuid: "29"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.countrySelectedVar.valueAttr)]
})];
}, function () {
return [];
}), $if(((OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("countryRule_vatRateRegion1", model.variables.countrySelectedVar.valueAttr, callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id)) !== ("")), false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
ExtendedClass: "margin-top-01",
Options: model.getCachedValue(idService.getId("8i51y71_aUOuZA2QwZCWcA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.justifyAttr = ShopperPortalEUModel.staticEntities.flexJustify.spaceBetween;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space1;
rec.wrapAttr = false;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "30",
alias: "14"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "countryRule_vatRateRegion1"
},
value: model.getCachedValue(idService.getId("UpYb1tt5lkike4uoLM5pCg.Value"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("countryRule_vatRateRegion1", model.variables.countrySelectedVar.valueAttr, callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
}, function () {
return model.variables.countrySelectedVar.valueAttr;
}),
_idProps: {
service: idService,
uuid: "31"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.countrySelectedVar.valueAttr)]
})];
}, function () {
return [];
}), $if(((OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("countryRule_vatRateRegion2", model.variables.countrySelectedVar.valueAttr, callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id)) !== ("")), false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
ExtendedClass: "margin-top-01",
Options: model.getCachedValue(idService.getId("VF0iMOJtOE2ZCryQ1qYjow.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.justifyAttr = ShopperPortalEUModel.staticEntities.flexJustify.spaceBetween;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space1;
rec.wrapAttr = false;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "32",
alias: "15"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "countryRule_vatRateRegion2"
},
value: model.getCachedValue(idService.getId("pWvJItwQ6kKbLtNY1pnblQ.Value"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("countryRule_vatRateRegion2", model.variables.countrySelectedVar.valueAttr, callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
}, function () {
return model.variables.countrySelectedVar.valueAttr;
}),
_idProps: {
service: idService,
uuid: "33"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.countrySelectedVar.valueAttr)]
})];
}, function () {
return [];
})), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomSeparator_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("CRJlTPVoxEu+neML2iY4iQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomSeparatorOptionsRec();
rec.marginTopAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
rec.marginBottomAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
rec.stateAttr = ShopperPortalEUModel.staticEntities.customSeparatorState.lighter;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "34",
alias: "16"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}, function () {
return [];
}), $if(((OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("countryRule_minSpend1", model.variables.countrySelectedVar.valueAttr, callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id)) !== ("")), false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "heading6",
visible: true,
_idProps: {
service: idService,
uuid: "35"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "MinimumSpend"
},
value: "Minimum spend",
_idProps: {
service: idService,
uuid: "36"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "body-4 margin-top-01",
visible: true,
_idProps: {
service: idService,
uuid: "37"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
ExtendedClass: "margin-top-01",
Options: model.getCachedValue(idService.getId("r4Q5zXBzRkyUZsUTJKZnlA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.justifyAttr = ShopperPortalEUModel.staticEntities.flexJustify.spaceBetween;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space1;
rec.wrapAttr = false;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "38",
alias: "17"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "countryRule_minSpend1"
},
value: model.getCachedValue(idService.getId("aP75b7wJUkeF0bbRBh6ljg.Value"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("countryRule_minSpend1", model.variables.countrySelectedVar.valueAttr, callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
}, function () {
return model.variables.countrySelectedVar.valueAttr;
}),
_idProps: {
service: idService,
uuid: "39"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.countrySelectedVar.valueAttr)]
}), $if(((OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("countryRule_minSpend2", model.variables.countrySelectedVar.valueAttr, callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id)) !== ("")), false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("WQ77zpVa3EaI9Np82w6LgQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.justifyAttr = ShopperPortalEUModel.staticEntities.flexJustify.spaceBetween;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space1;
rec.wrapAttr = false;
return rec;
}();
}),
ExtendedClass: "margin-top-01"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "40",
alias: "18"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "countryRule_minSpend2"
},
value: model.getCachedValue(idService.getId("DAcE5W0WF0K85euPe7qyGQ.Value"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("countryRule_minSpend2", model.variables.countrySelectedVar.valueAttr, callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
}, function () {
return model.variables.countrySelectedVar.valueAttr;
}),
_idProps: {
service: idService,
uuid: "41"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.countrySelectedVar.valueAttr)]
})];
}, function () {
return [];
}), $if(((OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("countryRule_minSpend3", model.variables.countrySelectedVar.valueAttr, callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id)) !== ("")), false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("xdhM9hnAyUymijXgr0qOtg.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.justifyAttr = ShopperPortalEUModel.staticEntities.flexJustify.spaceBetween;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space1;
rec.wrapAttr = false;
return rec;
}();
}),
ExtendedClass: "margin-top-01"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "42",
alias: "19"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "countryRule_minSpend3"
},
value: model.getCachedValue(idService.getId("C2uUOSy1w0mA1eIMPBZzAw.Value"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("countryRule_minSpend3", model.variables.countrySelectedVar.valueAttr, callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
}, function () {
return model.variables.countrySelectedVar.valueAttr;
}),
_idProps: {
service: idService,
uuid: "43"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.countrySelectedVar.valueAttr)]
})];
}, function () {
return [];
}), $if(((OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("countryRule_minSpend4", model.variables.countrySelectedVar.valueAttr, callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id)) !== ("")), false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
ExtendedClass: "margin-top-01",
Options: model.getCachedValue(idService.getId("DIP43r6MeEi7glH4eqV6+A.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.justifyAttr = ShopperPortalEUModel.staticEntities.flexJustify.spaceBetween;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space1;
rec.wrapAttr = false;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "44",
alias: "20"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "countryRule_minSpend4"
},
value: model.getCachedValue(idService.getId("uqMXggEH9ECEmM7N+baExw.Value"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("countryRule_minSpend4", model.variables.countrySelectedVar.valueAttr, callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
}, function () {
return model.variables.countrySelectedVar.valueAttr;
}),
_idProps: {
service: idService,
uuid: "45"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.countrySelectedVar.valueAttr)]
})];
}, function () {
return [];
}), $if(((OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("countryRule_minSpend5", model.variables.countrySelectedVar.valueAttr, callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id)) !== ("")), false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("RM0H4RGsRkajvB5mN7Roig.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.justifyAttr = ShopperPortalEUModel.staticEntities.flexJustify.spaceBetween;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space1;
rec.wrapAttr = false;
return rec;
}();
}),
ExtendedClass: "margin-top-01"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "46",
alias: "21"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "countryRule_minSpend5"
},
value: model.getCachedValue(idService.getId("Vm4XUo2g9kGli2Q4SxpjDw.Value"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("countryRule_minSpend5", model.variables.countrySelectedVar.valueAttr, callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
}, function () {
return model.variables.countrySelectedVar.valueAttr;
}),
_idProps: {
service: idService,
uuid: "47"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.countrySelectedVar.valueAttr)]
})];
}, function () {
return [];
}), $if(((OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("countryRule_minSpend6", model.variables.countrySelectedVar.valueAttr, callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id)) !== ("")), false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("sdkWxn926kG1i83niQ3Ldg.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.justifyAttr = ShopperPortalEUModel.staticEntities.flexJustify.spaceBetween;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space1;
rec.wrapAttr = false;
return rec;
}();
}),
ExtendedClass: "margin-top-01"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "48",
alias: "22"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "countryRule_minSpend6"
},
value: model.getCachedValue(idService.getId("+IeVjOwPPU2JwpY8XPp2JQ.Value"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("countryRule_minSpend6", model.variables.countrySelectedVar.valueAttr, callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
}, function () {
return model.variables.countrySelectedVar.valueAttr;
}),
_idProps: {
service: idService,
uuid: "49"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.countrySelectedVar.valueAttr)]
})];
}, function () {
return [];
})), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomSeparator_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("EnE4mzuZhUadgCvKqllrgA.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomSeparatorOptionsRec();
rec.marginTopAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
rec.stateAttr = ShopperPortalEUModel.staticEntities.customSeparatorState.lighter;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "50",
alias: "23"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}, function () {
return [];
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.countrySelectedVar.valueAttr)]
})];
}, function () {
return [];
}), $if((((OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("countryRule_timeLimit1", model.variables.countrySelectedVar.valueAttr, callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id)) !== ("")) || ((OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("countryRule_eligibility1", model.variables.countrySelectedVar.valueAttr, callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id)) !== (""))), false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomCard_mvc_view, {
inputs: {
ExtendedClass: "margin-top-04"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "51",
alias: "24"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [$if(((OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("countryRule_timeLimit1", model.variables.countrySelectedVar.valueAttr, callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id)) !== ("")), false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "heading6",
visible: true,
_idProps: {
service: idService,
uuid: "52"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "TimeLimitToExportYourGoods"
},
value: "Time limit to export your goods",
_idProps: {
service: idService,
uuid: "53"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "body-4 margin-top-01",
visible: true,
_idProps: {
service: idService,
uuid: "54"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("EOA6v5Ew00qSw9PxWBjJiw.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.justifyAttr = ShopperPortalEUModel.staticEntities.flexJustify.spaceBetween;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space1;
rec.wrapAttr = false;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "55",
alias: "25"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "countryRule_timeLimit1"
},
value: model.getCachedValue(idService.getId("7fuxps_AdUeJI5QfdFwQzw.Value"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("countryRule_timeLimit1", model.variables.countrySelectedVar.valueAttr, callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
}, function () {
return model.variables.countrySelectedVar.valueAttr;
}),
_idProps: {
service: idService,
uuid: "56"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.countrySelectedVar.valueAttr)]
}), $if(((OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("countryRule_timeLimit2", model.variables.countrySelectedVar.valueAttr, callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id)) !== ("")), false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("6+QVOBs8bEKuuoeLezElFg.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.justifyAttr = ShopperPortalEUModel.staticEntities.flexJustify.spaceBetween;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space1;
rec.wrapAttr = false;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "57",
alias: "26"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "countryRule_timeLimit2"
},
value: model.getCachedValue(idService.getId("C2O++x50dk6fVILRptvHVA.Value"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("countryRule_timeLimit2", model.variables.countrySelectedVar.valueAttr, callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
}, function () {
return model.variables.countrySelectedVar.valueAttr;
}),
_idProps: {
service: idService,
uuid: "58"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.countrySelectedVar.valueAttr)]
})];
}, function () {
return [];
})), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomSeparator_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("5rwIOV_otkGf64I5miRTwg.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomSeparatorOptionsRec();
rec.marginTopAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
rec.marginBottomAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
rec.stateAttr = ShopperPortalEUModel.staticEntities.customSeparatorState.lighter;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "59",
alias: "27"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}, function () {
return [];
}), $if(((OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("countryRule_eligibility1", model.variables.countrySelectedVar.valueAttr, callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id)) !== ("")), false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "heading6",
visible: true,
_idProps: {
service: idService,
uuid: "60"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "Eligibility"
},
value: "Eligibility",
_idProps: {
service: idService,
uuid: "61"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "body-4 margin-top-01",
visible: true,
_idProps: {
service: idService,
uuid: "62"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("i_Nro5ZuskqU0lt2eDVX4w.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.justifyAttr = ShopperPortalEUModel.staticEntities.flexJustify.spaceBetween;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space1;
rec.wrapAttr = false;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "63",
alias: "28"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "countryRule_eligibility1"
},
value: model.getCachedValue(idService.getId("WGc6ovlWO0qsQiDSTjvpyw.Value"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("countryRule_eligibility1", model.variables.countrySelectedVar.valueAttr, callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
}, function () {
return model.variables.countrySelectedVar.valueAttr;
}),
_idProps: {
service: idService,
uuid: "64"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.countrySelectedVar.valueAttr)]
}), $if(((OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("countryRule_eligibility2", model.variables.countrySelectedVar.valueAttr, callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id)) !== ("")), false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("j9sXWxLUE0mejXKoytDEOQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.justifyAttr = ShopperPortalEUModel.staticEntities.flexJustify.spaceBetween;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space1;
rec.wrapAttr = false;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "65",
alias: "29"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "countryRule_eligibility2"
},
value: model.getCachedValue(idService.getId("lg0hl5GHhkSA8LLqXAsrSA.Value"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("countryRule_eligibility2", model.variables.countrySelectedVar.valueAttr, callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
}, function () {
return model.variables.countrySelectedVar.valueAttr;
}),
_idProps: {
service: idService,
uuid: "66"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.countrySelectedVar.valueAttr)]
})];
}, function () {
return [];
}), $if(((OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("countryRule_eligibility3", model.variables.countrySelectedVar.valueAttr, callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id)) !== ("")), false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("I_znggFRl0S2igtEOH5kKQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.justifyAttr = ShopperPortalEUModel.staticEntities.flexJustify.spaceBetween;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space1;
rec.wrapAttr = false;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "67",
alias: "30"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "countryRule_eligibility3"
},
value: model.getCachedValue(idService.getId("+VaBli1kVUKBsBjtBC8VFg.Value"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("countryRule_eligibility3", model.variables.countrySelectedVar.valueAttr, callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
}, function () {
return model.variables.countrySelectedVar.valueAttr;
}),
_idProps: {
service: idService,
uuid: "68"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.countrySelectedVar.valueAttr)]
})];
}, function () {
return [];
}), $if(((OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("countryRule_eligibility4", model.variables.countrySelectedVar.valueAttr, callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id)) !== ("")), false, this, function () {
return [React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_Flex_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("c7h_NEW12UKb0WLV4ADJjQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.FlexOptionsRec();
rec.justifyAttr = ShopperPortalEUModel.staticEntities.flexJustify.spaceBetween;
rec.spacingAttr = ShopperPortalEUModel.staticEntities.spacing.space1;
rec.wrapAttr = false;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "69",
alias: "31"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "countryRule_eligibility4"
},
value: model.getCachedValue(idService.getId("rZZdjLBy8U6oOULz+7cU9Q.Value"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return ShopperPortalEUController.default.tRuleWrapper$Action("countryRule_eligibility4", model.variables.countrySelectedVar.valueAttr, callContext).textOut;
}, OS.DataTypes.DataTypes.Text, callContext.id);
}, function () {
return model.variables.countrySelectedVar.valueAttr;
}),
_idProps: {
service: idService,
uuid: "70"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.countrySelectedVar.valueAttr)]
})];
}, function () {
return [];
})), React.createElement(ShopperPortalEU_UI_Components_ShopperPortalEUUIComponents_CustomSeparator_mvc_view, {
inputs: {
Options: model.getCachedValue(idService.getId("DBezG4PN_ECUUXHc57vArQ.Options"), function () {
return function () {
var rec = new ShopperPortalEU_UI_ComponentsModel.CustomSeparatorOptionsRec();
rec.marginTopAttr = ShopperPortalEUModel.staticEntities.spacing.space2;
rec.stateAttr = ShopperPortalEUModel.staticEntities.customSeparatorState.lighter;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "71",
alias: "32"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}, function () {
return [];
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.countrySelectedVar.valueAttr)]
})];
}, function () {
return [];
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.countrySelectedVar.valueAttr), asPrimitiveValue(model.variables.getCountriesAndUserLocationDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.getCountriesAndUserLocationDataAct.eUCountryListOut)]
})];
}),
bottom: PlaceholderContent.Empty
},
_dependencies: [asPrimitiveValue(model.variables.countrySelectedVar.valueAttr), asPrimitiveValue(model.variables.getCountriesAndUserLocationDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.getCountriesAndUserLocationDataAct.eUCountryListOut), asPrimitiveValue(model.variables.isScreenReadyVar)]
}));
        };
        return View;
    })(OSView.BaseView.BaseWebScreen);
	
    return View;
});
define("ShopperPortalEU.Support.CountryRules.mvc$controller", ["OutSystems/ClientRuntime/Main", "ShopperPortalEU.model", "ShopperPortalEU.controller", "ShopperPortalEU_UI_Components.model", "ShopperPortalEU_UI_Theme.model", "ShopperPortalEU_API.model", "ShopperPortalEU.languageResources", "ShopperPortalEU.clientVariables", "ShopperPortalEU.Support.CountryRules.mvc$debugger", "ShopperPortalEU.Support.controller", "ShopperPortalEU.controller$TRuleWrapper", "ShopperPortalEU_UI_Components.model$CustomDropdownListValueOptionsRec", "ShopperPortalEU.referencesHealth", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Components", "ShopperPortalEU_UI_Theme.model$LayoutOptionsRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_UI_Theme", "ShopperPortalEU_UI_Theme.model$LayoutHeaderOptionsRec", "ShopperPortalEU.model$LayoutAuthenticationRec", "ShopperPortalEU.model$ApplicationHeaderRec", "ShopperPortalEU.model$CountriesWithFlagsDropdownListList", "ShopperPortalEU_UI_Components.model$CustomDropdownListValidationOptionsRec", "ShopperPortalEU_UI_Components.model$CustomAlertOptionsRec", "ShopperPortalEU_UI_Components.model$CustomAlertIconOptionsRec", "ShopperPortalEU_UI_Components.model$FlexOptionsRec", "ShopperPortalEU_UI_Components.model$CustomCardOptionsRec", "ShopperPortalEU_UI_Components.model$CustomSeparatorOptionsRec", "ShopperPortalEU_UI_Components.model$CustomSeparatorLabelOptionsRec", "ShopperPortalEU_API.model$SPCountry_WrapperRec", "ShopperPortalEU.referencesHealth$ShopperPortalEU_API", "ShopperPortalEU.model$SPCountry_WrapperList", "ShopperPortalEU_API.model$Location_WrapperRec"], function (OutSystems, ShopperPortalEUModel, ShopperPortalEUController, ShopperPortalEU_UI_ComponentsModel, ShopperPortalEU_UI_ThemeModel, ShopperPortalEU_APIModel, ShopperPortalEULanguageResources, ShopperPortalEUClientVariables, ShopperPortalEU_Support_CountryRules_mvc_Debugger, ShopperPortalEU_SupportController) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {
getCountriesAndUserLocation$DataActRefresh: 0
};
this.dataFetchDependentsGraph = {
getCountriesAndUserLocation$DataActRefresh: []
};
this.shouldSendClientVarsToDataSources = true;
}
// Server Actions

// Aggregates and Data Actions
Controller.prototype.getCountriesAndUserLocation$DataActRefresh = function (callContext) {
var model = this.model;
var controller = this.controller;
var callContext = controller.callContext(callContext);
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:2IO4NtG0dUO3LJ+fj3IsPw:/NRWebFlows._1zAHv5LwEGws6WRTm11hA/NodesShownInESpaceTree.SfsWLxkAiUW+PGziwD9LKA/DataActions.2IO4NtG0dUO3LJ+fj3IsPw:SjSj93Hl+boy37TO24_XGg", "ShopperPortalEU", "GetCountriesAndUserLocation", "NRFlows.DataScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.setThreadStartName(callContext.id, "Support/CountryRules/GetCountriesAndUserLocation");
return controller.callDataAction("DataActionGetCountriesAndUserLocation", "screenservices/ShopperPortalEU/Support/CountryRules/DataActionGetCountriesAndUserLocation", "Kv0IRXQlXW9qFC3ok_hMNQ", function (b) {
model.variables.getCountriesAndUserLocationDataAct.dataFetchStatusAttr = b;
}, function (json) {
model.variables.getCountriesAndUserLocationDataAct.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getCountriesAndUserLocationDataAct.constructor));
}, undefined, OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, callContext, ShopperPortalEUClientVariables, false).then(function () {
OutSystemsDebugger.setThreadStartName(callContext.id, "Support/CountryRules/GetCountriesAndUserLocation On After Fetch");
controller._getCountriesAndUserLocationOnAfterFetch$Action(controller.callContext(callContext));

});

}, function () {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:2IO4NtG0dUO3LJ+fj3IsPw", callContext.id);
controller.popDebuggerContext(callContext);

});
};

Controller.prototype.dataFetchActionNames = ["getCountriesAndUserLocation$DataActRefresh"];
// Client Actions
Controller.prototype._countryOnChange$Action = function (currentCountryIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("CountryOnChange");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("ShopperPortalEU.Support.CountryRules.CountryOnChange$vars"))());
vars.value.currentCountryInLocal = currentCountryIn.clone();
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:1KRjoJVbF02hezcy5H4+7w:/NRWebFlows._1zAHv5LwEGws6WRTm11hA/NodesShownInESpaceTree.SfsWLxkAiUW+PGziwD9LKA/ClientActions.1KRjoJVbF02hezcy5H4+7w:KvV3J0leRHZ825A8lvcI0g", "ShopperPortalEU", "CountryOnChange", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:my4iy6wCs0CgUIPDxBXDoQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:aAFcE2DhHEyKlbv36Ui05w", callContext.id);
// CountrySelected.Text = ""
model.variables.countrySelectedVar.textAttr = "";
// CountrySelected
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:HB8FMd0j+kOfD9jBKVwn6w", callContext.id);
// CountrySelected = CurrentCountry
model.variables.countrySelectedVar = vars.value.currentCountryInLocal;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:HMzl3oegXEaRIt8WXswXmg", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:1KRjoJVbF02hezcy5H4+7w", callContext.id);
}

};
Controller.registerVariableGroupType("ShopperPortalEU.Support.CountryRules.CountryOnChange$vars", [{
name: "CurrentCountry",
attrName: "currentCountryInLocal",
mandatory: true,
dataType: OS.DataTypes.DataTypes.Record,
defaultValue: function () {
return new ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValueOptionsRec();
},
complexType: ShopperPortalEU_UI_ComponentsModel.CustomDropdownListValueOptionsRec
}]);
Controller.prototype._getCountriesAndUserLocationOnAfterFetch$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("GetCountriesAndUserLocationOnAfterFetch");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:Tpu+uKV_Ak2BdnPNyh7VhQ:/NRWebFlows._1zAHv5LwEGws6WRTm11hA/NodesShownInESpaceTree.SfsWLxkAiUW+PGziwD9LKA/ClientActions.Tpu+uKV_Ak2BdnPNyh7VhQ:aGruE+ux9e2vtYH8XLf5bg", "ShopperPortalEU", "GetCountriesAndUserLocationOnAfterFetch", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:XkKkmAZPGkO3OXa8eMBK3w", callContext.id);
// User Location ?
if((OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:ge1EztEgr0uR8cv_BKEw_Q", callContext.id) && ((model.variables.getCountriesAndUserLocationDataAct.locationOut.countryAttr) !== ("")))) {
// CountrySelected
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:+BmTk1+F9kSTBswHNUSuag", callContext.id);
// CountrySelected.Text = GetCountriesAndUserLocation.Location.Country
model.variables.countrySelectedVar.textAttr = model.variables.getCountriesAndUserLocationDataAct.locationOut.countryAttr;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:+BmTk1+F9kSTBswHNUSuag", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// CountrySelected.Value = GetCountriesAndUserLocation.Location.CountryCode
model.variables.countrySelectedVar.valueAttr = model.variables.getCountriesAndUserLocationDataAct.locationOut.countryCodeAttr;
} else {
// CountrySelected
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:1yNF5mEJvUmynfZvy_z4ZQ", callContext.id);
// CountrySelected.Text = GetCountriesAndUserLocation.EUCountryList.Current.Name
model.variables.countrySelectedVar.textAttr = model.variables.getCountriesAndUserLocationDataAct.eUCountryListOut.getCurrent(callContext.iterationContext).nameAttr;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:1yNF5mEJvUmynfZvy_z4ZQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// CountrySelected.Value = GetCountriesAndUserLocation.EUCountryList.Current.Code2
model.variables.countrySelectedVar.valueAttr = model.variables.getCountriesAndUserLocationDataAct.eUCountryListOut.getCurrent(callContext.iterationContext).code2Attr;
}

OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:4VmLKgZ0TUiQZNpOGmuEEw", callContext.id);
// IsScreenReady = True
model.variables.isScreenReadyVar = true;
OutSystemsDebugger.handleBreakpoint("sVWao32nAUKeYxPPAcjqKg:b8Epq2CDykiuhcGCzWCuUA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:Tpu+uKV_Ak2BdnPNyh7VhQ", callContext.id);
}

};

Controller.prototype.countryOnChange$Action = function (currentCountryIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._countryOnChange$Action, callContext, currentCountryIn);

};
Controller.prototype.getCountriesAndUserLocationOnAfterFetch$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._getCountriesAndUserLocationOnAfterFetch$Action, callContext);

};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:_1zAHv5LwEGws6WRTm11hA:/NRWebFlows._1zAHv5LwEGws6WRTm11hA:mL1lLGIiQoiQpGIO1O5tXg", "ShopperPortalEU", "Support", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("sVWao32nAUKeYxPPAcjqKg:SfsWLxkAiUW+PGziwD9LKA:/NRWebFlows._1zAHv5LwEGws6WRTm11hA/NodesShownInESpaceTree.SfsWLxkAiUW+PGziwD9LKA:2yPJedx2loeWJ7WVJ8sfsQ", "ShopperPortalEU", "CountryRules", "NRNodes.WebScreen", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:SfsWLxkAiUW+PGziwD9LKA", callContext.id);
OutSystemsDebugger.pop("sVWao32nAUKeYxPPAcjqKg:_1zAHv5LwEGws6WRTm11hA", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return ShopperPortalEU_SupportController.default.handleError(ex, this.callContext());
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return ShopperPortalEUController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, ShopperPortalEULanguageResources);
});

define("ShopperPortalEU.Support.CountryRules.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"J2PO6yUK4EusC5vUOqzotQ": {
getter: function (varBag, idService) {
return varBag.vars.value.currentCountryInLocal;
}
},
"0rfG9qlgFUCJE_HEou8NTQ": {
getter: function (varBag, idService) {
return varBag.model.variables.countrySelectedVar;
}
},
"xkZlLUQmAEK+jWZ7NsOBLQ": {
getter: function (varBag, idService) {
return varBag.model.variables.isScreenReadyVar;
},
dataType: OS.DataTypes.DataTypes.Boolean
},
"2IO4NtG0dUO3LJ+fj3IsPw": {
getter: function (varBag, idService) {
return varBag.model.variables.getCountriesAndUserLocationDataAct;
}
},
"KM39R_0U7Eyhzx7XcM+SWA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderLeft"));
})(varBag.model, idService);
}
},
"ev_lbbaTCUKIN_oSPdg8Qg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderCenter"));
})(varBag.model, idService);
}
},
"Vk+eWQ84o02yKWQQs9xEQg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderRight"));
})(varBag.model, idService);
}
},
"Hs4R5K+74kSsQqEEqfy5Ng": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HeaderBottom"));
})(varBag.model, idService);
}
},
"GgwZ47zjj0uuBdo8hzUrnQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"7yt+EYkczUKs0cAhUNDZtA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"AkwWo6TIe0OTWIzTu2+p7A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Label"));
})(varBag.model, idService);
}
},
"jeh6BCylsEyVKVENSx18JA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("ShowCustomAlert"));
})(varBag.model, idService);
}
},
"a+JPydcuyEuw3n8ugikIvQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"PFBFk_8IHEuOKzRal5oLcA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"ez1HqkNqWEWIR+w+3IC5UA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"61RcAfYj1keIlN4jbZVqIw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("ShowCard1"));
})(varBag.model, idService);
}
},
"IY2Zhoae8EqNcf8Bvs33rQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"ODY0z3y4ZEaC8vW355uxJg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HasCurrency"));
})(varBag.model, idService);
}
},
"dkc+KfgmCkKdrw8Cng9NPw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HasVat"));
})(varBag.model, idService);
}
},
"2Gwegj3pyUWgXgv21FVvLQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"DtLh_exreU+Sb8foTRYAJQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"E4VanDyj4kKgb7hubUN8Vg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"5seI14bkTUmDDEfeBV_UPA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"YP7Kk+HLrE2tsqAYiCw5vA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"MQfhIXKHPEmxgjCYy4Qcdw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"4NPZKTBSpUaeF2g2eLgEAA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HasMinimumSpend"));
})(varBag.model, idService);
}
},
"ZqnG0RsJfkG7kCidJNmmkw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"sC7qtwXTwUetv7mmgAnM1g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("countryRule_minSpend2"));
})(varBag.model, idService);
}
},
"Un+qSB9V10qTVwa0HAwRxQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"teASs7m7S0qh_chlwAjhTg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("countryRule_minSpend3"));
})(varBag.model, idService);
}
},
"wAHD9uXpVka7M5nrNDM6qg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"qwY62luQ2EeGe5gknoESJQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("countryRule_minSpend4"));
})(varBag.model, idService);
}
},
"sGbfZBk_UUmzHI9wPoMK7Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"7XDOkGS6lEiHu9lb111rvA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("countryRule_minSpend5"));
})(varBag.model, idService);
}
},
"RwPDbwuMSEqIA54v9idZ9Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"KPs9cwx_bE+pTW2OQ1OVuQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("countryRule_minSpend6"));
})(varBag.model, idService);
}
},
"vDRhep30DEiLiM1pRzfMng": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"+AQI16X2KkOyDBcrC+GUGg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("ShowCard2"));
})(varBag.model, idService);
}
},
"V1kt+Rqt2EOMCZ9yuyXkYw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"hFAqh5JwxEShekw_dOphuA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HasTimeLimitInfo"));
})(varBag.model, idService);
}
},
"zcW_ob7bq02FwG2tJjKX1g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"kKLzIi_3dEqUUpx0eura_Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("countryRule_timeLimit2"));
})(varBag.model, idService);
}
},
"xtnDVE1dIEKtnx27RUKyHg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"LtGXN5SC90+XHVVBscfLdg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HasEligibilityInfo"));
})(varBag.model, idService);
}
},
"TFw5gj1jFE2JtvDoZ2amQQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"NE3WHSd3VUmu5sdcOdoEWQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("countryRule_eligibility2"));
})(varBag.model, idService);
}
},
"I3ITrjIel0yuHgInbQKEdg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"YZEkx1L7vkO5p_lLpk1lfA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("countryRule_eligibility3"));
})(varBag.model, idService);
}
},
"JAnTUkoo9EC9tz5eaCkBxw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"Hw8HovVkTEiXfFKWKIxFRw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("countryRule_eligibility4"));
})(varBag.model, idService);
}
},
"QoBPiec6sEei9V8tUu4FCw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"CSlDsSYGqEypPmpcsI60lA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Bottom"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
